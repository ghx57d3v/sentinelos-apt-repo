# Sentinel Pantry v1.0.1 Security Hotfix

This hotfix preserves the v1.0.0 feature baseline and fixes audit findings:

- Enforces do-not-consume reserve locks before consuming/wasting/reducing stock.
- Requires typed confirmation for destructive database restore.
- Requires typed confirmation for CLI permanent delete.
- Applies best-effort 0700 directory / 0600 file permissions to user-local Pantry data.
- Escapes spreadsheet formula-leading text cells in CSV exports.
- Scrubs static AEGIS manifest build-host paths.

No network capability or telemetry was added.
