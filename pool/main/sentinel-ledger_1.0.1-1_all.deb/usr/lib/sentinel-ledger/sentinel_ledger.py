#!/usr/bin/env python3
"""
Sentinel Ledger v1.0.1
Program 107 — local-first business ledger for SentinelOS / AEGIS.

This build keeps the v0.2.x Sentinel/AEGIS theme, launcher, local SQLite design,
AEGIS health output, workflow hotkeys, and double-entry accounting base.
"""
from __future__ import annotations

import argparse
import base64
import csv
import getpass
import hmac
import datetime as _dt
import hashlib
import json
import os
import shutil
import subprocess
import zipfile
import sqlite3
import stat
import sys
from dataclasses import dataclass
from decimal import Decimal, ROUND_HALF_UP, InvalidOperation
from pathlib import Path
from typing import Iterable, Optional

APP_NAME = "Sentinel Ledger"
APP_ID = "sentinel-ledger"
PROGRAM_ID = "107"
VERSION = "1.0.1"
SCHEMA_VERSION = "13"
FEATURE_LEVEL = 10
LOCAL_ONLY = True
DB_ENV = "SENTINEL_LEDGER_DB"
ROOT_WRITE_OVERRIDE_ENV = "SENTINEL_LEDGER_ALLOW_ROOT_WRITE"
MAX_BACKUP_JSON_BYTES = 250 * 1024 * 1024
MAX_IMPORT_CSV_BYTES = 50 * 1024 * 1024
MAX_IMPORT_CSV_ROWS = 10000
MAX_RESTORE_ROWS_PER_TABLE = 500000
PRIVATE_FILE_MAX_BYTES = 1024 * 1024


ACCOUNT_TYPES = ("asset", "liability", "equity", "income", "expense")
CONTACT_TYPES = ("customer", "supplier", "both", "other")
SIDES = ("debit", "credit")

DEFAULT_CHART = [
    ("1000", "Cash", "asset"),
    ("1010", "Business Bank", "asset"),
    ("1020", "Card Clearing", "asset"),
    ("1100", "Accounts Receivable", "asset"),
    ("1200", "Inventory Asset", "asset"),
    ("1300", "GST / Tax Paid", "asset"),
    ("2000", "Accounts Payable", "liability"),
    ("2200", "GST / Tax Collected", "liability"),
    ("3000", "Owner Equity", "equity"),
    ("3100", "Owner Drawings", "equity"),
    ("3200", "Opening Balance Equity", "equity"),
    ("4000", "Sales", "income"),
    ("4100", "Service Revenue", "income"),
    ("5000", "Purchases", "expense"),
    ("5100", "Rent", "expense"),
    ("5200", "Utilities", "expense"),
    ("5300", "Repairs and Maintenance", "expense"),
    ("5400", "Fuel and Vehicle", "expense"),
    ("5500", "Tools and Equipment", "expense"),
    ("5600", "Office Supplies", "expense"),
    ("5700", "Bank Fees", "expense"),
]

DEFAULT_TAX_CODES = [
    ("GST", "GST taxable sale/purchase", 1000, "taxable", 1),
    ("GSTFREE", "GST-free sale/purchase", 0, "gst_free", 1),
    ("NOGST", "No GST / out of scope", 0, "no_gst", 1),
    ("INPUTTAXED", "Input-taxed / no GST credit", 0, "input_taxed", 1),
    ("CAPITAL", "Capital purchase with GST", 1000, "capital", 1),
    ("PRIVATE", "Private/non-business portion", 0, "private", 1),
]

BACKUP_TABLES = [
    "business_profile", "accounts", "contacts", "journal_entries", "journal_lines",
    "document_refs", "period_locks", "invoices", "bills", "tax_codes",
    "payment_methods", "recurring_templates", "import_queue",
    "schema_migrations", "backup_registry", "recovery_audit", "security_audit", "meta",
]

RECOVERY_FEATURES = {
    "sqlite_pragmas": ["foreign_keys", "journal_mode=WAL", "synchronous=FULL", "busy_timeout=5000"],
    "automatic_pre_migration_copy": True,
    "backup_registry": True,
    "restore_check": True,
    "restore_to_new_database": True,
    "aegis_safe_summary": True,
    "hidden_internal_menu_entries": True,
    "complete_dark_gui_widgets": True,
    "receipt_reference_index": True,
    "readable_report_layout": True,
    "manual_tab": True,
    "copy_paste_report_text": True,
    "deductions_guide": True,
    "accountant_bas_report_export": True,
    "aegis_vault_metadata_index": True,
    "separate_taxes_tab": True,
    "reports_tab_read_only": True,
    "accountant_handoff_from_reports": True,
    "first_run_setup_wizard": True,
    "multi_ledger_profiles": True,
    "human_readable_gst_status": True,
    "human_readable_invoice_safety": True,
    "accountant_suggested_deductions_appendix": True,
    "ledger_menu_profile_switcher": True,
    "blank_setup_wizard_from_menu": True,
    "dashboard_compact_totals_header": True,
    "receipt_template_designer": True,
    "sale_receipt_live_preview": True,
    "inventory_bridge_contract": True,
    "aegis_capability_manifest": True,
    "phase1_stability_print_workflow_qa": True,
    "receipt_sequence_numbers": True,
    "receipt_print_open_flow": True,
    "ledger_switch_safety": True,
    "aegis_readiness_command": True,
    "phase2_security_hardening": True,
    "ledger_lock": True,
    "strict_file_permissions": True,
    "security_audit_log": True,
    "password_protected_backup_container": True,
    "redaction_mode": True,
    "no_network_self_check": True,
    "aegis_read_only_permission_boundary": True,
    "idle_lock_setting": True,
    "phase3_data_integrity_recovery_hardening": True,
    "deep_integrity_check": True,
    "human_recovery_report": True,
    "restore_wizard_status": True,
    "backup_schedule_status": True,
    "pre_upgrade_backup_enforcement_status": True,
    "read_only_repair_diagnostics": True,
    "reports_buttons_two_row_symmetry": True,
    "quick_expense_compact_form": True,
    "quick_expense_review_preview": True,
    "phase4_business_workflow_completion": True,
    "payment_methods": True,
    "contact_detail_search_update": True,
    "recurring_entries": True,
    "gui_attachment_linking": True,
    "business_workflow_status": True,

    "phase6_aegis_sentinel_command_integration": True,
    "sentinel_command_status_contract": True,
    "aegis_report_index": True,
    "aegis_risk_flags": True,
    "aegis_permission_map": True,
    "sentinel_command_registration": True,
    "final_aegis_command_contract": True,
    "phase7_release_candidate": True,
    "phase8_v1_user_ready_baseline": True,
    "feature_freeze_rc": True,
    "v1_stable_lock": True,
    "ddmmyyyy_display_dates": True,
    "manual_docs_release_candidate_pass": True,
    "install_upgrade_rc_checks": True,
    "manual_docs_v1_pass": True,
    "v1_stable_schema_contract": True,
}

SENTINEL_THEME = {
    "bg": "#151A20",
    "panel": "#20262E",
    "panel_alt": "#27303A",
    "header": "#10151B",
    "field": "#0F141A",
    "field_text": "#EEF4F7",
    "report_bg": "#0F141A",
    "report_bg_alt": "#151A20",
    "report_text": "#EEF4F7",
    "report_border": "#E19B00",
    "text": "#EEF4F7",
    "muted": "#AEB8C2",
    "gold": "#E19B00",
    "gold_light": "#FFD36A",
    "cyan": "#03C8FF",
    "danger": "#D95C5C",
    "ok": "#7BD88F",
}
THEME_NAME = "Sentinel Dark / AEGIS Gold"
HOTKEYS = {
    "close_application": "Ctrl+Q",
    "save_active_entry": "Ctrl+S",
    "refresh_active_view": "Ctrl+R",
    "show_aegis_health_report": "Ctrl+H",
    "backup_json": "Ctrl+B",
    "export_csv": "Ctrl+E",
    "copy_selection": "Ctrl+C",
    "paste_clipboard": "Ctrl+V",
    "select_all_text": "Ctrl+A",
}
HOTKEY_STATUS = {
    "enabled": True,
    "profile": "stable-v1.0.1",
    "scope": "gui",
    "hotkeys": HOTKEYS,
}


DEDUCTION_GUIDE = [
    {
        "category": "Core claim rules",
        "items": [
            "Review expenses that directly relate to earning business or work income.",
            "Keep evidence: receipts, invoices, bank records, diary notes, logbooks, photos, supplier records, and calculation notes.",
            "Apportion mixed business/private costs and record the business percentage used.",
            "Do not include reimbursed costs as suggested deductions.",
            "Treat this guide as accountant-prep prompts, not automatic lodgement or final tax advice.",
        ],
    },
    {
        "category": "Repairs, devices, tools, and workshop",
        "items": [
            "Repair parts, replacement components, consumables, screens, batteries, cables, connectors, adhesives, cleaning fluids, thermal paste, solder, flux, labels, packaging, and shipping used for jobs.",
            "Tools and diagnostic gear: multimeters, test leads, soldering gear, screwdrivers, clamps, benches, anti-static mats, storage drawers, shelves, lighting, magnifiers, cameras, and safety gear used for business.",
            "Decline-in-value/depreciation review for phones, laptops, tablets, printers, cameras, power tools, test equipment, benches, storage, and other assets used beyond a short period.",
            "Repairs and maintenance on business-use tools, workshop gear, storage, benches, computers, phones, printers, and diagnostic equipment.",
        ],
    },
    {
        "category": "Home office / home workshop running costs",
        "items": [
            "Business-use portion of electricity, heating/cooling, lighting, cleaning, internet, phone, and other running costs for a genuine work area.",
            "Dedicated workshop or storage area costs may need accountant review, especially where occupancy-style costs or mixed private/business space are involved.",
            "Stationery, printer ink, paper, labels, envelopes, storage containers, folders, backup drives, and admin supplies.",
            "Security, locks, cabinets, fire protection, surge protection, UPS units, and backup devices used to protect business records or customer devices.",
        ],
    },
    {
        "category": "Vehicle, travel, and pickup/drop-off costs",
        "items": [
            "Business trips to customers, suppliers, post office, couriers, accountants, bank, parts pickup, job sites, repair drop-offs, and equipment purchasing.",
            "Fuel, parking, tolls, rideshare/public transport, and vehicle running costs may need logbook or reasonable record support and private-use apportionment.",
            "Delivery, postage, courier fees, packaging, satchels, boxes, bubble wrap, tape, and tracking fees connected to sales or repairs.",
        ],
    },
    {
        "category": "Software, digital services, and online business costs",
        "items": [
            "Bookkeeping/accounting software, invoicing tools, business email, domain names, web hosting, website builders, cloud storage used for business, design tools, PDF tools, security tools, antivirus, VPN used for business, and backup services.",
            "Marketplace fees, payment processor fees, bank fees, merchant fees, chargeback fees, listing fees, platform subscriptions, and postage-label services.",
            "Business-use share of phone plans, internet plans, mobile data, hotspot use, and communication tools.",
        ],
    },
    {
        "category": "Education, references, and professional costs",
        "items": [
            "Short courses, licences, seminars, technical training, manuals, eBooks, reference books, standards, subscriptions, and trade journals that connect to current income-earning activities.",
            "Professional memberships, union/trade association fees, registration fees, accountant/bookkeeper/tax-agent fees, legal/admin advice connected to business operations.",
            "Advertising, branding, business cards, flyers, signs, labels, logos, photo/product staging, and marketing design costs.",
        ],
    },
    {
        "category": "Often-missed review prompts",
        "items": [
            "Small accessories: adapters, chargers, USB drives, SD cards, cables, cases, screen protectors, batteries, mouse/keyboard, cleaning kits, label tape, postage scales, and storage tubs used for work/business.",
            "Protective clothing/PPE and laundry only where the rules allow it; ordinary everyday clothing is usually not suitable without specific eligibility.",
            "Bank interest or finance costs tied to business assets may need review and apportionment.",
            "Bad debts, refunds, discounts, warranty replacements, redacted/reversed sales, and unpaid invoices should be reviewed before accountant handoff.",
            "Private-use adjustment notes for home, vehicle, phone, internet, tools, and computers help the accountant decide what can be claimed safely.",
        ],
    },
]


class LedgerError(Exception):
    pass

@dataclass
class JournalLine:
    account_code: str
    side: str
    amount_cents: int
    memo: str = ""
    tax_rate_bps: int = 0
    tax_amount_cents: int = 0


def now_iso() -> str:
    return _dt.datetime.now().replace(microsecond=0).isoformat()


def today() -> str:
    return _dt.date.today().isoformat()


DISPLAY_DATE_FORMAT = "DD/MM/YYYY"


def normalize_date(value: str | None) -> str:
    """Normalize user-entered dates to ISO storage format.

    Sentinel Ledger stores dates as ISO YYYY-MM-DD for safe sorting, but user-facing
    display defaults to DD/MM/YYYY for Australian/accountant readability. This
    helper accepts both DD/MM/YYYY and YYYY-MM-DD so existing scripts keep working.
    """
    raw = str(value or "").strip()
    if not raw:
        raise LedgerError("Date is required. Use DD/MM/YYYY or YYYY-MM-DD.")
    for fmt in ("%d/%m/%Y", "%Y-%m-%d"):
        try:
            return _dt.datetime.strptime(raw, fmt).date().isoformat()
        except ValueError:
            pass
    raise LedgerError(f"Invalid date {raw!r}. Use DD/MM/YYYY or YYYY-MM-DD.")


def display_date(value: str | None) -> str:
    """Return DD/MM/YYYY for ISO dates/datetimes; otherwise return the original text."""
    raw = str(value or "").strip()
    if not raw:
        return ""
    token = raw.split("T", 1)[0]
    for fmt in ("%Y-%m-%d", "%d/%m/%Y"):
        try:
            return _dt.datetime.strptime(token, fmt).date().strftime("%d/%m/%Y")
        except ValueError:
            pass
    return raw


def display_datetime(value: str | None) -> str:
    raw = str(value or "").strip()
    if not raw:
        return ""
    try:
        dt = _dt.datetime.fromisoformat(raw)
        return dt.strftime("%d/%m/%Y %H:%M:%S")
    except ValueError:
        return display_date(raw)


def display_period(start: str | None = None, end: str | None = None) -> str:
    s = display_date(start) if start else "all"
    e = display_date(end) if end else "all"
    if s == "all" and e == "all":
        return "All records"
    return f"{s} to {e}"


def data_dir() -> Path:
    base = os.environ.get("XDG_DATA_HOME")
    if base:
        return Path(base) / APP_ID
    return Path.home() / ".local" / "share" / APP_ID


def default_db_path() -> Path:
    env = os.environ.get(DB_ENV)
    if env:
        return Path(env).expanduser()
    return data_dir() / "sentinel_ledger.db"


def vault_dir() -> Path:
    return Path.home() / "AEGIS_Vault" / "07_Financial" / "Sentinel_Ledger"


def aegis_metadata_dir() -> Path:
    return vault_dir() / "AEGIS_Metadata"


def accountant_reports_dir() -> Path:
    return vault_dir() / "Accountant_Reports"




def sentinel_command_dir() -> Path:
    """Local metadata area used by future Sentinel Command / AEGIS hub."""
    return vault_dir() / "Sentinel_Command" / "Programs" / "107_Sentinel_Ledger"

def sentinel_command_status_path() -> Path:
    return sentinel_command_dir() / "sentinel_ledger_sentinel_command_status.json"

def sentinel_command_manifest_path() -> Path:
    return sentinel_command_dir() / "sentinel_ledger_command_contract.json"

def safe_slug(value: str, fallback: str = "sentinel-ledger") -> str:
    raw = str(value or "").strip() or fallback
    allowed = []
    for ch in raw:
        if ch.isalnum() or ch in ("-", "_", "."):
            allowed.append(ch)
        elif ch.isspace():
            allowed.append("_")
    slug = "".join(allowed).strip("._-")
    return slug or fallback


def ledgers_dir() -> Path:
    return data_dir() / "ledgers"


def ledger_registry_path() -> Path:
    return ledgers_dir() / "ledger_registry.json"


def normalize_ledger_name(name: str) -> str:
    return safe_slug(str(name or "default").strip().lower().replace(" ", "_"), "default")


def load_ledger_registry() -> dict:
    path = ledger_registry_path()
    if not path.exists():
        return {"active": "default", "ledgers": {}}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            raise ValueError("registry root is not object")
        data.setdefault("active", "default")
        data.setdefault("ledgers", {})
        return data
    except Exception:
        return {"active": "default", "ledgers": {}}


def save_ledger_registry(registry: dict) -> None:
    path = ledger_registry_path()
    safe_write_text_file(path, json.dumps(registry, indent=2, sort_keys=True), mode=0o600)


def ledger_db_path(name: str) -> Path:
    slug = normalize_ledger_name(name)
    return ledgers_dir() / slug / "sentinel_ledger.db"


def resolve_db_path(db_arg: str | None = None, ledger_name: str | None = None) -> Path | None:
    if db_arg and ledger_name:
        raise LedgerError("Use either --db or --ledger, not both.")
    if db_arg:
        return Path(db_arg).expanduser()
    if ledger_name:
        return ledger_db_path(ledger_name)
    return None


def list_ledger_profiles() -> dict:
    registry = load_ledger_registry()
    out = []
    for slug, rec in sorted(registry.get("ledgers", {}).items()):
        db_path = Path(rec.get("db_path") or ledger_db_path(slug)).expanduser()
        out.append({
            "name": rec.get("name") or slug,
            "slug": slug,
            "business_name": rec.get("business_name", ""),
            "db_path": str(db_path),
            "exists": db_path.exists(),
            "active": slug == registry.get("active"),
            "created_at": rec.get("created_at", ""),
            "updated_at": rec.get("updated_at", ""),
        })
    return {"active": registry.get("active", "default"), "registry_path": str(ledger_registry_path()), "ledgers": out}


def set_active_ledger(name: str) -> dict:
    slug = normalize_ledger_name(name)
    registry = load_ledger_registry()
    if slug not in registry.get("ledgers", {}):
        raise LedgerError(f"Unknown ledger profile: {name}")
    registry["active"] = slug
    registry["ledgers"][slug]["updated_at"] = now_iso()
    save_ledger_registry(registry)
    return list_ledger_profiles()


def create_ledger_profile(name: str, business_name: str = "", owner_name: str = "", registration_number: str = "", tax_number: str = "", currency: str = "AUD", gst_registered: str = "yes", bas_frequency: str = "quarterly", notes: str = "", set_active: bool = True) -> dict:
    slug = normalize_ledger_name(name or business_name or "default")
    db_path = ledger_db_path(slug)
    ledger = LedgerDB(db_path)
    try:
        ledger.init()
        ledger.update_business_profile(
            business_name=business_name or name,
            owner_name=owner_name,
            registration_number=registration_number,
            tax_number=tax_number,
            currency=currency or "AUD",
            gst_registered=gst_registered,
            bas_frequency=bas_frequency or "quarterly",
            notes=notes,
        )
        ledger.log_recovery_event("ledger_profile_created", "ok", f"Created/updated ledger profile {slug}", {"slug": slug, "db_path": str(db_path), "business_name": business_name or name})
        ledger.conn.commit()
    finally:
        ledger.close()
    registry = load_ledger_registry()
    registry.setdefault("ledgers", {})[slug] = {
        "name": name or business_name or slug,
        "slug": slug,
        "business_name": business_name or name,
        "db_path": str(db_path),
        "created_at": registry.get("ledgers", {}).get(slug, {}).get("created_at", now_iso()),
        "updated_at": now_iso(),
    }
    if set_active or not registry.get("active"):
        registry["active"] = slug
    save_ledger_registry(registry)
    return {"ok": True, "name": name or business_name or slug, "slug": slug, "db_path": str(db_path), "active": registry.get("active") == slug, "business_name": business_name or name}


def parse_iso_date_or_blank(value: str | None) -> str:
    if not value:
        return ""
    value = str(value).strip()
    if not value:
        return ""
    return normalize_date(value)


def parse_money(value: str | Decimal | int | float) -> Decimal:
    try:
        amount = Decimal(str(value).strip()).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    except (InvalidOperation, ValueError) as exc:
        raise LedgerError(f"Invalid money value: {value!r}") from exc
    if amount < 0:
        raise LedgerError("Money values must be zero or positive. Use debit/credit direction instead of negative amounts.")
    return amount


def money_to_cents(amount: Decimal | str | int | float) -> int:
    dec = parse_money(amount)
    return int((dec * 100).to_integral_value(rounding=ROUND_HALF_UP))


def cents_to_money(cents: int) -> Decimal:
    return (Decimal(int(cents)) / Decimal(100)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def money_str(cents: int) -> str:
    return f"{cents_to_money(cents):,.2f}"


def parse_rate_bps(rate: str | Decimal | int | float) -> int:
    raw = str(rate).strip()
    if raw.endswith("%"):
        dec = Decimal(raw[:-1].strip()) / Decimal(100)
    else:
        dec = Decimal(raw)
        if dec > 1:
            dec = dec / Decimal(100)
    if dec < 0:
        raise LedgerError("Tax rate cannot be negative.")
    return int((dec * Decimal(10000)).to_integral_value(rounding=ROUND_HALF_UP))


def bps_to_rate_text(bps: int) -> str:
    return f"{Decimal(bps) / Decimal(100):.2f}%"


def split_tax(amount: Decimal, tax_rate_bps: int, tax_mode: str) -> tuple[Decimal, Decimal, Decimal]:
    rate = Decimal(tax_rate_bps) / Decimal(10000)
    if rate == 0:
        return amount, Decimal("0.00"), amount
    if tax_mode == "exclusive":
        subtotal = amount
        tax = (subtotal * rate).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        total = subtotal + tax
    elif tax_mode == "inclusive":
        total = amount
        subtotal = (total / (Decimal(1) + rate)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        tax = total - subtotal
    else:
        raise LedgerError("tax_mode must be inclusive or exclusive")
    return subtotal, tax, total


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def is_running_as_root() -> bool:
    return hasattr(os, "geteuid") and os.geteuid() == 0


def enforce_not_root_for_write(action: str) -> None:
    """Refuse finance-data mutation when launched as root by accident.

    Running desktop finance apps with sudo/root can leave user ledgers owned by
    root and can widen the blast radius of export/restore mistakes. A documented
    override exists only for package validation or deliberate administrator work.
    """
    if is_running_as_root() and os.environ.get(ROOT_WRITE_OVERRIDE_ENV) != "1":
        raise LedgerError(
            f"Refusing to run write action '{action}' as root. Run as the normal user, "
            f"or set {ROOT_WRITE_OVERRIDE_ENV}=1 only for controlled package validation."
        )


def _expanded(path: Path | str) -> Path:
    return Path(path).expanduser()


def ensure_not_symlink(path: Path, label: str = "path") -> None:
    try:
        if path.is_symlink():
            raise LedgerError(f"Refusing unsafe symlink {label}: {path}")
    except OSError as exc:
        raise LedgerError(f"Cannot inspect {label}: {path}: {exc}") from exc


def ensure_no_symlink_ancestors(path: Path, label: str = "path") -> None:
    current = path
    checked = []
    while True:
        checked.append(current)
        parent = current.parent
        if parent == current:
            break
        current = parent
    for candidate in checked:
        if candidate.exists() and candidate.is_symlink():
            raise LedgerError(f"Refusing {label} with symlink ancestor: {candidate}")


def ensure_output_parent(path: Path) -> None:
    parent = path.parent
    ensure_no_symlink_ancestors(parent, "output parent")
    parent.mkdir(parents=True, exist_ok=True)
    ensure_not_symlink(parent, "output directory")
    if not parent.is_dir():
        raise LedgerError(f"Output parent is not a directory: {parent}")


def prepare_private_dir(path: Path | str) -> Path:
    p = _expanded(path)
    ensure_no_symlink_ancestors(p, "output directory")
    if p.exists() and p.is_symlink():
        raise LedgerError(f"Refusing symlinked output directory: {p}")
    p.mkdir(parents=True, exist_ok=True)
    if not p.is_dir():
        raise LedgerError(f"Output path is not a directory: {p}")
    try:
        p.chmod(0o700)
    except OSError:
        pass
    return p


def safe_write_text_file(path: Path | str, text: str, mode: int = 0o600, overwrite: bool = True) -> Path:
    p = _expanded(path)
    ensure_output_parent(p)
    if p.exists() and p.is_symlink():
        raise LedgerError(f"Refusing to overwrite symlink: {p}")
    if p.exists() and not overwrite:
        raise LedgerError(f"Refusing to overwrite existing file: {p}")
    tmp = p.with_name(f".{p.name}.tmp-{os.getpid()}")
    if tmp.exists() or tmp.is_symlink():
        raise LedgerError(f"Temporary output path already exists: {tmp}")
    try:
        with tmp.open("x", encoding="utf-8") as f:
            f.write(text)
        try:
            tmp.chmod(mode)
        except OSError:
            pass
        os.replace(tmp, p)
        try:
            p.chmod(mode)
        except OSError:
            pass
    finally:
        try:
            if tmp.exists() and not p.samefile(tmp):
                tmp.unlink()
        except Exception:
            pass
    return p


def safe_append_text_file(path: Path | str, text: str, mode: int = 0o600) -> Path:
    p = _expanded(path)
    ensure_output_parent(p)
    if p.exists() and p.is_symlink():
        raise LedgerError(f"Refusing to append to symlink: {p}")
    with p.open("a", encoding="utf-8") as f:
        f.write(text)
    try:
        p.chmod(mode)
    except OSError:
        pass
    return p


def safe_write_csv_file(path: Path | str, rows: list[sqlite3.Row] | list[dict], fieldnames: list[str] | None = None) -> Path:
    p = _expanded(path)
    ensure_output_parent(p)
    if p.exists() and p.is_symlink():
        raise LedgerError(f"Refusing to overwrite symlink CSV: {p}")
    tmp = p.with_name(f".{p.name}.tmp-{os.getpid()}")
    if tmp.exists() or tmp.is_symlink():
        raise LedgerError(f"Temporary CSV path already exists: {tmp}")
    try:
        with tmp.open("x", newline="", encoding="utf-8") as f:
            if fieldnames is None and rows:
                fieldnames = list(rows[0].keys())
            if fieldnames:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                for row in rows:
                    writer.writerow({k: (dict(row).get(k, "") if not isinstance(row, dict) else row.get(k, "")) for k in fieldnames})
            else:
                f.write("")
        try:
            tmp.chmod(0o600)
        except OSError:
            pass
        os.replace(tmp, p)
        try:
            p.chmod(0o600)
        except OSError:
            pass
    finally:
        try:
            if tmp.exists() and not p.samefile(tmp):
                tmp.unlink()
        except Exception:
            pass
    return p


def require_file_size(path: Path, max_bytes: int, label: str) -> None:
    try:
        size = path.stat().st_size
    except OSError as exc:
        raise LedgerError(f"Cannot stat {label}: {path}: {exc}") from exc
    if size > max_bytes:
        raise LedgerError(f"Refusing oversized {label}: {path} is {size} bytes; limit is {max_bytes} bytes")


def read_private_secret_arg(value: str | None, prompt: str, purpose: str) -> str:
    """Read sensitive values without putting them directly in argv.

    Accepted forms:
      - None/empty: interactive getpass prompt
      - @-: read secret from stdin
      - @/path/to/private-file: read from a non-symlink private file

    Any other inline value is refused to avoid shell-history and process-list leaks.
    """
    if value is None or value == "":
        return getpass.getpass(prompt)
    if value == "@-":
        secret = sys.stdin.read()
        return secret.rstrip("\r\n")
    if value.startswith("@"):
        path = _expanded(value[1:])
        ensure_not_symlink(path, "secret file")
        if not path.exists() or not path.is_file():
            raise LedgerError(f"Secret file not found: {path}")
        require_file_size(path, PRIVATE_FILE_MAX_BYTES, "secret file")
        try:
            mode = stat.S_IMODE(path.stat().st_mode)
            if mode & 0o077:
                raise LedgerError(f"Secret file must not be group/world accessible: {path}")
        except OSError as exc:
            raise LedgerError(f"Cannot inspect secret file permissions: {path}: {exc}") from exc
        return path.read_text(encoding="utf-8").rstrip("\r\n")
    raise LedgerError(
        f"Refusing direct {purpose} in command-line arguments. "
        "Use --password @- for stdin, --password @/private/file, or omit --password for an interactive prompt."
    )


def validate_restore_table_columns(target: "LedgerDB", payload: dict) -> list[str]:
    issues: list[str] = []
    tables = payload.get("tables") if isinstance(payload, dict) else None
    if not isinstance(tables, dict):
        return ["missing_tables_payload"]
    for table, rows in tables.items():
        if table not in BACKUP_TABLES:
            issues.append(f"unknown_table:{table}")
            continue
        if not isinstance(rows, list):
            issues.append(f"table_not_list:{table}")
            continue
        if len(rows) > MAX_RESTORE_ROWS_PER_TABLE:
            issues.append(f"too_many_rows:{table}")
            continue
        allowed = {r["name"] for r in target.conn.execute(f"PRAGMA table_info({table})")}
        for idx, row in enumerate(rows[:1000]):
            if not isinstance(row, dict):
                issues.append(f"row_not_object:{table}:{idx}")
                continue
            extra = sorted(set(row) - allowed)
            if extra:
                issues.append(f"unknown_columns:{table}:{','.join(extra[:5])}")
                break
    return issues


def write_sqlite_snapshot(conn: sqlite3.Connection, out_path: Path | str) -> Path:
    p = _expanded(out_path)
    ensure_output_parent(p)
    if p.exists() and p.is_symlink():
        raise LedgerError(f"Refusing to overwrite symlink SQLite snapshot: {p}")
    tmp = p.with_name(f".{p.name}.tmp-{os.getpid()}")
    if tmp.exists() or tmp.is_symlink():
        raise LedgerError(f"Temporary SQLite snapshot already exists: {tmp}")
    target = sqlite3.connect(str(tmp))
    try:
        conn.backup(target)
    finally:
        target.close()
    try:
        tmp.chmod(0o600)
    except OSError:
        pass
    os.replace(tmp, p)
    try:
        p.chmod(0o600)
    except OSError:
        pass
    return p


def validate_date(value: str) -> str:
    return normalize_date(value)


def print_table(headers: list[str], rows: Iterable[Iterable[object]]) -> None:
    rows = [[str(cell) for cell in row] for row in rows]
    widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            widths[i] = max(widths[i], len(cell))
    fmt = "  ".join("{:<" + str(w) + "}" for w in widths)
    print(fmt.format(*headers))
    print(fmt.format(*["-" * w for w in widths]))
    for row in rows:
        print(fmt.format(*row))


def resource_candidates(*parts: str) -> list[Path]:
    rel = Path(*parts)
    here = Path(__file__).resolve()
    return [
        Path("/usr/share/sentinel-ledger") / rel,
        Path("/usr/local/share/sentinel-ledger") / rel,
        here.parents[1] / rel if len(here.parents) > 1 else here.parent / rel,
        here.parents[1] / "assets" / rel.name if len(here.parents) > 1 else here.parent / "assets" / rel.name,
        here.parent / rel,
    ]


def first_existing_resource(*parts: str) -> Path | None:
    for candidate in resource_candidates(*parts):
        try:
            if candidate.exists():
                return candidate
        except OSError:
            continue
    return None


def user_desktop_dir() -> Path:
    config = Path.home() / ".config" / "user-dirs.dirs"
    if config.exists():
        try:
            for line in config.read_text(encoding="utf-8", errors="ignore").splitlines():
                line = line.strip()
                if line.startswith("XDG_DESKTOP_DIR="):
                    value = line.split("=", 1)[1].strip().strip('"')
                    value = value.replace("$HOME", str(Path.home()))
                    return Path(value).expanduser()
        except OSError:
            pass
    return Path.home() / "Desktop"


def install_desktop_launcher() -> Path:
    src = first_existing_resource("desktop", "sentinel-ledger.desktop")
    if src is None:
        app_src = Path("/usr/share/applications/sentinel-ledger.desktop")
        if app_src.exists():
            src = app_src
    if src is None:
        src = first_existing_resource("sentinel-ledger.desktop")
    if src is None:
        raise LedgerError("Could not find sentinel-ledger.desktop resource to install.")
    desktop = user_desktop_dir()
    desktop.mkdir(parents=True, exist_ok=True)
    out = desktop / "Sentinel Ledger.desktop"
    text = src.read_text(encoding="utf-8")
    lines = []
    exec_seen = False
    for line in text.splitlines():
        if line.startswith("Exec="):
            lines.append("Exec=sentinel-ledger-gui")
            exec_seen = True
        else:
            lines.append(line)
    if not exec_seen:
        lines.append("Exec=sentinel-ledger-gui")
    text = "\n".join(lines).rstrip() + "\n"
    if "StartupWMClass=" not in text:
        text = text.rstrip() + "\nStartupWMClass=sentinel-ledger\n"
    safe_write_text_file(out, text, mode=0o755)
    return out


class LedgerDB:
    def __init__(self, db_path: Path | None = None):
        self.db_path = Path(db_path or default_db_path()).expanduser()
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._db_preexisted = self.db_path.exists()
        self._pre_migration_backup: Path | None = None
        self.conn = sqlite3.connect(str(self.db_path))
        self.conn.row_factory = sqlite3.Row
        self.configure_sqlite_safety()

    def configure_sqlite_safety(self) -> None:
        self.conn.execute("PRAGMA foreign_keys = ON")
        self.conn.execute("PRAGMA busy_timeout = 5000")
        try:
            self.conn.execute("PRAGMA journal_mode = WAL")
        except sqlite3.DatabaseError:
            pass
        self.conn.execute("PRAGMA synchronous = FULL")

    def close(self) -> None:
        self.conn.close()

    def init(self) -> None:
        self.pre_migration_snapshot_if_needed()
        self.conn.executescript("""
            CREATE TABLE IF NOT EXISTS meta (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS business_profile (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                business_name TEXT DEFAULT '',
                owner_name TEXT DEFAULT '',
                registration_number TEXT DEFAULT '',
                tax_number TEXT DEFAULT '',
                currency TEXT DEFAULT 'AUD',
                notes TEXT DEFAULT '',
                updated_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS accounts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                code TEXT NOT NULL UNIQUE,
                name TEXT NOT NULL,
                type TEXT NOT NULL CHECK(type IN ('asset','liability','equity','income','expense')),
                is_active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS contacts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                type TEXT NOT NULL CHECK(type IN ('customer','supplier','both','other')),
                name TEXT NOT NULL,
                email TEXT DEFAULT '',
                phone TEXT DEFAULT '',
                tax_id TEXT DEFAULT '',
                notes TEXT DEFAULT '',
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS journal_entries (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                entry_date TEXT NOT NULL,
                description TEXT NOT NULL,
                source_type TEXT DEFAULT 'manual',
                source_ref TEXT DEFAULT '',
                contact_id INTEGER,
                memo TEXT DEFAULT '',
                created_at TEXT NOT NULL,
                FOREIGN KEY(contact_id) REFERENCES contacts(id) ON DELETE SET NULL
            );
            CREATE TABLE IF NOT EXISTS journal_lines (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                entry_id INTEGER NOT NULL,
                account_id INTEGER NOT NULL,
                side TEXT NOT NULL CHECK(side IN ('debit','credit')),
                amount_cents INTEGER NOT NULL CHECK(amount_cents >= 0),
                tax_rate_bps INTEGER NOT NULL DEFAULT 0,
                tax_amount_cents INTEGER NOT NULL DEFAULT 0,
                memo TEXT DEFAULT '',
                FOREIGN KEY(entry_id) REFERENCES journal_entries(id) ON DELETE CASCADE,
                FOREIGN KEY(account_id) REFERENCES accounts(id) ON DELETE RESTRICT
            );
            CREATE TABLE IF NOT EXISTS document_refs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                entry_id INTEGER,
                path TEXT NOT NULL,
                sha256 TEXT DEFAULT '',
                note TEXT DEFAULT '',
                created_at TEXT NOT NULL,
                FOREIGN KEY(entry_id) REFERENCES journal_entries(id) ON DELETE SET NULL
            );
            CREATE TABLE IF NOT EXISTS period_locks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                locked_through TEXT NOT NULL,
                reason TEXT DEFAULT '',
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS invoices (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                invoice_no TEXT NOT NULL UNIQUE,
                customer_name TEXT DEFAULT '',
                issue_date TEXT NOT NULL,
                due_date TEXT DEFAULT '',
                description TEXT NOT NULL,
                subtotal_cents INTEGER NOT NULL DEFAULT 0,
                tax_cents INTEGER NOT NULL DEFAULT 0,
                total_cents INTEGER NOT NULL DEFAULT 0,
                tax_rate_bps INTEGER NOT NULL DEFAULT 0,
                tax_mode TEXT DEFAULT 'inclusive',
                status TEXT NOT NULL DEFAULT 'unpaid',
                journal_entry_id INTEGER,
                paid_entry_id INTEGER,
                created_at TEXT NOT NULL,
                FOREIGN KEY(journal_entry_id) REFERENCES journal_entries(id) ON DELETE SET NULL,
                FOREIGN KEY(paid_entry_id) REFERENCES journal_entries(id) ON DELETE SET NULL
            );
            CREATE TABLE IF NOT EXISTS bills (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                bill_no TEXT NOT NULL UNIQUE,
                supplier_name TEXT DEFAULT '',
                bill_date TEXT NOT NULL,
                due_date TEXT DEFAULT '',
                description TEXT NOT NULL,
                subtotal_cents INTEGER NOT NULL DEFAULT 0,
                tax_cents INTEGER NOT NULL DEFAULT 0,
                total_cents INTEGER NOT NULL DEFAULT 0,
                tax_rate_bps INTEGER NOT NULL DEFAULT 0,
                tax_mode TEXT DEFAULT 'inclusive',
                status TEXT NOT NULL DEFAULT 'unpaid',
                journal_entry_id INTEGER,
                paid_entry_id INTEGER,
                created_at TEXT NOT NULL,
                FOREIGN KEY(journal_entry_id) REFERENCES journal_entries(id) ON DELETE SET NULL,
                FOREIGN KEY(paid_entry_id) REFERENCES journal_entries(id) ON DELETE SET NULL
            );
            CREATE TABLE IF NOT EXISTS tax_codes (
                code TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                rate_bps INTEGER NOT NULL DEFAULT 0,
                treatment TEXT NOT NULL DEFAULT 'no_gst',
                is_active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS schema_migrations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                schema_version TEXT NOT NULL,
                app_version TEXT NOT NULL,
                migration_name TEXT NOT NULL,
                notes TEXT DEFAULT '',
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS backup_registry (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                backup_type TEXT NOT NULL,
                path TEXT NOT NULL,
                sha256 TEXT DEFAULT '',
                size_bytes INTEGER NOT NULL DEFAULT 0,
                source_schema_version TEXT DEFAULT '',
                app_version TEXT DEFAULT '',
                verified INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS recovery_audit (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_type TEXT NOT NULL,
                status TEXT NOT NULL,
                message TEXT DEFAULT '',
                payload_json TEXT DEFAULT '',
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS security_audit (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_type TEXT NOT NULL,
                status TEXT NOT NULL,
                message TEXT DEFAULT '',
                payload_json TEXT DEFAULT '',
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS payment_methods (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                method_type TEXT DEFAULT 'other',
                clearing_account TEXT DEFAULT '1010',
                notes TEXT DEFAULT '',
                is_active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS recurring_templates (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                entry_type TEXT NOT NULL CHECK(entry_type IN ('sale','expense')),
                amount_cents INTEGER NOT NULL CHECK(amount_cents >= 0),
                description TEXT NOT NULL,
                contact_name TEXT DEFAULT '',
                account_code TEXT DEFAULT '',
                bank_account TEXT DEFAULT '1010',
                tax_code TEXT DEFAULT 'GST',
                tax_rate_bps INTEGER NOT NULL DEFAULT 1000,
                tax_mode TEXT DEFAULT 'inclusive',
                frequency TEXT DEFAULT 'monthly',
                next_date TEXT DEFAULT '',
                is_active INTEGER NOT NULL DEFAULT 1,
                notes TEXT DEFAULT '',
                last_posted_at TEXT DEFAULT '',
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS import_queue (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                import_type TEXT NOT NULL DEFAULT 'bank_csv',
                row_json TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending',
                source_path TEXT DEFAULT '',
                posted_entry_id INTEGER,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                FOREIGN KEY(posted_entry_id) REFERENCES journal_entries(id) ON DELETE SET NULL
            );
            CREATE INDEX IF NOT EXISTS idx_security_audit_created ON security_audit(created_at);
            CREATE INDEX IF NOT EXISTS idx_journal_entries_date ON journal_entries(entry_date);
            CREATE INDEX IF NOT EXISTS idx_journal_lines_account ON journal_lines(account_id);
            CREATE INDEX IF NOT EXISTS idx_contacts_name ON contacts(name);
            CREATE INDEX IF NOT EXISTS idx_invoices_no ON invoices(invoice_no);
            CREATE INDEX IF NOT EXISTS idx_bills_no ON bills(bill_no);
            CREATE INDEX IF NOT EXISTS idx_payment_methods_name ON payment_methods(name);
            CREATE INDEX IF NOT EXISTS idx_recurring_templates_active ON recurring_templates(is_active,next_date);
            CREATE INDEX IF NOT EXISTS idx_import_queue_status ON import_queue(status,created_at);
        """)
        self.migrate_schema()
        if self._pre_migration_backup is not None:
            self.register_backup(self._pre_migration_backup, "pre_migration_sqlite_copy", verified=True)
        self.log_recovery_event("init", "ok", f"Initialized or migrated schema {SCHEMA_VERSION}")
        self.set_meta("app_id", APP_ID)
        self.set_meta("program_id", PROGRAM_ID)
        self.set_meta("version", VERSION)
        self.set_meta("schema_version", SCHEMA_VERSION)
        self.set_meta("local_only", "true")
        self.set_meta("security_profile", "v0.7.0-local-private")
        if self.get_meta("ledger_lock_enabled", "") == "":
            self.set_meta("ledger_lock_enabled", "false")
        if self.get_meta("redaction_mode", "") == "":
            self.set_meta("redaction_mode", "false")
        if self.get_meta("idle_lock_minutes", "") == "":
            self.set_meta("idle_lock_minutes", "15")
        self.conn.execute("INSERT OR IGNORE INTO business_profile(id, updated_at) VALUES(1, ?)", (now_iso(),))
        self.seed_chart()
        self.seed_tax_codes()
        self.seed_payment_methods()
        self.set_meta("business_workflow_profile", "v0.8.5-import-export-accountant-handoff-polish")
        self.conn.commit()
        self.enforce_private_permissions()

    def table_exists(self, table: str) -> bool:
        row = self.conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone()
        return bool(row)

    def current_schema_version_raw(self) -> str:
        try:
            if not self.table_exists("meta"):
                return "0"
            row = self.conn.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()
            return str(row["value"]) if row else "0"
        except sqlite3.DatabaseError:
            return "0"

    def pre_migration_snapshot_if_needed(self) -> None:
        if not self._db_preexisted or not self.db_path.exists():
            return
        old_schema = self.current_schema_version_raw()
        if old_schema == "0" or old_schema == SCHEMA_VERSION:
            return
        try:
            if int(str(old_schema).split(".")[0]) >= int(SCHEMA_VERSION):
                return
        except ValueError:
            pass
        backup_dir = vault_dir() / "Backups" / "Pre_Migration"
        backup_dir.mkdir(parents=True, exist_ok=True)
        stamp = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
        out = backup_dir / f"sentinel_ledger_pre_migration_schema_{old_schema}_to_{SCHEMA_VERSION}_{stamp}.sqlite"
        self.conn.execute("PRAGMA wal_checkpoint(FULL)")
        write_sqlite_snapshot(self.conn, out)
        self._pre_migration_backup = out

    def migrate_schema(self) -> None:
        additions = {
            "business_profile": [
                ("default_tax_mode", "TEXT DEFAULT 'inclusive'"),
                ("gst_registered", "INTEGER NOT NULL DEFAULT 1"),
                ("bas_frequency", "TEXT DEFAULT 'quarterly'"),
                ("default_tax_code", "TEXT DEFAULT 'GST'"),
                ("financial_year_start", "TEXT DEFAULT '07-01'"),
            ],
            "journal_entries": [
                ("is_reversal", "INTEGER NOT NULL DEFAULT 0"),
                ("reverses_entry_id", "INTEGER"),
                ("payment_method", "TEXT DEFAULT ''"),
                ("external_ref", "TEXT DEFAULT ''"),
            ],
            "accounts": [
                ("notes", "TEXT DEFAULT ''"),
            ],
            "invoices": [
                ("payment_method", "TEXT DEFAULT ''"),
            ],
            "bills": [
                ("payment_method", "TEXT DEFAULT ''"),
            ],
        }
        for table, cols in additions.items():
            existing = {row["name"] for row in self.conn.execute(f"PRAGMA table_info({table})")}
            for name, ddl in cols:
                if name not in existing:
                    self.conn.execute(f"ALTER TABLE {table} ADD COLUMN {name} {ddl}")

        self.record_schema_migration("schema-v0.6.0-reliability-recovery", "Added migration, backup registry, recovery audit, restore-check, and AEGIS-safe recovery status tables.")
        self.record_schema_migration("schema-v0.6.5-setup-multiledger-tax-readability", "Added setup wizard readiness, multi-ledger registry support, readable tax safety reports, and suggested deductions handoff appendix.")
        self.record_schema_migration("schema-v0.6.7-ledger-selector-receipt-template-inventory-bridge", "Added profile selector menu, blank setup wizard, receipt template designer, live sale receipt preview, and future inventory bridge contract.")
        self.record_schema_migration("schema-v0.7.0-security-hardening", "Added Phase 2 security hardening: optional ledger lock metadata, security audit table, private permissions, password-protected backups, redaction status, no-network check, and AEGIS read-only boundary flags.")
        self.record_schema_migration("schema-v0.7.5-data-integrity-recovery-hardening", "Added Phase 3 deep integrity checks, human-readable recovery reports, restore wizard status, backup schedule status, pre-upgrade backup status, and read-only repair diagnostics.")
        self.record_schema_migration("schema-v0.8.0-business-workflow-completion", "Added Phase 4 daily business workflow features: payment methods, customer/supplier detail and search, recurring templates, document linking, and business workflow status.")

    def record_schema_migration(self, migration_name: str, notes: str = "") -> None:
        try:
            exists = self.conn.execute("SELECT id FROM schema_migrations WHERE schema_version=? AND migration_name=?", (SCHEMA_VERSION, migration_name)).fetchone()
            if not exists:
                self.conn.execute(
                    "INSERT INTO schema_migrations(schema_version,app_version,migration_name,notes,created_at) VALUES(?,?,?,?,?)",
                    (SCHEMA_VERSION, VERSION, migration_name, notes, now_iso()),
                )
        except sqlite3.DatabaseError:
            pass

    def log_recovery_event(self, event_type: str, status: str, message: str = "", payload: dict | None = None) -> None:
        try:
            self.conn.execute(
                "INSERT INTO recovery_audit(event_type,status,message,payload_json,created_at) VALUES(?,?,?,?,?)",
                (event_type, status, message, json.dumps(payload or {}, sort_keys=True), now_iso()),
            )
        except sqlite3.DatabaseError:
            pass

    def security_dir(self) -> Path:
        p = vault_dir() / "Security"
        p.mkdir(parents=True, exist_ok=True)
        return p

    def _chmod_private(self, path: Path) -> None:
        try:
            path = Path(path).expanduser()
            if not path.exists():
                return
            if path.is_dir():
                path.chmod(0o700)
            else:
                path.chmod(0o600)
        except OSError:
            pass

    def enforce_private_permissions(self) -> dict:
        """Best-effort local privacy hardening for ledger-owned files."""
        protected = []
        dirs = [self.db_path.parent, vault_dir(), self.security_dir()]
        for d in dirs:
            d.mkdir(parents=True, exist_ok=True)
            self._chmod_private(d); protected.append(str(d))
        for candidate in [self.db_path, Path(str(self.db_path) + "-wal"), Path(str(self.db_path) + "-shm")]:
            if candidate.exists():
                self._chmod_private(candidate); protected.append(str(candidate))
        return {"ok": True, "protected_paths": protected, "checked_at": now_iso()}

    def log_security_event(self, event_type: str, status: str, message: str, payload: dict | None = None) -> None:
        try:
            self.conn.execute(
                "INSERT INTO security_audit(event_type,status,message,payload_json,created_at) VALUES(?,?,?,?,?)",
                (event_type, status, message, json.dumps(payload or {}, sort_keys=True), now_iso()),
            )
        except sqlite3.DatabaseError:
            pass

    def security_audit_recent(self, limit: int = 25) -> dict:
        rows = []
        if self.table_exists("security_audit"):
            rows = [dict(r) for r in self.conn.execute("SELECT * FROM security_audit ORDER BY created_at DESC, id DESC LIMIT ?", (int(limit),))]
        return {"ok": True, "app": APP_NAME, "version": VERSION, "audit_count_returned": len(rows), "events": rows, "checked_at": now_iso()}

    def _password_hash(self, password: str, salt: bytes | None = None, iterations: int = 240000) -> str:
        if salt is None:
            salt = os.urandom(16)
        digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)
        return "pbkdf2_sha256${}${}${}".format(iterations, base64.b64encode(salt).decode(), base64.b64encode(digest).decode())

    def _verify_password_hash(self, password: str, stored: str) -> bool:
        try:
            scheme, iter_s, salt_s, digest_s = stored.split("$", 3)
            if scheme != "pbkdf2_sha256":
                return False
            iterations = int(iter_s)
            salt = base64.b64decode(salt_s.encode())
            expected = base64.b64decode(digest_s.encode())
            actual = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)
            return hmac.compare_digest(actual, expected)
        except Exception:
            return False

    def set_ledger_lock(self, password: str | None = None, enabled: bool = True) -> dict:
        if enabled:
            if not password:
                raise LedgerError("A password is required to enable the optional ledger lock.")
            self.set_meta("ledger_lock_hash", self._password_hash(password))
            self.set_meta("ledger_lock_enabled", "true")
            msg = "Optional local ledger lock enabled."
        else:
            self.set_meta("ledger_lock_hash", "")
            self.set_meta("ledger_lock_enabled", "false")
            msg = "Optional local ledger lock disabled."
        self.log_security_event("ledger_lock", "ok", msg, {"enabled": bool(enabled)})
        self.conn.commit()
        return self.security_status()

    def check_ledger_password(self, password: str) -> dict:
        enabled = self.get_meta("ledger_lock_enabled", "false") == "true"
        if not enabled:
            return {"ok": True, "lock_enabled": False, "message": "Ledger lock is not enabled."}
        ok = self._verify_password_hash(password, self.get_meta("ledger_lock_hash", ""))
        self.log_security_event("unlock_check", "ok" if ok else "failed", "Ledger password check performed.", {"ok": ok})
        self.conn.commit()
        return {"ok": ok, "lock_enabled": True, "message": "Password accepted." if ok else "Password rejected."}

    def set_redaction_mode(self, enabled: bool) -> dict:
        self.set_meta("redaction_mode", "true" if enabled else "false")
        self.log_security_event("redaction_mode", "ok", "Redaction mode updated.", {"enabled": enabled})
        self.conn.commit()
        return self.security_status()

    def security_status(self) -> dict:
        perms = self.enforce_private_permissions()
        no_net = self.no_network_check()
        lock_enabled = self.get_meta("ledger_lock_enabled", "false") == "true"
        redaction = self.get_meta("redaction_mode", "false") == "true"
        idle_minutes = self.get_meta("idle_lock_minutes", "15") or "15"
        risks = []
        if not lock_enabled:
            risks.append("ledger_lock_optional_not_enabled")
        if not no_net.get("ok"):
            risks.append("network_related_imports_or_calls_detected")
        return {
            "ok": no_net.get("ok") and not [r for r in risks if r != "ledger_lock_optional_not_enabled"],
            "app": APP_NAME,
            "program_id": PROGRAM_ID,
            "version": VERSION,
            "security_profile": "v0.7.0-local-private-security-hardening",
            "ledger_lock_enabled": lock_enabled,
            "redaction_mode_enabled": redaction,
            "idle_lock_minutes": idle_minutes,
            "strict_file_permissions": perms,
            "encrypted_backup_available": True,
            "security_audit_log_enabled": self.table_exists("security_audit"),
            "no_network_check": no_net,
            "aegis_permission_boundary": {"read_status": True, "read_summaries": True, "write_financial_records_without_user_approval": False, "delete_financial_records_without_user_approval": False},
            "risks": risks,
            "checked_at": now_iso(),
        }

    def no_network_check(self) -> dict:
        forbidden = ["socket", "requests", "urllib", "http.client", "ftplib", "smtplib", "imaplib"]
        findings = []
        try:
            text = Path(__file__).read_text(encoding="utf-8", errors="ignore")
            for name in forbidden:
                if f"import {name}" in text or f"from {name}" in text:
                    findings.append(name)
        except Exception as exc:
            findings.append(f"source_scan_error:{exc}")
        return {"ok": not findings, "local_only": LOCAL_ONLY, "network_modules_detected": findings, "note": "Static source self-check; printing/opening local files may use local OS commands but no network API is required.", "checked_at": now_iso()}

    def _secure_backup_payload(self) -> dict:
        tables=BACKUP_TABLES
        payload={"app": APP_NAME,"app_id": APP_ID,"program_id": PROGRAM_ID,"version": VERSION,"created_at": now_iso(),"encrypted_container_note":"Source JSON backup encrypted by password-protected container.","tables": {}}
        for table in tables:
            payload["tables"][table]=[dict(r) for r in self.conn.execute(f"SELECT * FROM {table}")]
        return payload

    def _xor_keystream(self, key: bytes, nonce: bytes, length: int) -> bytes:
        out = bytearray(); counter = 0
        while len(out) < length:
            out.extend(hashlib.sha256(key + nonce + counter.to_bytes(8, "big")).digest())
            counter += 1
        return bytes(out[:length])

    def encrypted_backup(self, password: str, out_path: Path | None = None) -> Path:
        if not password:
            raise LedgerError("A password is required for a protected backup.")
        if out_path is None:
            out_path = vault_dir() / f"sentinel_ledger_secure_backup_{_dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.slbackup"
        out_path=out_path.expanduser(); ensure_output_parent(out_path); ensure_not_symlink(out_path, "encrypted backup output")
        payload = json.dumps(self._secure_backup_payload(), indent=2).encode("utf-8")
        salt = os.urandom(16); nonce = os.urandom(16); iterations = 240000
        keymat = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations, dklen=64)
        enc_key, mac_key = keymat[:32], keymat[32:]
        stream = self._xor_keystream(enc_key, nonce, len(payload))
        cipher = bytes(a ^ b for a,b in zip(payload, stream))
        header = {
            "format": "sentinel-ledger-secure-backup-v1",
            "app": APP_NAME,
            "program_id": PROGRAM_ID,
            "version": VERSION,
            "kdf": "PBKDF2-HMAC-SHA256",
            "iterations": iterations,
            "salt": base64.b64encode(salt).decode(),
            "nonce": base64.b64encode(nonce).decode(),
            "created_at": now_iso(),
            "cipher": "sha256-keystream-xor",
            "warning": "Keep the password safe. This dependency-free container protects casual/local disclosure but should still be stored securely.",
        }
        mac_input = json.dumps(header, sort_keys=True).encode() + cipher
        mac = hmac.new(mac_key, mac_input, hashlib.sha256).hexdigest()
        container = dict(header)
        container["hmac_sha256"] = mac
        container["ciphertext"] = base64.b64encode(cipher).decode()
        safe_write_text_file(out_path, json.dumps(container, indent=2), mode=0o600)
        self.register_backup(out_path, "password_protected_backup_container", verified=True)
        self.record_aegis_metadata("password_protected_backup_container", out_path, {"backup_type":"password_protected", "contains_private_contents":"encrypted"})
        self.log_security_event("encrypted_backup", "ok", f"Created protected backup container at {out_path}")
        self.conn.commit()
        return out_path

    def encrypted_backup_check(self, backup_path: Path, password: str) -> dict:
        try:
            check_path = Path(backup_path).expanduser(); ensure_not_symlink(check_path, "encrypted backup input"); require_file_size(check_path, MAX_BACKUP_JSON_BYTES, "encrypted backup")
            raw = json.loads(check_path.read_text(encoding="utf-8"))
            salt = base64.b64decode(raw["salt"]); nonce = base64.b64decode(raw["nonce"]); cipher = base64.b64decode(raw["ciphertext"])
            iterations = int(raw["iterations"])
            mac_given = raw.get("hmac_sha256", "")
            keymat = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations, dklen=64)
            enc_key, mac_key = keymat[:32], keymat[32:]
            header = {k: raw[k] for k in raw if k not in {"hmac_sha256", "ciphertext"}}
            mac_input = json.dumps(header, sort_keys=True).encode() + cipher
            if not hmac.compare_digest(mac_given, hmac.new(mac_key, mac_input, hashlib.sha256).hexdigest()):
                return {"ok": False, "error": "HMAC/password check failed"}
            stream = self._xor_keystream(enc_key, nonce, len(cipher))
            plain = bytes(a ^ b for a,b in zip(cipher, stream))
            payload = json.loads(plain.decode("utf-8"))
            return {"ok": True, "app": payload.get("app"), "version": payload.get("version"), "tables": sorted((payload.get("tables") or {}).keys()), "checked_at": now_iso()}
        except Exception as exc:
            return {"ok": False, "error": str(exc), "checked_at": now_iso()}

    def register_backup(self, path: Path, backup_type: str, verified: bool = False) -> None:
        try:
            p = Path(path).expanduser()
            digest = sha256_file(p) if p.exists() else ""
            size = p.stat().st_size if p.exists() else 0
            self.conn.execute(
                "INSERT INTO backup_registry(backup_type,path,sha256,size_bytes,source_schema_version,app_version,verified,created_at) VALUES(?,?,?,?,?,?,?,?)",
                (backup_type, str(p), digest, int(size), self.current_schema_version_raw(), VERSION, 1 if verified else 0, now_iso()),
            )
        except sqlite3.DatabaseError:
            pass

    def set_meta(self, key: str, value: str) -> None:
        self.conn.execute("INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, value))

    def get_meta(self, key: str, fallback: str = "") -> str:
        row = self.conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
        return str(row["value"]) if row else fallback

    def meta(self) -> dict[str, str]:
        return {row["key"]: row["value"] for row in self.conn.execute("SELECT key,value FROM meta")}

    def seed_chart(self) -> None:
        for code, name, typ in DEFAULT_CHART:
            self.add_account(code, name, typ, commit=False, ignore_existing=True)

    def seed_tax_codes(self) -> None:
        for code, name, rate_bps, treatment, active in DEFAULT_TAX_CODES:
            self.conn.execute(
                "INSERT OR IGNORE INTO tax_codes(code,name,rate_bps,treatment,is_active,created_at) VALUES(?,?,?,?,?,?)",
                (code, name, rate_bps, treatment, active, now_iso()),
            )

    def seed_payment_methods(self) -> None:
        defaults = [
            ("Cash", "cash", "1000", "Cash takings or cash payments"),
            ("Bank Transfer", "bank", "1010", "Direct bank transfer"),
            ("Card", "card", "1020", "Card or EFTPOS clearing"),
            ("PayPal", "online", "1020", "Online payment clearing"),
            ("Owner Paid", "owner", "3000", "Owner-paid business cost to review"),
            ("Other", "other", "1010", "Other payment method"),
        ]
        for name, typ, acct, notes in defaults:
            self.conn.execute(
                "INSERT OR IGNORE INTO payment_methods(name,method_type,clearing_account,notes,is_active,created_at) VALUES(?,?,?,?,1,?)",
                (name, typ, acct, notes, now_iso()),
            )

    def add_payment_method(self, name: str, method_type: str = "other", clearing_account: str = "1010", notes: str = "", active: bool = True) -> int:
        if not str(name or "").strip():
            raise LedgerError("Payment method name is required.")
        self.account_row(clearing_account)
        cur = self.conn.execute(
            "INSERT INTO payment_methods(name,method_type,clearing_account,notes,is_active,created_at) VALUES(?,?,?,?,?,?) "
            "ON CONFLICT(name) DO UPDATE SET method_type=excluded.method_type, clearing_account=excluded.clearing_account, notes=excluded.notes, is_active=excluded.is_active",
            (name.strip(), method_type.strip() or "other", clearing_account.strip(), notes.strip(), 1 if active else 0, now_iso()),
        )
        self.conn.commit()
        return int(cur.lastrowid or 0)

    def list_payment_methods(self, active_only: bool = True) -> list[sqlite3.Row]:
        sql = "SELECT id,name,method_type,clearing_account,notes,is_active FROM payment_methods"
        if active_only:
            sql += " WHERE is_active=1"
        sql += " ORDER BY name COLLATE NOCASE"
        return list(self.conn.execute(sql))

    def add_account(self, code: str, name: str, typ: str, commit: bool = True, ignore_existing: bool = False) -> None:
        code = code.strip()
        name = name.strip()
        typ = typ.strip().lower()
        if not code or not name:
            raise LedgerError("Account code and name are required.")
        if typ not in ACCOUNT_TYPES:
            raise LedgerError(f"Account type must be one of: {', '.join(ACCOUNT_TYPES)}")
        try:
            self.conn.execute("INSERT INTO accounts(code,name,type,created_at) VALUES(?,?,?,?)", (code, name, typ, now_iso()))
        except sqlite3.IntegrityError:
            if not ignore_existing:
                raise LedgerError(f"Account code already exists: {code}")
        if commit:
            self.conn.commit()

    def update_account(self, code: str, name: str | None = None, typ: str | None = None, active: Optional[bool] = None, notes: str | None = None) -> None:
        if not self.conn.execute("SELECT id FROM accounts WHERE code=?", (code,)).fetchone():
            raise LedgerError(f"Unknown account code: {code}")
        updates = []
        params: list[object] = []
        if name is not None:
            if not name.strip():
                raise LedgerError("Account name cannot be blank.")
            updates.append("name=?"); params.append(name.strip())
        if typ is not None:
            typ = typ.strip().lower()
            if typ not in ACCOUNT_TYPES:
                raise LedgerError(f"Account type must be one of: {', '.join(ACCOUNT_TYPES)}")
            updates.append("type=?"); params.append(typ)
        if active is not None:
            updates.append("is_active=?"); params.append(1 if active else 0)
        if notes is not None:
            updates.append("notes=?"); params.append(notes.strip())
        if not updates:
            raise LedgerError("No account updates requested.")
        params.append(code)
        self.conn.execute(f"UPDATE accounts SET {', '.join(updates)} WHERE code=?", params)
        self.conn.commit()

    def list_accounts(self, active_only: bool = True) -> list[sqlite3.Row]:
        sql = "SELECT code,name,type,is_active FROM accounts"
        if active_only:
            sql += " WHERE is_active=1"
        sql += " ORDER BY code"
        return list(self.conn.execute(sql))

    def account_row(self, code: str) -> sqlite3.Row:
        row = self.conn.execute("SELECT * FROM accounts WHERE code=?", (code,)).fetchone()
        if not row:
            raise LedgerError(f"Unknown account code: {code}")
        return row

    def account_id(self, code: str) -> int:
        row = self.conn.execute("SELECT id FROM accounts WHERE code=? AND is_active=1", (code,)).fetchone()
        if not row:
            raise LedgerError(f"Unknown or inactive account code: {code}")
        return int(row["id"])

    def add_contact(self, typ: str, name: str, email: str = "", phone: str = "", tax_id: str = "", notes: str = "") -> int:
        typ = typ.strip().lower()
        if typ not in CONTACT_TYPES:
            raise LedgerError(f"Contact type must be one of: {', '.join(CONTACT_TYPES)}")
        if not name.strip():
            raise LedgerError("Contact name is required.")
        cur = self.conn.execute(
            "INSERT INTO contacts(type,name,email,phone,tax_id,notes,created_at) VALUES(?,?,?,?,?,?,?)",
            (typ, name.strip(), email.strip(), phone.strip(), tax_id.strip(), notes.strip(), now_iso()),
        )
        self.conn.commit()
        return int(cur.lastrowid)

    def find_contact_id(self, name: str | None) -> Optional[int]:
        if not name:
            return None
        row = self.conn.execute("SELECT id FROM contacts WHERE lower(name)=lower(?) ORDER BY id LIMIT 1", (name.strip(),)).fetchone()
        return int(row["id"]) if row else None

    def ensure_contact(self, typ: str, name: str | None, email: str = "", phone: str = "", tax_id: str = "", notes: str = "") -> Optional[int]:
        """Return an existing contact id or create a lightweight registered customer/supplier.

        Quick sales, expenses, invoices, and bills can now remember who the
        record belongs to.  If the user types a customer/supplier name that is
        not registered yet, Sentinel Ledger creates a minimal contact record so
        later customer/supplier tabs can show order/expense history.
        """
        if not name or not str(name).strip():
            return None
        typ = typ.strip().lower()
        if typ not in CONTACT_TYPES:
            typ = "other"
        clean_name = str(name).strip()
        row = self.conn.execute("SELECT * FROM contacts WHERE lower(name)=lower(?) ORDER BY id LIMIT 1", (clean_name,)).fetchone()
        if row:
            existing_type = str(row["type"] or "other")
            if typ in ("customer", "supplier") and existing_type not in (typ, "both"):
                merged = "both" if existing_type in ("customer", "supplier") else typ
                self.conn.execute("UPDATE contacts SET type=? WHERE id=?", (merged, int(row["id"])))
                self.conn.commit()
            return int(row["id"])
        return self.add_contact(typ, clean_name, email=email, phone=phone, tax_id=tax_id, notes=notes or f"Auto-registered from ledger {typ} record.")

    def add_customer(self, name: str, email: str = "", phone: str = "", tax_id: str = "", notes: str = "") -> int:
        return int(self.ensure_contact("customer", name, email, phone, tax_id, notes) or 0)

    def add_supplier(self, name: str, email: str = "", phone: str = "", tax_id: str = "", notes: str = "") -> int:
        return int(self.ensure_contact("supplier", name, email, phone, tax_id, notes) or 0)

    def list_contacts(self) -> list[sqlite3.Row]:
        return list(self.conn.execute("SELECT id,type,name,email,phone,tax_id FROM contacts ORDER BY name COLLATE NOCASE"))

    def list_contact_registry(self, typ: str) -> list[sqlite3.Row]:
        """List registered customers or suppliers with remembered order/expense totals."""
        typ = typ.strip().lower()
        if typ not in ("customer", "supplier"):
            raise LedgerError("Contact registry type must be customer or supplier.")
        if typ == "customer":
            source_types = ("quick_sale", "invoice", "invoice_payment")
        else:
            source_types = ("quick_expense", "bill", "bill_payment")
        placeholders = ",".join("?" for _ in source_types)
        return list(self.conn.execute(f"""
            SELECT c.id,c.type,c.name,c.email,c.phone,c.tax_id,c.notes,c.created_at,
                   COUNT(DISTINCT e.id) AS record_count,
                   COALESCE(SUM(CASE WHEN l.side='debit' THEN l.amount_cents ELSE 0 END),0) AS debit_cents,
                   COALESCE(SUM(CASE WHEN l.side='credit' THEN l.amount_cents ELSE 0 END),0) AS credit_cents,
                   MAX(e.entry_date) AS last_record_date
            FROM contacts c
            LEFT JOIN journal_entries e ON e.contact_id=c.id AND e.source_type IN ({placeholders})
            LEFT JOIN journal_lines l ON l.entry_id=e.id
            WHERE c.type IN (?, 'both')
            GROUP BY c.id
            ORDER BY c.name COLLATE NOCASE
        """, (*source_types, typ)))

    def contact_history(self, contact_id: int, role: str | None = None, limit: int = 100) -> dict:
        detail = self.contact_detail(contact_id)
        role = (role or detail["contact"].get("type") or "contact").lower()
        source_filter = []
        if role == "customer":
            source_filter = ["quick_sale", "invoice", "invoice_payment"]
        elif role == "supplier":
            source_filter = ["quick_expense", "bill", "bill_payment"]
        params: list[object] = [int(contact_id)]
        clause = "WHERE e.contact_id=?"
        if source_filter:
            clause += " AND e.source_type IN (" + ",".join("?" for _ in source_filter) + ")"
            params.extend(source_filter)
        params.append(int(limit))
        rows = [dict(r) for r in self.conn.execute(f"""
            SELECT e.id,e.entry_date,e.description,e.source_type,e.source_ref,e.payment_method,
                   COALESCE(SUM(CASE WHEN l.side='debit' THEN l.amount_cents ELSE 0 END),0) AS debit_cents,
                   COALESCE(SUM(CASE WHEN l.side='credit' THEN l.amount_cents ELSE 0 END),0) AS credit_cents
            FROM journal_entries e LEFT JOIN journal_lines l ON l.entry_id=e.id
            {clause}
            GROUP BY e.id ORDER BY e.entry_date DESC,e.id DESC LIMIT ?
        """, tuple(params))]
        return {"contact": detail["contact"], "role": role, "record_count": len(rows), "records": rows, "checked_at": now_iso()}

    def update_contact(self, contact_id: int, typ: str | None = None, name: str | None = None, email: str | None = None, phone: str | None = None, tax_id: str | None = None, notes: str | None = None) -> None:
        if not self.conn.execute("SELECT id FROM contacts WHERE id=?", (int(contact_id),)).fetchone():
            raise LedgerError(f"Unknown contact id: {contact_id}")
        updates=[]; params=[]
        if typ is not None:
            typ = typ.strip().lower()
            if typ not in CONTACT_TYPES:
                raise LedgerError(f"Contact type must be one of: {', '.join(CONTACT_TYPES)}")
            updates.append("type=?"); params.append(typ)
        for col, val in (("name", name), ("email", email), ("phone", phone), ("tax_id", tax_id), ("notes", notes)):
            if val is not None:
                if col == "name" and not str(val).strip():
                    raise LedgerError("Contact name cannot be blank.")
                updates.append(f"{col}=?"); params.append(str(val).strip())
        if not updates:
            raise LedgerError("No contact updates requested.")
        params.append(int(contact_id))
        self.conn.execute(f"UPDATE contacts SET {', '.join(updates)} WHERE id=?", params)
        self.conn.commit()

    def contact_detail(self, contact_id: int) -> dict:
        row = self.conn.execute("SELECT * FROM contacts WHERE id=?", (int(contact_id),)).fetchone()
        if not row:
            raise LedgerError(f"Unknown contact id: {contact_id}")
        name = row["name"]
        tx = [dict(r) for r in self.conn.execute("""
            SELECT e.id,e.entry_date,e.description,e.source_type,e.source_ref,
                   COALESCE(SUM(CASE WHEN l.side='debit' THEN l.amount_cents ELSE 0 END),0) AS total_cents
            FROM journal_entries e LEFT JOIN journal_lines l ON l.entry_id=e.id
            WHERE e.contact_id=?
            GROUP BY e.id ORDER BY e.entry_date DESC,e.id DESC LIMIT 100
        """, (int(contact_id),))]
        invoices = [dict(r) for r in self.conn.execute("SELECT invoice_no,issue_date,due_date,description,total_cents,status FROM invoices WHERE lower(customer_name)=lower(?) ORDER BY issue_date DESC,id DESC", (name,))]
        bills = [dict(r) for r in self.conn.execute("SELECT bill_no,bill_date,due_date,description,total_cents,status FROM bills WHERE lower(supplier_name)=lower(?) ORDER BY bill_date DESC,id DESC", (name,))]
        return {"contact": dict(row), "transactions": tx, "invoices": invoices, "bills": bills, "checked_at": now_iso()}

    def search_contacts(self, text: str, limit: int = 100) -> dict:
        q = f"%{str(text or '').strip()}%"
        rows = [dict(r) for r in self.conn.execute("""
            SELECT id,type,name,email,phone,tax_id,notes,created_at FROM contacts
            WHERE name LIKE ? OR email LIKE ? OR phone LIKE ? OR tax_id LIKE ? OR notes LIKE ?
            ORDER BY name COLLATE NOCASE LIMIT ?
        """, (q,q,q,q,q,int(limit)))]
        return {"query": text, "count": len(rows), "contacts": rows, "checked_at": now_iso()}

    def link_document(self, entry_id: int, path: str, note: str = "") -> dict:
        if not self.conn.execute("SELECT id FROM journal_entries WHERE id=?", (int(entry_id),)).fetchone():
            raise LedgerError(f"Unknown journal entry id: {entry_id}")
        doc_id = self.add_document_ref(int(entry_id), path, note)
        entry = self.conn.execute("SELECT source_ref,source_type FROM journal_entries WHERE id=?", (int(entry_id),)).fetchone()
        meta = self.record_aegis_metadata("linked_document", path, {"document_ref_id": doc_id, "note": note, "source_type": entry["source_type"] if entry else ""}, int(entry_id), entry["source_ref"] if entry else "")
        return {"ok": True, "entry_id": int(entry_id), "document_ref_id": doc_id, "path": str(Path(path).expanduser()), "metadata": meta}

    def is_period_locked(self, entry_date: str) -> bool:
        validate_date(entry_date)
        row = self.conn.execute("SELECT MAX(locked_through) AS locked_through FROM period_locks").fetchone()
        locked = row["locked_through"] if row else None
        return bool(locked and entry_date <= locked)

    def lock_period(self, locked_through: str, reason: str = "") -> int:
        locked_through = validate_date(locked_through)
        cur = self.conn.execute("INSERT INTO period_locks(locked_through,reason,created_at) VALUES(?,?,?)", (locked_through, reason.strip(), now_iso()))
        self.conn.commit()
        return int(cur.lastrowid)

    def latest_period_lock(self) -> str:
        row = self.conn.execute("SELECT MAX(locked_through) AS locked_through FROM period_locks").fetchone()
        return str(row["locked_through"] or "")

    def add_journal_entry(self, entry_date: str, description: str, lines: list[JournalLine], source_type: str = "manual", source_ref: str = "", contact_name: str | None = None, memo: str = "", document_path: str | None = None, is_reversal: bool = False, reverses_entry_id: int | None = None, payment_method: str = "") -> int:
        entry_date = validate_date(entry_date)
        if self.is_period_locked(entry_date):
            raise LedgerError(f"Period is locked through {self.latest_period_lock()}; enter a later-dated correction/reversal instead.")
        description = description.strip()
        if not description:
            raise LedgerError("Description is required.")
        if len(lines) < 2:
            raise LedgerError("At least two journal lines are required.")
        debit = sum(l.amount_cents for l in lines if l.side == "debit")
        credit = sum(l.amount_cents for l in lines if l.side == "credit")
        if debit != credit:
            raise LedgerError(f"Journal entry is not balanced. Debit {money_str(debit)} != Credit {money_str(credit)}")
        if debit <= 0:
            raise LedgerError("Journal entry total must be greater than zero.")
        for line in lines:
            if line.side not in SIDES:
                raise LedgerError("Line side must be debit or credit.")
            if line.amount_cents <= 0:
                raise LedgerError("Journal line amount must be greater than zero.")
        contact_id = self.find_contact_id(contact_name)
        with self.conn:
            cur = self.conn.execute(
                "INSERT INTO journal_entries(entry_date,description,source_type,source_ref,contact_id,memo,created_at,is_reversal,reverses_entry_id,payment_method) VALUES(?,?,?,?,?,?,?,?,?,?)",
                (entry_date, description, source_type, source_ref, contact_id, memo.strip(), now_iso(), 1 if is_reversal else 0, reverses_entry_id, payment_method.strip()),
            )
            entry_id = int(cur.lastrowid)
            for line in lines:
                account_id = self.account_id(line.account_code)
                self.conn.execute(
                    "INSERT INTO journal_lines(entry_id,account_id,side,amount_cents,tax_rate_bps,tax_amount_cents,memo) VALUES(?,?,?,?,?,?,?)",
                    (entry_id, account_id, line.side, int(line.amount_cents), int(line.tax_rate_bps), int(line.tax_amount_cents), line.memo.strip()),
                )
            if document_path:
                self.add_document_ref(entry_id, document_path, commit=False)
        return entry_id

    def add_document_ref(self, entry_id: Optional[int], path: str, note: str = "", commit: bool = True) -> int:
        p = Path(path).expanduser()
        if p.exists() and p.is_symlink():
            raise LedgerError(f"Refusing to index symlinked document path: {p}")
        digest = sha256_file(p) if p.exists() and p.is_file() else ""
        cur = self.conn.execute("INSERT INTO document_refs(entry_id,path,sha256,note,created_at) VALUES(?,?,?,?,?)", (entry_id, str(p), digest, note.strip(), now_iso()))
        if commit:
            self.conn.commit()
        return int(cur.lastrowid)

    def record_aegis_metadata(self, record_type: str, path: str | Path | None = None, payload: dict | None = None, entry_id: int | None = None, source_ref: str = "") -> dict:
        """Write a small AEGIS-readable metadata record into the local AEGIS Vault.

        Metadata only: enough for AEGIS/Sentinel Command to remember that a ledger
        artifact exists, where it lives, what it hashes to, and what it relates to.
        Private report contents stay in the actual ledger/report files.
        """
        payload = dict(payload or {})
        p = Path(path).expanduser() if path else None
        meta_dir = aegis_metadata_dir()
        meta_dir.mkdir(parents=True, exist_ok=True)
        rec = {
            "app": APP_NAME,
            "app_id": APP_ID,
            "program_id": PROGRAM_ID,
            "version": VERSION,
            "record_type": str(record_type),
            "created_at": now_iso(),
            "db_path": str(self.db_path),
            "entry_id": entry_id,
            "source_ref": source_ref or "",
            "path": str(p) if p else "",
            "sha256": sha256_file(p) if p and p.exists() and p.is_file() and not p.is_symlink() else "",
            "size_bytes": p.stat().st_size if p and p.exists() and p.is_file() and not p.is_symlink() else 0,
            "payload": payload,
        }
        index_path = meta_dir / "sentinel_ledger_aegis_metadata.jsonl"
        safe_append_text_file(index_path, json.dumps(rec, sort_keys=True) + "\n", mode=0o600)
        latest_path = meta_dir / "sentinel_ledger_latest_metadata.json"
        safe_write_text_file(latest_path, json.dumps(rec, indent=2), mode=0o600)
        try:
            self.log_recovery_event("aegis_metadata_indexed", "ok", f"Indexed {record_type} metadata for AEGIS", {"metadata_index": str(index_path), "path": rec["path"], "entry_id": entry_id, "source_ref": source_ref or ""})
        except sqlite3.DatabaseError:
            pass
        return rec

    def aegis_metadata_status(self) -> dict:
        meta_dir = aegis_metadata_dir()
        index_path = meta_dir / "sentinel_ledger_aegis_metadata.jsonl"
        latest_path = meta_dir / "sentinel_ledger_latest_metadata.json"
        count = 0
        latest = None
        if index_path.exists():
            with index_path.open("r", encoding="utf-8") as f:
                for line in f:
                    if line.strip():
                        count += 1
                        try:
                            latest = json.loads(line)
                        except json.JSONDecodeError:
                            pass
        return {
            "ok": index_path.exists(),
            "metadata_dir": str(meta_dir),
            "index_path": str(index_path),
            "latest_path": str(latest_path),
            "metadata_records": count,
            "latest_record": latest,
            "aegis_recollection_mode": "metadata-only-local-vault",
            "checked_at": now_iso(),
        }

    def tax_code(self, code: str) -> sqlite3.Row:
        row = self.conn.execute("SELECT * FROM tax_codes WHERE upper(code)=upper(?) AND is_active=1", (code.strip(),)).fetchone()
        if not row:
            raise LedgerError(f"Unknown or inactive tax code: {code}")
        return row

    def tax_rate_for(self, tax_rate: str, tax_code: str | None = None) -> int:
        if tax_code:
            return int(self.tax_code(tax_code)["rate_bps"])
        return parse_rate_bps(tax_rate)

    def next_reference(self, source_type: str) -> str:
        prefix_map = {
            "quick_sale": "SALE",
            "quick_expense": "EXP",
            "invoice": "INV",
            "bill": "BILL",
            "receipt": "RCT",
        }
        prefix = prefix_map.get(source_type, "LEDGER")
        stamp = _dt.datetime.now().strftime("%Y%m%d")
        like = f"{prefix}-{stamp}-%"
        row = self.conn.execute(
            "SELECT source_ref FROM journal_entries WHERE source_ref LIKE ? ORDER BY source_ref DESC LIMIT 1",
            (like,),
        ).fetchone()
        seq = 1
        if row and row["source_ref"]:
            try:
                seq = int(str(row["source_ref"]).rsplit("-", 1)[-1]) + 1
            except (TypeError, ValueError):
                seq = 1
        return f"{prefix}-{stamp}-{seq:04d}"

    def log_reference_index(self, entry_id: int, source_type: str, source_ref: str) -> None:
        self.log_recovery_event(
            "source_reference_indexed",
            "ok",
            f"Indexed {source_type} reference {source_ref} for entry #{entry_id}",
            {"entry_id": entry_id, "source_type": source_type, "source_ref": source_ref},
        )
        self.conn.commit()

    def quick_sale(self, amount: str, description: str, entry_date: str | None = None, tax_rate: str = "0.10", tax_mode: str = "inclusive", receive_account: str = "1010", income_account: str = "4000", gst_account: str = "2200", customer: str | None = None, source_ref: str = "", document_path: str | None = None, tax_code: str | None = None, payment_method: str = "") -> int:
        if not str(source_ref or "").strip():
            source_ref = self.next_reference("quick_sale")
        self.ensure_contact("customer", customer)
        bps = self.tax_rate_for(tax_rate, tax_code if FEATURE_LEVEL >= 5 else None)
        subtotal, tax, total = split_tax(parse_money(amount), bps, tax_mode)
        lines = [
            JournalLine(receive_account, "debit", money_to_cents(total), "sale receipt total"),
            JournalLine(income_account, "credit", money_to_cents(subtotal), "sale subtotal", bps, money_to_cents(tax)),
        ]
        if money_to_cents(tax) > 0:
            lines.append(JournalLine(gst_account, "credit", money_to_cents(tax), "tax collected", bps, money_to_cents(tax)))
        eid = self.add_journal_entry(entry_date or today(), description, lines, "quick_sale", source_ref, customer, document_path=document_path, payment_method=payment_method)
        self.log_reference_index(eid, "quick_sale", source_ref)
        return eid

    def quick_expense(self, amount: str, description: str, entry_date: str | None = None, tax_rate: str = "0.10", tax_mode: str = "inclusive", pay_account: str = "1010", expense_account: str = "5000", gst_account: str = "1300", supplier: str | None = None, source_ref: str = "", document_path: str | None = None, tax_code: str | None = None, payment_method: str = "") -> int:
        if not str(source_ref or "").strip():
            source_ref = self.next_reference("quick_expense")
        self.ensure_contact("supplier", supplier)
        bps = self.tax_rate_for(tax_rate, tax_code if FEATURE_LEVEL >= 5 else None)
        subtotal, tax, total = split_tax(parse_money(amount), bps, tax_mode)
        lines = [JournalLine(expense_account, "debit", money_to_cents(subtotal), "expense subtotal", bps, money_to_cents(tax))]
        if money_to_cents(tax) > 0:
            lines.append(JournalLine(gst_account, "debit", money_to_cents(tax), "tax paid", bps, money_to_cents(tax)))
        lines.append(JournalLine(pay_account, "credit", money_to_cents(total), "payment total"))
        eid = self.add_journal_entry(entry_date or today(), description, lines, "quick_expense", source_ref, supplier, document_path=document_path, payment_method=payment_method)
        self.log_reference_index(eid, "quick_expense", source_ref)
        return eid

    def existing_receipt_number(self, entry_id: int) -> str:
        row = self.conn.execute("SELECT note FROM document_refs WHERE entry_id=? AND note LIKE ? ORDER BY id ASC LIMIT 1", (entry_id, "%receipt_no=%")).fetchone()
        if row and row["note"]:
            note = str(row["note"])
            marker = "receipt_no="
            if marker in note:
                return note.split(marker, 1)[1].split()[0].strip(" ;,")
        return ""

    def next_receipt_number(self) -> str:
        stamp = _dt.datetime.now().strftime("%Y%m%d")
        key_date = "receipt_sequence_date"
        key_seq = "receipt_sequence_number"
        meta = self.meta()
        seq = 1
        if meta.get(key_date) == stamp:
            try:
                seq = int(meta.get(key_seq, "0")) + 1
            except ValueError:
                seq = 1
        self.set_meta(key_date, stamp)
        self.set_meta(key_seq, str(seq))
        return f"RCT-{stamp}-{seq:04d}"

    def receipt_text(self, entry_id: int, receipt_no: str | None = None) -> str:
        detail = self.entry_detail(entry_id)
        entry = detail["entry"]
        total = sum(int(l["amount_cents"] or 0) for l in detail["lines"] if l["side"] == "debit")
        profile = self.get_business_profile()
        tpl = self.receipt_template()
        receipt_no = receipt_no or self.existing_receipt_number(entry_id) or f"RCT-{entry.get('source_ref') or entry_id}"
        header = tpl.get("header") or "SENTINEL LEDGER RECEIPT"
        lines = [
            header,
            "=" * max(23, len(header)),
            tpl.get("business_details") or profile.get('business_name') or 'Unconfigured business',
            f"Receipt: {receipt_no}",
            f"Entry:    #{entry['id']}",
            f"Date:     {display_date(entry['entry_date'])}",
            f"Ref:      {entry.get('source_ref') or ''}",
            f"Type:     {entry.get('source_type') or ''}",
            f"Details:  {entry.get('description') or ''}",
            f"Total:    {money_str(total)} {profile.get('currency') or 'AUD'}",
            "",
            "Ledger lines:",
        ]
        for l in detail["lines"]:
            lines.append(f"  {l['code']} {l['name']:<28} {l['side']:<6} {money_str(int(l['amount_cents']))}")
        if tpl.get("advert"):
            lines.extend(["", "ADVERTISEMENT / NOTICE", tpl["advert"]])
        if tpl.get("footer"):
            lines.extend(["", tpl["footer"]])
        lines.append("")
        lines.append("Generated locally by Sentinel Ledger. No cloud. No telemetry.")
        lines.append(f"Generated at: {now_iso()}")
        return "\n".join(lines) + "\n"

    def write_receipt(self, entry_id: int, out_dir: Path | None = None) -> Path:
        detail = self.entry_detail(entry_id)
        entry = detail["entry"]
        existing_no = self.existing_receipt_number(entry_id)
        receipt_no = existing_no or self.next_receipt_number()
        ref = (receipt_no or entry.get("source_ref") or f"entry-{entry_id}").replace("/", "-").replace("\\", "-")
        out_dir = prepare_private_dir(Path(out_dir).expanduser() if out_dir else vault_dir() / "Receipts")
        out = out_dir / f"{ref}_receipt.txt"
        safe_write_text_file(out, self.receipt_text(entry_id, receipt_no=receipt_no), mode=0o600)
        self.add_document_ref(entry_id, str(out), note=f"Generated Sentinel Ledger receipt; receipt_no={receipt_no}", commit=False)
        self.record_aegis_metadata("receipt", out, {"note": "Generated Sentinel Ledger receipt", "entry_id": entry_id, "receipt_no": receipt_no}, entry_id=entry_id, source_ref=entry.get("source_ref") or "")
        self.log_recovery_event("receipt_generated", "ok", f"Generated receipt {receipt_no} for entry #{entry_id}", {"path": str(out), "entry_id": entry_id, "source_ref": entry.get("source_ref"), "receipt_no": receipt_no})
        self.conn.commit()
        return out

    def receipt_print_open_status(self, path: Path) -> dict:
        p = Path(path).expanduser()
        return {
            "path": str(p),
            "exists": p.exists(),
            "print_command_available": bool(shutil.which("lpr") or shutil.which("lp")),
            "open_command_available": bool(shutil.which("xdg-open")),
            "checked_at": now_iso(),
        }

    def receipt_template(self) -> dict:
        profile = self.get_business_profile()
        def get_meta(key: str, fallback: str = "") -> str:
            row = self.conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
            return str(row["value"]) if row and row["value"] is not None else fallback
        return {
            "header": get_meta("receipt_template_header", "SENTINEL LEDGER RECEIPT"),
            "business_details": get_meta("receipt_template_business_details", profile.get("business_name") or "Unconfigured business"),
            "footer": get_meta("receipt_template_footer", "Thank you for your business."),
            "advert": get_meta("receipt_template_advert", "Advertise here"),
        }

    def update_receipt_template(self, header: str = "", business_details: str = "", footer: str = "", advert: str = "") -> dict:
        values = {
            "receipt_template_header": header.strip() or "SENTINEL LEDGER RECEIPT",
            "receipt_template_business_details": business_details.strip(),
            "receipt_template_footer": footer.strip(),
            "receipt_template_advert": advert.strip(),
        }
        for key, value in values.items():
            self.set_meta(key, value)
        self.log_recovery_event("receipt_template_updated", "ok", "Updated receipt template", {"fields": sorted(values)})
        self.conn.commit()
        return self.receipt_template()

    def draft_receipt_preview(self, amount: str = "", description: str = "", entry_date: str = "", tax_rate: str = "10%", tax_mode: str = "inclusive", customer: str = "", source_ref: str = "") -> str:
        profile = self.get_business_profile()
        tpl = self.receipt_template()
        ref = source_ref.strip() or self.next_reference("quick_sale")
        total_text = "not entered"
        tax_text = "not calculated"
        try:
            subtotal, tax, total = split_tax(parse_money(amount or "0"), parse_rate_bps(tax_rate or "0%"), tax_mode or "inclusive")
            total_text = f"{total:,.2f} {profile.get('currency') or 'AUD'}"
            tax_text = f"subtotal {subtotal:,.2f} · tax {tax:,.2f}"
        except Exception:
            pass
        lines = [
            tpl.get("header") or "SENTINEL LEDGER RECEIPT",
            "=" * max(24, len(tpl.get("header") or "SENTINEL LEDGER RECEIPT")),
            tpl.get("business_details") or profile.get("business_name") or "Unconfigured business",
            "",
            "DRAFT RECEIPT PREVIEW",
            f"Date:     {display_date(entry_date or today())}",
            f"Ref:      {ref}",
            f"Customer: {customer or '-'}",
            f"Details:  {description or '-'}",
            f"Total:    {total_text}",
            f"Tax:      {tax_text}",
        ]
        if tpl.get("advert"):
            lines.extend(["", "ADVERTISEMENT / NOTICE", tpl["advert"]])
        if tpl.get("footer"):
            lines.extend(["", tpl["footer"]])
        lines.extend(["", "Preview only — final receipt is generated after the sale is recorded."])
        return "\n".join(lines) + "\n"

    def inventory_bridge_status(self, write_contract: bool = True) -> dict:
        bridge_dir = vault_dir() / "Inventory_Bridge"
        contract_path = bridge_dir / "sentinel_ledger_inventory_bridge_status.json"
        status = {
            "ok": True,
            "bridge_name": "Sentinel Ledger ↔ Sentinel Inventory",
            "ledger_program": "107",
            "inventory_program": "115",
            "mode": "local-file-contract",
            "current_connection": "standby-awaiting-sentinel-inventory",
            "network_required": False,
            "ledger_can_export_sale_refs": True,
            "ledger_can_accept_future_inventory_item_refs": True,
            "stock_mutation_enabled_now": False,
            "contract_path": str(contract_path),
            "notes": "Future Sentinel Inventory can use this local contract to link inventory items, stock movements, sales references, and receipt metadata. No inventory stock changes are performed by Ledger yet.",
            "checked_at": now_iso(),
        }
        if write_contract:
            prepare_private_dir(bridge_dir)
            safe_write_text_file(contract_path, json.dumps(status, indent=2, sort_keys=True), mode=0o600)
            self.record_aegis_metadata("inventory_bridge_contract", contract_path, {"note": "Sentinel Inventory bridge contract", "inventory_program": "115"})
        return status

    def aegis_capability_manifest(self) -> dict:
        return {
            "app": APP_NAME,
            "program_id": PROGRAM_ID,
            "version": VERSION,
            "aegis_integration_encoded": True,
            "mode": "local-read-mostly-guarded-write",
            "read_only_capabilities": [
                "health", "aegis-summary", "aegis-readiness", "dashboard-summary", "aegis-metadata-status", "migration-status", "recovery-status", "backup-status", "integrity-check", "gst-status --json", "inventory-bridge-status"
            ],
            "guarded_user_approved_write_capabilities": [
                "backup-json", "receipt ENTRY_ID", "accountant-bas-report", "install-desktop-launcher", "setup-wizard", "create-ledger"
            ],
            "blocked_without_user_approval": [
                "create/edit/delete financial records", "lodge BAS/tax", "silently mutate inventory stock", "send data online"
            ],
            "vault_metadata_mode": "metadata-only",
            "network_required": False,
            "inventory_bridge_status": self.inventory_bridge_status(write_contract=False),
            "checked_at": now_iso(),
        }

    def search_records(self, text: str, limit: int = 100) -> dict:
        q = (text or "").strip()
        if not q:
            return {"query": q, "transactions": [], "receipts": [], "count": 0}
        like = f"%{q}%"
        transactions = [dict(r) for r in self.conn.execute("""
            SELECT e.id,e.entry_date,e.description,e.source_type,e.source_ref,
                   SUM(CASE WHEN l.side='debit' THEN l.amount_cents ELSE 0 END) AS total_cents
            FROM journal_entries e JOIN journal_lines l ON l.entry_id=e.id
            WHERE e.description LIKE ? OR e.source_ref LIKE ? OR e.memo LIKE ?
            GROUP BY e.id ORDER BY e.entry_date DESC,e.id DESC LIMIT ?
        """, (like, like, like, limit))]
        receipts = [dict(r) for r in self.conn.execute("""
            SELECT d.id,d.entry_id,d.path,d.sha256,d.note,d.created_at,e.source_ref,e.description
            FROM document_refs d LEFT JOIN journal_entries e ON e.id=d.entry_id
            WHERE d.path LIKE ? OR d.sha256 LIKE ? OR d.note LIKE ? OR e.source_ref LIKE ? OR e.description LIKE ?
            ORDER BY d.created_at DESC,d.id DESC LIMIT ?
        """, (like, like, like, like, like, limit))]
        return {"query": q, "transactions": transactions, "receipts": receipts, "count": len(transactions)+len(receipts), "checked_at": now_iso()}

    def opening_balance(self, account_code: str, amount: str, entry_date: str | None = None, side: str | None = None, equity_account: str = "3200", memo: str = "") -> int:
        row = self.account_row(account_code)
        if side is None:
            side = "debit" if row["type"] in ("asset", "expense") else "credit"
        side = side.lower()
        if side not in SIDES:
            raise LedgerError("Opening balance side must be debit or credit.")
        other = "credit" if side == "debit" else "debit"
        lines = [
            JournalLine(account_code, side, money_to_cents(amount), "opening balance"),
            JournalLine(equity_account, other, money_to_cents(amount), "opening balance equity"),
        ]
        return self.add_journal_entry(entry_date or today(), f"Opening balance — {row['code']} {row['name']}", lines, "opening_balance", memo, memo=memo)

    def recent_transactions(self, limit: int = 25, start: str | None = None, end: str | None = None, source_type: str | None = None, text: str | None = None) -> list[sqlite3.Row]:
        clauses = []
        params: list[object] = []
        if start:
            start = validate_date(start); clauses.append("e.entry_date >= ?"); params.append(start)
        if end:
            end = validate_date(end); clauses.append("e.entry_date <= ?"); params.append(end)
        if source_type:
            clauses.append("e.source_type = ?"); params.append(source_type)
        if text:
            clauses.append("(e.description LIKE ? OR e.memo LIKE ? OR e.source_ref LIKE ?)")
            like = f"%{text}%"; params += [like, like, like]
        where = "WHERE " + " AND ".join(clauses) if clauses else ""
        params.append(limit)
        return list(self.conn.execute(f"""
            SELECT e.id,e.entry_date,e.description,e.source_type,e.source_ref,e.is_reversal,
                   SUM(CASE WHEN l.side='debit' THEN l.amount_cents ELSE 0 END) AS total_cents
            FROM journal_entries e JOIN journal_lines l ON l.entry_id=e.id
            {where}
            GROUP BY e.id
            ORDER BY e.entry_date DESC, e.id DESC
            LIMIT ?
        """, params))

    def entry_detail(self, entry_id: int) -> dict:
        entry = self.conn.execute("SELECT * FROM journal_entries WHERE id=?", (entry_id,)).fetchone()
        if not entry:
            raise LedgerError(f"Unknown journal entry: {entry_id}")
        lines = list(self.conn.execute("""
            SELECT l.*,a.code,a.name,a.type FROM journal_lines l JOIN accounts a ON a.id=l.account_id
            WHERE l.entry_id=? ORDER BY l.id
        """, (entry_id,)))
        docs = list(self.conn.execute("SELECT * FROM document_refs WHERE entry_id=? ORDER BY id", (entry_id,)))
        return {"entry": dict(entry), "lines": [dict(r) for r in lines], "documents": [dict(r) for r in docs]}

    def reverse_entry(self, entry_id: int, entry_date: str | None = None, reason: str = "") -> int:
        detail = self.entry_detail(entry_id)
        original = detail["entry"]
        lines = []
        for r in detail["lines"]:
            lines.append(JournalLine(r["code"], "credit" if r["side"] == "debit" else "debit", int(r["amount_cents"]), f"reversal of entry #{entry_id}", int(r["tax_rate_bps"] or 0), int(r["tax_amount_cents"] or 0)))
        desc = f"REVERSAL of #{entry_id}: {original['description']}"
        return self.add_journal_entry(entry_date or today(), desc, lines, "reversal", str(entry_id), memo=reason, is_reversal=True, reverses_entry_id=entry_id)

    def unbalanced_entries(self) -> list[sqlite3.Row]:
        return list(self.conn.execute("""
            SELECT e.id,e.entry_date,e.description,
                   SUM(CASE WHEN l.side='debit' THEN l.amount_cents ELSE 0 END) AS debit_cents,
                   SUM(CASE WHEN l.side='credit' THEN l.amount_cents ELSE 0 END) AS credit_cents
            FROM journal_entries e JOIN journal_lines l ON l.entry_id=e.id
            GROUP BY e.id HAVING debit_cents != credit_cents
            ORDER BY e.entry_date DESC, e.id DESC
        """))

    def integrity_check(self) -> dict:
        unbalanced = self.unbalanced_entries()
        inactive_lines = list(self.conn.execute("""
            SELECT l.id,e.id AS entry_id,a.code,a.name FROM journal_lines l
            JOIN accounts a ON a.id=l.account_id JOIN journal_entries e ON e.id=l.entry_id
            WHERE a.is_active=0 ORDER BY e.id,l.id
        """))
        orphan_docs = list(self.conn.execute("SELECT * FROM document_refs WHERE entry_id IS NOT NULL AND entry_id NOT IN (SELECT id FROM journal_entries)"))
        lock = self.latest_period_lock()
        return {
            "ok": not unbalanced and not orphan_docs,
            "unbalanced_entries": [dict(r) for r in unbalanced],
            "inactive_account_lines": [dict(r) for r in inactive_lines],
            "orphan_document_refs": [dict(r) for r in orphan_docs],
            "latest_period_lock": lock,
            "checked_at": now_iso(),
        }

    def deep_integrity_check(self) -> dict:
        """Phase 3 read-only integrity check. No repairs are applied here."""
        basic = self.integrity_check()
        foreign_key_issues = []
        try:
            foreign_key_issues = [dict(r) for r in self.conn.execute("PRAGMA foreign_key_check")]
        except Exception as exc:
            foreign_key_issues = [{"error": str(exc)}]

        orphan_journal_lines = [dict(r) for r in self.conn.execute("""
            SELECT l.id,l.entry_id,l.account_id,l.side,l.amount_cents
            FROM journal_lines l LEFT JOIN journal_entries e ON e.id=l.entry_id
            WHERE e.id IS NULL ORDER BY l.id
        """)]
        missing_account_lines = [dict(r) for r in self.conn.execute("""
            SELECT l.id,l.entry_id,l.account_id,l.side,l.amount_cents
            FROM journal_lines l LEFT JOIN accounts a ON a.id=l.account_id
            WHERE a.id IS NULL ORDER BY l.id
        """)]
        invoice_entry_links = [dict(r) for r in self.conn.execute("""
            SELECT id, invoice_no, journal_entry_id, paid_entry_id FROM invoices
            WHERE (journal_entry_id IS NOT NULL AND journal_entry_id NOT IN (SELECT id FROM journal_entries))
               OR (paid_entry_id IS NOT NULL AND paid_entry_id NOT IN (SELECT id FROM journal_entries))
            ORDER BY id
        """)] if self.table_exists("invoices") else []
        bill_entry_links = [dict(r) for r in self.conn.execute("""
            SELECT id, bill_no, journal_entry_id, paid_entry_id FROM bills
            WHERE (journal_entry_id IS NOT NULL AND journal_entry_id NOT IN (SELECT id FROM journal_entries))
               OR (paid_entry_id IS NOT NULL AND paid_entry_id NOT IN (SELECT id FROM journal_entries))
            ORDER BY id
        """)] if self.table_exists("bills") else []

        missing_documents = []
        hash_mismatches = []
        for r in self.conn.execute("SELECT id,entry_id,path,sha256,note FROM document_refs ORDER BY id"):
            rec = dict(r); path = Path(rec.get("path") or "").expanduser()
            if not path.exists():
                missing_documents.append(rec)
            elif rec.get("sha256") and path.is_file():
                current = sha256_file(path)
                if current and current != rec.get("sha256"):
                    rec["current_sha256"] = current
                    hash_mismatches.append(rec)

        profiles = list_ledger_profiles()
        missing_profile_dbs = [r for r in profiles.get("ledgers", []) if not r.get("exists")]
        backup = self.backup_status()
        issues = []
        for name, rows in [("foreign_key_issues", foreign_key_issues), ("orphan_journal_lines", orphan_journal_lines), ("missing_account_lines", missing_account_lines), ("invoice_entry_link_issues", invoice_entry_links), ("bill_entry_link_issues", bill_entry_links), ("missing_document_files", missing_documents), ("document_hash_mismatches", hash_mismatches), ("missing_ledger_profile_databases", missing_profile_dbs)]:
            if rows:
                issues.append(name)
        return {
            "ok": bool(basic.get("ok")) and not issues,
            "phase": "v0.7.5 data integrity and recovery hardening",
            "basic_integrity": basic,
            "foreign_key_issues": foreign_key_issues,
            "orphan_journal_lines": orphan_journal_lines,
            "missing_account_lines": missing_account_lines,
            "invoice_entry_link_issues": invoice_entry_links,
            "bill_entry_link_issues": bill_entry_links,
            "missing_document_files": missing_documents,
            "document_hash_mismatches": hash_mismatches,
            "ledger_profiles": profiles,
            "missing_ledger_profile_databases": missing_profile_dbs,
            "backup_status": backup,
            "issues": issues,
            "read_only": True,
            "checked_at": now_iso(),
        }

    def backup_schedule_status(self, max_age_days: int = 7) -> dict:
        backup = self.backup_status()
        last = backup.get("last_backup") if isinstance(backup, dict) else None
        due = True
        age_days = None
        if isinstance(last, dict) and last.get("created_at"):
            try:
                dt = _dt.datetime.fromisoformat(str(last.get("created_at")))
                age_days = (_dt.datetime.now() - dt).days
                due = age_days > int(max_age_days)
            except Exception:
                due = True
        return {
            "ok": not due,
            "recommended_frequency_days": max_age_days,
            "backup_due": due,
            "last_backup": last,
            "last_backup_age_days": age_days,
            "recommended_command": "sentinel-ledger backup-json",
            "note": "Local reminder status only; no background cloud sync or automatic scheduler is enabled.",
            "checked_at": now_iso(),
        }

    def pre_upgrade_backup_status(self) -> dict:
        backup = self.backup_status()
        schedule = self.backup_schedule_status()
        return {
            "ok": bool(backup.get("ok")) and not bool(schedule.get("backup_due")),
            "backup_status": backup,
            "backup_schedule_status": schedule,
            "upgrade_policy": "Create and verify a local backup before major version upgrades.",
            "recommended_command": "sentinel-ledger backup-json",
            "checked_at": now_iso(),
        }

    def restore_wizard_status(self) -> dict:
        backup = self.backup_status()
        recent = []
        for row in backup.get("recent_backups", []) if isinstance(backup, dict) else []:
            p = Path(row.get("path") or "").expanduser()
            recent.append({**row, "exists_now": p.exists(), "restore_check_command": f"sentinel-ledger restore-check {p}", "restore_to_new_db_command": f"sentinel-ledger restore-json {p} ~/restored_sentinel_ledger.db"})
        return {
            "ok": bool(recent),
            "mode": "guided-restore-status",
            "recent_backups": recent,
            "safe_restore_rule": "Restore into a new database path first. Do not overwrite the active ledger unless the restored copy has been checked.",
            "gui_ready": True,
            "checked_at": now_iso(),
        }

    def diagnose_repair_status(self) -> dict:
        deep = self.deep_integrity_check()
        actions = []
        if deep.get("missing_document_files"):
            actions.append("Relink or re-index missing receipt/document files from the original location or backup.")
        if deep.get("document_hash_mismatches"):
            actions.append("Review changed receipt/document files before trusting them as source evidence.")
        if deep.get("orphan_journal_lines") or deep.get("missing_account_lines") or deep.get("foreign_key_issues"):
            actions.append("Create a backup and restore/check a clean copy before attempting any repair.")
        if not actions:
            actions.append("No repair action suggested. Keep regular backups.")
        return {
            "ok": deep.get("ok"),
            "mode": "read-only-diagnostics-first",
            "deep_integrity": deep,
            "suggested_actions": actions,
            "mutation_allowed_without_user_approval": False,
            "checked_at": now_iso(),
        }

    def recovery_report_text(self) -> str:
        recovery = self.recovery_status()
        deep = self.deep_integrity_check()
        schedule = self.backup_schedule_status()
        pre = self.pre_upgrade_backup_status()
        lines = []
        lines.append("SENTINEL LEDGER RECOVERY REPORT")
        lines.append("=" * 38)
        lines.append("")
        lines.append(f"App version:        {VERSION}")
        lines.append(f"Schema version:     {SCHEMA_VERSION}")
        lines.append(f"Database:           {self.db_path}")
        lines.append(f"Recovery status:    {'OK' if recovery.get('ok') else 'CHECK'}")
        lines.append(f"Deep integrity:     {'OK' if deep.get('ok') else 'CHECK'}")
        lines.append(f"Backup due:         {'YES' if schedule.get('backup_due') else 'NO'}")
        lines.append(f"Pre-upgrade backup: {'READY' if pre.get('ok') else 'CREATE BACKUP FIRST'}")
        lines.append("")
        lines.append("Issue summary")
        lines.append("-------------")
        for key in ["issues", "risks"]:
            vals = deep.get(key) or recovery.get(key) or []
            for val in vals:
                lines.append(f"• {val}")
        if not deep.get("issues") and not recovery.get("risks"):
            lines.append("• No data-integrity issues detected by the current checks.")
        lines.append("")
        lines.append("Recommended next actions")
        lines.append("------------------------")
        lines.append("• Run Backup JSON before major upgrades or repairs.")
        lines.append("• Use Restore Check before trusting a backup.")
        lines.append("• Restore into a new database path first; avoid overwriting the active ledger.")
        lines.append("• Keep receipt/document originals where possible; Ledger tracks metadata and hashes.")
        lines.append("")
        lines.append("Local-only · No cloud · No telemetry · Repair diagnostics are read-only until explicitly approved.")
        return "\n".join(lines)

    def trial_balance(self) -> list[sqlite3.Row]:
        return list(self.conn.execute("""
            SELECT a.code,a.name,a.type,
                   COALESCE(SUM(CASE WHEN l.side='debit' THEN l.amount_cents ELSE 0 END),0) AS debit_cents,
                   COALESCE(SUM(CASE WHEN l.side='credit' THEN l.amount_cents ELSE 0 END),0) AS credit_cents
            FROM accounts a LEFT JOIN journal_lines l ON l.account_id=a.id
            GROUP BY a.id ORDER BY a.code
        """))

    def _date_clause(self, start: str | None, end: str | None, prefix: str = "e") -> tuple[str, list[str]]:
        parts = []
        params = []
        if start:
            start = validate_date(start); parts.append(f"{prefix}.entry_date >= ?"); params.append(start)
        if end:
            end = validate_date(end); parts.append(f"{prefix}.entry_date <= ?"); params.append(end)
        if not parts:
            return "", []
        return " AND " + " AND ".join(parts), params

    def profit_loss(self, start: str | None = None, end: str | None = None) -> dict:
        clause, params = self._date_clause(start, end, prefix="e")
        rows = list(self.conn.execute(f"""
            SELECT a.type,a.code,a.name,
                   COALESCE(SUM(CASE WHEN l.side='debit' THEN l.amount_cents ELSE 0 END),0) AS debit_cents,
                   COALESCE(SUM(CASE WHEN l.side='credit' THEN l.amount_cents ELSE 0 END),0) AS credit_cents
            FROM accounts a
            LEFT JOIN journal_lines l ON l.account_id=a.id
            LEFT JOIN journal_entries e ON e.id=l.entry_id
            WHERE a.type IN ('income','expense') {clause}
            GROUP BY a.id ORDER BY a.type,a.code
        """, params))
        income=[]; expenses=[]; total_income=0; total_expense=0
        for r in rows:
            debit=int(r["debit_cents"] or 0); credit=int(r["credit_cents"] or 0)
            if r["type"] == "income":
                bal = credit - debit; total_income += bal; income.append((r, bal))
            elif r["type"] == "expense":
                bal = debit - credit; total_expense += bal; expenses.append((r, bal))
        return {"income": income, "expenses": expenses, "total_income": total_income, "total_expense": total_expense, "net_profit": total_income-total_expense}

    def balance_sheet(self) -> dict:
        rows = self.trial_balance()
        out = {"assets": [], "liabilities": [], "equity": [], "total_assets": 0, "total_liabilities": 0, "total_equity": 0}
        for r in rows:
            debit=int(r["debit_cents"] or 0); credit=int(r["credit_cents"] or 0); typ=r["type"]
            if typ == "asset":
                bal=debit-credit; out["assets"].append((r,bal)); out["total_assets"] += bal
            elif typ == "liability":
                bal=credit-debit; out["liabilities"].append((r,bal)); out["total_liabilities"] += bal
            elif typ == "equity":
                bal=credit-debit; out["equity"].append((r,bal)); out["total_equity"] += bal
        return out

    def account_balance(self, code: str, start: str | None = None, end: str | None = None, normal: str = "debit") -> int:
        account_id = self.account_id(code)
        clause, params = self._date_clause(start, end, prefix="e")
        row = self.conn.execute(f"""
            SELECT COALESCE(SUM(CASE WHEN l.side='debit' THEN l.amount_cents ELSE 0 END),0) AS debit_cents,
                   COALESCE(SUM(CASE WHEN l.side='credit' THEN l.amount_cents ELSE 0 END),0) AS credit_cents
            FROM journal_lines l JOIN journal_entries e ON e.id=l.entry_id
            WHERE l.account_id=? {clause}
        """, [account_id]+params).fetchone()
        debit=int(row["debit_cents"] or 0); credit=int(row["credit_cents"] or 0)
        return debit-credit if normal == "debit" else credit-debit

    def gst_summary(self, start: str | None = None, end: str | None = None) -> dict:
        collected = self.account_balance("2200", start, end, normal="credit")
        paid = self.account_balance("1300", start, end, normal="debit")
        return {"gst_collected_cents": collected, "gst_paid_cents": paid, "net_gst_payable_cents": collected - paid}

    def get_business_profile(self) -> dict:
        row = self.conn.execute("SELECT * FROM business_profile WHERE id=1").fetchone()
        return dict(row) if row else {}

    def update_business_profile(self, **fields) -> dict:
        allowed = {"business_name","owner_name","registration_number","tax_number","currency","notes","default_tax_mode","gst_registered","bas_frequency","default_tax_code","financial_year_start"}
        updates=[]; params=[]
        for k,v in fields.items():
            if k not in allowed or v is None:
                continue
            if k == "gst_registered":
                v = 1 if str(v).lower() in ("1","true","yes","y","registered") else 0
            updates.append(f"{k}=?"); params.append(v)
        updates.append("updated_at=?"); params.append(now_iso())
        params.append(1)
        self.conn.execute(f"UPDATE business_profile SET {', '.join(updates)} WHERE id=?", params)
        self.conn.commit()
        return self.get_business_profile()

    def create_invoice(self, invoice_no: str, amount: str, description: str, customer: str = "", issue_date: str | None = None, due_date: str = "", tax_rate: str = "0.10", tax_mode: str = "inclusive", tax_code: str | None = None, income_account: str = "4000", ar_account: str = "1100", gst_account: str = "2200") -> int:
        if FEATURE_LEVEL < 4:
            raise LedgerError("Invoices require Sentinel Ledger v0.4.0 or later.")
        issue_date = validate_date(issue_date or today())
        if due_date: due_date = validate_date(due_date)
        self.ensure_contact("customer", customer)
        bps = self.tax_rate_for(tax_rate, tax_code if FEATURE_LEVEL >= 5 else None)
        subtotal,tax,total = split_tax(parse_money(amount), bps, tax_mode)
        lines=[JournalLine(ar_account,"debit",money_to_cents(total),"invoice receivable"), JournalLine(income_account,"credit",money_to_cents(subtotal),"invoice income",bps,money_to_cents(tax))]
        if money_to_cents(tax)>0:
            lines.append(JournalLine(gst_account,"credit",money_to_cents(tax),"tax collected",bps,money_to_cents(tax)))
        entry_id = self.add_journal_entry(issue_date, f"Invoice {invoice_no}: {description}", lines, "invoice", invoice_no, customer or None)
        try:
            cur=self.conn.execute("INSERT INTO invoices(invoice_no,customer_name,issue_date,due_date,description,subtotal_cents,tax_cents,total_cents,tax_rate_bps,tax_mode,status,journal_entry_id,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)", (invoice_no.strip(), customer.strip(), issue_date, due_date, description.strip(), money_to_cents(subtotal), money_to_cents(tax), money_to_cents(total), bps, tax_mode, "unpaid", entry_id, now_iso()))
            self.conn.commit(); return int(cur.lastrowid)
        except sqlite3.IntegrityError as exc:
            raise LedgerError(f"Invoice number already exists: {invoice_no}") from exc

    def pay_invoice(self, invoice_no: str, amount: str | None = None, payment_date: str | None = None, receive_account: str = "1010") -> int:
        row = self.conn.execute("SELECT * FROM invoices WHERE invoice_no=?", (invoice_no,)).fetchone()
        if not row:
            raise LedgerError(f"Unknown invoice: {invoice_no}")
        if row["status"] == "paid":
            raise LedgerError(f"Invoice already paid: {invoice_no}")
        cents = int(row["total_cents"] if amount is None else money_to_cents(amount))
        entry_id = self.add_journal_entry(payment_date or today(), f"Payment received for invoice {invoice_no}", [JournalLine(receive_account,"debit",cents,"invoice payment"), JournalLine("1100","credit",cents,"reduce receivable")], "invoice_payment", invoice_no, row["customer_name"] or None)
        self.conn.execute("UPDATE invoices SET status='paid', paid_entry_id=? WHERE invoice_no=?", (entry_id, invoice_no))
        self.conn.commit(); return entry_id

    def create_bill(self, bill_no: str, amount: str, description: str, supplier: str = "", bill_date: str | None = None, due_date: str = "", tax_rate: str = "0.10", tax_mode: str = "inclusive", tax_code: str | None = None, expense_account: str = "5000", ap_account: str = "2000", gst_account: str = "1300") -> int:
        if FEATURE_LEVEL < 4:
            raise LedgerError("Bills require Sentinel Ledger v0.4.0 or later.")
        bill_date = validate_date(bill_date or today())
        if due_date: due_date = validate_date(due_date)
        self.ensure_contact("supplier", supplier)
        bps = self.tax_rate_for(tax_rate, tax_code if FEATURE_LEVEL >= 5 else None)
        subtotal,tax,total = split_tax(parse_money(amount), bps, tax_mode)
        lines=[JournalLine(expense_account,"debit",money_to_cents(subtotal),"supplier bill expense",bps,money_to_cents(tax))]
        if money_to_cents(tax)>0:
            lines.append(JournalLine(gst_account,"debit",money_to_cents(tax),"tax paid",bps,money_to_cents(tax)))
        lines.append(JournalLine(ap_account,"credit",money_to_cents(total),"bill payable"))
        entry_id = self.add_journal_entry(bill_date, f"Bill {bill_no}: {description}", lines, "bill", bill_no, supplier or None)
        try:
            cur=self.conn.execute("INSERT INTO bills(bill_no,supplier_name,bill_date,due_date,description,subtotal_cents,tax_cents,total_cents,tax_rate_bps,tax_mode,status,journal_entry_id,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)", (bill_no.strip(), supplier.strip(), bill_date, due_date, description.strip(), money_to_cents(subtotal), money_to_cents(tax), money_to_cents(total), bps, tax_mode, "unpaid", entry_id, now_iso()))
            self.conn.commit(); return int(cur.lastrowid)
        except sqlite3.IntegrityError as exc:
            raise LedgerError(f"Bill number already exists: {bill_no}") from exc

    def pay_bill(self, bill_no: str, amount: str | None = None, payment_date: str | None = None, pay_account: str = "1010") -> int:
        row = self.conn.execute("SELECT * FROM bills WHERE bill_no=?", (bill_no,)).fetchone()
        if not row:
            raise LedgerError(f"Unknown bill: {bill_no}")
        if row["status"] == "paid":
            raise LedgerError(f"Bill already paid: {bill_no}")
        cents = int(row["total_cents"] if amount is None else money_to_cents(amount))
        entry_id = self.add_journal_entry(payment_date or today(), f"Payment made for bill {bill_no}", [JournalLine("2000","debit",cents,"reduce payable"), JournalLine(pay_account,"credit",cents,"bill payment")], "bill_payment", bill_no, row["supplier_name"] or None)
        self.conn.execute("UPDATE bills SET status='paid', paid_entry_id=? WHERE bill_no=?", (entry_id, bill_no))
        self.conn.commit(); return entry_id

    def list_invoices(self) -> list[sqlite3.Row]:
        return list(self.conn.execute("SELECT invoice_no,issue_date,due_date,customer_name,description,total_cents,status FROM invoices ORDER BY issue_date DESC,id DESC"))

    def list_bills(self) -> list[sqlite3.Row]:
        return list(self.conn.execute("SELECT bill_no,bill_date,due_date,supplier_name,description,total_cents,status FROM bills ORDER BY bill_date DESC,id DESC"))

    def list_tax_codes(self) -> list[sqlite3.Row]:
        return list(self.conn.execute("SELECT code,name,rate_bps,treatment,is_active FROM tax_codes ORDER BY code"))

    def gst_status(self) -> dict:
        profile = self.get_business_profile()
        codes = [dict(r) for r in self.list_tax_codes()]
        issues = []
        ready = True
        if not profile.get("business_name"):
            issues.append("Business name has not been set. Run the setup wizard before accountant handoff."); ready = False
        if bool(profile.get("gst_registered", 1)) and not profile.get("tax_number"):
            issues.append("GST registered mode is enabled, but the tax/GST number field is blank. Add it if your accountant expects it on handoff records.")
        if not codes:
            issues.append("No tax codes are available. Re-run init or add tax codes before tax review."); ready = False
        default_code = str(profile.get("default_tax_code") or "GST").upper()
        if default_code and default_code not in {str(c.get("code", "")).upper() for c in codes}:
            issues.append(f"Default tax code {default_code} is not in the active tax-code list."); ready = False
        return {
            "ok": ready,
            "business_name": profile.get("business_name", ""),
            "gst_registered": bool(profile.get("gst_registered", 1)),
            "bas_frequency": profile.get("bas_frequency", "quarterly"),
            "default_tax_mode": profile.get("default_tax_mode", "inclusive"),
            "default_tax_code": default_code,
            "tax_number_set": bool(profile.get("tax_number")),
            "tax_codes": codes,
            "issues": issues,
            "human_readable": True,
            "checked_at": now_iso(),
        }

    def add_tax_code(self, code: str, name: str, rate: str, treatment: str = "taxable") -> None:
        if FEATURE_LEVEL < 5:
            raise LedgerError("Tax code editing requires Sentinel Ledger v0.6.3 or later.")
        bps = parse_rate_bps(rate)
        self.conn.execute("INSERT INTO tax_codes(code,name,rate_bps,treatment,is_active,created_at) VALUES(?,?,?,?,1,?) ON CONFLICT(code) DO UPDATE SET name=excluded.name,rate_bps=excluded.rate_bps,treatment=excluded.treatment,is_active=1", (code.strip().upper(), name.strip(), bps, treatment.strip(), now_iso()))
        self.conn.commit()

    def bas_worksheet(self, start: str | None = None, end: str | None = None) -> dict:
        if FEATURE_LEVEL < 5:
            raise LedgerError("BAS worksheet requires Sentinel Ledger v0.6.3 or later.")
        gst = self.gst_summary(start, end)
        pl = self.profit_loss(start, end)
        profile = self.get_business_profile()
        return {
            "period_start": start or "",
            "period_end": end or "",
            "business_name": profile.get("business_name", ""),
            "gst_registered": bool(profile.get("gst_registered", 1)),
            "bas_frequency": profile.get("bas_frequency", "quarterly"),
            "gst_collected_cents": gst["gst_collected_cents"],
            "gst_paid_cents": gst["gst_paid_cents"],
            "net_gst_payable_cents": gst["net_gst_payable_cents"],
            "gross_income_cents": pl["total_income"],
            "gross_expense_cents": pl["total_expense"],
            "notes": "Preparation worksheet only. Review records before lodgement or accountant handoff.",
        }

    def accountant_bas_report_payload(self, start: str | None = None, end: str | None = None, include_suggested_deductions: bool = False) -> dict:
        start = parse_iso_date_or_blank(start)
        end = parse_iso_date_or_blank(end)
        bas = self.bas_worksheet(start or None, end or None)
        profile = self.get_business_profile()
        where = []
        params: list[str] = []
        if start:
            start = validate_date(start); where.append("e.entry_date >= ?"); params.append(start)
        if end:
            end = validate_date(end); where.append("e.entry_date <= ?"); params.append(end)
        entry_clause = "WHERE " + " AND ".join(where) if where else ""
        entries = [dict(r) for r in self.conn.execute(f"""
            SELECT e.id,e.entry_date,e.description,e.source_type,e.source_ref,
                   COALESCE(SUM(CASE WHEN l.side='debit' THEN l.amount_cents ELSE 0 END),0) AS debit_cents,
                   COALESCE(SUM(CASE WHEN l.side='credit' THEN l.amount_cents ELSE 0 END),0) AS credit_cents
            FROM journal_entries e LEFT JOIN journal_lines l ON l.entry_id=e.id
            {entry_clause}
            GROUP BY e.id ORDER BY e.entry_date,e.id
        """, tuple(params))]
        doc_where = []
        doc_params: list[str] = []
        if start:
            start = validate_date(start); doc_where.append("(e.entry_date IS NULL OR e.entry_date >= ?)"); doc_params.append(start)
        if end:
            end = validate_date(end); doc_where.append("(e.entry_date IS NULL OR e.entry_date <= ?)"); doc_params.append(end)
        doc_clause = "WHERE " + " AND ".join(doc_where) if doc_where else ""
        docs = [dict(r) for r in self.conn.execute(f"""
            SELECT d.id,d.entry_id,d.path,d.sha256,d.note,d.created_at,e.entry_date,e.source_type,e.source_ref,e.description
            FROM document_refs d LEFT JOIN journal_entries e ON e.id=d.entry_id
            {doc_clause}
            ORDER BY e.entry_date,d.created_at,d.id
        """, tuple(doc_params))]
        source_counts: dict[str, int] = {}
        for entry in entries:
            source = entry.get("source_type") or "unknown"
            source_counts[source] = source_counts.get(source, 0) + 1
        payload = {
            "app": APP_NAME,
            "version": VERSION,
            "report_type": "accountant_bas_handoff",
            "created_at": now_iso(),
            "period_start": start,
            "period_end": end,
            "business_profile": profile,
            "bas_worksheet": bas,
            "record_counts": {"transactions": len(entries), "documents": len(docs), "by_source_type": source_counts},
            "transactions": entries,
            "documents": docs,
            "disclaimer": "Accountant handoff report only. Review records, receipts, tax codes, GST registration, and private-use apportionment before lodging or claiming.",
        }
        if include_suggested_deductions:
            payload["suggested_deductions"] = deduction_guide_payload()
        return payload

    def write_accountant_bas_report(self, start: str | None = None, end: str | None = None, out_dir: Path | None = None, include_suggested_deductions: bool = False) -> dict:
        payload = self.accountant_bas_report_payload(start, end, include_suggested_deductions)
        start_label = payload["period_start"] or "all-start"
        end_label = payload["period_end"] or "all-end"
        stamp = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
        out_base = prepare_private_dir(Path(out_dir).expanduser() if out_dir else accountant_reports_dir())
        out_dir_final = out_base / f"BAS_Accountant_Handoff_{safe_slug(start_label)}_to_{safe_slug(end_label)}_{stamp}"
        out_dir_final = prepare_private_dir(out_dir_final)
        txt_path = out_dir_final / "BAS_Accountant_Handoff_Report.txt"
        json_path = out_dir_final / "BAS_Accountant_Handoff_Report.json"
        tx_csv = out_dir_final / "transactions.csv"
        docs_csv = out_dir_final / "receipts_documents_index.csv"
        manifest_path = out_dir_final / "handoff_manifest.json"
        suggested_path = out_dir_final / "suggested_deductions_checklist.txt"
        safe_write_text_file(txt_path, format_accountant_bas_report(payload), mode=0o600)
        safe_write_text_file(json_path, json.dumps(payload, indent=2), mode=0o600)
        tx_fields = ["id","entry_date","description","source_type","source_ref","debit_cents","credit_cents"]
        safe_write_csv_file(tx_csv, payload["transactions"], tx_fields)
        doc_fields = ["id","entry_id","entry_date","source_type","source_ref","description","path","sha256","note","created_at"]
        safe_write_csv_file(docs_csv, payload["documents"], doc_fields)
        files = [txt_path, json_path, tx_csv, docs_csv]
        if payload.get("suggested_deductions"):
            safe_write_text_file(suggested_path, format_deductions_guide(), mode=0o600)
            files.append(suggested_path)
        manifest = {
            "app": APP_NAME,
            "version": VERSION,
            "report_type": payload["report_type"],
            "created_at": now_iso(),
            "period_start": payload["period_start"],
            "period_end": payload["period_end"],
            "files": [{"name": f.name, "path": str(f), "sha256": sha256_file(f), "size_bytes": f.stat().st_size} for f in files],
        }
        safe_write_text_file(manifest_path, json.dumps(manifest, indent=2), mode=0o600)
        files.append(manifest_path)
        self.add_document_ref(None, str(txt_path), note="Accountant BAS handoff report", commit=False)
        self.record_aegis_metadata("accountant_bas_report", txt_path, {"period_start": payload["period_start"], "period_end": payload["period_end"], "folder": str(out_dir_final), "manifest": str(manifest_path), "file_count": len(files)})
        self.log_recovery_event("accountant_bas_report_exported", "ok", f"Created accountant BAS handoff report at {out_dir_final}", {"period_start": payload["period_start"], "period_end": payload["period_end"], "folder": str(out_dir_final)})
        self.conn.commit()
        return {"ok": True, "folder": str(out_dir_final), "report_path": str(txt_path), "manifest_path": str(manifest_path), "files": [str(f) for f in files], "created_at": now_iso()}

    def invoice_safety_check(self) -> dict:
        profile = self.get_business_profile()
        issues = []
        if not profile.get("business_name"):
            issues.append("Business name is blank.")
        if not profile.get("currency"):
            issues.append("Currency is blank.")
        if not bool(profile.get("gst_registered", 1)):
            issues.append("GST registered mode is off; do not label invoices as tax invoices.")
        if bool(profile.get("gst_registered", 1)) and not profile.get("tax_number"):
            issues.append("GST registered mode is on but tax/GST number is blank.")
        return {"ok": not issues, "issues": issues, "checked_at": now_iso(), "profile": profile}

    def health(self) -> dict:
        self.init()
        integrity = self.integrity_check()
        profile = self.get_business_profile()
        return {
            "app": APP_NAME,
            "app_id": APP_ID,
            "program_id": PROGRAM_ID,
            "version": VERSION,
            "launch_repair_patch": True,
            "wrapper_entrypoints_fixed": True,
            "desktop_exec_uses_gui_wrapper": True,
            "schema_version": SCHEMA_VERSION,
            "feature_level": FEATURE_LEVEL,
            "local_only": LOCAL_ONLY,
            "db_path": str(self.db_path),
            "db_exists": self.db_path.exists(),
            "db_sha256": sha256_file(self.db_path) if self.db_path.exists() else "",
            "accounts": self.conn.execute("SELECT COUNT(*) AS c FROM accounts").fetchone()["c"],
            "contacts": self.conn.execute("SELECT COUNT(*) AS c FROM contacts").fetchone()["c"],
            "journal_entries": self.conn.execute("SELECT COUNT(*) AS c FROM journal_entries").fetchone()["c"],
            "document_refs": self.conn.execute("SELECT COUNT(*) AS c FROM document_refs").fetchone()["c"],
            "invoices": self.conn.execute("SELECT COUNT(*) AS c FROM invoices").fetchone()["c"],
            "bills": self.conn.execute("SELECT COUNT(*) AS c FROM bills").fetchone()["c"],
            "tax_codes": self.conn.execute("SELECT COUNT(*) AS c FROM tax_codes").fetchone()["c"],
            "backup_count": self.conn.execute("SELECT COUNT(*) AS c FROM backup_registry").fetchone()["c"],
            "last_backup": self.backup_status().get("last_backup"),
            "migration_status": self.migration_status(),
            "recovery_features": RECOVERY_FEATURES,
            "phase7_release_candidate_enabled": True,
            "phase8_v1_user_ready_baseline_enabled": True,
            "stable_release": True,
            "v1_stable_lock": True,
            "v1_user_ready_baseline": True,
            "feature_freeze_rc": True,
            "date_display_format": DISPLAY_DATE_FORMAT,
            "internal_date_storage": "YYYY-MM-DD",
            "ddmmyyyy_display_dates": True,
            "menu_visibility": {"main_launcher_visible": True, "aegis_internal_launchers_hidden": True},
            "unbalanced_entries": len(self.unbalanced_entries()),
            "integrity_ok": bool(integrity["ok"]),
            "latest_period_lock": self.latest_period_lock(),
            "business_profile_ready": bool(profile.get("business_name")),
            "gst_registered": bool(profile.get("gst_registered", 1)),
            "aegis_ready": True,
            "theme": THEME_NAME,
            "desktop_launcher_capable": True,
            "desktop_launcher_command": "sentinel-ledger install-desktop-launcher",
            "report_text_theme": "dark-aegis-gold-cyan",
            "all_gui_fields_dark_themed": True,
            "dashboard_split_sales_expenses": True,
            "receipt_print_prompt": True,
            "record_search_enabled": True,
            "readable_reports_enabled": True,
            "report_copy_paste_enabled": True,
            "manual_tab_enabled": True,
            "deductions_guide_enabled": True,
            "tax_bas_worksheet_readable": True,
            "accountant_bas_report_export_enabled": True,
            "accountant_report_period_select_enabled": True,
            "aegis_vault_metadata_index_enabled": True,
            "separate_taxes_tab_enabled": True,
            "reports_tab_non_editable": True,
            "tax_bas_controls_separated_from_reports": True,
            "accountant_handoff_report_from_reports_tab": True,
            "first_run_setup_wizard_enabled": True,
            "multi_ledger_profiles_enabled": True,
            "ledger_profiles": list_ledger_profiles(),
            "readable_gst_status_enabled": True,
            "readable_invoice_safety_enabled": True,
            "accountant_suggested_deductions_appendix_enabled": True,
            "ledger_menu_profile_switcher_enabled": True,
            "blank_setup_wizard_from_menu_enabled": True,
            "dashboard_compact_totals_header_enabled": True,
            "quick_sale_compact_form_enabled": True,
            "quick_sale_receipt_preview_enabled": True,
            "receipt_template_designer_enabled": True,
            "inventory_bridge_contract_enabled": True,
            "inventory_bridge_status": self.inventory_bridge_status(write_contract=False),
            "aegis_integration_encoded": True,
            "aegis_capability_manifest": self.aegis_capability_manifest(),
            "aegis_metadata_status": self.aegis_metadata_status(),
            "phase1_stability_print_workflow_qa_enabled": True,
            "receipt_sequence_numbers_enabled": True,
            "receipt_print_open_flow_enabled": True,
            "ledger_switch_safety_enabled": True,
            "dashboard_summary_command_enabled": True,
            "aegis_readiness_command_enabled": True,
            "phase2_security_hardening_enabled": True,
            "phase3_data_integrity_recovery_hardening_enabled": True,
            "deep_integrity_check_enabled": True,
            "human_recovery_report_enabled": True,
            "restore_wizard_status_enabled": True,
            "backup_schedule_status_enabled": True,
            "pre_upgrade_backup_status_enabled": True,
            "read_only_repair_diagnostics_enabled": True,
            "reports_buttons_two_row_symmetry_enabled": True,
            "quick_expense_compact_form_enabled": True,
            "quick_expense_review_preview_enabled": True,
            "phase4_business_workflow_completion_enabled": True,
            "payment_methods_enabled": True,
            "payment_methods_count": self.conn.execute("SELECT COUNT(*) AS c FROM payment_methods WHERE is_active=1").fetchone()["c"],
            "contact_detail_search_update_enabled": True,
            "recurring_entries_enabled": True,
            "recurring_templates_count": self.conn.execute("SELECT COUNT(*) AS c FROM recurring_templates WHERE is_active=1").fetchone()["c"],
            "document_linking_enabled": True,
            "business_workflow_status_enabled": True,
            "business_workflow_status": self.business_workflow_status(),
            "phase5_import_export_accountant_handoff_enabled": True,
            "accountant_handoff_wizard_enabled": True,
            "full_archive_export_enabled": True,
            "portable_restore_pack_enabled": True,
            "csv_import_review_queue_enabled": True,
            "customer_supplier_tabs_enabled": True,
            "contact_order_expense_memory_enabled": True,
            "customers_registered": self.conn.execute("SELECT COUNT(*) AS c FROM contacts WHERE type IN ('customer','both')").fetchone()["c"],
            "suppliers_registered": self.conn.execute("SELECT COUNT(*) AS c FROM contacts WHERE type IN ('supplier','both')").fetchone()["c"],
            "import_export_status": self.import_export_status(),

            "phase6_aegis_sentinel_command_integration_enabled": True,
            "sentinel_command_status_contract_enabled": True,
            "aegis_report_index_enabled": True,
            "aegis_risk_flags_enabled": True,
            "aegis_permission_map_enabled": True,
            "sentinel_command_registration_enabled": True,
            "final_aegis_command_contract_enabled": True,
            "sentinel_command_status": self.sentinel_command_status(write_contract=False),
            "aegis_report_index": self.aegis_report_index(),
            "aegis_risk_flags": self.aegis_risk_flags(),
            "ledger_lock_available": True,
            "strict_file_permissions_enabled": True,
            "security_audit_log_enabled": True,
            "password_protected_backup_container_enabled": True,
            "redaction_mode_available": True,
            "no_network_self_check_enabled": True,
            "aegis_read_only_permission_boundary_encoded": True,
            "quick_view_two_line_header_enabled": True,
            "security_status": self.security_status(),
            "recovery_report_available": True,
            "deep_integrity_status": self.deep_integrity_check(),
            "backup_schedule_status": self.backup_schedule_status(),
            "pre_upgrade_backup_status": self.pre_upgrade_backup_status(),
            "business_workflow_status": self.business_workflow_status(),
            "hotkeys_enabled": True,
            "hotkey_profile": HOTKEY_STATUS["profile"],
            "hotkeys": HOTKEYS,
            "safe_mode": "local-sqlite-no-network-no-telemetry",
            "v1_path": "0.9.0 Phase 6 AEGIS/Sentinel Command integration complete; next 0.9.5 release candidate",
        }

    def export_csv(self, out_dir: Path) -> list[Path]:
        out_dir = prepare_private_dir(out_dir)
        tables = BACKUP_TABLES
        exported=[]
        for table in tables:
            rows=list(self.conn.execute(f"SELECT * FROM {table}"))
            path=out_dir/f"{table}.csv"
            safe_write_csv_file(path, rows)
            exported.append(path)
        manifest={"app": APP_NAME,"version": VERSION,"created_at": now_iso(),"db_path": str(self.db_path),"files": [p.name for p in exported]}
        mpath=out_dir/"export_manifest.json"
        safe_write_text_file(mpath, json.dumps(manifest, indent=2), mode=0o600)
        exported.append(mpath)
        return exported

    def backup_json(self, out_path: Path | None = None) -> Path:
        if out_path is None:
            out_path = vault_dir() / f"sentinel_ledger_backup_{_dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        out_path=out_path.expanduser(); ensure_output_parent(out_path); ensure_not_symlink(out_path, "backup output")
        tables=BACKUP_TABLES
        payload={"app": APP_NAME,"app_id": APP_ID,"program_id": PROGRAM_ID,"version": VERSION,"created_at": now_iso(),"tables": {}}
        for table in tables:
            payload["tables"][table]=[dict(r) for r in self.conn.execute(f"SELECT * FROM {table}")]
        safe_write_text_file(out_path, json.dumps(payload, indent=2), mode=0o600)
        check = self.restore_check(out_path)
        self.register_backup(out_path, "json_backup", verified=bool(check.get("ok")))
        self.record_aegis_metadata("json_backup", out_path, {"restore_check_ok": bool(check.get("ok")), "backup_type": "json_backup"})
        self.log_recovery_event("backup_json", "ok" if check.get("ok") else "warning", f"Created JSON backup at {out_path}", {"restore_check": check})
        self.conn.commit()
        return out_path

    def backup_status(self) -> dict:
        rows = list(self.conn.execute("SELECT * FROM backup_registry ORDER BY created_at DESC, id DESC LIMIT 10")) if self.table_exists("backup_registry") else []
        last = dict(rows[0]) if rows else None
        risks = []
        if not last:
            risks.append("no_backup_recorded")
        else:
            try:
                created = _dt.datetime.fromisoformat(last["created_at"])
                if (_dt.datetime.now() - created).days >= 7:
                    risks.append("backup_older_than_7_days")
            except Exception:
                risks.append("backup_timestamp_unreadable")
            if last and not Path(last["path"]).expanduser().exists():
                risks.append("last_backup_file_missing")
        return {
            "ok": not risks,
            "backup_count": self.conn.execute("SELECT COUNT(*) AS c FROM backup_registry").fetchone()["c"] if self.table_exists("backup_registry") else 0,
            "last_backup": last,
            "recent_backups": [dict(r) for r in rows],
            "risks": risks,
            "checked_at": now_iso(),
        }

    def migration_status(self) -> dict:
        rows = list(self.conn.execute("SELECT * FROM schema_migrations ORDER BY id DESC")) if self.table_exists("schema_migrations") else []
        return {
            "schema_version": SCHEMA_VERSION,
            "stored_schema_version": self.current_schema_version_raw(),
            "app_version": VERSION,
            "migrations": [dict(r) for r in rows],
            "pre_migration_backup": str(self._pre_migration_backup) if self._pre_migration_backup else "",
            "checked_at": now_iso(),
        }

    def restore_check(self, backup_path: Path) -> dict:
        p = Path(backup_path).expanduser()
        issues = []
        payload = None
        if not p.exists():
            return {"ok": False, "path": str(p), "issues": ["backup_file_missing"], "checked_at": now_iso()}
        try:
            ensure_not_symlink(p, "restore backup input")
            require_file_size(p, MAX_BACKUP_JSON_BYTES, "JSON backup")
            payload = json.loads(p.read_text(encoding="utf-8"))
        except LedgerError as exc:
            return {"ok": False, "path": str(p), "issues": [str(exc)], "checked_at": now_iso()}
        except Exception as exc:
            return {"ok": False, "path": str(p), "issues": [f"invalid_json: {exc}"], "checked_at": now_iso()}
        if not isinstance(payload, dict):
            issues.append("backup_root_not_object")
        elif payload.get("app_id") != APP_ID:
            issues.append("app_id_mismatch")
        if not isinstance(payload, dict) or "tables" not in payload or not isinstance(payload.get("tables"), dict):
            issues.append("missing_tables_payload")
        else:
            for table in ("accounts", "journal_entries", "journal_lines", "meta"):
                if table not in payload["tables"]:
                    issues.append(f"missing_table:{table}")
            issues.extend(validate_restore_table_columns(self, payload))
        try:
            digest = sha256_file(p)
            size = p.stat().st_size
        except Exception:
            digest = ""
            size = 0
        return {
            "ok": not issues,
            "path": str(p),
            "sha256": digest,
            "size_bytes": size,
            "backup_version": payload.get("version") if isinstance(payload, dict) else "",
            "created_at": payload.get("created_at") if isinstance(payload, dict) else "",
            "tables": sorted(list(payload.get("tables", {}).keys())) if isinstance(payload, dict) else [],
            "issues": issues,
            "checked_at": now_iso(),
        }

    def restore_json_to_new_db(self, backup_path: Path, out_db: Path, force: bool = False) -> Path:
        check = self.restore_check(backup_path)
        if not check.get("ok"):
            raise LedgerError("Backup failed restore-check: " + ", ".join(check.get("issues", [])))
        source = Path(backup_path).expanduser()
        ensure_not_symlink(source, "restore backup input")
        out_db = Path(out_db).expanduser()
        ensure_output_parent(out_db)
        ensure_not_symlink(out_db, "restore output database")
        if out_db.suffix.lower() not in {".db", ".sqlite", ".sqlite3"}:
            raise LedgerError("Restore output must end with .db, .sqlite, or .sqlite3 to avoid overwriting unrelated files.")
        try:
            if out_db.resolve() == self.db_path.resolve():
                raise LedgerError("Refusing to restore over the active ledger database. Restore to a new path first.")
        except FileNotFoundError:
            pass
        if out_db.exists() and not force:
            raise LedgerError(f"Output database already exists: {out_db}. Use --force to overwrite.")
        payload = json.loads(source.read_text(encoding="utf-8"))
        temp_db = out_db.with_name(f".{out_db.name}.restore-tmp-{os.getpid()}")
        if temp_db.exists() or temp_db.is_symlink():
            raise LedgerError(f"Temporary restore database already exists: {temp_db}")
        target = LedgerDB(temp_db)
        try:
            target.init()
            column_issues = validate_restore_table_columns(target, payload)
            if column_issues:
                raise LedgerError("Backup failed strict column validation: " + ", ".join(column_issues))
            target.conn.execute("PRAGMA foreign_keys = OFF")
            with target.conn:
                for table in reversed(BACKUP_TABLES):
                    if target.table_exists(table):
                        target.conn.execute(f"DELETE FROM {table}")
                for table in BACKUP_TABLES:
                    rows = payload.get("tables", {}).get(table, [])
                    if not rows or not target.table_exists(table):
                        continue
                    allowed = {r["name"] for r in target.conn.execute(f"PRAGMA table_info({table})")}
                    cols = [c for c in rows[0].keys() if c in allowed]
                    placeholders = ",".join(["?"] * len(cols))
                    col_sql = ",".join([f'"{c}"' for c in cols])
                    for row in rows:
                        extra = set(row) - allowed
                        if extra:
                            raise LedgerError(f"Unexpected columns in restore table {table}: {sorted(extra)[:5]}")
                        target.conn.execute(f"INSERT INTO {table}({col_sql}) VALUES({placeholders})", [row.get(c) for c in cols])
            target.conn.execute("PRAGMA foreign_keys = ON")
            fk = [dict(r) for r in target.conn.execute("PRAGMA foreign_key_check")]
            if fk:
                raise LedgerError(f"Restored database failed foreign key check: {fk[:3]}")
            target.set_meta("restored_from", str(source))
            target.set_meta("restored_at", now_iso())
            target.register_backup(source, "restored_from_json", verified=True)
            target.log_recovery_event("restore_json", "ok", f"Restored backup into {out_db}", {"source": str(source)})
            target.conn.commit()
        finally:
            target.close()
        if out_db.exists():
            if not force:
                raise LedgerError(f"Output database already exists: {out_db}. Use --force to overwrite.")
            out_db.unlink()
        os.replace(temp_db, out_db)
        try:
            out_db.chmod(0o600)
        except OSError:
            pass
        self.log_recovery_event("restore_json_to_new_db", "ok", f"Restore check/output completed for {out_db}", {"source": str(source), "out_db": str(out_db)})
        self.conn.commit()
        return out_db

    def recovery_status(self) -> dict:
        integrity = self.integrity_check()
        deep = self.deep_integrity_check()
        backup = self.backup_status()
        migration = self.migration_status()
        schedule = self.backup_schedule_status()
        pre_upgrade = self.pre_upgrade_backup_status()
        risks = []
        if not integrity.get("ok"):
            risks.append("ledger_integrity_failed")
        if not deep.get("ok"):
            risks.extend(["deep_integrity_" + str(x) for x in deep.get("issues", [])])
        risks.extend(backup.get("risks", []))
        if schedule.get("backup_due"):
            risks.append("backup_due")
        if self.current_schema_version_raw() != SCHEMA_VERSION:
            risks.append("schema_version_mismatch")
        return {
            "ok": not risks,
            "app": APP_NAME,
            "version": VERSION,
            "schema_version": SCHEMA_VERSION,
            "db_path": str(self.db_path),
            "sqlite_pragmas": {
                "foreign_keys": self.conn.execute("PRAGMA foreign_keys").fetchone()[0],
                "journal_mode": self.conn.execute("PRAGMA journal_mode").fetchone()[0],
                "synchronous": self.conn.execute("PRAGMA synchronous").fetchone()[0],
            },
            "integrity": integrity,
            "deep_integrity": deep,
            "backup": backup,
            "backup_schedule": schedule,
            "pre_upgrade_backup": pre_upgrade,
            "migration": migration,
            "restore_wizard": self.restore_wizard_status(),
            "risks": risks,
            "aegis_read_only": True,
            "phase3_data_integrity_recovery_hardening": True,
            "checked_at": now_iso(),
        }

    def aegis_safe_summary(self) -> dict:
        pl = self.profit_loss()
        gst = self.gst_summary()
        invoices_unpaid = self.conn.execute("SELECT COUNT(*) AS c FROM invoices WHERE status!='paid'").fetchone()["c"]
        bills_unpaid = self.conn.execute("SELECT COUNT(*) AS c FROM bills WHERE status!='paid'").fetchone()["c"]
        recovery = self.recovery_status()
        return {
            "app": APP_NAME,
            "program_id": PROGRAM_ID,
            "version": VERSION,
            "mode": "aegis-safe-read-only-summary",
            "integrity_ok": recovery["integrity"].get("ok"),
            "backup_ok": recovery["backup"].get("ok"),
            "net_profit_cents": pl["net_profit"],
            "net_gst_payable_cents": gst["net_gst_payable_cents"],
            "open_invoices": invoices_unpaid,
            "unpaid_bills": bills_unpaid,
            "risk_flags": recovery["risks"],
            "mutation_allowed": False,
            "checked_at": now_iso(),
        }


    def add_recurring_template(self, name: str, entry_type: str, amount: str, description: str, contact_name: str = "", account_code: str = "", bank_account: str = "1010", tax_code: str = "GST", tax_rate: str = "0.10", tax_mode: str = "inclusive", frequency: str = "monthly", next_date: str | None = None, notes: str = "") -> int:
        entry_type = str(entry_type or "").strip().lower()
        if entry_type not in ("sale", "expense"):
            raise LedgerError("Recurring entry type must be sale or expense.")
        if not str(name or "").strip():
            raise LedgerError("Recurring template name is required.")
        if not str(description or "").strip():
            raise LedgerError("Recurring template description is required.")
        cents = money_to_cents(amount)
        if cents <= 0:
            raise LedgerError("Recurring amount must be greater than zero.")
        acct = account_code.strip() if account_code else ("4000" if entry_type == "sale" else "5000")
        self.account_row(acct); self.account_row(bank_account)
        nd = parse_iso_date_or_blank(next_date) or today()
        cur = self.conn.execute(
            "INSERT INTO recurring_templates(name,entry_type,amount_cents,description,contact_name,account_code,bank_account,tax_code,tax_rate_bps,tax_mode,frequency,next_date,is_active,notes,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (name.strip(), entry_type, cents, description.strip(), contact_name.strip(), acct, bank_account.strip(), (tax_code or "GST").strip().upper(), parse_rate_bps(tax_rate), tax_mode, frequency.strip() or "monthly", nd, 1, notes.strip(), now_iso()),
        )
        self.conn.commit()
        return int(cur.lastrowid)

    def list_recurring_templates(self, active_only: bool = True) -> list[sqlite3.Row]:
        sql = "SELECT id,name,entry_type,amount_cents,description,contact_name,account_code,bank_account,tax_code,tax_rate_bps,tax_mode,frequency,next_date,is_active,last_posted_at FROM recurring_templates"
        if active_only:
            sql += " WHERE is_active=1"
        sql += " ORDER BY next_date,id"
        return list(self.conn.execute(sql))

    def post_recurring_template(self, template_id: int, post_date: str | None = None, advance: bool = True) -> dict:
        row = self.conn.execute("SELECT * FROM recurring_templates WHERE id=?", (int(template_id),)).fetchone()
        if not row:
            raise LedgerError(f"Unknown recurring template id: {template_id}")
        if not int(row["is_active"]):
            raise LedgerError("Recurring template is inactive.")
        d = parse_iso_date_or_blank(post_date) or row["next_date"] or today()
        amount = str(cents_to_money(row["amount_cents"]))
        tax_rate = str(Decimal(int(row["tax_rate_bps"])) / Decimal(10000))
        if row["entry_type"] == "sale":
            entry_id = self.quick_sale(amount, row["description"], d, tax_rate, row["tax_mode"], row["bank_account"], row["account_code"] or "4000", "2200", row["contact_name"] or None, f"REC-{row['id']}-{d}", None, row["tax_code"])
        else:
            entry_id = self.quick_expense(amount, row["description"], d, tax_rate, row["tax_mode"], row["bank_account"], row["account_code"] or "5000", "1300", row["contact_name"] or None, f"REC-{row['id']}-{d}", None, row["tax_code"])
        next_date = row["next_date"] or d
        try:
            base = _dt.date.fromisoformat(next_date)
            freq = str(row["frequency"] or "monthly").lower()
            if freq == "weekly":
                nxt = base + _dt.timedelta(days=7)
            elif freq == "fortnightly":
                nxt = base + _dt.timedelta(days=14)
            elif freq == "quarterly":
                nxt = base + _dt.timedelta(days=91)
            elif freq == "yearly":
                nxt = base.replace(year=base.year + 1)
            else:
                nxt = base + _dt.timedelta(days=31)
                nxt = nxt.replace(day=min(base.day, 28))
            if advance:
                self.conn.execute("UPDATE recurring_templates SET next_date=?, last_posted_at=? WHERE id=?", (nxt.isoformat(), now_iso(), int(template_id)))
                self.conn.commit()
        except Exception:
            self.conn.execute("UPDATE recurring_templates SET last_posted_at=? WHERE id=?", (now_iso(), int(template_id)))
            self.conn.commit()
        return {"ok": True, "template_id": int(template_id), "entry_id": entry_id, "posted_date": d, "advanced": bool(advance)}

    def business_workflow_status(self) -> dict:
        contacts = self.conn.execute("SELECT COUNT(*) AS c FROM contacts").fetchone()["c"]
        customers = self.conn.execute("SELECT COUNT(*) AS c FROM contacts WHERE type IN ('customer','both')").fetchone()["c"]
        suppliers = self.conn.execute("SELECT COUNT(*) AS c FROM contacts WHERE type IN ('supplier','both')").fetchone()["c"]
        payment_methods = self.conn.execute("SELECT COUNT(*) AS c FROM payment_methods WHERE is_active=1").fetchone()["c"]
        recurring = self.conn.execute("SELECT COUNT(*) AS c FROM recurring_templates WHERE is_active=1").fetchone()["c"]
        documents = self.conn.execute("SELECT COUNT(*) AS c FROM document_refs").fetchone()["c"]
        invoices_unpaid = self.conn.execute("SELECT COUNT(*) AS c FROM invoices WHERE status!='paid'").fetchone()["c"]
        bills_unpaid = self.conn.execute("SELECT COUNT(*) AS c FROM bills WHERE status!='paid'").fetchone()["c"]
        issues=[]
        if contacts == 0: issues.append("no_contacts_created")
        if payment_methods == 0: issues.append("no_active_payment_methods")
        if documents == 0: issues.append("no_receipts_or_documents_linked")
        return {
            "app": APP_NAME, "program_id": PROGRAM_ID, "version": VERSION,
            "phase": "Phase 4 Business Workflow Completion",
            "ok": not issues,
            "contacts_total": contacts, "customers": customers, "suppliers": suppliers,
            "payment_methods_active": payment_methods, "recurring_templates_active": recurring,
            "open_invoices": invoices_unpaid, "unpaid_bills": bills_unpaid, "document_refs": documents,
            "features": {"payment_methods": True, "contact_detail_search_update": True, "recurring_entries": True, "document_linking": True, "business_workflow_status": True},
            "issues": issues, "checked_at": now_iso(),
        }



    def dashboard_summary(self) -> dict:
        today_s = today()
        month_start = today_s[:8] + "01"
        def total_for(source_type: str, start: str | None = None, end: str | None = None) -> int:
            rows = self.recent_transactions(100000, start=start, end=end, source_type=source_type)
            return sum(int(r["total_cents"] or 0) for r in rows)
        gst_all = self.gst_summary()
        backup = self.backup_status()
        profile = self.get_business_profile()
        invoices_unpaid = self.conn.execute("SELECT COUNT(*) AS c FROM invoices WHERE status!='paid'").fetchone()["c"]
        bills_unpaid = self.conn.execute("SELECT COUNT(*) AS c FROM bills WHERE status!='paid'").fetchone()["c"]
        return {
            "app": APP_NAME,
            "program_id": PROGRAM_ID,
            "version": VERSION,
            "active_ledger_name": profile.get("business_name") or self.db_path.stem,
            "db_path": str(self.db_path),
            "today": today_s,
            "month_start": month_start,
            "today_sales_cents": total_for("quick_sale", today_s, today_s),
            "today_expenses_cents": total_for("quick_expense", today_s, today_s),
            "month_sales_cents": total_for("quick_sale", month_start, today_s),
            "month_expenses_cents": total_for("quick_expense", month_start, today_s),
            "estimated_gst_collected_cents": gst_all.get("gst_collected_cents", 0),
            "estimated_gst_paid_cents": gst_all.get("gst_paid_cents", 0),
            "estimated_gst_net_payable_cents": gst_all.get("net_gst_payable_cents", 0),
            "unpaid_invoices": invoices_unpaid,
            "unpaid_bills": bills_unpaid,
            "last_backup": backup.get("last_backup"),
            "backup_ok": backup.get("ok"),
            "integrity_ok": self.integrity_check().get("ok"),
            "checked_at": now_iso(),
        }

    def aegis_readiness(self) -> dict:
        health = self.health()
        backup = self.backup_status()
        metadata = self.aegis_metadata_status()
        inventory = self.inventory_bridge_status(write_contract=False)
        gst = self.gst_status()
        risks = []
        if not health.get("integrity_ok"):
            risks.append("ledger_integrity_check_failed")
        if not backup.get("ok"):
            risks.extend(backup.get("risks", []))
        if not metadata.get("ok"):
            risks.append("aegis_metadata_index_missing_or_empty")
        if not gst.get("ok"):
            risks.extend(["gst_profile_" + str(x).lower().replace(" ", "_")[:48] for x in gst.get("issues", [])])
        if not health.get("business_profile_ready"):
            risks.append("business_profile_incomplete")
        return {
            "app": APP_NAME,
            "program_id": PROGRAM_ID,
            "version": VERSION,
            "phase": "v0.8.5 Phase 5 import/export and accountant handoff polish",
            "ok": not risks,
            "readiness_profile": "phase5-import-export-accountant-handoff-polish",
            "ledger_health": {"integrity_ok": health.get("integrity_ok"), "db_path": health.get("db_path"), "schema_version": health.get("schema_version")},
            "backup_status": backup,
            "metadata_status": metadata,
            "inventory_bridge_status": inventory,
            "receipt_template_status": {"configured": True, "template": self.receipt_template(), "sequence_numbers": True, "print_open_flow": True},
            "tax_setup_status": {"ok": gst.get("ok"), "gst_registered": gst.get("gst_registered"), "bas_frequency": gst.get("bas_frequency"), "issues": gst.get("issues", [])},
            "security_status": self.security_status(),
            "recovery_report_available": True,
            "deep_integrity_status": self.deep_integrity_check(),
            "backup_schedule_status": self.backup_schedule_status(),
            "pre_upgrade_backup_status": self.pre_upgrade_backup_status(),
            "import_export_status": self.import_export_status(),
            "accountant_handoff_wizard_status": self.accountant_handoff_wizard_status(),
            "known_warnings": risks,
            "mutation_allowed_without_user_approval": False,
            "checked_at": now_iso(),
        }



    def aegis_permission_map(self) -> dict:
        """Machine-readable AEGIS/Sentinel Command permission contract.

        The boundary is intentionally conservative: AEGIS may inspect and report,
        but financial mutations require explicit user action/approval.
        """
        read_only = [
            "health", "aegis-summary", "aegis-readiness", "aegis-capabilities",
            "sentinel-command-status", "aegis-report-index", "aegis-risk-flags",
            "dashboard-summary", "business-workflow-status", "import-export-status",
            "aegis-metadata-status", "migration-status", "recovery-status", "backup-status",
            "integrity-check", "deep-integrity-check", "security-status", "no-network-check",
            "inventory-bridge-status", "gst-status --json", "invoice-safety-check --json",
            "customers", "suppliers", "payment-methods", "recurring --json",
        ]
        user_approved_write = [
            "quick-sale", "quick-expense", "journal", "reverse-entry", "opening-balance",
            "create-invoice", "pay-invoice", "create-bill", "pay-bill", "add-customer",
            "add-supplier", "update-contact", "add-payment-method", "add-recurring",
            "post-recurring", "approve-import", "link-document", "backup-json", "encrypted-backup",
            "full-archive-export", "portable-restore-pack", "accountant-bas-report", "restore-json",
            "set-active-ledger", "create-ledger", "business-profile", "setup-wizard",
        ]
        prohibited = [
            "silent_financial_record_mutation", "silent_record_deletion", "silent_tax_lodgement",
            "silent_banking_action", "silent_inventory_stock_mutation", "cloud_sync_without_user_approval",
            "network_access_without_user_approval",
        ]
        return {
            "app": APP_NAME,
            "app_id": APP_ID,
            "program_id": PROGRAM_ID,
            "version": VERSION,
            "contract_version": "aegis-ledger-permissions-v1",
            "local_only": LOCAL_ONLY,
            "default_mode": "read-only-inspection",
            "aegis_may_read": True,
            "aegis_may_warn": True,
            "aegis_may_summarize": True,
            "aegis_may_index_metadata": True,
            "aegis_may_mutate_financial_records_without_user_approval": False,
            "aegis_may_delete_records_without_user_approval": False,
            "aegis_may_lodge_tax_or_bas": False,
            "read_only_commands": read_only,
            "user_approved_write_commands": user_approved_write,
            "prohibited_actions": prohibited,
            "checked_at": now_iso(),
        }

    def aegis_report_index(self) -> dict:
        reports = [
            {"id":"trial_balance", "label":"Trial Balance", "command":"sentinel-ledger report trial-balance", "tab":"Reports", "format":"text", "mutates_ledger":False},
            {"id":"profit_loss", "label":"Profit / Loss", "command":"sentinel-ledger report profit-loss", "tab":"Reports", "format":"text", "mutates_ledger":False},
            {"id":"balance_sheet", "label":"Balance Sheet", "command":"sentinel-ledger report balance-sheet", "tab":"Reports", "format":"text", "mutates_ledger":False},
            {"id":"gst_summary", "label":"GST / Tax Summary", "command":"sentinel-ledger report gst-summary", "tab":"Taxes", "format":"text", "mutates_ledger":False},
            {"id":"bas_worksheet", "label":"Tax/BAS Worksheet", "command":"sentinel-ledger report bas-worksheet --start YYYY-MM-DD --end YYYY-MM-DD", "tab":"Taxes", "format":"text", "mutates_ledger":False},
            {"id":"accountant_handoff", "label":"Accountant Handoff Pack", "command":"sentinel-ledger accountant-bas-report --start YYYY-MM-DD --end YYYY-MM-DD --include-suggested-deductions", "tab":"Reports", "format":"folder", "mutates_ledger":False, "writes_export_files":True},
            {"id":"recovery_report", "label":"Recovery Report", "command":"sentinel-ledger recovery-report", "tab":"Reports", "format":"text", "mutates_ledger":False},
            {"id":"security_status", "label":"Security Status", "command":"sentinel-ledger security-status", "tab":"Settings/Help", "format":"json", "mutates_ledger":False},
            {"id":"aegis_readiness", "label":"AEGIS Readiness", "command":"sentinel-ledger aegis-readiness", "tab":"Help", "format":"json", "mutates_ledger":False},
            {"id":"sentinel_command_status", "label":"Sentinel Command Status", "command":"sentinel-ledger sentinel-command-status", "tab":"Help", "format":"json", "mutates_ledger":False},
        ]
        return {
            "app": APP_NAME,
            "app_id": APP_ID,
            "program_id": PROGRAM_ID,
            "version": VERSION,
            "report_index_version": "sentinel-ledger-report-index-v1",
            "reports": reports,
            "reports_are_read_only": True,
            "accountant_handoff_available": True,
            "checked_at": now_iso(),
        }

    def aegis_risk_flags(self) -> dict:
        flags = []
        def add(code, severity, message, source, action=""):
            flags.append({"code": code, "severity": severity, "message": message, "source": source, "recommended_action": action})
        integrity = self.integrity_check()
        deep = self.deep_integrity_check()
        backup = self.backup_status()
        security = self.security_status()
        gst = self.gst_status()
        workflow = self.business_workflow_status()
        import_export = self.import_export_status()
        metadata = self.aegis_metadata_status()
        if not integrity.get("ok"):
            add("ledger_integrity_failed", "critical", "Ledger balance/integrity check failed.", "integrity-check", "Run deep-integrity-check and recovery-report before entering more records.")
        if not deep.get("ok"):
            add("deep_integrity_warnings", "high", "Deep integrity check found warnings or issues.", "deep-integrity-check", "Review recovery-report and diagnose-repair output.")
        if not backup.get("ok"):
            add("backup_attention_required", "medium", "No recent verified backup is registered.", "backup-status", "Create a JSON backup, full archive, or protected backup.")
        if not security.get("ledger_lock_enabled"):
            add("ledger_lock_disabled", "medium", "Optional local ledger lock is not enabled.", "security-status", "Enable the ledger lock if this machine is shared or mobile.")
        if not metadata.get("ok"):
            add("aegis_metadata_empty", "low", "AEGIS metadata index is missing or empty.", "aegis-metadata-status", "Generate a receipt, backup, accountant handoff, or run sentinel-command-register.")
        if not gst.get("ok"):
            for issue in gst.get("issues", []):
                add("tax_profile_review", "medium", f"Tax/GST profile review: {issue}", "gst-status", "Open Taxes tab and confirm business tax setup.")
        if workflow.get("issues"):
            for issue in workflow.get("issues", []):
                add("business_workflow_review", "low", f"Business workflow review: {issue}", "business-workflow-status", "Add payment methods, contacts, or receipt links as relevant.")
        if import_export.get("pending_import_rows", 0):
            add("import_queue_pending", "medium", f"{import_export.get('pending_import_rows')} imported row(s) are awaiting review.", "import-queue", "Review and approve or skip queued imported rows.")
        return {
            "app": APP_NAME,
            "app_id": APP_ID,
            "program_id": PROGRAM_ID,
            "version": VERSION,
            "risk_profile_version": "sentinel-ledger-risk-flags-v1",
            "ok": not any(f["severity"] in {"critical", "high"} for f in flags),
            "flags_count": len(flags),
            "flags": flags,
            "mutation_performed": False,
            "checked_at": now_iso(),
        }

    def sentinel_command_status(self, write_contract: bool = True) -> dict:
        profile = self.get_business_profile()
        risk = self.aegis_risk_flags()
        permission = self.aegis_permission_map()
        report_index = self.aegis_report_index()
        payload = {
            "app": APP_NAME,
            "app_id": APP_ID,
            "program_id": PROGRAM_ID,
            "program_name": "Sentinel Ledger",
            "version": VERSION,
            "phase": "v1.0.1 Redteam Security Cleanup Hotfix",
            "status_profile": "sentinel-command-program-status-v1",
            "local_only": LOCAL_ONLY,
            "no_cloud": True,
            "no_telemetry": True,
            "visible_launcher": "sentinel-ledger.desktop",
            "gui_command": "sentinel-ledger-gui",
            "main_cli_command": "sentinel-ledger",
            "internal_launchers_hidden": True,
            "active_ledger": {"business_name": profile.get("business_name") or "", "db_path": str(self.db_path), "schema_version": SCHEMA_VERSION},
            "storage": {"vault_dir": str(vault_dir()), "metadata_dir": str(aegis_metadata_dir()), "sentinel_command_dir": str(sentinel_command_dir())},
            "health_ok": bool(self.integrity_check().get("ok")),
            "risk_flags": risk,
            "permission_boundary": {"default_mode": permission["default_mode"], "mutation_without_user_approval": False, "read_only_commands_count": len(permission["read_only_commands"])},
            "report_index": report_index,
            "sentinel_command_actions": {
                "inspect_status": "sentinel-ledger sentinel-command-status",
                "inspect_risks": "sentinel-ledger aegis-risk-flags",
                "inspect_reports": "sentinel-ledger aegis-report-index",
                "inspect_permissions": "sentinel-ledger aegis-permission-map",
                "register_contract": "sentinel-ledger sentinel-command-register",
            },
            "inventory_bridge": self.inventory_bridge_status(write_contract=False),
            "aegis_metadata_status": self.aegis_metadata_status(),
            "checked_at": now_iso(),
        }
        if write_contract:
            out_dir = prepare_private_dir(sentinel_command_dir())
            status_path = sentinel_command_status_path()
            safe_write_text_file(status_path, json.dumps(payload, indent=2), mode=0o600)
            self.record_aegis_metadata("sentinel_command_status", status_path, {"program_id": PROGRAM_ID, "contract_version": payload["status_profile"]})
            payload["status_path"] = str(status_path)
        return payload

    def sentinel_command_register(self) -> dict:
        out_dir = prepare_private_dir(sentinel_command_dir())
        contract = {
            "app": APP_NAME,
            "app_id": APP_ID,
            "program_id": PROGRAM_ID,
            "version": VERSION,
            "contract_type": "sentinel-command-program-contract-v1",
            "created_at": now_iso(),
            "status_command": "sentinel-ledger sentinel-command-status",
            "readiness_command": "sentinel-ledger aegis-readiness",
            "risk_flags_command": "sentinel-ledger aegis-risk-flags",
            "report_index_command": "sentinel-ledger aegis-report-index",
            "permission_map_command": "sentinel-ledger aegis-permission-map",
            "capabilities_command": "sentinel-ledger aegis-capabilities",
            "permissions": self.aegis_permission_map(),
            "reports": self.aegis_report_index(),
            "capabilities": self.aegis_capability_manifest(),
            "safety_boundary": "AEGIS/Sentinel Command may inspect, summarize, warn, and index metadata. Financial record mutation requires explicit user approval.",
        }
        path = sentinel_command_manifest_path()
        safe_write_text_file(path, json.dumps(contract, indent=2), mode=0o600)
        status = self.sentinel_command_status(write_contract=True)
        self.record_aegis_metadata("sentinel_command_contract", path, {"program_id": PROGRAM_ID, "contract_type": contract["contract_type"]})
        self.conn.commit()
        return {"ok": True, "contract_path": str(path), "status_path": status.get("status_path"), "registered_at": now_iso(), "mutation_performed": "metadata_registration_only"}

    def aegis_capability_manifest(self) -> dict:
        permission = self.aegis_permission_map()
        return {
            "app": APP_NAME,
            "app_id": APP_ID,
            "program_id": PROGRAM_ID,
            "version": VERSION,
            "capability_manifest_version": "sentinel-ledger-aegis-capabilities-v1",
            "phase": "v1.0.1 Redteam Security Cleanup Hotfix",
            "local_only": LOCAL_ONLY,
            "aegis_integration_encoded": True,
            "sentinel_command_integration_encoded": True,
            "mutation_allowed_without_user_approval": False,
            "visible_launcher": "sentinel-ledger.desktop",
            "internal_launchers_hidden": True,
            "read_only_commands": permission["read_only_commands"],
            "user_approved_write_commands": permission["user_approved_write_commands"],
            "report_index_command": "sentinel-ledger aegis-report-index",
            "risk_flags_command": "sentinel-ledger aegis-risk-flags",
            "sentinel_command_status_command": "sentinel-ledger sentinel-command-status",
            "sentinel_command_register_command": "sentinel-ledger sentinel-command-register",
            "metadata_paths": {"aegis_metadata_dir": str(aegis_metadata_dir()), "sentinel_command_dir": str(sentinel_command_dir())},
            "capabilities": [
                "health", "read_only_summary", "readiness", "risk_flags", "report_index",
                "permission_map", "sentinel_command_status", "sentinel_command_registration",
                "backup_status", "recovery_status", "deep_integrity", "security_status",
                "customer_supplier_registry", "contact_order_expense_memory", "full_archive_export",
                "portable_restore_pack", "csv_import_review_queue", "accountant_handoff_wizard",
                "inventory_bridge_contract",
            ],
            "security_boundary": "AEGIS may inspect, summarize, warn, and register metadata. Ledger writes require explicit user approval.",
            "checked_at": now_iso(),
        }

    def aegis_readiness(self) -> dict:
        health = self.health()
        backup = self.backup_status()
        metadata = self.aegis_metadata_status()
        inventory = self.inventory_bridge_status(write_contract=False)
        gst = self.gst_status()
        risk = self.aegis_risk_flags()
        sentinel_status = self.sentinel_command_status(write_contract=False)
        risks = [f["code"] for f in risk.get("flags", []) if f.get("severity") in {"critical", "high", "medium"}]
        return {
            "app": APP_NAME,
            "program_id": PROGRAM_ID,
            "version": VERSION,
            "phase": "v1.0.1 Redteam Security Cleanup Hotfix",
            "ok": not any(f.get("severity") in {"critical", "high"} for f in risk.get("flags", [])),
            "readiness_profile": "v1-redteam-security-cleanup-hotfix",
            "ledger_health": {"integrity_ok": health.get("integrity_ok"), "db_path": health.get("db_path"), "schema_version": health.get("schema_version")},
            "backup_status": backup,
            "metadata_status": metadata,
            "inventory_bridge_status": inventory,
            "sentinel_command_status": {"status_profile": sentinel_status.get("status_profile"), "local_only": sentinel_status.get("local_only"), "visible_launcher": sentinel_status.get("visible_launcher"), "internal_launchers_hidden": sentinel_status.get("internal_launchers_hidden")},
            "report_index_status": {"enabled": True, "reports_count": len(self.aegis_report_index().get("reports", []))},
            "permission_boundary": self.aegis_permission_map(),
            "risk_flags": risk,
            "receipt_template_status": {"configured": True, "template": self.receipt_template(), "sequence_numbers": True, "print_open_flow": True},
            "tax_setup_status": {"ok": gst.get("ok"), "gst_registered": gst.get("gst_registered"), "bas_frequency": gst.get("bas_frequency"), "issues": gst.get("issues", [])},
            "security_status": self.security_status(),
            "business_workflow_status": self.business_workflow_status(),
            "import_export_status": self.import_export_status(),
            "known_warnings": risks,
            "mutation_allowed_without_user_approval": False,
            "checked_at": now_iso(),
        }


    def release_candidate_status(self) -> dict:
        """Phase 7 release-candidate readiness summary for v1.0 preparation."""
        health = self.health()
        deep = self.deep_integrity_check()
        recovery = self.recovery_status()
        security = self.security_status()
        no_network = self.no_network_check()
        aegis = self.aegis_readiness()
        import_export = self.import_export_status()
        issues = []
        if not health.get("integrity_ok"):
            issues.append("basic_integrity_not_ok")
        if not deep.get("ok"):
            issues.append("deep_integrity_not_ok")
        if not recovery.get("ok"):
            issues.append("recovery_status_has_warnings")
        if not security.get("ok"):
            issues.append("security_status_has_warnings")
        if not no_network.get("ok"):
            issues.append("no_network_check_failed")
        if import_export.get("pending_import_rows", 0):
            issues.append("pending_import_rows_need_review")
        return {
            "app": APP_NAME,
            "app_id": APP_ID,
            "program_id": PROGRAM_ID,
            "version": VERSION,
            "phase": "v1.0.1 Redteam Security Cleanup Hotfix",
            "release_candidate": False,
            "stable_release": True,
            "v1_stable_lock": True,
            "feature_freeze": True,
            "date_display_format": DISPLAY_DATE_FORMAT,
            "internal_date_storage": "YYYY-MM-DD",
            "ok": not issues,
            "issues": issues,
            "checks": {
                "health_ok": bool(health.get("integrity_ok")),
                "basic_integrity_ok": health.get("integrity_ok"),
                "deep_integrity_ok": deep.get("ok"),
                "recovery_ok": recovery.get("ok"),
                "security_ok": security.get("ok"),
                "no_network_ok": no_network.get("ok"),
                "aegis_ready": aegis.get("ok"),
                "import_export_ready": not bool(import_export.get("pending_import_rows", 0)),
                "main_launcher_visible": health.get("menu_visibility", {}).get("main_launcher_visible"),
                "internal_launchers_hidden": health.get("menu_visibility", {}).get("aegis_internal_launchers_hidden"),
            },
            "v1_baseline_scope": [
                "multi-ledger business bookkeeping",
                "setup wizard and business profile",
                "receipts, receipt designer, customer/supplier registry",
                "GST/BAS preparation and accountant handoff",
                "backup, recovery, security, and AEGIS/Sentinel Command inspection",
            ],
            "mutation_allowed_without_user_approval": False,
            "checked_at": now_iso(),
        }


    def stable_baseline_status(self) -> dict:
        """v1.0.1 redteam security cleanup baseline status for Program 107."""
        rc = self.release_candidate_status()
        health = self.health()
        readiness = self.aegis_readiness()
        security = self.security_status()
        deep = self.deep_integrity_check()
        raw_issues = list(rc.get("issues", []))
        warning_only = {"recovery_status_has_warnings", "pending_import_rows_need_review"}
        warnings = [i for i in raw_issues if i in warning_only]
        issues = [i for i in raw_issues if i not in warning_only]
        return {
            "app": APP_NAME,
            "app_id": APP_ID,
            "program_id": PROGRAM_ID,
            "version": VERSION,
            "phase": "v1.0.1 Redteam Security Cleanup Hotfix",
            "stable_release": True,
            "v1_stable_lock": True,
            "local_only": LOCAL_ONLY,
            "schema_version": SCHEMA_VERSION,
            "schema_contract": "stable-v1-compatible; internal dates stored YYYY-MM-DD; user-facing dates display DD/MM/YYYY",
            "ok": not issues and bool(health.get("integrity_ok")) and bool(deep.get("ok")) and bool(readiness.get("ok")),
            "issues": issues,
            "warnings": warnings,
            "checks": {
                "health_ok": bool(health.get("integrity_ok")),
                "deep_integrity_ok": bool(deep.get("ok")),
                "security_ok": bool(security.get("ok")),
                "aegis_ready": bool(readiness.get("ok")),
                "main_launcher_visible": health.get("menu_visibility", {}).get("main_launcher_visible"),
                "internal_launchers_hidden": health.get("menu_visibility", {}).get("aegis_internal_launchers_hidden"),
                "ddmmyyyy_display_dates": health.get("ddmmyyyy_display_dates"),
                "mutation_allowed_without_user_approval": False,
            },
            "v1_scope": {
                "business_ledgers": "multi-ledger local SQLite",
                "daily_workflows": ["quick sale", "quick expense", "invoices", "supplier bills", "customers", "suppliers", "recurring templates"],
                "tax_prep": ["GST/BAS worksheet", "GST status", "invoice safety", "deductions checklist", "accountant handoff"],
                "recovery": ["JSON backup", "protected backup", "portable restore pack", "deep integrity", "recovery report"],
                "security": ["optional local ledger lock", "private file permissions", "security audit", "no-network check", "redaction status"],
                "aegis": ["health", "readiness", "metadata", "risk flags", "permission map", "Sentinel Command contract"],
            },
            "known_limitations": [
                "GST/BAS tools prepare records for accountant review; they do not lodge tax/BAS.",
                "Inventory bridge is a contract only until Program 115 Sentinel Inventory is built.",
                "Recurring templates require explicit posting and do not post silently.",
            ],
            "checked_at": now_iso(),
        }

    def import_export_status(self) -> dict:
        pending = self.conn.execute("SELECT COUNT(*) AS c FROM import_queue WHERE status='pending'").fetchone()["c"]
        posted = self.conn.execute("SELECT COUNT(*) AS c FROM import_queue WHERE status='posted'").fetchone()["c"]
        return {
            "app": APP_NAME,
            "version": VERSION,
            "phase": "0.8.5-import-export-accountant-handoff-polish",
            "full_archive_export_enabled": True,
            "portable_restore_pack_enabled": True,
            "csv_import_review_queue_enabled": True,
            "imports_never_post_silently": True,
            "pending_import_rows": pending,
            "posted_import_rows": posted,
            "customers_registered": self.conn.execute("SELECT COUNT(*) AS c FROM contacts WHERE type IN ('customer','both')").fetchone()["c"],
            "suppliers_registered": self.conn.execute("SELECT COUNT(*) AS c FROM contacts WHERE type IN ('supplier','both')").fetchone()["c"],
            "checked_at": now_iso(),
        }

    def full_archive_export(self, out_dir: Path | None = None) -> dict:
        stamp = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
        base = prepare_private_dir(Path(out_dir).expanduser() if out_dir else vault_dir() / "Archive_Exports")
        folder = prepare_private_dir(base / f"sentinel_ledger_full_archive_{stamp}")
        csv_dir = folder / "csv_tables"
        exported_csv = self.export_csv(csv_dir)
        json_backup = self.backup_json(folder / "sentinel_ledger_backup.json")
        if self.db_path.exists():
            write_sqlite_snapshot(self.conn, folder / "sentinel_ledger.sqlite")
        manifest = {
            "app": APP_NAME,
            "version": VERSION,
            "archive_type": "full_ledger_archive",
            "created_at": now_iso(),
            "db_path": str(self.db_path),
            "json_backup": str(json_backup),
            "csv_files": [str(p) for p in exported_csv],
            "restore_note": "Use restore-json with sentinel_ledger_backup.json for a clean database restore, or keep the sqlite copy as a snapshot.",
            "files": [],
        }
        for fp in sorted(folder.rglob("*")):
            if fp.is_file() and fp.name != "archive_manifest.json":
                manifest["files"].append({"path": str(fp.relative_to(folder)), "sha256": sha256_file(fp), "size_bytes": fp.stat().st_size})
        mpath = folder / "archive_manifest.json"
        safe_write_text_file(mpath, json.dumps(manifest, indent=2), mode=0o600)
        zip_path = Path(shutil.make_archive(str(folder), "zip", root_dir=folder))
        self.register_backup(zip_path, "full_archive_export", verified=True)
        self.record_aegis_metadata("full_archive_export", zip_path, {"folder": str(folder), "manifest": str(mpath)})
        self.log_recovery_event("full_archive_export", "ok", f"Created full archive {zip_path}", {"folder": str(folder)})
        self.conn.commit()
        return {"ok": True, "folder": str(folder), "zip_path": str(zip_path), "manifest": str(mpath), "created_at": now_iso()}

    def portable_restore_pack(self, out_dir: Path | None = None) -> dict:
        stamp = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
        base = prepare_private_dir(Path(out_dir).expanduser() if out_dir else vault_dir() / "Portable_Restore_Packs")
        folder = prepare_private_dir(base / f"sentinel_ledger_restore_pack_{stamp}")
        backup = self.backup_json(folder / "restore_backup.json")
        readme = folder / "RESTORE_README.txt"
        safe_write_text_file(readme,
            "SENTINEL LEDGER PORTABLE RESTORE PACK\n"
            "======================================\n\n"
            "This folder contains a restore-focused JSON backup.\n\n"
            "Restore command example:\n"
            "  sentinel-ledger restore-json restore_backup.json restored-ledger.sqlite\n\n"
            "Do not overwrite an existing business ledger unless you have made a separate backup first.\n",
            mode=0o600,
        )
        manifest = {"app": APP_NAME, "version": VERSION, "created_at": now_iso(), "backup": str(backup), "readme": str(readme), "backup_sha256": sha256_file(backup)}
        safe_write_text_file(folder / "restore_manifest.json", json.dumps(manifest, indent=2), mode=0o600)
        zip_path = Path(shutil.make_archive(str(folder), "zip", root_dir=folder))
        self.register_backup(zip_path, "portable_restore_pack", verified=True)
        self.record_aegis_metadata("portable_restore_pack", zip_path, {"folder": str(folder)})
        self.conn.commit()
        return {"ok": True, "folder": str(folder), "zip_path": str(zip_path), "created_at": now_iso()}

    def import_csv_queue(self, csv_path: Path, import_type: str = "bank_csv") -> dict:
        path = Path(csv_path).expanduser()
        ensure_not_symlink(path, "CSV import input")
        if not path.exists():
            raise LedgerError(f"CSV file not found: {path}")
        if not path.is_file():
            raise LedgerError(f"CSV import path is not a regular file: {path}")
        require_file_size(path, MAX_IMPORT_CSV_BYTES, "CSV import")
        created = 0
        with path.open("r", newline="", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            if not reader.fieldnames:
                raise LedgerError("CSV file has no header row.")
            with self.conn:
                for row in reader:
                    if created >= MAX_IMPORT_CSV_ROWS:
                        raise LedgerError(f"CSV import row limit exceeded ({MAX_IMPORT_CSV_ROWS}). Split the file and import in reviewed batches.")
                    self.conn.execute(
                        "INSERT INTO import_queue(import_type,row_json,status,source_path,created_at,updated_at) VALUES(?,?,?,?,?,?)",
                        (import_type, json.dumps(row, ensure_ascii=False), "pending", str(path), now_iso(), now_iso()),
                    )
                    created += 1
        return {"ok": True, "source_path": str(path), "queued_rows": created, "status": "pending_review", "posted_automatically": False, "created_at": now_iso()}

    def list_import_queue(self, status: str = "pending", limit: int = 100) -> dict:
        params: list[object] = []
        clause = ""
        if status != "all":
            clause = "WHERE status=?"
            params.append(status)
        params.append(int(limit))
        rows = [dict(r) for r in self.conn.execute(f"SELECT * FROM import_queue {clause} ORDER BY id LIMIT ?", tuple(params))]
        for row in rows:
            try:
                row["row"] = json.loads(row.pop("row_json"))
            except Exception:
                row["row"] = {}
        return {"status_filter": status, "count": len(rows), "rows": rows, "checked_at": now_iso()}

    def approve_import_row(self, queue_id: int, entry_type: str, amount: str, description: str, entry_date: str | None = None, contact: str = "", account: str = "", tax_code: str = "GST") -> dict:
        row = self.conn.execute("SELECT * FROM import_queue WHERE id=?", (int(queue_id),)).fetchone()
        if not row:
            raise LedgerError(f"Unknown import queue row: {queue_id}")
        if row["status"] != "pending":
            raise LedgerError(f"Import queue row is not pending: {queue_id}")
        if entry_type == "sale":
            eid = self.quick_sale(amount, description, entry_date or today(), customer=contact or None, income_account=account or "4000", tax_code=tax_code, source_ref=f"IMPORT-{queue_id}")
        elif entry_type == "expense":
            eid = self.quick_expense(amount, description, entry_date or today(), supplier=contact or None, expense_account=account or "5000", tax_code=tax_code, source_ref=f"IMPORT-{queue_id}")
        else:
            raise LedgerError("entry_type must be sale or expense.")
        self.conn.execute("UPDATE import_queue SET status='posted',posted_entry_id=?,updated_at=? WHERE id=?", (eid, now_iso(), int(queue_id)))
        self.conn.commit()
        return {"ok": True, "queue_id": int(queue_id), "posted_entry_id": eid, "entry_type": entry_type, "posted_at": now_iso()}

    def accountant_handoff_wizard_status(self) -> dict:
        profile = self.get_business_profile()
        return {
            "ok": bool(profile.get("business_name")),
            "wizard_available": True,
            "period_select": True,
            "include_suggested_deductions_option": True,
            "includes_transactions_csv": True,
            "includes_receipts_documents_index": True,
            "includes_manifest_hashes": True,
            "recommended_action": "Use accountant-bas-report --start YYYY-MM-DD --end YYYY-MM-DD --include-suggested-deductions",
            "checked_at": now_iso(),
        }


def parse_journal_lines(spec: str) -> list[JournalLine]:
    lines=[]
    for item in spec.split(","):
        parts=item.split(":",3)
        if len(parts)<3:
            raise LedgerError("Line spec must be code:debit|credit:amount[:memo]")
        code,side,amount=parts[:3]; memo=parts[3] if len(parts)==4 else ""
        side=side.strip().lower()
        if side not in SIDES:
            raise LedgerError("Line side must be debit or credit.")
        lines.append(JournalLine(code.strip(), side, money_to_cents(amount.strip()), memo.strip()))
    return lines


def add_common_parsers(sub):
    sub.add_parser("init", help="Initialize database and default chart of accounts.")
    sub.add_parser("health", help="Print AEGIS-ready health JSON.")
    sub.add_parser("inventory-bridge-status", help="Print/write Sentinel Inventory bridge status contract JSON.")
    sub.add_parser("aegis-capabilities", help="Print AEGIS integration capability manifest JSON.")
    sub.add_parser("aegis-readiness", help="Print one clean AEGIS/Sentinel Command readiness summary JSON.")

    sub.add_parser("sentinel-command-status", help="Print/write Sentinel Command program status contract JSON.")
    sub.add_parser("sentinel-command-register", help="Register Sentinel Ledger metadata contract for Sentinel Command.")
    sub.add_parser("aegis-report-index", help="Print AEGIS/Sentinel Command report index JSON.")
    sub.add_parser("aegis-risk-flags", help="Print AEGIS/Sentinel Command risk flags JSON.")
    sub.add_parser("aegis-permission-map", help="Print AEGIS/Sentinel Command permission boundary JSON.")
    sub.add_parser("dashboard-summary", help="Print compact dashboard totals and workflow summary JSON.")
    sub.add_parser("hotkey-status", help="Print AEGIS-ready GUI hotkey status JSON.")
    sub.add_parser("integrity-check", help="Check ledger balancing, lock state, and basic data integrity.")
    sub.add_parser("deep-integrity-check", help="Run Phase 3 read-only deep data integrity checks JSON.")
    rr=sub.add_parser("recovery-report", help="Print a human-readable recovery and integrity report."); rr.add_argument("--json", action="store_true")
    sub.add_parser("restore-wizard-status", help="Print restore wizard/readiness status JSON.")
    sub.add_parser("backup-schedule-status", help="Print local backup reminder/schedule status JSON.")
    sub.add_parser("pre-upgrade-backup-status", help="Check whether a verified recent backup exists before upgrade.")
    sub.add_parser("diagnose-repair", help="Read-only repair diagnostics and suggested next actions JSON.")
    ac=sub.add_parser("add-account", help="Add an account."); ac.add_argument("code"); ac.add_argument("name"); ac.add_argument("type", choices=ACCOUNT_TYPES)
    ua=sub.add_parser("update-account", help="Rename, reclassify, activate, or deactivate an account."); ua.add_argument("code"); ua.add_argument("--name"); ua.add_argument("--type", choices=ACCOUNT_TYPES); ua.add_argument("--active", choices=("yes","no")); ua.add_argument("--notes")
    acc=sub.add_parser("accounts", help="List accounts."); acc.add_argument("--all", action="store_true")
    cc=sub.add_parser("add-contact", help="Add a customer/supplier contact."); cc.add_argument("type", choices=CONTACT_TYPES); cc.add_argument("name"); cc.add_argument("--email", default=""); cc.add_argument("--phone", default=""); cc.add_argument("--tax-id", default=""); cc.add_argument("--notes", default="")
    cust=sub.add_parser("add-customer", help="Register or update a customer contact for sales/order history."); cust.add_argument("name"); cust.add_argument("--email", default=""); cust.add_argument("--phone", default=""); cust.add_argument("--tax-id", default=""); cust.add_argument("--notes", default="")
    supp=sub.add_parser("add-supplier", help="Register or update a supplier contact for expense/bill history."); supp.add_argument("name"); supp.add_argument("--email", default=""); supp.add_argument("--phone", default=""); supp.add_argument("--tax-id", default=""); supp.add_argument("--notes", default="")
    sub.add_parser("contacts", help="List contacts.")
    sub.add_parser("customers", help="List registered customers with remembered sales/order totals.")
    sub.add_parser("suppliers", help="List registered suppliers with remembered expense/bill totals.")
    uc=sub.add_parser("update-contact", help="Update a customer/supplier contact."); uc.add_argument("contact_id", type=int); uc.add_argument("--type", choices=CONTACT_TYPES); uc.add_argument("--name"); uc.add_argument("--email"); uc.add_argument("--phone"); uc.add_argument("--tax-id"); uc.add_argument("--notes")
    cd=sub.add_parser("contact-detail", help="Show full customer/supplier contact detail."); cd.add_argument("contact_id", type=int); cd.add_argument("--json", action="store_true")
    cdh=sub.add_parser("customer-history", help="Show remembered sales/orders for a customer contact."); cdh.add_argument("contact_id", type=int); cdh.add_argument("--json", action="store_true")
    sdh=sub.add_parser("supplier-history", help="Show remembered expenses/bills for a supplier contact."); sdh.add_argument("contact_id", type=int); sdh.add_argument("--json", action="store_true")
    sc=sub.add_parser("search-contacts", help="Search customer/supplier contact records."); sc.add_argument("text"); sc.add_argument("--limit", type=int, default=100); sc.add_argument("--json", action="store_true")
    pm=sub.add_parser("payment-methods", help="List configured payment methods."); pm.add_argument("--all", action="store_true")
    apm=sub.add_parser("add-payment-method", help="Create or update a payment method."); apm.add_argument("name"); apm.add_argument("--type", default="other"); apm.add_argument("--clearing-account", default="1010"); apm.add_argument("--notes", default=""); apm.add_argument("--inactive", action="store_true")
    ar=sub.add_parser("add-recurring", help="Create a recurring sale/expense template."); ar.add_argument("name"); ar.add_argument("entry_type", choices=("sale","expense")); ar.add_argument("amount"); ar.add_argument("description"); ar.add_argument("--contact", default=""); ar.add_argument("--account", default=""); ar.add_argument("--bank-account", default="1010"); ar.add_argument("--tax-code", default="GST"); ar.add_argument("--tax-rate", default="0.10"); ar.add_argument("--tax-mode", choices=("inclusive","exclusive"), default="inclusive"); ar.add_argument("--frequency", default="monthly"); ar.add_argument("--next-date", default=None); ar.add_argument("--notes", default="")
    rec=sub.add_parser("recurring", help="List recurring templates."); rec.add_argument("--all", action="store_true"); rec.add_argument("--json", action="store_true")
    pr=sub.add_parser("post-recurring", help="Post one recurring template into the ledger."); pr.add_argument("template_id", type=int); pr.add_argument("--date", default=None); pr.add_argument("--no-advance", action="store_true")
    ld=sub.add_parser("link-document", help="Attach/index a receipt or document against a journal entry."); ld.add_argument("entry_id", type=int); ld.add_argument("path"); ld.add_argument("--note", default="")
    sub.add_parser("business-workflow-status", help="Print Phase 4 business workflow status JSON.")
    sub.add_parser("import-export-status", help="Print Phase 5 import/export and accountant handoff status JSON.")
    sub.add_parser("release-candidate-status", help="Print Phase 7 release-candidate readiness JSON.")
    sub.add_parser("stable-status", help="Print v1.0.1 stable/security-hotfix baseline status JSON.")
    sub.add_parser("accountant-handoff-wizard", help="Print accountant handoff wizard/readiness status JSON.")
    fa=sub.add_parser("full-archive-export", help="Export a full ledger archive ZIP with CSV tables, JSON backup, manifest, and hashes."); fa.add_argument("--out-dir")
    prp=sub.add_parser("portable-restore-pack", help="Create a portable restore pack ZIP for migration/recovery."); prp.add_argument("--out-dir")
    iq=sub.add_parser("import-csv-queue", help="Load CSV rows into a review queue without posting them."); iq.add_argument("csv_path"); iq.add_argument("--type", default="bank_csv")
    lq=sub.add_parser("import-queue", help="List queued imported rows awaiting approval."); lq.add_argument("--status", default="pending", choices=("pending","posted","skipped","all")); lq.add_argument("--limit", type=int, default=100); lq.add_argument("--json", action="store_true")
    aq=sub.add_parser("approve-import", help="Approve one import queue row and post it as a sale or expense."); aq.add_argument("queue_id", type=int); aq.add_argument("entry_type", choices=("sale","expense")); aq.add_argument("amount"); aq.add_argument("description"); aq.add_argument("--date", default=today()); aq.add_argument("--contact", default=""); aq.add_argument("--account", default=""); aq.add_argument("--tax-code", default="GST")
    sale=sub.add_parser("quick-sale", help="Record a balanced sale with optional tax split."); sale.add_argument("amount"); sale.add_argument("description"); sale.add_argument("--date", default=today()); sale.add_argument("--tax-rate", default="0.10"); sale.add_argument("--tax-mode", choices=("inclusive","exclusive"), default="inclusive"); sale.add_argument("--tax-code", default=None); sale.add_argument("--receive-account", default="1010"); sale.add_argument("--income-account", default="4000"); sale.add_argument("--gst-account", default="2200"); sale.add_argument("--customer", default=None); sale.add_argument("--source-ref", default=""); sale.add_argument("--document", default=None); sale.add_argument("--payment-method", default="")
    exp=sub.add_parser("quick-expense", help="Record a balanced expense with optional tax split."); exp.add_argument("amount"); exp.add_argument("description"); exp.add_argument("--date", default=today()); exp.add_argument("--tax-rate", default="0.10"); exp.add_argument("--tax-mode", choices=("inclusive","exclusive"), default="inclusive"); exp.add_argument("--tax-code", default=None); exp.add_argument("--pay-account", default="1010"); exp.add_argument("--expense-account", default="5000"); exp.add_argument("--gst-account", default="1300"); exp.add_argument("--supplier", default=None); exp.add_argument("--source-ref", default=""); exp.add_argument("--document", default=None); exp.add_argument("--payment-method", default="")
    je=sub.add_parser("journal", help="Record a manual balanced journal entry."); je.add_argument("description"); je.add_argument("--date", default=today()); je.add_argument("--lines", required=True); je.add_argument("--source-ref", default=""); je.add_argument("--memo", default=""); je.add_argument("--document", default=None)
    ob=sub.add_parser("opening-balance", help="Record an opening balance against Opening Balance Equity."); ob.add_argument("account_code"); ob.add_argument("amount"); ob.add_argument("--date", default=today()); ob.add_argument("--side", choices=SIDES); ob.add_argument("--equity-account", default="3200"); ob.add_argument("--memo", default="")
    rv=sub.add_parser("reverse-entry", help="Create a dated reversal entry instead of editing history."); rv.add_argument("entry_id", type=int); rv.add_argument("--date", default=today()); rv.add_argument("--reason", default="")
    vd=sub.add_parser("entry-detail", help="Show full journal entry detail."); vd.add_argument("entry_id", type=int); vd.add_argument("--json", action="store_true")
    lp=sub.add_parser("lock-period", help="Lock accounting periods through a date."); lp.add_argument("locked_through"); lp.add_argument("--reason", default="")
    tr=sub.add_parser("transactions", help="List transactions."); tr.add_argument("--limit", type=int, default=25); tr.add_argument("--start"); tr.add_argument("--end"); tr.add_argument("--source-type"); tr.add_argument("--text")
    sr=sub.add_parser("search-records", help="Search transactions and generated receipt/document references."); sr.add_argument("text"); sr.add_argument("--limit", type=int, default=100); sr.add_argument("--json", action="store_true")
    rcpt=sub.add_parser("receipt", help="Generate a local text receipt for an entry."); rcpt.add_argument("entry_id", type=int); rcpt.add_argument("--out-dir"); rcpt.add_argument("--json", action="store_true"); rcpt.add_argument("--status", action="store_true", help="Also print print/open capability status for the generated receipt.")
    rep=sub.add_parser("report", help="Generate a report."); rep.add_argument("type", choices=("trial-balance","profit-loss","balance-sheet","gst-summary","bas-worksheet")); rep.add_argument("--start"); rep.add_argument("--end"); rep.add_argument("--json", action="store_true")
    abr=sub.add_parser("accountant-bas-report", help="Save an accountant-readable BAS handoff report for a selected period."); abr.add_argument("--start"); abr.add_argument("--end"); abr.add_argument("--out-dir"); abr.add_argument("--include-suggested-deductions", action="store_true"); abr.add_argument("--json", action="store_true")
    ex=sub.add_parser("export-csv", help="Export tables to CSV files."); ex.add_argument("out_dir")
    bk=sub.add_parser("backup-json", help="Create a JSON backup and register it for recovery status."); bk.add_argument("out_path", nargs="?")
    sub.add_parser("backup-status", help="Print backup registry and backup freshness status JSON.")
    rc=sub.add_parser("restore-check", help="Validate a Sentinel Ledger JSON backup without restoring it."); rc.add_argument("backup_path")
    rj=sub.add_parser("restore-json", help="Restore a JSON backup into a new SQLite database path."); rj.add_argument("backup_path"); rj.add_argument("out_db"); rj.add_argument("--force", action="store_true")
    sub.add_parser("migration-status", help="Print schema migration status JSON.")
    sub.add_parser("recovery-status", help="Print recovery, backup, migration, and integrity status JSON.")
    sub.add_parser("aegis-summary", help="Print AEGIS-safe read-only ledger summary JSON.")
    sub.add_parser("aegis-metadata-status", help="Print AEGIS Vault metadata index status JSON.")
    sub.add_parser("gui", help="Launch the Sentinel-themed compact Tk GUI.")
    sub.add_parser("install-desktop-launcher", help="Install or repair the current user Desktop launcher.")
    sub.add_parser("list-ledgers", help="List named ledger profiles for multiple businesses.")
    sl=sub.add_parser("set-active-ledger", help="Set active named ledger profile."); sl.add_argument("name")
    cl=sub.add_parser("create-ledger", help="Create a separate named ledger for another business."); cl.add_argument("name"); cl.add_argument("--business-name", default=""); cl.add_argument("--owner-name", default=""); cl.add_argument("--registration-number", default=""); cl.add_argument("--tax-number", default=""); cl.add_argument("--currency", default="AUD"); cl.add_argument("--gst-registered", choices=("yes","no"), default="yes"); cl.add_argument("--bas-frequency", default="quarterly"); cl.add_argument("--notes", default=""); cl.add_argument("--no-active", action="store_true")
    sw=sub.add_parser("setup-wizard", help="Configure the current ledger business profile from CLI options."); sw.add_argument("--business-name"); sw.add_argument("--owner-name"); sw.add_argument("--registration-number"); sw.add_argument("--tax-number"); sw.add_argument("--currency"); sw.add_argument("--gst-registered", choices=("yes","no")); sw.add_argument("--bas-frequency"); sw.add_argument("--notes")


def build_parser() -> argparse.ArgumentParser:
    p=argparse.ArgumentParser(prog="sentinel-ledger", description=f"{APP_NAME} v{VERSION} — Program {PROGRAM_ID}")
    p.add_argument("--db", help=f"SQLite database path. Defaults to ${DB_ENV} or user data dir.")
    p.add_argument("--ledger", help="Named ledger profile for separate businesses, e.g. --ledger repairs or --ledger mowing.")
    p.add_argument("--version", action="store_true", help="Print version and exit.")
    sub=p.add_subparsers(dest="cmd")
    add_common_parsers(sub)
    bp=sub.add_parser("business-profile", help="Show or update local business profile."); bp.add_argument("--business-name"); bp.add_argument("--owner-name"); bp.add_argument("--registration-number"); bp.add_argument("--tax-number"); bp.add_argument("--currency"); bp.add_argument("--notes"); bp.add_argument("--gst-registered", choices=("yes","no")); bp.add_argument("--bas-frequency"); bp.add_argument("--default-tax-code"); bp.add_argument("--financial-year-start")
    inv=sub.add_parser("create-invoice", help="Create unpaid customer invoice and receivable journal entry."); inv.add_argument("invoice_no"); inv.add_argument("amount"); inv.add_argument("description"); inv.add_argument("--customer", default=""); inv.add_argument("--issue-date", default=today()); inv.add_argument("--due-date", default=""); inv.add_argument("--tax-rate", default="0.10"); inv.add_argument("--tax-mode", choices=("inclusive","exclusive"), default="inclusive"); inv.add_argument("--tax-code", default=None); inv.add_argument("--income-account", default="4000")
    pi=sub.add_parser("pay-invoice", help="Mark invoice paid and record bank receipt."); pi.add_argument("invoice_no"); pi.add_argument("--amount"); pi.add_argument("--date", default=today()); pi.add_argument("--receive-account", default="1010")
    sub.add_parser("invoices", help="List invoices.")
    bill=sub.add_parser("create-bill", help="Create unpaid supplier bill and payable journal entry."); bill.add_argument("bill_no"); bill.add_argument("amount"); bill.add_argument("description"); bill.add_argument("--supplier", default=""); bill.add_argument("--bill-date", default=today()); bill.add_argument("--due-date", default=""); bill.add_argument("--tax-rate", default="0.10"); bill.add_argument("--tax-mode", choices=("inclusive","exclusive"), default="inclusive"); bill.add_argument("--tax-code", default=None); bill.add_argument("--expense-account", default="5000")
    pb=sub.add_parser("pay-bill", help="Mark bill paid and record bank payment."); pb.add_argument("bill_no"); pb.add_argument("--amount"); pb.add_argument("--date", default=today()); pb.add_argument("--pay-account", default="1010")
    sub.add_parser("bills", help="List bills.")
    tc=sub.add_parser("tax-codes", help="List tax/GST codes.")
    atc=sub.add_parser("add-tax-code", help="Create or update a tax/GST code."); atc.add_argument("code"); atc.add_argument("name"); atc.add_argument("rate"); atc.add_argument("--treatment", default="taxable")
    gs=sub.add_parser("gst-status", help="Print readable GST/BAS profile and tax-code status."); gs.add_argument("--json", action="store_true")
    dg=sub.add_parser("deductions-guide", help="Print a general Australian deductions checklist for review."); dg.add_argument("--json", action="store_true")
    sub.add_parser("manual", help="Print the built-in Sentinel Ledger manual text.")
    isc=sub.add_parser("invoice-safety-check", help="Check tax-invoice readiness and warning flags."); isc.add_argument("--json", action="store_true")
    sec=sub.add_parser("security-status", help="Print security hardening status JSON.")
    sub.add_parser("no-network-check", help="Run local-only/no-network static self-check JSON.")
    lock=sub.add_parser("set-ledger-lock", help="Enable or disable the optional local ledger lock."); lock.add_argument("--enable", action="store_true"); lock.add_argument("--disable", action="store_true"); lock.add_argument("--password", default=None, help="Use @- for stdin or @/private/file; direct argv secrets are refused.")
    unlock=sub.add_parser("unlock-check", help="Check the optional local ledger lock password."); unlock.add_argument("--password", default=None, help="Use @- for stdin or @/private/file; direct argv secrets are refused.")
    eb=sub.add_parser("encrypted-backup", help="Create a password-protected local backup container."); eb.add_argument("--out-path"); eb.add_argument("--password", default=None, help="Use @- for stdin or @/private/file; direct argv secrets are refused.")
    ebc=sub.add_parser("encrypted-backup-check", help="Validate a password-protected backup container."); ebc.add_argument("backup_path"); ebc.add_argument("--password", default=None, help="Use @- for stdin or @/private/file; direct argv secrets are refused.")
    red=sub.add_parser("redaction-mode", help="Enable or disable redaction mode for summaries/screenshots."); red.add_argument("state", choices=("on","off","status"))
    aud=sub.add_parser("security-audit", help="Show recent security audit events."); aud.add_argument("--limit", type=int, default=25)
    return p


def normalize_launcher_argv(argv: list[str] | None = None) -> list[str]:
    """Return CLI args with accidental wrapper/program-name prefixes removed.

    v0.6.5 package wrappers passed strings like ``sentinel-ledger`` as the
    first argument to the Python entry point. That made desktop launchers fail
    because argparse treated the wrapper name as a command. Keep this function
    small and explicit so both installed wrappers and direct source runs work.
    """
    raw = list(sys.argv[1:] if argv is None else argv)
    launcher_aliases = {
        "sentinel-ledger",
        "sentinel-ledger-cli",
        "sentinel-ledger-gui",
        "aegis-ledger",
        "sentinel-ledger-accountant-report",
        "sentinel-ledger-aegis-metadata",
        "sentinel-ledger-backup-status",
        "sentinel-ledger-hotkeys",
        "sentinel-ledger-install-desktop-launcher",
        "sentinel-ledger-ledgers",
        "sentinel-ledger-recovery",
        "sentinel-ledger-setup",
        "sentinel-ledger-security-status",
        "sentinel-ledger-secure-backup",
        "sentinel-ledger-no-network-check",
        "sentinel-ledger-aegis-readiness",
        "sentinel-ledger-dashboard-summary",
        "sentinel-ledger-deep-integrity",
        "sentinel-ledger-recovery-report",
        "sentinel-ledger-restore-wizard",
        "sentinel-ledger-sentinel-command-status",
        "sentinel-ledger-sentinel-command-register",
        "sentinel-ledger-aegis-report-index",
        "sentinel-ledger-aegis-risk-flags",
        "sentinel-ledger-aegis-permission-map",
        "sentinel-ledger-release-candidate-status",
        "sentinel-ledger-stable-status",

    }
    if raw and Path(raw[0]).name in launcher_aliases:
        raw = raw[1:]
    return raw


WRITE_COMMANDS = {
    "init", "create-ledger", "set-active-ledger", "add-account", "update-account",
    "add-contact", "add-customer", "add-supplier", "update-contact",
    "add-payment-method", "add-recurring", "post-recurring", "link-document",
    "full-archive-export", "portable-restore-pack", "import-csv-queue", "approve-import",
    "quick-sale", "quick-expense", "journal", "opening-balance", "reverse-entry", "lock-period",
    "receipt", "export-csv", "accountant-bas-report", "backup-json", "restore-json",
    "business-profile", "setup-wizard", "create-invoice", "pay-invoice", "create-bill", "pay-bill",
    "add-tax-code", "install-desktop-launcher", "set-ledger-lock", "redaction-mode",
    "encrypted-backup", "sentinel-command-register", "inventory-bridge-status", "sentinel-command-status",
    "gui",
}


def command_main(argv: list[str] | None = None) -> int:
    argv = normalize_launcher_argv(argv)
    parser=build_parser(); args=parser.parse_args(argv)
    if args.version:
        print(f"{APP_NAME} {VERSION} Program {PROGRAM_ID}"); return 0
    if args.cmd in WRITE_COMMANDS:
        try:
            enforce_not_root_for_write(args.cmd)
        except LedgerError as exc:
            print(f"Error: {exc}", file=sys.stderr)
            return 2
    if args.cmd == "list-ledgers":
        print(json.dumps(list_ledger_profiles(), indent=2)); return 0
    if args.cmd == "create-ledger":
        result = create_ledger_profile(args.name, args.business_name, args.owner_name, args.registration_number, args.tax_number, args.currency, args.gst_registered, args.bas_frequency, args.notes, set_active=not args.no_active)
        print(json.dumps(result, indent=2)); return 0
    if args.cmd == "set-active-ledger":
        print(json.dumps(set_active_ledger(args.name), indent=2)); return 0
    selected_db_path = resolve_db_path(args.db, args.ledger)
    if not args.cmd:
        if sys.stdout.isatty(): parser.print_help(); return 0
        try:
            enforce_not_root_for_write("gui")
        except LedgerError as exc:
            print(f"Error: {exc}", file=sys.stderr)
            return 2
        return launch_gui(selected_db_path)
    if args.cmd == "gui":
        return launch_gui(selected_db_path)
    db=LedgerDB(selected_db_path)
    try:
        if args.cmd not in ("install-desktop-launcher", "hotkey-status", "restore-check", "restore-json"):
            db.init()
        if args.cmd == "init": print(f"Initialized {APP_NAME} database: {db.db_path}")
        elif args.cmd == "health": print(json.dumps(db.health(), indent=2))
        elif args.cmd == "inventory-bridge-status": print(json.dumps(db.inventory_bridge_status(write_contract=True), indent=2))
        elif args.cmd == "aegis-capabilities": print(json.dumps(db.aegis_capability_manifest(), indent=2))
        elif args.cmd == "aegis-readiness": print(json.dumps(db.aegis_readiness(), indent=2))
        elif args.cmd == "sentinel-command-status": print(json.dumps(db.sentinel_command_status(write_contract=True), indent=2))
        elif args.cmd == "sentinel-command-register": print(json.dumps(db.sentinel_command_register(), indent=2))
        elif args.cmd == "aegis-report-index": print(json.dumps(db.aegis_report_index(), indent=2))
        elif args.cmd == "aegis-risk-flags": print(json.dumps(db.aegis_risk_flags(), indent=2))
        elif args.cmd == "aegis-permission-map": print(json.dumps(db.aegis_permission_map(), indent=2))

        elif args.cmd == "dashboard-summary": print(json.dumps(db.dashboard_summary(), indent=2))
        elif args.cmd == "hotkey-status": print(json.dumps({"app":APP_NAME,"app_id":APP_ID,"program_id":PROGRAM_ID,"version":VERSION,"hotkeys_enabled":True,"hotkeys":HOTKEYS,"hotkey_status":HOTKEY_STATUS,"aegis_ready":True}, indent=2))
        elif args.cmd == "security-status": print(json.dumps(db.security_status(), indent=2))
        elif args.cmd == "no-network-check": print(json.dumps(db.no_network_check(), indent=2))
        elif args.cmd == "set-ledger-lock":
            if args.enable == args.disable:
                raise LedgerError("Choose exactly one of --enable or --disable.")
            password = read_private_secret_arg(args.password, "New Sentinel Ledger lock password: ", "ledger lock password") if args.enable else None
            print(json.dumps(db.set_ledger_lock(password=password, enabled=bool(args.enable)), indent=2))
        elif args.cmd == "unlock-check":
            password = read_private_secret_arg(args.password, "Sentinel Ledger lock password: ", "ledger unlock password")
            print(json.dumps(db.check_ledger_password(password), indent=2))
        elif args.cmd == "encrypted-backup":
            password = read_private_secret_arg(args.password, "Backup password: ", "backup password")
            path = db.encrypted_backup(password, Path(args.out_path).expanduser() if args.out_path else None)
            print(f"Created password-protected backup container: {path}")
        elif args.cmd == "encrypted-backup-check":
            password = read_private_secret_arg(args.password, "Backup password: ", "backup password")
            print(json.dumps(db.encrypted_backup_check(Path(args.backup_path).expanduser(), password), indent=2))
        elif args.cmd == "redaction-mode":
            if args.state == "status": print(json.dumps(db.security_status(), indent=2))
            else: print(json.dumps(db.set_redaction_mode(args.state == "on"), indent=2))
        elif args.cmd == "security-audit": print(json.dumps(db.security_audit_recent(args.limit), indent=2))

        elif args.cmd == "integrity-check": print(json.dumps(db.integrity_check(), indent=2))
        elif args.cmd == "deep-integrity-check": print(json.dumps(db.deep_integrity_check(), indent=2))
        elif args.cmd == "recovery-report": print(json.dumps(db.recovery_status(), indent=2) if args.json else db.recovery_report_text())
        elif args.cmd == "restore-wizard-status": print(json.dumps(db.restore_wizard_status(), indent=2))
        elif args.cmd == "backup-schedule-status": print(json.dumps(db.backup_schedule_status(), indent=2))
        elif args.cmd == "pre-upgrade-backup-status": print(json.dumps(db.pre_upgrade_backup_status(), indent=2))
        elif args.cmd == "diagnose-repair": print(json.dumps(db.diagnose_repair_status(), indent=2))
        elif args.cmd == "add-account": db.add_account(args.code,args.name,args.type); print(f"Added account {args.code} — {args.name}")
        elif args.cmd == "update-account": db.update_account(args.code,args.name,args.type, None if args.active is None else args.active=="yes", args.notes); print(f"Updated account {args.code}")
        elif args.cmd == "accounts": print_table(["Code","Name","Type","Active"], [(r["code"],r["name"],r["type"],r["is_active"]) for r in db.list_accounts(active_only=not args.all)])
        elif args.cmd == "add-contact": cid=db.add_contact(args.type,args.name,args.email,args.phone,args.tax_id,args.notes); print(f"Added contact #{cid}: {args.name}")
        elif args.cmd == "add-customer": cid=db.add_customer(args.name,args.email,args.phone,args.tax_id,args.notes); print(f"Registered customer #{cid}: {args.name}")
        elif args.cmd == "add-supplier": cid=db.add_supplier(args.name,args.email,args.phone,args.tax_id,args.notes); print(f"Registered supplier #{cid}: {args.name}")
        elif args.cmd == "contacts": print_table(["ID","Type","Name","Email","Phone","Tax ID"], [(r["id"],r["type"],r["name"],r["email"],r["phone"],r["tax_id"]) for r in db.list_contacts()])
        elif args.cmd == "customers": print_table(["ID","Name","Email","Phone","Records","Last","Total"], [(r["id"],r["name"],r["email"],r["phone"],r["record_count"],r["last_record_date"] or "-",money_str(max(int(r["debit_cents"]), int(r["credit_cents"])))) for r in db.list_contact_registry("customer")])
        elif args.cmd == "suppliers": print_table(["ID","Name","Email","Phone","Records","Last","Total"], [(r["id"],r["name"],r["email"],r["phone"],r["record_count"],r["last_record_date"] or "-",money_str(max(int(r["debit_cents"]), int(r["credit_cents"])))) for r in db.list_contact_registry("supplier")])
        elif args.cmd == "update-contact": db.update_contact(args.contact_id,args.type,args.name,args.email,args.phone,args.tax_id,args.notes); print(f"Updated contact #{args.contact_id}")
        elif args.cmd == "contact-detail": detail=db.contact_detail(args.contact_id); print(json.dumps(detail, indent=2) if args.json else format_contact_detail(detail))
        elif args.cmd == "customer-history": hist=db.contact_history(args.contact_id,"customer"); print(json.dumps(hist, indent=2) if args.json else format_contact_history(hist))
        elif args.cmd == "supplier-history": hist=db.contact_history(args.contact_id,"supplier"); print(json.dumps(hist, indent=2) if args.json else format_contact_history(hist))
        elif args.cmd == "search-contacts": result=db.search_contacts(args.text,args.limit); print(json.dumps(result, indent=2) if args.json else format_contacts_search(result))
        elif args.cmd == "payment-methods": print_table(["ID","Name","Type","Clearing","Active","Notes"], [(r["id"],r["name"],r["method_type"],r["clearing_account"],r["is_active"],r["notes"]) for r in db.list_payment_methods(active_only=not args.all)])
        elif args.cmd == "add-payment-method": db.add_payment_method(args.name,args.type,args.clearing_account,args.notes,active=not args.inactive); print(f"Saved payment method: {args.name}")
        elif args.cmd == "add-recurring": rid=db.add_recurring_template(args.name,args.entry_type,args.amount,args.description,args.contact,args.account,args.bank_account,args.tax_code,args.tax_rate,args.tax_mode,args.frequency,args.next_date,args.notes); print(f"Created recurring template #{rid}: {args.name}")
        elif args.cmd == "recurring": rows=[dict(r) for r in db.list_recurring_templates(active_only=not args.all)]; print(json.dumps(rows, indent=2) if args.json else format_recurring_table(rows))
        elif args.cmd == "post-recurring": result=db.post_recurring_template(args.template_id,args.date,advance=not args.no_advance); print(json.dumps(result, indent=2))
        elif args.cmd == "link-document": print(json.dumps(db.link_document(args.entry_id,args.path,args.note), indent=2))
        elif args.cmd == "business-workflow-status": print(json.dumps(db.business_workflow_status(), indent=2))
        elif args.cmd == "import-export-status": print(json.dumps(db.import_export_status(), indent=2))
        elif args.cmd == "release-candidate-status": print(json.dumps(db.release_candidate_status(), indent=2))
        elif args.cmd == "stable-status": print(json.dumps(db.stable_baseline_status(), indent=2))
        elif args.cmd == "accountant-handoff-wizard": print(json.dumps(db.accountant_handoff_wizard_status(), indent=2))
        elif args.cmd == "full-archive-export": print(json.dumps(db.full_archive_export(Path(args.out_dir).expanduser() if args.out_dir else None), indent=2))
        elif args.cmd == "portable-restore-pack": print(json.dumps(db.portable_restore_pack(Path(args.out_dir).expanduser() if args.out_dir else None), indent=2))
        elif args.cmd == "import-csv-queue": print(json.dumps(db.import_csv_queue(Path(args.csv_path).expanduser(), args.type), indent=2))
        elif args.cmd == "import-queue": result=db.list_import_queue(args.status,args.limit); print(json.dumps(result, indent=2) if args.json else format_import_queue(result))
        elif args.cmd == "approve-import": print(json.dumps(db.approve_import_row(args.queue_id,args.entry_type,args.amount,args.description,args.date,args.contact,args.account,args.tax_code), indent=2))
        elif args.cmd == "quick-sale": eid=db.quick_sale(args.amount,args.description,args.date,args.tax_rate,args.tax_mode,args.receive_account,args.income_account,args.gst_account,args.customer,args.source_ref,args.document,args.tax_code,args.payment_method); print(f"Recorded sale journal entry #{eid}")
        elif args.cmd == "quick-expense": eid=db.quick_expense(args.amount,args.description,args.date,args.tax_rate,args.tax_mode,args.pay_account,args.expense_account,args.gst_account,args.supplier,args.source_ref,args.document,args.tax_code,args.payment_method); print(f"Recorded expense journal entry #{eid}")
        elif args.cmd == "journal": eid=db.add_journal_entry(args.date,args.description,parse_journal_lines(args.lines),"manual",args.source_ref,memo=args.memo,document_path=args.document); print(f"Recorded manual journal entry #{eid}")
        elif args.cmd == "opening-balance": eid=db.opening_balance(args.account_code,args.amount,args.date,args.side,args.equity_account,args.memo); print(f"Recorded opening balance entry #{eid}")
        elif args.cmd == "reverse-entry": eid=db.reverse_entry(args.entry_id,args.date,args.reason); print(f"Recorded reversal entry #{eid}")
        elif args.cmd == "entry-detail": detail=db.entry_detail(args.entry_id); print(json.dumps(detail, indent=2) if args.json else format_entry_detail(detail))
        elif args.cmd == "lock-period": lid=db.lock_period(args.locked_through,args.reason); print(f"Locked period through {args.locked_through} as lock #{lid}")
        elif args.cmd == "transactions": print_table(["ID","Date","Description","Source","Ref","Total"], [(r["id"],display_date(r["entry_date"]),r["description"],r["source_type"],r["source_ref"],money_str(r["total_cents"])) for r in db.recent_transactions(args.limit,args.start,args.end,args.source_type,args.text)])
        elif args.cmd == "search-records":
            result=db.search_records(args.text,args.limit)
            if args.json: print(json.dumps(result, indent=2))
            else: print_table(["ID","Date","Description","Source","Ref","Total"], [(r["id"],display_date(r["entry_date"]),r["description"],r["source_type"],r["source_ref"],money_str(r["total_cents"])) for r in result["transactions"]])
        elif args.cmd == "receipt":
            path=db.write_receipt(args.entry_id, Path(args.out_dir).expanduser() if args.out_dir else None)
            status_payload=db.receipt_print_open_status(path)
            if args.json or args.status:
                print(json.dumps({"ok": True, "receipt_path": str(path), "status": status_payload}, indent=2))
            else:
                print(f"Generated receipt: {path}")
        elif args.cmd == "report": handle_report(db,args)
        elif args.cmd == "export-csv": paths=db.export_csv(Path(args.out_dir).expanduser()); print("Exported:"); [print(f"  {p}") for p in paths]
        elif args.cmd == "accountant-bas-report":
            result = db.write_accountant_bas_report(args.start, args.end, Path(args.out_dir).expanduser() if args.out_dir else None, include_suggested_deductions=args.include_suggested_deductions)
            print(json.dumps(result, indent=2) if args.json else f"Created accountant BAS handoff report: {result['report_path']}\nFolder: {result['folder']}")
        elif args.cmd == "backup-json": path=db.backup_json(Path(args.out_path).expanduser() if args.out_path else None); print(f"Created backup: {path}")
        elif args.cmd == "backup-status": print(json.dumps(db.backup_status(), indent=2))
        elif args.cmd == "restore-check": print(json.dumps(db.restore_check(Path(args.backup_path).expanduser()), indent=2))
        elif args.cmd == "restore-json": out=db.restore_json_to_new_db(Path(args.backup_path).expanduser(), Path(args.out_db).expanduser(), args.force); print(f"Restored backup to new database: {out}")
        elif args.cmd == "migration-status": print(json.dumps(db.migration_status(), indent=2))
        elif args.cmd == "recovery-status": print(json.dumps(db.recovery_status(), indent=2))
        elif args.cmd == "aegis-summary": print(json.dumps(db.aegis_safe_summary(), indent=2))
        elif args.cmd == "aegis-metadata-status": print(json.dumps(db.aegis_metadata_status(), indent=2))
        elif args.cmd == "business-profile": fields={"business_name":args.business_name,"owner_name":args.owner_name,"registration_number":args.registration_number,"tax_number":args.tax_number,"currency":args.currency,"notes":args.notes,"gst_registered":args.gst_registered,"bas_frequency":args.bas_frequency,"default_tax_code":args.default_tax_code,"financial_year_start":args.financial_year_start}; profile=db.update_business_profile(**fields) if any(v is not None for v in fields.values()) else db.get_business_profile(); print(json.dumps(profile, indent=2))
        elif args.cmd == "setup-wizard": fields={"business_name":args.business_name,"owner_name":args.owner_name,"registration_number":args.registration_number,"tax_number":args.tax_number,"currency":args.currency,"notes":args.notes,"gst_registered":args.gst_registered,"bas_frequency":args.bas_frequency}; profile=db.update_business_profile(**fields) if any(v is not None for v in fields.values()) else db.get_business_profile(); print(json.dumps({"ok": True, "setup_wizard": "cli", "business_profile": profile, "db_path": str(db.db_path)}, indent=2))
        elif args.cmd == "create-invoice": iid=db.create_invoice(args.invoice_no,args.amount,args.description,args.customer,args.issue_date,args.due_date,args.tax_rate,args.tax_mode,args.tax_code,args.income_account); print(f"Created invoice #{iid}: {args.invoice_no}")
        elif args.cmd == "pay-invoice": eid=db.pay_invoice(args.invoice_no,args.amount,args.date,args.receive_account); print(f"Recorded invoice payment entry #{eid}")
        elif args.cmd == "invoices": print_table(["No","Issue","Due","Customer","Description","Total","Status"], [(r["invoice_no"],display_date(r["issue_date"]),display_date(r["due_date"]),r["customer_name"],r["description"],money_str(r["total_cents"]),r["status"]) for r in db.list_invoices()])
        elif args.cmd == "create-bill": bid=db.create_bill(args.bill_no,args.amount,args.description,args.supplier,args.bill_date,args.due_date,args.tax_rate,args.tax_mode,args.tax_code,args.expense_account); print(f"Created bill #{bid}: {args.bill_no}")
        elif args.cmd == "pay-bill": eid=db.pay_bill(args.bill_no,args.amount,args.date,args.pay_account); print(f"Recorded bill payment entry #{eid}")
        elif args.cmd == "bills": print_table(["No","Bill Date","Due","Supplier","Description","Total","Status"], [(r["bill_no"],display_date(r["bill_date"]),display_date(r["due_date"]),r["supplier_name"],r["description"],money_str(r["total_cents"]),r["status"]) for r in db.list_bills()])
        elif args.cmd == "tax-codes": print_table(["Code","Name","Rate","Treatment","Active"], [(r["code"],r["name"],bps_to_rate_text(r["rate_bps"]),r["treatment"],r["is_active"]) for r in db.list_tax_codes()])
        elif args.cmd == "add-tax-code": db.add_tax_code(args.code,args.name,args.rate,args.treatment); print(f"Saved tax code {args.code.upper()}")
        elif args.cmd == "gst-status":
            status_payload = db.gst_status()
            print(json.dumps(status_payload, indent=2) if args.json else format_gst_status(status_payload))
        elif args.cmd == "deductions-guide": print(json.dumps(deduction_guide_payload(), indent=2) if args.json else format_deductions_guide())
        elif args.cmd == "manual": print(format_manual_text())
        elif args.cmd == "invoice-safety-check":
            check = db.invoice_safety_check()
            print(json.dumps(check, indent=2) if args.json else format_invoice_safety_check(check))
        elif args.cmd == "install-desktop-launcher": path=install_desktop_launcher(); print(f"Installed Desktop launcher: {path}")
        else:
            parser.print_help(); return 2
        return 0
    except LedgerError as exc:
        print(f"Error: {exc}", file=sys.stderr); return 2
    finally:
        db.close()

def format_entry_detail(detail: dict) -> str:
    e=detail["entry"]
    out=[f"Entry #{e['id']}  {display_date(e['entry_date'])}  {e['description']}", f"Source: {e.get('source_type','')} {e.get('source_ref','')}", "", "Lines:"]
    for l in detail["lines"]:
        out.append(f"  {l['code']} {l['name']:<28} {l['side']:<6} {money_str(l['amount_cents'])}  {l.get('memo','')}")
    if detail["documents"]:
        out.append("\nDocuments:")
        for d in detail["documents"]:
            out.append(f"  {d['path']} {d['sha256']}")
    return "\n".join(out)



def format_contact_detail(detail: dict) -> str:
    c = detail.get("contact", {})
    lines = [
        f"CONTACT DETAIL #{c.get('id')}",
        "=================",
        "",
        f"Name       : {c.get('name','')}",
        f"Type       : {c.get('type','')}",
        f"Email      : {c.get('email','')}",
        f"Phone      : {c.get('phone','')}",
        f"Tax ID     : {c.get('tax_id','')}",
        f"Notes      : {c.get('notes','')}",
        "",
        "Recent linked transactions",
        "--------------------------",
    ]
    for r in detail.get("transactions", []):
        lines.append(f"  #{r.get('id'):<5} {display_date(r.get('entry_date'))} {r.get('source_type'):<14} {r.get('source_ref') or '-':<18} {money_str(r.get('total_cents',0)):>12}  {r.get('description')}")
    if not detail.get("transactions"):
        lines.append("  No linked transactions found.")
    lines.extend(["", "Invoices", "--------"])
    for r in detail.get("invoices", []):
        lines.append(f"  {r.get('invoice_no'):<16} {display_date(r.get('issue_date'))} due {display_date(r.get('due_date')) or '-':<10} {money_str(r.get('total_cents',0)):>12} {r.get('status')}")
    if not detail.get("invoices"):
        lines.append("  No invoices found for this contact name.")
    lines.extend(["", "Bills", "-----"])
    for r in detail.get("bills", []):
        lines.append(f"  {r.get('bill_no'):<16} {display_date(r.get('bill_date'))} due {display_date(r.get('due_date')) or '-':<10} {money_str(r.get('total_cents',0)):>12} {r.get('status')}")
    if not detail.get("bills"):
        lines.append("  No bills found for this contact name.")
    return "\n".join(lines)


def format_contacts_search(result: dict) -> str:
    lines = ["CONTACT SEARCH", "==============", "", f"Query: {result.get('query')}", f"Matches: {result.get('count')}", ""]
    for c in result.get("contacts", []):
        lines.append(f"#{c.get('id'):<5} {c.get('type'):<9} {c.get('name'):<32} {c.get('email'):<28} {c.get('phone')}")
    if not result.get("contacts"):
        lines.append("No matching contacts found.")
    return "\n".join(lines)


def format_contact_history(history: dict) -> str:
    c = history.get("contact", {})
    title = f"{str(history.get('role') or 'contact').upper()} HISTORY — {c.get('name','')}"
    lines = [title, "=" * max(28, len(title)), "", f"Contact ID : {c.get('id')}", f"Email      : {c.get('email','')}", f"Phone      : {c.get('phone','')}", f"Records    : {history.get('record_count',0)}", ""]
    for r in history.get("records", []):
        total = max(int(r.get("debit_cents") or 0), int(r.get("credit_cents") or 0))
        lines.append(f"#{r.get('id'):<5} {display_date(r.get('entry_date'))} {r.get('source_type'):<15} {r.get('source_ref') or '-':<18} {money_str(total):>12}  {r.get('description')}")
    if not history.get("records"):
        lines.append("No remembered orders/expenses are linked to this contact yet.")
    return "\n".join(lines)


def format_import_queue(result: dict) -> str:
    lines = ["IMPORT REVIEW QUEUE", "===================", "", f"Status filter: {result.get('status_filter')}", f"Rows: {result.get('count')}", ""]
    for r in result.get("rows", []):
        row = r.get("row", {}) or {}
        preview = "; ".join(f"{k}={v}" for k, v in list(row.items())[:5])
        lines.append(f"#{r.get('id'):<5} {r.get('status'):<8} {r.get('import_type'):<12} {preview}")
    if not result.get("rows"):
        lines.append("No import rows found for this status.")
    lines.extend(["", "Import rows are never posted silently. Use approve-import after review."])
    return "\n".join(lines)


def format_recurring_table(rows: list[dict]) -> str:
    lines = ["RECURRING TEMPLATES", "===================", ""]
    for r in rows:
        lines.append(f"#{r.get('id'):<4} {r.get('next_date') or '-':<10} {r.get('entry_type'):<7} {money_str(r.get('amount_cents',0)):>12} {r.get('frequency'):<12} {r.get('name')} — {r.get('description')}")
    if not rows:
        lines.append("No recurring templates configured.")
    return "\n".join(lines)


def deduction_guide_payload() -> dict:
    return {
        "app": APP_NAME,
        "version": VERSION,
        "jurisdiction_note": "Australia-oriented checklist. Verify current ATO rules and seek advice before claiming.",
        "generated_at": now_iso(),
        "guide": DEDUCTION_GUIDE,
    }


def format_deductions_guide() -> str:
    lines = [
        "POTENTIAL DEDUCTIONS GUIDE",
        "==========================",
        "",
        "This is a checklist, not tax advice. It is designed to remind you what to review",
        "before preparing a tax return, BAS worksheet, or accountant handoff.",
        "",
        "Core principle: the expense must connect to earning income, records must exist,",
        "and private-use portions must be excluded or apportioned.",
        "",
    ]
    for section in DEDUCTION_GUIDE:
        lines.append(section["category"].upper())
        lines.append("-" * len(section["category"]))
        for item in section["items"]:
            lines.append(f"  • {item}")
        lines.append("")
    lines.extend([
        "Suggested workflow inside Sentinel Ledger:",
        "  1. Record the expense with a clear description.",
        "  2. Keep or generate a receipt/document reference.",
        "  3. Add a tax code and business-use percentage note where needed.",
        "  4. Review with the BAS worksheet and accountant/export pack before claiming.",
        "",
        "Local-only · No cloud · No telemetry · Review current ATO guidance before lodgement",
    ])
    return "\n".join(lines)


def format_manual_text() -> str:
    return """SENTINEL LEDGER MANUAL
======================

Purpose
-------
Sentinel Ledger is Program 107 in the Sentinel Desktop Suite. It is a local-first,
AEGIS-ready business ledger for recording sales, expenses, invoices, supplier bills,
receipts, GST/tax summaries, BAS preparation worksheets, CSV exports, and local backups.

Daily workflow
--------------
1. Use Quick Sale to record business income. Leave Source ref blank to auto-generate one.
2. Use Quick Expense to record business costs. Keep descriptions clear enough for tax review.
3. Use Dashboard to review recent Sales and Expenses separately.
4. Double-click or right-click dashboard rows to open a full record.
5. Use Search Records / Receipts to find a sale, expense, reference, receipt, or document.
6. Use Taxes → Tax / BAS Worksheet before accountant handoff or BAS review.
7. Use Backup JSON regularly and keep backups in the AEGIS Vault/export location.
8. Use Reports → Save Accountant Handover Report to create a period-based handoff folder for your accountant.
9. Use Ledger → Setup Wizard for business details. Use Ledger → Create New Ledger for separate businesses.

Keyboard shortcuts
------------------
Ctrl+Q    Close Sentinel Ledger cleanly
Ctrl+S    Save active Quick Sale / Quick Expense form
Ctrl+R    Refresh active view
Ctrl+H    Open AEGIS Health JSON
Ctrl+B    Create JSON backup
Ctrl+E    Export CSV
Ctrl+A    Select all text in report/manual panels
Ctrl+C    Copy selected report/manual text
Ctrl+V    Paste into Manual notes only; Reports/Taxes panels are read-only
Enter     Confirm active sale/expense form
Esc       Cancel/clear active form or close detail window

Reports page
------------
The Reports tab is a read-only review surface for accounting reports and accountant handoff.
Tax/BAS tools now live in the Taxes tab. Reports do not silently lodge tax, edit records,
or send data online. Use Ctrl+A/C or right-click copy to copy report text. Accountant
handoff can optionally include suggested deductions for your accountant to review.

Tax/BAS worksheet
-----------------
The BAS worksheet is generated from current ledger sales and expenses. It is a preparation
worksheet only. Check GST registration, tax codes, receipts, and invoice safety before relying
on it. Sentinel Ledger does not lodge BAS automatically.

Deductions guide
----------------
Use the Potential Deductions guide as a reminder checklist. It is not automatic tax advice.
Eligibility depends on your business structure, income source, records, GST registration,
private-use percentage, and current ATO rules.

AEGIS safety
------------
AEGIS-readable commands are intended for status, health, integrity, backup, recovery, and
summary checks. AEGIS should not silently create, edit, delete, or lodge financial records.

Local-only · No cloud · No telemetry
"""


def format_bas_worksheet(data: dict) -> str:
    collected = data.get("gst_collected_cents", 0)
    paid = data.get("gst_paid_cents", 0)
    net = data.get("net_gst_payable_cents", 0)
    gross_income = data.get("gross_income_cents", 0)
    gross_expense = data.get("gross_expense_cents", 0)
    status = "PAYABLE" if net >= 0 else "REFUND ESTIMATE"
    lines = [
        "TAX / BAS PREPARATION WORKSHEET",
        "================================",
        "",
        "Status",
        "------",
        f"Business name        : {data.get('business_name') or '(not set)'}",
        f"Period               : {display_period(data.get('period_start'), data.get('period_end'))}",
        f"GST registered       : {data.get('gst_registered')}",
        f"BAS frequency        : {data.get('bas_frequency') or 'not set'}",
        "",
        "Ledger Summary",
        "--------------",
        f"Gross income/sales   : {money_str(gross_income)}",
        f"Gross expenses       : {money_str(gross_expense)}",
        "",
        "GST / Tax Summary",
        "-----------------",
        f"GST collected        : {money_str(collected)}",
        f"GST paid / credits   : {money_str(paid)}",
        f"Estimated net GST    : {money_str(net)}  ({status})",
        "",
        "BAS Review Pointers",
        "-------------------",
        "G1  Total sales/income: review sales, invoices, and GST-free/out-of-scope items.",
        "1A  GST on sales: review GST/tax collected account and tax-code treatment.",
        "1B  GST on purchases: review GST/tax paid account, valid tax invoices, and private-use portions.",
        "",
        "Before lodging or accountant handoff",
        "-----------------------------------",
        "[ ] Business profile and GST registration status are correct.",
        "[ ] Sales and expenses are split between business and private use where needed.",
        "[ ] Receipts/tax invoices are attached or indexed where possible.",
        "[ ] Reversed/redacted entries have been reviewed after any correction.",
        "[ ] Backup JSON has been created before finalising the period.",
        "",
        f"Note: {data.get('notes', 'Preparation worksheet only. Review before lodgement.')}",
        "",
        "This worksheet is local-only and does not lodge BAS automatically.",
    ]
    return "\n".join(lines)


def format_gst_status(data: dict) -> str:
    lines = [
        "GST / TAX STATUS",
        "================",
        "",
        f"Business name       : {data.get('business_name') or '(not set)'}",
        f"GST registered mode : {'Yes' if data.get('gst_registered') else 'No'}",
        f"BAS frequency       : {data.get('bas_frequency') or 'not set'}",
        f"Default tax mode    : {data.get('default_tax_mode') or 'inclusive'}",
        f"Default tax code    : {data.get('default_tax_code') or 'not set'}",
        f"Tax/GST number set  : {'Yes' if data.get('tax_number_set') else 'No'}",
        f"Overall readiness   : {'Ready for review' if data.get('ok') else 'Needs attention'}",
        "",
        "Tax codes",
        "---------",
    ]
    for c in data.get("tax_codes", []):
        lines.append(f"  {c.get('code', ''):<10} {c.get('name', ''):<36} {bps_to_rate_text(int(c.get('rate_bps', 0))):>7}  {c.get('treatment', '')}")
    lines.extend(["", "Review flags", "------------"])
    if data.get("issues"):
        for issue in data.get("issues", []):
            lines.append(f"  [ ] {issue}")
    else:
        lines.append("  [x] No GST profile issues detected by Sentinel Ledger.")
    lines.extend(["", "This screen is a readable status view. It does not lodge BAS or validate final tax treatment."])
    return "\n".join(lines)


def format_invoice_safety_check(data: dict) -> str:
    profile = data.get("profile", {}) or {}
    lines = [
        "INVOICE SAFETY CHECK",
        "====================",
        "",
        f"Business name       : {profile.get('business_name') or '(not set)'}",
        f"Currency            : {profile.get('currency') or '(not set)'}",
        f"GST registered mode : {'Yes' if profile.get('gst_registered', 1) else 'No'}",
        f"Tax/GST number set  : {'Yes' if profile.get('tax_number') else 'No'}",
        f"Status              : {'Ready for review' if data.get('ok') else 'Needs attention'}",
        "",
        "Checks",
        "------",
    ]
    issues = data.get("issues") or []
    if issues:
        for issue in issues:
            lines.append(f"  [ ] {issue}")
    else:
        lines.append("  [x] Business name is set.")
        lines.append("  [x] Currency is set.")
        lines.append("  [x] GST/tax-invoice mode has no obvious profile conflict.")
    lines.extend([
        "",
        "Before sending invoices",
        "-----------------------",
        "  [ ] Confirm invoice number, issue date, due date, customer, description, total, and GST treatment.",
        "  [ ] If not GST registered, do not label the document as a tax invoice.",
        "  [ ] Keep generated invoices/receipts linked to the ledger record where possible.",
        "",
        "This is a safety checklist for preparation, not final legal/tax advice.",
    ])
    return "\n".join(lines)

def format_accountant_bas_report(data: dict) -> str:
    bas = data.get("bas_worksheet", {})
    profile = data.get("business_profile", {})
    counts = data.get("record_counts", {})
    lines = [
        "SENTINEL LEDGER — ACCOUNTANT BAS HANDOFF REPORT",
        "=================================================",
        "",
        "REPORT DETAILS",
        "--------------",
        f"Generated at          : {display_datetime(data.get('created_at'))}",
        f"Period               : {display_period(data.get('period_start'), data.get('period_end'))}",
        f"Ledger version        : {data.get('version')}",
        "",
        "BUSINESS PROFILE",
        "----------------",
        f"Business name         : {profile.get('business_name') or 'not set'}",
        f"Owner name            : {profile.get('owner_name') or 'not set'}",
        f"Registration / ABN    : {profile.get('registration_number') or 'not set'}",
        f"Tax / GST number      : {profile.get('tax_number') or 'not set'}",
        f"GST registered mode   : {bool(profile.get('gst_registered', 1))}",
        f"Currency              : {profile.get('currency') or 'AUD'}",
        "",
        "BAS / GST WORKSHEET SUMMARY",
        "---------------------------",
        f"GST/tax collected     : {money_str(int(bas.get('gst_collected_cents', 0)))}",
        f"GST/tax paid          : {money_str(int(bas.get('gst_paid_cents', 0)))}",
        f"Net GST/tax payable   : {money_str(int(bas.get('net_gst_payable_cents', 0)))}",
        f"Gross income          : {money_str(int(bas.get('gross_income_cents', 0)))}",
        f"Gross expenses        : {money_str(int(bas.get('gross_expense_cents', 0)))}",
        "",
        "RECORD COUNTS",
        "-------------",
        f"Transactions included : {counts.get('transactions', 0)}",
        f"Documents/receipts    : {counts.get('documents', 0)}",
    ]
    by_source = counts.get("by_source_type", {}) or {}
    for source, count in sorted(by_source.items()):
        lines.append(f"  - {source:<18}: {count}")
    lines.extend([
        "",
        "HANDOFF FILES",
        "-------------",
        "This report folder also includes:",
        "  - BAS_Accountant_Handoff_Report.json",
        "  - transactions.csv",
        "  - receipts_documents_index.csv",
        "  - handoff_manifest.json",
        "",
        "SUGGESTED DEDUCTIONS APPENDIX",
        "-----------------------------",
    ])
    if data.get("suggested_deductions"):
        lines.append("Included as a review checklist only. Ask the accountant to confirm eligibility, records, and apportionment.")
        for section in DEDUCTION_GUIDE:
            lines.append("")
            lines.append(section["category"])
            for item in section["items"]:
                lines.append(f"  [ ] {item}")
    else:
        lines.append("Not included in this handoff. Use the Save Accountant Handover prompt to add suggested deductions for accountant review.")
    lines.extend([
        "",
        "ACCOUNTANT REVIEW NOTES",
        "-----------------------",
        "- Confirm GST registration status and BAS period before lodgement.",
        "- Check tax codes, receipt availability, private-use apportionment, and capital purchases.",
        "- Use the receipts/documents index to locate supporting evidence.",
        "- This is a preparation/handoff report only, not tax lodgement or formal tax advice.",
        "",
    ])
    return "\n".join(lines) + "\n"


def handle_report(db: LedgerDB, args) -> None:
    if args.type == "trial-balance":
        rows=db.trial_balance();
        if args.json: print(json.dumps([dict(r) for r in rows], indent=2))
        else: print_table(["Code","Name","Type","Debit","Credit"], [(r["code"],r["name"],r["type"],money_str(r["debit_cents"]),money_str(r["credit_cents"])) for r in rows])
    elif args.type == "profit-loss":
        data=db.profit_loss(args.start,args.end)
        if args.json: print(json.dumps({k:v for k,v in data.items() if not isinstance(v,list)}, indent=2))
        else:
            print("Income"); print_table(["Code","Name","Amount"], [(r["code"],r["name"],money_str(bal)) for r,bal in data["income"] if bal != 0])
            print("\nExpenses"); print_table(["Code","Name","Amount"], [(r["code"],r["name"],money_str(bal)) for r,bal in data["expenses"] if bal != 0])
            print(f"\nTotal income:   {money_str(data['total_income'])}\nTotal expenses: {money_str(data['total_expense'])}\nNet profit:     {money_str(data['net_profit'])}")
    elif args.type == "balance-sheet":
        data=db.balance_sheet()
        if args.json: print(json.dumps({k:v for k,v in data.items() if not isinstance(v,list)}, indent=2))
        else:
            print("Assets"); print_table(["Code","Name","Amount"], [(r["code"],r["name"],money_str(bal)) for r,bal in data["assets"] if bal != 0])
            print("\nLiabilities"); print_table(["Code","Name","Amount"], [(r["code"],r["name"],money_str(bal)) for r,bal in data["liabilities"] if bal != 0])
            print("\nEquity"); print_table(["Code","Name","Amount"], [(r["code"],r["name"],money_str(bal)) for r,bal in data["equity"] if bal != 0])
            print(f"\nTotal assets:      {money_str(data['total_assets'])}\nTotal liabilities: {money_str(data['total_liabilities'])}\nTotal equity:      {money_str(data['total_equity'])}")
    elif args.type == "gst-summary":
        data=db.gst_summary(args.start,args.end)
        if args.json: print(json.dumps(data, indent=2))
        else: print(f"GST / tax collected: {money_str(data['gst_collected_cents'])}\nGST / tax paid:      {money_str(data['gst_paid_cents'])}\nNet payable:         {money_str(data['net_gst_payable_cents'])}")
    elif args.type == "bas-worksheet":
        data=db.bas_worksheet(args.start,args.end)
        if args.json: print(json.dumps(data, indent=2))
        else:
            print(format_bas_worksheet(data))


def launch_gui(db_path: Path | None = None) -> int:
    try:
        import tkinter as tk
        from tkinter import messagebox, ttk, filedialog, simpledialog
    except Exception as exc:
        print(f"Tk GUI unavailable: {exc}", file=sys.stderr)
        print("Use the CLI, e.g. sentinel-ledger init && sentinel-ledger health", file=sys.stderr)
        return 3

    db = LedgerDB(db_path); db.init()
    root = tk.Tk(); root.title(f"{APP_NAME} v{VERSION}"); root.geometry("1180x760"); root.minsize(1040, 660)
    style = ttk.Style()
    try: style.theme_use("clam")
    except Exception: pass
    apply_sentinel_theme(root, style)

    notebook = None
    sales_tree = expenses_tree = customer_tree = supplier_tree = acc_tree = report_text = tax_text = manual_text = status = active_ledger_label = None
    receipt_preview = receipt_template_preview = expense_preview = None
    sale_vars = exp_vars = None

    def status_line(msg: str):
        if status is not None:
            status.config(text=f"{msg} · Enter confirms · Esc cancels/clears · Ctrl+Q closes · Ctrl+S saves · Ctrl+R refreshes · Ctrl+H health · Ctrl+A/C/V text")


    def bind_text_clipboard(widget, allow_paste: bool = True):
        def select_all(event=None):
            widget.focus_set()
            widget.tag_add("sel", "1.0", "end-1c")
            return "break"
        def copy_text(event=None):
            try:
                text = widget.get("sel.first", "sel.last")
                root.clipboard_clear(); root.clipboard_append(text)
            except Exception:
                pass
            return "break"
        def paste_text(event=None):
            if not allow_paste:
                return "break"
            try:
                widget.focus_set()
                widget.insert("insert", root.clipboard_get())
            except Exception:
                pass
            return "break"
        def popup(event):
            menu = tk.Menu(root, tearoff=0, bg=SENTINEL_THEME["panel"], fg=SENTINEL_THEME["text"], activebackground=SENTINEL_THEME["gold"], activeforeground=SENTINEL_THEME["header"])
            menu.add_command(label="Copy", command=copy_text)
            if allow_paste:
                menu.add_command(label="Paste", command=paste_text)
            menu.add_command(label="Select All", command=select_all)
            try: menu.tk_popup(event.x_root, event.y_root)
            finally: menu.grab_release()
            return "break"
        widget.bind("<Control-a>", select_all); widget.bind("<Control-A>", select_all)
        widget.bind("<Control-c>", copy_text); widget.bind("<Control-C>", copy_text)
        widget.bind("<Control-v>", paste_text); widget.bind("<Control-V>", paste_text)
        widget.bind("<Button-3>", popup)

    def set_pretty_report(widget, text: str, readonly: bool = False):
        widget.configure(state="normal")
        widget.delete("1.0", "end")
        for line in text.splitlines():
            stripped = line.strip()
            tag = "value"
            if stripped and stripped == stripped.upper() and any(ch.isalpha() for ch in stripped):
                tag = "heading"
            elif stripped and set(stripped) <= set("=-_"):
                tag = "rule"
            elif stripped.startswith("[ ]") or stripped.startswith("•") or stripped.startswith("  •"):
                tag = "muted"
            elif ":" in line:
                tag = "label"
            if "not tax advice" in stripped.lower() or "does not lodge" in stripped.lower() or "review" in stripped.lower():
                tag = "warn"
            widget.insert("end", line + "\n", tag)
        widget.configure(state="disabled" if readonly else "normal")

    def text_select_all_hotkey(event=None):
        w = root.focus_get()
        if hasattr(w, "tag_add"):
            w.tag_add("sel", "1.0", "end-1c")
            return "break"
        return None

    def text_paste_hotkey(event=None):
        w = root.focus_get()
        if w is not manual_text:
            return "break"
        if hasattr(w, "insert") and hasattr(w, "index"):
            try:
                w.insert("insert", root.clipboard_get())
                return "break"
            except Exception:
                return "break"
        return "break"

    def active_tab_label():
        try: return notebook.tab(notebook.select(), "text") if notebook is not None else ""
        except Exception: return ""

    def show_entry_detail(entry_id: int):
        detail = db.entry_detail(int(entry_id))
        top = tk.Toplevel(root); top.title(f"Sentinel Ledger Entry #{entry_id}"); top.geometry("820x560"); top.configure(bg=SENTINEL_THEME["bg"])
        shell = tk.Frame(top, bg=SENTINEL_THEME["report_border"], highlightthickness=1, highlightbackground=SENTINEL_THEME["cyan"])
        shell.pack(fill="both", expand=True, padx=12, pady=12)
        txt = tk.Text(shell, wrap="word", bg=SENTINEL_THEME["report_bg"], fg=SENTINEL_THEME["report_text"], insertbackground=SENTINEL_THEME["cyan"], selectbackground=SENTINEL_THEME["cyan"], selectforeground=SENTINEL_THEME["header"], relief="flat", borderwidth=0, padx=14, pady=12, font=("DejaVu Sans Mono", 10))
        txt.pack(fill="both", expand=True, padx=1, pady=1); configure_report_text(txt); bind_text_clipboard(txt)
        txt.insert("end", format_entry_detail(detail)); txt.configure(state="disabled")
        btns = ttk.Frame(top, style="SentinelPanel.TFrame"); btns.pack(fill="x", padx=12, pady=(0,12))
        def gen_receipt():
            try:
                path = db.write_receipt(int(entry_id)); messagebox.showinfo(APP_NAME, f"Receipt generated:\n{path}", parent=top); status_line(f"Receipt generated for entry #{entry_id}")
            except Exception as exc: messagebox.showerror(APP_NAME, str(exc), parent=top)
        ttk.Button(btns, text="Generate Receipt", command=gen_receipt, style="Sentinel.TButton").pack(side="left", padx=4)
        ttk.Button(btns, text="Close", command=top.destroy, style="Sentinel.TButton").pack(side="right", padx=4)
        top.bind("<Escape>", lambda e: (top.destroy(), "break"))
        top.bind("<Return>", lambda e: (top.destroy(), "break"))
        top.focus_set()

    def tree_entry_id(tree):
        sel = tree.selection()
        if not sel: return None
        vals = tree.item(sel[0], "values")
        return vals[0] if vals else None

    def open_selected(tree):
        eid = tree_entry_id(tree)
        if eid: show_entry_detail(int(eid))
        return "break"

    def show_context_menu(event, tree):
        row = tree.identify_row(event.y)
        if row:
            tree.selection_set(row); tree.focus(row)
        menu = tk.Menu(root, tearoff=0, bg=SENTINEL_THEME["panel"], fg=SENTINEL_THEME["text"], activebackground=SENTINEL_THEME["gold"], activeforeground=SENTINEL_THEME["header"])
        menu.add_command(label="Open record", command=lambda: open_selected(tree))
        menu.add_command(label="Generate receipt", command=lambda: db.write_receipt(int(tree_entry_id(tree))) if tree_entry_id(tree) else None)
        try: menu.tk_popup(event.x_root, event.y_root)
        finally: menu.grab_release()
        return "break"

    def current_report_period() -> tuple[str, str]:
        try:
            start = parse_iso_date_or_blank(period_start_var.get())
            end = parse_iso_date_or_blank(period_end_var.get())
            return start, end
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc), parent=root)
            return "", ""

    def show_bas_report():
        notebook.select(tax_tab)
        start, end = current_report_period()
        set_pretty_report(tax_text, format_bas_worksheet(db.bas_worksheet(start or None, end or None)), readonly=True)
        status_line("Taxes/BAS worksheet refreshed" + f" · period {start or 'all'} to {end or 'all'}")

    def save_accountant_bas_report_gui():
        try:
            start, end = current_report_period()
            include_suggestions = messagebox.askyesno(APP_NAME, "Add potential/free deduction prompts to this accountant handoff as suggested deductions for review?", parent=root, default="yes")
            result = db.write_accountant_bas_report(start or None, end or None, include_suggested_deductions=include_suggestions)
            set_pretty_report(report_text, format_accountant_bas_report(db.accountant_bas_report_payload(start or None, end or None, include_suggested_deductions=include_suggestions)), readonly=True)
            messagebox.showinfo(APP_NAME, f"Accountant BAS handoff report saved:\n{result['report_path']}\n\nFolder:\n{result['folder']}", parent=root)
            status_line("Accountant BAS handoff report saved")
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc), parent=root)

    def show_tax_summary():
        notebook.select(tax_tab)
        start, end = current_report_period()
        gst = db.gst_summary(start or None, end or None)
        set_report_lines(tax_text, "GST / TAX SUMMARY", [("Period", f"{start or 'all'} to {end or 'all'}"), ("GST / tax collected", money_str(gst["gst_collected_cents"])), ("GST / tax paid", money_str(gst["gst_paid_cents"])), ("Net payable", money_str(gst["net_gst_payable_cents"]))], readonly=True)
        status_line("Tax summary refreshed")

    def open_records(source_type: str):
        title = "FULL SALES RECORDS" if source_type == "quick_sale" else "FULL EXPENSE RECORDS"
        notebook.select(rep_tab)
        rows = db.recent_transactions(500, source_type=source_type)
        report_text.configure(state="normal"); report_text.delete("1.0", "end")
        report_text.insert("end", f"{title}\n", "heading"); report_text.insert("end", "="*max(28, len(title))+"\n\n", "rule")
        for r in rows:
            report_text.insert("end", f"#{r['id']:<5} {display_date(r['entry_date'])}  {r['source_ref'] or '-':<18} ", "label")
            report_text.insert("end", f"{money_str(r['total_cents']):>12}  {r['description']}\n", "value")
        report_text.insert("end", "\nDouble-click/right-click dashboard rows to open a full record.\n", "muted")
        report_text.configure(state="disabled")
        status_line(title.title())

    def search_records_dialog():
        q = simpledialog.askstring("Search records / receipts", "Search records, references, receipt paths, or notes:", parent=root)
        if not q: return
        result = db.search_records(q, 200)
        notebook.select(rep_tab)
        report_text.configure(state="normal"); report_text.delete("1.0", "end")
        report_text.insert("end", f"SEARCH RECORDS / RECEIPTS\n", "heading"); report_text.insert("end", "=========================\n\n", "rule")
        report_text.insert("end", f"Query: {q}\nMatches: {result['count']}\n\n", "value")
        report_text.insert("end", "Transactions\n", "label")
        for r in result["transactions"]:
            report_text.insert("end", f"  #{r['id']:<5} {display_date(r['entry_date'])} {r['source_type']:<14} {r['source_ref'] or '-':<18} {money_str(r['total_cents']):>12}  {r['description']}\n", "value")
        report_text.insert("end", "\nReceipts / document references\n", "label")
        for d in result["receipts"]:
            report_text.insert("end", f"  entry #{d.get('entry_id') or '-'}  {d.get('source_ref') or '-'}  {d.get('path')}\n", "value")
        report_text.configure(state="disabled")
        status_line(f"Search complete: {result['count']} matches")

    def show_deductions_guide():
        notebook.select(tax_tab)
        set_pretty_report(tax_text, format_deductions_guide(), readonly=True)
        status_line("Potential deductions guide opened for review")

    def show_manual_home():
        notebook.select(manual_tab)
        set_pretty_report(manual_text, format_manual_text())
        status_line("Manual opened")

    def gui_backup():
        try: path = db.backup_json(); messagebox.showinfo(APP_NAME, f"Backup created:\n{path}")
        except Exception as exc: messagebox.showerror(APP_NAME, str(exc))

    def gui_export():
        folder = filedialog.askdirectory(title="Choose export folder")
        if not folder: return
        try: paths = db.export_csv(Path(folder)); messagebox.showinfo(APP_NAME, f"Exported {len(paths)} files.")
        except Exception as exc: messagebox.showerror(APP_NAME, str(exc))

    def maybe_print_receipt(entry_id: int):
        if messagebox.askyesno(APP_NAME, "Recorded. Print Receipt?\n\nYes = generate/save receipt and send to printer if available.\nNo = save sale only / no receipt.", default="yes"):
            try:
                path = db.write_receipt(entry_id)
                printed = False
                if shutil.which("lpr") or shutil.which("lp"):
                    cmd = "lpr" if shutil.which("lpr") else "lp"
                    try:
                        subprocess.run([cmd, str(path)], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                        printed = True
                    except Exception:
                        printed = False
                msg = f"Receipt saved:\n{path}"
                if printed:
                    msg = f"Receipt sent to printer and saved:\n{path}"
                else:
                    msg += "\n\nPrinting system was not available, so the receipt was saved for manual printing."
                if shutil.which("xdg-open") and messagebox.askyesno(APP_NAME, msg + "\n\nOpen the receipt file now?", parent=root, default="no"):
                    subprocess.Popen(["xdg-open", str(path)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                else:
                    messagebox.showinfo(APP_NAME, msg, parent=root)
            except Exception as exc: messagebox.showerror(APP_NAME, str(exc), parent=root)

    def refresh_dashboard():
        dash_summary = db.dashboard_summary()
        last_backup = dash_summary.get("last_backup") or {}
        last_backup_text = "none"
        if isinstance(last_backup, dict) and last_backup.get("created_at"):
            last_backup_text = display_datetime(last_backup.get("created_at"))
        summary.config(text=(
            f"{dash_summary.get('active_ledger_name') or 'Current ledger'}  ·  "
            f"Today S/E {money_str(dash_summary['today_sales_cents'])}/{money_str(dash_summary['today_expenses_cents'])}  ·  "
            f"Month S/E {money_str(dash_summary['month_sales_cents'])}/{money_str(dash_summary['month_expenses_cents'])}\n"
            f"GST net {money_str(dash_summary['estimated_gst_net_payable_cents'])}  ·  "
            f"Inv/Bills {dash_summary['unpaid_invoices']}/{dash_summary['unpaid_bills']}  ·  "
            f"Backup {last_backup_text}  ·  Integrity {'OK' if dash_summary['integrity_ok'] else 'CHECK'}"
        ))
        if active_ledger_label is not None:
            active_ledger_label.config(text=f"Program {PROGRAM_ID} · v{VERSION} · Active ledger: {dash_summary.get('active_ledger_name')} · {THEME_NAME} · {db.db_path.name}")
        for tree in (sales_tree, expenses_tree):
            [tree.delete(i) for i in tree.get_children()]
        for r in db.recent_transactions(200, source_type="quick_sale"):
            sales_tree.insert("", "end", values=(r["id"], display_date(r["entry_date"]), r["source_ref"], r["description"], money_str(r["total_cents"])))
        for r in db.recent_transactions(200, source_type="quick_expense"):
            expenses_tree.insert("", "end", values=(r["id"], display_date(r["entry_date"]), r["source_ref"], r["description"], money_str(r["total_cents"])))

    def clear_sale_form():
        sale_vars["amount"].set(""); sale_vars["description"].set(""); sale_vars["customer"].set(""); sale_vars["source_ref"].set(db.next_reference("quick_sale")); refresh_sale_preview()

    def clear_expense_form():
        exp_vars["amount"].set(""); exp_vars["description"].set(""); exp_vars["source_ref"].set(db.next_reference("quick_expense")); refresh_expense_preview()

    def save_sale():
        try:
            eid = db.quick_sale(sale_vars["amount"].get(), sale_vars["description"].get(), sale_vars["date"].get(), sale_vars["tax_rate"].get(), sale_vars["tax_mode"].get(), customer=sale_vars["customer"].get() or None, source_ref=sale_vars["source_ref"].get())
            clear_sale_form(); refresh_dashboard(); refresh_contact_tabs(); refresh_sale_preview(); status_line(f"Recorded sale entry #{eid}"); maybe_print_receipt(eid)
        except Exception as exc: messagebox.showerror(APP_NAME, str(exc))

    def save_expense():
        try:
            eid = db.quick_expense(exp_vars["amount"].get(), exp_vars["description"].get(), exp_vars["date"].get(), exp_vars["tax_rate"].get(), exp_vars["tax_mode"].get(), expense_account=exp_vars["expense_account"].get(), supplier=exp_vars["supplier"].get() or None, source_ref=exp_vars["source_ref"].get())
            clear_expense_form(); refresh_dashboard(); refresh_contact_tabs(); refresh_expense_preview(); status_line(f"Recorded expense entry #{eid}")
        except Exception as exc: messagebox.showerror(APP_NAME, str(exc))

    def refresh_sale_preview(*_):
        if receipt_preview is None or sale_vars is None:
            return
        try:
            text = db.draft_receipt_preview(
                sale_vars["amount"].get(),
                sale_vars["description"].get(),
                sale_vars["date"].get(),
                sale_vars["tax_rate"].get(),
                sale_vars["tax_mode"].get(),
                sale_vars["customer"].get(),
                sale_vars["source_ref"].get(),
            )
        except Exception as exc:
            text = f"Receipt preview unavailable: {exc}"
        receipt_preview.configure(state="normal")
        receipt_preview.delete("1.0", "end")
        receipt_preview.insert("end", text)
        receipt_preview.configure(state="disabled")

    def refresh_expense_preview(*_):
        if expense_preview is None or exp_vars is None:
            return
        try:
            amount = exp_vars["amount"].get() or "0"
            bps = parse_rate_bps(exp_vars["tax_rate"].get() or "0%")
            subtotal, tax, total = split_tax(parse_money(amount), bps, exp_vars["tax_mode"].get() or "inclusive")
            text = "QUICK EXPENSE REVIEW\n" + "="*28 + "\n\n"
            text += f"Date:            {display_date(exp_vars['date'].get() or today())}\n"
            text += f"Supplier:        {exp_vars['supplier'].get() or '-'}\n"
            text += f"Description:     {exp_vars['description'].get() or '-'}\n"
            text += f"Source ref:      {exp_vars['source_ref'].get() or db.next_reference('quick_expense')}\n"
            text += f"Expense account: {exp_vars['expense_account'].get() or '5000'}\n"
            text += "\nAmounts\n" + "-------\n"
            text += f"Subtotal:        {money_str(money_to_cents(subtotal))}\n"
            text += f"GST/tax paid:    {money_str(money_to_cents(tax))}\n"
            text += f"Total paid:      {money_str(money_to_cents(total))}\n"
            text += "\nLedger effect\n" + "-------------\n"
            text += "Debit expense + GST paid, credit payment account.\n"
            text += "\nReminder\n" + "--------\n"
            text += "Attach or retain the receipt/document. Potential deductions guide is in the Taxes tab for accountant review.\n"
        except Exception as exc:
            text = f"Expense preview unavailable: {exc}"
        expense_preview.configure(state="normal")
        expense_preview.delete("1.0", "end")
        expense_preview.insert("end", text)
        expense_preview.configure(state="disabled")

    def refresh_accounts():
        [acc_tree.delete(i) for i in acc_tree.get_children()]
        for r in db.list_accounts(active_only=False): acc_tree.insert("", "end", values=(r["code"], r["name"], r["type"], r["is_active"]))

    def refresh_contact_tabs():
        for tree, typ in ((customer_tree, "customer"), (supplier_tree, "supplier")):
            if tree is None:
                continue
            [tree.delete(i) for i in tree.get_children()]
            for r in db.list_contact_registry(typ):
                total = max(int(r["debit_cents"] or 0), int(r["credit_cents"] or 0))
                tree.insert("", "end", values=(r["id"], r["name"], r["email"], r["phone"], r["record_count"], r["last_record_date"] or "-", money_str(total)))

    def selected_contact_id(tree):
        sel = tree.selection()
        if not sel: return None
        vals = tree.item(sel[0], "values")
        return int(vals[0]) if vals else None

    def show_contact_history_window(contact_id: int, role: str):
        hist = db.contact_history(contact_id, role)
        top = tk.Toplevel(root); top.title(f"{role.title()} History #{contact_id}"); top.geometry("840x560"); top.configure(bg=SENTINEL_THEME["bg"])
        shell = tk.Frame(top, bg=SENTINEL_THEME["report_border"], highlightthickness=1, highlightbackground=SENTINEL_THEME["cyan"])
        shell.pack(fill="both", expand=True, padx=12, pady=12)
        txt = tk.Text(shell, wrap="word", bg=SENTINEL_THEME["report_bg"], fg=SENTINEL_THEME["report_text"], insertbackground=SENTINEL_THEME["cyan"], selectbackground=SENTINEL_THEME["cyan"], selectforeground=SENTINEL_THEME["header"], relief="flat", borderwidth=0, padx=14, pady=12, font=("DejaVu Sans Mono", 10))
        txt.pack(fill="both", expand=True, padx=1, pady=1); configure_report_text(txt); bind_text_clipboard(txt, allow_paste=False)
        set_pretty_report(txt, format_contact_history(hist), readonly=True)
        ttk.Button(top, text="Close", command=top.destroy, style="Sentinel.TButton").pack(anchor="e", padx=12, pady=(0,12))
        top.bind("<Escape>", lambda e: (top.destroy(), "break")); top.focus_set()

    def add_contact_window(role: str):
        top = tk.Toplevel(root); top.title(f"Add {role.title()}"); top.geometry("520x360"); top.configure(bg=SENTINEL_THEME["bg"])
        panel = ttk.Labelframe(top, text=f"{role.title()} Details", style="Sentinel.TLabelframe", padding=12)
        panel.pack(fill="both", expand=True, padx=12, pady=12)
        vars_ = {k: tk.StringVar(value="") for k in ("name","email","phone","tax_id","notes")}
        make_form(panel, [("Name", vars_["name"]),("Email", vars_["email"]),("Phone", vars_["phone"]),("Tax / ABN", vars_["tax_id"]),("Notes", vars_["notes"])], width=34)
        def save_contact():
            try:
                if role == "customer": db.add_customer(vars_["name"].get(), vars_["email"].get(), vars_["phone"].get(), vars_["tax_id"].get(), vars_["notes"].get())
                else: db.add_supplier(vars_["name"].get(), vars_["email"].get(), vars_["phone"].get(), vars_["tax_id"].get(), vars_["notes"].get())
                refresh_contact_tabs(); status_line(f"{role.title()} saved"); top.destroy()
            except Exception as exc: messagebox.showerror(APP_NAME, str(exc), parent=top)
        ttk.Button(panel, text=f"Save {role.title()}", command=save_contact, style="SentinelAccent.TButton").pack(anchor="w", pady=10)
        top.bind("<Return>", lambda e: (save_contact(), "break")); top.bind("<Escape>", lambda e: (top.destroy(), "break")); top.focus_set()

    def show_trial_balance_report():
        notebook.select(rep_tab)
        rows = db.trial_balance()
        total_debit = sum(int(r["debit_cents"] or 0) for r in rows)
        total_credit = sum(int(r["credit_cents"] or 0) for r in rows)
        report_text.configure(state="normal")
        report_text.delete("1.0", "end")
        title = "TRIAL BALANCE"
        report_text.insert("end", title + "\n", "heading")
        report_text.insert("end", "=" * max(28, len(title)) + "\n\n", "rule")
        report_text.insert("end", f"{'Code':<8} {'Account':<34} {'Type':<11} {'Debit':>13} {'Credit':>13}\n", "label")
        report_text.insert("end", "-" * 86 + "\n", "rule")
        for r in rows:
            report_text.insert("end", f"{r['code']:<8} {r['name'][:34]:<34} {r['type']:<11} {money_str(r['debit_cents']):>13} {money_str(r['credit_cents']):>13}\n", "value")
        report_text.insert("end", "-" * 86 + "\n", "rule")
        report_text.insert("end", f"{'TOTALS':<55} {money_str(total_debit):>13} {money_str(total_credit):>13}\n", "ok" if total_debit == total_credit else "warn")
        report_text.insert("end", "\nRead-only report · use Ctrl+A/C or right-click to copy.\n", "muted")
        report_text.configure(state="disabled")
        status_line("Trial Balance report opened")

    def show_profit_loss_report():
        notebook.select(rep_tab)
        data = db.profit_loss()
        report_text.configure(state="normal")
        report_text.delete("1.0", "end")
        title = "PROFIT / LOSS REPORT"
        report_text.insert("end", title + "\n", "heading")
        report_text.insert("end", "=" * max(28, len(title)) + "\n\n", "rule")
        report_text.insert("end", "Income\n", "label")
        for r, bal in data["income"]:
            if bal:
                report_text.insert("end", f"  {r['code']:<8} {r['name'][:44]:<44} {money_str(bal):>13}\n", "value")
        report_text.insert("end", f"  {'Total income':<54} {money_str(data['total_income']):>13}\n\n", "ok")
        report_text.insert("end", "Expenses\n", "label")
        for r, bal in data["expenses"]:
            if bal:
                report_text.insert("end", f"  {r['code']:<8} {r['name'][:44]:<44} {money_str(bal):>13}\n", "value")
        report_text.insert("end", f"  {'Total expenses':<54} {money_str(data['total_expense']):>13}\n", "value")
        report_text.insert("end", "-" * 79 + "\n", "rule")
        report_text.insert("end", f"  {'Net profit / loss':<54} {money_str(data['net_profit']):>13}\n", "ok" if data['net_profit'] >= 0 else "warn")
        report_text.insert("end", "\nRead-only report · use Ctrl+A/C or right-click to copy.\n", "muted")
        report_text.configure(state="disabled")
        status_line("Profit / Loss report opened")

    def show_balance_sheet_report():
        notebook.select(rep_tab)
        data = db.balance_sheet()
        report_text.configure(state="normal")
        report_text.delete("1.0", "end")
        title = "BALANCE SHEET"
        report_text.insert("end", title + "\n", "heading")
        report_text.insert("end", "=" * max(28, len(title)) + "\n\n", "rule")
        for label, key, total_key in [("Assets", "assets", "total_assets"), ("Liabilities", "liabilities", "total_liabilities"), ("Equity", "equity", "total_equity")]:
            report_text.insert("end", label + "\n", "label")
            for r, bal in data[key]:
                if bal:
                    report_text.insert("end", f"  {r['code']:<8} {r['name'][:44]:<44} {money_str(bal):>13}\n", "value")
            report_text.insert("end", f"  {'Total ' + label.lower():<54} {money_str(data[total_key]):>13}\n\n", "ok")
        report_text.insert("end", "Read-only report · use Ctrl+A/C or right-click to copy.\n", "muted")
        report_text.configure(state="disabled")
        status_line("Balance Sheet report opened")

    def show_json(title, payload):
        notebook.select(rep_tab); set_json_report(report_text, title, payload)

    def show_tax_json(title, payload):
        notebook.select(tax_tab); set_json_report(tax_text, title, payload)

    def show_recovery_report_gui():
        notebook.select(rep_tab); set_pretty_report(report_text, db.recovery_report_text(), readonly=True); status_line("Recovery report opened")

    def show_deep_integrity_gui():
        notebook.select(rep_tab); set_json_report(report_text, "DEEP INTEGRITY CHECK", db.deep_integrity_check()); status_line("Deep integrity check opened")

    def show_restore_wizard_status_gui():
        notebook.select(rep_tab); set_json_report(report_text, "RESTORE WIZARD STATUS", db.restore_wizard_status()); status_line("Restore wizard status opened")

    def show_backup_schedule_gui():
        notebook.select(rep_tab); set_json_report(report_text, "BACKUP SCHEDULE STATUS", db.backup_schedule_status()); status_line("Backup schedule status opened")

    def close_app(event=None):
        try: db.close()
        finally: root.destroy()
        return "break"

    def save_active(event=None):
        tab = active_tab_label()
        if tab == "Quick Sale": save_sale()
        elif tab == "Quick Expense": save_expense()
        else: status_line("Ctrl+S saves only from Quick Sale or Quick Expense")
        return "break"

    def refresh_active(event=None):
        if active_tab_label() == "Accounts": refresh_accounts()
        else: refresh_dashboard()
        status_line("View refreshed"); return "break"

    def cancel_active(event=None):
        tab = active_tab_label()
        if tab == "Quick Sale": clear_sale_form(); status_line("Quick Sale cleared")
        elif tab == "Quick Expense": clear_expense_form(); status_line("Quick Expense cleared")
        else: status_line("Cancelled")
        return "break"

    def health_hotkey(event=None): show_json("AEGIS HEALTH JSON", db.health()); status_line("AEGIS health opened"); return "break"
    def backup_hotkey(event=None): gui_backup(); return "break"
    def export_hotkey(event=None): gui_export(); return "break"


    def open_setup_wizard(first_run: bool = False, blank: bool = False):
        profile = {} if blank else db.get_business_profile()
        top = tk.Toplevel(root); top.title("Sentinel Ledger Setup Wizard"); top.geometry("620x430"); top.configure(bg=SENTINEL_THEME["bg"]); top.transient(root); top.grab_set()
        ttk.Label(top, text="Sentinel Ledger Setup Wizard", style="SentinelTitle.TLabel", padding=(12,10)).pack(fill="x")
        body = ttk.Frame(top, padding=12, style="SentinelPanel.TFrame"); body.pack(fill="both", expand=True, padx=12, pady=8)
        vars_ = {
            "business_name": tk.StringVar(value=profile.get("business_name", "")),
            "owner_name": tk.StringVar(value=profile.get("owner_name", "")),
            "registration_number": tk.StringVar(value=profile.get("registration_number", "")),
            "tax_number": tk.StringVar(value=profile.get("tax_number", "")),
            "currency": tk.StringVar(value=profile.get("currency", "AUD") or "AUD"),
            "gst_registered": tk.StringVar(value="yes" if profile.get("gst_registered", 1) else "no"),
            "bas_frequency": tk.StringVar(value=profile.get("bas_frequency", "quarterly") or "quarterly"),
            "notes": tk.StringVar(value=profile.get("notes", "")),
        }
        make_form(body, [("Business name", vars_["business_name"]),("Owner name", vars_["owner_name"]),("Registration / ABN", vars_["registration_number"]),("Tax / GST no.", vars_["tax_number"]),("Currency", vars_["currency"]),("GST registered yes/no", vars_["gst_registered"]),("BAS frequency", vars_["bas_frequency"]),("Notes", vars_["notes"])])
        ttk.Label(body, text="Default chart of accounts is created automatically when the ledger is initialised.", style="SentinelStatus.TLabel").pack(anchor="w", pady=(8,4))
        btns = ttk.Frame(top, style="SentinelPanel.TFrame"); btns.pack(fill="x", padx=12, pady=(0,12))
        def save_profile():
            try:
                db.update_business_profile(**{k:v.get() for k,v in vars_.items()})
                status_line("Business setup saved")
                refresh_dashboard(); top.destroy()
            except Exception as exc:
                messagebox.showerror(APP_NAME, str(exc), parent=top)
        ttk.Button(btns, text="Save Setup", command=save_profile, style="SentinelAccent.TButton").pack(side="left", padx=4)
        ttk.Button(btns, text="Cancel", command=top.destroy, style="Sentinel.TButton").pack(side="right", padx=4)
        top.bind("<Return>", lambda e: (save_profile(), "break")); top.bind("<Escape>", lambda e: (top.destroy(), "break"))
        if first_run:
            ttk.Label(body, text="First run detected: enter business details to prepare this ledger.", style="SentinelBody.TLabel").pack(anchor="w", pady=(4,0))

    def create_ledger_gui():
        name = simpledialog.askstring("Create ledger", "Ledger name, e.g. repairs_business or second_business:", parent=root)
        if not name:
            return
        business = simpledialog.askstring("Business name", "Business name for this ledger:", parent=root) or name
        try:
            result = create_ledger_profile(name, business_name=business, set_active=False)
            if messagebox.askyesno(APP_NAME, f"Ledger created:\n{result['db_path']}\n\nOpen this ledger now?", parent=root):
                db.close(); root.destroy(); os.execv(sys.executable, [sys.executable, str(Path(__file__).resolve()), "--db", result["db_path"], "gui"])
            else:
                status_line(f"Created ledger profile {result['slug']}")
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc), parent=root)

    def show_ledger_profiles():
        notebook.select(rep_tab)
        profiles = list_ledger_profiles()
        lines = ["LEDGER PROFILES", "===============", "", f"Registry: {profiles.get('registry_path')}", f"Active: {profiles.get('active')}", ""]
        for rec in profiles.get("ledgers", []):
            lines.append(f"{'*' if rec.get('active') else ' '} {rec.get('slug')} — {rec.get('business_name') or rec.get('name')}")
            lines.append(f"    DB: {rec.get('db_path')}")
            lines.append(f"    Exists: {rec.get('exists')}")
        if not profiles.get("ledgers"):
            lines.append("No named ledgers yet. Use Ledger → Create New Ledger.")
        set_pretty_report(report_text, "\n".join(lines), readonly=True)

    def forms_have_unsaved_data() -> bool:
        try:
            sale_dirty = any((sale_vars[k].get() or "").strip() for k in ("amount", "description", "customer"))
            exp_dirty = any((exp_vars[k].get() or "").strip() for k in ("amount", "description", "supplier"))
            return bool(sale_dirty or exp_dirty)
        except Exception:
            return False

    def open_ledger_profile_gui(slug: str):
        try:
            if forms_have_unsaved_data() and not messagebox.askyesno(APP_NAME, "Unsaved Quick Sale/Expense form data exists. Switch ledgers anyway?", parent=root, default="no"):
                return
            if messagebox.askyesno(APP_NAME, f"Open ledger profile '{slug}' now?\n\nThe Ledger window will restart and load that business ledger.", parent=root):
                set_active_ledger(slug)
                db.close(); root.destroy(); os.execv(sys.executable, [sys.executable, str(Path(__file__).resolve()), "--ledger", slug, "gui"])
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc), parent=root)

    def build_open_ledger_submenu(menu):
        menu.delete(0, "end")
        profiles = list_ledger_profiles()
        ledgers = profiles.get("ledgers", [])
        if not ledgers:
            menu.add_command(label="No ledger profiles yet", state="disabled")
            menu.add_separator()
            menu.add_command(label="Create New Ledger...", command=create_ledger_gui)
            return
        for rec in ledgers:
            label = f"{'✓ ' if rec.get('active') else ''}{rec.get('business_name') or rec.get('name') or rec.get('slug')} ({rec.get('slug')})"
            menu.add_command(label=label, command=lambda slug=rec.get('slug'): open_ledger_profile_gui(slug))
        menu.add_separator()
        menu.add_command(label="Refresh Ledger List", command=lambda: build_open_ledger_submenu(menu))
        menu.add_command(label="Create New Ledger...", command=create_ledger_gui)

    menubar = tk.Menu(root, bg=SENTINEL_THEME["header"], fg=SENTINEL_THEME["text"], activebackground=SENTINEL_THEME["gold"], activeforeground=SENTINEL_THEME["header"])
    file_menu = tk.Menu(menubar, tearoff=0, bg=SENTINEL_THEME["panel"], fg=SENTINEL_THEME["text"], activebackground=SENTINEL_THEME["gold"], activeforeground=SENTINEL_THEME["header"])
    file_menu.add_command(label="Backup JSON", command=gui_backup); file_menu.add_command(label="Export CSV", command=gui_export); file_menu.add_command(label="Import / Export Status", command=lambda: show_json("IMPORT / EXPORT STATUS", db.import_export_status())); file_menu.add_separator(); file_menu.add_command(label="Close  Ctrl+Q", command=close_app)
    ledger_menu = tk.Menu(menubar, tearoff=0, bg=SENTINEL_THEME["panel"], fg=SENTINEL_THEME["text"], activebackground=SENTINEL_THEME["gold"], activeforeground=SENTINEL_THEME["header"])
    ledger_menu.add_command(label="Setup Wizard", command=lambda: open_setup_wizard(False, blank=True))
    ledger_menu.add_command(label="Create New Ledger", command=create_ledger_gui)
    ledger_menu.add_command(label="Show Ledger Profiles", command=show_ledger_profiles)
    open_ledger_menu = tk.Menu(ledger_menu, tearoff=0, bg=SENTINEL_THEME["panel"], fg=SENTINEL_THEME["text"], activebackground=SENTINEL_THEME["gold"], activeforeground=SENTINEL_THEME["header"])
    build_open_ledger_submenu(open_ledger_menu)
    ledger_menu.add_cascade(label="Open Ledger Database", menu=open_ledger_menu)
    records_menu = tk.Menu(menubar, tearoff=0, bg=SENTINEL_THEME["panel"], fg=SENTINEL_THEME["text"], activebackground=SENTINEL_THEME["gold"], activeforeground=SENTINEL_THEME["header"])
    records_menu.add_command(label="Open Full Sales Records", command=lambda: open_records("quick_sale")); records_menu.add_command(label="Open Full Expense Records", command=lambda: open_records("quick_expense")); records_menu.add_command(label="Search Records / Receipts", command=search_records_dialog)
    records_menu.add_separator(); records_menu.add_command(label="Customers", command=lambda: notebook.select(customer_tab)); records_menu.add_command(label="Suppliers", command=lambda: notebook.select(supplier_tab)); records_menu.add_command(label="Add Customer", command=lambda: add_contact_window("customer")); records_menu.add_command(label="Add Supplier", command=lambda: add_contact_window("supplier"))
    records_menu.add_separator(); records_menu.add_command(label="Business Workflow Status", command=lambda: show_json("BUSINESS WORKFLOW STATUS", db.business_workflow_status())); records_menu.add_command(label="Import / Export Status", command=lambda: show_json("IMPORT / EXPORT STATUS", db.import_export_status())); records_menu.add_command(label="Payment Methods", command=lambda: show_json("PAYMENT METHODS", {"payment_methods": [dict(r) for r in db.list_payment_methods(active_only=False)]})); records_menu.add_command(label="Recurring Templates", command=lambda: show_json("RECURRING TEMPLATES", {"recurring_templates": [dict(r) for r in db.list_recurring_templates(active_only=False)]}))
    reports_menu = tk.Menu(menubar, tearoff=0, bg=SENTINEL_THEME["panel"], fg=SENTINEL_THEME["text"], activebackground=SENTINEL_THEME["gold"], activeforeground=SENTINEL_THEME["header"])
    reports_menu.add_command(label="Trial Balance", command=lambda: show_trial_balance_report())
    reports_menu.add_command(label="Profit / Loss", command=lambda: show_profit_loss_report())
    reports_menu.add_command(label="Balance Sheet", command=lambda: show_balance_sheet_report())
    reports_menu.add_separator()
    reports_menu.add_command(label="Save Accountant Handover Report", command=save_accountant_bas_report_gui)
    reports_menu.add_command(label="Accountant Handoff Wizard Status", command=lambda: show_json("ACCOUNTANT HANDOFF WIZARD", db.accountant_handoff_wizard_status()))
    reports_menu.add_separator()
    reports_menu.add_command(label="Integrity", command=lambda: show_json("LEDGER INTEGRITY", db.integrity_check()))
    reports_menu.add_command(label="Deep Integrity", command=show_deep_integrity_gui)
    reports_menu.add_command(label="Recovery Report", command=show_recovery_report_gui)
    reports_menu.add_command(label="Restore Wizard Status", command=show_restore_wizard_status_gui)
    reports_menu.add_command(label="AEGIS Health JSON", command=lambda: show_json("AEGIS HEALTH JSON", db.health()))
    reports_menu.add_command(label="Recovery Status", command=lambda: show_json("RECOVERY STATUS", db.recovery_status()))
    taxes_menu = tk.Menu(menubar, tearoff=0, bg=SENTINEL_THEME["panel"], fg=SENTINEL_THEME["text"], activebackground=SENTINEL_THEME["gold"], activeforeground=SENTINEL_THEME["header"])
    taxes_menu.add_command(label="Tax / BAS Worksheet", command=show_bas_report)
    taxes_menu.add_command(label="GST / Tax Summary", command=show_tax_summary)
    taxes_menu.add_command(label="GST Status", command=lambda: (notebook.select(tax_tab), set_pretty_report(tax_text, format_gst_status(db.gst_status()), readonly=True)))
    taxes_menu.add_command(label="Invoice Safety Check", command=lambda: (notebook.select(tax_tab), set_pretty_report(tax_text, format_invoice_safety_check(db.invoice_safety_check()), readonly=True)))
    taxes_menu.add_command(label="Potential Deductions Guide", command=show_deductions_guide)
    settings_menu = tk.Menu(menubar, tearoff=0, bg=SENTINEL_THEME["panel"], fg=SENTINEL_THEME["text"], activebackground=SENTINEL_THEME["gold"], activeforeground=SENTINEL_THEME["header"])
    settings_menu.add_command(label="Receipt Creator", command=lambda: notebook.select(receipt_tab))
    settings_menu.add_command(label="Security Status", command=lambda: show_json("SECURITY STATUS", db.security_status()))
    settings_menu.add_command(label="No-Network Check", command=lambda: show_json("NO-NETWORK CHECK", db.no_network_check()))
    settings_menu.add_command(label="GST Profile / Tax Codes", command=lambda: (notebook.select(tax_tab), set_pretty_report(tax_text, format_gst_status(db.gst_status()), readonly=True))); settings_menu.add_command(label="Invoice Safety Check", command=lambda: (notebook.select(tax_tab), set_pretty_report(tax_text, format_invoice_safety_check(db.invoice_safety_check()), readonly=True)))
    help_menu = tk.Menu(menubar, tearoff=0, bg=SENTINEL_THEME["panel"], fg=SENTINEL_THEME["text"], activebackground=SENTINEL_THEME["gold"], activeforeground=SENTINEL_THEME["header"])
    help_menu.add_command(label="Manual", command=show_manual_home); help_menu.add_command(label="Security Status", command=lambda: show_json("SECURITY STATUS", db.security_status())); help_menu.add_command(label="Hotkeys", command=lambda: show_json("HOTKEYS", HOTKEY_STATUS)); help_menu.add_command(label="Inventory Bridge Status", command=lambda: show_json("INVENTORY BRIDGE STATUS", db.inventory_bridge_status(write_contract=True))); help_menu.add_command(label="AEGIS Capabilities", command=lambda: show_json("AEGIS CAPABILITIES", db.aegis_capability_manifest())); help_menu.add_command(label="AEGIS Readiness", command=lambda: show_json("AEGIS READINESS", db.aegis_readiness())); help_menu.add_command(label="Sentinel Command Status", command=lambda: show_json("SENTINEL COMMAND STATUS", db.sentinel_command_status(write_contract=True))); help_menu.add_command(label="AEGIS Report Index", command=lambda: show_json("AEGIS REPORT INDEX", db.aegis_report_index())); help_menu.add_command(label="AEGIS Risk Flags", command=lambda: show_json("AEGIS RISK FLAGS", db.aegis_risk_flags())); help_menu.add_command(label="Backup Schedule", command=show_backup_schedule_gui); help_menu.add_command(label="About", command=lambda: messagebox.showinfo(APP_NAME, f"{APP_NAME} v{VERSION}\nProgram {PROGRAM_ID}\nLocal-only business ledger."))
    menubar.add_cascade(label="File", menu=file_menu); menubar.add_cascade(label="Ledger", menu=ledger_menu); menubar.add_cascade(label="Records", menu=records_menu); menubar.add_cascade(label="Reports", menu=reports_menu); menubar.add_cascade(label="Taxes", menu=taxes_menu); menubar.add_cascade(label="Settings", menu=settings_menu); menubar.add_cascade(label="Help", menu=help_menu)
    root.config(menu=menubar)

    header = ttk.Frame(root, padding=(14,12), style="SentinelHeader.TFrame"); header.pack(fill="x")
    ttk.Label(header, text=APP_NAME, style="SentinelTitle.TLabel").pack(side="left")
    active_ledger_label = ttk.Label(header, text=f"Program {PROGRAM_ID} · v{VERSION} · Active ledger: {db.get_business_profile().get('business_name') or db.db_path.stem} · {THEME_NAME} · local SQLite · {db.db_path.name}", style="SentinelSubTitle.TLabel", padding=(14,5)); active_ledger_label.pack(side="left")

    notebook = ttk.Notebook(root, style="Sentinel.TNotebook"); notebook.pack(fill="both", expand=True, padx=12, pady=12)
    dash = ttk.Frame(notebook, padding=10, style="SentinelPanel.TFrame"); notebook.add(dash, text="Dashboard")
    taxbar = ttk.Frame(dash, style="SentinelPanel.TFrame"); taxbar.pack(fill="x", pady=(0,6))
    ttk.Button(taxbar, text="Refresh", command=refresh_dashboard, style="Sentinel.TButton").pack(side="left", padx=4)
    ttk.Button(taxbar, text="Taxes", command=show_bas_report, style="SentinelAccent.TButton").pack(side="left", padx=4)
    ttk.Button(taxbar, text="Search Records / Receipts", command=search_records_dialog, style="Sentinel.TButton").pack(side="left", padx=4)
    summary = tk.Label(taxbar, text="", justify="right", anchor="e", bg=SENTINEL_THEME["header"], fg=SENTINEL_THEME["gold_light"], padx=10, pady=6, font=("Sans", 9, "bold"))
    summary.pack(side="right", fill="x", expand=True, padx=(12,4))
    split = ttk.PanedWindow(dash, orient="horizontal"); split.pack(fill="both", expand=True, pady=6)
    sales_frame = ttk.Labelframe(split, text="Sales", style="Sentinel.TLabelframe", padding=6); expenses_frame = ttk.Labelframe(split, text="Expenses", style="Sentinel.TLabelframe", padding=6)
    split.add(sales_frame, weight=1); split.add(expenses_frame, weight=1)
    sales_tree = ttk.Treeview(sales_frame, columns=("id","date","ref","desc","total"), show="headings", height=14, style="Sentinel.Treeview")
    expenses_tree = ttk.Treeview(expenses_frame, columns=("id","date","ref","desc","total"), show="headings", height=14, style="Sentinel.Treeview")
    for tree in (sales_tree, expenses_tree):
        for col,label,width in [("id","ID",55),("date","Date",105),("ref","Ref",145),("desc","Description",290),("total","Total",95)]:
            tree.heading(col, text=label); tree.column(col, width=width, anchor="w")
        tree.pack(fill="both", expand=True)
        tree.bind("<Double-1>", lambda e, t=tree: open_selected(t))
        tree.bind("<Button-3>", lambda e, t=tree: show_context_menu(e, t))

    sale_tab = ttk.Frame(notebook, padding=12, style="SentinelPanel.TFrame"); notebook.add(sale_tab, text="Quick Sale")
    sale_vars = {k: tk.StringVar(value=v) for k,v in {"amount":"","description":"","date":display_date(today()),"tax_rate":"10%","tax_mode":"inclusive","customer":"","source_ref":""}.items()}
    sale_vars["source_ref"].set(db.next_reference("quick_sale"))
    sale_outer = ttk.Frame(sale_tab, style="SentinelPanel.TFrame"); sale_outer.pack(fill="both", expand=True)
    sale_form_panel = ttk.Labelframe(sale_outer, text="Sale Details", style="Sentinel.TLabelframe", padding=8); sale_form_panel.pack(side="left", fill="y", padx=(0,12), anchor="n")
    make_form(sale_form_panel, [("Amount", sale_vars["amount"]),("Description", sale_vars["description"]),("Date", sale_vars["date"]),("Tax rate", sale_vars["tax_rate"]),("Tax mode", sale_vars["tax_mode"]),("Customer", sale_vars["customer"]),("Source ref", sale_vars["source_ref"])], width=13)
    ttk.Button(sale_form_panel, text="Record Sale", command=save_sale, style="SentinelAccent.TButton").pack(anchor="w", pady=8)
    preview_panel = ttk.Labelframe(sale_outer, text="Live Receipt Preview", style="Sentinel.TLabelframe", padding=6); preview_panel.pack(side="left", fill="both", expand=True)
    receipt_preview = tk.Text(preview_panel, wrap="word", height=18, bg=SENTINEL_THEME["report_bg"], fg=SENTINEL_THEME["report_text"], insertbackground=SENTINEL_THEME["cyan"], selectbackground=SENTINEL_THEME["cyan"], selectforeground=SENTINEL_THEME["header"], relief="flat", borderwidth=0, padx=14, pady=12, font=("DejaVu Sans Mono", 10))
    receipt_preview.pack(fill="both", expand=True, padx=1, pady=1); configure_report_text(receipt_preview); bind_text_clipboard(receipt_preview, allow_paste=False)
    for _v in sale_vars.values():
        _v.trace_add("write", refresh_sale_preview)
    refresh_sale_preview()

    exp_tab = ttk.Frame(notebook, padding=12, style="SentinelPanel.TFrame"); notebook.add(exp_tab, text="Quick Expense")
    exp_vars = {k: tk.StringVar(value=v) for k,v in {"amount":"","description":"","date":display_date(today()),"tax_rate":"10%","tax_mode":"inclusive","supplier":"","expense_account":"5000","source_ref":""}.items()}
    exp_vars["source_ref"].set(db.next_reference("quick_expense"))
    exp_outer = ttk.Frame(exp_tab, style="SentinelPanel.TFrame"); exp_outer.pack(fill="both", expand=True)
    exp_form_panel = ttk.Labelframe(exp_outer, text="Expense Details", style="Sentinel.TLabelframe", padding=8); exp_form_panel.pack(side="left", fill="y", padx=(0,12), anchor="n")
    make_form(exp_form_panel, [("Amount", exp_vars["amount"]),("Description", exp_vars["description"]),("Date", exp_vars["date"]),("Tax rate", exp_vars["tax_rate"]),("Tax mode", exp_vars["tax_mode"]),("Supplier", exp_vars["supplier"]),("Expense account", exp_vars["expense_account"]),("Source ref", exp_vars["source_ref"])], width=13)
    ttk.Button(exp_form_panel, text="Record Expense", command=save_expense, style="SentinelAccent.TButton").pack(anchor="w", pady=8)
    exp_preview_panel = ttk.Labelframe(exp_outer, text="Expense Review / Deduction Prep", style="Sentinel.TLabelframe", padding=6); exp_preview_panel.pack(side="left", fill="both", expand=True)
    expense_preview = tk.Text(exp_preview_panel, wrap="word", height=18, bg=SENTINEL_THEME["report_bg"], fg=SENTINEL_THEME["report_text"], insertbackground=SENTINEL_THEME["cyan"], selectbackground=SENTINEL_THEME["cyan"], selectforeground=SENTINEL_THEME["header"], relief="flat", borderwidth=0, padx=14, pady=12, font=("DejaVu Sans Mono", 10))
    expense_preview.pack(fill="both", expand=True, padx=1, pady=1); configure_report_text(expense_preview); bind_text_clipboard(expense_preview, allow_paste=False)
    for _v in exp_vars.values():
        _v.trace_add("write", refresh_expense_preview)
    refresh_expense_preview()

    receipt_tab = ttk.Frame(notebook, padding=12, style="SentinelPanel.TFrame"); notebook.add(receipt_tab, text="Receipt Creator")
    tpl = db.receipt_template()
    receipt_vars = {
        "header": tk.StringVar(value=tpl.get("header", "")),
        "business_details": tk.StringVar(value=tpl.get("business_details", "")),
        "footer": tk.StringVar(value=tpl.get("footer", "")),
        "advert": tk.StringVar(value=tpl.get("advert", "")),
    }
    receipt_outer = ttk.Frame(receipt_tab, style="SentinelPanel.TFrame"); receipt_outer.pack(fill="both", expand=True)
    receipt_form = ttk.Labelframe(receipt_outer, text="Receipt Template", style="Sentinel.TLabelframe", padding=8); receipt_form.pack(side="left", fill="y", padx=(0,12), anchor="n")
    make_form(receipt_form, [("Header", receipt_vars["header"]),("Business details", receipt_vars["business_details"]),("Footer", receipt_vars["footer"]),("Advertise here", receipt_vars["advert"])], width=42)
    receipt_preview_frame = ttk.Labelframe(receipt_outer, text="Template Preview", style="Sentinel.TLabelframe", padding=6); receipt_preview_frame.pack(side="left", fill="both", expand=True)
    receipt_template_preview = tk.Text(receipt_preview_frame, wrap="word", height=18, bg=SENTINEL_THEME["report_bg"], fg=SENTINEL_THEME["report_text"], insertbackground=SENTINEL_THEME["cyan"], selectbackground=SENTINEL_THEME["cyan"], selectforeground=SENTINEL_THEME["header"], relief="flat", borderwidth=0, padx=14, pady=12, font=("DejaVu Sans Mono", 10))
    receipt_template_preview.pack(fill="both", expand=True, padx=1, pady=1); configure_report_text(receipt_template_preview); bind_text_clipboard(receipt_template_preview, allow_paste=False)
    def refresh_receipt_template_preview(*_):
        sample = db.draft_receipt_preview("110.00", "Sample repair sale", today(), "10%", "inclusive", "Sample customer", db.next_reference("quick_sale"))
        for key, var in receipt_vars.items():
            sample = sample.replace(tpl.get(key, ""), var.get()) if tpl.get(key, "") else sample
        receipt_template_preview.configure(state="normal"); receipt_template_preview.delete("1.0", "end"); receipt_template_preview.insert("end", sample); receipt_template_preview.configure(state="disabled")
    def save_receipt_template():
        try:
            db.update_receipt_template(receipt_vars["header"].get(), receipt_vars["business_details"].get(), receipt_vars["footer"].get(), receipt_vars["advert"].get())
            refresh_receipt_template_preview(); refresh_sale_preview(); status_line("Receipt template saved")
            messagebox.showinfo(APP_NAME, "Receipt template saved and applied to the live Quick Sale preview.", parent=root)
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc), parent=root)
    ttk.Button(receipt_form, text="Save Receipt Template", command=save_receipt_template, style="SentinelAccent.TButton").pack(anchor="w", pady=8)
    for _v in receipt_vars.values():
        _v.trace_add("write", refresh_receipt_template_preview)
    refresh_receipt_template_preview()

    customer_tab = ttk.Frame(notebook, padding=10, style="SentinelPanel.TFrame"); notebook.add(customer_tab, text="Customers")
    customer_bar = ttk.Frame(customer_tab, style="SentinelPanel.TFrame"); customer_bar.pack(fill="x", pady=(0,8))
    ttk.Button(customer_bar, text="Add Customer", command=lambda: add_contact_window("customer"), style="SentinelAccent.TButton").pack(side="left", padx=4)
    ttk.Button(customer_bar, text="Refresh", command=refresh_contact_tabs, style="Sentinel.TButton").pack(side="left", padx=4)
    ttk.Label(customer_bar, text="Registered customers · double-click a row to see remembered sales/orders", style="SentinelStatus.TLabel").pack(side="left", padx=10)
    customer_tree = ttk.Treeview(customer_tab, columns=("id","name","email","phone","records","last","total"), show="headings", style="Sentinel.Treeview")
    for col,label,width in [("id","ID",55),("name","Customer",240),("email","Email",220),("phone","Phone",130),("records","Records",75),("last","Last",105),("total","Total",110)]:
        customer_tree.heading(col, text=label); customer_tree.column(col, width=width, anchor="w")
    customer_tree.pack(fill="both", expand=True)
    customer_tree.bind("<Double-1>", lambda e: show_contact_history_window(selected_contact_id(customer_tree), "customer") if selected_contact_id(customer_tree) else None)

    supplier_tab = ttk.Frame(notebook, padding=10, style="SentinelPanel.TFrame"); notebook.add(supplier_tab, text="Suppliers")
    supplier_bar = ttk.Frame(supplier_tab, style="SentinelPanel.TFrame"); supplier_bar.pack(fill="x", pady=(0,8))
    ttk.Button(supplier_bar, text="Add Supplier", command=lambda: add_contact_window("supplier"), style="SentinelAccent.TButton").pack(side="left", padx=4)
    ttk.Button(supplier_bar, text="Refresh", command=refresh_contact_tabs, style="Sentinel.TButton").pack(side="left", padx=4)
    ttk.Label(supplier_bar, text="Registered suppliers · double-click a row to see remembered expenses/bills", style="SentinelStatus.TLabel").pack(side="left", padx=10)
    supplier_tree = ttk.Treeview(supplier_tab, columns=("id","name","email","phone","records","last","total"), show="headings", style="Sentinel.Treeview")
    for col,label,width in [("id","ID",55),("name","Supplier",240),("email","Email",220),("phone","Phone",130),("records","Records",75),("last","Last",105),("total","Total",110)]:
        supplier_tree.heading(col, text=label); supplier_tree.column(col, width=width, anchor="w")
    supplier_tree.pack(fill="both", expand=True)
    supplier_tree.bind("<Double-1>", lambda e: show_contact_history_window(selected_contact_id(supplier_tree), "supplier") if selected_contact_id(supplier_tree) else None)

    acc_tab = ttk.Frame(notebook, padding=10, style="SentinelPanel.TFrame"); notebook.add(acc_tab, text="Accounts")
    acc_tree = ttk.Treeview(acc_tab, columns=("code","name","type","active"), show="headings", style="Sentinel.Treeview")
    for col,label,width in [("code","Code",90),("name","Name",420),("type","Type",120),("active","Active",80)]: acc_tree.heading(col, text=label); acc_tree.column(col, width=width)
    acc_tree.pack(fill="both", expand=True)
    ttk.Button(acc_tab, text="Refresh Accounts", command=refresh_accounts, style="Sentinel.TButton").pack(anchor="e", pady=8)

    rep_tab = ttk.Frame(notebook, padding=10, style="SentinelPanel.TFrame"); notebook.add(rep_tab, text="Reports")
    shell = tk.Frame(rep_tab, bg=SENTINEL_THEME["report_border"], bd=0, highlightthickness=1, highlightbackground=SENTINEL_THEME["cyan"]); shell.pack(fill="both", expand=True)
    report_text = tk.Text(shell, wrap="word", height=22, bg=SENTINEL_THEME["report_bg"], fg=SENTINEL_THEME["report_text"], insertbackground=SENTINEL_THEME["cyan"], selectbackground=SENTINEL_THEME["cyan"], selectforeground=SENTINEL_THEME["header"], relief="flat", borderwidth=0, highlightthickness=0, padx=14, pady=12, font=("DejaVu Sans Mono", 10)); report_text.pack(fill="both", expand=True, padx=1, pady=1); configure_report_text(report_text); bind_text_clipboard(report_text, allow_paste=False)
    set_report_lines(report_text, "SENTINEL LEDGER REPORT WINDOW", [("Theme", THEME_NAME), ("Mode", "Read-only local reports"), ("Tax tools", "Moved to separate Taxes tab"), ("Accountant handover", "Use Save Accountant Handover Report")], readonly=True)
    btns = ttk.Frame(rep_tab, style="SentinelPanel.TFrame"); btns.pack(fill="x", pady=8)
    report_button_rows = [
        [("Trial Balance", show_trial_balance_report, "Sentinel.TButton"), ("Profit / Loss", show_profit_loss_report, "Sentinel.TButton"), ("Balance Sheet", show_balance_sheet_report, "Sentinel.TButton"), ("Integrity", lambda: show_json("LEDGER INTEGRITY", db.integrity_check()), "Sentinel.TButton"), ("Deep Integrity", show_deep_integrity_gui, "Sentinel.TButton"), ("AEGIS Health", lambda: show_json("AEGIS HEALTH JSON", db.health()), "Sentinel.TButton")],
        [("Recovery Report", show_recovery_report_gui, "SentinelAccent.TButton"), ("Restore Wizard", show_restore_wizard_status_gui, "Sentinel.TButton"), ("Backup Schedule", show_backup_schedule_gui, "Sentinel.TButton"), ("Accountant Handover", save_accountant_bas_report_gui, "SentinelAccent.TButton"), ("Backup JSON", gui_backup, "Sentinel.TButton"), ("Export CSV", gui_export, "Sentinel.TButton")],
    ]
    for row_specs in report_button_rows:
        row_frame = ttk.Frame(btns, style="SentinelPanel.TFrame"); row_frame.pack(fill="x", pady=2)
        for label, cmd, sty in row_specs:
            ttk.Button(row_frame, text=label, command=cmd, style=sty).pack(side="left", padx=4, expand=True, fill="x")

    tax_tab = ttk.Frame(notebook, padding=10, style="SentinelPanel.TFrame"); notebook.add(tax_tab, text="Taxes")
    period_bar = ttk.Frame(tax_tab, style="SentinelPanel.TFrame"); period_bar.pack(fill="x", pady=(0,8))
    period_start_var = tk.StringVar(value="")
    period_end_var = tk.StringVar(value="")
    ttk.Label(period_bar, text="Period start", style="SentinelBody.TLabel").pack(side="left", padx=(0,6))
    tk.Entry(period_bar, textvariable=period_start_var, bg=SENTINEL_THEME["field"], fg=SENTINEL_THEME["field_text"], insertbackground=SENTINEL_THEME["cyan"], relief="solid", bd=1, highlightthickness=1, highlightbackground=SENTINEL_THEME["gold"], highlightcolor=SENTINEL_THEME["cyan"], width=14).pack(side="left", padx=(0,12))
    ttk.Label(period_bar, text="Period end", style="SentinelBody.TLabel").pack(side="left", padx=(0,6))
    tk.Entry(period_bar, textvariable=period_end_var, bg=SENTINEL_THEME["field"], fg=SENTINEL_THEME["field_text"], insertbackground=SENTINEL_THEME["cyan"], relief="solid", bd=1, highlightthickness=1, highlightbackground=SENTINEL_THEME["gold"], highlightcolor=SENTINEL_THEME["cyan"], width=14).pack(side="left", padx=(0,12))
    ttk.Label(period_bar, text="DD/MM/YYYY display · YYYY-MM-DD also accepted · blank = all records", style="SentinelStatus.TLabel").pack(side="left", padx=(0,6))
    tax_shell = tk.Frame(tax_tab, bg=SENTINEL_THEME["report_border"], bd=0, highlightthickness=1, highlightbackground=SENTINEL_THEME["cyan"]); tax_shell.pack(fill="both", expand=True)
    tax_text = tk.Text(tax_shell, wrap="word", height=22, bg=SENTINEL_THEME["report_bg"], fg=SENTINEL_THEME["report_text"], insertbackground=SENTINEL_THEME["cyan"], selectbackground=SENTINEL_THEME["cyan"], selectforeground=SENTINEL_THEME["header"], relief="flat", borderwidth=0, highlightthickness=0, padx=14, pady=12, font=("DejaVu Sans Mono", 10)); tax_text.pack(fill="both", expand=True, padx=1, pady=1); configure_report_text(tax_text); bind_text_clipboard(tax_text, allow_paste=False)
    set_report_lines(tax_text, "SENTINEL LEDGER TAXES WINDOW", [("Purpose", "GST/BAS preparation tools"), ("Period", "Set start/end above"), ("Deductions", "Checklist for accountant preparation"), ("Note", "Preparation only, not lodgement")], readonly=True)
    tax_btns = ttk.Frame(tax_tab, style="SentinelPanel.TFrame"); tax_btns.pack(fill="x", pady=8)
    ttk.Button(tax_btns, text="Tax / BAS Worksheet", command=show_bas_report, style="SentinelAccent.TButton").pack(side="left", padx=4)
    ttk.Button(tax_btns, text="GST / Tax Summary", command=show_tax_summary, style="Sentinel.TButton").pack(side="left", padx=4)
    ttk.Button(tax_btns, text="GST Status", command=lambda: (notebook.select(tax_tab), set_pretty_report(tax_text, format_gst_status(db.gst_status()), readonly=True)), style="Sentinel.TButton").pack(side="left", padx=4)
    ttk.Button(tax_btns, text="Invoice Safety", command=lambda: (notebook.select(tax_tab), set_pretty_report(tax_text, format_invoice_safety_check(db.invoice_safety_check()), readonly=True)), style="Sentinel.TButton").pack(side="left", padx=4)
    ttk.Button(tax_btns, text="Deductions Guide", command=show_deductions_guide, style="Sentinel.TButton").pack(side="left", padx=4)

    manual_tab = ttk.Frame(notebook, padding=10, style="SentinelPanel.TFrame"); notebook.add(manual_tab, text="Manual")
    manual_shell = tk.Frame(manual_tab, bg=SENTINEL_THEME["report_border"], bd=0, highlightthickness=1, highlightbackground=SENTINEL_THEME["cyan"]); manual_shell.pack(fill="both", expand=True)
    manual_text = tk.Text(manual_shell, wrap="word", height=22, bg=SENTINEL_THEME["report_bg"], fg=SENTINEL_THEME["report_text"], insertbackground=SENTINEL_THEME["cyan"], selectbackground=SENTINEL_THEME["cyan"], selectforeground=SENTINEL_THEME["header"], relief="flat", borderwidth=0, highlightthickness=0, padx=14, pady=12, font=("DejaVu Sans Mono", 10)); manual_text.pack(fill="both", expand=True, padx=1, pady=1); configure_report_text(manual_text); bind_text_clipboard(manual_text, allow_paste=True)
    set_pretty_report(manual_text, format_manual_text())
    manual_btns = ttk.Frame(manual_tab, style="SentinelPanel.TFrame"); manual_btns.pack(fill="x", pady=8)
    ttk.Button(manual_btns, text="Open Manual", command=show_manual_home, style="SentinelAccent.TButton").pack(side="left", padx=4)
    ttk.Button(manual_btns, text="Potential Deductions", command=show_deductions_guide, style="Sentinel.TButton").pack(side="left", padx=4)

    status = ttk.Label(root, text="", style="SentinelStatus.TLabel", anchor="w"); status.pack(fill="x", padx=12, pady=(0,8))
    refresh_dashboard(); refresh_accounts(); refresh_contact_tabs(); root.protocol("WM_DELETE_WINDOW", close_app)
    if not db.get_business_profile().get("business_name"):
        root.after(400, lambda: open_setup_wizard(True, blank=True))
    for seq, fn in [("<Control-q>", close_app),("<Control-Q>", close_app),("<Control-s>", save_active),("<Control-S>", save_active),("<Control-r>", refresh_active),("<Control-R>", refresh_active),("<Control-h>", health_hotkey),("<Control-H>", health_hotkey),("<Control-b>", backup_hotkey),("<Control-B>", backup_hotkey),("<Control-e>", export_hotkey),("<Control-E>", export_hotkey),("<Control-a>", text_select_all_hotkey),("<Control-A>", text_select_all_hotkey),("<Control-v>", text_paste_hotkey),("<Control-V>", text_paste_hotkey),("<Escape>", cancel_active),("<Return>", save_active),("<KP_Enter>", save_active)]:
        root.bind_all(seq, fn)
    status_line("Local-only bookkeeping · No cloud · No telemetry · AEGIS-readable health available")
    root.mainloop(); return 0

def apply_sentinel_theme(root, style) -> None:
    c = SENTINEL_THEME; root.configure(bg=c["bg"])
    style.configure(".", background=c["panel"], foreground=c["text"], fieldbackground=c["field"], bordercolor=c["gold"], lightcolor=c["cyan"], darkcolor=c["header"], font=("Sans", 10))
    style.configure("SentinelHeader.TFrame", background=c["header"])
    style.configure("SentinelPanel.TFrame", background=c["panel"])
    style.configure("SentinelTitle.TLabel", background=c["header"], foreground=c["gold_light"], font=("Sans", 20, "bold"))
    style.configure("SentinelSubTitle.TLabel", background=c["header"], foreground=c["cyan"], font=("Sans", 10))
    style.configure("SentinelBody.TLabel", background=c["panel"], foreground=c["text"], font=("Sans", 10))
    style.configure("SentinelForm.TLabel", background=c["panel"], foreground=c["muted"], font=("Sans", 10, "bold"))
    style.configure("SentinelStatus.TLabel", background=c["bg"], foreground=c["muted"], padding=(6,4))
    style.configure("Sentinel.TEntry", fieldbackground=c["field"], background=c["field"], foreground=c["field_text"], insertcolor=c["cyan"], bordercolor=c["gold"], lightcolor=c["cyan"], darkcolor=c["header"], padding=(5,3))
    style.map("Sentinel.TEntry", fieldbackground=[("focus", c["field"]), ("!disabled", c["field"])], foreground=[("!disabled", c["field_text"])], bordercolor=[("focus", c["cyan"]), ("!focus", c["gold"])])
    style.configure("TEntry", fieldbackground=c["field"], background=c["field"], foreground=c["field_text"], insertcolor=c["cyan"], bordercolor=c["gold"])
    style.configure("Sentinel.TButton", background=c["panel_alt"], foreground=c["text"], bordercolor=c["gold"], focusthickness=2, focuscolor=c["cyan"], padding=(10,5))
    style.map("Sentinel.TButton", background=[("active", c["gold"]), ("pressed", c["gold_light"])], foreground=[("active", c["header"]), ("pressed", c["header"])])
    style.configure("SentinelAccent.TButton", background=c["gold"], foreground=c["header"], bordercolor=c["cyan"], focusthickness=2, focuscolor=c["cyan"], padding=(12,6), font=("Sans", 10, "bold"))
    style.map("SentinelAccent.TButton", background=[("active", c["gold_light"]), ("pressed", c["cyan"])], foreground=[("active", c["header"]), ("pressed", c["header"])])
    style.configure("Sentinel.TNotebook", background=c["bg"], borderwidth=0)
    style.configure("Sentinel.TNotebook.Tab", background=c["panel_alt"], foreground=c["text"], padding=(12,6))
    style.map("Sentinel.TNotebook.Tab", background=[("selected", c["gold"]), ("active", c["panel"])], foreground=[("selected", c["header"]), ("active", c["cyan"])])
    style.configure("Sentinel.Treeview", background=c["report_bg"], foreground=c["report_text"], fieldbackground=c["report_bg"], bordercolor=c["gold"], lightcolor=c["cyan"], darkcolor=c["header"], rowheight=25)
    style.configure("Sentinel.Treeview.Heading", background=c["header"], foreground=c["gold_light"], bordercolor=c["gold"], font=("Sans", 10, "bold"))
    style.map("Sentinel.Treeview", background=[("selected", c["cyan"])], foreground=[("selected", c["header"])])
    style.configure("Sentinel.TLabelframe", background=c["panel"], foreground=c["gold_light"], bordercolor=c["gold"], relief="solid")
    style.configure("Sentinel.TLabelframe.Label", background=c["panel"], foreground=c["gold_light"], font=("Sans", 10, "bold"))

def configure_report_text(widget) -> None:
    c=SENTINEL_THEME; widget.configure(bg=c["report_bg"],fg=c["report_text"],insertbackground=c["cyan"],selectbackground=c["cyan"],selectforeground=c["header"])
    widget.tag_configure("heading",foreground=c["gold_light"],font=("DejaVu Sans Mono",12,"bold"),spacing3=8); widget.tag_configure("rule",foreground=c["gold"]); widget.tag_configure("label",foreground=c["cyan"],font=("DejaVu Sans Mono",10,"bold")); widget.tag_configure("value",foreground=c["report_text"]); widget.tag_configure("muted",foreground=c["muted"]); widget.tag_configure("ok",foreground=c["ok"],font=("DejaVu Sans Mono",10,"bold")); widget.tag_configure("warn",foreground=c["danger"],font=("DejaVu Sans Mono",10,"bold")); widget.tag_configure("json_key",foreground=c["cyan"]); widget.tag_configure("json_value",foreground=c["gold_light"])


def set_report_lines(widget, title: str, rows: list[tuple[str, str]], readonly: bool = False) -> None:
    widget.configure(state="normal"); widget.delete("1.0","end"); widget.insert("end",f"{title}\n","heading"); widget.insert("end","="*max(28,len(title))+"\n\n","rule")
    for label,value in rows:
        widget.insert("end",f"{label:<24}","label"); widget.insert("end",f" {value}\n","ok" if str(value).lower() in {"ok","ready","healthy","choose a report below"} else "value")
    widget.insert("end","\nLocal-only · No cloud · No telemetry\n","muted"); widget.configure(state="disabled" if readonly else "normal")


def set_json_report(widget, title: str, payload: dict) -> None:
    widget.configure(state="normal"); widget.delete("1.0","end"); widget.insert("end",f"{title}\n","heading"); widget.insert("end","="*max(28,len(title))+"\n\n","rule")
    for line in json.dumps(payload, indent=2).splitlines():
        if ':' in line:
            key,rest=line.split(':',1); widget.insert("end",key+':',"json_key"); widget.insert("end",rest+"\n","json_value")
        else: widget.insert("end",line+"\n","muted")
    widget.configure(state="disabled")


def make_form(parent, fields, width: int = 52):
    from tkinter import ttk
    frame=ttk.Frame(parent,style="SentinelPanel.TFrame"); frame.pack(anchor="w",fill="x")
    entries = []
    for i,(label,var) in enumerate(fields):
        ttk.Label(frame,text=label,width=18,style="SentinelForm.TLabel").grid(row=i,column=0,sticky="w",pady=4)
        ent=ttk.Entry(frame,textvariable=var,width=width,style="Sentinel.TEntry")
        ent.grid(row=i,column=1,sticky="we",pady=4)
        entries.append(ent)
    frame.columnconfigure(1,weight=0 if width <= 16 else 1)
    return entries


if __name__ == "__main__":
    raise SystemExit(command_main())
