# Sentinel Ledger Manual — v1.0.1

Sentinel Ledger is Program 107 in the Sentinel Desktop Suite. It is a local SQLite double-entry ledger for small-business bookkeeping, receipts, GST/BAS preparation, accountant handoff reports, and local backup/recovery workflows.

## First run

```bash
sentinel-ledger init
sentinel-ledger gui
```

For additional businesses, create named profiles:

```bash
sentinel-ledger create-ledger repairs --business-name "Repairs"
sentinel-ledger --ledger repairs gui
```

## Recording work

```bash
sentinel-ledger quick-sale 110.00 "Repair job" --tax-rate 10% --tax-mode inclusive
sentinel-ledger quick-expense 55.00 "Parts" --tax-rate 10% --tax-mode inclusive
sentinel-ledger receipt 1
```

## Backups and restore

Use regular JSON backups and accountant/archive packs:

```bash
sentinel-ledger backup-json
sentinel-ledger restore-check ~/AEGIS_Vault/07_Financial/Sentinel_Ledger/sentinel_ledger_backup_YYYYMMDD_HHMMSS.json
sentinel-ledger full-archive-export
sentinel-ledger portable-restore-pack
```

Restore always targets a new database path. v1.0.1 refuses restoring over the active ledger and rejects malformed backup table/column layouts.

## Password-protected backups

Do not place backup passwords directly in shell commands. Use stdin, a private file, or prompt mode:

```bash
printf '%s' 'backup password' | sentinel-ledger encrypted-backup --password @-
sentinel-ledger encrypted-backup
```

## Root/sudo warning

Do not run the ledger as root. v1.0.1 blocks write actions when launched as root unless `SENTINEL_LEDGER_ALLOW_ROOT_WRITE=1` is set for controlled package validation.

## AEGIS/Sentinel Command boundary

AEGIS/Sentinel Command integration is for local read-only status, summaries, readiness, risk flags, report indexes, metadata indexing, and explicit user-approved workflows. It must not silently mutate financial records.
