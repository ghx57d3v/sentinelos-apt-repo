# Sentinel Ledger v1.0.1 — Redteam Security Cleanup Report

## Verdict

The uploaded v1.0.0 source was a strong local-first bookkeeping baseline, but it was **not safe enough to remain untouched as the finance-suite baseline**. The main concerns were not network behaviour; the risks were local host/user-data hazards around secrets, restores, symlinks, root execution, and WAL-mode raw database snapshots.

v1.0.1 is the recommended safer baseline.

## Findings and fixes

### High — direct command-line password exposure

v1.0.0 accepted `--password` values directly for ledger lock and encrypted backup commands. These values can leak through shell history, terminal scrollback, process listings, crash logs, or support screenshots.

**Fix:** direct argv secrets are refused. Supported secret sources are now:

- omitted `--password` → interactive prompt
- `--password @-` → stdin
- `--password @/private/file` → private non-symlink file with no group/world access

### High — restore path could overwrite or damage the wrong file

`restore-json --force` could overwrite any chosen output path and did not explicitly block restoring over the active ledger database.

**Fix:** restore now refuses symlink outputs, refuses active ledger overwrite, requires a database-like suffix, restores into a temporary database first, validates it, then atomically publishes it.

### High — backup JSON restore trusted backup column names

The restore engine used column names from the JSON backup when constructing SQL insert statements. Even though Python sqlite blocks multi-statement execution, this still allowed malformed backups to break restore integrity or produce confusing failure modes.

**Fix:** restore-check now validates table names, row structure, row counts, and column names against the target schema before restore. Restore also repeats strict validation before writing.

### Medium/High — symlink overwrite hazards in export/backup/report/receipt/metadata paths

Several output functions used direct `write_text`/CSV writes. If an output file path was replaced by a symlink, the ledger could overwrite an unintended target.

**Fix:** output writes now use symlink/ancestor checks plus atomic private writes for backups, exports, reports, receipts, metadata contracts, and Desktop launcher repair.

### Medium — raw SQLite copies could miss WAL-mode data

The app uses SQLite WAL mode. Copying only the main `.db` file can miss transactions still represented by the WAL file.

**Fix:** raw SQLite snapshots now use the SQLite backup API.

### Medium — CSV import could queue oversized/unbounded files

CSV import accepted arbitrary regular input size and row count.

**Fix:** v1.0.1 adds file-size, symlink, regular-file, and row-count guards.

### Medium — running as root can damage user ledger ownership

Running GUI/CLI write actions with sudo can create root-owned ledger files under user paths and widen the blast radius of path mistakes.

**Fix:** v1.0.1 refuses write actions as root by default. Controlled package validation can set `SENTINEL_LEDGER_ALLOW_ROOT_WRITE=1`.

### Low/Medium — symlinked document references could hash unexpected files

Document linking could follow symlinked evidence paths and hash/index the target rather than the visible path.

**Fix:** v1.0.1 refuses symlinked document reference paths.

## Remaining note

The password-protected backup container still uses a dependency-free stream/HMAC construction rather than a modern external AEAD library such as libsodium or cryptography. v1.0.1 reduces secret exposure and hardens the container handling, but a future v1.1+ crypto uplift should replace the custom cipher format with a standard audited AEAD if external dependencies become acceptable.
