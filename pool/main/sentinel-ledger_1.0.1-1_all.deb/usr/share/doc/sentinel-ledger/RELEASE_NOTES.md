# Sentinel Ledger v1.0.1 — Release Notes

This is a redteam/security cleanup hotfix over v1.0.0.

## Upgrade reason

Upgrade to v1.0.1 if you use Ledger for real finance data. It fixes local data-loss and leakage risks around command-line passwords, symlinked output paths, JSON restore validation, root execution, and raw SQLite snapshot consistency.

## Compatibility

The database schema remains `13`; v1.0.1 preserves the v1.0.0 ledger format.

## Behaviour changes

Direct password arguments are refused:

```bash
sentinel-ledger encrypted-backup --password mysecret
```

Use one of these instead:

```bash
sentinel-ledger encrypted-backup
printf '%s' 'mysecret' | sentinel-ledger encrypted-backup --password @-
sentinel-ledger encrypted-backup --password @/home/$USER/private-ledger-backup-password.txt
```

Write actions are refused when the app is launched as root unless `SENTINEL_LEDGER_ALLOW_ROOT_WRITE=1` is deliberately set for controlled validation.
