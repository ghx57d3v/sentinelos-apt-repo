# Sentinel Ledger Changelog

## v1.0.1 — Redteam Security Cleanup Hotfix

- Refuses direct argv secrets for ledger lock and encrypted-backup commands; use `@-`, `@/private/file`, or interactive prompt instead.
- Adds guarded root-write refusal to prevent accidental sudo/root finance-data mutation and root-owned user ledgers.
- Hardens JSON backup/restore with strict table/column validation, size limits, symlink refusal, active-ledger overwrite refusal, atomic restore-to-new-database, and post-restore foreign-key checks.
- Hardens backup/export/report/receipt/metadata writes with symlink/ancestor checks and atomic private writes.
- Uses SQLite backup API for raw database snapshots so WAL-mode ledgers are copied consistently.
- Adds CSV import symlink, file-size, and row-count protections.
- Refuses symlinked document references to avoid indexing or hashing an unexpected target.
- Cleans package layout and removes bytecode/build clutter.

## v1.0.0 — User Ready Baseline

- Promoted Program 107 Sentinel Ledger from v0.9.5 release candidate to v1.0.0 stable baseline.
- Added `stable-status` for v1 readiness and stable-lock reporting.
- Preserved DD/MM/YYYY display dates with YYYY-MM-DD internal storage.
- Locked local-first / no-cloud / no-telemetry / explicit-write-approval doctrine.
- Preserved AEGIS/Sentinel Command read-only inspection and metadata contracts.
- Updated README, Manual, AEGIS manifest, and release metadata for v1.0.0.
