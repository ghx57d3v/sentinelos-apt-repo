# Sentinel Ledger v1.0.1

Program 107 — Sentinel Ledger is the local-first business bookkeeping application for SentinelOS / AEGIS.

v1.0.1 is a **Redteam Security Cleanup Hotfix** over the v1.0.0 User Ready Baseline. It preserves the local SQLite double-entry ledger, Sentinel/AEGIS GUI, multi-ledger business profiles, setup wizard, receipts, receipt designer, customer/supplier registry, invoice and supplier bill workflows, GST/BAS preparation, accountant handoff reports, import/export packs, AEGIS metadata, Sentinel Command contracts, inventory bridge contract, and workflow hotkeys.

## Security cleanup highlights

- Do not pass ledger-lock or backup passwords directly in command-line arguments.
- Use `@-` for stdin, `@/private/file` for a private non-symlink file, or omit `--password` for an interactive prompt.
- Backup, export, receipt, report, restore, metadata, and Desktop launcher writes now refuse symlink targets and use safer private writes.
- JSON restore now validates table names, column names, file size, active-ledger overwrite attempts, and restored foreign keys before publishing the restored database.
- Running write actions as root is refused by default to avoid root-owned user ledgers and widened blast radius. Package validation may explicitly set `SENTINEL_LEDGER_ALLOW_ROOT_WRITE=1`.

## Safe password examples

```bash
printf '%s' 'backup password here' | sentinel-ledger encrypted-backup --password @-

chmod 600 ~/ledger-backup-password.txt
sentinel-ledger encrypted-backup --password @/home/$USER/ledger-backup-password.txt
```

Unsafe direct argv secrets are refused:

```bash
sentinel-ledger encrypted-backup --password mysecret
```

## Date display

User-facing dates display as **DD/MM/YYYY**. Internal database storage remains **YYYY-MM-DD** for safe sorting and filtering.

## Safety boundary

Sentinel Ledger is not a tax lodgement tool. It prepares reports, records, receipt indexes, suggested deduction checklists, and accountant handoff packs for review. AEGIS/Sentinel Command may inspect, summarize, warn, and index metadata, but financial record changes require explicit user action.

## Useful commands

```bash
sentinel-ledger gui
sentinel-ledger stable-status
sentinel-ledger health
sentinel-ledger security-status
sentinel-ledger accountant-bas-report --start 01/07/2025 --end 30/06/2026 --include-suggested-deductions
sentinel-ledger full-archive-export
sentinel-ledger portable-restore-pack
```
