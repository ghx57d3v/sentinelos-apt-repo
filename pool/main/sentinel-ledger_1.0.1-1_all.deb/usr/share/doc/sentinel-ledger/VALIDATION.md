# Sentinel Ledger v1.0.1 — Validation Report

Validation was run in the sandbox against the patched source.

## Passed

- Python compile check
- Database initialization
- Quick sale workflow
- Quick expense workflow
- Invoice create/pay workflow
- Supplier bill create/pay workflow
- Basic integrity check
- Deep integrity check
- Security status JSON
- No-network static check
- Stable-status JSON
- JSON backup creation
- JSON restore-check
- Restore to new SQLite database
- Full archive export
- Portable restore pack
- CSV export
- Accountant BAS handoff report export
- Receipt generation
- Root write refusal regression
- Direct argv secret refusal regression
- Stdin secret source accepted for encrypted backup
- Symlink backup-output refusal regression
- Malicious restore-column refusal regression
- Active-ledger restore refusal regression
- CSV import symlink refusal regression
- Debian package rebuild
- Extracted package Python compile
- No packaged `.pyc` / `__pycache__`

## Validation notes

The sandbox runs as root, so normal write-flow validation used the explicit package-test override `SENTINEL_LEDGER_ALLOW_ROOT_WRITE=1`. A separate regression confirmed that without the override, root write actions are refused cleanly.
