# Sentinel Terminal v1.0.0

## Stable Lock

- First stable lock of the official SentinelOS terminal.
- Keeps MATE-like desktop-native behaviour without copying MATE Terminal compatibility.
- Keeps compact SentinelOS identity.
- Keeps dangerous paste and multiline paste warnings.
- Keeps v0.8.0 desktop integration and v0.9.0 root-banner removal.
- Adds final stable lock documentation and manual page.
- Freezes the current feature set for stable testing.
