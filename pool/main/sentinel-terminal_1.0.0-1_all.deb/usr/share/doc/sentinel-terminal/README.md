# Sentinel Terminal v1.0.0

Official lightweight SentinelOS terminal emulator.

## v1.0.0 Stable Lock

Sentinel Terminal v1.0.0 is the first stable lock of the official SentinelOS terminal.

This is not a MATE Terminal clone. It is a MATE-like, SentinelOS-native terminal: lightweight, desktop-integrated, tabbed, practical, and aligned with the SentinelOS/AEGIS local-first design.

## Stable feature set

- GTK3/VTE terminal foundation.
- Compact headerless UI.
- Compact tabs.
- Supplied Sentinel/AEGIS icon integration.
- Automatic terminal focus on startup, tab creation, and tab switching.
- `exit` closes the active tab; if it is the last tab, the app exits.
- Ctrl+C interrupt forwarding.
- Tabs, duplicate tab, rename tab, tab switching shortcuts.
- Session state handling.
- Preferences panel.
- Non-modal find bar.
- Find next / previous.
- Clear scrollback.
- Save terminal output.
- Open current folder in file manager.
- Warning-only dangerous paste protection.
- Multiline paste warning.
- No command logging by default.
- MATE/Caja "Open Sentinel Terminal Here".
- Desktop quick actions.
- Launcher repair helper.
- User launcher cleanup helper.
- Doctor, runtime-check, safe mode, reset config, GUI smoke test, AEGIS status JSON.
- Manual page.

## Install

```bash
sudo apt install ./sentinel-terminal_1.0.0-1_all.deb
sentinel-terminal-user-setup
sentinel-terminal-launcher-repair
sentinel-terminal-doctor
sentinel-terminal-runtime-check
```

## Stable test

```bash
sentinel-terminal --safe-mode
sentinel-terminal --gui-smoke-test
sentinel-terminal
```
