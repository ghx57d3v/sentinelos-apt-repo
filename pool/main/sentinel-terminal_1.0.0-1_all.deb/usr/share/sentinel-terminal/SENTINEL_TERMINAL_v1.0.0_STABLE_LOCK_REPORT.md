# Sentinel Terminal v1.0.0 — Stable Lock

## Stable Lock
- First stable lock of Program 106 Sentinel Terminal.
- MATE-like, SentinelOS-native terminal.
- Not a MATE Terminal compatibility clone.

## Preserved
- Desktop integration.
- Caja Open Sentinel Terminal Here.
- Launcher repair and user cleanup helpers.
- Dangerous paste and multiline paste warnings.
- Productivity tools.
- Session handling.
- Focus / exit / Ctrl+C behaviour.
- Preferences and runtime diagnostics.

## Added
- Stable lock metadata and documentation.
- Manual page.
- Stable lock self-test coverage.
