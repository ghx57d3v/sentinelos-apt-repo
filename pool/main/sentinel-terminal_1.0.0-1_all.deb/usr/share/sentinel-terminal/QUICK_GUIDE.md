# Sentinel Terminal Quick Guide

## Install user desktop integration

```bash
sentinel-terminal-user-setup
```

## Repair launchers

```bash
sentinel-terminal-launcher-repair
```

## Remove user-level launchers only

```bash
sentinel-terminal-user-cleanup
```

## Safety behaviour

```text
Top root/admin banner    removed
Dangerous paste          warns before risky command patterns
Multiline paste          warns before multi-command paste
Safety model             warn only; user remains in control
Command logging          off by default
```

## Caja integration

```text
Caja → Scripts → Open Sentinel Terminal Here
```

## Useful commands

```bash
sentinel-terminal --safe-mode
sentinel-terminal --reset-config
sentinel-terminal-doctor
sentinel-terminal-runtime-check
sentinel-terminal --gui-smoke-test
sentinel-terminal --aegis-status
```

## Core shortcuts

```text
Ctrl+Shift+T     new tab
Ctrl+Shift+D     duplicate tab
Ctrl+Shift+R     rename tab
Ctrl+Shift+W     close tab
Ctrl+C           interrupt active terminal task
Ctrl+Shift+C     copy
Ctrl+Shift+V     paste
Ctrl+Shift+F     find bar
F3               find next
Shift+F3         find previous
Ctrl+Shift+K     clear scrollback
Ctrl+Shift+S     save terminal output
Ctrl+Shift+O     open current folder
Ctrl+PageUp      previous tab
Ctrl+PageDown    next tab
Alt+1..Alt+9     switch directly to tab number
```
