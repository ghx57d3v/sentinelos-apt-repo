"""Sentinel Terminal package."""

VERSION = "1.0.0"
APP_ID = "sentinel-terminal"
APP_NAME = "Sentinel Terminal"
