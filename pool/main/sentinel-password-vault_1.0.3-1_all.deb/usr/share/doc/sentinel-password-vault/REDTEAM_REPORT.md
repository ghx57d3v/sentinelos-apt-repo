# Sentinel Password Vault v1.0.1 — Redteam Security Cleanup Report

## Verdict

`sentinel_password_vault_v1_0_0` was functionally strong for a local-first encrypted vault, but it had several security and reliability issues that should be fixed before treating it as a hardened Program 113 baseline. The most important risks were plaintext secrets accepted directly through command-line arguments, restore paths that accepted unvalidated `.spv` files, GUI lock semantics that did not clear unlocked session references, and browser-origin matching that used substring-style matching.

The v1.0.1 hotfix preserves the existing encrypted vault format and focuses on defensive hardening and code cleanup.

## Findings

### High — plaintext secrets accepted through process-list-visible argv

The v1.0.0 CLI accepted secret material through flags such as `--password`, `--browser-password`, `--totp-secret`, `--totp-uri`, and inline `--json-action` payloads containing `master_password` or saved passwords. Those values can leak through shell history, process listings, desktop launch logs, debugging output, or crash reports.

**Fix:** v1.0.1 refuses direct argv secrets by default and supports `@-` stdin or `@private-file` secret sources. Legacy argv secrets require explicit `SENTINEL_PASSWORD_VAULT_ALLOW_ARG_SECRETS=1`.

### High — restore accepted unvalidated backup paths

Local and AEGIS restore paths accepted direct paths and copied them over the active vault if `--yes` was supplied. A malformed or wrong file could corrupt the active vault. Symlink handling was also not explicit.

**Fix:** v1.0.1 validates encrypted `.spv` container schema, crypto markers, required fields, KDF iteration bounds, file type, size, and symlink status before restoring. Restore now writes through a private temporary file and atomically replaces the active vault.

### Medium — GUI lock did not purge unlocked session references

Returning to the lock screen removed the visible UI, but the session dictionary still retained decrypted vault data and the master password reference.

**Fix:** v1.0.1 clears `container`, `plain`, `master`, selected record, and clipboard state when the GUI returns to the lock screen.

### Medium — browser-origin matching could false-positive on substring/domain confusion

Matching logic used host/root substring checks. This could rank unrelated domains with lookalike names or embedded strings as possible matches.

**Fix:** v1.0.1 uses stricter host parsing, same-site/parent-domain checks, and token-boundary title/issuer matching. If a record has a URL host and it conflicts with the browser origin, it is not recommended as a match.

### Medium — root action surface was too broad

Root introspection allowed `--json-action`, `--aegis-action`, and `--write-manifest`. Those can perform action dispatch or arbitrary file writes and should not be part of the root-safe set for a password vault.

**Fix:** v1.0.1 removes those from root-allowed actions. Root remains for system installation and limited read-only/introspection checks only.

### Medium — `--init --force` could overwrite an existing vault without a backup

The previous force path could replace an active vault without first preserving the existing encrypted container.

**Fix:** v1.0.1 requires `--yes` with `--init --force` and creates an encrypted `before-force-init` backup before replacement.

### Low/Medium — symlink destinations for export/write operations

Metadata export, plaintext JSON export, and manifest writing could follow destination symlinks. Under normal-user permissions this is still user-scoped, but it is unsafe for a secrets tool.

**Fix:** v1.0.1 writes private files atomically and refuses symlink destinations.

### Low — messy metadata and package hygiene

Version strings, docs, and packaging metadata required refresh after hardening.

**Fix:** v1.0.1 refreshes version/package metadata, README, changelog, security notes, manifest, and package docs. No `.pyc`/`__pycache__` files are packaged.

## Remaining design notes

- The vault still supports plaintext JSON export for emergency migration. It remains intentionally gated behind `--yes`, writes mode `0600`, and should be deleted immediately after use.
- PBKDF2-HMAC-SHA256 at 390,000 iterations is acceptable as a compatibility baseline, but a future v1.x security upgrade could offer Argon2id migration if the target OS packaging supports it reliably.
- GUI memory clearing in Python cannot guarantee cryptographic zeroization, but v1.0.1 now drops references on lock and clears clipboard state, which is a meaningful practical improvement.

## Recommendation

Treat v1.0.1 as the safer Program 113 baseline over v1.0.0. Existing v1.0.0 vault containers remain compatible.
