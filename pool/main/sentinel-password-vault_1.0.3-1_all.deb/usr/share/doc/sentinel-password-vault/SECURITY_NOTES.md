# Security Notes — Sentinel Password Vault v1.0.1

- Do not pass passwords, TOTP secrets, TOTP URIs, browser passwords, or JSON payloads containing `master_password` directly on the command line.
- Use `@-` or `@private-file` secret sources.
- Plaintext JSON export still exists for emergency migration only; it requires `--yes`, writes `0600`, and should be deleted after use.
- Backup restore validates the encrypted `.spv` container before replacing the active vault.
- Root is for system installation only. Run vault operations as the normal desktop user.
