# Sentinel Password Vault v1.0.3 — Browser Save/Fill Integration

- Preserves the v1.0.1 redteam security-cleanup baseline.
- Adds restricted, Vault-owned exact-host credential selection for Sentinel Browser.
- Adds save-new and update-existing login workflows with cross-process file locking and encrypted write verification.
- Receives credential candidates through stdin JSON and returns an approved selected credential through one-shot stdout only.
- No password is placed in command-line arguments, audit logs, metadata output, or Browser storage.
- Filled Browser forms are never automatically submitted.

# Sentinel Password Vault v1.0.1

Program 113 — local-first encrypted password vault for SentinelOS / AEGIS.

This build is a redteam security cleanup hotfix over v1.0.0. It preserves the v1 encrypted vault format while hardening secret handling, restore safety, GUI lock behavior, and browser-integration matching.

## Security posture

- Local-only: no cloud, no telemetry, no network requirement.
- Encrypted vault: AES-256-GCM with PBKDF2-HMAC-SHA256.
- Master password is not stored on disk.
- Secret values are not written to audit logs.
- Plaintext command-line secret arguments are refused by default.

## Supplying secrets safely

Use stdin or a private file instead of passing secrets directly in argv:

```bash
printf '%s' 'secret-value' | sentinel-password-vault --add --password @-
printf '%s' 'browser-password' | sentinel-password-vault --browser-save-login --browser-password @- --yes
sentinel-password-vault --json-action @payload.json
```

Private secret files should be regular, non-symlink files readable only by the current user.

Legacy direct argv secrets can be temporarily allowed only with:

```bash
SENTINEL_PASSWORD_VAULT_ALLOW_ARG_SECRETS=1 sentinel-password-vault ...
```

That is for compatibility/testing only and is not recommended.

## Install

```bash
sudo ./install.sh --system
sentinel-password-vault-user-setup --clean-shadow
sentinel-password-vault --self-check
```

## Validate

```bash
sentinel-password-vault --version
sentinel-password-vault --self-check
sentinel-password-vault --stable-lock-report --no-unlock
```
