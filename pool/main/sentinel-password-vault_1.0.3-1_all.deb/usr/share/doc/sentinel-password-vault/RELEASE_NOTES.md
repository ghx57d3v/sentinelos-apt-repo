# Sentinel Password Vault v1.0.3 — Browser Save/Fill Integration

- Preserves the v1.0.1 redteam security-cleanup baseline.
- Adds restricted, Vault-owned exact-host credential selection for Sentinel Browser.
- Adds save-new and update-existing login workflows with cross-process file locking and encrypted write verification.
- Receives credential candidates through stdin JSON and returns an approved selected credential through one-shot stdout only.
- No password is placed in command-line arguments, audit logs, metadata output, or Browser storage.
- Filled Browser forms are never automatically submitted.

# Sentinel Password Vault v1.0.1 Release Notes

This is a focused redteam/security cleanup hotfix for Program 113. It does not change the encrypted vault container format. Existing v1.0.0 `.spv` vault files remain compatible.

Main improvements:

- safer secret ingress via `@-` and `@private-file`;
- direct argv secret refusal by default;
- validated, atomic backup restore;
- GUI lock now clears in-memory session references;
- safer browser-origin matching;
- root action surface reduced to read-only/introspection actions.
