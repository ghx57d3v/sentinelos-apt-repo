# Sentinel Password Vault v1.0.3 — Browser Save/Fill Integration

- Preserves the v1.0.1 redteam security-cleanup baseline.
- Adds restricted, Vault-owned exact-host credential selection for Sentinel Browser.
- Adds save-new and update-existing login workflows with cross-process file locking and encrypted write verification.
- Receives credential candidates through stdin JSON and returns an approved selected credential through one-shot stdout only.
- No password is placed in command-line arguments, audit logs, metadata output, or Browser storage.
- Filled Browser forms are never automatically submitted.

# Sentinel Password Vault Changelog

## v1.0.1 — Redteam Security Cleanup Hotfix

- Refuses plaintext secrets passed directly through process-list-visible command-line arguments by default.
- Adds `@-` stdin and `@private-file` secret-source support for password, browser-password, TOTP secret, TOTP URI, and sensitive JSON-action payloads.
- Blocks root execution of JSON/action and arbitrary manifest-write paths; root is now limited to read-only/introspection actions.
- Validates encrypted `.spv` containers before restoring local or AEGIS backups.
- Restores backups atomically and refuses symlink restore sources/destinations.
- Creates an encrypted backup before `--init --force` and requires `--yes`.
- Refuses symlink destinations for plaintext/metadata exports and manifest writes.
- Clears unlocked GUI session material when the user locks the vault.
- Tightens browser-origin matching to avoid substring/domain-confusion false positives.
- Removes stale build roots/bytecode and refreshes package metadata.

## v1.0.0

Initial stable Sentinel Password Vault baseline.
