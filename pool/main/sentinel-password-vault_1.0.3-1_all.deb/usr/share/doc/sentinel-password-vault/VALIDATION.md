# Sentinel Password Vault v1.0.1 — Validation

Validation performed in the sandbox against the patched source and rebuilt Debian package.

## Passed

- Python compile check for main CLI and doctor helper.
- Non-root self-check with isolated test HOME.
- Stable-lock report with `--no-unlock`.
- New vault initialization.
- Direct `--password directsecret` refusal after unlock.
- `--password @-` stdin secret acceptance after unlock.
- Direct `--browser-password browserdirect` refusal after unlock.
- Inline sensitive `--json-action` refusal with clean JSON error.
- `--json-action @private-file` acceptance.
- Valid encrypted backup creation and restore.
- Invalid `.spv` restore refusal before overwrite.
- Symlink export destination refusal.
- Browser-origin regression: `evilpaypal.com` no longer matches `paypal.com`; `accounts.paypal.com` does match `paypal.com`.
- Root `--json-action` refusal.
- Debian rebuild as `sentinel-password-vault_1.0.1-1_all.deb`.
- Extracted package Python compile check.
- Package inspection: no `.pyc` or `__pycache__`.

## Notes

- GUI live smoke testing was not performed in this container. The code path was statically reviewed and compile-checked; target package dependencies still include Tkinter, qrcode, PIL, and cryptography.
- The direct-argv secret refusal is intentionally breaking for unsafe legacy caller patterns. Callers should switch to `@-` stdin or private files.
