# Sentinel Calculator v1.1.1 Upgrade / Repair Guide

Install:

```bash
sudo apt install ./sentinel-calculator_1.1.1-1_all.deb
sentinel-calculator-user-setup
sentinel-calculator-doctor
```

Repair launchers:

```bash
sentinel-calculator-repair-user-system
sentinel-calculator-user-setup
```

Reset user settings if needed:

```bash
sentinel-calculator --reset-settings
```
