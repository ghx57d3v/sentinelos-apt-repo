# Sentinel Calculator Quick Guide — v1.1.1

## New in v1.1.1

- Market Exchange tab.
- Crypto reference price conversion using manual refresh.
- Stock/ETF quote lookup using manual refresh.
- Local market cache at `~/.local/share/sentinel-calculator/market_exchange_cache.json`.

## Common commands

```bash
sentinel-calculator
sentinel-calculator --safe-mode
sentinel-calculator --self-test
sentinel-calculator --gui-smoke-test
sentinel-calculator-doctor
```

## Market Exchange examples

Crypto:

```text
Type: Crypto
Amount: 1
Symbol / coin: BTC
Quote: AUD
```

Stock / ETF:

```text
Type: Stock / ETF
Amount: 10
Symbol: AAPL.US
Quote: USD
```

Market values are informational reference values only.
