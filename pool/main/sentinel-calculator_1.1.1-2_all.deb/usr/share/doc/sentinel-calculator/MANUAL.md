# Sentinel Calculator Manual — v1.1.1

## Overview

Sentinel Calculator provides calculator, converter, networking, defensive security, electronics, and optional market-reference tools in one SentinelOS / AEGIS themed desktop utility.

## Standard / Scientific

Use the expression field and keypad. Supported functions include `sqrt`, `sin`, `cos`, `tan`, `log`, `ln`, `abs`, `round`, and `fact`.

## Unit Converter

The Unit Converter is fully offline. Select a category, value, source unit, and destination unit, then click **Convert**.

Supported groups include length, area, volume, mass, speed, pressure, energy, power, data storage, time, temperature, and fuel economy.

## Currency Converter

The Currency Converter can refresh latest-available reference rates online and store them locally for cached conversion later.

Currency rates are reference data only. They may differ from bank, exchange, broker, card, or retail rates.

## Market Exchange

The Market Exchange tab is an optional online reference panel.

### Crypto

1. Select **Crypto**.
2. Enter an amount, such as `1` or `0.25`.
3. Enter a crypto symbol or CoinGecko id, such as `BTC`, `ETH`, `SOL`, or `bitcoin`.
4. Enter a quote currency, such as `AUD` or `USD`.
5. Click **Refresh Online**.

The app stores the last-known result in `market_exchange_cache.json` so **Use Cached** can work later.

### Stock / ETF

1. Select **Stock / ETF**.
2. Enter an amount of shares/units.
3. Enter a Stooq-style symbol, such as `AAPL.US`, `AMD.US`, `MSFT.US`, `CBA.AU`, or `BHP.AU`.
4. Enter the quote currency label, such as `USD` or `AUD`.
5. Click **Refresh Online**.

For stocks/ETFs, the quote currency is a display label matching the source market. The app does not place trades or connect broker accounts.

## Security scope

The Security tab is defensive only: hashing, encoding/decoding, length checks, epoch conversion, and decode-only JWT viewing. It does not perform offensive security actions.

## Theme

The interface uses the SentinelOS / AEGIS Desktop Suite palette: AEGIS Dark backgrounds, AEGIS Gold primary accents, Sentinel Cyan secondary highlights, themed menus, bordered panels, and transparent Sentinel/AEGIS application artwork.
