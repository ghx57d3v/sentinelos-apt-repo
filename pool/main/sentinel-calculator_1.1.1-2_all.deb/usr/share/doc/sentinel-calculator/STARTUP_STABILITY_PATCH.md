# Sentinel Calculator v1.1.1 Stability Notes

v1.1.1 preserves the v0.8.5 startup crash cleanup, the v1.0.0 stable converter path, and the v1.0.1 AEGIS/Sentinel theme alignment. The Market Exchange tab is manual-refresh and cache-backed so network failures do not crash the GUI.
