# Sentinel Calculator v1.1.1 Validation

Validation performed in the build container.

## Passed

- Python syntax compile for patched `app.py`.
- Internal self-test:
  - standard/scientific math
  - safe parser rejection
  - resource-limit rejection
  - programmer conversion
  - CIDR/network report
  - defensive security transforms
  - unit conversion
  - currency arithmetic/cache logic
  - market parser/arithmetic
  - electronics calculations
- Resource-heavy expression regression:
  - oversized exponent refused
  - oversized factorial refused
  - overlong expression refused
- Symlink cache write regression:
  - symlinked currency cache target was not clobbered
- Symlink log regression:
  - symlinked log target was not written
- Shell helper syntax checks.
- Debian package rebuild.
- Extracted package Python compile.
- No packaged `.pyc` / `__pycache__`.

## Not performed here

- Live MATE desktop menu validation.
- Live GUI smoke under a real SentinelOS display.
- Real online currency/market refresh against providers.
