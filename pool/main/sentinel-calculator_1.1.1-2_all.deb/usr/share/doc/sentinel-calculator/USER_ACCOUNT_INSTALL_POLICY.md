# Sentinel Calculator v1.1.1 User Account Install Policy

System package files install under `/usr/bin`, `/usr/share/applications`, and `/usr/share/sentinel-calculator`.

Per-user state is stored under:

```text
~/.local/share/sentinel-calculator/
~/.local/state/sentinel-calculator/
```

Currency rates are cached per user at:

```text
~/.local/share/sentinel-calculator/currency_rates_cache.json
```

Market prices are cached per user at:

```text
~/.local/share/sentinel-calculator/market_exchange_cache.json
```

No wallet credentials, broker credentials, exchange credentials, or API keys are stored by this package.
