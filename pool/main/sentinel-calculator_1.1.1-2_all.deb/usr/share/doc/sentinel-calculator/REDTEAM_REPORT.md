# Sentinel Calculator v1.1.1 Redteam Security Cleanup Report

## Scope

Input audited: `sentinel_calculator_v1_1_0(2).zip` containing `sentinel-calculator_1.1.0-1_all.deb`.

Audit focus: expression evaluation safety, GUI/runtime user-state handling, optional online market/currency refresh, launcher scripts, package hygiene, and host-safety regressions.

## Verdict

The uploaded v1.1.0 package used an AST-based calculator evaluator rather than Python `eval`, which is good. However, it still had enough host-risk edge cases to warrant a hotfix before treating it as a redteam-clean baseline.

Patched baseline: **v1.1.1-1**.

## Findings and fixes

### HIGH — Unbounded expression resource exhaustion

v1.1.0 rejected obvious code-execution payloads, but allowed resource-heavy expressions such as very large powers, factorials, and excessively long expressions. These can freeze or exhaust a user session even without arbitrary code execution.

Fixed in v1.1.1:

- Adds maximum expression length.
- Adds maximum AST node count.
- Adds numeric literal and intermediate-result limits.
- Adds power-exponent guard.
- Adds factorial input guard.
- Rejects non-finite calculation results.
- Adds regression checks for resource-heavy expressions.

### MEDIUM — User-state/cache symlink clobber risk

Settings, history, log, currency cache, and market cache writes used normal `write_text()` / logging file paths. If an app-state file was replaced with a symlink, the calculator could write through that symlink and alter another user-owned file.

Fixed in v1.1.1:

- Adds symlink refusal for Sentinel Calculator state/cache/log files.
- Adds atomic private writes for settings/history/caches.
- Applies `0600` mode to private state files where practical.
- Adds size limits for local state/cache reads.
- Disables file logging safely when the log path is symlinked.

### MEDIUM — Unbounded online response reads

Manual-refresh currency and market providers were fetched with unbounded `response.read()` calls. A provider failure, proxy issue, or hostile network response could feed an oversized body into the app.

Fixed in v1.1.1:

- Adds capped HTTP response reads.
- Keeps cache unchanged on oversized provider response.
- Updates the currency User-Agent version string.

### LOW/MEDIUM — Large paste/input handling

Security helpers and JWT viewer accepted large pasted values without explicit limits, which could make the GUI sluggish or memory-heavy.

Fixed in v1.1.1:

- Adds text-size limits for Security mode transforms.
- Adds JWT section-size limits.
- Adds programmer-input length limit.
- Adds market-symbol/crypto-asset input length checks.

### LOW — Launcher helper hardening

User launcher setup wrote directly into launcher paths and relied on `python3` / command lookup in a few helper scripts.

Fixed in v1.1.1:

- Main wrapper now executes `/usr/bin/python3` explicitly.
- User-system repair now calls `/usr/bin/sentinel-calculator-user-setup` explicitly.
- Log helper refuses symlinked log files.
- User setup refuses symlinked launcher/icon destinations and writes launcher files through temporary files.

### LOW — Messy code cleanup

Fixed duplicate `first_host` assignment in the CIDR report path and removed packaged bytecode/cache artifacts.

## Remaining notes

- Currency and market lookup remain intentionally manual-refresh online features. Offline cached conversion remains available when a prior rate/price exists.
- The Security tab remains defensive/inspection-only; no exploit, payload, cracking, or bypass functionality was added.
