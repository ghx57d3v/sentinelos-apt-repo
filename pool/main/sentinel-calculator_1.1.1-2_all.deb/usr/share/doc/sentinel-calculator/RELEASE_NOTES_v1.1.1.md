# Sentinel Calculator v1.1.1 Release Notes

v1.1.1 is a redteam security cleanup hotfix over v1.1.0.

## Changes

- Hardened expression evaluator against resource-exhaustion inputs.
- Added input-size limits for security transforms, JWT viewing, programmer mode, and market symbols.
- Hardened settings/history/cache/log writes against symlink clobber.
- Added atomic private writes for user-state JSON files.
- Capped manual-refresh provider response size.
- Hardened launcher helper scripts and absolute interpreter/helper paths.
- Removed packaged Python bytecode/cache files.
- Cleaned duplicate CIDR-report assignment.

## Compatibility

Existing settings/history/currency/market cache files remain JSON-compatible. Unsafe symlinked app-state files are now refused instead of followed.
