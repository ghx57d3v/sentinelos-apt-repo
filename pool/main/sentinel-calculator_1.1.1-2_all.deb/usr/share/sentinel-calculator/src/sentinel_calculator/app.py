#!/usr/bin/env python3
"""
Sentinel Calculator v1.1.1
Program 103 — SentinelOS Desktop Suite

Market Exchange upgrade:
- Adds optional manual-refresh crypto and stock/ETF price lookup
- Keeps offline calculator and converter modes intact
- Uses local cache for last-known market values
"""

from __future__ import annotations

import argparse
import ast
import base64
import csv
import datetime as _dt
import hashlib
import ipaddress
import json
import logging
import math
import os
import operator
from pathlib import Path
import sys
import time
import tkinter as tk
import urllib.error
import urllib.request
from tkinter import messagebox
from tkinter import ttk
from urllib.parse import quote, unquote
from typing import Any, Callable


APP_NAME = "Sentinel Calculator"
APP_VERSION = "1.1.1"
PROGRAM_ID = "103"

AEGIS_BLACK = "#020506"
AEGIS_BG = "#071014"
AEGIS_PANEL = "#101820"
AEGIS_PANEL_2 = "#16232B"
AEGIS_PANEL_3 = "#21313B"
AEGIS_FIELD = "#05090C"
AEGIS_BORDER = "#3D2B08"
AEGIS_GOLD = "#E19B00"
AEGIS_GOLD_SOFT = "#F2B42C"
AEGIS_CYAN = "#03C8FF"
AEGIS_CYAN_SOFT = "#6BE4FF"
AEGIS_TEXT = "#F4F1E8"
AEGIS_MUTED = "#AAB4B8"
AEGIS_DANGER = "#8A3030"

APP_DATA_DIR = Path.home() / ".local" / "share" / "sentinel-calculator"
STATE_DIR = Path.home() / ".local" / "state" / "sentinel-calculator"
HISTORY_FILE = APP_DATA_DIR / "history_by_mode.json"
SETTINGS_FILE = APP_DATA_DIR / "settings.json"
LOG_FILE = STATE_DIR / "sentinel-calculator.log"
CURRENCY_CACHE_FILE = APP_DATA_DIR / "currency_rates_cache.json"
MARKET_CACHE_FILE = APP_DATA_DIR / "market_exchange_cache.json"

MODES = [
    "Standard",
    "Scientific",
    "Unit Converter",
    "Currency Converter",
    "Market Exchange",
    "Programmer",
    "Network",
    "Security",
    "Electronics",
]


MAX_EXPRESSION_CHARS = 512
MAX_AST_NODES = 96
MAX_ABS_NUMERIC_LITERAL = 10**12
MAX_ABS_INTERMEDIATE = 10**120
MAX_POWER_EXPONENT = 10000
MAX_FACTORIAL_INPUT = 5000
MAX_TEXT_INPUT_BYTES = 262_144
MAX_JWT_SECTION_BYTES = 131_072
MAX_CACHE_FILE_BYTES = 1_048_576
MAX_HTTP_RESPONSE_BYTES = 1_048_576
MAX_GEOMETRY_CHARS = 64


def _path_contains_symlink(path: Path) -> bool:
    """Return True when an existing path component is a symlink."""
    try:
        resolved_home = Path.home().resolve()
    except Exception:
        resolved_home = Path.home()
    candidate = path.expanduser()
    parts = candidate.parts
    current = Path(parts[0]) if candidate.is_absolute() else Path.cwd()
    for part in (parts[1:] if candidate.is_absolute() else parts):
        current = current / part
        try:
            if os.path.lexists(current) and current.is_symlink():
                return True
        except OSError:
            return True
    try:
        candidate.resolve().relative_to(resolved_home)
    except Exception:
        # The calculator only writes user-state below the active HOME.
        return True
    return False


def ensure_private_dir(path: Path) -> None:
    path = path.expanduser()
    if _path_contains_symlink(path):
        raise RuntimeError(f"Refusing symlinked/out-of-home Sentinel Calculator directory path: {path}")
    path.mkdir(parents=True, exist_ok=True, mode=0o700)
    try:
        os.chmod(path, 0o700)
    except OSError:
        pass


def ensure_user_state_dirs() -> None:
    ensure_private_dir(APP_DATA_DIR)
    ensure_private_dir(STATE_DIR)


def read_private_text(path: Path, *, max_bytes: int = MAX_CACHE_FILE_BYTES) -> str:
    if path.is_symlink():
        raise RuntimeError(f"Refusing to read symlinked Sentinel Calculator state file: {path}")
    if not path.exists():
        return ""
    size = path.stat().st_size
    if size > max_bytes:
        raise RuntimeError(f"Refusing oversized Sentinel Calculator state file: {path} ({size} bytes)")
    return path.read_text(encoding="utf-8", errors="replace")


def write_private_text(path: Path, text: str) -> None:
    ensure_private_dir(path.parent)
    if path.is_symlink():
        raise RuntimeError(f"Refusing to write symlinked Sentinel Calculator state file: {path}")
    encoded = text.encode("utf-8")
    if len(encoded) > MAX_CACHE_FILE_BYTES:
        raise RuntimeError(f"Refusing oversized Sentinel Calculator state write: {path}")
    tmp = path.with_name(f".{path.name}.tmp.{os.getpid()}.{time.time_ns()}")
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    with os.fdopen(os.open(tmp, flags, 0o600), "w", encoding="utf-8") as handle:
        handle.write(text)
        handle.flush()
        os.fsync(handle.fileno())
    if path.is_symlink():
        try:
            tmp.unlink()
        finally:
            raise RuntimeError(f"Refusing to replace symlinked Sentinel Calculator state file: {path}")
    os.replace(tmp, path)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


def read_response_limited(response: Any, *, max_bytes: int = MAX_HTTP_RESPONSE_BYTES) -> bytes:
    chunks: list[bytes] = []
    remaining = max_bytes + 1
    while remaining > 0:
        chunk = response.read(min(65536, remaining))
        if not chunk:
            break
        chunks.append(chunk)
        remaining -= len(chunk)
    data = b"".join(chunks)
    if len(data) > max_bytes:
        raise ValueError("Online provider response was too large; cache unchanged.")
    return data


def ensure_text_limit(text: str, label: str, *, max_bytes: int = MAX_TEXT_INPUT_BYTES) -> None:
    if len(text.encode("utf-8")) > max_bytes:
        raise ValueError(f"{label} is too large for safe local processing.")


def setup_logging(debug: bool = False) -> None:
    level = logging.DEBUG if debug else logging.INFO
    try:
        ensure_user_state_dirs()
        if LOG_FILE.is_symlink():
            raise RuntimeError(f"Refusing symlinked log file: {LOG_FILE}")
        logging.basicConfig(
            filename=str(LOG_FILE),
            filemode="a",
            level=level,
            format="%(asctime)s %(levelname)s %(message)s",
        )
        try:
            os.chmod(LOG_FILE, 0o600)
        except OSError:
            pass
    except Exception as exc:
        logging.basicConfig(
            stream=sys.stderr,
            level=level,
            format="%(asctime)s %(levelname)s %(message)s",
        )
        logging.warning("Sentinel Calculator file logging disabled: %s", exc)
    logging.info("=== Sentinel Calculator v%s start ===", APP_VERSION)


class CalculatorError(Exception):
    """Raised when a calculator expression is invalid or unsafe."""


SAFE_CONSTANTS = {"pi": math.pi, "π": math.pi, "e": math.e, "tau": math.tau}

def safe_factorial(value: float) -> int:
    if isinstance(value, bool) or int(value) != value:
        raise ValueError("Factorial requires a whole number.")
    number = int(value)
    if number < 0:
        raise ValueError("Factorial requires a non-negative number.")
    if number > MAX_FACTORIAL_INPUT:
        raise ValueError(f"Factorial input is limited to {MAX_FACTORIAL_INPUT}.")
    return math.factorial(number)


def _guard_numeric(value: Any, label: str = "number") -> Any:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise CalculatorError(f"Invalid {label}.")
    try:
        if isinstance(value, float) and not math.isfinite(value):
            raise CalculatorError("Result must be finite.")
        if abs(value) > MAX_ABS_INTERMEDIATE:
            raise CalculatorError("Result is too large for safe local calculation.")
    except OverflowError as exc:
        raise CalculatorError("Result is too large for safe local calculation.") from exc
    return value


SAFE_FUNCTIONS: dict[str, Callable[..., float]] = {
    "sqrt": math.sqrt,
    "abs": abs,
    "round": round,
    "sin": math.sin,
    "cos": math.cos,
    "tan": math.tan,
    "asin": math.asin,
    "acos": math.acos,
    "atan": math.atan,
    "ln": math.log,
    "log": math.log10,
    "exp": math.exp,
    "floor": math.floor,
    "ceil": math.ceil,
    "fact": safe_factorial,
    "factorial": safe_factorial,
}

BIN_OPS: dict[type[ast.operator], Callable[[Any, Any], Any]] = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv,
    ast.Mod: operator.mod,
    ast.Pow: operator.pow,
}

UNARY_OPS: dict[type[ast.unaryop], Callable[[Any], Any]] = {
    ast.UAdd: operator.pos,
    ast.USub: operator.neg,
}


def resource_path(*parts: str) -> Path:
    candidates = [
        Path(__file__).resolve().parents[2] / "assets",
        APP_DATA_DIR / "assets",
        Path("/usr/share/sentinel-calculator/assets"),
    ]
    for root in candidates:
        candidate = root.joinpath(*parts)
        if candidate.exists():
            return candidate
    return candidates[0].joinpath(*parts)


def normalize_expression(expression: str) -> str:
    expr = expression.strip()
    replacements = {"×": "*", "÷": "/", "^": "**", "√": "sqrt"}
    for old, new in replacements.items():
        expr = expr.replace(old, new)
    return expr


def _eval_node(node: ast.AST) -> float:
    if isinstance(node, ast.Expression):
        return _eval_node(node.body)
    if isinstance(node, ast.Constant):
        if isinstance(node.value, (int, float)) and not isinstance(node.value, bool):
            if abs(node.value) > MAX_ABS_NUMERIC_LITERAL:
                raise CalculatorError("Number is too large for safe local calculation.")
            return node.value
        raise CalculatorError("Only numbers are allowed.")
    if isinstance(node, ast.BinOp):
        op_type = type(node.op)
        if op_type not in BIN_OPS:
            raise CalculatorError("Unsupported operator.")
        left = _guard_numeric(_eval_node(node.left), "left operand")
        right = _guard_numeric(_eval_node(node.right), "right operand")
        if op_type is ast.Pow:
            if abs(right) > MAX_POWER_EXPONENT:
                raise CalculatorError(f"Power exponent is limited to {MAX_POWER_EXPONENT}.")
            if abs(left) > 1_000_000 and abs(right) > 8:
                raise CalculatorError("Power expression is too large for safe local calculation.")
        return _guard_numeric(BIN_OPS[op_type](left, right), "result")
    if isinstance(node, ast.UnaryOp):
        op_type = type(node.op)
        if op_type not in UNARY_OPS:
            raise CalculatorError("Unsupported sign/operator.")
        return _guard_numeric(UNARY_OPS[op_type](_guard_numeric(_eval_node(node.operand))), "result")
    if isinstance(node, ast.Name):
        if node.id in SAFE_CONSTANTS:
            return SAFE_CONSTANTS[node.id]
        raise CalculatorError(f"Unknown name: {node.id}")
    if isinstance(node, ast.Call):
        if not isinstance(node.func, ast.Name):
            raise CalculatorError("Unsupported function call.")
        func_name = node.func.id
        if func_name not in SAFE_FUNCTIONS:
            raise CalculatorError(f"Unsupported function: {func_name}")
        if node.keywords:
            raise CalculatorError("Keyword arguments are not allowed.")
        if len(node.args) > 4:
            raise CalculatorError("Too many function arguments.")
        args = [_guard_numeric(_eval_node(arg), "function argument") for arg in node.args]
        return _guard_numeric(SAFE_FUNCTIONS[func_name](*args), "function result")
    raise CalculatorError("Unsupported expression.")


def calculate_expression(expression: str) -> float:
    normalized = normalize_expression(expression)
    if not normalized:
        raise CalculatorError("Enter a calculation first.")
    if len(normalized) > MAX_EXPRESSION_CHARS:
        raise CalculatorError(f"Calculation is too long; limit is {MAX_EXPRESSION_CHARS} characters.")
    try:
        tree = ast.parse(normalized, mode="eval")
    except SyntaxError as exc:
        raise CalculatorError("Invalid calculation.") from exc
    if sum(1 for _node in ast.walk(tree)) > MAX_AST_NODES:
        raise CalculatorError("Calculation is too complex for safe local processing.")
    try:
        result = _eval_node(tree)
    except ZeroDivisionError as exc:
        raise CalculatorError("Division by zero.") from exc
    except OverflowError as exc:
        raise CalculatorError("Result is too large.") from exc
    except ValueError as exc:
        raise CalculatorError(str(exc)) from exc
    except TypeError as exc:
        raise CalculatorError(str(exc)) from exc
    if isinstance(result, bool) or not isinstance(result, (int, float)):
        raise CalculatorError("Calculation did not return a number.")
    _guard_numeric(result, "result")
    return result


def format_number(value: float) -> str:
    if math.isfinite(value):
        if value == int(value):
            return str(int(value))
        return f"{value:.12g}"
    return str(value)


def parse_int_any(value: str) -> int:
    ensure_text_limit(value, "Programmer input", max_bytes=4096)
    text = value.strip().lower().replace("_", "")
    if not text:
        raise ValueError("Enter a number first.")
    if text.startswith("0x"):
        return int(text, 16)
    if text.startswith("0b"):
        return int(text, 2)
    if text.startswith("0o"):
        return int(text, 8)
    if text.endswith("h"):
        return int(text[:-1], 16)
    if text.endswith("b"):
        return int(text[:-1], 2)
    if text.endswith("o"):
        return int(text[:-1], 8)
    return int(text, 10)


def programmer_report(value: int) -> str:
    masked64 = value & ((1 << 64) - 1)
    return (
        f"DEC: {value}\n"
        f"HEX: 0x{value:X}\n"
        f"OCT: 0o{value:o}\n"
        f"BIN: 0b{value:b}\n"
        f"Bit length: {value.bit_length()}\n"
        f"Unsigned 64-bit mask: 0x{masked64:016X}"
    )


def cidr_report(cidr: str) -> str:
    network = ipaddress.ip_network(cidr.strip(), strict=False)
    if network.version == 4:
        hosts_total = network.num_addresses
        usable = max(hosts_total - 2, 0) if network.prefixlen < 31 else hosts_total

        # Do not materialise network.hosts() into a list. Large ranges such as
        # 10.0.0.0/8 or 0.0.0.0/0 can contain millions/billions of addresses
        # and would freeze or exhaust memory. Calculate boundary hosts directly.
        if usable <= 0:
            first_host = "N/A"
            last_host = "N/A"
        elif network.prefixlen < 31:
            first_host = str(network.network_address + 1)
            last_host = str(network.broadcast_address - 1)
        else:
            first_host = str(network.network_address)
            last_host = str(network.broadcast_address)

        return (
            f"CIDR: {network.with_prefixlen}\n"
            f"Network address: {network.network_address}\n"
            f"Netmask: {network.netmask}\n"
            f"Wildcard mask: {network.hostmask}\n"
            f"Broadcast: {network.broadcast_address}\n"
            f"First usable: {first_host}\n"
            f"Last usable: {last_host}\n"
            f"Total addresses: {hosts_total}\n"
            f"Usable hosts: {usable}"
        )
    return (
        f"CIDR: {network.with_prefixlen}\n"
        f"Network address: {network.network_address}\n"
        f"Prefix length: /{network.prefixlen}\n"
        f"Total addresses: {network.num_addresses}\n"
        f"Compressed: {network.compressed}\n"
        f"Exploded: {network.exploded}"
    )


def decode_jwt_view(token: str) -> str:
    ensure_text_limit(token, "JWT", max_bytes=MAX_TEXT_INPUT_BYTES)
    token = token.strip()
    parts = token.split(".")
    if len(parts) < 2:
        raise ValueError("JWT must contain at least header and payload sections.")

    def b64url_decode(part: str) -> bytes:
        if len(part.encode("ascii", errors="ignore")) > MAX_JWT_SECTION_BYTES:
            raise ValueError("JWT section is too large for safe local viewing.")
        padding = "=" * (-len(part) % 4)
        return base64.urlsafe_b64decode(part + padding)

    def pretty(raw: bytes) -> str:
        try:
            parsed = json.loads(raw.decode("utf-8"))
            return json.dumps(parsed, indent=2, sort_keys=True)
        except Exception:
            return raw.decode("utf-8", errors="replace")

    return (
        "JWT decode-only viewer.\n"
        "Signature verification is not performed.\n\n"
        "Header:\n"
        f"{pretty(b64url_decode(parts[0]))}\n\n"
        "Payload:\n"
        f"{pretty(b64url_decode(parts[1]))}"
    )


def security_transform(operation: str, text: str) -> str:
    ensure_text_limit(text, "Security-tool input")
    if operation == "Base64 Encode":
        return base64.b64encode(text.encode("utf-8")).decode("ascii")
    if operation == "Base64 Decode":
        return base64.b64decode(text.encode("ascii"), validate=True).decode("utf-8", errors="replace")
    if operation == "URL Encode":
        return quote(text, safe="")
    if operation == "URL Decode":
        return unquote(text)
    if operation == "Hex Encode":
        return text.encode("utf-8").hex()
    if operation == "Hex Decode":
        cleaned = text.strip().replace(" ", "").replace("0x", "")
        return bytes.fromhex(cleaned).decode("utf-8", errors="replace")
    if operation == "Hashes":
        data = text.encode("utf-8")
        return (
            f"MD5:    {hashlib.md5(data).hexdigest()}\n"
            f"SHA1:   {hashlib.sha1(data).hexdigest()}\n"
            f"SHA256: {hashlib.sha256(data).hexdigest()}\n"
            f"SHA512: {hashlib.sha512(data).hexdigest()}"
        )
    if operation == "Lengths":
        return (
            f"Characters: {len(text)}\n"
            f"Bytes UTF-8: {len(text.encode('utf-8'))}\n"
            f"Lines: {len(text.splitlines()) if text else 0}\n"
            f"Words: {len(text.split())}"
        )
    if operation == "Epoch To UTC":
        ts = float(text.strip())
        return _dt.datetime.fromtimestamp(ts, tz=_dt.timezone.utc).isoformat()
    if operation == "UTC To Epoch":
        raw = text.strip()
        if raw.endswith("Z"):
            raw = raw[:-1] + "+00:00"
        dt = _dt.datetime.fromisoformat(raw)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=_dt.timezone.utc)
        return str(int(dt.timestamp()))
    if operation == "JWT Viewer":
        return decode_jwt_view(text)
    raise ValueError("Unsupported security operation.")


def ohms_law(mode: str, a: float, b: float) -> str:
    if mode == "Voltage from Current + Resistance":
        current, resistance = a, b
        voltage = current * resistance
        power = voltage * current
        return f"Voltage: {voltage:.12g} V\nPower: {power:.12g} W"
    if mode == "Current from Voltage + Resistance":
        voltage, resistance = a, b
        current = voltage / resistance
        power = voltage * current
        return f"Current: {current:.12g} A\nPower: {power:.12g} W"
    if mode == "Resistance from Voltage + Current":
        voltage, current = a, b
        resistance = voltage / current
        power = voltage * current
        return f"Resistance: {resistance:.12g} Ω\nPower: {power:.12g} W"
    if mode == "Power from Voltage + Current":
        voltage, current = a, b
        power = voltage * current
        resistance = voltage / current if current != 0 else float("inf")
        return f"Power: {power:.12g} W\nResistance: {resistance:.12g} Ω"
    raise ValueError("Unsupported electronics operation.")


UNIT_CATEGORIES: dict[str, dict[str, float]] = {
    "Length": {
        "millimetre (mm)": 0.001,
        "centimetre (cm)": 0.01,
        "metre (m)": 1.0,
        "kilometre (km)": 1000.0,
        "inch (in)": 0.0254,
        "foot (ft)": 0.3048,
        "yard (yd)": 0.9144,
        "mile (mi)": 1609.344,
        "nautical mile (nmi)": 1852.0,
    },
    "Area": {
        "square millimetre (mm²)": 0.000001,
        "square centimetre (cm²)": 0.0001,
        "square metre (m²)": 1.0,
        "square kilometre (km²)": 1_000_000.0,
        "square inch (in²)": 0.00064516,
        "square foot (ft²)": 0.09290304,
        "square yard (yd²)": 0.83612736,
        "acre": 4046.8564224,
        "hectare": 10000.0,
        "square mile (mi²)": 2_589_988.110336,
    },
    "Volume": {
        "millilitre (mL)": 0.001,
        "litre (L)": 1.0,
        "cubic metre (m³)": 1000.0,
        "teaspoon AU (tsp)": 0.005,
        "tablespoon AU (tbsp)": 0.02,
        "cup AU (250 mL)": 0.25,
        "fluid ounce US (fl oz)": 0.0295735295625,
        "pint US": 0.473176473,
        "gallon US": 3.785411784,
        "gallon imperial": 4.54609,
    },
    "Mass": {
        "milligram (mg)": 0.001,
        "gram (g)": 1.0,
        "kilogram (kg)": 1000.0,
        "tonne (t)": 1_000_000.0,
        "ounce (oz)": 28.349523125,
        "pound (lb)": 453.59237,
        "stone (st)": 6350.29318,
    },
    "Speed": {
        "metres/sec (m/s)": 1.0,
        "kilometres/hour (km/h)": 0.2777777777777778,
        "miles/hour (mph)": 0.44704,
        "knot": 0.5144444444444445,
        "feet/sec (ft/s)": 0.3048,
    },
    "Pressure": {
        "pascal (Pa)": 1.0,
        "kilopascal (kPa)": 1000.0,
        "bar": 100000.0,
        "psi": 6894.757293168,
        "atmosphere (atm)": 101325.0,
        "millimetre mercury (mmHg)": 133.322387415,
    },
    "Energy": {
        "joule (J)": 1.0,
        "kilojoule (kJ)": 1000.0,
        "calorie (cal)": 4.184,
        "kilocalorie (kcal)": 4184.0,
        "watt-hour (Wh)": 3600.0,
        "kilowatt-hour (kWh)": 3_600_000.0,
        "BTU": 1055.05585262,
    },
    "Power": {
        "watt (W)": 1.0,
        "kilowatt (kW)": 1000.0,
        "horsepower mechanical (hp)": 745.6998715822702,
    },
    "Data Storage": {
        "bit": 0.125,
        "byte (B)": 1.0,
        "kilobyte (KB)": 1000.0,
        "kibibyte (KiB)": 1024.0,
        "megabyte (MB)": 1_000_000.0,
        "mebibyte (MiB)": 1_048_576.0,
        "gigabyte (GB)": 1_000_000_000.0,
        "gibibyte (GiB)": 1_073_741_824.0,
        "terabyte (TB)": 1_000_000_000_000.0,
        "tebibyte (TiB)": 1_099_511_627_776.0,
    },
    "Time": {
        "nanosecond (ns)": 0.000000001,
        "microsecond (µs)": 0.000001,
        "millisecond (ms)": 0.001,
        "second (s)": 1.0,
        "minute (min)": 60.0,
        "hour (h)": 3600.0,
        "day": 86400.0,
        "week": 604800.0,
        "year average": 31557600.0,
    },
}

TEMPERATURE_UNITS = ["Celsius (°C)", "Fahrenheit (°F)", "Kelvin (K)"]
FUEL_ECONOMY_UNITS = ["L/100km", "km/L", "mpg US", "mpg Imperial"]
CURRENCY_DEFAULTS = "AUD, USD, EUR, GBP, NZD, CAD, JPY, CNY, HKD, SGD, CHF, INR, ZAR"
FRANKFURTER_API_BASE = "https://api.frankfurter.dev/v1/latest"
COINGECKO_SIMPLE_PRICE_API = "https://api.coingecko.com/api/v3/simple/price"
STOOQ_QUOTE_API = "https://stooq.com/q/l/"
MARKET_PROVIDER_NOTE = "Manual refresh only. Informational price references; not financial advice."
CRYPTO_SYMBOL_IDS = {
    "BTC": "bitcoin",
    "ETH": "ethereum",
    "BNB": "binancecoin",
    "SOL": "solana",
    "XRP": "ripple",
    "ADA": "cardano",
    "DOGE": "dogecoin",
    "DOT": "polkadot",
    "MATIC": "matic-network",
    "AVAX": "avalanche-2",
    "LTC": "litecoin",
    "BCH": "bitcoin-cash",
    "LINK": "chainlink",
    "UNI": "uniswap",
    "USDT": "tether",
    "USDC": "usd-coin",
}
MARKET_TYPES = ["Crypto", "Stock / ETF"]
MARKET_DEFAULT_STOCKS = "Examples: AAPL.US, AMD.US, MSFT.US, TSLA.US, CBA.AU, BHP.AU"


def convert_temperature(value: float, from_unit: str, to_unit: str) -> float:
    if from_unit == to_unit:
        return value
    if from_unit == "Celsius (°C)":
        celsius = value
    elif from_unit == "Fahrenheit (°F)":
        celsius = (value - 32.0) * 5.0 / 9.0
    elif from_unit == "Kelvin (K)":
        celsius = value - 273.15
    else:
        raise ValueError("Unsupported temperature unit.")

    if to_unit == "Celsius (°C)":
        return celsius
    if to_unit == "Fahrenheit (°F)":
        return celsius * 9.0 / 5.0 + 32.0
    if to_unit == "Kelvin (K)":
        return celsius + 273.15
    raise ValueError("Unsupported temperature unit.")


def convert_fuel_economy(value: float, from_unit: str, to_unit: str) -> float:
    if value == 0:
        raise ValueError("Fuel economy conversion cannot use zero.")
    if from_unit == to_unit:
        return value
    if from_unit == "L/100km":
        litres_per_100km = value
    elif from_unit == "km/L":
        litres_per_100km = 100.0 / value
    elif from_unit == "mpg US":
        litres_per_100km = 235.214583 / value
    elif from_unit == "mpg Imperial":
        litres_per_100km = 282.4809363 / value
    else:
        raise ValueError("Unsupported fuel economy unit.")

    if litres_per_100km == 0:
        raise ValueError("Fuel economy conversion cannot use zero.")
    if to_unit == "L/100km":
        return litres_per_100km
    if to_unit == "km/L":
        return 100.0 / litres_per_100km
    if to_unit == "mpg US":
        return 235.214583 / litres_per_100km
    if to_unit == "mpg Imperial":
        return 282.4809363 / litres_per_100km
    raise ValueError("Unsupported fuel economy unit.")


def unit_names_for_category(category: str) -> list[str]:
    if category == "Temperature":
        return TEMPERATURE_UNITS[:]
    if category == "Fuel Economy":
        return FUEL_ECONOMY_UNITS[:]
    units = UNIT_CATEGORIES.get(category)
    if not units:
        raise ValueError("Unsupported unit category.")
    return list(units.keys())


def convert_unit(category: str, value: float, from_unit: str, to_unit: str) -> float:
    if category == "Temperature":
        return convert_temperature(value, from_unit, to_unit)
    if category == "Fuel Economy":
        return convert_fuel_economy(value, from_unit, to_unit)
    units = UNIT_CATEGORIES.get(category)
    if not units:
        raise ValueError("Unsupported unit category.")
    if from_unit not in units or to_unit not in units:
        raise ValueError("Unsupported unit for selected category.")
    base_value = value * units[from_unit]
    return base_value / units[to_unit]


def load_currency_cache() -> dict[str, Any]:
    try:
        if CURRENCY_CACHE_FILE.exists():
            data = json.loads(read_private_text(CURRENCY_CACHE_FILE))
            if isinstance(data, dict):
                return data
    except Exception:
        logging.exception("Currency cache load failed")
    return {}


def save_currency_cache(cache: dict[str, Any]) -> None:
    try:
        write_private_text(CURRENCY_CACHE_FILE, json.dumps(cache, indent=2, sort_keys=True))
    except Exception:
        logging.exception("Currency cache save failed")


def normalize_currency_code(value: str) -> str:
    code = value.strip().upper()
    if len(code) != 3 or not code.isalpha():
        raise ValueError("Currency codes must use 3 letters, for example AUD, USD, EUR.")
    return code


def currency_convert_with_rate(amount: float, rate: float) -> float:
    return amount * rate


def fetch_latest_currency_rate(from_code: str, to_code: str, timeout: float = 8.0) -> tuple[float, str, str]:
    base = normalize_currency_code(from_code)
    target = normalize_currency_code(to_code)
    if base == target:
        return 1.0, _dt.date.today().isoformat(), "identity"
    url = f"{FRANKFURTER_API_BASE}?base={quote(base)}&symbols={quote(target)}"
    req = urllib.request.Request(url, headers={"User-Agent": f"Sentinel-Calculator/{APP_VERSION}"})
    with urllib.request.urlopen(req, timeout=timeout) as response:
        raw = read_response_limited(response).decode("utf-8")
    data = json.loads(raw)
    rates = data.get("rates", {})
    if target not in rates:
        raise ValueError(f"Provider did not return a rate for {base} to {target}.")
    return float(rates[target]), str(data.get("date", "unknown")), "Frankfurter"


def get_cached_currency_rate(from_code: str, to_code: str) -> tuple[float, str, str]:
    base = normalize_currency_code(from_code)
    target = normalize_currency_code(to_code)
    if base == target:
        return 1.0, _dt.date.today().isoformat(), "identity"
    cache = load_currency_cache()
    base_cache = cache.get(base, {}) if isinstance(cache.get(base, {}), dict) else {}
    rates = base_cache.get("rates", {}) if isinstance(base_cache.get("rates", {}), dict) else {}
    if target not in rates:
        raise ValueError(f"No cached rate for {base} to {target}. Click Refresh Online first.")
    return float(rates[target]), str(base_cache.get("date", "cached")), "cache"


def update_currency_cache(from_code: str, to_code: str, rate: float, rate_date: str, provider: str) -> None:
    base = normalize_currency_code(from_code)
    target = normalize_currency_code(to_code)
    cache = load_currency_cache()
    base_cache = cache.get(base, {}) if isinstance(cache.get(base, {}), dict) else {}
    rates = base_cache.get("rates", {}) if isinstance(base_cache.get("rates", {}), dict) else {}
    rates[target] = rate
    base_cache.update(
        {
            "date": rate_date,
            "provider": provider,
            "fetched_at_utc": _dt.datetime.now(tz=_dt.timezone.utc).isoformat(timespec="seconds"),
            "rates": rates,
        }
    )
    cache[base] = base_cache
    save_currency_cache(cache)


def load_market_cache() -> dict[str, Any]:
    try:
        if MARKET_CACHE_FILE.exists():
            data = json.loads(read_private_text(MARKET_CACHE_FILE))
            if isinstance(data, dict):
                return data
    except Exception:
        logging.exception("Market cache load failed")
    return {}


def save_market_cache(cache: dict[str, Any]) -> None:
    try:
        write_private_text(MARKET_CACHE_FILE, json.dumps(cache, indent=2, sort_keys=True))
    except Exception:
        logging.exception("Market cache save failed")


def normalize_market_type(value: str) -> str:
    text = value.strip().lower()
    if text in {"crypto", "cryptocurrency", "coin"}:
        return "Crypto"
    if text in {"stock", "stocks", "etf", "stock / etf", "share", "shares"}:
        return "Stock / ETF"
    raise ValueError("Market type must be Crypto or Stock / ETF.")


def normalize_crypto_asset(value: str) -> str:
    ensure_text_limit(value, "Crypto asset", max_bytes=128)
    raw = value.strip()
    if not raw:
        raise ValueError("Enter a crypto symbol or CoinGecko coin id.")
    upper = raw.upper()
    if upper in CRYPTO_SYMBOL_IDS:
        return CRYPTO_SYMBOL_IDS[upper]
    return raw.lower().replace(" ", "-")


def normalize_stock_symbol(value: str) -> str:
    ensure_text_limit(value, "Market symbol", max_bytes=64)
    symbol = value.strip().upper().replace(" ", "")
    if not symbol:
        raise ValueError("Enter a stock/ETF symbol, for example AAPL.US or CBA.AU.")
    allowed = set("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.-_")
    if any(ch not in allowed for ch in symbol):
        raise ValueError("Stock symbols may only contain letters, numbers, dot, dash, or underscore.")
    return symbol


def market_cache_key(asset_type: str, symbol: str, quote_code: str) -> str:
    return f"{normalize_market_type(asset_type)}|{symbol.strip().lower()}|{quote_code.strip().upper()}"


def market_value(amount: float, price: float) -> float:
    return amount * price


def parse_stooq_quote_csv(raw: str) -> dict[str, Any]:
    rows = list(csv.DictReader(raw.splitlines()))
    if not rows:
        raise ValueError("Stooq returned no quote rows.")
    row = rows[0]
    close_text = str(row.get("Close", "")).strip()
    if not close_text or close_text.upper() in {"N/D", "NA", "N/A"}:
        raise ValueError("Stooq did not return a usable latest close for this symbol.")
    try:
        price = float(close_text)
    except ValueError as exc:
        raise ValueError("Stooq returned an invalid quote price.") from exc
    return {
        "symbol": str(row.get("Symbol", "")).strip(),
        "price": price,
        "date": str(row.get("Date", "unknown")).strip() or "unknown",
        "time": str(row.get("Time", "")).strip(),
        "open": str(row.get("Open", "")).strip(),
        "high": str(row.get("High", "")).strip(),
        "low": str(row.get("Low", "")).strip(),
        "volume": str(row.get("Volume", "")).strip(),
    }


def fetch_crypto_market_price(asset: str, quote_code: str, timeout: float = 8.0) -> dict[str, Any]:
    coin_id = normalize_crypto_asset(asset)
    vs_currency = normalize_currency_code(quote_code).lower()
    url = (
        COINGECKO_SIMPLE_PRICE_API
        + f"?ids={quote(coin_id)}&vs_currencies={quote(vs_currency)}"
        + "&include_24hr_change=true&include_last_updated_at=true"
    )
    req = urllib.request.Request(url, headers={"User-Agent": f"Sentinel-Calculator/{APP_VERSION}"})
    with urllib.request.urlopen(req, timeout=timeout) as response:
        data = json.loads(read_response_limited(response).decode("utf-8"))
    item = data.get(coin_id)
    if not isinstance(item, dict) or vs_currency not in item:
        raise ValueError(f"CoinGecko did not return a price for {coin_id}/{vs_currency.upper()}.")
    last_updated = item.get("last_updated_at")
    if isinstance(last_updated, (int, float)):
        updated = _dt.datetime.fromtimestamp(float(last_updated), tz=_dt.timezone.utc).isoformat(timespec="seconds")
    else:
        updated = _dt.datetime.now(tz=_dt.timezone.utc).isoformat(timespec="seconds")
    return {
        "asset_type": "Crypto",
        "symbol": coin_id,
        "quote": vs_currency.upper(),
        "price": float(item[vs_currency]),
        "change_24h": item.get(f"{vs_currency}_24h_change"),
        "provider": "CoinGecko",
        "updated": updated,
    }


def fetch_stock_market_price(symbol: str, quote_code: str, timeout: float = 8.0) -> dict[str, Any]:
    normalized = normalize_stock_symbol(symbol)
    display_quote = normalize_currency_code(quote_code)
    stooq_symbol = normalized.lower()
    url = f"{STOOQ_QUOTE_API}?s={quote(stooq_symbol)}&f=sd2t2ohlcv&h&e=csv"
    req = urllib.request.Request(url, headers={"User-Agent": f"Sentinel-Calculator/{APP_VERSION}"})
    with urllib.request.urlopen(req, timeout=timeout) as response:
        raw = read_response_limited(response).decode("utf-8", errors="replace")
    parsed = parse_stooq_quote_csv(raw)
    parsed.update(
        {
            "asset_type": "Stock / ETF",
            "symbol": normalized,
            "quote": display_quote,
            "provider": "Stooq",
            "updated": f"{parsed.get('date', 'unknown')} {parsed.get('time', '')}".strip(),
        }
    )
    return parsed


def fetch_market_price(asset_type: str, symbol: str, quote_code: str, timeout: float = 8.0) -> dict[str, Any]:
    kind = normalize_market_type(asset_type)
    if kind == "Crypto":
        return fetch_crypto_market_price(symbol, quote_code, timeout=timeout)
    return fetch_stock_market_price(symbol, quote_code, timeout=timeout)


def update_market_cache(asset_type: str, symbol: str, quote_code: str, data: dict[str, Any]) -> None:
    cache = load_market_cache()
    key = market_cache_key(asset_type, str(data.get("symbol", symbol)), quote_code)
    data = dict(data)
    data["cached_at_utc"] = _dt.datetime.now(tz=_dt.timezone.utc).isoformat(timespec="seconds")
    cache[key] = data
    # Alias common crypto input symbols to the resolved CoinGecko id cache key.
    if normalize_market_type(asset_type) == "Crypto":
        try:
            input_key = market_cache_key(asset_type, symbol, quote_code)
            cache[input_key] = data
        except Exception:
            pass
    save_market_cache(cache)


def get_cached_market_price(asset_type: str, symbol: str, quote_code: str) -> dict[str, Any]:
    key = market_cache_key(asset_type, symbol, quote_code)
    cache = load_market_cache()
    data = cache.get(key)
    if not isinstance(data, dict):
        raise ValueError("No cached market price for this asset. Click Refresh Online first.")
    return data


def run_internal_self_test() -> tuple[bool, str]:
    checks: list[str] = []
    math_cases = {
        "1+1": 2,
        "2*3+4": 10,
        "2*(3+4)": 14,
        "10/2": 5,
        "2^8": 256,
        "sqrt(81)": 9,
        "abs(-42)": 42,
        "50/100": 0.5,
        "sin(pi/2)": 1,
        "cos(0)": 1,
        "log(100)": 2,
        "ln(e)": 1,
        "fact(5)": 120,
    }
    for expr, expected in math_cases.items():
        got = calculate_expression(expr)
        if abs(got - expected) > 1e-9:
            return False, f"Math failed: {expr} got {got}, expected {expected}"
    checks.append("math")

    for expr in ["__import__('os').system('whoami')", "open('/etc/passwd').read()", "(lambda: 1)()"]:
        try:
            calculate_expression(expr)
            return False, f"Unsafe expression accepted: {expr}"
        except CalculatorError:
            pass
    checks.append("safe_parser")

    for expr in ["2**1000001", "fact(5001)", "1+" * 600 + "1"]:
        try:
            calculate_expression(expr)
            return False, f"Resource-heavy expression accepted: {expr[:32]}"
        except CalculatorError:
            pass
    checks.append("resource_limits")

    if parse_int_any("0xff") != 255 or parse_int_any("1111b") != 15:
        return False, "Programmer base parsing failed"
    checks.append("programmer")

    net = cidr_report("192.168.1.0/24")
    if "Network address: 192.168.1.0" not in net or "Usable hosts: 254" not in net:
        return False, "CIDR report failed"
    checks.append("network")

    if security_transform("Base64 Encode", "Sentinel") != "U2VudGluZWw=":
        return False, "Base64 encode failed"
    if security_transform("Base64 Decode", "U2VudGluZWw=") != "Sentinel":
        return False, "Base64 decode failed"
    if "SHA256:" not in security_transform("Hashes", "Sentinel"):
        return False, "Hash report failed"
    checks.append("security")

    if abs(convert_unit("Length", 1, "kilometre (km)", "metre (m)") - 1000) > 1e-9:
        return False, "Unit length conversion failed"
    if abs(convert_unit("Temperature", 0, "Celsius (°C)", "Fahrenheit (°F)") - 32) > 1e-9:
        return False, "Unit temperature conversion failed"
    if abs(convert_unit("Data Storage", 1, "gibibyte (GiB)", "mebibyte (MiB)") - 1024) > 1e-9:
        return False, "Unit data conversion failed"
    checks.append("unit_converter")

    if normalize_currency_code("aud") != "AUD":
        return False, "Currency code normalization failed"
    if abs(currency_convert_with_rate(10, 0.5) - 5) > 1e-9:
        return False, "Currency arithmetic failed"
    checks.append("currency_converter")

    if normalize_crypto_asset("BTC") != "bitcoin":
        return False, "Crypto symbol normalization failed"
    if abs(market_value(2.5, 10.0) - 25.0) > 1e-9:
        return False, "Market value arithmetic failed"
    sample_quote = "Symbol,Date,Time,Open,High,Low,Close,Volume\nAAPL.US,2026-06-29,22:00:00,100,110,99,105.5,12345\n"
    parsed_quote = parse_stooq_quote_csv(sample_quote)
    if abs(float(parsed_quote["price"]) - 105.5) > 1e-9:
        return False, "Stooq quote parser failed"
    checks.append("market_exchange")

    if "Voltage: 12" not in ohms_law("Voltage from Current + Resistance", 2, 6):
        return False, "Electronics voltage failed"
    if "Power: 24" not in ohms_law("Power from Voltage + Current", 12, 2):
        return False, "Electronics power failed"
    checks.append("electronics")

    return True, "PASS: " + ", ".join(checks)


def reset_settings() -> None:
    for path in [SETTINGS_FILE, HISTORY_FILE]:
        try:
            if path.is_symlink():
                print(f"Refusing to reset symlinked state file: {path}", file=sys.stderr)
                continue
            if path.exists():
                backup = path.with_suffix(path.suffix + f".bak.{int(time.time())}")
                if backup.exists() or backup.is_symlink():
                    raise RuntimeError(f"Backup path already exists: {backup}")
                path.rename(backup)
                try:
                    os.chmod(backup, 0o600)
                except OSError:
                    pass
                print(f"Backed up {path} -> {backup}")
        except Exception as exc:
            print(f"Could not reset {path}: {exc}", file=sys.stderr)


class SentinelCalculator(tk.Tk):
    def __init__(self, safe_mode: bool = False, debug: bool = False) -> None:
        super().__init__()
        self.safe_mode = safe_mode
        self.debug = debug

        ensure_user_state_dirs()

        self.title(f"{APP_NAME} v{APP_VERSION}")
        self.configure(bg=AEGIS_BG)
        self.option_add("*Background", AEGIS_BG)
        self.option_add("*Foreground", AEGIS_TEXT)
        self.option_add("*Menu.background", AEGIS_PANEL)
        self.option_add("*Menu.foreground", AEGIS_TEXT)
        self.option_add("*Menu.activeBackground", AEGIS_GOLD)
        self.option_add("*Menu.activeForeground", AEGIS_BLACK)
        self.option_add("*selectBackground", AEGIS_GOLD)
        self.option_add("*selectForeground", AEGIS_BLACK)
        self.minsize(720 if safe_mode else 850, 560 if safe_mode else 660)

        self.expression_var = tk.StringVar()
        self.result_var = tk.StringVar(value="Ready")
        self.status_var = tk.StringVar(value="Ready")
        self.last_result = ""
        self.history_by_mode: dict[str, list[str]] = {mode: [] for mode in MODES}
        self.current_mode = tk.StringVar(value="Standard")
        self.compact_mode = tk.BooleanVar(value=False)

        logging.info("Initializing GUI safe_mode=%s debug=%s", safe_mode, debug)

        self._load_settings()
        if not safe_mode:
            self._load_history()
        self._load_window_icon()
        self._configure_style()
        self._build_menu()
        self._build_ui()
        self._bind_keys()
        self._refresh_history_list()

        self.report_callback_exception = self._tk_callback_exception
        self.protocol("WM_DELETE_WINDOW", self.quit_app)
        logging.info("GUI initialized")

    def _configure_style(self) -> None:
        try:
            style = ttk.Style(self)
            try:
                style.theme_use("clam")
            except Exception as exc:
                logging.warning("Could not set ttk theme: %s", exc)
            style.configure(".", background=AEGIS_BG, foreground=AEGIS_TEXT, fieldbackground=AEGIS_FIELD)
            style.configure("Sentinel.TNotebook", background=AEGIS_BG, borderwidth=0, tabmargins=(2, 5, 2, 0))
            style.configure(
                "Sentinel.TNotebook.Tab",
                background=AEGIS_PANEL_2,
                foreground=AEGIS_TEXT,
                padding=(16, 8),
                borderwidth=0,
                focuscolor=AEGIS_CYAN,
            )
            style.map(
                "Sentinel.TNotebook.Tab",
                background=[("selected", AEGIS_GOLD), ("active", AEGIS_PANEL_3)],
                foreground=[("selected", AEGIS_BLACK), ("active", AEGIS_CYAN)],
            )
            style.configure("Sentinel.Horizontal.TSeparator", background=AEGIS_BORDER)
            style.configure("TCombobox", fieldbackground=AEGIS_FIELD, background=AEGIS_PANEL_2, foreground=AEGIS_TEXT, arrowcolor=AEGIS_GOLD)
        except Exception:
            logging.exception("Style configuration failed")

    def _load_settings(self) -> None:
        geometry = "900x720"
        selected_mode = "Standard"
        if self.safe_mode:
            self.geometry(geometry)
            return
        try:
            if SETTINGS_FILE.exists():
                data = json.loads(read_private_text(SETTINGS_FILE))
                geometry = str(data.get("geometry", geometry))[:MAX_GEOMETRY_CHARS]
                selected_mode = str(data.get("selected_mode", selected_mode))
                self.compact_mode.set(bool(data.get("compact_mode", False)))
        except Exception:
            logging.exception("Settings load failed; using defaults")
            geometry = "900x720"
        if selected_mode in MODES:
            self.current_mode.set(selected_mode)
        try:
            self.geometry(geometry)
        except Exception:
            logging.exception("Bad saved geometry; using default")
            self.geometry("900x720")

    def _save_settings(self) -> None:
        if self.safe_mode:
            return
        try:
            data = {"geometry": self.geometry(), "selected_mode": self.current_mode.get(), "compact_mode": self.compact_mode.get()}
            write_private_text(SETTINGS_FILE, json.dumps(data, indent=2))
        except Exception:
            logging.exception("Settings save failed")

    def _load_history(self) -> None:
        try:
            if HISTORY_FILE.exists():
                data = json.loads(read_private_text(HISTORY_FILE))
                if isinstance(data, dict):
                    for mode in MODES:
                        entries = data.get(mode, [])
                        if isinstance(entries, list):
                            self.history_by_mode[mode] = [str(item) for item in entries[:75]]
        except Exception:
            logging.exception("History load failed; using empty history")
            self.history_by_mode = {mode: [] for mode in MODES}

    def _save_history(self) -> None:
        if self.safe_mode:
            return
        try:
            write_private_text(HISTORY_FILE, json.dumps(self.history_by_mode, indent=2))
        except Exception:
            logging.exception("History save failed")

    def _load_window_icon(self) -> None:
        try:
            icon = resource_path("sentinel-calculator.png")
            self._window_icon = tk.PhotoImage(file=str(icon))
            self.iconphoto(True, self._window_icon)
            logging.info("Loaded icon: %s", icon)
        except Exception:
            logging.exception("Window icon load failed; continuing without icon")

    def _make_menu(self, parent: tk.Misc) -> tk.Menu:
        menu = tk.Menu(
            parent,
            tearoff=False,
            bg=AEGIS_PANEL,
            fg=AEGIS_TEXT,
            activebackground=AEGIS_GOLD,
            activeforeground=AEGIS_BLACK,
            disabledforeground=AEGIS_MUTED,
            bd=0,
            relief="flat",
        )
        return menu

    def _build_menu(self) -> None:
        menubar = tk.Menu(
            self,
            bg=AEGIS_PANEL,
            fg=AEGIS_TEXT,
            activebackground=AEGIS_GOLD,
            activeforeground=AEGIS_BLACK,
            bd=0,
            relief="flat",
        )
        file_menu = self._make_menu(menubar)
        file_menu.add_command(label="New Calculation", accelerator="Ctrl+N", command=self.clear)
        file_menu.add_command(label="Clear Current History", accelerator="Ctrl+Shift+H", command=self.clear_history)
        file_menu.add_separator()
        file_menu.add_command(label="Quit", accelerator="Ctrl+Q", command=self.quit_app)
        menubar.add_cascade(label="File", menu=file_menu)

        edit_menu = self._make_menu(menubar)
        edit_menu.add_command(label="Copy Result", accelerator="Ctrl+Shift+C", command=self.copy_result)
        edit_menu.add_command(label="Copy Input", command=self.copy_expression)
        edit_menu.add_command(label="Paste", accelerator="Ctrl+V", command=self.paste_from_clipboard)
        edit_menu.add_separator()
        edit_menu.add_command(label="Backspace", accelerator="Backspace", command=self.backspace)
        edit_menu.add_command(label="Clear", accelerator="Esc", command=self.clear)
        menubar.add_cascade(label="Edit", menu=edit_menu)

        view_menu = self._make_menu(menubar)
        view_menu.add_checkbutton(label="Compact Mode", variable=self.compact_mode, command=self.apply_compact_mode)
        view_menu.add_separator()
        for mode in MODES:
            view_menu.add_command(label=f"Go to {mode}", command=lambda m=mode: self.select_mode(m))
        menubar.add_cascade(label="View", menu=view_menu)

        help_menu = self._make_menu(menubar)
        help_menu.add_command(label="Keyboard Shortcuts", accelerator="F1", command=self.show_shortcuts)
        help_menu.add_command(label="Mode Guide", command=self.show_mode_guide)
        help_menu.add_command(label="User Manual", command=self.show_user_manual)
        help_menu.add_command(label="Beta Test Checklist", command=self.show_beta_checklist)
        help_menu.add_command(label="Security Safety Scope", command=self.show_security_scope)
        help_menu.add_separator()
        help_menu.add_command(label="Open Log Location", command=self.show_log_location)
        help_menu.add_command(label="About Sentinel Calculator", command=self.show_about)
        menubar.add_cascade(label="Help", menu=help_menu)
        self.config(menu=menubar)

    def _build_ui(self) -> None:
        header_outer = tk.Frame(self, bg=AEGIS_GOLD, padx=1, pady=1)
        header_outer.pack(fill="x", padx=14, pady=(14, 8))
        header = tk.Frame(header_outer, bg=AEGIS_PANEL, padx=12, pady=10)
        header.pack(fill="x")
        icon_file = resource_path("sentinel-calculator.png")
        try:
            self._header_icon = tk.PhotoImage(file=str(icon_file))
            scale = max(1, max(self._header_icon.width(), self._header_icon.height()) // 52)
            self._header_icon = self._header_icon.subsample(scale, scale)
            tk.Label(header, image=self._header_icon, bg=AEGIS_PANEL).pack(side="left", padx=(0, 12))
        except Exception:
            logging.exception("Header icon failed")
            tk.Label(header, text="▣", bg=AEGIS_PANEL, fg=AEGIS_GOLD, font=("TkDefaultFont", 30, "bold")).pack(side="left", padx=(0, 12))

        title_box = tk.Frame(header, bg=AEGIS_PANEL)
        title_box.pack(side="left", fill="x", expand=True)
        tk.Label(title_box, text="Sentinel Calculator", bg=AEGIS_PANEL, fg=AEGIS_GOLD, font=("TkDefaultFont", 19, "bold")).pack(anchor="w")
        tk.Label(
            title_box,
            text=f"Program {PROGRAM_ID} · v{APP_VERSION} · AEGIS Dark / Sentinel Cyan · Calculators, converters, and defensive utilities",
            bg=AEGIS_PANEL,
            fg=AEGIS_CYAN,
            font=("TkDefaultFont", 9, "bold"),
        ).pack(anchor="w")
        tk.Label(
            title_box,
            text="Local-first core · optional manual-refresh market exchange tools",
            bg=AEGIS_PANEL,
            fg=AEGIS_MUTED,
            font=("TkDefaultFont", 9),
        ).pack(anchor="w")

        badge = tk.Frame(header, bg=AEGIS_FIELD, highlightbackground=AEGIS_CYAN, highlightthickness=1, padx=10, pady=6)
        badge.pack(side="right", padx=(12, 0))
        tk.Label(badge, text="AEGIS", bg=AEGIS_FIELD, fg=AEGIS_GOLD, font=("TkDefaultFont", 10, "bold")).pack(anchor="e")
        tk.Label(badge, text="SENTINEL", bg=AEGIS_FIELD, fg=AEGIS_CYAN, font=("TkDefaultFont", 8, "bold")).pack(anchor="e")

        self.notebook = ttk.Notebook(self, style="Sentinel.TNotebook")
        self.notebook.pack(fill="x", padx=14, pady=(0, 8))
        self.tab_frames: dict[str, tk.Frame] = {}
        for mode in MODES:
            frame = tk.Frame(self.notebook, bg=AEGIS_BG)
            self.tab_frames[mode] = frame
            self.notebook.add(frame, text=mode)
        self.notebook.bind("<<NotebookTabChanged>>", self.on_tab_changed)

        display_frame = tk.Frame(self, bg=AEGIS_PANEL, highlightbackground=AEGIS_CYAN, highlightthickness=1)
        display_frame.pack(fill="x", padx=14, pady=(0, 10))
        self.display = tk.Entry(display_frame, textvariable=self.expression_var, bg=AEGIS_PANEL, fg=AEGIS_TEXT, insertbackground=AEGIS_CYAN, relief="flat", justify="right", font=("TkDefaultFont", 22))
        self.display.pack(fill="x", padx=12, pady=(12, 4))
        self.display.bind("<Button-3>", self.show_context_menu)
        tk.Label(display_frame, textvariable=self.result_var, bg=AEGIS_PANEL, fg=AEGIS_CYAN, anchor="e", font=("TkDefaultFont", 12, "bold")).pack(fill="x", padx=12, pady=(0, 10))

        self.content_area = tk.Frame(self, bg=AEGIS_BG)
        self.content_area.pack(fill="both", expand=True, padx=14, pady=0)
        self.mode_panels: dict[str, tk.Frame] = {}
        for mode in MODES:
            self.mode_panels[mode] = tk.Frame(self.content_area, bg=AEGIS_PANEL, highlightbackground=AEGIS_BORDER, highlightthickness=1, padx=10, pady=10)

        self._build_standard_panel()
        self._build_scientific_panel()
        self._build_unit_converter_panel()
        self._build_currency_converter_panel()
        self._build_market_exchange_panel()
        self._build_programmer_panel()
        self._build_network_panel()
        self._build_security_panel()
        self._build_electronics_panel()

        self.bottom = tk.Frame(self, bg=AEGIS_BG)
        self.bottom.pack(fill="both", expand=False, padx=14, pady=(8, 12))
        self.history_frame = tk.Frame(self.bottom, bg=AEGIS_PANEL, highlightbackground=AEGIS_BORDER, highlightthickness=1)
        self.history_frame.pack(fill="both", expand=True)
        hist_header = tk.Frame(self.history_frame, bg=AEGIS_PANEL)
        hist_header.pack(fill="x", padx=10, pady=(8, 3))
        self.history_title = tk.Label(hist_header, text="Calculation Tape — Standard", bg=AEGIS_PANEL, fg=AEGIS_GOLD, anchor="w", font=("TkDefaultFont", 10, "bold"))
        self.history_title.pack(side="left")
        self._button(hist_header, "Clear", self.clear_history, "op").pack(side="right")
        self.history = tk.Listbox(self.history_frame, height=5, bg=AEGIS_PANEL_2, fg=AEGIS_TEXT, selectbackground=AEGIS_GOLD, selectforeground="#000000", relief="flat", highlightthickness=0, font=("TkDefaultFont", 10))
        self.history.pack(fill="both", padx=10, pady=(0, 10))
        self.history.bind("<Double-Button-1>", self.reuse_history)

        self.status_bar = tk.Label(self, textvariable=self.status_var, bg=AEGIS_BLACK, fg=AEGIS_CYAN, anchor="w", font=("TkDefaultFont", 9, "bold"))
        self.status_bar.pack(fill="x", side="bottom")

        self.context_menu = self._make_menu(self)
        self.context_menu.add_command(label="Copy Result", command=self.copy_result)
        self.context_menu.add_command(label="Copy Input", command=self.copy_expression)
        self.context_menu.add_command(label="Paste", command=self.paste_from_clipboard)
        self.context_menu.add_separator()
        self.context_menu.add_command(label="Clear", command=self.clear)

        self.select_mode(self.current_mode.get(), update_notebook=True)
        self.apply_compact_mode()

    def _button(self, parent: tk.Widget, text: str, command: Callable[[], None], style: str = "num") -> tk.Button:
        bg = AEGIS_PANEL_2
        fg = AEGIS_TEXT
        active_bg = AEGIS_PANEL_3
        active_fg = AEGIS_CYAN
        border = AEGIS_BORDER
        if style == "op":
            fg = AEGIS_GOLD
            active_fg = AEGIS_BLACK
            active_bg = AEGIS_GOLD
        elif style == "sci":
            fg = AEGIS_CYAN
            border = AEGIS_CYAN
            active_fg = AEGIS_BLACK
            active_bg = AEGIS_CYAN
        elif style == "danger":
            bg = AEGIS_DANGER
            fg = "#FFFFFF"
            active_bg = "#A03A3A"
            active_fg = "#FFFFFF"
            border = "#B05252"
        elif style == "equals":
            bg = AEGIS_GOLD
            fg = AEGIS_BLACK
            active_bg = AEGIS_GOLD_SOFT
            active_fg = AEGIS_BLACK
            border = AEGIS_CYAN
        return tk.Button(
            parent,
            text=text,
            command=command,
            bg=bg,
            fg=fg,
            activebackground=active_bg,
            activeforeground=active_fg,
            relief="flat",
            bd=0,
            highlightthickness=1,
            highlightbackground=border,
            highlightcolor=AEGIS_CYAN,
            font=("TkDefaultFont", 10, "bold"),
            cursor="hand2",
        )

    def _widget_bg(self, parent: tk.Widget, fallback: str = AEGIS_BG) -> str:
        try:
            return str(parent.cget("bg"))
        except Exception:
            return fallback

    def _label(self, parent: tk.Widget, text: str, **kwargs: Any) -> tk.Label:
        # Centralised label defaults. Use setdefault so callers can safely
        # override fg/bg/anchor without passing duplicate Tk keyword arguments.
        kwargs.setdefault("bg", self._widget_bg(parent))
        kwargs.setdefault("fg", AEGIS_TEXT)
        kwargs.setdefault("anchor", "w")
        return tk.Label(parent, text=text, **kwargs)

    def _entry(self, parent: tk.Widget, var: tk.StringVar | None = None) -> tk.Entry:
        entry = tk.Entry(
            parent,
            textvariable=var,
            bg=AEGIS_FIELD,
            fg=AEGIS_TEXT,
            insertbackground=AEGIS_CYAN,
            relief="flat",
            highlightthickness=1,
            highlightbackground=AEGIS_BORDER,
            highlightcolor=AEGIS_CYAN,
            font=("TkDefaultFont", 11),
        )
        entry.bind("<Button-3>", self.show_context_menu)
        return entry

    def _text(self, parent: tk.Widget, height: int = 6) -> tk.Text:
        text = tk.Text(
            parent,
            height=height,
            bg=AEGIS_FIELD,
            fg=AEGIS_TEXT,
            insertbackground=AEGIS_CYAN,
            relief="flat",
            highlightthickness=1,
            highlightbackground=AEGIS_BORDER,
            highlightcolor=AEGIS_CYAN,
            wrap="word",
            font=("TkDefaultFont", 10),
        )
        text.bind("<Button-3>", self.show_context_menu)
        return text

    def _build_keypad(self, panel: tk.Frame, buttons: list[tuple[str, Callable[[], None], str]], columns: int) -> None:
        for col in range(columns):
            panel.columnconfigure(col, weight=1, uniform="key")
        rows = (len(buttons) + columns - 1) // columns
        for row in range(rows):
            panel.rowconfigure(row, weight=1, uniform="key")
        for index, (label, command, style) in enumerate(buttons):
            row, col = divmod(index, columns)
            self._button(panel, label, command, style).grid(row=row, column=col, sticky="nsew", padx=3, pady=3)

    def _build_standard_panel(self) -> None:
        panel = self.mode_panels["Standard"]
        buttons = [
            ("C", self.clear, "danger"), ("DEL", self.backspace, "op"), ("(", lambda: self.insert("("), "op"), (")", lambda: self.insert(")"), "op"),
            ("7", lambda: self.insert("7"), "num"), ("8", lambda: self.insert("8"), "num"), ("9", lambda: self.insert("9"), "num"), ("÷", lambda: self.insert("÷"), "op"),
            ("4", lambda: self.insert("4"), "num"), ("5", lambda: self.insert("5"), "num"), ("6", lambda: self.insert("6"), "num"), ("×", lambda: self.insert("×"), "op"),
            ("1", lambda: self.insert("1"), "num"), ("2", lambda: self.insert("2"), "num"), ("3", lambda: self.insert("3"), "num"), ("-", lambda: self.insert("-"), "op"),
            ("0", lambda: self.insert("0"), "num"), (".", lambda: self.insert("."), "num"), ("%", lambda: self.insert("/100"), "op"), ("+", lambda: self.insert("+"), "op"),
            ("Ans", self.insert_answer, "op"), ("Copy", self.copy_result, "op"), ("=", self.evaluate_math, "equals"), ("↵", self.evaluate_math, "equals"),
        ]
        self._build_keypad(panel, buttons, 4)

    def _build_scientific_panel(self) -> None:
        panel = self.mode_panels["Scientific"]
        buttons = [
            ("C", self.clear, "danger"), ("DEL", self.backspace, "op"), ("(", lambda: self.insert("("), "op"), (")", lambda: self.insert(")"), "op"), ("÷", lambda: self.insert("÷"), "op"),
            ("sin", lambda: self.insert("sin("), "sci"), ("cos", lambda: self.insert("cos("), "sci"), ("tan", lambda: self.insert("tan("), "sci"), ("√", lambda: self.insert("sqrt("), "sci"), ("×", lambda: self.insert("×"), "op"),
            ("asin", lambda: self.insert("asin("), "sci"), ("acos", lambda: self.insert("acos("), "sci"), ("atan", lambda: self.insert("atan("), "sci"), ("x²", lambda: self.insert("^2"), "sci"), ("-", lambda: self.insert("-"), "op"),
            ("ln", lambda: self.insert("ln("), "sci"), ("log", lambda: self.insert("log("), "sci"), ("exp", lambda: self.insert("exp("), "sci"), ("xʸ", lambda: self.insert("^"), "sci"), ("+", lambda: self.insert("+"), "op"),
            ("7", lambda: self.insert("7"), "num"), ("8", lambda: self.insert("8"), "num"), ("9", lambda: self.insert("9"), "num"), ("π", lambda: self.insert("pi"), "sci"), ("=", self.evaluate_math, "equals"),
            ("4", lambda: self.insert("4"), "num"), ("5", lambda: self.insert("5"), "num"), ("6", lambda: self.insert("6"), "num"), ("e", lambda: self.insert("e"), "sci"), ("↵", self.evaluate_math, "equals"),
            ("1", lambda: self.insert("1"), "num"), ("2", lambda: self.insert("2"), "num"), ("3", lambda: self.insert("3"), "num"), ("tau", lambda: self.insert("tau"), "sci"), ("Copy", self.copy_result, "op"),
            ("0", lambda: self.insert("0"), "num"), (".", lambda: self.insert("."), "num"), ("abs", lambda: self.insert("abs("), "sci"), ("fact", lambda: self.insert("fact("), "sci"), ("Ans", self.insert_answer, "op"),
        ]
        self._build_keypad(panel, buttons, 5)


    def _style_option_menu(self, option: tk.OptionMenu) -> None:
        option.configure(
            bg=AEGIS_PANEL_2,
            fg=AEGIS_TEXT,
            activebackground=AEGIS_GOLD,
            activeforeground=AEGIS_BLACK,
            relief="flat",
            highlightthickness=1,
            highlightbackground=AEGIS_BORDER,
        )
        option["menu"].configure(bg=AEGIS_PANEL_2, fg=AEGIS_TEXT, activebackground=AEGIS_GOLD, activeforeground=AEGIS_BLACK)

    def _reset_option_menu(self, option: tk.OptionMenu, variable: tk.StringVar, values: list[str]) -> None:
        menu = option["menu"]
        menu.delete(0, "end")
        for value in values:
            menu.add_command(label=value, command=lambda v=value: variable.set(v))

    def _build_unit_converter_panel(self) -> None:
        panel = self.mode_panels["Unit Converter"]
        panel.columnconfigure(0, weight=1)
        panel.columnconfigure(1, weight=1)
        panel.rowconfigure(6, weight=1)

        self._label(panel, "Offline unit converter", font=("TkDefaultFont", 11, "bold"), fg=AEGIS_GOLD).grid(row=0, column=0, columnspan=2, sticky="ew")
        self._label(panel, "Converts common workshop, computing, cooking, science, and networking units without internet access.", fg=AEGIS_MUTED).grid(row=1, column=0, columnspan=2, sticky="ew", pady=(0, 8))

        self.unit_category = tk.StringVar(value="Length")
        self.unit_value = tk.StringVar(value="1")
        self.unit_from = tk.StringVar(value="metre (m)")
        self.unit_to = tk.StringVar(value="kilometre (km)")

        self._label(panel, "Category", fg=AEGIS_MUTED).grid(row=2, column=0, sticky="ew", padx=(0, 8))
        self._label(panel, "Value", fg=AEGIS_MUTED).grid(row=2, column=1, sticky="ew", padx=(8, 0))
        category_menu = tk.OptionMenu(panel, self.unit_category, *list(UNIT_CATEGORIES.keys()), "Temperature", "Fuel Economy", command=lambda _v: self.unit_category_changed())
        self._style_option_menu(category_menu)
        category_menu.grid(row=3, column=0, sticky="ew", padx=(0, 8), pady=(0, 8))
        self._entry(panel, self.unit_value).grid(row=3, column=1, sticky="ew", padx=(8, 0), pady=(0, 8))

        self._label(panel, "From", fg=AEGIS_MUTED).grid(row=4, column=0, sticky="ew", padx=(0, 8))
        self._label(panel, "To", fg=AEGIS_MUTED).grid(row=4, column=1, sticky="ew", padx=(8, 0))
        self.unit_from_menu = tk.OptionMenu(panel, self.unit_from, *unit_names_for_category("Length"))
        self.unit_to_menu = tk.OptionMenu(panel, self.unit_to, *unit_names_for_category("Length"))
        self._style_option_menu(self.unit_from_menu)
        self._style_option_menu(self.unit_to_menu)
        self.unit_from_menu.grid(row=5, column=0, sticky="ew", padx=(0, 8), pady=(0, 8))
        self.unit_to_menu.grid(row=5, column=1, sticky="ew", padx=(8, 0), pady=(0, 8))

        self.unit_output = self._text(panel, height=8)
        self.unit_output.grid(row=6, column=0, columnspan=2, sticky="nsew", pady=6)
        btns = tk.Frame(panel, bg=AEGIS_BG)
        btns.grid(row=7, column=0, columnspan=2, sticky="ew")
        for i in range(4):
            btns.columnconfigure(i, weight=1)
        self._button(btns, "Convert", self.unit_convert_ui, "equals").grid(row=0, column=0, sticky="ew", padx=2)
        self._button(btns, "Swap", self.unit_swap, "op").grid(row=0, column=1, sticky="ew", padx=2)
        self._button(btns, "Copy Result", lambda: self.copy_text_widget(self.unit_output), "op").grid(row=0, column=2, sticky="ew", padx=2)
        self._button(btns, "Clear", self.unit_clear, "danger").grid(row=0, column=3, sticky="ew", padx=2)

    def _build_currency_converter_panel(self) -> None:
        panel = self.mode_panels["Currency Converter"]
        panel.columnconfigure(0, weight=1)
        panel.columnconfigure(1, weight=1)
        panel.columnconfigure(2, weight=1)
        panel.rowconfigure(6, weight=1)

        self._label(panel, "Currency converter", font=("TkDefaultFont", 11, "bold"), fg=AEGIS_GOLD).grid(row=0, column=0, columnspan=3, sticky="ew")
        self._label(panel, "Uses latest-available online rates when refreshed, then stores a local cache for offline conversion. Informational only.", fg=AEGIS_MUTED).grid(row=1, column=0, columnspan=3, sticky="ew", pady=(0, 8))

        self.currency_amount = tk.StringVar(value="1")
        self.currency_from = tk.StringVar(value="AUD")
        self.currency_to = tk.StringVar(value="USD")
        self.currency_status = tk.StringVar(value=f"Provider: Frankfurter · Cache: {CURRENCY_CACHE_FILE}")

        self._label(panel, "Amount", fg=AEGIS_MUTED).grid(row=2, column=0, sticky="ew", padx=(0, 8))
        self._label(panel, "From", fg=AEGIS_MUTED).grid(row=2, column=1, sticky="ew", padx=4)
        self._label(panel, "To", fg=AEGIS_MUTED).grid(row=2, column=2, sticky="ew", padx=(8, 0))
        self._entry(panel, self.currency_amount).grid(row=3, column=0, sticky="ew", padx=(0, 8), pady=(0, 8))
        self._entry(panel, self.currency_from).grid(row=3, column=1, sticky="ew", padx=4, pady=(0, 8))
        self._entry(panel, self.currency_to).grid(row=3, column=2, sticky="ew", padx=(8, 0), pady=(0, 8))

        self._label(panel, f"Common codes: {CURRENCY_DEFAULTS}", fg=AEGIS_MUTED).grid(row=4, column=0, columnspan=3, sticky="ew")
        self.currency_output = self._text(panel, height=8)
        self.currency_output.grid(row=6, column=0, columnspan=3, sticky="nsew", pady=6)
        tk.Label(panel, textvariable=self.currency_status, bg=self._widget_bg(panel), fg=AEGIS_MUTED, anchor="w", font=("TkDefaultFont", 9)).grid(row=7, column=0, columnspan=3, sticky="ew", pady=(0, 6))

        btns = tk.Frame(panel, bg=AEGIS_BG)
        btns.grid(row=8, column=0, columnspan=3, sticky="ew")
        for i in range(5):
            btns.columnconfigure(i, weight=1)
        self._button(btns, "Refresh Online + Convert", self.currency_refresh_and_convert, "equals").grid(row=0, column=0, sticky="ew", padx=2)
        self._button(btns, "Convert Cached", self.currency_convert_cached, "op").grid(row=0, column=1, sticky="ew", padx=2)
        self._button(btns, "Swap", self.currency_swap, "op").grid(row=0, column=2, sticky="ew", padx=2)
        self._button(btns, "Copy Result", lambda: self.copy_text_widget(self.currency_output), "op").grid(row=0, column=3, sticky="ew", padx=2)
        self._button(btns, "Clear", self.currency_clear, "danger").grid(row=0, column=4, sticky="ew", padx=2)

    def _build_market_exchange_panel(self) -> None:
        panel = self.mode_panels["Market Exchange"]
        panel.columnconfigure(0, weight=1)
        panel.columnconfigure(1, weight=1)
        panel.columnconfigure(2, weight=1)
        panel.rowconfigure(8, weight=1)

        self._label(panel, "Crypto and stock/ETF market exchange", font=("TkDefaultFont", 11, "bold"), fg=AEGIS_GOLD).grid(row=0, column=0, columnspan=3, sticky="ew")
        self._label(panel, "Manual-refresh market lookup with local last-known cache. Informational only; no trading, wallet, or broker connection.", fg=AEGIS_MUTED).grid(row=1, column=0, columnspan=3, sticky="ew", pady=(0, 8))

        self.market_type = tk.StringVar(value="Crypto")
        self.market_amount = tk.StringVar(value="1")
        self.market_symbol = tk.StringVar(value="BTC")
        self.market_quote = tk.StringVar(value="AUD")
        self.market_status = tk.StringVar(value=f"Providers: CoinGecko crypto · Stooq stocks/ETFs · Cache: {MARKET_CACHE_FILE}")

        self._label(panel, "Asset type", fg=AEGIS_MUTED).grid(row=2, column=0, sticky="ew", padx=(0, 8))
        self._label(panel, "Amount / units held", fg=AEGIS_MUTED).grid(row=2, column=1, sticky="ew", padx=4)
        self._label(panel, "Quote currency", fg=AEGIS_MUTED).grid(row=2, column=2, sticky="ew", padx=(8, 0))
        market_menu = tk.OptionMenu(panel, self.market_type, *MARKET_TYPES, command=lambda _v: self.market_type_changed())
        self._style_option_menu(market_menu)
        market_menu.grid(row=3, column=0, sticky="ew", padx=(0, 8), pady=(0, 8))
        self._entry(panel, self.market_amount).grid(row=3, column=1, sticky="ew", padx=4, pady=(0, 8))
        self._entry(panel, self.market_quote).grid(row=3, column=2, sticky="ew", padx=(8, 0), pady=(0, 8))

        self._label(panel, "Symbol / coin", fg=AEGIS_MUTED).grid(row=4, column=0, sticky="ew", padx=(0, 8))
        self.market_hint = tk.StringVar(value="Crypto examples: BTC, ETH, SOL, DOGE, or CoinGecko id like bitcoin")
        self._label(panel, "Examples / note", fg=AEGIS_MUTED).grid(row=4, column=1, columnspan=2, sticky="ew", padx=(4, 0))
        self._entry(panel, self.market_symbol).grid(row=5, column=0, sticky="ew", padx=(0, 8), pady=(0, 8))
        tk.Label(panel, textvariable=self.market_hint, bg=self._widget_bg(panel), fg=AEGIS_MUTED, anchor="w", font=("TkDefaultFont", 9)).grid(row=5, column=1, columnspan=2, sticky="ew", padx=(4, 0), pady=(0, 8))

        self._label(panel, "Scope", fg=AEGIS_GOLD, font=("TkDefaultFont", 10, "bold")).grid(row=6, column=0, sticky="ew")
        self._label(panel, MARKET_PROVIDER_NOTE, fg=AEGIS_MUTED).grid(row=6, column=1, columnspan=2, sticky="ew")

        self.market_output = self._text(panel, height=9)
        self.market_output.grid(row=8, column=0, columnspan=3, sticky="nsew", pady=6)
        tk.Label(panel, textvariable=self.market_status, bg=self._widget_bg(panel), fg=AEGIS_MUTED, anchor="w", font=("TkDefaultFont", 9)).grid(row=9, column=0, columnspan=3, sticky="ew", pady=(0, 6))

        btns = tk.Frame(panel, bg=AEGIS_BG)
        btns.grid(row=10, column=0, columnspan=3, sticky="ew")
        for i in range(4):
            btns.columnconfigure(i, weight=1)
        self._button(btns, "Refresh Online", self.market_refresh_and_convert, "equals").grid(row=0, column=0, sticky="ew", padx=2)
        self._button(btns, "Use Cached", self.market_convert_cached, "op").grid(row=0, column=1, sticky="ew", padx=2)
        self._button(btns, "Copy Result", lambda: self.copy_text_widget(self.market_output), "op").grid(row=0, column=2, sticky="ew", padx=2)
        self._button(btns, "Clear", self.market_clear, "danger").grid(row=0, column=3, sticky="ew", padx=2)

    def _build_programmer_panel(self) -> None:
        panel = self.mode_panels["Programmer"]
        panel.columnconfigure(0, weight=1)
        panel.columnconfigure(1, weight=1)
        panel.rowconfigure(0, weight=1)
        left = tk.Frame(panel, bg=AEGIS_BG)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        right = tk.Frame(panel, bg=AEGIS_BG)
        right.grid(row=0, column=1, sticky="nsew", padx=(8, 0))
        self._label(left, "Number conversion", font=("TkDefaultFont", 11, "bold"), fg=AEGIS_GOLD).pack(fill="x")
        self.prog_value = tk.StringVar()
        self._entry(left, self.prog_value).pack(fill="x", pady=6)
        self.prog_output = self._text(left, height=7)
        self.prog_output.pack(fill="both", expand=True)
        prog_buttons = tk.Frame(left, bg=AEGIS_BG)
        prog_buttons.pack(fill="x", pady=(6, 0))
        for i in range(3): prog_buttons.columnconfigure(i, weight=1)
        self._button(prog_buttons, "Convert", self.programmer_convert, "equals").grid(row=0, column=0, sticky="ew", padx=2)
        self._button(prog_buttons, "Use Input", lambda: self.prog_value.set(self.expression_var.get()), "op").grid(row=0, column=1, sticky="ew", padx=2)
        self._button(prog_buttons, "To Input", self.programmer_to_input, "op").grid(row=0, column=2, sticky="ew", padx=2)

        self._label(right, "Bitwise operation", font=("TkDefaultFont", 11, "bold"), fg=AEGIS_GOLD).pack(fill="x")
        row1 = tk.Frame(right, bg=AEGIS_BG); row1.pack(fill="x", pady=6)
        row1.columnconfigure(0, weight=1); row1.columnconfigure(1, weight=1)
        self.prog_a = tk.StringVar(); self.prog_b = tk.StringVar()
        self._entry(row1, self.prog_a).grid(row=0, column=0, sticky="ew", padx=(0, 4))
        self._entry(row1, self.prog_b).grid(row=0, column=1, sticky="ew", padx=(4, 0))
        self.prog_bit_output = self._text(right, height=7); self.prog_bit_output.pack(fill="both", expand=True)
        bit_buttons = tk.Frame(right, bg=AEGIS_BG); bit_buttons.pack(fill="x", pady=(6, 0))
        for i in range(6): bit_buttons.columnconfigure(i, weight=1)
        ops = [("AND", "AND"), ("OR", "OR"), ("XOR", "XOR"), ("NOT A", "NOT"), ("A << B", "LSHIFT"), ("A >> B", "RSHIFT")]
        for idx, (label, op) in enumerate(ops):
            self._button(bit_buttons, label, lambda o=op: self.programmer_bitwise(o), "sci").grid(row=0, column=idx, sticky="ew", padx=2)

    def _build_network_panel(self) -> None:
        panel = self.mode_panels["Network"]
        panel.columnconfigure(0, weight=1); panel.columnconfigure(1, weight=2); panel.rowconfigure(1, weight=1)
        self._label(panel, "CIDR / subnet calculator", font=("TkDefaultFont", 11, "bold"), fg=AEGIS_GOLD).grid(row=0, column=0, columnspan=2, sticky="ew")
        self.net_cidr = tk.StringVar(value="192.168.1.0/24")
        self._entry(panel, self.net_cidr).grid(row=1, column=0, sticky="new", padx=(0, 8), pady=6)
        self.net_output = self._text(panel, height=12); self.net_output.grid(row=1, column=1, sticky="nsew", padx=(8, 0), pady=6)
        btns = tk.Frame(panel, bg=AEGIS_BG); btns.grid(row=2, column=0, columnspan=2, sticky="ew")
        for i in range(3): btns.columnconfigure(i, weight=1)
        self._button(btns, "Calculate CIDR", self.network_calculate, "equals").grid(row=0, column=0, sticky="ew", padx=2)
        self._button(btns, "Use Input Field", lambda: self.net_cidr.set(self.expression_var.get()), "op").grid(row=0, column=1, sticky="ew", padx=2)
        self._button(btns, "Copy Result", lambda: self.copy_text_widget(self.net_output), "op").grid(row=0, column=2, sticky="ew", padx=2)

    def _build_security_panel(self) -> None:
        panel = self.mode_panels["Security"]
        panel.columnconfigure(0, weight=1); panel.columnconfigure(1, weight=1); panel.rowconfigure(2, weight=1)
        self._label(panel, "Security tools are defensive/inspection-only: encodings, hashes, lengths, timestamps, and JWT viewing.", fg=AEGIS_MUTED).grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 6))
        controls = tk.Frame(panel, bg=AEGIS_BG); controls.grid(row=1, column=0, columnspan=2, sticky="ew"); controls.columnconfigure(1, weight=1)
        self.security_operation = tk.StringVar(value="Base64 Encode")
        tk.Label(controls, text="Operation", bg=AEGIS_BG, fg=AEGIS_GOLD, font=("TkDefaultFont", 10, "bold")).grid(row=0, column=0, sticky="w", padx=(0, 8))
        operations = ["Base64 Encode","Base64 Decode","URL Encode","URL Decode","Hex Encode","Hex Decode","Hashes","Lengths","Epoch To UTC","UTC To Epoch","JWT Viewer"]
        option = tk.OptionMenu(controls, self.security_operation, *operations)
        self._style_option_menu(option)
        option.grid(row=0, column=1, sticky="ew")
        left = tk.Frame(panel, bg=AEGIS_BG); left.grid(row=2, column=0, sticky="nsew", padx=(0, 8), pady=6)
        right = tk.Frame(panel, bg=AEGIS_BG); right.grid(row=2, column=1, sticky="nsew", padx=(8, 0), pady=6)
        left.rowconfigure(1, weight=1); right.rowconfigure(1, weight=1); left.columnconfigure(0, weight=1); right.columnconfigure(0, weight=1)
        self._label(left, "Input", font=("TkDefaultFont", 10, "bold"), fg=AEGIS_GOLD).grid(row=0, column=0, sticky="ew")
        self.security_input = self._text(left, height=10); self.security_input.grid(row=1, column=0, sticky="nsew")
        self._label(right, "Output", font=("TkDefaultFont", 10, "bold"), fg=AEGIS_GOLD).grid(row=0, column=0, sticky="ew")
        self.security_output = self._text(right, height=10); self.security_output.grid(row=1, column=0, sticky="nsew")
        btns = tk.Frame(panel, bg=AEGIS_BG); btns.grid(row=3, column=0, columnspan=2, sticky="ew")
        for i in range(4): btns.columnconfigure(i, weight=1)
        self._button(btns, "Run", self.security_run, "equals").grid(row=0, column=0, sticky="ew", padx=2)
        self._button(btns, "Input From Main", self.security_from_main, "op").grid(row=0, column=1, sticky="ew", padx=2)
        self._button(btns, "Output To Main", self.security_to_main, "op").grid(row=0, column=2, sticky="ew", padx=2)
        self._button(btns, "Copy Output", lambda: self.copy_text_widget(self.security_output), "op").grid(row=0, column=3, sticky="ew", padx=2)

    def _build_electronics_panel(self) -> None:
        panel = self.mode_panels["Electronics"]
        panel.columnconfigure(0, weight=1); panel.columnconfigure(1, weight=1); panel.rowconfigure(3, weight=1)
        self._label(panel, "Ohm's law helper", font=("TkDefaultFont", 11, "bold"), fg=AEGIS_GOLD).grid(row=0, column=0, columnspan=2, sticky="ew")
        self.elec_mode = tk.StringVar(value="Voltage from Current + Resistance")
        elec_modes = ["Voltage from Current + Resistance","Current from Voltage + Resistance","Resistance from Voltage + Current","Power from Voltage + Current"]
        opt = tk.OptionMenu(panel, self.elec_mode, *elec_modes)
        self._style_option_menu(opt)
        opt.grid(row=1, column=0, columnspan=2, sticky="ew", pady=6)
        self.elec_a = tk.StringVar(); self.elec_b = tk.StringVar()
        self._label(panel, "Value A", fg=AEGIS_MUTED).grid(row=2, column=0, sticky="ew", padx=(0, 8))
        self._label(panel, "Value B", fg=AEGIS_MUTED).grid(row=2, column=1, sticky="ew", padx=(8, 0))
        self._entry(panel, self.elec_a).grid(row=3, column=0, sticky="new", padx=(0, 8), pady=(0, 8))
        self._entry(panel, self.elec_b).grid(row=3, column=1, sticky="new", padx=(8, 0), pady=(0, 8))
        self.elec_output = self._text(panel, height=8); self.elec_output.grid(row=4, column=0, columnspan=2, sticky="nsew", pady=6)
        btns = tk.Frame(panel, bg=AEGIS_BG); btns.grid(row=5, column=0, columnspan=2, sticky="ew")
        for i in range(3): btns.columnconfigure(i, weight=1)
        self._button(btns, "Calculate", self.electronics_calculate, "equals").grid(row=0, column=0, sticky="ew", padx=2)
        self._button(btns, "Copy Result", lambda: self.copy_text_widget(self.elec_output), "op").grid(row=0, column=1, sticky="ew", padx=2)
        self._button(btns, "Clear", self.electronics_clear, "danger").grid(row=0, column=2, sticky="ew", padx=2)

    def _safe_bind(self, sequence: str, callback: Callable[..., Any]) -> None:
        try:
            self.bind(sequence, callback)
        except Exception:
            logging.exception("Non-fatal key binding failed: %s", sequence)

    def _tk_callback_exception(self, exc: type[BaseException], val: BaseException, tb: Any) -> None:
        logging.exception("Non-fatal Tk callback exception", exc_info=(exc, val, tb))
        try:
            self.status_var.set(f"Non-fatal UI warning: {val}")
        except Exception:
            pass

    def _bind_keys(self) -> None:
        # Key bindings are non-fatal. Some Tk/MATE builds reject certain
        # modifier/key patterns; the app must not crash because one shortcut fails.
        bindings = [
            ("<Return>", lambda _event: self.evaluate_or_run_current()),
            ("<KP_Enter>", lambda _event: self.evaluate_or_run_current()),
            ("<Escape>", lambda _event: self.clear()),
            ("<Control-n>", lambda _event: self.clear()),
            ("<Control-q>", lambda _event: self.quit_app()),
            ("<Control-w>", lambda _event: self.quit_app()),
            ("<Control-l>", lambda _event: self.focus_entry()),
            ("<F1>", lambda _event: self.show_shortcuts()),
            ("<Control-Shift-c>", lambda _event: self.copy_result()),
            ("<Control-Shift-h>", lambda _event: self.clear_history()),
        ]

        for sequence, callback in bindings:
            self._safe_bind(sequence, callback)

        for i, mode in enumerate(MODES, start=1):
            self._safe_bind(f"<Alt-KeyPress-{i}>", lambda _event, m=mode: self.select_mode(m, update_notebook=True))

    def show_context_menu(self, event: tk.Event) -> None:
        try:
            self.context_menu.tk_popup(event.x_root, event.y_root)
        finally:
            self.context_menu.grab_release()

    def on_tab_changed(self, _event: tk.Event) -> None:
        try:
            selected_id = self.notebook.select()
            mode = self.notebook.tab(selected_id, "text")
            self.select_mode(mode, update_notebook=False)
        except Exception:
            logging.exception("Tab change failed")

    def select_mode(self, mode: str, update_notebook: bool = False) -> None:
        if mode not in MODES:
            mode = "Standard"
        self.current_mode.set(mode)
        if update_notebook and hasattr(self, "notebook"):
            try:
                self.notebook.select(MODES.index(mode))
            except Exception:
                logging.exception("Notebook select failed")
        if hasattr(self, "mode_panels"):
            for panel in self.mode_panels.values():
                panel.pack_forget()
            self.mode_panels[mode].pack(fill="both", expand=True)
        if hasattr(self, "history_title"):
            self.history_title.config(text=f"Calculation Tape — {mode}")
        self.status_var.set(f"{mode} mode ready")
        self._refresh_history_list()

    def focus_entry(self) -> None:
        self.display.focus_set()
        self.display.icursor(tk.END)

    def insert(self, value: str) -> None:
        self.display.insert(tk.INSERT, value)
        self.result_var.set("")
        self.status_var.set("Editing")

    def clear(self) -> None:
        self.expression_var.set("")
        self.result_var.set("Ready")
        self.status_var.set(f"{self.current_mode.get()} mode ready")
        self.focus_entry()

    def backspace(self) -> None:
        current = self.expression_var.get()
        index = self.display.index(tk.INSERT)
        if index > 0:
            self.expression_var.set(current[:index - 1] + current[index:])
            self.display.icursor(index - 1)
        self.status_var.set("Editing")

    def insert_answer(self) -> None:
        if self.last_result:
            self.insert(self.last_result)

    def evaluate_or_run_current(self) -> None:
        mode = self.current_mode.get()
        if mode in ("Standard", "Scientific"):
            self.evaluate_math()
        elif mode == "Unit Converter":
            self.unit_convert_ui()
        elif mode == "Currency Converter":
            self.currency_convert_cached()
        elif mode == "Market Exchange":
            self.market_convert_cached()
        elif mode == "Programmer":
            self.programmer_convert()
        elif mode == "Network":
            self.network_calculate()
        elif mode == "Security":
            self.security_run()
        elif mode == "Electronics":
            self.electronics_calculate()

    def evaluate_math(self) -> None:
        expression = self.expression_var.get()
        try:
            result = calculate_expression(expression)
            result_text = format_number(result)
        except CalculatorError as exc:
            self.result_var.set(f"Error: {exc}")
            self.status_var.set("Calculation error")
            return
        self.last_result = result_text
        self.result_var.set(f"= {result_text}")
        self.status_var.set("Calculated")
        self._add_history_item(f"{expression} = {result_text}")
        self.focus_entry()


    def unit_category_changed(self) -> None:
        try:
            units = unit_names_for_category(self.unit_category.get())
            self._reset_option_menu(self.unit_from_menu, self.unit_from, units)
            self._reset_option_menu(self.unit_to_menu, self.unit_to, units)
            self.unit_from.set(units[0])
            self.unit_to.set(units[1] if len(units) > 1 else units[0])
            self.status_var.set(f"{self.unit_category.get()} units loaded")
        except Exception as exc:
            self.status_var.set(f"Unit category error: {exc}")

    def unit_convert_ui(self) -> None:
        try:
            value = float(self.unit_value.get().strip())
            category = self.unit_category.get()
            from_unit = self.unit_from.get()
            to_unit = self.unit_to.get()
            result = convert_unit(category, value, from_unit, to_unit)
            report = (
                f"{format_number(value)} {from_unit}\n"
                f"= {format_number(result)} {to_unit}\n\n"
                f"Category: {category}\n"
                "Mode: offline unit conversion"
            )
        except Exception as exc:
            self._set_text(self.unit_output, f"Error: {exc}")
            self.status_var.set("Unit conversion error")
            return
        self._set_text(self.unit_output, report)
        self.last_result = f"{format_number(result)} {to_unit}"
        self.result_var.set(f"= {self.last_result}")
        self._add_history_item(f"{format_number(value)} {from_unit} → {self.last_result}")
        self.status_var.set("Unit conversion complete")

    def unit_swap(self) -> None:
        current_from = self.unit_from.get()
        self.unit_from.set(self.unit_to.get())
        self.unit_to.set(current_from)
        self.status_var.set("Unit direction swapped")

    def unit_clear(self) -> None:
        self.unit_value.set("")
        self._set_text(self.unit_output, "")
        self.status_var.set("Unit converter cleared")

    def _currency_values(self) -> tuple[float, str, str]:
        amount = float(self.currency_amount.get().strip())
        from_code = normalize_currency_code(self.currency_from.get())
        to_code = normalize_currency_code(self.currency_to.get())
        self.currency_from.set(from_code)
        self.currency_to.set(to_code)
        return amount, from_code, to_code

    def _currency_report(self, amount: float, from_code: str, to_code: str, rate: float, rate_date: str, source: str) -> str:
        result = currency_convert_with_rate(amount, rate)
        return (
            f"{format_number(amount)} {from_code}\n"
            f"= {format_number(result)} {to_code}\n\n"
            f"Rate: 1 {from_code} = {format_number(rate)} {to_code}\n"
            f"Rate date: {rate_date}\n"
            f"Source: {source}\n"
            "Note: latest-available reference rate, informational only."
        )

    def currency_refresh_and_convert(self) -> None:
        try:
            amount, from_code, to_code = self._currency_values()
            rate, rate_date, source = fetch_latest_currency_rate(from_code, to_code)
            update_currency_cache(from_code, to_code, rate, rate_date, source)
            report = self._currency_report(amount, from_code, to_code, rate, rate_date, source)
            result = currency_convert_with_rate(amount, rate)
        except (urllib.error.URLError, TimeoutError) as exc:
            self._set_text(self.currency_output, f"Online refresh failed: {exc}\n\nTry Convert Cached if a saved rate exists.")
            self.currency_status.set("Currency refresh failed; cache unchanged")
            self.status_var.set("Currency online refresh failed")
            return
        except Exception as exc:
            self._set_text(self.currency_output, f"Error: {exc}")
            self.currency_status.set("Currency conversion error")
            self.status_var.set("Currency conversion error")
            return
        self._set_text(self.currency_output, report)
        self.last_result = f"{format_number(result)} {to_code}"
        self.result_var.set(f"= {self.last_result}")
        self._add_history_item(f"{format_number(amount)} {from_code} → {self.last_result}")
        self.currency_status.set(f"Latest refresh saved: {from_code}/{to_code} · {rate_date} · {source}")
        self.status_var.set("Currency refreshed and converted")

    def currency_convert_cached(self) -> None:
        try:
            amount, from_code, to_code = self._currency_values()
            rate, rate_date, source = get_cached_currency_rate(from_code, to_code)
            report = self._currency_report(amount, from_code, to_code, rate, rate_date, source)
            result = currency_convert_with_rate(amount, rate)
        except Exception as exc:
            self._set_text(self.currency_output, f"Error: {exc}")
            self.currency_status.set("Cached conversion unavailable")
            self.status_var.set("Cached currency conversion error")
            return
        self._set_text(self.currency_output, report)
        self.last_result = f"{format_number(result)} {to_code}"
        self.result_var.set(f"= {self.last_result}")
        self._add_history_item(f"{format_number(amount)} {from_code} → {self.last_result} cached")
        self.currency_status.set(f"Used cached rate: {from_code}/{to_code} · {rate_date}")
        self.status_var.set("Cached currency conversion complete")

    def currency_swap(self) -> None:
        current_from = self.currency_from.get()
        self.currency_from.set(self.currency_to.get())
        self.currency_to.set(current_from)
        self.status_var.set("Currency direction swapped")

    def currency_clear(self) -> None:
        self.currency_amount.set("")
        self._set_text(self.currency_output, "")
        self.status_var.set("Currency converter cleared")

    def market_type_changed(self) -> None:
        kind = self.market_type.get()
        if kind == "Crypto":
            self.market_symbol.set("BTC")
            self.market_quote.set("AUD")
            self.market_hint.set("Crypto examples: BTC, ETH, SOL, DOGE, or CoinGecko id like bitcoin")
        else:
            self.market_symbol.set("AAPL.US")
            self.market_quote.set("USD")
            self.market_hint.set(MARKET_DEFAULT_STOCKS + " · quote currency is a display label from the source market")
        self.status_var.set(f"{kind} market lookup ready")

    def _market_values(self) -> tuple[float, str, str, str]:
        amount = float(self.market_amount.get().strip())
        kind = normalize_market_type(self.market_type.get())
        symbol = self.market_symbol.get().strip()
        quote_code = normalize_currency_code(self.market_quote.get())
        self.market_type.set(kind)
        self.market_quote.set(quote_code)
        if kind == "Crypto":
            self.market_symbol.set(symbol.upper() if symbol.upper() in CRYPTO_SYMBOL_IDS else normalize_crypto_asset(symbol))
        else:
            self.market_symbol.set(normalize_stock_symbol(symbol))
        return amount, kind, symbol, quote_code

    def _market_report(self, amount: float, data: dict[str, Any], source: str) -> tuple[str, float]:
        price = float(data.get("price"))
        quote_code = str(data.get("quote", self.market_quote.get())).upper()
        symbol = str(data.get("symbol", self.market_symbol.get()))
        value = market_value(amount, price)
        change = data.get("change_24h")
        change_line = ""
        if isinstance(change, (int, float)):
            change_line = f"\n24h change: {float(change):.4g}%"
        elif data.get("open") or data.get("high") or data.get("low"):
            change_line = (
                f"\nOpen: {data.get('open', '')}"
                f"\nHigh: {data.get('high', '')}"
                f"\nLow: {data.get('low', '')}"
                f"\nVolume: {data.get('volume', '')}"
            )
        report = (
            f"{format_number(amount)} × {symbol}\n"
            f"≈ {format_number(value)} {quote_code}\n\n"
            f"Unit price: {format_number(price)} {quote_code}\n"
            f"Asset type: {data.get('asset_type', self.market_type.get())}\n"
            f"Updated: {data.get('updated', 'unknown')}"
            f"{change_line}\n"
            f"Source: {source}\n"
            "Note: manual-refresh market reference only; not financial advice."
        )
        return report, value

    def market_refresh_and_convert(self) -> None:
        try:
            amount, kind, symbol, quote_code = self._market_values()
            data = fetch_market_price(kind, symbol, quote_code)
            update_market_cache(kind, symbol, quote_code, data)
            report, value = self._market_report(amount, data, str(data.get("provider", "online")))
        except (urllib.error.URLError, TimeoutError) as exc:
            self._set_text(self.market_output, f"Online market refresh failed: {exc}\n\nTry Use Cached if a saved price exists.")
            self.market_status.set("Market refresh failed; cache unchanged")
            self.status_var.set("Market online refresh failed")
            return
        except Exception as exc:
            self._set_text(self.market_output, f"Error: {exc}")
            self.market_status.set("Market exchange error")
            self.status_var.set("Market exchange error")
            return
        self._set_text(self.market_output, report)
        quote_code = str(data.get("quote", quote_code)).upper()
        self.last_result = f"{format_number(value)} {quote_code}"
        self.result_var.set(f"≈ {self.last_result}")
        self._add_history_item(f"Market {format_number(amount)} × {data.get('symbol', symbol)} → {self.last_result}")
        self.market_status.set(f"Latest refresh saved: {data.get('symbol', symbol)} · {data.get('provider', 'online')} · {data.get('updated', 'unknown')}")
        self.status_var.set("Market price refreshed")

    def market_convert_cached(self) -> None:
        try:
            amount, kind, symbol, quote_code = self._market_values()
            data = get_cached_market_price(kind, symbol, quote_code)
            report, value = self._market_report(amount, data, "cache / " + str(data.get("provider", "cached")))
        except Exception as exc:
            self._set_text(self.market_output, f"Error: {exc}")
            self.market_status.set("Cached market price unavailable")
            self.status_var.set("Cached market exchange error")
            return
        self._set_text(self.market_output, report)
        quote_code = str(data.get("quote", quote_code)).upper()
        self.last_result = f"{format_number(value)} {quote_code}"
        self.result_var.set(f"≈ {self.last_result}")
        self._add_history_item(f"Cached market {format_number(amount)} × {data.get('symbol', symbol)} → {self.last_result}")
        self.market_status.set(f"Used cached price: {data.get('symbol', symbol)} · {data.get('updated', 'unknown')}")
        self.status_var.set("Cached market price used")

    def market_clear(self) -> None:
        self.market_amount.set("")
        self._set_text(self.market_output, "")
        self.status_var.set("Market Exchange cleared")

    def programmer_convert(self) -> None:
        raw = self.prog_value.get().strip() or self.expression_var.get().strip()
        try:
            value = parse_int_any(raw)
            report = programmer_report(value)
        except Exception as exc:
            self._set_text(self.prog_output, f"Error: {exc}")
            self.status_var.set("Programmer conversion error")
            return
        self._set_text(self.prog_output, report)
        self.last_result = str(value)
        self.result_var.set(f"= {value}")
        self._add_history_item(f"Convert {raw} → {value}")
        self.status_var.set("Programmer conversion complete")

    def programmer_to_input(self) -> None:
        try:
            value = parse_int_any(self.prog_value.get())
            self.expression_var.set(str(value))
            self.focus_entry()
        except Exception as exc:
            self.status_var.set(f"Programmer error: {exc}")

    def programmer_bitwise(self, op: str) -> None:
        try:
            a = parse_int_any(self.prog_a.get())
            if op == "NOT":
                result = ~a
                report = f"~{a} = {result}\n\n{programmer_report(result)}"
            else:
                b = parse_int_any(self.prog_b.get())
                mapping = {"AND": ("&", a & b), "OR": ("|", a | b), "XOR": ("^", a ^ b), "LSHIFT": ("<<", a << b), "RSHIFT": (">>", a >> b)}
                symbol, result = mapping[op]
                report = f"{a} {symbol} {b} = {result}\n\n{programmer_report(result)}"
        except Exception as exc:
            self._set_text(self.prog_bit_output, f"Error: {exc}")
            self.status_var.set("Bitwise error")
            return
        self._set_text(self.prog_bit_output, report)
        self.last_result = str(result)
        self.result_var.set(f"= {result}")
        self._add_history_item(report.splitlines()[0])
        self.status_var.set("Bitwise operation complete")

    def network_calculate(self) -> None:
        cidr = self.net_cidr.get().strip() or self.expression_var.get().strip()
        try:
            report = cidr_report(cidr)
        except Exception as exc:
            self._set_text(self.net_output, f"Error: {exc}")
            self.status_var.set("Network calculation error")
            return
        self._set_text(self.net_output, report)
        self.last_result = report.splitlines()[0]
        self.result_var.set("CIDR calculated")
        self._add_history_item(f"CIDR {cidr}")
        self.status_var.set("Network calculation complete")

    def security_from_main(self) -> None:
        self._set_text(self.security_input, self.expression_var.get())
        self.status_var.set("Main input copied to Security tab")

    def security_to_main(self) -> None:
        value = self.security_output.get("1.0", "end-1c")
        self.expression_var.set(value)
        self.status_var.set("Security output copied to main input")

    def security_run(self) -> None:
        op = self.security_operation.get()
        text = self.security_input.get("1.0", "end-1c")
        try:
            output = security_transform(op, text)
        except Exception as exc:
            output = f"Error: {exc}"
            self.status_var.set("Security tool error")
        else:
            self.last_result = output
            self.result_var.set(f"{op} complete")
            self._add_history_item(f"{op}: {len(text)} chars")
            self.status_var.set("Security operation complete")
        self._set_text(self.security_output, output)

    def electronics_calculate(self) -> None:
        try:
            a = float(self.elec_a.get().strip())
            b = float(self.elec_b.get().strip())
            result = ohms_law(self.elec_mode.get(), a, b)
        except Exception as exc:
            self._set_text(self.elec_output, f"Error: {exc}")
            self.status_var.set("Electronics calculation error")
            return
        self._set_text(self.elec_output, result)
        self.last_result = result.splitlines()[0]
        self.result_var.set("Electronics calculated")
        self._add_history_item(f"{self.elec_mode.get()}: {a}, {b}")
        self.status_var.set("Electronics calculation complete")

    def electronics_clear(self) -> None:
        self.elec_a.set("")
        self.elec_b.set("")
        self._set_text(self.elec_output, "")
        self.status_var.set("Electronics cleared")

    def copy_result(self) -> None:
        value = self.last_result
        if not value:
            self.status_var.set("No result to copy")
            return
        self.clipboard_clear()
        self.clipboard_append(value)
        self.result_var.set("Copied")
        self.status_var.set("Result copied")

    def copy_expression(self) -> None:
        value = self.expression_var.get()
        if not value:
            self.status_var.set("No input to copy")
            return
        self.clipboard_clear()
        self.clipboard_append(value)
        self.status_var.set("Input copied")

    def paste_from_clipboard(self) -> None:
        try:
            value = self.clipboard_get()
        except Exception:
            self.status_var.set("Clipboard empty")
            return
        widget = self.focus_get()
        if isinstance(widget, tk.Text):
            widget.insert(tk.INSERT, value)
        elif isinstance(widget, tk.Entry):
            widget.insert(tk.INSERT, value)
        else:
            self.insert(value)
        self.status_var.set("Pasted")

    def copy_text_widget(self, widget: tk.Text) -> None:
        value = widget.get("1.0", "end-1c")
        if not value:
            self.status_var.set("Nothing to copy")
            return
        self.clipboard_clear()
        self.clipboard_append(value)
        self.last_result = value
        self.status_var.set("Text copied")

    def _set_text(self, widget: tk.Text, value: str) -> None:
        widget.delete("1.0", tk.END)
        widget.insert("1.0", value)

    def _add_history_item(self, item: str) -> None:
        mode = self.current_mode.get()
        self.history_by_mode.setdefault(mode, [])
        self.history_by_mode[mode].insert(0, item)
        self.history_by_mode[mode] = self.history_by_mode[mode][:75]
        self._save_history()
        self._refresh_history_list()

    def _refresh_history_list(self) -> None:
        if not hasattr(self, "history"):
            return
        self.history.delete(0, tk.END)
        mode = self.current_mode.get()
        for item in self.history_by_mode.get(mode, [])[:75]:
            self.history.insert(tk.END, item)

    def clear_history(self) -> None:
        mode = self.current_mode.get()
        self.history_by_mode[mode] = []
        self._save_history()
        self._refresh_history_list()
        self.status_var.set(f"{mode} history cleared")

    def reuse_history(self, _event: tk.Event) -> None:
        selection = self.history.curselection()
        if not selection:
            return
        item = self.history.get(selection[0])
        mode = self.current_mode.get()
        if mode in ("Standard", "Scientific") and " = " in item:
            expression, _result = item.split(" = ", 1)
            self.expression_var.set(expression)
        else:
            self.expression_var.set(item)
        self.focus_entry()
        self.status_var.set("History item loaded")

    def apply_compact_mode(self) -> None:
        if not hasattr(self, "history_frame"):
            return
        if self.compact_mode.get():
            self.history_frame.pack_forget()
            self.status_var.set("Compact mode enabled")
        else:
            if not self.history_frame.winfo_ismapped():
                self.history_frame.pack(fill="both", expand=True)
            self.status_var.set("Compact mode disabled")

    def show_shortcuts(self) -> None:
        messagebox.showinfo(
            "Sentinel Calculator Keyboard Shortcuts",
            "Enter / Numpad Enter: Run current mode\n"
            "Esc: Clear main input\n"
            "Ctrl+N: New calculation\n"
            "Ctrl+L: Focus main input\n"
            "Ctrl+Shift+C: Copy result\n"
            "Ctrl+Shift+H: Clear current mode history\n"
            "Ctrl+Q: Quit / close application\n"
            "Ctrl+W: Close application\n"
            "Alt+1..Alt+8: Switch modes\n"
            "F1: Keyboard shortcuts",
        )

    def show_mode_guide(self) -> None:
        messagebox.showinfo(
            "Sentinel Calculator Mode Guide",
            "Standard: everyday arithmetic.\n\n"
            "Scientific: trig, roots, logs, powers, constants.\n\n"
            "Programmer: DEC/HEX/BIN/OCT conversion and bitwise operations.\n\n"
            "Network: CIDR/subnet calculations for IPv4 and IPv6.\n\n"
            "Security: defensive inspection tools only.\n\n"
            "Electronics: Ohm's law and basic electrical formulas.",
        )

    def show_user_manual(self) -> None:
        messagebox.showinfo(
            "Sentinel Calculator User Manual",
            "1. Choose a calculator mode using the tabs above the input field.\n"
            "2. Enter a value or expression.\n"
            "3. Press Enter or use the mode's Calculate/Run button.\n"
            "4. Copy results from the result display, output panels, or history.\n\n"
            "Close application: Ctrl+Q.\n\n"
            f"Crash log:\n{LOG_FILE}",
        )

    def show_beta_checklist(self) -> None:
        messagebox.showinfo(
            "Sentinel Calculator Beta Test Checklist",
            "Beta checks:\n"
            "- Ctrl+Q closes the app.\n"
            "- Tabs switch correctly.\n"
            "- History persists per mode.\n"
            "- Window size/selected tab persist.\n"
            "- Copy/paste works.\n"
            "- Security tab stays inspection-only.\n\n"
            "If the app closes unexpectedly, check the crash log.",
        )

    def show_security_scope(self) -> None:
        messagebox.showinfo(
            "Security Safety Scope",
            "Included:\n"
            "- Base64 / URL / Hex encode-decode\n"
            "- Hashes and lengths\n"
            "- Epoch conversion\n"
            "- JWT decode-only viewing\n\n"
            "Excluded:\n"
            "- exploit builders\n"
            "- payload generators\n"
            "- bypass tools\n"
            "- malware helpers\n"
            "- phishing helpers\n"
            "- credential cracking helpers",
        )

    def show_log_location(self) -> None:
        messagebox.showinfo("Sentinel Calculator Log", f"Crash/runtime log:\n{LOG_FILE}")

    def show_about(self) -> None:
        messagebox.showinfo(
            "About Sentinel Calculator",
            f"{APP_NAME} v{APP_VERSION}\n"
            f"Program {PROGRAM_ID} — SentinelOS Desktop Suite\n\n"
            "Stable lock release.\n\n"
            "Hotkeys:\n"
            "Ctrl+Q closes the application.\n"
            "Ctrl+W closes the application.",
        )

    def quit_app(self) -> None:
        logging.info("Quit requested")
        self._save_settings()
        self._save_history()
        self.destroy()


def launch_gui_smoke_test(debug: bool = False) -> int:
    """Construct and destroy the GUI once, without entering the main loop."""
    setup_logging(debug)
    try:
        ok, report = run_internal_self_test()
        if not ok:
            print(f"Sentinel Calculator v{APP_VERSION} self-test: {report}")
            return 1
        app = SentinelCalculator(safe_mode=True, debug=debug)
        app.update_idletasks()
        app.update()
        app.destroy()
        print(f"Sentinel Calculator v{APP_VERSION} GUI smoke test: PASS")
        return 0
    except Exception:
        logging.exception("GUI smoke test failed")
        print(f"Sentinel Calculator v{APP_VERSION} GUI smoke test: FAIL. See log: {LOG_FILE}", file=sys.stderr)
        return 1


def launch_gui(args: argparse.Namespace) -> int:
    setup_logging(args.debug)
    try:
        ok, report = run_internal_self_test()
        logging.info("Pre-GUI self-test: %s %s", ok, report)
        app = SentinelCalculator(safe_mode=args.safe_mode, debug=args.debug)
        app.mainloop()
        logging.info("GUI closed normally")
        return 0
    except Exception:
        logging.exception("Fatal GUI crash")
        # Try to show a visible error only if Tk can still work.
        try:
            root = tk.Tk()
            root.withdraw()
            messagebox.showerror(
                "Sentinel Calculator crashed",
                "Sentinel Calculator hit a startup/runtime error.\n\n"
                f"Crash log:\n{LOG_FILE}\n\n"
                "Try:\n"
                "sentinel-calculator --safe-mode\n"
                "sentinel-calculator --reset-settings",
            )
            root.destroy()
        except Exception:
            pass
        print(f"Sentinel Calculator crashed. See log: {LOG_FILE}", file=sys.stderr)
        return 1


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="sentinel-calculator",
        description="Sentinel Calculator — Program 103 in the SentinelOS Desktop Suite.",
    )
    parser.add_argument("--version", action="store_true", help="Print version and exit.")
    parser.add_argument("--self-test", action="store_true", help="Run non-GUI internal self-tests and exit.")
    parser.add_argument("--gui-smoke-test", action="store_true", help="Construct and destroy the GUI once, then exit. Requires a display or xvfb-run.")
    parser.add_argument("--print-paths", action="store_true", help="Print app data/config/log paths and exit.")
    parser.add_argument("--reset-settings", action="store_true", help="Back up settings/history and reset to defaults.")
    parser.add_argument("--safe-mode", action="store_true", help="Launch without saved settings/history and with safer defaults.")
    parser.add_argument("--debug", action="store_true", help="Enable verbose crash/runtime logging.")
    parser.add_argument("--show-log", action="store_true", help="Print the current crash/runtime log and exit.")
    args = parser.parse_args(argv)

    if args.version:
        print(f"{APP_NAME} v{APP_VERSION}")
        return 0

    if args.self_test:
        ok, report = run_internal_self_test()
        print(f"Sentinel Calculator v{APP_VERSION} self-test: {report}")
        return 0 if ok else 1

    if args.gui_smoke_test:
        return launch_gui_smoke_test(args.debug)

    if args.print_paths:
        print(f"APP_DATA_DIR={APP_DATA_DIR}")
        print(f"STATE_DIR={STATE_DIR}")
        print(f"HISTORY_FILE={HISTORY_FILE}")
        print(f"SETTINGS_FILE={SETTINGS_FILE}")
        print(f"LOG_FILE={LOG_FILE}")
        print(f"CURRENCY_CACHE_FILE={CURRENCY_CACHE_FILE}")
        print(f"ICON={resource_path('sentinel-calculator.png')}")
        return 0

    if args.reset_settings:
        reset_settings()
        print("Sentinel Calculator settings/history reset complete.")
        return 0

    if args.show_log:
        if LOG_FILE.exists():
            print(read_private_text(LOG_FILE, max_bytes=262_144))
        else:
            print(f"No log found yet: {LOG_FILE}")
        return 0

    return launch_gui(args)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
