# SentinelOS AEGIS Sentinel Suite Option

Registers AEGIS Sentinel Suite as a default-available/default-selected conversion and installation option.

Runtime and component installation remain disabled/user-initiated by default.
