#!/usr/bin/env python3
"""
Sentinel Media Index — Program 118
Local-only media catalogue for Sentinel Desktop Suite.

Local-first with automatic opt-out online metadata enrichment for player-useful media. No telemetry, no custom codecs. Indexes file metadata into SQLite
and optionally computes SHA256 hashes for duplicate/integrity workflows.
Metadata cleaning/editing is backend-driven, optional, backup-first where supported,
and requires explicit confirmation before writing to source media.
"""
from __future__ import annotations

import argparse
import csv
import datetime as _dt
import hashlib
import json
import mimetypes
import os
import re
import subprocess
import shutil
import sqlite3
import sys
import textwrap
import time
import threading
import urllib.parse
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

VERSION = "1.0.8"
APP_NAME = "Sentinel Media Index"
APP_ID = "sentinel-media-index"
PROGRAM_ID = "118"
DB_SCHEMA_VERSION = 17

HOME = Path.home()
DATA_ROOT = Path(os.environ.get("SENTINEL_MEDIA_INDEX_HOME", HOME / ".local" / "share" / APP_ID))
DB_PATH = Path(os.environ.get("SENTINEL_MEDIA_INDEX_DB", DATA_ROOT / "media_index.sqlite3"))
EXPORT_ROOT = DATA_ROOT / "exports"
BACKUP_ROOT = DATA_ROOT / "backups"
REPORT_ROOT = DATA_ROOT / "reports"
RENAME_ROOT = DATA_ROOT / "rename_reports"
THUMB_ROOT = DATA_ROOT / "thumbnails"
PLAYER_ROOT = DATA_ROOT / "player_handoffs"
COLLECTION_ROOT = DATA_ROOT / "collections"
ORG_ROOT = DATA_ROOT / "organisation_reports"
PLAYER_CONTRACT_ROOT = DATA_ROOT / "player_contracts"
METADATA_ROOT = DATA_ROOT / "metadata_reports"
CONTEXT_ROOT = DATA_ROOT / "context_actions"
METADATA_BATCH_ROOT = DATA_ROOT / "metadata_batch"
METADATA_BACKUP_REVIEW_ROOT = DATA_ROOT / "metadata_backup_reviews"
LIBRARY_ROOT = DATA_ROOT / "player_libraries"
VISUAL_BOARD_ROOT = DATA_ROOT / "visual_boards"
ONLINE_METADATA_ROOT = DATA_ROOT / "online_metadata"
ONLINE_ARTWORK_ROOT = DATA_ROOT / "online_artwork"
AUDIT_ROOT = DATA_ROOT / "audits"
RENAME_CONFIRM_WORD = "RENAME_MEDIA"
UNDO_RENAME_CONFIRM_WORD = "UNDO_RENAME"
PLAYER_FAST_CATALOGUE_PATH = DATA_ROOT / "player_catalogue.json"
PLAYER_FAST_CATALOGUE_ALT_PATH = LIBRARY_ROOT / "sentinel_media_player_catalogue.json"
PLAYER_FAST_CONTRACT_VERSION = "sentinel_media_player_fast_catalogue_v1"

APPROVED_DEFAULT_ROOTS = [
    HOME / "Documents" / "eBooks",
    HOME / "Videos" / "Movies",
    HOME / "Videos" / "TV Shows",
    HOME / "Pictures",
]
APPROVED_DEFAULT_ROOT_LABELS = [str(p) for p in APPROVED_DEFAULT_ROOTS]
NAMED_EXTERNAL_ROOTS = {"movies", "movie", "tv shows", "tv show", "tv", "television", "music"}
SCAN_LOCATIONS_PATH = DATA_ROOT / "scan_locations.json"

# v1.0.7 hard guard: never treat these broad locations as normal scan roots,
# even if a legacy scan_locations.json saved them before the policy was tightened.
BROAD_DISALLOWED_SCAN_ROOTS = [
    Path("/"),
    Path("/home"),
    HOME,
    HOME / "Documents",
    HOME / "Videos",
    HOME / "Music",
    HOME / "Desktop",
    HOME / "Downloads",
    Path("/mnt"),
    Path("/media"),
    Path("/run"),
    Path("/usr"),
    Path("/var"),
    Path("/etc"),
    Path("/opt"),
    Path("/tmp"),
]


def _safe_resolved(path: Path) -> Path:
    try:
        return path.expanduser().resolve(strict=False)
    except Exception:
        return Path(os.path.abspath(os.path.expanduser(str(path))))


def _unique_paths(paths: Iterable[Path]) -> List[Path]:
    seen = set()
    out: List[Path] = []
    for p in paths:
        try:
            rp = _safe_resolved(p)
        except Exception:
            continue
        key = str(rp)
        if key not in seen:
            seen.add(key)
            out.append(rp)
    return out


def is_broad_disallowed_scan_root(path: Path) -> bool:
    """Return True for scan roots that are too broad for normal indexing.

    This deliberately blocks legacy/user config entries like /home/stephen or
    /home/stephen/Documents from leaking into Scan Default Files.
    """
    p = _safe_resolved(path.expanduser())
    for root in BROAD_DISALLOWED_SCAN_ROOTS:
        if p == _safe_resolved(root):
            return True
    # If the selected path is a parent of one of the exact approved roots, it
    # is too broad. Example: ~/Documents contains ~/Documents/eBooks, and
    # ~/Videos contains Movies/TV Shows, but neither should be scanned whole.
    for approved in APPROVED_DEFAULT_ROOTS:
        ap = _safe_resolved(approved)
        if p != ap and p in ap.parents:
            return True
    return False


def split_manual_scan_locations(existing_only: bool = False) -> Tuple[List[Path], List[Path]]:
    try:
        data = json.loads(SCAN_LOCATIONS_PATH.read_text(encoding="utf-8")) if SCAN_LOCATIONS_PATH.exists() else {}
    except Exception:
        data = {}
    raw = data.get("locations", []) if isinstance(data, dict) else []
    candidates = _unique_paths(Path(str(x)).expanduser() for x in raw if str(x).strip())
    allowed: List[Path] = []
    rejected: List[Path] = []
    for candidate in candidates:
        if is_broad_disallowed_scan_root(candidate):
            rejected.append(candidate)
            continue
        if existing_only and not (candidate.exists() and candidate.is_dir()):
            continue
        allowed.append(candidate)
    return allowed, rejected


def load_manual_scan_locations(existing_only: bool = False) -> List[Path]:
    allowed, _rejected = split_manual_scan_locations(existing_only=existing_only)
    return allowed


def save_manual_scan_locations(paths: Sequence[Path]) -> Dict[str, Any]:
    roots = _unique_paths(paths)
    allowed = [p for p in roots if not is_broad_disallowed_scan_root(p)]
    rejected = [p for p in roots if is_broad_disallowed_scan_root(p)]
    if _path_has_symlink_component(DATA_ROOT):
        raise RuntimeError(f"unsafe_data_root_symlink:{DATA_ROOT}")
    DATA_ROOT.mkdir(parents=True, exist_ok=True)
    payload = {
        "app": APP_NAME,
        "version": VERSION,
        "policy": "manual_batch_scan_locations_exact_only_no_home",
        "updated_at": utc_now() if 'utc_now' in globals() else _dt.datetime.now(_dt.timezone.utc).isoformat(),
        "locations": [str(p) for p in allowed],
        "rejected_broad_locations": [str(p) for p in rejected],
    }
    _safe_write_text(SCAN_LOCATIONS_PATH, json.dumps(payload, indent=2), role="scan_locations")
    return payload


def add_manual_scan_location(path: Path) -> Dict[str, Any]:
    p = _safe_resolved(path.expanduser())
    if is_broad_disallowed_scan_root(p):
        return {
            "ok": False,
            "error": "broad_scan_root_blocked",
            "path": str(p),
            "policy": "Do not add /home, $HOME, ~/Documents, ~/Videos, ~/Music, Desktop, Downloads, or broad system/mount roots. Add exact media folders such as /media/drive/Movies instead.",
        }
    current = load_manual_scan_locations(existing_only=False)
    payload = save_manual_scan_locations(current + [p])
    payload.update({"ok": True, "added": str(p), "exists": p.exists() and p.is_dir()})
    return payload


def remove_manual_scan_location(path: Path) -> Dict[str, Any]:
    target = str(_safe_resolved(path.expanduser()))
    current = [p for p in load_manual_scan_locations(existing_only=False) if str(p) != target]
    payload = save_manual_scan_locations(current)
    payload.update({"ok": True, "removed": target})
    return payload


def discover_named_external_roots(existing_only: bool = False) -> List[Path]:
    # Safe bounded discovery only: do not crawl whole disks. Look for clearly
    # named media-library folders on mounted drives and direct mount roots.
    candidates: List[Path] = []
    user = os.environ.get("USER") or HOME.name
    bases = [Path("/media") / user, Path("/run/media") / user, Path("/mnt"), Path("/media")]
    for base in bases:
        if not base.exists() or not base.is_dir():
            continue
        stack: List[Tuple[Path, int]] = [(base, 0)]
        while stack:
            cur, depth = stack.pop(0)
            if depth > 3:
                continue
            try:
                children = [x for x in cur.iterdir() if x.is_dir() and not x.is_symlink()]
            except Exception:
                continue
            for child in children:
                name = child.name.strip().lower().replace("_", " ").replace("-", " ")
                if name in NAMED_EXTERNAL_ROOTS:
                    candidates.append(child)
                if depth < 3:
                    stack.append((child, depth + 1))
    roots = _unique_paths(candidates)
    if existing_only:
        roots = [p for p in roots if p.exists() and p.is_dir()]
    return roots


def approved_default_roots(existing_only: bool = False, include_external: bool = True, include_manual: bool = True) -> List[Path]:
    roots: List[Path] = [_safe_resolved(p) for p in APPROVED_DEFAULT_ROOTS]
    if include_external:
        roots.extend(discover_named_external_roots(existing_only=False))
    if include_manual:
        roots.extend(load_manual_scan_locations(existing_only=False))
    roots = _unique_paths(roots)
    if existing_only:
        roots = [p for p in roots if p.exists() and p.is_dir()]
    return roots


def scan_root_policy_report() -> Dict[str, Any]:
    home_roots = [_safe_resolved(p) for p in APPROVED_DEFAULT_ROOTS]
    external = discover_named_external_roots(existing_only=True)
    manual, rejected_manual = split_manual_scan_locations(existing_only=False)
    return {
        "ok": True,
        "app": APP_NAME,
        "version": VERSION,
        "policy": "exact_default_media_folders_plus_named_external_and_manual_batch_locations",
        "home_roots": [str(p) for p in home_roots],
        "existing_home_roots": [str(p) for p in home_roots if p.exists() and p.is_dir()],
        "named_external_roots": [str(p) for p in external],
        "named_external_names": sorted(NAMED_EXTERNAL_ROOTS),
        "manual_batch_locations": [str(p) for p in manual],
        "existing_manual_batch_locations": [str(p) for p in manual if p.exists() and p.is_dir()],
        "rejected_manual_batch_locations": [str(p) for p in rejected_manual],
        "effective_scan_roots": [str(p) for p in approved_default_roots(existing_only=True)],
        "manual_locations_config": str(SCAN_LOCATIONS_PATH),
        "excluded_by_default": "No broad /home or whole-home scan is performed. Everything outside the exact default media folders, clearly named external roots, or user-added batch locations is excluded from the normal Media Index.",
        "player_catalogue_effect": "Sentinel Media Player reflects the written fast catalogue exactly; use Retrieve Media Index after changing roots or manual batch locations.",
        "exact_default_folders": ["~/Documents/eBooks", "~/Videos/Movies", "~/Videos/TV Shows", "~/Pictures"],
        "no_home_scan": True,
    }


def is_under_or_equal(path: Path, root: Path) -> bool:
    try:
        path_res = _safe_resolved(path)
        root_res = _safe_resolved(root)
        return path_res == root_res or root_res in path_res.parents
    except Exception:
        text = str(path).lower()
        base = str(root).lower().rstrip('/')
        return text == base or text.startswith(base + '/')


def is_ancestor_of(path: Path, child: Path) -> bool:
    try:
        path_res = _safe_resolved(path)
        child_res = _safe_resolved(child)
        return path_res == child_res or path_res in child_res.parents
    except Exception:
        base = str(path).lower().rstrip('/')
        text = str(child).lower()
        return text == base or text.startswith(base + '/')


def is_in_default_media_roots(path: Path) -> bool:
    return any(is_under_or_equal(path, root) for root in approved_default_roots(existing_only=False))


def can_reach_default_media_root(path: Path) -> bool:
    # v1.0.7 strict policy: do not treat /home, $HOME, or broad parent folders
    # as scan contexts. A scan root must be the exact approved folder, a child
    # of an approved folder, a clearly named external media root, or a user-added
    # manual batch location. This prevents slow whole-home walking.
    return is_in_default_media_roots(path)


def default_root_policy_report() -> Dict[str, Any]:
    # Backwards-compatible alias for the expanded v1.0.5 root policy.
    return scan_root_policy_report()


def scan_default_roots(**kwargs: Any) -> Dict[str, Any]:
    db = kwargs.pop("db", None) or MediaIndexDB()
    db.init()
    roots = approved_default_roots(existing_only=True)
    results = []
    totals = {
        "files_seen": 0,
        "media_indexed": 0,
        "errors": 0,
        "skipped_disallowed_roots": 0,
        "skipped_non_media": 0,
        "skipped_system_assets": 0,
        "skipped_support_artwork": 0,
        "online_metadata_attempted": 0,
        "online_metadata_success": 0,
        "online_metadata_failed": 0,
    }
    for root in roots:
        result = scan_directory(root, db=db, **kwargs)
        results.append(result)
        for key in totals:
            totals[key] += int(result.get(key) or 0)
    fast_path = ""
    try:
        fast_path = str(db.export_player_fast_catalogue())
    except Exception:
        fast_path = ""
    policy = scan_root_policy_report()
    return {
        "ok": True,
        "app": APP_NAME,
        "version": VERSION,
        "policy": policy.get("policy"),
        "roots_scanned": [str(p) for p in roots],
        "roots_missing": [str(p) for p in approved_default_roots(existing_only=False) if not p.exists()],
        "root_policy": policy,
        "results": results,
        "totals": totals,
        "player_fast_catalogue_path": fast_path,
        "player_fast_catalogue_contract": PLAYER_FAST_CONTRACT_VERSION,
    }


IMAGE_EXTS = {
    ".jpg", ".jpeg", ".png", ".gif", ".bmp", ".tif", ".tiff", ".webp", ".heic", ".heif", ".avif"
}
VIDEO_EXTS = {
    ".mp4", ".m4v", ".mkv", ".mov", ".avi", ".webm", ".wmv", ".flv", ".mpeg", ".mpg", ".3gp", ".ogv"
}
AUDIO_EXTS = {
    ".mp3", ".flac", ".wav", ".ogg", ".oga", ".m4a", ".aac", ".opus", ".wma", ".aiff", ".alac"
}
EBOOK_EXTS = {
    ".pdf", ".epub", ".mobi", ".azw", ".azw3", ".djvu", ".fb2", ".cbz", ".cbr", ".lit"
}
PLAYLIST_EXTS = {".m3u", ".m3u8", ".pls", ".xspf"}
SIDECAR_EXTS = {".srt", ".vtt", ".ass", ".ssa", ".nfo", ".cue", ".json", ".xml"}
# Default catalogue policy: only index user-library content.
# Cover/poster/album-art image files and sidecar files may be read as support files,
# but they are not catalogued as standalone library items by default.
LIBRARY_MEDIA_EXTS = VIDEO_EXTS | AUDIO_EXTS | EBOOK_EXTS | IMAGE_EXTS
MEDIA_EXTS = LIBRARY_MEDIA_EXTS
SCAN_TYPE_CHOICES = ["all", "image", "video", "tvshow", "audio", "ebook"]
ONLINE_PROVIDER_CHOICES = ["auto", "openlibrary", "musicbrainz", "omdb"]
SYSTEM_ASSET_DIR_NAMES = {
    ".cache", ".git", "__pycache__", "node_modules", ".trash-1000", "thumbnails",
    "icons", "icon-theme", "pixmaps", "themes", "assets", "asset", "cursors"
}
SYSTEM_ASSET_PATH_HINTS = (
    "/usr/share/icons", "/usr/share/pixmaps", "/usr/share/themes",
    "/usr/local/share/icons", "/var/lib/flatpak", "/snap/",
    "/.local/share/icons", "/.icons", "/.themes", "/.cache/"
)

EDITABLE_METADATA_FIELDS = {
    "title": "Title",
    "artist": "Artist",
    "album": "Album",
    "genre": "Genre",
    "date": "DateTimeOriginal",
    "comment": "Comment",
    "rating": "Rating",
}
METADATA_CONFIRM_WORD = "MODIFY_METADATA"
METADATA_RESTORE_CONFIRM_WORD = "RESTORE_METADATA_BACKUP"
CAJA_SCRIPT_DIR = HOME / ".local" / "share" / "caja" / "scripts" / "Sentinel Media Index"
CONTEXT_ACTIONS = {
    "Read Metadata": "read",
    "Clean Metadata": "clean",
    "Edit Metadata": "edit",
}

THEME = {
    "bg": "#05090B",
    "panel": "#0D171F",
    "panel2": "#142230",
    "fg": "#D9E8EF",
    "muted": "#AFC4CE",
    "gold": "#E19B00",
    "cyan": "#03C8FF",
    "danger": "#B94A48",
    "ok": "#5FA777",
}


def utc_now() -> str:
    return _dt.datetime.now(_dt.timezone.utc).replace(microsecond=0).isoformat()


def ensure_dirs() -> None:
    for p in (DATA_ROOT, EXPORT_ROOT, BACKUP_ROOT, REPORT_ROOT, RENAME_ROOT, THUMB_ROOT, PLAYER_ROOT, COLLECTION_ROOT, ORG_ROOT, PLAYER_CONTRACT_ROOT, METADATA_ROOT, CONTEXT_ROOT, METADATA_BATCH_ROOT, METADATA_BACKUP_REVIEW_ROOT, LIBRARY_ROOT, VISUAL_BOARD_ROOT, ONLINE_METADATA_ROOT, ONLINE_ARTWORK_ROOT):
        p.mkdir(parents=True, exist_ok=True)


def is_system_asset_path(path: Path) -> bool:
    """Default skip rule for system icon/theme/asset folders.

    The index is for user media libraries, not OS icon themes, app assets, cache
    thumbnails, or packaged UI artwork. Users can override this with
    --include-assets when they intentionally want those files indexed.
    """
    try:
        text = str(path.expanduser().resolve(strict=False)).lower()
    except Exception:
        text = str(path).lower()
    parts = {part.lower() for part in Path(text).parts}
    if parts & SYSTEM_ASSET_DIR_NAMES:
        return True
    return any(hint in text for hint in SYSTEM_ASSET_PATH_HINTS)


def media_type_for(path: Path) -> str:
    ext = path.suffix.lower()
    if ext in IMAGE_EXTS:
        return "image"
    if ext in VIDEO_EXTS:
        return "video"
    if ext in AUDIO_EXTS:
        return "audio"
    if ext in EBOOK_EXTS:
        return "ebook"
    if ext in PLAYLIST_EXTS:
        return "playlist"
    if ext in SIDECAR_EXTS:
        return "sidecar"
    return "other"


def is_artwork_support_file(path: Path) -> bool:
    """True for local cover/poster art that should enrich nearby media instead of becoming a library item.

    This keeps poster.jpg/cover.jpg/folder.jpg style files out of the visible library
    when they sit beside real audio/video/eBook files, while still allowing normal
    photo folders to index user images.
    """
    if path.suffix.lower() not in IMAGE_EXTS:
        return False
    stem = path.stem.lower().strip()
    artwork_stems = {
        "cover", "folder", "poster", "front", "back", "album", "albumart",
        "book", "thumb", "thumbnail", "fanart", "banner", "clearart", "logo"
    }
    if stem not in artwork_stems:
        return False
    try:
        for sibling in path.parent.iterdir():
            if sibling == path or not sibling.is_file():
                continue
            if sibling.suffix.lower() in (VIDEO_EXTS | AUDIO_EXTS | EBOOK_EXTS):
                return True
    except Exception:
        return False
    return False


def is_media_file(path: Path) -> bool:
    """True only for supported user library items.

    User photos/images are now indexed again, while system assets and cover/poster
    support files are excluded by default. Sidecar files are read by
    discover_artwork()/discover_sidecar_metadata() to enrich audio/video/eBook
    library entries.
    """
    return path.is_file() and path.suffix.lower() in MEDIA_EXTS


def is_player_catalogue_type(media_type: str) -> bool:
    return media_type in {"audio", "video", "ebook", "image"}


def is_incomplete_download_path(path: Path) -> bool:
    text = str(path).lower()
    return any(token in text for token in (".crdownload", ".part", ".partial", ".aria2", ".tmp", ".!qb", "unconfirmed", "incomplete"))

def player_category_for_item(media_type: str, lib: Dict[str, Any], path: Path) -> str:
    section = str(lib.get("library_section") or library_section_for_media(media_type, lib))
    if media_type == "audio":
        return "Music"
    if media_type == "ebook":
        return "eBooks"
    if media_type == "image":
        return "Pictures"
    if media_type == "video":
        if "tv" in section.lower() or lib.get("series") or lib.get("season") or lib.get("episode"):
            return "TV Shows"
        # Keep broad legacy Movie/Video section readable for Program 119.
        return "Movies"
    return "Unsorted"

def primary_artwork_from_lib(row: Dict[str, Any], lib: Dict[str, Any]) -> str:
    for key in ("poster_path", "cover_path", "album_art_path", "artwork_path", "thumbnail_path", "fanart_path"):
        val = lib.get(key) or row.get(key)
        if val:
            return str(val)
    return ""


def is_tv_show_item(row_or_meta: Dict[str, Any]) -> bool:
    try:
        if row_or_meta.get("library_section") == "TV Shows / Series":
            return True
        meta = row_or_meta.get("metadata_json")
        if meta:
            raw = json.loads(meta)
            lib = raw.get("library_metadata") or {}
            return bool(lib.get("series") or lib.get("season") or lib.get("episode") or lib.get("library_section") == "TV Shows / Series")
    except Exception:
        return False
    return bool(row_or_meta.get("series") or row_or_meta.get("season") or row_or_meta.get("episode"))



RELEASE_TAG_RE = re.compile(r"\b(480p|576p|720p|1080p|2160p|4k|8k|bluray|blu[- ]?ray|brrip|dvdrip|hdrip|webrip|web[- ]?dl|hdtv|x264|x265|h264|h265|hevc|aac|ac3|dts|yify|rarbg|proper|repack|extended|unrated|remastered|limited|multi|subs?|dubbed)\b", re.IGNORECASE)
YEAR_RE = re.compile(r"(?:^|[^0-9])((?:19|20)[0-9]{2})(?:[^0-9]|$)")
TV_EP_RE = re.compile(r"(?i)\bS(\d{1,2})E(\d{1,2})\b")


def clean_filename_title(path: Path) -> Dict[str, Any]:
    """Parse a messy media filename into a stable title/year proposal."""
    stem = path.stem
    original_stem = stem
    tv = TV_EP_RE.search(stem)
    season = episode = ""
    if tv:
        season, episode = tv.group(1).zfill(2), tv.group(2).zfill(2)
    # Convert separators while preserving apostrophes/ampersands.
    s = re.sub(r"[._]+", " ", stem)
    s = re.sub(r"[\[\]{}]", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    # Prefer first year-like token as movie release year.
    year = ""
    m = YEAR_RE.search(" " + s + " ")
    if m:
        year = m.group(1)
        title_part = s[:max(0, m.start(1)-1)].strip()
    else:
        title_part = s
    # Remove TV episode marker and common release tags.
    title_part = TV_EP_RE.sub(" ", title_part)
    title_part = RELEASE_TAG_RE.sub(" ", title_part)
    title_part = re.sub(r"\b(cd|disc|disk)\s*\d+\b", " ", title_part, flags=re.I)
    title_part = re.sub(r"[-–—]+", " ", title_part)
    title_part = re.sub(r"\s+", " ", title_part).strip(" .-_()")
    if not title_part:
        title_part = re.sub(RELEASE_TAG_RE, " ", s).strip() or original_stem
    def titlecase_token(tok: str) -> str:
        if tok.isupper() and len(tok) <= 4:
            return tok
        # Keep common apostrophe casing readable.
        return tok[:1].upper() + tok[1:].lower() if tok else tok
    title = " ".join(titlecase_token(t) for t in title_part.split())
    return {"original_stem": original_stem, "title": title, "year": year, "season": season, "episode": episode, "is_tv_episode": bool(tv)}


def safe_library_filename(name: str) -> str:
    name = re.sub(r"[\\/:*?\"<>|]", " - ", name)
    name = re.sub(r"\s+", " ", name).strip(" .")
    return name or "Untitled"


def movie_rename_target_for_row(row: Dict[str, Any]) -> Dict[str, Any]:
    p = Path(str(row.get("path") or ""))
    try:
        meta = json.loads(row.get("metadata_json") or "{}")
    except Exception:
        meta = {}
    lib = dict(meta.get("library_metadata") or {})
    parsed = clean_filename_title(p)
    title = str(lib.get("title") or parsed.get("title") or p.stem).strip()
    year = str(lib.get("year") or parsed.get("year") or "").strip()
    tmdb_id = str(lib.get("tmdb_id") or lib.get("tmdb") or "").strip()
    # TV episodes are not renamed by the movie rule.
    if parsed.get("is_tv_episode") or lib.get("series") or lib.get("season") or lib.get("episode"):
        return {"eligible": False, "reason": "tv_episode_or_series", "path": str(p)}
    base = f"{safe_library_filename(title)} ({year})" if year else safe_library_filename(title)
    target = p.with_name(base + p.suffix.lower())
    clean = p.name == target.name
    confidence = "high" if year or tmdb_id else "medium"
    return {
        "eligible": True,
        "path": str(p),
        "parent": str(p.parent),
        "current_filename": p.name,
        "proposed_filename": target.name,
        "proposed_path": str(target),
        "title": title,
        "year": year,
        "tmdb_id": tmdb_id,
        "confidence": confidence,
        "rename_status": "clean" if clean else "proposed",
        "would_change": not clean,
        "reason": "already_clean" if clean else "movie_filename_normalisation",
    }


def unique_rename_target(path_text: str) -> str:
    target = Path(path_text)
    if not target.exists():
        return str(target)
    stem = target.stem
    suffix = target.suffix
    parent = target.parent
    for i in range(2, 1000):
        candidate = parent / f"{stem} - {i}{suffix}"
        if not candidate.exists():
            return str(candidate)
    raise RuntimeError(f"unable to find non-conflicting target for {target}")


def propose_movie_renames(db: 'MediaIndexDB', output: Optional[Path] = None, include_clean: bool = False) -> Dict[str, Any]:
    rows = db.search(query="", media_type="video", limit=1000000)
    proposals = []
    skipped = []
    for row in rows:
        p = Path(str(row.get("path") or ""))
        if not p.exists() or is_incomplete_download_path(p) or is_system_asset_path(p):
            skipped.append({"path": str(p), "reason": "missing_or_excluded"})
            continue
        prop = movie_rename_target_for_row(row)
        if not prop.get("eligible"):
            skipped.append(prop)
            continue
        if prop.get("would_change") or include_clean:
            proposals.append(prop)
    payload = {
        "ok": True,
        "program": APP_NAME,
        "version": VERSION,
        "operation": "propose_movie_renames",
        "safe_mode": "dry_run_only",
        "confirm_word_for_apply": RENAME_CONFIRM_WORD,
        "generated_at": utc_now(),
        "count": len(proposals),
        "change_count": sum(1 for p in proposals if p.get("would_change")),
        "skipped_count": len(skipped),
        "proposals": proposals,
        "skipped": skipped[:200],
    }
    if output:
        output = _ensure_safe_output_path(output.expanduser(), role="rename_proposal")
        _safe_write_text(output, json.dumps(payload, indent=2, sort_keys=True), role="rename_proposal")
        payload["output"] = str(output)
    return payload


def update_db_path_after_rename(db: 'MediaIndexDB', old_path: str, new_path: str, title: str = "", year: str = "") -> None:
    p = Path(new_path)
    with db.connect() as conn:
        row = conn.execute("SELECT * FROM media_items WHERE path=?", (old_path,)).fetchone()
        meta = {}
        if row:
            try:
                meta = json.loads(row["metadata_json"] or "{}")
            except Exception:
                meta = {}
        lib = dict(meta.get("library_metadata") or {})
        if title:
            lib["title"] = title
            lib["sort_title"] = title.lower().removeprefix("the ").strip()
        if year:
            lib["year"] = year
        lib["rename_status"] = "clean"
        lib["renamed_by"] = APP_ID
        lib["renamed_at"] = utc_now()
        meta["library_metadata"] = lib
        conn.execute(
            "UPDATE media_items SET path=?, parent=?, filename=?, extension=?, metadata_json=?, last_seen_at=?, missing=0 WHERE path=?",
            (str(p), str(p.parent), p.name, p.suffix.lower(), json.dumps(meta, sort_keys=True), utc_now(), old_path),
        )


def apply_movie_renames(db: 'MediaIndexDB', plan_path: Path, execute: bool, confirm: str) -> Dict[str, Any]:
    if not execute or confirm != RENAME_CONFIRM_WORD:
        return {"ok": False, "error": "guard_required", "execute_required": True, "confirm_required": RENAME_CONFIRM_WORD, "plan": str(plan_path)}
    plan_path = Path(plan_path).expanduser()
    if _path_has_symlink_component(plan_path):
        return {"ok": False, "error": "rename_plan_symlink_blocked", "plan": safe_realpath(plan_path)}
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    actions = []
    errors = []
    for prop in plan.get("proposals", []):
        if not prop.get("would_change"):
            continue
        old = Path(prop.get("path") or "").expanduser()
        proposed = unique_rename_target(str(prop.get("proposed_path") or ""))
        new = Path(proposed).expanduser()
        try:
            ok_old, err_old, old_checked = _safe_regular_media_file(old, require_approved_root=True)
            if not ok_old:
                errors.append({"path": str(old), "error": err_old})
                continue
            if _path_has_symlink_component(new) or not is_in_default_media_roots(new) or new.parent != old_checked.parent:
                errors.append({"path": str(old), "target": str(new), "error": "unsafe_rename_target_blocked"})
                continue
            if new.exists() or new.is_symlink():
                errors.append({"path": str(old), "target": str(new), "error": "target_exists"})
                continue
            new.parent.mkdir(parents=True, exist_ok=True)
            old_checked.rename(new)
            update_db_path_after_rename(db, str(old_checked), str(new), str(prop.get("title") or ""), str(prop.get("year") or ""))
            actions.append({"from": str(old_checked), "to": str(new), "title": prop.get("title"), "year": prop.get("year"), "status": "renamed"})
        except Exception as exc:
            errors.append({"path": str(old), "target": str(new), "error": type(exc).__name__, "detail": str(exc)[:500]})
    manifest = {
        "ok": not errors,
        "program": APP_NAME,
        "version": VERSION,
        "operation": "apply_movie_renames",
        "generated_at": utc_now(),
        "source_plan": str(plan_path),
        "actions": actions,
        "errors": errors,
        "undo_confirm_word": UNDO_RENAME_CONFIRM_WORD,
    }
    if _path_has_symlink_component(RENAME_ROOT):
        raise RuntimeError(f"unsafe_rename_root_symlink:{RENAME_ROOT}")
    RENAME_ROOT.mkdir(parents=True, exist_ok=True)
    out = _ensure_safe_output_path(RENAME_ROOT / ("rename_manifest_" + _dt.datetime.now().strftime("%Y%m%d_%H%M%S") + ".json"), role="rename_manifest")
    _safe_write_text(out, json.dumps(manifest, indent=2, sort_keys=True), role="rename_manifest")
    try:
        db.export_player_fast_catalogue()
    except Exception:
        pass
    manifest["manifest"] = str(out)
    return manifest


def latest_rename_manifest() -> Optional[Path]:
    try:
        files = sorted(RENAME_ROOT.glob("rename_manifest_*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
        return files[0] if files else None
    except Exception:
        return None


def undo_last_rename(db: 'MediaIndexDB', execute: bool, confirm: str) -> Dict[str, Any]:
    manifest_path = latest_rename_manifest()
    if not manifest_path:
        return {"ok": False, "error": "no_rename_manifest", "root": str(RENAME_ROOT)}
    if not execute or confirm != UNDO_RENAME_CONFIRM_WORD:
        return {"ok": False, "error": "guard_required", "execute_required": True, "confirm_required": UNDO_RENAME_CONFIRM_WORD, "manifest": str(manifest_path)}
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    undone = []
    errors = []
    for action in reversed(manifest.get("actions", [])):
        src = Path(action.get("to") or "").expanduser()
        dst = Path(action.get("from") or "").expanduser()
        try:
            ok_src, err_src, src_checked = _safe_regular_media_file(src, require_approved_root=True)
            if not ok_src:
                errors.append({"path": str(src), "error": f"renamed_file_{err_src}"})
                continue
            if _path_has_symlink_component(dst) or not is_in_default_media_roots(dst) or dst.parent != src_checked.parent:
                errors.append({"path": str(src), "target": str(dst), "error": "unsafe_undo_target_blocked"})
                continue
            if dst.exists() or dst.is_symlink():
                errors.append({"path": str(dst), "error": "original_path_occupied"})
                continue
            src_checked.rename(dst)
            update_db_path_after_rename(db, str(src_checked), str(dst), str(action.get("title") or ""), str(action.get("year") or ""))
            undone.append({"from": str(src_checked), "to": str(dst), "status": "undone"})
        except Exception as exc:
            errors.append({"path": str(src), "target": str(dst), "error": type(exc).__name__, "detail": str(exc)[:500]})
    try:
        db.export_player_fast_catalogue()
    except Exception:
        pass
    return {"ok": not errors, "operation": "undo_last_rename", "manifest": str(manifest_path), "undone": undone, "errors": errors}


def rename_status_payload(db: 'MediaIndexDB') -> Dict[str, Any]:
    plan = propose_movie_renames(db, include_clean=False)
    latest = latest_rename_manifest()
    return {
        "ok": True,
        "program": APP_NAME,
        "version": VERSION,
        "rename_engine": "movie_filename_parser_v1_dry_run_default",
        "format": "Movie Title (Year).ext",
        "optional_future_format": "Movie Title (Year) [tmdb-ID].ext",
        "pending_change_count": plan.get("change_count", 0),
        "proposal_count": plan.get("count", 0),
        "latest_manifest": str(latest) if latest else "",
        "safe_defaults": ["dry-run by default", "no overwrite", "preserve extension", "skip TV episodes", "skip missing/incomplete/system files", "writes undo manifest"],
        "commands": {
            "propose": "sentinel-media-index --propose-renames OUTPUT --json",
            "apply": f"sentinel-media-index --apply-renames PLAN --execute --confirm {RENAME_CONFIRM_WORD} --json",
            "undo": f"sentinel-media-index --undo-last-rename --execute --confirm {UNDO_RENAME_CONFIRM_WORD} --json",
        },
    }

def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            block = f.read(chunk_size)
            if not block:
                break
            h.update(block)
    return h.hexdigest()


def safe_realpath(path: Path) -> str:
    try:
        return str(path.expanduser().resolve(strict=False))
    except Exception:
        return str(path.expanduser())


def _path_has_symlink_component(path: Path) -> bool:
    """Return True if an existing component in path is a symlink.

    This is intentionally conservative for write-capable/report/export paths and
    source-media mutation paths. Nonexistent trailing components are allowed, but
    existing symlink ancestors are not followed.
    """
    p = Path(path).expanduser()
    try:
        if p.is_symlink():
            return True
    except Exception:
        return True
    cur = Path(p.anchor) if p.is_absolute() else Path.cwd()
    parts = p.parts[1:] if p.is_absolute() else p.parts
    for part in parts:
        cur = cur / part
        try:
            if cur.exists() and cur.is_symlink():
                return True
        except Exception:
            return True
    return False


def _ensure_safe_output_path(path: Path, *, role: str = "output") -> Path:
    out = Path(path).expanduser()
    if out.exists() and out.is_symlink():
        raise RuntimeError(f"unsafe_{role}_symlink_target:{out}")
    if _path_has_symlink_component(out.parent):
        raise RuntimeError(f"unsafe_{role}_symlink_parent:{out.parent}")
    out.parent.mkdir(parents=True, exist_ok=True)
    return out


def _safe_write_text(path: Path, text: str, *, role: str = "output", encoding: str = "utf-8") -> None:
    out = _ensure_safe_output_path(path, role=role)
    tmp = out.with_name(out.name + f".tmp-{os.getpid()}")
    if tmp.exists() or tmp.is_symlink():
        tmp.unlink(missing_ok=True)
    fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(fd, "w", encoding=encoding) as fh:
            fh.write(text)
        os.replace(tmp, out)
    finally:
        try:
            if tmp.exists() or tmp.is_symlink():
                tmp.unlink()
        except Exception:
            pass


def _safe_write_json(path: Path, payload: Any, *, role: str = "json_output") -> None:
    _safe_write_text(path, json.dumps(payload, indent=2, sort_keys=True), role=role)


def _safe_regular_media_file(path: Path, *, require_approved_root: bool = True) -> Tuple[bool, str, Path]:
    p = Path(path).expanduser()
    if _path_has_symlink_component(p):
        return False, "symlink_media_path_blocked", p
    if not p.exists() or not p.is_file():
        return False, "file_not_found", p
    if require_approved_root and not is_in_default_media_roots(p):
        return False, "media_path_outside_approved_roots", p
    if not is_media_file(p):
        return False, "not_supported_media_file", p
    return True, "ok", p


def tool_available(name: str) -> bool:
    return shutil.which(name) is not None


def pil_available() -> bool:
    try:
        import PIL.Image  # type: ignore  # noqa: F401
        import PIL.ImageDraw  # type: ignore  # noqa: F401
        return True
    except Exception:
        return False


def probe_image_with_pillow(path: Path) -> Dict[str, Any]:
    try:
        from PIL import Image  # type: ignore
        with Image.open(path) as img:
            return {
                "width": int(img.width),
                "height": int(img.height),
                "container": (img.format or path.suffix.lstrip('.')).lower(),
                "codec": (img.format or "image").lower(),
                "metadata_status": "pillow_ok",
            }
    except Exception as exc:
        return {"metadata_status": f"pillow_unavailable_or_failed:{type(exc).__name__}"}


def ffprobe_metadata(path: Path) -> Dict[str, Any]:
    if not tool_available("ffprobe"):
        return {"metadata_status": "ffprobe_unavailable"}
    try:
        proc = subprocess.run(
            ["ffprobe", "-v", "error", "-print_format", "json", "-show_format", "-show_streams", str(path)],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=20,
            check=False,
        )
        if proc.returncode != 0:
            return {"metadata_status": "ffprobe_failed", "ffprobe_error": proc.stderr.strip()[:500]}
        raw = json.loads(proc.stdout or "{}")
        fmt = raw.get("format") or {}
        streams = raw.get("streams") or []
        chosen = streams[0] if streams else {}
        video_stream = next((x for x in streams if x.get("codec_type") == "video"), None)
        audio_stream = next((x for x in streams if x.get("codec_type") == "audio"), None)
        main = video_stream or audio_stream or chosen
        duration = None
        for val in (fmt.get("duration"), main.get("duration")):
            try:
                if val is not None:
                    duration = float(val)
                    break
            except Exception:
                pass
        result: Dict[str, Any] = {
            "duration_seconds": duration,
            "codec": main.get("codec_name") or "",
            "container": fmt.get("format_name") or path.suffix.lstrip('.').lower(),
            "metadata_status": "ffprobe_ok",
            "ffprobe_format": fmt.get("format_name") or "",
            "bit_rate": fmt.get("bit_rate") or main.get("bit_rate") or "",
        }
        if video_stream:
            result["width"] = int(video_stream.get("width") or 0) or None
            result["height"] = int(video_stream.get("height") or 0) or None
        return result
    except subprocess.TimeoutExpired:
        return {"metadata_status": "ffprobe_timeout"}
    except Exception as exc:
        return {"metadata_status": f"ffprobe_error:{type(exc).__name__}"}


def _clean_metadata_value(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, (list, tuple)):
        return ", ".join(_clean_metadata_value(v) for v in value if _clean_metadata_value(v)).strip()
    text = str(value).replace("\x00", " ").strip()
    return " ".join(text.split())


def _split_people(value: Any) -> List[str]:
    if value is None:
        return []
    if isinstance(value, list):
        raw = value
    else:
        raw = str(value).replace(";", ",").replace("/", ",").split(",")
    seen: set[str] = set()
    out: List[str] = []
    for item in raw:
        name = _clean_metadata_value(item)
        if name and name.lower() not in seen:
            seen.add(name.lower())
            out.append(name)
    return out[:20]


def _safe_read_text(path: Path, limit: int = 50000) -> str:
    try:
        data = path.read_bytes()[:limit]
    except Exception:
        return ""
    for enc in ("utf-8", "utf-8-sig", "latin-1"):
        try:
            return data.decode(enc, errors="replace")
        except Exception:
            pass
    return data.decode("utf-8", errors="replace")


def _metadata_candidates_from_mapping(raw: Dict[str, Any]) -> Dict[str, Any]:
    # Handles sidecar JSON and ExifTool-like dictionaries without requiring one exact schema.
    key_map = {str(k).lower().replace(" ", "").replace("_", "").replace("-", ""): v for k, v in raw.items()}
    def first(*names: str) -> str:
        for n in names:
            key = n.lower().replace(" ", "").replace("_", "").replace("-", "")
            if key in key_map:
                val = _clean_metadata_value(key_map[key])
                if val:
                    return val
        return ""
    cast_val = raw.get("cast") or raw.get("actors") or raw.get("actor") or raw.get("performers") or raw.get("Artist")
    return {
        "title": first("title", "name", "movie", "album", "booktitle"),
        "sort_title": first("sorttitle", "sort_title"),
        "year": first("year", "date", "releasedate", "release_date", "originalyear"),
        "synopsis": first("synopsis", "plot", "outline", "summary", "description", "comment", "overview"),
        "genre": first("genre", "category"),
        "director": first("director"),
        "cast": _split_people(cast_val),
        "artist": first("artist", "albumartist", "album_artist", "composer"),
        "album": first("album"),
        "track": first("track", "tracknumber", "track_number"),
        "author": first("author", "creator", "writer"),
        "series": first("series", "seriesname", "show", "showtitle"),
        "season": first("season", "seasonnumber"),
        "episode": first("episode", "episodenumber"),
        "rating": first("rating", "userrating"),
    }


def _parse_nfo_xml(path: Path) -> Dict[str, Any]:
    text = _safe_read_text(path)
    if not text.strip():
        return {}
    try:
        import xml.etree.ElementTree as ET
        root = ET.fromstring(text)
    except Exception:
        # Plain-text fallback: useful for simple .txt/.nfo blurbs.
        title = ""
        synopsis = text.strip()[:5000]
        return {"title": title, "synopsis": synopsis}
    def find_text(*names: str) -> str:
        for name in names:
            el = root.find(f".//{name}")
            if el is not None and el.text:
                val = _clean_metadata_value(el.text)
                if val:
                    return val
        return ""
    cast: List[str] = []
    for actor in root.findall(".//actor"):
        name_el = actor.find("name")
        if name_el is not None and name_el.text:
            cast.append(_clean_metadata_value(name_el.text))
    genre_values = [g.text for g in root.findall(".//genre") if g is not None and g.text]
    return {
        "title": find_text("title", "originaltitle", "showtitle"),
        "sort_title": find_text("sorttitle"),
        "year": find_text("year", "premiered", "releasedate"),
        "synopsis": find_text("plot", "outline", "tagline", "summary", "description"),
        "genre": ", ".join(_clean_metadata_value(g) for g in genre_values if _clean_metadata_value(g)) or find_text("genre"),
        "director": find_text("director"),
        "cast": _split_people(cast),
        "artist": find_text("artist", "albumartist"),
        "album": find_text("album"),
        "author": find_text("author", "writer"),
        "series": find_text("series", "showtitle"),
        "season": find_text("season"),
        "episode": find_text("episode"),
        "rating": find_text("rating", "userrating"),
    }


def discover_sidecar_metadata(path: Path) -> Dict[str, Any]:
    """Load local sidecar metadata without network access.

    Supports common local library files: basename.nfo/json/xml/txt and directory-level
    movie.nfo/tvshow.nfo/album.json/book.json. Empty fields are ignored by callers.
    """
    p = path.expanduser()
    candidates = [p.with_suffix(ext) for ext in (".json", ".nfo", ".xml", ".txt")]
    candidates += [p.parent / name for name in ("movie.nfo", "tvshow.nfo", "album.nfo", "book.nfo", "metadata.json", "album.json", "book.json")]
    sources: List[str] = []
    merged: Dict[str, Any] = {}
    for c in candidates:
        if not c.exists() or not c.is_file():
            continue
        parsed: Dict[str, Any] = {}
        if c.suffix.lower() == ".json":
            try:
                raw = json.loads(_safe_read_text(c))
                if isinstance(raw, dict):
                    parsed = _metadata_candidates_from_mapping(raw)
            except Exception:
                parsed = {}
        elif c.suffix.lower() in {".nfo", ".xml", ".txt"}:
            parsed = _parse_nfo_xml(c)
        if parsed:
            sources.append(str(c))
            for k, v in parsed.items():
                if k == "cast":
                    if v and not merged.get("cast"):
                        merged[k] = v
                elif v and not merged.get(k):
                    merged[k] = v
    merged["sidecar_paths"] = sources
    return merged


def discover_artwork(path: Path) -> Dict[str, Any]:
    p = path.expanduser()
    image_exts = [".jpg", ".jpeg", ".png", ".webp"]
    stems = [p.stem, "poster", "cover", "folder", "front", "album", "albumart", "book", "thumb", "thumbnail"]
    candidates: List[Path] = []
    for stem in stems:
        for ext in image_exts:
            candidates.append(p.parent / f"{stem}{ext}")
            candidates.append(p.parent / f"{p.stem}-{stem}{ext}")
            candidates.append(p.parent / f"{p.stem}.{stem}{ext}")
    seen: set[str] = set()
    for c in candidates:
        key = str(c)
        if key in seen:
            continue
        seen.add(key)
        if c.exists() and c.is_file() and c.suffix.lower() in IMAGE_EXTS:
            name = c.stem.lower()
            role = "poster" if "poster" in name or media_type_for(p) == "video" else "cover"
            return {
                "cover_path": str(c),
                "poster_path": str(c) if role == "poster" else "",
                "artwork_source": "local_artwork_file",
                "artwork_role": role,
            }
    return {"cover_path": "", "poster_path": "", "artwork_source": "", "artwork_role": ""}


def derive_library_metadata(path: Path, media_type: str, base_metadata: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    sidecar = discover_sidecar_metadata(path)
    artwork = discover_artwork(path)
    base = base_metadata or {}
    external: Dict[str, Any] = {}
    # If ExifTool has been read elsewhere and stored under metadata_json, this function still
    # remains local/offline and safely falls back to filenames and sidecars.
    filename_title = path.stem.replace(".", " ").replace("_", " ").replace("-", " ").strip()
    title = sidecar.get("title") or _clean_metadata_value(base.get("title") or base.get("Title")) or filename_title
    synopsis = sidecar.get("synopsis") or _clean_metadata_value(base.get("synopsis") or base.get("description") or base.get("Comment"))
    genre = sidecar.get("genre") or _clean_metadata_value(base.get("genre") or base.get("Genre"))
    year = sidecar.get("year") or _clean_metadata_value(base.get("year") or base.get("date") or base.get("DateTimeOriginal"))
    cast = sidecar.get("cast") or _split_people(base.get("cast") or base.get("Artist"))
    artist = sidecar.get("artist") or _clean_metadata_value(base.get("artist") or base.get("Artist"))
    album = sidecar.get("album") or _clean_metadata_value(base.get("album") or base.get("Album"))
    author = sidecar.get("author") or _clean_metadata_value(base.get("author") or base.get("Creator"))
    section = library_section_for_media(media_type, sidecar)
    return {
        "title": title,
        "sort_title": sidecar.get("sort_title") or title.lower().removeprefix("the ").strip(),
        "year": year[:4] if year else "",
        "synopsis": synopsis,
        "genre": genre,
        "director": sidecar.get("director") or _clean_metadata_value(base.get("director") or base.get("Director")),
        "cast": cast,
        "artist": artist,
        "album": album,
        "track": sidecar.get("track") or _clean_metadata_value(base.get("track") or base.get("Track")),
        "author": author,
        "series": sidecar.get("series") or _clean_metadata_value(base.get("series") or base.get("Series")),
        "season": sidecar.get("season") or "",
        "episode": sidecar.get("episode") or "",
        "rating": sidecar.get("rating") or _clean_metadata_value(base.get("rating") or base.get("Rating")),
        "cover_path": artwork.get("cover_path") or "",
        "poster_path": artwork.get("poster_path") or artwork.get("cover_path") or "",
        "artwork_source": artwork.get("artwork_source") or "",
        "artwork_role": artwork.get("artwork_role") or "",
        "sidecar_paths": sidecar.get("sidecar_paths") or [],
        "library_section": section,
        "display_blurb": synopsis or f"Local {media_type} item indexed by Sentinel Media Index.",
    }


def library_section_for_media(media_type: str, data: Optional[Dict[str, Any]] = None) -> str:
    data = data or {}
    if media_type == "video":
        if data.get("season") or data.get("episode") or data.get("series"):
            return "TV Shows / Series"
        return "Movies / Videos"
    if media_type == "audio":
        return "Music / Albums"
    if media_type == "ebook":
        return "eBooks"
    if media_type == "image":
        return "Images / Photos"
    return "Other Media"


def _http_json(url: str, timeout: int = 6, headers: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
    req_headers = {
        "User-Agent": f"SentinelMediaIndex/{VERSION} (local-first optional metadata enrichment)",
        "Accept": "application/json",
    }
    if headers:
        req_headers.update(headers)
    req = urllib.request.Request(url, headers=req_headers)
    with urllib.request.urlopen(req, timeout=timeout) as resp:  # nosec: user-triggered metadata lookup only
        charset = resp.headers.get_content_charset() or "utf-8"
        text = resp.read(1024 * 1024).decode(charset, errors="replace")
        return json.loads(text or "{}")


def _download_online_artwork(url: str, media_type: str, title: str, provider: str, timeout: int = 8) -> str:
    if not url or url == "N/A":
        return ""
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme not in {"http", "https"}:
        return ""
    ext = Path(parsed.path).suffix.lower()
    if ext not in {".jpg", ".jpeg", ".png", ".webp"}:
        ext = ".jpg"
    digest = hashlib.sha1(f"{provider}|{media_type}|{title}|{url}".encode("utf-8", "replace")).hexdigest()
    out = ONLINE_ARTWORK_ROOT / provider / media_type / f"{digest}{ext}"
    if out.exists() and not out.is_symlink() and out.stat().st_size > 0:
        return str(out)
    if out.is_symlink():
        return ""
    out = _ensure_safe_output_path(out, role="online_artwork")
    req = urllib.request.Request(url, headers={"User-Agent": f"SentinelMediaIndex/{VERSION}"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:  # nosec: user-triggered artwork cache only
        data = resp.read(4 * 1024 * 1024)
    if data:
        if out.exists() and out.is_symlink():
            return ""
        _ensure_safe_output_path(out, role="online_artwork")
        tmp = out.with_name(out.name + f".tmp-{os.getpid()}")
        if tmp.exists() or tmp.is_symlink():
            tmp.unlink(missing_ok=True)
        fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        try:
            with os.fdopen(fd, "wb") as fh:
                fh.write(data)
            os.replace(tmp, out)
        finally:
            try:
                if tmp.exists() or tmp.is_symlink():
                    tmp.unlink()
            except Exception:
                pass
        return str(out)
    return ""


def _title_query_from_row(row: Dict[str, Any]) -> Dict[str, str]:
    try:
        meta = json.loads(row.get("metadata_json") or "{}")
    except Exception:
        meta = {}
    lib = meta.get("library_metadata") or {}
    title = _clean_metadata_value(lib.get("title") or row.get("filename") or "")
    if not title and row.get("path"):
        title = Path(str(row.get("path"))).stem.replace(".", " ").replace("_", " ").replace("-", " ")
    if title.lower().endswith(str(row.get("extension") or "").lower()):
        title = title[: -len(str(row.get("extension") or ""))].strip()
    return {
        "title": title,
        "artist": _clean_metadata_value(lib.get("artist") or ""),
        "album": _clean_metadata_value(lib.get("album") or ""),
        "author": _clean_metadata_value(lib.get("author") or ""),
        "year": _clean_metadata_value(lib.get("year") or ""),
    }


def online_metadata_plan_for_row(row: Dict[str, Any], provider: str = "auto") -> Dict[str, Any]:
    mtype = str(row.get("media_type") or "other")
    q = _title_query_from_row(row)
    chosen = provider
    if provider == "auto":
        chosen = "openlibrary" if mtype == "ebook" else "musicbrainz" if mtype == "audio" else "omdb" if mtype == "video" else "unsupported"
    return {
        "program": APP_NAME,
        "program_id": PROGRAM_ID,
        "version": VERSION,
        "action": "online_metadata_plan",
        "ok": chosen != "unsupported",
        "local_first": True,
        "network_required": True,
        "network_default": "automatic_for_scan_unless_disabled",
        "requires_flag": "--allow-network for one-off CLI enrichment; scans use automatic enrichment unless --no-online-metadata/--offline",
        "provider": chosen,
        "media_type": mtype,
        "path": row.get("path"),
        "query": q,
        "notes": "Plan only. Normal scans can automatically enrich online metadata unless --no-online-metadata/--offline is supplied; one-off enrichment still requires explicit --allow-network.",
    }


def lookup_openlibrary(title: str, download_artwork: bool = True) -> Dict[str, Any]:
    url = "https://openlibrary.org/search.json?" + urllib.parse.urlencode({
        "title": title,
        "limit": "1",
        "fields": "title,author_name,first_publish_year,cover_i,subject,key",
    })
    raw = _http_json(url)
    docs = raw.get("docs") or []
    if not docs:
        return {"ok": False, "provider": "openlibrary", "error": "no_match", "query_url": url}
    d = docs[0]
    cover_url = f"https://covers.openlibrary.org/b/id/{d.get('cover_i')}-M.jpg" if d.get("cover_i") else ""
    artwork_path = _download_online_artwork(cover_url, "ebook", title, "openlibrary") if (download_artwork and cover_url) else ""
    return {
        "ok": True,
        "provider": "openlibrary",
        "source_url": "https://openlibrary.org" + str(d.get("key") or ""),
        "card": {
            "title": _clean_metadata_value(d.get("title")),
            "author": ", ".join(d.get("author_name") or []) if isinstance(d.get("author_name"), list) else _clean_metadata_value(d.get("author_name")),
            "year": str(d.get("first_publish_year") or ""),
            "genre": ", ".join((d.get("subject") or [])[:5]) if isinstance(d.get("subject"), list) else "",
            "cover_url": cover_url,
            "cover_path": artwork_path,
            "synopsis": "",
        },
        "raw_sample": {k: d.get(k) for k in ("title", "author_name", "first_publish_year", "cover_i", "key")},
    }


def lookup_musicbrainz(title: str, artist: str = "", download_artwork: bool = True) -> Dict[str, Any]:
    query = f'releasegroup:"{title}"' + (f' AND artist:"{artist}"' if artist else "")
    url = "https://musicbrainz.org/ws/2/release-group/?" + urllib.parse.urlencode({"query": query, "fmt": "json", "limit": "1"})
    raw = _http_json(url)
    groups = raw.get("release-groups") or []
    if not groups:
        return {"ok": False, "provider": "musicbrainz", "error": "no_match", "query_url": url}
    g = groups[0]
    mbid = str(g.get("id") or "")
    cover_url = f"https://coverartarchive.org/release-group/{mbid}/front-250" if mbid else ""
    artwork_path = ""
    if download_artwork and cover_url:
        try:
            artwork_path = _download_online_artwork(cover_url, "audio", title, "musicbrainz")
        except Exception:
            artwork_path = ""
    artist_credit = g.get("artist-credit") or []
    artist_name = ""
    if artist_credit and isinstance(artist_credit, list):
        artist_name = ", ".join(_clean_metadata_value((a.get("artist") or {}).get("name") or a.get("name")) for a in artist_credit if isinstance(a, dict)).strip(", ")
    return {
        "ok": True,
        "provider": "musicbrainz",
        "source_url": f"https://musicbrainz.org/release-group/{mbid}" if mbid else "",
        "card": {
            "title": _clean_metadata_value(g.get("title")),
            "artist": artist_name or artist,
            "album": _clean_metadata_value(g.get("title")),
            "year": str(g.get("first-release-date") or "")[:4],
            "genre": ", ".join((g.get("tags") or [])[:5]) if isinstance(g.get("tags"), list) else "",
            "cover_url": cover_url,
            "cover_path": artwork_path,
            "synopsis": "",
        },
        "raw_sample": {k: g.get(k) for k in ("id", "title", "first-release-date", "primary-type")},
    }


def lookup_omdb(title: str, api_key: str = "", download_artwork: bool = True) -> Dict[str, Any]:
    key = api_key or os.environ.get("OMDB_API_KEY", "")
    if not key:
        return {"ok": False, "provider": "omdb", "error": "omdb_api_key_required", "notes": "Set OMDB_API_KEY or pass --omdb-api-key."}
    url = "https://www.omdbapi.com/?" + urllib.parse.urlencode({"t": title, "plot": "short", "r": "json", "apikey": key})
    raw = _http_json(url)
    if str(raw.get("Response", "")).lower() == "false":
        return {"ok": False, "provider": "omdb", "error": raw.get("Error") or "no_match", "query_title": title}
    poster = raw.get("Poster") if raw.get("Poster") != "N/A" else ""
    artwork_path = _download_online_artwork(poster, "video", title, "omdb") if (download_artwork and poster) else ""
    return {
        "ok": True,
        "provider": "omdb",
        "source_url": f"https://www.imdb.com/title/{raw.get('imdbID')}" if raw.get("imdbID") else "",
        "card": {
            "title": _clean_metadata_value(raw.get("Title")),
            "year": _clean_metadata_value(raw.get("Year"))[:4],
            "synopsis": _clean_metadata_value(raw.get("Plot")),
            "genre": _clean_metadata_value(raw.get("Genre")),
            "director": _clean_metadata_value(raw.get("Director")),
            "cast": _split_people(raw.get("Actors")),
            "rating": _clean_metadata_value(raw.get("imdbRating")),
            "poster_url": poster,
            "cover_url": poster,
            "poster_path": artwork_path,
            "cover_path": artwork_path,
        },
        "raw_sample": {k: raw.get(k) for k in ("Title", "Year", "Genre", "Director", "Actors", "Plot", "imdbID")},
    }


def _merge_online_card_into_metadata(existing_json: str, online_result: Dict[str, Any]) -> Dict[str, Any]:
    try:
        meta = json.loads(existing_json or "{}")
    except Exception:
        meta = {}
    lib = dict(meta.get("library_metadata") or {})
    card = online_result.get("card") or {}
    # Fill blank user-facing fields only. Manual/local metadata remains authoritative.
    for key in ("title", "year", "synopsis", "genre", "director", "artist", "album", "author", "series", "rating"):
        val = card.get(key)
        if val and not lib.get(key):
            lib[key] = val
    if card.get("cast") and not lib.get("cast"):
        lib["cast"] = card.get("cast")
    for key in ("cover_path", "poster_path", "cover_url", "poster_url"):
        val = card.get(key)
        if val and not lib.get(key):
            lib[key] = val
    lib["online_enriched"] = bool(online_result.get("ok"))
    if online_result.get("provider"):
        lib["online_provider"] = online_result.get("provider")
    if online_result.get("source_url"):
        lib["online_source_url"] = online_result.get("source_url")
    lib["display_blurb"] = lib.get("synopsis") or lib.get("display_blurb") or "Online metadata enrichment available."
    meta["library_metadata"] = lib
    history = list(meta.get("online_metadata") or [])
    history.append({
        "provider": online_result.get("provider"),
        "ok": online_result.get("ok"),
        "source_url": online_result.get("source_url", ""),
        "card": online_result.get("card", {}),
        "looked_up_at": utc_now(),
    })
    meta["online_metadata"] = history[-10:]
    status = str(meta.get("metadata_status") or "basic_only")
    if "+online" not in status:
        meta["metadata_status"] = status + "+online"
    return meta


def extract_media_metadata(path: Path, media_type: str) -> Dict[str, Any]:
    data: Dict[str, Any] = {}
    if media_type == "image":
        data.update(probe_image_with_pillow(path))
    elif media_type in {"video", "audio"}:
        data.update(ffprobe_metadata(path))
    else:
        data["metadata_status"] = "basic_only"
    data["library_metadata"] = derive_library_metadata(path, media_type, data)
    if data["library_metadata"].get("sidecar_paths"):
        data["metadata_status"] = str(data.get("metadata_status") or "basic_only") + "+sidecar"
    if data["library_metadata"].get("cover_path"):
        data["metadata_status"] = str(data.get("metadata_status") or "basic_only") + "+artwork"
    return data


def _path_media_check(path: Path) -> Dict[str, Any]:
    ok, error, p = _safe_regular_media_file(Path(path), require_approved_root=True)
    if not ok:
        return {"ok": False, "error": error, "path": safe_realpath(p)}
    return {"ok": True, "path": safe_realpath(p), "media_type": media_type_for(p)}


def metadata_read_backend(path: Path) -> Dict[str, Any]:
    check = _path_media_check(path)
    if not check.get("ok"):
        return check
    p = Path(check["path"])
    basic = preview_report_for(p, make_thumbnail=False)
    result: Dict[str, Any] = {
        "ok": True,
        "path": str(p),
        "media_type": check.get("media_type"),
        "editable_fields": sorted(EDITABLE_METADATA_FIELDS.keys()),
        "basic_metadata": basic.get("metadata", {}),
        "exiftool_available": tool_available("exiftool"),
        "external_metadata": {},
        "local_only": True,
    }
    if not tool_available("exiftool"):
        result["metadata_status"] = "exiftool_unavailable"
        result["notes"] = "Install libimage-exiftool-perl for embedded metadata read/edit/clean operations."
        return result
    try:
        tags = ["-j"] + [f"-{v}" for v in EDITABLE_METADATA_FIELDS.values()] + ["-CreateDate", "-ModifyDate", str(p)]
        proc = subprocess.run(tags, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=20, check=False)
        result["exiftool_returncode"] = proc.returncode
        result["exiftool_stderr"] = proc.stderr.strip()[:1000]
        if proc.returncode == 0:
            raw = json.loads(proc.stdout or "[]")
            result["external_metadata"] = raw[0] if raw else {}
            result["metadata_status"] = "exiftool_ok"
        else:
            result["metadata_status"] = "exiftool_failed"
    except subprocess.TimeoutExpired:
        result["metadata_status"] = "exiftool_timeout"
    except Exception as exc:
        result["metadata_status"] = f"exiftool_error:{type(exc).__name__}"
    return result


def metadata_clean_backend(path: Path, execute: bool = False, confirm: str = "") -> Dict[str, Any]:
    check = _path_media_check(path)
    if not check.get("ok"):
        return check
    p = Path(check["path"])
    command = ["exiftool", "-P", "-all=", "-tagsfromfile", "@", "-Orientation", str(p)]
    payload: Dict[str, Any] = {
        "ok": True,
        "action": "metadata_clean",
        "path": str(p),
        "media_type": check.get("media_type"),
        "execute": execute,
        "requires_confirm": METADATA_CONFIRM_WORD,
        "confirm_ok": confirm == METADATA_CONFIRM_WORD,
        "exiftool_available": tool_available("exiftool"),
        "backup_behavior": "ExifTool creates FILE_original backup by default when writing.",
        "command_display": " ".join(command),
        "source_media_mutation": bool(execute and confirm == METADATA_CONFIRM_WORD),
        "local_only": True,
    }
    if not tool_available("exiftool"):
        payload.update({"ok": False, "error": "exiftool_unavailable", "install_hint": "sudo apt install libimage-exiftool-perl"})
        return payload
    if not execute or confirm != METADATA_CONFIRM_WORD:
        payload.update({"dry_run": True, "would_modify_source_file": True})
        return payload
    try:
        proc = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=60, check=False)
        payload.update({
            "dry_run": False,
            "returncode": proc.returncode,
            "stdout": proc.stdout.strip()[:2000],
            "stderr": proc.stderr.strip()[:2000],
            "ok": proc.returncode == 0,
        })
    except subprocess.TimeoutExpired:
        payload.update({"ok": False, "error": "exiftool_timeout"})
    except Exception as exc:
        payload.update({"ok": False, "error": f"exiftool_error:{type(exc).__name__}"})
    return payload


def parse_metadata_set(values: Optional[Sequence[str]]) -> Dict[str, str]:
    fields: Dict[str, str] = {}
    for item in values or []:
        if "=" not in item:
            raise ValueError(f"metadata set value must be KEY=VALUE, got: {item}")
        key, val = item.split("=", 1)
        key = key.strip().lower()
        if key not in EDITABLE_METADATA_FIELDS:
            raise ValueError(f"unsupported metadata field: {key}; allowed: {', '.join(sorted(EDITABLE_METADATA_FIELDS))}")
        fields[key] = val.strip()
    return fields


def metadata_edit_backend(path: Path, fields: Dict[str, str], execute: bool = False, confirm: str = "") -> Dict[str, Any]:
    check = _path_media_check(path)
    if not check.get("ok"):
        return check
    p = Path(check["path"])
    clean_fields = {k.strip().lower(): str(v) for k, v in fields.items() if k.strip().lower() in EDITABLE_METADATA_FIELDS}
    command = ["exiftool", "-P"]
    for key, value in clean_fields.items():
        command.append(f"-{EDITABLE_METADATA_FIELDS[key]}={value}")
    command.append(str(p))
    payload: Dict[str, Any] = {
        "ok": bool(clean_fields),
        "action": "metadata_edit",
        "path": str(p),
        "media_type": check.get("media_type"),
        "fields": clean_fields,
        "execute": execute,
        "requires_confirm": METADATA_CONFIRM_WORD,
        "confirm_ok": confirm == METADATA_CONFIRM_WORD,
        "exiftool_available": tool_available("exiftool"),
        "backup_behavior": "ExifTool creates FILE_original backup by default when writing.",
        "command_display": " ".join(command),
        "source_media_mutation": bool(execute and confirm == METADATA_CONFIRM_WORD),
        "local_only": True,
    }
    if not clean_fields:
        payload["error"] = "no_supported_metadata_fields_supplied"
        return payload
    if not tool_available("exiftool"):
        payload.update({"ok": False, "error": "exiftool_unavailable", "install_hint": "sudo apt install libimage-exiftool-perl"})
        return payload
    if not execute or confirm != METADATA_CONFIRM_WORD:
        payload.update({"dry_run": True, "would_modify_source_file": True})
        return payload
    try:
        proc = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=60, check=False)
        payload.update({
            "dry_run": False,
            "returncode": proc.returncode,
            "stdout": proc.stdout.strip()[:2000],
            "stderr": proc.stderr.strip()[:2000],
            "ok": proc.returncode == 0,
        })
    except subprocess.TimeoutExpired:
        payload.update({"ok": False, "error": "exiftool_timeout"})
    except Exception as exc:
        payload.update({"ok": False, "error": f"exiftool_error:{type(exc).__name__}"})
    return payload


def collect_media_targets(targets: Sequence[Path], include_assets: bool = False, limit: int = 5000) -> List[Path]:
    """Expand files/directories into supported media files for batch metadata plans.

    Safe by default: ignores system icon/theme/cache/assets folders unless explicitly
    overridden, and never mutates source files.
    """
    found: List[Path] = []
    seen = set()
    for target in targets:
        t = Path(target).expanduser()
        if _path_has_symlink_component(t):
            continue
        if t.is_file() and is_media_file(t) and is_in_default_media_roots(t):
            rp = safe_realpath(t)
            if rp not in seen:
                seen.add(rp); found.append(Path(rp))
        elif t.is_dir() and is_in_default_media_roots(t):
            for root, dirs, files in os.walk(t, followlinks=False):
                r = Path(root)
                dirs[:] = [d for d in dirs if not (r / d).is_symlink()]
                if not include_assets and is_system_asset_path(r):
                    dirs[:] = []
                    continue
                for name in files:
                    p = r / name
                    if p.is_symlink() or _path_has_symlink_component(p):
                        continue
                    if is_media_file(p) and is_in_default_media_roots(p):
                        rp = safe_realpath(p)
                        if rp not in seen:
                            seen.add(rp); found.append(Path(rp))
                            if len(found) >= limit:
                                return found
    return found


def metadata_batch_clean_plan(targets: Sequence[Path], include_assets: bool = False, output: Optional[Path] = None) -> Dict[str, Any]:
    files = collect_media_targets(targets, include_assets=include_assets)
    items = []
    for f in files:
        plan = metadata_clean_backend(f, execute=False)
        items.append({
            "path": str(f),
            "media_type": media_type_for(f),
            "ok": plan.get("ok"),
            "metadata_status": plan.get("metadata_status"),
            "exiftool_available": plan.get("exiftool_available"),
            "would_modify_source_file": plan.get("would_modify_source_file", True),
            "requires_confirm": METADATA_CONFIRM_WORD,
        })
    payload = {
        "ok": True,
        "action": "metadata_batch_clean_plan",
        "version": VERSION,
        "targets": [safe_realpath(Path(t)) for t in targets],
        "count": len(items),
        "items": items,
        "execute_supported": False,
        "notes": "Batch cleaner is a planning/review workflow in v0.8.0. Run single-file guarded clean for actual writes.",
        "ui_readiness": {
            "default_window": "1420x980",
            "minimum_window": "1160x800",
            "themed_inputs": True,
            "themed_dropdowns": True,
            "expanded_preview": True,
            "thumb_column_width": 76,
            "compact_search_rows": True,
        },
        "local_only": True,
        "generated_at": utc_now(),
    }
    if output:
        output = _ensure_safe_output_path(Path(output).expanduser(), role="metadata_report")
        _safe_write_text(output, json.dumps(payload, indent=2), role="metadata_report")
        payload["output"] = str(output)
    return payload


def metadata_backup_review(root: Path, output: Optional[Path] = None, limit: int = 1000) -> Dict[str, Any]:
    root = Path(root).expanduser()
    backups = []
    if root.is_file() and root.name.endswith("_original"):
        candidates = [root]
    elif root.is_dir():
        candidates = []
        for r, _dirs, files in os.walk(root):
            for name in files:
                if name.endswith("_original"):
                    candidates.append(Path(r) / name)
                    if len(candidates) >= limit:
                        break
            if len(candidates) >= limit:
                break
    else:
        candidates = []
    for b in candidates:
        target = b.with_name(b.name[:-9]) if b.name.endswith("_original") else b
        backups.append({
            "backup_path": safe_realpath(b),
            "probable_original_path": safe_realpath(target),
            "backup_exists": b.exists(),
            "original_exists": target.exists(),
            "size_bytes": b.stat().st_size if b.exists() else 0,
            "restore_guard": METADATA_RESTORE_CONFIRM_WORD,
        })
    payload = {
        "ok": True,
        "action": "metadata_backup_review",
        "version": VERSION,
        "root": safe_realpath(root),
        "count": len(backups),
        "backups": backups,
        "notes": "Review ExifTool FILE_original backups. Restore is guarded and never automatic.",
        "ui_readiness": {
            "default_window": "1420x980",
            "minimum_window": "1160x800",
            "themed_inputs": True,
            "themed_dropdowns": True,
            "expanded_preview": True,
            "thumb_column_width": 76,
            "compact_search_rows": True,
        },
        "local_only": True,
        "generated_at": utc_now(),
    }
    if output:
        output = _ensure_safe_output_path(Path(output).expanduser(), role="metadata_report")
        _safe_write_text(output, json.dumps(payload, indent=2), role="metadata_report")
        payload["output"] = str(output)
    return payload


def metadata_restore_backup_backend(backup_path: Path, execute: bool = False, confirm: str = "") -> Dict[str, Any]:
    backup = Path(backup_path).expanduser()
    if _path_has_symlink_component(backup):
        return {"ok": False, "error": "symlink_backup_path_blocked", "path": safe_realpath(backup)}
    if not backup.exists() or not backup.is_file() or not backup.name.endswith("_original"):
        return {"ok": False, "error": "expected_existing_exiftool_backup_file_ending_original", "path": safe_realpath(backup)}
    target = backup.with_name(backup.name[:-9])
    ok, error, _checked_target = _safe_regular_media_file(target, require_approved_root=True)
    if not ok:
        return {"ok": False, "error": f"restore_target_{error}", "path": safe_realpath(target)}
    payload = {
        "ok": True,
        "action": "metadata_restore_backup",
        "backup_path": safe_realpath(backup),
        "target_path": safe_realpath(target),
        "execute": execute,
        "requires_confirm": METADATA_RESTORE_CONFIRM_WORD,
        "confirm_ok": confirm == METADATA_RESTORE_CONFIRM_WORD,
        "would_overwrite_target": target.exists(),
        "source_media_mutation": bool(execute and confirm == METADATA_RESTORE_CONFIRM_WORD),
        "local_only": True,
    }
    if not execute or confirm != METADATA_RESTORE_CONFIRM_WORD:
        payload["dry_run"] = True
        return payload
    tmp = target.with_name(target.name + f".restore-tmp-{os.getpid()}")
    if tmp.exists() or tmp.is_symlink():
        tmp.unlink(missing_ok=True)
    shutil.copy2(backup, tmp, follow_symlinks=False)
    os.replace(tmp, target)
    payload.update({"dry_run": False, "restored": True, "ok": True, "atomic_restore": True})
    return payload




def caja_script_content(action: str) -> str:
    script = """#!/bin/sh
# Sentinel Media Index Caja context script — ACTION metadata
# Uses the first selected file from Caja/MATE. Source files are not modified on launch.
set -eu
SELECTED="${CAJA_SCRIPT_SELECTED_FILE_PATHS:-}"
if [ -z "$SELECTED" ]; then
  SELECTED="${NAUTILUS_SCRIPT_SELECTED_FILE_PATHS:-}"
fi
FILE=$(printf '%s
' "$SELECTED" | sed '/^$/d' | head -n 1)
if [ -z "$FILE" ]; then
  exit 0
fi
case "ACTION" in
  read)  exec sentinel-media-index --context-read-metadata "$FILE" ;;
  clean) exec sentinel-media-index --context-clean-metadata "$FILE" ;;
  edit)  exec sentinel-media-index --context-edit-metadata "$FILE" ;;
  *) exit 2 ;;
esac
"""
    return script.replace("ACTION", action)


def install_caja_scripts(target_dir: Optional[Path] = None) -> Dict[str, Any]:
    target = (target_dir or CAJA_SCRIPT_DIR).expanduser()
    if _path_has_symlink_component(target):
        return {"ok": False, "error": "caja_script_target_symlink_blocked", "target_dir": safe_realpath(target)}
    target.mkdir(parents=True, exist_ok=True)
    installed: List[str] = []
    for display_name, action in CONTEXT_ACTIONS.items():
        script = target / display_name
        _safe_write_text(script, caja_script_content(action), role="caja_script")
        script.chmod(0o755)
        installed.append(str(script))
    return {
        "ok": True,
        "action": "install_caja_scripts",
        "target_dir": str(target),
        "installed": installed,
        "notes": "Restart Caja or log out/in if the Scripts menu does not refresh immediately. Scripts appear under right-click > Scripts > Sentinel Media Index.",
        "local_only": True,
        "network_required": False,
        "generated_at": utc_now(),
    }


def context_action_payload(action: str, path: Path) -> Dict[str, Any]:
    """AEGIS-readable description of file-manager context metadata workflows."""
    check = _path_media_check(path)
    safe_actions = {"read", "clean", "edit"}
    payload: Dict[str, Any] = {
        "program": APP_NAME,
        "program_id": PROGRAM_ID,
        "version": VERSION,
        "action": action,
        "requested_path": safe_realpath(Path(path)),
        "valid_actions": sorted(safe_actions),
        "local_only": True,
        "network_required": False,
        "source_media_mutation_on_launch": False,
        "gui_autofill_supported": True,
        "requires_gui_confirmation_for_writes": METADATA_CONFIRM_WORD,
        "exiftool_available": tool_available("exiftool"),
        "generated_at": utc_now(),
    }
    if action not in safe_actions:
        payload.update({"ok": False, "error": "unsupported_context_action"})
        return payload
    if not check.get("ok"):
        payload.update(check)
        payload["ok"] = False
        return payload
    payload.update({
        "ok": True,
        "path": check.get("path"),
        "media_type": check.get("media_type"),
        "launch_command": f"sentinel-media-index --context-{action}-metadata {check.get('path')}",
        "notes": "Opens Sentinel Media Index with the selected file loaded into the requested metadata workflow.",
    })
    return payload

def thumb_name_for(path: Path) -> str:
    key = f"{safe_realpath(path)}|{path.stat().st_mtime_ns if path.exists() else 0}|{path.stat().st_size if path.exists() else 0}".encode("utf-8", "replace")
    return hashlib.sha1(key).hexdigest() + ".png"


def make_placeholder_thumbnail(path: Path, media_type: str, output: Path, size: Tuple[int, int] = (256, 144)) -> Optional[str]:
    try:
        from PIL import Image, ImageDraw, ImageFont  # type: ignore
        output = _ensure_safe_output_path(output, role="thumbnail")
        img = Image.new("RGB", size, "#171a1f")
        d = ImageDraw.Draw(img)
        accent = THEME["gold"] if media_type in {"audio", "playlist"} else THEME["cyan"] if media_type == "video" else THEME["muted"]
        d.rectangle((0, 0, size[0]-1, size[1]-1), outline=accent, width=3)
        label = media_type.upper()
        name = path.name[:26]
        try:
            font = ImageFont.load_default()
        except Exception:
            font = None
        d.text((14, 18), label, fill=accent, font=font)
        d.text((14, 54), name, fill="#EDE7D1", font=font)
        d.text((14, 92), path.suffix.lower() or "media", fill="#A9A39A", font=font)
        img.save(output, "PNG")
        return str(output)
    except Exception:
        # Last-resort SVG card for file managers; Tk preview may not render SVG.
        svg = output.with_suffix(".svg")
        svg_content = (
            '<svg xmlns="http://www.w3.org/2000/svg" width="256" height="144" viewBox="0 0 256 144">'
            '<rect width="256" height="144" fill="#171a1f"/>'
            '<rect x="2" y="2" width="252" height="140" fill="none" stroke="#E19B00" stroke-width="3"/>'
            f'<text x="14" y="34" fill="#E19B00" font-family="sans-serif" font-size="18">{media_type.upper()}</text>'
            f'<text x="14" y="72" fill="#EDE7D1" font-family="sans-serif" font-size="12">{path.name[:30]}</text>'
            '</svg>'
        )
        _safe_write_text(svg, svg_content, role="thumbnail_svg")
        return str(svg)


def generate_thumbnail(path: Path, media_type: str) -> Optional[str]:
    try:
        out = THUMB_ROOT / media_type / thumb_name_for(path)
        if out.exists() and not out.is_symlink():
            return str(out)
        if out.is_symlink():
            return None
        out = _ensure_safe_output_path(out, role="thumbnail")
        if media_type == "image":
            try:
                from PIL import Image  # type: ignore
                with Image.open(path) as img:
                    img.thumbnail((256, 256))
                    canvas = Image.new("RGB", (256, 256), "#101214")
                    x = (256 - img.width) // 2
                    y = (256 - img.height) // 2
                    if img.mode in ("RGBA", "LA"):
                        canvas.paste(img.convert("RGBA"), (x, y), img.convert("RGBA"))
                    else:
                        canvas.paste(img.convert("RGB"), (x, y))
                    canvas.save(out, "PNG")
                    return str(out)
            except Exception:
                return make_placeholder_thumbnail(path, media_type, out)
        return make_placeholder_thumbnail(path, media_type, out)
    except Exception:
        return None


def preview_report_for(path: Path, make_thumbnail: bool = True) -> Dict[str, Any]:
    path = path.expanduser()
    if not path.exists() or not path.is_file():
        return {"ok": False, "error": "not_a_file", "path": safe_realpath(path)}
    st = path.stat()
    mtype = media_type_for(path)
    meta = extract_media_metadata(path, mtype)
    thumb = generate_thumbnail(path, mtype) if make_thumbnail and is_media_file(path) else None
    return {
        "ok": True,
        "path": safe_realpath(path),
        "filename": path.name,
        "media_type": mtype,
        "extension": path.suffix.lower(),
        "size_bytes": int(st.st_size),
        "mtime": float(st.st_mtime),
        "thumbnail_path": thumb,
        "metadata": meta,
        "generated_at": utc_now(),
    }


@dataclass
class MediaRecord:
    path: str
    parent: str
    filename: str
    extension: str
    media_type: str
    mime_guess: str
    size_bytes: int
    mtime: float
    sha256: Optional[str]
    width: Optional[int]
    height: Optional[int]
    duration_seconds: Optional[float]
    codec: str
    container: str
    thumbnail_path: str
    metadata_json: str
    metadata_status: str
    indexed_at: str


class MediaIndexDB:
    def __init__(self, db_path: Path = DB_PATH):
        self.db_path = db_path
        ensure_dirs()

    def connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        return conn

    def _ensure_column(self, conn: sqlite3.Connection, table: str, column: str, decl: str) -> None:
        existing = {row[1] for row in conn.execute(f"PRAGMA table_info({table})").fetchall()}
        if column not in existing:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {decl}")

    def _migrate_schema(self, conn: sqlite3.Connection) -> None:
        self._ensure_column(conn, "media_items", "width", "INTEGER")
        self._ensure_column(conn, "media_items", "height", "INTEGER")
        self._ensure_column(conn, "media_items", "duration_seconds", "REAL")
        self._ensure_column(conn, "media_items", "codec", "TEXT DEFAULT ''")
        self._ensure_column(conn, "media_items", "container", "TEXT DEFAULT ''")
        self._ensure_column(conn, "media_items", "thumbnail_path", "TEXT DEFAULT ''")
        self._ensure_column(conn, "media_items", "metadata_json", "TEXT DEFAULT ''")
        self._ensure_column(conn, "media_items", "metadata_status", "TEXT DEFAULT ''")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_media_duration ON media_items(duration_seconds)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_media_dimensions ON media_items(width,height)")

    def init(self) -> None:
        with self.connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS meta (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS scans (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    root_path TEXT NOT NULL,
                    started_at TEXT NOT NULL,
                    finished_at TEXT,
                    files_seen INTEGER DEFAULT 0,
                    media_indexed INTEGER DEFAULT 0,
                    errors INTEGER DEFAULT 0,
                    hash_enabled INTEGER DEFAULT 0
                );
                CREATE TABLE IF NOT EXISTS media_items (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    path TEXT NOT NULL UNIQUE,
                    parent TEXT NOT NULL,
                    filename TEXT NOT NULL,
                    extension TEXT NOT NULL,
                    media_type TEXT NOT NULL,
                    mime_guess TEXT,
                    size_bytes INTEGER NOT NULL,
                    mtime REAL NOT NULL,
                    sha256 TEXT,
                    indexed_at TEXT NOT NULL,
                    last_seen_at TEXT NOT NULL,
                    missing INTEGER DEFAULT 0,
                    notes TEXT DEFAULT ''
                );
                CREATE INDEX IF NOT EXISTS idx_media_type ON media_items(media_type);
                CREATE INDEX IF NOT EXISTS idx_media_filename ON media_items(filename);
                CREATE INDEX IF NOT EXISTS idx_media_parent ON media_items(parent);
                CREATE INDEX IF NOT EXISTS idx_media_sha256 ON media_items(sha256);
                CREATE INDEX IF NOT EXISTS idx_media_size_name ON media_items(size_bytes, filename);
                CREATE TABLE IF NOT EXISTS scan_errors (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    scan_id INTEGER,
                    path TEXT NOT NULL,
                    error TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY(scan_id) REFERENCES scans(id) ON DELETE SET NULL
                );
                CREATE TABLE IF NOT EXISTS tags (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL UNIQUE,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS media_tags (
                    media_id INTEGER NOT NULL,
                    tag_id INTEGER NOT NULL,
                    created_at TEXT NOT NULL,
                    PRIMARY KEY(media_id, tag_id),
                    FOREIGN KEY(media_id) REFERENCES media_items(id) ON DELETE CASCADE,
                    FOREIGN KEY(tag_id) REFERENCES tags(id) ON DELETE CASCADE
                );
                CREATE TABLE IF NOT EXISTS collections (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL UNIQUE,
                    description TEXT DEFAULT '',
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS collection_items (
                    collection_id INTEGER NOT NULL,
                    media_id INTEGER NOT NULL,
                    created_at TEXT NOT NULL,
                    PRIMARY KEY(collection_id, media_id),
                    FOREIGN KEY(collection_id) REFERENCES collections(id) ON DELETE CASCADE,
                    FOREIGN KEY(media_id) REFERENCES media_items(id) ON DELETE CASCADE
                );
                CREATE INDEX IF NOT EXISTS idx_tags_name ON tags(name);
                CREATE INDEX IF NOT EXISTS idx_collections_name ON collections(name);
                """
            )
            self._migrate_schema(conn)
            conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES(?,?)", ("schema_version", str(DB_SCHEMA_VERSION)))
            conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES(?,?)", ("app_version", VERSION))
            conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES(?,?)", ("last_init", utc_now()))

    def start_scan(self, root: str, hash_enabled: bool) -> int:
        with self.connect() as conn:
            cur = conn.execute(
                "INSERT INTO scans(root_path,started_at,hash_enabled) VALUES(?,?,?)",
                (root, utc_now(), int(hash_enabled)),
            )
            return int(cur.lastrowid)

    def finish_scan(self, scan_id: int, files_seen: int, media_indexed: int, errors: int) -> None:
        with self.connect() as conn:
            conn.execute(
                "UPDATE scans SET finished_at=?, files_seen=?, media_indexed=?, errors=? WHERE id=?",
                (utc_now(), files_seen, media_indexed, errors, scan_id),
            )

    def log_error(self, scan_id: Optional[int], path: str, error: str) -> None:
        with self.connect() as conn:
            conn.execute(
                "INSERT INTO scan_errors(scan_id,path,error,created_at) VALUES(?,?,?,?)",
                (scan_id, path, error[:1000], utc_now()),
            )

    def upsert_media(self, rec: MediaRecord) -> None:
        with self.connect() as conn:
            conn.execute(
                """
                INSERT INTO media_items(path,parent,filename,extension,media_type,mime_guess,size_bytes,mtime,sha256,width,height,duration_seconds,codec,container,thumbnail_path,metadata_json,metadata_status,indexed_at,last_seen_at,missing)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,0)
                ON CONFLICT(path) DO UPDATE SET
                    parent=excluded.parent,
                    filename=excluded.filename,
                    extension=excluded.extension,
                    media_type=excluded.media_type,
                    mime_guess=excluded.mime_guess,
                    size_bytes=excluded.size_bytes,
                    mtime=excluded.mtime,
                    sha256=COALESCE(excluded.sha256, media_items.sha256),
                    width=COALESCE(excluded.width, media_items.width),
                    height=COALESCE(excluded.height, media_items.height),
                    duration_seconds=COALESCE(excluded.duration_seconds, media_items.duration_seconds),
                    codec=COALESCE(NULLIF(excluded.codec,''), media_items.codec),
                    container=COALESCE(NULLIF(excluded.container,''), media_items.container),
                    thumbnail_path=COALESCE(NULLIF(excluded.thumbnail_path,''), media_items.thumbnail_path),
                    metadata_json=COALESCE(NULLIF(excluded.metadata_json,''), media_items.metadata_json),
                    metadata_status=COALESCE(NULLIF(excluded.metadata_status,''), media_items.metadata_status),
                    indexed_at=excluded.indexed_at,
                    last_seen_at=excluded.last_seen_at,
                    missing=0
                """,
                (
                    rec.path,
                    rec.parent,
                    rec.filename,
                    rec.extension,
                    rec.media_type,
                    rec.mime_guess,
                    rec.size_bytes,
                    rec.mtime,
                    rec.sha256,
                    rec.width,
                    rec.height,
                    rec.duration_seconds,
                    rec.codec,
                    rec.container,
                    rec.thumbnail_path,
                    rec.metadata_json,
                    rec.metadata_status,
                    rec.indexed_at,
                    rec.indexed_at,
                ),
            )

    def mark_missing(self) -> int:
        count = 0
        with self.connect() as conn:
            rows = conn.execute("SELECT id,path FROM media_items WHERE missing=0").fetchall()
            for row in rows:
                if not Path(row["path"]).exists():
                    conn.execute("UPDATE media_items SET missing=1 WHERE id=?", (row["id"],))
                    count += 1
        return count

    def stats(self) -> Dict[str, Any]:
        with self.connect() as conn:
            total = conn.execute("SELECT COUNT(*) FROM media_items").fetchone()[0]
            present = conn.execute("SELECT COUNT(*) FROM media_items WHERE missing=0").fetchone()[0]
            missing = conn.execute("SELECT COUNT(*) FROM media_items WHERE missing=1").fetchone()[0]
            size = conn.execute("SELECT COALESCE(SUM(size_bytes),0) FROM media_items WHERE missing=0").fetchone()[0]
            by_type = {r["media_type"]: r["c"] for r in conn.execute("SELECT media_type, COUNT(*) c FROM media_items GROUP BY media_type")}
            scans = conn.execute("SELECT COUNT(*) FROM scans").fetchone()[0]
            last_scan = conn.execute("SELECT * FROM scans ORDER BY id DESC LIMIT 1").fetchone()
            dup_hash_groups = conn.execute(
                "SELECT COUNT(*) FROM (SELECT sha256 FROM media_items WHERE sha256 IS NOT NULL AND sha256!='' GROUP BY sha256 HAVING COUNT(*)>1)"
            ).fetchone()[0]
            dup_name_size_groups = conn.execute(
                "SELECT COUNT(*) FROM (SELECT filename,size_bytes FROM media_items GROUP BY filename,size_bytes HAVING COUNT(*)>1)"
            ).fetchone()[0]
            thumbnails = conn.execute("SELECT COUNT(*) FROM media_items WHERE thumbnail_path IS NOT NULL AND thumbnail_path!=''").fetchone()[0]
            enriched = conn.execute("SELECT COUNT(*) FROM media_items WHERE metadata_status IS NOT NULL AND metadata_status!=''").fetchone()[0]
            covers = conn.execute("SELECT COUNT(*) FROM media_items WHERE metadata_json LIKE '%cover_path%' AND metadata_json NOT LIKE '%\"cover_path\": \"\"%'").fetchone()[0]
            sidecars = conn.execute("SELECT COUNT(*) FROM media_items WHERE metadata_json LIKE '%sidecar_paths%' AND metadata_json NOT LIKE '%\"sidecar_paths\": []%'").fetchone()[0]
            durations = conn.execute("SELECT COALESCE(SUM(duration_seconds),0) FROM media_items WHERE duration_seconds IS NOT NULL").fetchone()[0]
            tag_count = conn.execute("SELECT COUNT(*) FROM tags").fetchone()[0]
            collection_count = conn.execute("SELECT COUNT(*) FROM collections").fetchone()[0]
        return {
            "app": APP_NAME,
            "program_id": PROGRAM_ID,
            "version": VERSION,
            "db_path": str(self.db_path),
            "data_root": str(DATA_ROOT),
            "total_items": total,
            "present_items": present,
            "missing_items": missing,
            "total_size_bytes": size,
            "by_type": by_type,
            "scan_count": scans,
            "last_scan": dict(last_scan) if last_scan else None,
            "duplicate_hash_groups": dup_hash_groups,
            "duplicate_name_size_groups": dup_name_size_groups,
            "thumbnail_count": thumbnails,
            "metadata_enriched_items": enriched,
            "cover_art_items": covers,
            "sidecar_enriched_items": sidecars,
            "total_duration_seconds": durations,
            "tag_count": tag_count,
            "collection_count": collection_count,
            "thumbnail_root": str(THUMB_ROOT),
            "player_handoff_root": str(PLAYER_ROOT),
            "organisation_report_root": str(ORG_ROOT),
            "player_contract_root": str(PLAYER_CONTRACT_ROOT),
            "metadata_report_root": str(METADATA_ROOT),
            "player_library_root": str(LIBRARY_ROOT),
            "visual_board_root": str(VISUAL_BOARD_ROOT),
            "report_root": str(REPORT_ROOT),
            "local_only": True,
            "network_required": False,
        }

    def search(self, query: str = "", media_type: str = "all", limit: int = 200) -> List[Dict[str, Any]]:
        clauses = []
        params: List[Any] = []
        if query:
            like = f"%{query}%"
            clauses.append("(filename LIKE ? OR parent LIKE ? OR path LIKE ? OR notes LIKE ?)")
            params.extend([like, like, like, like])
        if media_type == "all":
            clauses.append("media_type IN ('audio','video','ebook','image')")
        else:
            if media_type == "tvshow":
                clauses.append("media_type=?")
                params.append("video")
                clauses.append("(metadata_json LIKE ? OR metadata_json LIKE ? OR metadata_json LIKE ?)")
                params.extend(["%TV Shows / Series%", "%\"series\":%", "%\"season\":%"] )
            else:
                clauses.append("media_type=?")
                params.append(media_type)
        where = " WHERE " + " AND ".join(clauses) if clauses else ""
        sql = f"SELECT * FROM media_items{where} ORDER BY indexed_at DESC, filename COLLATE NOCASE LIMIT ?"
        params.append(limit)
        with self.connect() as conn:
            return [dict(r) for r in conn.execute(sql, params).fetchall()]

    def duplicates(self, mode: str = "hash", limit: int = 500) -> List[Dict[str, Any]]:
        if mode == "hash":
            sql = """
            SELECT sha256 AS duplicate_key, COUNT(*) c, SUM(size_bytes) total_size
            FROM media_items
            WHERE sha256 IS NOT NULL AND sha256!=''
            GROUP BY sha256 HAVING COUNT(*)>1
            ORDER BY c DESC, total_size DESC LIMIT ?
            """
            item_sql = "SELECT * FROM media_items WHERE sha256=? ORDER BY path"
        else:
            sql = """
            SELECT filename || '|' || size_bytes AS duplicate_key, COUNT(*) c, SUM(size_bytes) total_size
            FROM media_items
            GROUP BY filename,size_bytes HAVING COUNT(*)>1
            ORDER BY c DESC, total_size DESC LIMIT ?
            """
            item_sql = "SELECT * FROM media_items WHERE filename=? AND size_bytes=? ORDER BY path"
        groups: List[Dict[str, Any]] = []
        with self.connect() as conn:
            for row in conn.execute(sql, (limit,)).fetchall():
                key = row["duplicate_key"]
                if mode == "hash":
                    items = [dict(r) for r in conn.execute(item_sql, (key,)).fetchall()]
                else:
                    filename, size_s = key.rsplit("|", 1)
                    items = [dict(r) for r in conn.execute(item_sql, (filename, int(size_s))).fetchall()]
                groups.append({"key": key, "count": row["c"], "total_size_bytes": row["total_size"], "items": items})
        return groups

    def export_csv(self, output: Path, query: str = "", media_type: str = "all") -> Path:
        rows = self.search(query=query, media_type=media_type, limit=1000000)
        output = _ensure_safe_output_path(output, role="csv_export")
        fields = [
            "id", "path", "parent", "filename", "extension", "media_type", "mime_guess", "size_bytes", "mtime", "sha256", "width", "height", "duration_seconds", "codec", "container", "thumbnail_path", "metadata_status", "metadata_json", "indexed_at", "last_seen_at", "missing", "notes"
        ]
        with output.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
            writer.writeheader()
            writer.writerows(rows)
        return output

    def export_json(self, output: Path, query: str = "", media_type: str = "all") -> Path:
        rows = self.search(query=query, media_type=media_type, limit=1000000)
        output = _ensure_safe_output_path(output, role="json_export")
        _safe_write_text(output, json.dumps({"generated_at": utc_now(), "items": rows}, indent=2), role="json_export")
        return output

    def backup(self) -> Path:
        self.init()
        stamp = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
        out = _ensure_safe_output_path(BACKUP_ROOT / f"sentinel_media_index_backup_{stamp}.sqlite3", role="sqlite_backup")
        with self.connect() as src:
            dst = sqlite3.connect(str(out))
            try:
                src.backup(dst)
            finally:
                dst.close()
        return out

    def _media_id_for_path(self, path: Path | str) -> Optional[int]:
        p = safe_realpath(Path(path))
        with self.connect() as conn:
            row = conn.execute("SELECT id FROM media_items WHERE path=?", (p,)).fetchone()
            return int(row["id"]) if row else None

    def get_item_by_path(self, path: Path | str) -> Optional[Dict[str, Any]]:
        self.init()
        p = safe_realpath(Path(path))
        with self.connect() as conn:
            row = conn.execute("SELECT * FROM media_items WHERE path=?", (p,)).fetchone()
            return dict(row) if row else None

    def refresh_metadata_for_path(self, path: Path | str, refresh_thumbnail: bool = True) -> Dict[str, Any]:
        self.init()
        p = Path(path).expanduser()
        check = _path_media_check(p)
        if not check.get("ok"):
            return check
        real = Path(check["path"])
        row = self.get_item_by_path(real)
        if not row:
            return {"ok": False, "error": "media_not_indexed", "path": str(real)}
        mtype = media_type_for(real)
        meta = extract_media_metadata(real, mtype)
        thumb = generate_thumbnail(real, mtype) if refresh_thumbnail else (row.get("thumbnail_path") or "")
        with self.connect() as conn:
            conn.execute(
                """
                UPDATE media_items
                SET width=?, height=?, duration_seconds=?, codec=?, container=?, thumbnail_path=?,
                    metadata_json=?, metadata_status=?, size_bytes=?, mtime=?, last_seen_at=?, missing=0
                WHERE path=?
                """,
                (
                    meta.get("width") or row.get("width"),
                    meta.get("height") or row.get("height"),
                    meta.get("duration_seconds") or row.get("duration_seconds"),
                    str(meta.get("codec") or row.get("codec") or ""),
                    str(meta.get("container") or row.get("container") or ""),
                    thumb or row.get("thumbnail_path") or "",
                    json.dumps(meta, sort_keys=True),
                    str(meta.get("metadata_status") or ""),
                    real.stat().st_size,
                    real.stat().st_mtime,
                    utc_now(),
                    str(real),
                ),
            )
        return {"ok": True, "path": str(real), "metadata_status": meta.get("metadata_status"), "thumbnail_path": thumb or ""}

    def online_enrich_path(self, path: Path | str, provider: str = "auto", allow_network: bool = False, omdb_api_key: str = "", download_artwork: bool = True) -> Dict[str, Any]:
        self.init()
        p = safe_realpath(Path(path))
        row = self.get_item_by_path(p)
        if not row:
            return {"ok": False, "error": "media_not_indexed", "path": p}
        plan = online_metadata_plan_for_row(row, provider=provider)
        if not plan.get("ok"):
            return plan
        if not allow_network:
            plan["ok"] = False
            plan["error"] = "network_not_allowed"
            return plan
        q = plan.get("query") or {}
        chosen = str(plan.get("provider") or "auto")
        try:
            if chosen == "openlibrary":
                result = lookup_openlibrary(str(q.get("title") or ""), download_artwork=download_artwork)
            elif chosen == "musicbrainz":
                result = lookup_musicbrainz(str(q.get("album") or q.get("title") or ""), artist=str(q.get("artist") or ""), download_artwork=download_artwork)
            elif chosen == "omdb":
                result = lookup_omdb(str(q.get("title") or ""), api_key=omdb_api_key, download_artwork=download_artwork)
            else:
                return {"ok": False, "error": "unsupported_online_provider", "provider": chosen}
        except Exception as exc:
            return {"ok": False, "provider": chosen, "error": f"online_lookup_failed:{type(exc).__name__}", "detail": str(exc)[:500], "plan": plan}
        if not result.get("ok"):
            result["plan"] = plan
            return result
        merged = _merge_online_card_into_metadata(str(row.get("metadata_json") or ""), result)
        with self.connect() as conn:
            conn.execute(
                "UPDATE media_items SET metadata_json=?, metadata_status=?, thumbnail_path=COALESCE(NULLIF(?,''), thumbnail_path), last_seen_at=? WHERE path=?",
                (json.dumps(merged, sort_keys=True), str(merged.get("metadata_status") or ""), (result.get("card") or {}).get("cover_path") or (result.get("card") or {}).get("poster_path") or "", utc_now(), p),
            )
        out = {"ok": True, "action": "online_metadata_enrich", "path": p, "provider": chosen, "result": result, "updated_index": True, "player_exports_include_enrichment": True, "network_used": True}
        report = _ensure_safe_output_path(ONLINE_METADATA_ROOT / f"online_enrich_{hashlib.sha1(p.encode()).hexdigest()[:12]}_{int(time.time())}.json", role="online_metadata_report")
        _safe_write_text(report, json.dumps(out, indent=2), role="online_metadata_report")
        out["report_path"] = str(report)
        return out

    def add_tag(self, path: Path | str, tag_name: str) -> Dict[str, Any]:
        self.init()
        tag = tag_name.strip().lower()
        if not tag:
            return {"ok": False, "error": "empty_tag"}
        media_id = self._media_id_for_path(path)
        if media_id is None:
            return {"ok": False, "error": "media_not_indexed", "path": safe_realpath(Path(path))}
        with self.connect() as conn:
            conn.execute("INSERT OR IGNORE INTO tags(name,created_at) VALUES(?,?)", (tag, utc_now()))
            tag_id = int(conn.execute("SELECT id FROM tags WHERE name=?", (tag,)).fetchone()["id"])
            conn.execute("INSERT OR IGNORE INTO media_tags(media_id,tag_id,created_at) VALUES(?,?,?)", (media_id, tag_id, utc_now()))
        return {"ok": True, "path": safe_realpath(Path(path)), "tag": tag}

    def list_tags(self) -> List[Dict[str, Any]]:
        self.init()
        with self.connect() as conn:
            return [dict(r) for r in conn.execute("""
                SELECT t.name, COUNT(mt.media_id) AS item_count, MIN(t.created_at) AS created_at
                FROM tags t LEFT JOIN media_tags mt ON mt.tag_id=t.id
                GROUP BY t.id ORDER BY t.name COLLATE NOCASE
            """).fetchall()]

    def create_collection(self, name: str, description: str = "") -> Dict[str, Any]:
        self.init()
        cname = name.strip()
        if not cname:
            return {"ok": False, "error": "empty_collection_name"}
        with self.connect() as conn:
            conn.execute("INSERT OR IGNORE INTO collections(name,description,created_at) VALUES(?,?,?)", (cname, description.strip(), utc_now()))
            row = conn.execute("SELECT * FROM collections WHERE name=?", (cname,)).fetchone()
        return {"ok": True, "collection": dict(row) if row else {"name": cname}}

    def add_to_collection(self, collection_name: str, path: Path | str) -> Dict[str, Any]:
        self.init()
        c = self.create_collection(collection_name)
        if not c.get("ok"):
            return c
        media_id = self._media_id_for_path(path)
        if media_id is None:
            return {"ok": False, "error": "media_not_indexed", "path": safe_realpath(Path(path))}
        with self.connect() as conn:
            cid = int(conn.execute("SELECT id FROM collections WHERE name=?", (collection_name.strip(),)).fetchone()["id"])
            conn.execute("INSERT OR IGNORE INTO collection_items(collection_id,media_id,created_at) VALUES(?,?,?)", (cid, media_id, utc_now()))
        return {"ok": True, "collection": collection_name.strip(), "path": safe_realpath(Path(path))}

    def list_collections(self) -> List[Dict[str, Any]]:
        self.init()
        with self.connect() as conn:
            return [dict(r) for r in conn.execute("""
                SELECT c.name, c.description, COUNT(ci.media_id) AS item_count, c.created_at
                FROM collections c LEFT JOIN collection_items ci ON ci.collection_id=c.id
                GROUP BY c.id ORDER BY c.name COLLATE NOCASE
            """).fetchall()]

    def collection_items(self, collection_name: str, limit: int = 1000000) -> List[Dict[str, Any]]:
        self.init()
        with self.connect() as conn:
            return [dict(r) for r in conn.execute("""
                SELECT mi.* FROM media_items mi
                JOIN collection_items ci ON ci.media_id=mi.id
                JOIN collections c ON c.id=ci.collection_id
                WHERE c.name=? ORDER BY mi.media_type, mi.filename COLLATE NOCASE LIMIT ?
            """, (collection_name.strip(), limit)).fetchall()]

    def categorized_search(self, query: str = "", media_type: str = "all", limit: int = 1000) -> Dict[str, List[Dict[str, Any]]]:
        rows = self.search(query=query, media_type=media_type, limit=limit)
        order = ["Images / Photos", "Movies / Videos", "TV Shows / Series", "Music / Albums", "eBooks", "Missing / Offline"]
        grouped: Dict[str, List[Dict[str, Any]]] = {k: [] for k in order}
        for r in rows:
            mtype = str(r.get("media_type") or "other")
            if not is_player_catalogue_type(mtype):
                continue
            if int(r.get("missing") or 0):
                grouped["Missing / Offline"].append(r)
                continue
            try:
                meta = json.loads(r.get("metadata_json") or "{}")
                lib = meta.get("library_metadata") or {}
            except Exception:
                lib = {}
            section = library_section_for_media(mtype, lib)
            if mtype == "image":
                section = "Images / Photos"
            if media_type == "tvshow" and section != "TV Shows / Series":
                continue
            grouped.setdefault(section, []).append(r)
        return {k: grouped[k] for k in order if grouped.get(k)}

    def duplicate_report_payload(self, mode: str = "hash", limit: int = 500) -> Dict[str, Any]:
        self.init()
        groups = self.duplicates(mode=mode, limit=limit)
        total_duplicate_items = 0
        potential_savings = 0
        for g in groups:
            items = g.get("items") or []
            if len(items) > 1:
                total_duplicate_items += len(items)
                sizes = [int(i.get("size_bytes") or 0) for i in items]
                potential_savings += max(0, sum(sizes) - max(sizes))
        return {
            "program": APP_NAME,
            "program_id": PROGRAM_ID,
            "version": VERSION,
            "report_type": "duplicate_report",
            "generated_at": utc_now(),
            "mode": mode,
            "group_count": len(groups),
            "duplicate_item_count": total_duplicate_items,
            "potential_savings_bytes_if_reviewed_and_one_kept": potential_savings,
            "warning": "Report only. Sentinel Media Index does not delete, move, rename, or alter source media.",
            "groups": groups,
            "local_only": True,
            "network_required": False,
        }

    def export_duplicate_report(self, output: Path, mode: str = "hash", limit: int = 500) -> Path:
        payload = self.duplicate_report_payload(mode=mode, limit=limit)
        output = _ensure_safe_output_path(output, role="report_output")
        if output.suffix.lower() in {".md", ".markdown"}:
            lines = [
                f"# Sentinel Media Index Duplicate Report",
                "",
                f"Generated: {payload['generated_at']}",
                f"Mode: {payload['mode']}",
                f"Duplicate groups: {payload['group_count']}",
                f"Duplicate items: {payload['duplicate_item_count']}",
                f"Potential space to review: {fmt_size(int(payload['potential_savings_bytes_if_reviewed_and_one_kept']))}",
                "",
                "> Report only. No files were changed.",
                "",
            ]
            for idx, g in enumerate(payload["groups"], 1):
                lines += [f"## Group {idx}: {g.get('key')}", f"Items: {g.get('count')}  |  Combined size: {fmt_size(int(g.get('total_size_bytes') or 0))}", ""]
                for item in g.get("items") or []:
                    lines.append(f"- `{item.get('path')}`")
                lines.append("")
            _safe_write_text(output, "\n".join(lines), role="report_output")
        else:
            _safe_write_text(output, json.dumps(payload, indent=2), role="report_output")
        return output

    def organisation_report_payload(self, query: str = "", media_type: str = "all", limit: int = 25) -> Dict[str, Any]:
        self.init()
        stats = self.stats()
        where_parts = []
        params: List[Any] = []
        if query:
            like = f"%{query}%"
            where_parts.append("(filename LIKE ? OR parent LIKE ? OR path LIKE ? OR notes LIKE ?)")
            params.extend([like, like, like, like])
        if media_type != "all":
            where_parts.append("media_type=?")
            params.append(media_type)
        where = " WHERE " + " AND ".join(where_parts) if where_parts else ""
        with self.connect() as conn:
            by_extension = [dict(r) for r in conn.execute(
                f"SELECT extension, media_type, COUNT(*) AS item_count, COALESCE(SUM(size_bytes),0) AS size_bytes FROM media_items{where} GROUP BY extension, media_type ORDER BY item_count DESC, size_bytes DESC LIMIT ?",
                params + [limit],
            ).fetchall()]
            by_folder = [dict(r) for r in conn.execute(
                f"SELECT parent, COUNT(*) AS item_count, COALESCE(SUM(size_bytes),0) AS size_bytes FROM media_items{where} GROUP BY parent ORDER BY size_bytes DESC, item_count DESC LIMIT ?",
                params + [limit],
            ).fetchall()]
            largest = [dict(r) for r in conn.execute(
                f"SELECT path, filename, media_type, size_bytes, duration_seconds, width, height, sha256, missing FROM media_items{where} ORDER BY size_bytes DESC LIMIT ?",
                params + [limit],
            ).fetchall()]
            missing = [dict(r) for r in conn.execute(
                f"SELECT path, filename, media_type, size_bytes FROM media_items{where + (' AND ' if where else ' WHERE ')} missing=1 ORDER BY filename COLLATE NOCASE LIMIT ?",
                params + [limit],
            ).fetchall()]
            playable_count = conn.execute(
                f"SELECT COUNT(*) FROM media_items{where + (' AND ' if where else ' WHERE ')} media_type IN ('audio','video','ebook') AND missing=0",
                params,
            ).fetchone()[0]
            untagged_count = conn.execute("""
                SELECT COUNT(*) FROM media_items mi
                LEFT JOIN media_tags mt ON mt.media_id=mi.id
                WHERE mt.media_id IS NULL AND mi.missing=0
            """).fetchone()[0]
            uncollected_count = conn.execute("""
                SELECT COUNT(*) FROM media_items mi
                LEFT JOIN collection_items ci ON ci.media_id=mi.id
                WHERE ci.media_id IS NULL AND mi.missing=0
            """).fetchone()[0]
        duplicate_hash = self.duplicate_report_payload(mode="hash", limit=limit)
        duplicate_name = self.duplicate_report_payload(mode="name_size", limit=limit)
        recommendations = []
        if stats.get("missing_items", 0):
            recommendations.append("Run Mark Missing, then review missing-file entries before rebuilding collections or player handoffs.")
        if duplicate_hash.get("group_count", 0):
            recommendations.append("Review hash duplicate groups manually; SMI will not delete or move any media.")
        if untagged_count:
            recommendations.append("Add tags to important family/media groups to improve AEGIS retrieval and future player playlists.")
        if uncollected_count:
            recommendations.append("Create collections for albums, family events, movies, music sets, and device-import batches.")
        if playable_count:
            recommendations.append("Export a Media Player handoff or M3U playlist for Program 119 playback testing.")
        return {
            "program": APP_NAME,
            "program_id": PROGRAM_ID,
            "version": VERSION,
            "report_type": "organisation_report",
            "generated_at": utc_now(),
            "query": query,
            "media_type": media_type,
            "stats": stats,
            "by_extension": by_extension,
            "largest_files": largest,
            "largest_folders": by_folder,
            "missing_sample": missing,
            "duplicate_summary": {
                "hash_groups": duplicate_hash.get("group_count", 0),
                "name_size_groups": duplicate_name.get("group_count", 0),
                "potential_hash_duplicate_savings_bytes": duplicate_hash.get("potential_savings_bytes_if_reviewed_and_one_kept", 0),
            },
            "tagging_summary": {"untagged_present_items": untagged_count, "uncollected_present_items": uncollected_count},
            "player_summary": {"playable_present_items": playable_count, "handoff_contract_version": "sentinel_media_player_handoff_v1"},
            "recommendations": recommendations,
            "safety": "Report only. No source media was changed.",
            "local_only": True,
            "network_required": False,
        }

    def export_organisation_report(self, output: Path, query: str = "", media_type: str = "all", limit: int = 25) -> Path:
        payload = self.organisation_report_payload(query=query, media_type=media_type, limit=limit)
        output = _ensure_safe_output_path(output, role="report_output")
        if output.suffix.lower() in {".md", ".markdown"}:
            lines = [
                "# Sentinel Media Index Organisation Report",
                "",
                f"Generated: {payload['generated_at']}",
                f"Query: {payload.get('query') or '(all)'}",
                f"Type: {payload.get('media_type')}",
                "",
                "## Summary",
                f"- Total items: {payload['stats'].get('total_items')}",
                f"- Present items: {payload['stats'].get('present_items')}",
                f"- Missing items: {payload['stats'].get('missing_items')}",
                f"- Total size: {fmt_size(int(payload['stats'].get('total_size_bytes') or 0))}",
                f"- Playable items: {payload['player_summary'].get('playable_present_items')}",
                "",
                "## Recommendations",
            ]
            lines += [f"- {r}" for r in payload.get("recommendations") or ["No immediate recommendations."]]
            lines += ["", "## Largest Folders"]
            for r in payload.get("largest_folders", []):
                lines.append(f"- {fmt_size(int(r.get('size_bytes') or 0))} • {r.get('item_count')} items • `{r.get('parent')}`")
            lines += ["", "## Largest Files"]
            for r in payload.get("largest_files", []):
                lines.append(f"- {fmt_size(int(r.get('size_bytes') or 0))} • {r.get('media_type')} • `{r.get('path')}`")
            lines += ["", "> Report only. No source media was changed.", ""]
            _safe_write_text(output, "\n".join(lines), role="report_output")
        else:
            _safe_write_text(output, json.dumps(payload, indent=2), role="report_output")
        return output

    def player_contract_payload(self) -> Dict[str, Any]:
        return {
            "program": APP_NAME,
            "program_id": PROGRAM_ID,
            "version": VERSION,
            "contract_type": "sentinel_media_player_contract",
            "contract_version": "sentinel_media_player_library_v2",
            "target_program": "119 Sentinel Media Player",
            "generated_at": utc_now(),
            "handoff_action": "sentinel-media-index --player-handoff OUTPUT --json",
            "playlist_action": "sentinel-media-index --m3u OUTPUT --json",
            "library_media_types": ["audio", "video", "ebook", "image"],
            "playable_media_types": ["audio", "video"],
            "tv_show_detection": "video items with series/season/episode metadata are presented under TV Shows / Series",
            "catalogue_source": "Sentinel Media Index by default",
            "presentation_model": "structured library + visual media cabinet",
            "item_fields": {
                "id": "SQLite media item id, local only",
                "path": "absolute local media path",
                "filename": "display filename",
                "media_type": "audio|video|ebook",
                "size_bytes": "integer file size",
                "duration_seconds": "optional duration",
                "codec": "optional codec",
                "container": "optional container/format",
                "thumbnail_path": "optional local thumbnail path",
                "cover_path": "optional local poster/album/book cover path from sidecar/artwork discovery",
                "poster_path": "optional video poster path",
                "title_synopsis_cast": "display metadata from embedded tags, sidecars, local artwork, or manual edits",
                "sha256": "optional file hash when scanned with --hash",
                "exists": "true when source path exists at handoff generation time",
                "playback_safe": "true when type is playable and file is not marked missing",
            },
            "safety": {
                "local_only": True,
                "network_required": False,
                "optional_online_metadata_enrichment": True,
                "online_metadata_requires_user_flag": "--allow-network",
                "online_sources": ["Open Library for eBooks", "MusicBrainz/Cover Art Archive for music", "OMDb for video when user supplies API key"],
                "source_media_mutation_allowed": False,
                "metadata_clean_edit_available_in_index": True,
                "metadata_write_requires_explicit_confirm": METADATA_CONFIRM_WORD,
                "player_may_read_paths": True,
                "player_may_modify_index": False,
            },
        }

    def _library_item_payload(self, row: Dict[str, Any]) -> Dict[str, Any]:
        try:
            meta = json.loads(row.get("metadata_json") or "{}")
        except Exception:
            meta = {}
        lib = meta.get("library_metadata") or {}
        mtype = str(row.get("media_type") or "other")
        section = lib.get("library_section") or library_section_for_media(mtype, lib)
        exists = Path(str(row.get("path") or "")).exists()
        cover = lib.get("poster_path") or lib.get("cover_path") or row.get("thumbnail_path") or ""
        return {
            "id": row.get("id"),
            "path": row.get("path"),
            "filename": row.get("filename"),
            "media_type": mtype,
            "library_section": section,
            "display": {
                "title": lib.get("title") or row.get("filename"),
                "sort_title": lib.get("sort_title") or str(lib.get("title") or row.get("filename") or "").lower(),
                "year": lib.get("year") or "",
                "synopsis": lib.get("synopsis") or lib.get("display_blurb") or "",
                "blurb": lib.get("display_blurb") or lib.get("synopsis") or "",
                "genre": lib.get("genre") or "",
                "duration_seconds": row.get("duration_seconds"),
                "codec": row.get("codec"),
                "container": row.get("container"),
            },
            "people": {
                "cast": lib.get("cast") or [],
                "director": lib.get("director") or "",
                "artist": lib.get("artist") or "",
                "album": lib.get("album") or "",
                "author": lib.get("author") or "",
                "series": lib.get("series") or "",
            },
            "artwork": {
                "thumbnail_path": row.get("thumbnail_path") or "",
                "cover_path": lib.get("cover_path") or "",
                "poster_path": lib.get("poster_path") or "",
                "cover_url": lib.get("cover_url") or "",
                "poster_url": lib.get("poster_url") or "",
                "primary_image": cover,
                "source": lib.get("artwork_source") or lib.get("online_provider") or ("generated_thumbnail" if row.get("thumbnail_path") else ""),
            },
            "media": {
                "size_bytes": row.get("size_bytes"),
                "sha256": row.get("sha256"),
                "width": row.get("width"),
                "height": row.get("height"),
                "exists": exists,
                "missing": bool(int(row.get("missing") or 0)),
                "playback_safe": mtype in {"audio", "video"} and exists and not int(row.get("missing") or 0),
            },
            "index": {
                "metadata_status": row.get("metadata_status") or "",
                "sidecar_paths": lib.get("sidecar_paths") or [],
                "online_enriched": bool(lib.get("online_enriched")),
                "online_provider": lib.get("online_provider") or "",
                "online_source_url": lib.get("online_source_url") or "",
                "indexed_at": row.get("indexed_at"),
                "last_seen_at": row.get("last_seen_at"),
            },
        }

    def player_library_payload(self, query: str = "", media_type: str = "all", collection: str = "") -> Dict[str, Any]:
        self.init()
        rows = self.collection_items(collection) if collection else self.search(query=query, media_type=media_type, limit=1000000)
        items = [self._library_item_payload(r) for r in rows if is_player_catalogue_type(str(r.get("media_type") or ""))]
        if media_type == "tvshow":
            items = [item for item in items if item.get("library_section") == "TV Shows / Series"]
        sections: Dict[str, List[Dict[str, Any]]] = {}
        for item in items:
            if not item["media"].get("exists") or item["media"].get("missing"):
                section = "Missing / Offline"
            else:
                section = str(item.get("library_section") or "Other Media")
            sections.setdefault(section, []).append(item)
        order = ["Movies / Videos", "TV Shows / Series", "Music / Albums", "Audiobooks", "eBooks", "Collections", "Recently Added", "Missing / Offline", "Duplicates / Needs Review"]
        structured = []
        for name in order + sorted(k for k in sections if k not in order):
            if name in sections:
                sorted_items = sorted(sections[name], key=lambda x: str(x.get("display", {}).get("sort_title") or ""))
                structured.append({"section": name, "count": len(sorted_items), "items": sorted_items})
        board_cards = []
        for item in items:
            disp = item.get("display", {})
            art = item.get("artwork", {})
            board_cards.append({
                "id": item.get("id"),
                "section": item.get("library_section"),
                "title": disp.get("title"),
                "subtitle": disp.get("year") or item.get("people", {}).get("artist") or item.get("people", {}).get("author") or "",
                "blurb": disp.get("blurb") or disp.get("synopsis") or "",
                "image": art.get("primary_image") or art.get("thumbnail_path") or "",
                "path": item.get("path"),
                "playback_safe": item.get("media", {}).get("playback_safe"),
            })
        return {
            "program": APP_NAME,
            "program_id": PROGRAM_ID,
            "version": VERSION,
            "handoff_type": "sentinel_media_player_structured_library",
            "handoff_contract_version": "sentinel_media_player_library_v2",
            "target_program": "119 Sentinel Media Player",
            "generated_at": utc_now(),
            "query": query,
            "media_type": media_type,
            "collection": collection,
            "count": len(items),
            "sections": structured,
            "visual_board": {
                "view_name": "Media Cabinet",
                "card_style": "poster_cover_tile",
                "cards": board_cards,
            },
            "source_of_truth": "Sentinel Media Index SQLite catalogue",
            "metadata_sources": ["embedded metadata", "local artwork files", "sidecar .nfo/.json/.xml/.txt", "manual Media Index edits", "automatic online enrichment during scans unless disabled plus manual one-off enrichment"],
            "local_first": True,
            "network_required": False,
            "online_enrichment_policy": "automatic during scans for audio/video/eBook unless --no-online-metadata/--offline; one-off enrichment still requires --allow-network",
        }


    def _fast_catalogue_item_payload(self, row: Dict[str, Any]) -> Dict[str, Any]:
        try:
            meta = json.loads(row.get("metadata_json") or "{}")
        except Exception:
            meta = {}
        lib = dict(meta.get("library_metadata") or {})
        mtype = str(row.get("media_type") or "other")
        path_text = str(row.get("path") or "")
        p = Path(path_text)
        exists = p.exists()
        missing = bool(int(row.get("missing") or 0))
        valid = bool(path_text and is_player_catalogue_type(mtype) and exists and not missing and not is_system_asset_path(p) and not is_incomplete_download_path(p))
        category = player_category_for_item(mtype, lib, p)
        primary_art = primary_artwork_from_lib(row, lib)
        rename_info = movie_rename_target_for_row(row) if mtype == "video" else {"rename_status": "not_applicable"}
        title = str(lib.get("title") or rename_info.get("title") or row.get("filename") or p.stem)
        display_title = str(lib.get("display_title") or title)
        return {
            "id": row.get("id"),
            "path": path_text,
            "uri": f"file://{urllib.parse.quote(path_text)}" if path_text else "",
            "filename": row.get("filename") or p.name,
            "media_type": mtype,
            "category": category,
            "library_section": lib.get("library_section") or library_section_for_media(mtype, lib),
            "title": title,
            "sort_title": lib.get("sort_title") or title.lower().removeprefix("the ").strip(),
            "display_title": display_title,
            "clean_title": rename_info.get("title") or title,
            "rename_status": lib.get("rename_status") or rename_info.get("rename_status") or "unknown",
            "rename_suggested_path": rename_info.get("proposed_path") if rename_info.get("would_change") else "",
            "metadata_confidence": rename_info.get("confidence") or "",
            "year": lib.get("year") or rename_info.get("year") or "",
            "artist": lib.get("artist") or "",
            "album": lib.get("album") or "",
            "author": lib.get("author") or "",
            "series": lib.get("series") or "",
            "season": lib.get("season") or "",
            "episode": lib.get("episode") or "",
            "genre": lib.get("genre") or "",
            "description": lib.get("synopsis") or lib.get("display_blurb") or "",
            "duration_seconds": row.get("duration_seconds"),
            "duration": row.get("duration_seconds"),
            "width": row.get("width"),
            "height": row.get("height"),
            "resolution": f"{row.get('width')}x{row.get('height')}" if row.get("width") and row.get("height") else "",
            "codec": row.get("codec") or "",
            "container": row.get("container") or "",
            "size_bytes": row.get("size_bytes"),
            "sha256": row.get("sha256") or "",
            "thumbnail_path": row.get("thumbnail_path") or lib.get("thumbnail_path") or "",
            "poster_path": lib.get("poster_path") or "",
            "cover_path": lib.get("cover_path") or "",
            "album_art_path": lib.get("album_art_path") or lib.get("cover_path") or "",
            "artwork_path": primary_art,
            "fanart_path": lib.get("fanart_path") or "",
            "metadata_source": "Sentinel Media Index",
            "metadata_provider": lib.get("online_provider") or "local",
            "metadata_status": row.get("metadata_status") or meta.get("metadata_status") or "",
            "metadata_enriched_at": (meta.get("online_metadata") or [{}])[-1].get("looked_up_at", "") if isinstance(meta.get("online_metadata"), list) and meta.get("online_metadata") else "",
            "metadata_cached": bool(primary_art or row.get("thumbnail_path")),
            "rating": lib.get("rating") or "",
            "director": lib.get("director") or "",
            "cast": lib.get("cast") or [],
            "creator": lib.get("author") or lib.get("artist") or "",
            "indexed_at": row.get("indexed_at"),
            "last_seen_at": row.get("last_seen_at"),
            "exists": exists,
            "missing": missing,
            "is_valid_user_media": valid,
            "playback_safe": mtype in {"audio", "video"} and valid,
            "open_external": mtype in {"ebook", "image"} and valid,
            "source_db": str(self.db_path),
        }

    def player_fast_catalogue_payload(self, query: str = "", media_type: str = "all", collection: str = "") -> Dict[str, Any]:
        self.init()
        rows = self.collection_items(collection) if collection else self.search(query=query, media_type=media_type, limit=1000000)
        raw_items = [self._fast_catalogue_item_payload(r) for r in rows if is_player_catalogue_type(str(r.get("media_type") or ""))]
        items = [i for i in raw_items if i.get("is_valid_user_media")]
        categories: Dict[str, int] = {}
        artwork_count = 0
        for item in items:
            categories[str(item.get("category") or "Unsorted")] = categories.get(str(item.get("category") or "Unsorted"), 0) + 1
            if item.get("artwork_path") or item.get("thumbnail_path") or item.get("poster_path") or item.get("cover_path"):
                artwork_count += 1
        return {
            "program": APP_NAME,
            "program_id": PROGRAM_ID,
            "version": VERSION,
            "handoff_type": PLAYER_FAST_CONTRACT_VERSION,
            "contract_version": PLAYER_FAST_CONTRACT_VERSION,
            "target_program": "119 Sentinel Media Player",
            "generated_at": utc_now(),
            "source_of_truth": "Sentinel Media Index",
            "source_db": str(self.db_path),
            "query": query,
            "media_type": media_type,
            "collection": collection,
            "raw_count": len(raw_items),
            "count": len(items),
            "artwork_item_count": artwork_count,
            "categories": categories,
            "items": sorted(items, key=lambda x: (str(x.get("category") or ""), str(x.get("sort_title") or ""))),
            "player_contract": {
                "reader": "fast_flat_json",
                "no_schema_guessing_required": True,
                "player_should_not_scan_sqlite_when_this_file_exists": True,
                "media_index_owns_metadata_and_artwork": True,
                "artwork_fields": ["artwork_path", "poster_path", "cover_path", "album_art_path", "thumbnail_path"],
            },
            "local_first": True,
            "network_required": False,
        }

    def export_player_fast_catalogue(self, output: Optional[Path] = None, query: str = "", media_type: str = "all", collection: str = "") -> Path:
        payload = self.player_fast_catalogue_payload(query=query, media_type=media_type, collection=collection)
        targets = [Path(output).expanduser()] if output else [PLAYER_FAST_CATALOGUE_PATH, PLAYER_FAST_CATALOGUE_ALT_PATH]
        first = targets[0]
        for target in targets:
            target = _ensure_safe_output_path(target, role="player_fast_catalogue")
            _safe_write_text(target, json.dumps(payload, indent=2, sort_keys=True), role="player_fast_catalogue")
        return first

    def player_fast_catalogue_status(self) -> Dict[str, Any]:
        payload = self.player_fast_catalogue_payload()
        return {
            "ok": True,
            "program": APP_NAME,
            "version": VERSION,
            "contract_version": PLAYER_FAST_CONTRACT_VERSION,
            "default_path": str(PLAYER_FAST_CATALOGUE_PATH),
            "alt_path": str(PLAYER_FAST_CATALOGUE_ALT_PATH),
            "count": payload.get("count"),
            "raw_count": payload.get("raw_count"),
            "artwork_item_count": payload.get("artwork_item_count"),
            "categories": payload.get("categories"),
            "source_db": str(self.db_path),
            "player_should_prefer": "player_catalogue.json",
        }

    def export_player_library(self, output: Path, query: str = "", media_type: str = "all", collection: str = "") -> Path:
        output = _ensure_safe_output_path(output, role="player_library_export")
        _safe_write_text(output, json.dumps(self.player_library_payload(query=query, media_type=media_type, collection=collection), indent=2), role="player_library_export")
        return output

    def export_player_contract(self, output: Path) -> Path:
        output = _ensure_safe_output_path(output, role="player_contract_export")
        _safe_write_text(output, json.dumps(self.player_contract_payload(), indent=2), role="player_contract_export")
        return output

    def export_player_handoff(self, output: Path, query: str = "", media_type: str = "all", collection: str = "") -> Path:
        self.init()
        rows = self.collection_items(collection) if collection else self.search(query=query, media_type=media_type, limit=1000000)
        playable = [r for r in rows if r.get("media_type") in {"audio", "video"} and not int(r.get("missing") or 0)]
        output = _ensure_safe_output_path(output, role="player_handoff_export")
        by_type: Dict[str, int] = {}
        for r in playable:
            by_type[str(r.get("media_type") or "other")] = by_type.get(str(r.get("media_type") or "other"), 0) + 1
        payload = {
            "program": APP_NAME,
            "program_id": PROGRAM_ID,
            "version": VERSION,
            "handoff_type": "sentinel_media_player_library",
            "handoff_contract_version": "sentinel_media_player_handoff_v1",
            "target_program": "119 Sentinel Media Player",
            "generated_at": utc_now(),
            "query": query,
            "media_type": media_type,
            "collection": collection,
            "count": len(playable),
            "by_type": by_type,
            "items": [{
                "id": r.get("id"),
                "path": r.get("path"),
                "filename": r.get("filename"),
                "media_type": r.get("media_type"),
                "size_bytes": r.get("size_bytes"),
                "duration_seconds": r.get("duration_seconds"),
                "codec": r.get("codec"),
                "container": r.get("container"),
                "thumbnail_path": r.get("thumbnail_path"),
                "library_item": self._library_item_payload(r),
                "sha256": r.get("sha256"),
                "exists": Path(str(r.get("path") or "")).exists(),
                "playback_safe": r.get("media_type") in {"audio", "video"} and not int(r.get("missing") or 0),
            } for r in playable],
            "contract": self.player_contract_payload(),
            "local_first": True,
            "network_required": False,
            "online_enrichment_policy": "Player handoff may include previously cached online metadata/artwork from Media Index; export itself performs no network calls.",
        }
        _safe_write_text(output, json.dumps(payload, indent=2), role="player_handoff_export")
        return output

    def export_m3u(self, output: Path, query: str = "", media_type: str = "all", collection: str = "") -> Path:
        self.init()
        rows = self.collection_items(collection) if collection else self.search(query=query, media_type=media_type, limit=1000000)
        playable = [r for r in rows if r.get("media_type") in {"audio", "video"} and not int(r.get("missing") or 0)]
        output = _ensure_safe_output_path(output, role="m3u_export")
        lines = ["#EXTM3U", f"# Sentinel Media Index v{VERSION} export", f"# Generated {utc_now()}"]
        for r in playable:
            dur = int(float(r.get("duration_seconds") or -1))
            lines.append(f"#EXTINF:{dur},{r.get('filename','')}")
            lines.append(str(r.get("path")))
        _safe_write_text(output, "\n".join(lines) + "\n", role="m3u_export")
        return output


def scan_directory(
    root: Path,
    hash_enabled: bool = False,
    follow_symlinks: bool = False,
    db: Optional[MediaIndexDB] = None,
    extract_metadata: bool = False,
    thumbnails: bool = False,
    save_report: bool = True,
    include_assets: bool = False,
    auto_online_metadata: bool = True,
    online_provider: str = "auto",
    omdb_api_key: str = "",
    download_online_artwork: bool = True,
    cancel_event: Optional[threading.Event] = None,
) -> Dict[str, Any]:
    db = db or MediaIndexDB()
    db.init()
    root = root.expanduser()
    root_str = safe_realpath(root)
    # Default scan root policy: only exact approved media folders are indexed.
    # No broad /home, $HOME, or whole-user-folder walking is performed.
    root_allowed_context = include_assets or can_reach_default_media_root(root)
    if not root_allowed_context:
        return {
            "ok": False,
            "error": "scan_root_blocked_by_policy",
            "root_path": root_str,
            "media_indexed": 0,
            "files_seen": 0,
            "errors": 0,
            "skipped_disallowed_roots": 1,
            "cancelled": False,
            "policy": "Scan Default Files only scans ~/Documents/eBooks, ~/Videos/Movies, ~/Videos/TV Shows, ~/Pictures, approved named external media folders, and exact manual batch locations. No /home scan.",
            "default_root_policy": default_root_policy_report(),
        }
    scan_id = db.start_scan(root_str, hash_enabled)
    files_seen = 0
    media_indexed = 0
    errors = 0
    thumbnails_generated = 0
    metadata_enriched = 0
    online_metadata_attempted = 0
    online_metadata_success = 0
    online_metadata_failed = 0
    online_metadata_errors: List[Dict[str, str]] = []
    type_counts: Dict[str, int] = {}
    skipped_non_media = 0
    skipped_assets = 0
    skipped_support_artwork = 0
    skipped_disallowed_roots = 0
    skipped_symlinks = 0
    cancelled = False
    started = time.time()
    for dirpath, dirnames, filenames in os.walk(root_str, followlinks=follow_symlinks):
        if cancel_event is not None and cancel_event.is_set():
            cancelled = True
            break
        current_dir = Path(dirpath)
        if not include_assets and not can_reach_default_media_root(current_dir):
            skipped_disallowed_roots += len(filenames)
            dirnames[:] = []
            continue
        # Default to user media libraries only. Keep OS/application icons, themes,
        # cache thumbnails, and generic asset folders out unless explicitly requested.
        kept_dirs = []
        for d in dirnames:
            candidate = Path(dirpath) / d
            if candidate.is_symlink() and not follow_symlinks:
                skipped_symlinks += 1
                continue
            if not include_assets and not can_reach_default_media_root(candidate):
                skipped_disallowed_roots += 1
                continue
            if not include_assets and is_system_asset_path(candidate):
                skipped_assets += 1
                continue
            kept_dirs.append(d)
        dirnames[:] = kept_dirs
        for name in filenames:
            if cancel_event is not None and cancel_event.is_set():
                cancelled = True
                break
            p = Path(dirpath) / name
            files_seen += 1
            try:
                if p.is_symlink() and not follow_symlinks:
                    skipped_symlinks += 1
                    continue
                if _path_has_symlink_component(p) and not follow_symlinks:
                    skipped_symlinks += 1
                    continue
                if not include_assets and not is_in_default_media_roots(p):
                    skipped_disallowed_roots += 1
                    continue
                if not include_assets and is_system_asset_path(p):
                    skipped_assets += 1
                    continue
                if not include_assets and is_artwork_support_file(p):
                    skipped_support_artwork += 1
                    continue
                if not is_media_file(p):
                    skipped_non_media += 1
                    continue
                st = p.stat()
                sha = sha256_file(p) if hash_enabled else None
                mime, _enc = mimetypes.guess_type(str(p))
                mtype = media_type_for(p)
                meta = extract_media_metadata(p, mtype) if extract_metadata else {"metadata_status": "not_requested"}
                thumb = generate_thumbnail(p, mtype) if thumbnails else None
                if thumb:
                    thumbnails_generated += 1
                if meta.get("metadata_status") not in {None, "", "not_requested"}:
                    metadata_enriched += 1
                type_counts[mtype] = type_counts.get(mtype, 0) + 1
                rec = MediaRecord(
                    path=safe_realpath(p),
                    parent=safe_realpath(p.parent),
                    filename=p.name,
                    extension=p.suffix.lower(),
                    media_type=mtype,
                    mime_guess=mime or "",
                    size_bytes=int(st.st_size),
                    mtime=float(st.st_mtime),
                    sha256=sha,
                    width=meta.get("width"),
                    height=meta.get("height"),
                    duration_seconds=meta.get("duration_seconds"),
                    codec=str(meta.get("codec") or ""),
                    container=str(meta.get("container") or ""),
                    thumbnail_path=thumb or "",
                    metadata_json=json.dumps(meta, sort_keys=True),
                    metadata_status=str(meta.get("metadata_status") or ""),
                    indexed_at=utc_now(),
                )
                db.upsert_media(rec)
                if auto_online_metadata and mtype in {"audio", "video", "ebook"}:
                    online_metadata_attempted += 1
                    try:
                        enrich = db.online_enrich_path(p, provider=online_provider, allow_network=True, omdb_api_key=omdb_api_key, download_artwork=download_online_artwork)
                        if enrich.get("ok"):
                            online_metadata_success += 1
                        else:
                            online_metadata_failed += 1
                            if len(online_metadata_errors) < 20:
                                online_metadata_errors.append({"path": str(p), "provider": str(enrich.get("provider") or "auto"), "error": str(enrich.get("error") or "not_enriched")})
                    except Exception as exc:
                        online_metadata_failed += 1
                        if len(online_metadata_errors) < 20:
                            online_metadata_errors.append({"path": str(p), "provider": online_provider, "error": f"{type(exc).__name__}: {str(exc)[:180]}"})
                media_indexed += 1
            except Exception as exc:  # keep scanning other files
                errors += 1
                db.log_error(scan_id, str(p), f"{type(exc).__name__}: {exc}")
    db.finish_scan(scan_id, files_seen, media_indexed, errors)
    result = {
        "scan_id": scan_id,
        "root_path": root_str,
        "hash_enabled": hash_enabled,
        "metadata_enabled": extract_metadata,
        "thumbnails_enabled": thumbnails,
        "auto_online_metadata_enabled": auto_online_metadata,
        "online_metadata_provider": online_provider,
        "files_seen": files_seen,
        "media_indexed": media_indexed,
        "skipped_non_media": skipped_non_media,
        "skipped_system_assets": skipped_assets,
        "skipped_support_artwork": skipped_support_artwork,
        "skipped_disallowed_roots": skipped_disallowed_roots,
        "skipped_symlinks": skipped_symlinks,
        "default_root_policy": default_root_policy_report(),
        "default_system_assets_excluded": not include_assets,
        "errors": errors,
        "type_counts": type_counts,
        "metadata_enriched": metadata_enriched,
        "thumbnails_generated": thumbnails_generated,
        "online_metadata_attempted": online_metadata_attempted,
        "online_metadata_success": online_metadata_success,
        "online_metadata_failed": online_metadata_failed,
        "online_metadata_errors": online_metadata_errors,
        "duration_seconds": round(time.time() - started, 3),
        "cancelled": cancelled,
        "db_path": str(db.db_path),
    }
    try:
        fast_path = db.export_player_fast_catalogue()
        result["player_fast_catalogue_path"] = str(fast_path)
        result["player_fast_catalogue_contract"] = PLAYER_FAST_CONTRACT_VERSION
    except Exception as exc:
        result["player_fast_catalogue_error"] = f"{type(exc).__name__}: {str(exc)[:180]}"
    if save_report:
        if _path_has_symlink_component(REPORT_ROOT):
            raise RuntimeError(f"unsafe_report_root_symlink:{REPORT_ROOT}")
        REPORT_ROOT.mkdir(parents=True, exist_ok=True)
        report_path = _ensure_safe_output_path(REPORT_ROOT / f"scan_{scan_id}_{_dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.json", role="scan_report")
        _safe_write_text(report_path, json.dumps(result, indent=2), role="scan_report")
        result["scan_report_path"] = str(report_path)
    return result


def readiness_report(db: Optional[MediaIndexDB] = None) -> Dict[str, Any]:
    db = db or MediaIndexDB()
    db.init()
    deps = {
        "python3": sys.version.split()[0],
        "tkinter": False,
        "sqlite3": sqlite3.sqlite_version,
        "ffprobe_optional": shutil.which("ffprobe") is not None,
        "pillow_optional": pil_available(),
        "exiftool_optional": shutil.which("exiftool") is not None,
        "online_metadata_optional": True,
        "online_metadata_default": "automatic_for_scan_unless_disabled",
    }
    try:
        import tkinter  # noqa: F401
        deps["tkinter"] = True
    except Exception:
        deps["tkinter"] = False
    stats = db.stats()
    ready = deps["tkinter"] and Path(DB_PATH).parent.exists()
    return {
        "program": APP_NAME,
        "program_id": PROGRAM_ID,
        "version": VERSION,
        "status": "stable_locked" if ready else "degraded",
        "baseline": "v1_stable_locked",
        "capabilities": [
            "local_media_scan",
            "sqlite_media_catalogue",
            "audio_video_tvshow_ebook_collection_only_default_catalogue",
            "media_only_default_scan_policy",
            "system_icons_assets_cover_art_and_sidecars_not_catalogued_by_default",
            "optional_sha256_hash_index",
            "duplicate_detection_hash_or_name_size",
            "csv_json_export",
            "database_backup",
            "aegis_status_json",
            "optional_thumbnail_generation",
            "local_preview_metadata",
            "optional_ffprobe_audio_video_metadata",
            "image_dimension_metadata",
            "scan_report_json",
            "categorized_search_results",
            "tags_and_collections",
            "media_player_handoff_json",
            "m3u_playlist_export",
            "advanced_duplicate_reports",
            "media_organisation_reports",
            "sentinel_media_player_contract_v1",
            "player_handoff_contract_hardening",
            "thumbnail_search_results",
            "backend_metadata_cleaner",
            "metadata_editor_gui",
            "guarded_metadata_write_actions",
            "dashboard_summary_cards",
            "visual_scan_feedback",
            "thumbnail_search_bugfix",
            "file_manager_context_metadata_actions",
            "caja_right_click_scripts",
            "per_user_caja_script_installer",
            "system_caja_script_templates",
            "gui_context_autofill_metadata",
            "aegis_context_action_contracts",
            "gui_enter_confirm_hotkeys",
            "ctrl_q_close",
            "larger_default_window",
            "expanded_preview_panel",
            "metadata_batch_clean_plan",
            "metadata_backup_review",
            "guarded_metadata_backup_restore",
            "theme_matched_entry_fields",
            "theme_matched_dropdown_menus",
            "taller_default_window",
            "larger_preview_window",
            "live_library_hardening",
            "v1_stable_lock",
            "program_118_stable_baseline",
            "thumb_column_header_fit",
            "v1_readiness_candidate",
            "player_structured_library_v2",
            "visual_media_cabinet_contract",
            "compact_search_category_rows",
            "smaller_search_thumbnails",
            "automatic_online_metadata_enrichment",
            "online_enriched_player_exports",
            "online_metadata_offline_opt_out",
            "local_cover_poster_album_art_discovery_as_enrichment_not_library_items",
            "sidecar_synopsis_cast_metadata_import",
        ],
        "dependencies": deps,
        "stats": stats,
        "ui_readiness": {
            "default_window": "1420x980",
            "minimum_window": "1160x800",
            "themed_inputs": True,
            "themed_dropdowns": True,
            "expanded_preview": True,
            "thumb_column_width": 76,
            "compact_search_rows": True,
        },
        "local_only": True,
        "network_required": False,
        "telemetry": False,
        "final_audit_ready": True,
        "stable_lock": True,
        "stable_lock_report_ready": True,
        "stable_lock_next_step": "maintenance patch only unless live-library testing finds a blocker",
        "generated_at": utc_now(),
    }


def aegis_actions() -> Dict[str, Any]:
    return {
        "program": APP_NAME,
        "program_id": PROGRAM_ID,
        "version": VERSION,
        "actions": {
            "status": {"command": "sentinel-media-index --aegis-status", "safe": True},
            "readiness": {"command": "sentinel-media-index --readiness", "safe": True},
            "final_audit": {"command": "sentinel-media-index --final-audit OUTPUT --json", "safe": True, "notes": "Generates final v1 readiness/audit report without modifying media files."},
            "stable_lock_report": {"command": "sentinel-media-index --stable-lock-report OUTPUT --json", "safe": True, "notes": "Generates the Program 118 v1.0.0 stable-lock declaration without modifying media files."},
            "stats": {"command": "sentinel-media-index --stats --json", "safe": True},
            "scan": {"command": "sentinel-media-index --scan PATH --json", "safe": True, "network_default": "automatic metadata enrichment for audio/video/ebook unless --no-online-metadata/--offline", "notes": "Indexes user images/photos, audio, video/TV, and eBook library files by default; system icons/assets are excluded and cover art/sidecars enrich entries without becoming clutter."},
            "scan_rich": {"command": "sentinel-media-index --scan PATH --metadata --thumbnails --json", "safe": True, "notes": "Indexes metadata and generates local thumbnails for images/photos, audio, video/TV and eBook library entries; does not modify source media; excludes system icons/assets and does not catalogue cover art/sidecars as clutter."},
            "online_metadata_plan": {"command": "sentinel-media-index --online-metadata-plan FILE --json", "safe": True, "network_required": False, "notes": "Builds an AEGIS-readable online enrichment plan without contacting the network."},
            "online_metadata_enrich": {"command": "sentinel-media-index --online-metadata FILE --allow-network --online-provider auto --json", "safe": True, "network_required": True, "notes": "One-off enrichment for covers/blurbs/cast/album/book details; scans enrich automatically unless disabled; updates index only and feeds player-library/visual-board exports."},
            "preview": {"command": "sentinel-media-index --preview FILE --json", "safe": True},
            "metadata_read": {"command": "sentinel-media-index --metadata-read FILE --json", "safe": True},
            "metadata_clean_plan": {"command": "sentinel-media-index --metadata-clean FILE --json", "safe": True, "notes": "Dry-run metadata cleaner plan; does not modify without --execute --confirm MODIFY_METADATA."},
            "metadata_clean_execute_guarded": {"command": "sentinel-media-index --metadata-clean FILE --execute --confirm MODIFY_METADATA --json", "safe": False, "guarded": True, "notes": "Can modify embedded metadata using exiftool; backup-first where supported."},
            "metadata_edit_execute_guarded": {"command": "sentinel-media-index --metadata-edit FILE --set title=VALUE --execute --confirm MODIFY_METADATA --json", "safe": False, "guarded": True, "notes": "Can edit embedded metadata using exiftool; backup-first where supported."},
            "metadata_batch_clean_plan": {"command": "sentinel-media-index --metadata-batch-clean PATH --json", "safe": True, "notes": "Review-only batch metadata clean plan; no source writes."},
            "metadata_backup_review": {"command": "sentinel-media-index --metadata-backup-review PATH --json", "safe": True, "notes": "Lists ExifTool FILE_original backups for review."},
            "metadata_restore_backup_guarded": {"command": "sentinel-media-index --metadata-restore-backup FILE_original --execute --confirm RESTORE_METADATA_BACKUP --json", "safe": False, "guarded": True, "notes": "Restores one ExifTool backup over its paired file only after explicit confirmation."},
            "context_read_metadata": {"command": "sentinel-media-index --context-read-metadata FILE", "safe": True, "notes": "MATE/Caja file-manager context action. Opens GUI with selected file metadata loaded."},
            "context_clean_metadata": {"command": "sentinel-media-index --context-clean-metadata FILE", "safe": "launches GUI dry-run plan; source write still requires GUI confirmation and ExifTool"},
            "context_edit_metadata": {"command": "sentinel-media-index --context-edit-metadata FILE", "safe": "launches GUI editor; source write still requires confirmation MODIFY_METADATA"},
            "context_action_info": {"command": "sentinel-media-index --context-action-info read:FILE --json", "safe": True, "notes": "AEGIS-readable report for file-manager context metadata actions."},
            "install_caja_scripts": {"command": "sentinel-media-index --install-caja-scripts", "safe": True, "notes": "Installs per-user Caja right-click Scripts submenu actions for Read/Clean/Edit Metadata."},
            "reindex_file_metadata": {"command": "sentinel-media-index --reindex-file FILE --thumbnails --json", "safe": True},
            "categorized_search": {"command": "sentinel-media-index --search QUERY --categorized --json", "safe": True},
            "tag_add": {"command": "sentinel-media-index --tag-file PATH --tag-name TAG --json", "safe": True},
            "collections": {"command": "sentinel-media-index --list-collections --json", "safe": True},
            "player_handoff": {"command": "sentinel-media-index --player-handoff OUTPUT --json", "safe": True, "notes": "Exports local JSON handoff for Program 119 Sentinel Media Player."},
            "player_library": {"command": "sentinel-media-index --player-library OUTPUT --json", "safe": True, "notes": "Exports structured user-readable library sections and visual board/card data for Program 119."},
            "visual_board": {"command": "sentinel-media-index --visual-board OUTPUT --json", "safe": True, "notes": "Exports poster/cover tile board data for Media Player cabinet view."},
            "m3u_export": {"command": "sentinel-media-index --m3u OUTPUT", "safe": True},
            "duplicates": {"command": "sentinel-media-index --duplicates --mode hash --json", "safe": True},
            "duplicate_report": {"command": "sentinel-media-index --duplicate-report OUTPUT --mode hash --json", "safe": True, "notes": "Report only; does not alter media."},
            "organisation_report": {"command": "sentinel-media-index --organisation-report OUTPUT --json", "safe": True, "notes": "Media-library organisation report only; does not move/delete/rename media."},
            "player_contract": {"command": "sentinel-media-index --player-contract OUTPUT --json", "safe": True, "notes": "Exports Program 119 Media Player handoff contract."},
            "export_csv": {"command": "sentinel-media-index --export-csv OUTPUT", "safe": True},
            "backup": {"command": "sentinel-media-index --backup --json", "safe": True},
        },
        "ui_readiness": {
            "default_window": "1420x980",
            "minimum_window": "1160x800",
            "themed_inputs": True,
            "themed_dropdowns": True,
            "expanded_preview": True,
            "thumb_column_width": 76,
            "compact_search_rows": True,
        },
        "local_only": True,
        "generated_at": utc_now(),
    }


def _audit_check(name: str, ok: bool, detail: str, severity: str = "required") -> Dict[str, Any]:
    return {"name": name, "ok": bool(ok), "severity": severity, "detail": detail}


def final_audit_report(db: Optional[MediaIndexDB] = None, output: Optional[Path] = None) -> Dict[str, Any]:
    """Generate a non-mutating v1-readiness audit report.

    This is intentionally a report-only gate. It does not scan, enrich online
    metadata, modify metadata, move files, or touch source media.
    """
    db = db or MediaIndexDB()
    db.init()
    readiness = readiness_report(db)
    actions = aegis_actions()
    stats = db.stats()
    deps = readiness.get("dependencies", {})
    caps = set(readiness.get("capabilities", []))
    player_payload = db.player_library_payload(query="", media_type="all", collection="")
    visual_board = player_payload.get("visual_board", {})
    checks = [
        _audit_check("python_available", bool(deps.get("python3")), f"python={deps.get('python3', '')}"),
        _audit_check("tkinter_available", bool(deps.get("tkinter")), "Required for GUI launch."),
        _audit_check("sqlite_catalogue_ready", Path(str(stats.get("db_path"))).parent.exists(), str(stats.get("db_path"))),
        _audit_check("local_first_posture", readiness.get("local_only") is True and readiness.get("telemetry") is False, "No Sentinel telemetry; normal exports do not require network."),
        _audit_check("automatic_online_metadata_visible", "automatic_online_metadata_enrichment" in caps, "Automatic online metadata is declared and can be disabled with --no-online-metadata/--offline."),
        _audit_check("offline_opt_out_present", "online_metadata_offline_opt_out" in caps, "Offline/no-online scan opt-outs are part of the AEGIS contract."),
        _audit_check("system_asset_exclusion_present", "system_icons_assets_cover_art_and_sidecars_not_catalogued_by_default" in caps, "System icons/assets and standalone support artwork are excluded from default library clutter."),
        _audit_check("images_photos_supported", "image" in SCAN_TYPE_CHOICES, "User photos/images remain searchable while desktop/system assets are excluded."),
        _audit_check("media_player_library_contract", player_payload.get("handoff_contract_version") == "sentinel_media_player_library_v2", str(player_payload.get("handoff_contract_version"))),
        _audit_check("visual_board_contract", isinstance(visual_board.get("cards", []), list), "Visual-board Media Cabinet export is available for Program 119."),
        _audit_check("guarded_metadata_writes", "guarded_metadata_write_actions" in caps and "guarded_metadata_backup_restore" in caps, "Metadata clean/edit/restore writes require explicit guards."),
        _audit_check("caja_context_actions", "file_manager_context_metadata_actions" in caps, "MATE/Caja right-click metadata actions are available."),
        _audit_check("aegis_actions_ready", "final_audit" in actions.get("actions", {}) and "status" in actions.get("actions", {}), "AEGIS status/readiness/final audit actions are exposed."),
        _audit_check("package_optional_deps_declared", True, "Optional rich backends: python3-pil, ffmpeg, libimage-exiftool-perl, caja." , "advisory"),
    ]
    required = [c for c in checks if c.get("severity") == "required"]
    passed_required = sum(1 for c in required if c.get("ok"))
    failed_required = [c for c in required if not c.get("ok")]
    result = {
        "program": APP_NAME,
        "program_id": PROGRAM_ID,
        "version": VERSION,
        "audit_type": "v1_readiness_final_audit",
        "status": "pass" if not failed_required else "needs_attention",
        "v1_stable_lock_candidate": not failed_required,
        "stable_lock_recommendation": "ready_for_v1_0_0_stable_lock" if not failed_required else "patch_failed_required_checks_before_v1_lock",
        "summary": {
            "required_checks_passed": passed_required,
            "required_checks_total": len(required),
            "failed_required_checks": [c["name"] for c in failed_required],
            "indexed_items": stats.get("total_items", 0),
            "present_items": stats.get("present_items", 0),
            "media_types": stats.get("by_type", {}),
            "player_library_items": player_payload.get("count", 0),
            "visual_board_cards": len(visual_board.get("cards", [])),
        },
        "checks": checks,
        "readiness": readiness,
        "player_contract_probe": {
            "handoff_contract_version": player_payload.get("handoff_contract_version"),
            "sections": [{"section": s.get("section"), "count": s.get("count")} for s in player_payload.get("sections", [])],
            "visual_board_card_count": len(visual_board.get("cards", [])),
        },
        "safety_doctrine": {
            "source_media_mutation_default": False,
            "metadata_clean_edit_requires_guard": "MODIFY_METADATA",
            "metadata_backup_restore_requires_guard": "RESTORE_METADATA_BACKUP",
            "online_enrichment_modifies_source_media": False,
            "online_enrichment_updates_local_catalogue": True,
            "telemetry": False,
        },
        "next_step": "Promote to Sentinel Media Index v1.0.0 stable lock if live-library testing accepts this audit.",
        "generated_at": utc_now(),
    }
    if output:
        output = _ensure_safe_output_path(output, role="report_output")
        if output.suffix.lower() in {".md", ".markdown"}:
            lines = [
                f"# {APP_NAME} v{VERSION} Final Audit",
                "",
                f"- Status: **{result['status']}**",
                f"- V1 stable-lock candidate: **{result['v1_stable_lock_candidate']}**",
                f"- Required checks: **{passed_required}/{len(required)}**",
                f"- Indexed items: **{stats.get('total_items', 0)}**",
                f"- Player library items: **{player_payload.get('count', 0)}**",
                f"- Visual board cards: **{len(visual_board.get('cards', []))}**",
                "",
                "## Checks",
            ]
            for c in checks:
                mark = "PASS" if c.get("ok") else "FAIL"
                lines.append(f"- **{mark}** `{c['name']}` — {c['detail']}")
            lines.extend(["", "## Safety Doctrine", "", "- No source-media mutation by default.", "- Metadata clean/edit requires `MODIFY_METADATA`.", "- Metadata backup restore requires `RESTORE_METADATA_BACKUP`.", "- Online enrichment updates the local catalogue only.", "- No Sentinel telemetry.", "", f"Generated: `{result['generated_at']}`", ""])
            _safe_write_text(output, "\n".join(lines), role="final_audit_report")
        else:
            _safe_write_text(output, json.dumps(result, indent=2), role="final_audit_report")
        result["output"] = str(output)
    return result


def print_json(obj: Any) -> None:
    print(json.dumps(obj, indent=2, sort_keys=False))


def fmt_size(n: int) -> str:
    units = ["B", "KB", "MB", "GB", "TB", "PB"]
    f = float(n)
    for u in units:
        if f < 1024 or u == units[-1]:
            return f"{f:.1f} {u}" if u != "B" else f"{int(f)} B"
        f /= 1024
    return f"{n} B"



def stable_lock_report(db: Optional[MediaIndexDB] = None, output: Optional[Path] = None) -> Dict[str, Any]:
    """Generate the official non-mutating Program 118 v1.0.0 stable-lock declaration."""
    db = db or MediaIndexDB()
    db.init()
    readiness = readiness_report(db)
    audit = final_audit_report(db, output=None)
    result = {
        "program": APP_NAME,
        "program_id": PROGRAM_ID,
        "version": VERSION,
        "status": "stable_locked",
        "stable_lock": True,
        "stable_lock_name": "Sentinel Media Index v1.0.0 Stable Lock",
        "locked_component": "Program 118 media catalogue authority for Program 119 Sentinel Media Player",
        "baseline": "v1.0.0",
        "preserved_doctrine": {
            "local_first": True,
            "telemetry": False,
            "source_media_mutation_default": False,
            "guarded_metadata_write_actions": True,
            "system_assets_excluded_by_default": True,
            "automatic_online_metadata_during_scan": True,
            "offline_opt_out": True,
        },
        "locked_capabilities": readiness.get("capabilities", []),
        "ui_lock": {
            "default_window": "1420x980",
            "minimum_window": "1160x800",
            "search_categories_columns": ["Thumb", "Name", "Type", "Size", "Details", "Path"],
            "thumb_column_width": 76,
            "compact_rows": True,
            "thumb_header_fits": True,
        },
        "media_player_contract": {
            "media_index_is_default_catalogue_authority": True,
            "exports": ["player-library", "visual-board", "player-handoff", "player-contract"],
            "visual_board_ready": True,
            "metadata_fields_ready": ["cover", "poster", "synopsis", "cast", "director", "artist", "album", "author", "series"],
        },
        "audit_summary": {
            "v1_stable_lock_candidate": audit.get("v1_stable_lock_candidate"),
            "failed_required_checks": audit.get("failed_required_checks", []),
            "recommendation": "stable_locked" if not audit.get("failed_required_checks") else "review_required",
        },
        "generated_at": utc_now(),
    }
    if output:
        output = _ensure_safe_output_path(output, role="stable_lock_report_output")
        if output.suffix.lower() == ".md":
            lines = [
                f"# {APP_NAME} v{VERSION} Stable Lock Report",
                "",
                f"- Program: **{APP_NAME}**",
                f"- Program ID: **{PROGRAM_ID}**",
                f"- Version: **{VERSION}**",
                "- Status: **stable_locked**",
                "- Media Player contract: **ready**",
                "- Source media mutation by default: **false**",
                "- System assets excluded by default: **true**",
                "- Thumb column header fit: **true**",
                "",
                "## Doctrine",
                "Media Index owns scanning, metadata, thumbnails, tags, collections, reports, and Program 119 catalogue exports. Media Player consumes the catalogue and presents it as a visual user-readable library.",
            ]
            _safe_write_text(output, "\n".join(lines) + "\n", role="stable_lock_report")
        else:
            _safe_write_text(output, json.dumps(result, indent=2), role="stable_lock_report")
        result["output"] = str(output)
    return result

def run_gui(initial_action: str = "", initial_file: str = "") -> int:
    try:
        import tkinter as tk
        from tkinter import filedialog, messagebox, ttk
    except Exception as exc:
        print(f"Tkinter is not available: {exc}", file=sys.stderr)
        return 2

    db = MediaIndexDB()
    db.init()

    class App(tk.Tk):
        def __init__(self) -> None:
            super().__init__()
            self.initial_action = initial_action
            self.initial_file = initial_file
            self.title(f"{APP_NAME} v{VERSION}")
            self.geometry("1500x980")
            self.minsize(1160, 800)
            self.configure(bg=THEME["bg"])
            # Keep Tk/ttk popups, dropdown listboxes, entry cursors and menus aligned with the Sentinel/AEGIS dark theme.
            self.option_add("*Background", THEME["bg"])
            self.option_add("*Foreground", THEME["fg"])
            self.option_add("*Entry.Background", THEME["panel"])
            self.option_add("*Entry.Foreground", THEME["fg"])
            self.option_add("*Entry.insertBackground", THEME["gold"])
            self.option_add("*Text.Background", THEME["panel"])
            self.option_add("*Text.Foreground", THEME["fg"])
            self.option_add("*Text.insertBackground", THEME["gold"])
            self.option_add("*Menu.background", THEME["panel2"])
            self.option_add("*Menu.foreground", THEME["fg"])
            self.option_add("*Menu.activeBackground", THEME["gold"])
            self.option_add("*Menu.activeForeground", THEME["bg"])
            self.option_add("*TCombobox*Listbox.background", THEME["panel"])
            self.option_add("*TCombobox*Listbox.foreground", THEME["fg"])
            self.option_add("*TCombobox*Listbox.selectBackground", THEME["gold"])
            self.option_add("*TCombobox*Listbox.selectForeground", THEME["bg"])
            self.scan_path = tk.StringVar(value=str(HOME / "Videos" / "Movies"))  # No broad /home scan by default.
            self.hash_var = tk.BooleanVar(value=False)
            self.metadata_var = tk.BooleanVar(value=True)
            self.thumb_var = tk.BooleanVar(value=True)
            self.auto_online_var = tk.BooleanVar(value=True)
            self.include_assets_var = tk.BooleanVar(value=False)
            self.scan_running = False
            self.scan_cancel_event = threading.Event()
            self.preview_img = None
            self.result_rows = {}
            self.query_var = tk.StringVar(value="")
            self.type_var = tk.StringVar(value="all")
            self.tag_path_var = tk.StringVar(value="")
            self.tag_name_var = tk.StringVar(value="")
            self.collection_name_var = tk.StringVar(value="")
            self.player_handoff_var = tk.StringVar(value=str(PLAYER_ROOT / "sentinel_player_handoff.json"))
            self.meta_edit_path_var = tk.StringVar(value="")
            self.meta_title_var = tk.StringVar(value="")
            self.meta_artist_var = tk.StringVar(value="")
            self.meta_album_var = tk.StringVar(value="")
            self.meta_genre_var = tk.StringVar(value="")
            self.meta_date_var = tk.StringVar(value="")
            self.meta_comment_var = tk.StringVar(value="")
            self.meta_rating_var = tk.StringVar(value="")
            self.result_images = {}
            self.status_var = tk.StringVar(value="Ready — exact default folders only: ~/Documents/eBooks, ~/Videos/Movies, ~/Videos/TV Shows, ~/Pictures. No /home scan. Add batch locations for extra drives.")
            self.bind_all("<Control-q>", lambda _e: self.destroy())
            self.bind_all("<Control-Q>", lambda _e: self.destroy())
            self._setup_style()
            self._build_ui()
            self.refresh_stats()
            if self.initial_file:
                self.after(350, self.handle_initial_context_action)

        def _setup_style(self) -> None:
            style = ttk.Style(self)
            try:
                style.theme_use("clam")
            except tk.TclError:
                pass
            style.configure("TNotebook", background=THEME["bg"], borderwidth=0)
            style.configure("TNotebook.Tab", background=THEME["panel2"], foreground=THEME["fg"], padding=(14, 8))
            style.map("TNotebook.Tab", background=[("selected", THEME["gold"])], foreground=[("selected", "#101214")])
            style.configure("TFrame", background=THEME["bg"])
            style.configure("Card.TFrame", background=THEME["panel"], relief="flat")
            style.configure("Hero.TFrame", background="#071116", relief="flat")
            style.configure("Sidebar.TFrame", background="#071116", relief="flat")
            style.configure("TLabel", background=THEME["bg"], foreground=THEME["fg"])
            style.configure("Muted.TLabel", background=THEME["bg"], foreground=THEME["muted"])
            style.configure("Card.TLabel", background=THEME["panel"], foreground=THEME["fg"])
            style.configure("Gold.TLabel", background=THEME["bg"], foreground=THEME["gold"], font=("Sans", 15, "bold"))
            style.configure("HeroTitle.TLabel", background="#071116", foreground=THEME["gold"], font=("Sans", 18, "bold"))
            style.configure("HeroMuted.TLabel", background="#071116", foreground=THEME["muted"], font=("Sans", 10))
            style.configure("Sidebar.TButton", padding=(10, 9), background="#142230", foreground=THEME["fg"], borderwidth=1)
            style.configure("TButton", padding=(10, 6), background=THEME["panel2"], foreground=THEME["fg"], borderwidth=1)
            style.map("TButton", background=[("active", "#2B313B"), ("pressed", THEME["gold"])], foreground=[("pressed", THEME["bg"])])
            style.configure("Accent.TButton", padding=(10, 6), background=THEME["gold"], foreground=THEME["bg"])
            style.configure("Treeview", background=THEME["panel"], fieldbackground=THEME["panel"], foreground=THEME["fg"], borderwidth=0, rowheight=30)
            style.configure("Treeview.Heading", background=THEME["panel2"], foreground=THEME["gold"], relief="flat")
            style.map("Treeview", background=[("selected", "#374151")], foreground=[("selected", THEME["fg"])])
            style.configure("TCheckbutton", background=THEME["bg"], foreground=THEME["fg"], indicatorcolor=THEME["panel2"], padding=(4, 3))
            style.map("TCheckbutton", background=[("active", THEME["bg"])], foreground=[("active", THEME["gold"])])
            style.configure("TEntry", fieldbackground=THEME["panel"], background=THEME["panel"], foreground=THEME["fg"], insertcolor=THEME["gold"], bordercolor=THEME["panel2"], lightcolor=THEME["panel2"], darkcolor=THEME["panel2"], padding=(7, 5))
            style.map("TEntry", fieldbackground=[("readonly", THEME["panel2"]), ("disabled", "#111318"), ("focus", THEME["panel"])], foreground=[("disabled", THEME["muted"]), ("focus", THEME["fg"])])
            style.configure("TCombobox", fieldbackground=THEME["panel"], background=THEME["panel2"], foreground=THEME["fg"], arrowcolor=THEME["gold"], bordercolor=THEME["panel2"], lightcolor=THEME["panel2"], darkcolor=THEME["panel2"], padding=(7, 5))
            style.map("TCombobox", fieldbackground=[("readonly", THEME["panel"]), ("focus", THEME["panel"])], background=[("readonly", THEME["panel2"]), ("active", "#2B313B")], foreground=[("readonly", THEME["fg"])])
            style.configure("Vertical.TScrollbar", background=THEME["panel2"], troughcolor=THEME["bg"], arrowcolor=THEME["gold"], bordercolor=THEME["bg"])
            style.configure("Horizontal.TScrollbar", background=THEME["panel2"], troughcolor=THEME["bg"], arrowcolor=THEME["gold"], bordercolor=THEME["bg"])
            style.configure("TProgressbar", background=THEME["gold"], troughcolor=THEME["panel"], bordercolor=THEME["panel2"], lightcolor=THEME["gold"], darkcolor=THEME["gold"])

        def _build_ui(self) -> None:
            menu = tk.Menu(self, bg=THEME["panel2"], fg=THEME["fg"], activebackground=THEME["gold"], activeforeground=THEME["bg"], tearoff=False)
            file_menu = tk.Menu(menu, tearoff=False, bg=THEME["panel2"], fg=THEME["fg"], activebackground=THEME["gold"], activeforeground=THEME["bg"])
            file_menu.add_command(label="Scan Default Files", command=self.scan_default_roots_gui)
            file_menu.add_command(label="Write Player Catalogue", command=self.write_player_catalogue_gui)
            file_menu.add_separator()
            file_menu.add_command(label="Quit", accelerator="Ctrl+Q", command=self.destroy)
            view_menu = tk.Menu(menu, tearoff=False, bg=THEME["panel2"], fg=THEME["fg"], activebackground=THEME["gold"], activeforeground=THEME["bg"])
            menu.add_cascade(label="File", menu=file_menu)
            menu.add_cascade(label="View", menu=view_menu)
            self.config(menu=menu)

            hero = ttk.Frame(self, style="Hero.TFrame", padding=(16, 14))
            hero.pack(fill="x", padx=14, pady=(12, 8))
            ttk.Label(hero, text="▤🛡", style="HeroTitle.TLabel").pack(side="left", padx=(0, 14))
            hero_text = ttk.Frame(hero, style="Hero.TFrame")
            hero_text.pack(side="left", fill="x", expand=True)
            ttk.Label(hero_text, text="S E N T I N E L   M E D I A   I N D E X", style="HeroTitle.TLabel").pack(anchor="w")
            ttk.Label(hero_text, text="Program 118 • catalogue authority • player handoff • local metadata • exact-root scanning", style="HeroMuted.TLabel").pack(anchor="w", pady=(4, 0))

            main = ttk.Frame(self)
            main.pack(fill="both", expand=True, padx=14, pady=(0, 10))
            sidebar = ttk.Frame(main, style="Sidebar.TFrame", padding=(10, 12))
            sidebar.pack(side="left", fill="y", padx=(0, 10))
            nb = ttk.Notebook(main)
            self.nb = nb
            nb.pack(side="left", fill="both", expand=True)
            self.dashboard = ttk.Frame(nb, padding=14)
            self.scan_tab = ttk.Frame(nb, padding=14)
            self.search_tab = ttk.Frame(nb, padding=14)
            self.duplicates_tab = ttk.Frame(nb, padding=14)
            self.organise_tab = ttk.Frame(nb, padding=14)
            self.metadata_tab = ttk.Frame(nb, padding=14)
            self.tools_tab = ttk.Frame(nb, padding=14)
            self.manual_tab = ttk.Frame(nb, padding=14)
            nb.add(self.dashboard, text="Dashboard")
            nb.add(self.scan_tab, text="Scan")
            nb.add(self.search_tab, text="Search / Categories")
            nb.add(self.duplicates_tab, text="Duplicates")
            nb.add(self.organise_tab, text="Tags / Collections")
            nb.add(self.metadata_tab, text="Metadata Editor")
            nb.add(self.tools_tab, text="Export / AEGIS / Player")
            nb.add(self.manual_tab, text="Manual")
            nav_specs = [
                ("Dashboard", self.dashboard),
                ("Scan", self.scan_tab),
                ("Search / Views", self.search_tab),
                ("Duplicates", self.duplicates_tab),
                ("Tags / Collections", self.organise_tab),
                ("Metadata", self.metadata_tab),
                ("Export / Player", self.tools_tab),
                ("Manual", self.manual_tab),
            ]
            for label, tab in nav_specs:
                b = ttk.Button(sidebar, text=label, style="Sidebar.TButton", command=lambda t=tab: self.nb.select(t))
                b.pack(fill="x", pady=5)
            ttk.Separator(sidebar, orient="horizontal").pack(fill="x", pady=10)
            ttk.Button(sidebar, text="Scan Default Files", style="Accent.TButton", command=self.scan_default_roots_gui).pack(fill="x", pady=5)
            ttk.Button(sidebar, text="Write Catalogue", style="Sidebar.TButton", command=self.write_player_catalogue_gui).pack(fill="x", pady=5)
            ttk.Button(sidebar, text="Open Media Player", style="Sidebar.TButton", command=self.open_media_player_gui).pack(fill="x", pady=5)
            self._build_dashboard()
            self._build_scan()
            self._build_search()
            self._build_duplicates()
            self._build_organise()
            self._build_metadata_editor()
            self._build_tools()
            self._build_manual()

            status = ttk.Label(self, textvariable=self.status_var, style="Muted.TLabel", padding=(14, 6))
            status.pack(fill="x")

        def _card(self, parent: tk.Widget, title: str) -> ttk.Frame:
            frame = ttk.Frame(parent, style="Card.TFrame", padding=14)
            ttk.Label(frame, text=title, style="Card.TLabel", font=("Sans", 12, "bold")).pack(anchor="w")
            return frame

        def _build_dashboard(self) -> None:
            ttk.Label(self.dashboard, text="Library Overview", style="Gold.TLabel").pack(anchor="w")
            ttk.Label(
                self.dashboard,
                text="Readable local summary. By default Sentinel Media Index scans exact library folders only: ~/Documents/eBooks, ~/Videos/Movies, ~/Videos/TV Shows, and ~/Pictures. No broad /home scan is performed; add exact batch locations for other drives.",
                style="Muted.TLabel",
                wraplength=1050,
            ).pack(anchor="w", pady=(2, 12))
            self.dashboard_cards = ttk.Frame(self.dashboard)
            self.dashboard_cards.pack(fill="x")
            self.dashboard_vars: Dict[str, tk.StringVar] = {}
            card_specs = [
                ("total", "Indexed Files"),
                ("size", "Library Size"),
                ("types", "Media Types"),
                ("thumbs", "Thumbnails"),
                ("metadata", "Metadata"),
                ("duplicates", "Duplicate Groups"),
            ]
            for idx, (key, title) in enumerate(card_specs):
                card = ttk.Frame(self.dashboard_cards, style="Card.TFrame", padding=12)
                card.grid(row=idx // 3, column=idx % 3, sticky="nsew", padx=6, pady=6)
                ttk.Label(card, text=title, style="Card.TLabel", font=("Sans", 10, "bold")).pack(anchor="w")
                var = tk.StringVar(value="—")
                self.dashboard_vars[key] = var
                ttk.Label(card, textvariable=var, style="Card.TLabel", font=("Sans", 18, "bold")).pack(anchor="w", pady=(6, 0))
            for col in range(3):
                self.dashboard_cards.columnconfigure(col, weight=1)
            row = ttk.Frame(self.dashboard)
            row.pack(fill="x", pady=(12, 8))
            ttk.Button(row, text="Refresh Stats", command=self.refresh_stats).pack(side="left")
            ttk.Button(row, text="Start Scan", command=lambda: self.nb.select(self.scan_tab)).pack(side="left", padx=8)
            ttk.Button(row, text="Mark Missing Files", command=self.mark_missing_gui).pack(side="left", padx=8)
            ttk.Button(row, text="Open Data Folder", command=lambda: self.open_path(DATA_ROOT)).pack(side="left", padx=8)
            self.stats_text = tk.Text(self.dashboard, height=12, bg=THEME["panel"], fg=THEME["fg"], insertbackground=THEME["gold"], relief="flat", wrap="word")
            self.stats_text.pack(fill="both", expand=True)

        def _build_scan(self) -> None:
            top = ttk.Frame(self.scan_tab)
            top.pack(fill="x")
            ttk.Label(top, text="Folder to scan:").grid(row=0, column=0, sticky="w", pady=4)
            ent = ttk.Entry(top, textvariable=self.scan_path)
            ent.grid(row=0, column=1, sticky="ew", padx=8, pady=4)
            ent.bind("<Return>", lambda _e: self.scan_gui())
            ttk.Button(top, text="Browse", command=self.browse_scan_folder).grid(row=0, column=2, pady=4)
            ttk.Checkbutton(top, text="Compute SHA256 hashes (slower, best for duplicates/integrity)", variable=self.hash_var).grid(row=1, column=1, sticky="w", pady=4)
            ttk.Checkbutton(top, text="Extract local metadata when possible", variable=self.metadata_var).grid(row=2, column=1, sticky="w", pady=4)
            ttk.Checkbutton(top, text="Generate local thumbnails/previews", variable=self.thumb_var).grid(row=3, column=1, sticky="w", pady=4)
            ttk.Checkbutton(top, text="Automatically enrich covers/blurbs/cast/album/book metadata online", variable=self.auto_online_var).grid(row=4, column=1, sticky="w", pady=4)
            ttk.Checkbutton(top, text="Diagnostic: include system/cache/assets folders (off; not used for normal library scans)", variable=self.include_assets_var).grid(row=5, column=1, sticky="w", pady=4)
            scan_buttons = ttk.Frame(top)
            scan_buttons.grid(row=6, column=1, sticky="w", pady=8)
            self.scan_button = ttk.Button(scan_buttons, text="Start Scan", command=self.scan_gui)
            self.scan_button.pack(side="left")
            self.default_roots_button = ttk.Button(scan_buttons, text="Scan Default Files", command=self.scan_default_roots_gui)
            self.default_roots_button.pack(side="left", padx=8)
            self.stop_scan_button = ttk.Button(scan_buttons, text="Stop Scan", command=self.stop_scan_gui, state="disabled")
            self.stop_scan_button.pack(side="left", padx=8)
            ttk.Button(scan_buttons, text="Add Batch Location", command=self.add_batch_location_gui).pack(side="left", padx=8)
            ttk.Button(scan_buttons, text="Show Root Policy", command=self.show_root_policy_gui).pack(side="left", padx=8)
            top.columnconfigure(1, weight=1)
            feedback = ttk.Frame(self.scan_tab)
            feedback.pack(fill="x", pady=(10, 0))
            self.scan_feedback_var = tk.StringVar(value="Ready. Default files scan only: ~/Documents/eBooks, ~/Videos/Movies, ~/Videos/TV Shows, ~/Pictures. No /home scan. Add Batch Location for exact external folders.")
            ttk.Label(feedback, textvariable=self.scan_feedback_var, style="Muted.TLabel").pack(anchor="w")
            self.scan_progress = ttk.Progressbar(feedback, mode="indeterminate")
            self.scan_progress.pack(fill="x", pady=(6, 0))
            self.scan_output = tk.Text(self.scan_tab, height=18, bg=THEME["panel"], fg=THEME["fg"], relief="flat", wrap="word")
            self.scan_output.pack(fill="both", expand=True, pady=(12, 0))

        def _build_search(self) -> None:
            row = ttk.Frame(self.search_tab)
            row.pack(fill="x")
            ttk.Label(row, text="Search:").pack(side="left")
            search_entry = ttk.Entry(row, textvariable=self.query_var, width=42)
            search_entry.pack(side="left", padx=8)
            search_entry.bind("<Return>", lambda _e: self.search_gui())
            ttk.Label(row, text="Type:").pack(side="left", padx=(12, 0))
            type_box = ttk.Combobox(row, textvariable=self.type_var, values=SCAN_TYPE_CHOICES, width=12, state="readonly")
            type_box.pack(side="left", padx=8)
            type_box.bind("<Return>", lambda _e: self.search_gui())
            ttk.Button(row, text="Search", command=self.search_gui).pack(side="left")
            ttk.Button(row, text="Open Selected", command=self.open_selected_result).pack(side="left", padx=8)
            ttk.Label(row, text="Enter = confirm search • Ctrl+Q = close", style="Muted.TLabel").pack(side="left", padx=12)
            pane = ttk.PanedWindow(self.search_tab, orient="horizontal")
            pane.pack(fill="both", expand=True, pady=(12, 0))
            left = ttk.Frame(pane)
            right = ttk.Frame(pane, padding=(10, 0))
            pane.add(left, weight=3)
            pane.add(right, weight=2)
            cols = ("name", "type", "size", "details", "path")
            self.results = ttk.Treeview(left, columns=cols, show="tree headings")
            self.results.heading("#0", text="Thumb")
            self.results.column("#0", width=76, minwidth=68, anchor="center", stretch=False)
            column_specs = (
                ("name", "Name", 300, "w", True),
                ("type", "Type", 80, "center", False),
                ("size", "Size", 84, "e", False),
                ("details", "Details", 150, "w", False),
                ("path", "Path", 500, "w", True),
            )
            for c, label, w, anchor, stretch in column_specs:
                self.results.heading(c, text=label)
                self.results.column(c, width=w, minwidth=max(70, int(w * 0.55)), anchor=anchor, stretch=stretch)
            yscroll = ttk.Scrollbar(left, orient="vertical", command=self.results.yview)
            self.results.configure(yscrollcommand=yscroll.set)
            self.results.pack(side="left", fill="both", expand=True)
            yscroll.pack(side="right", fill="y")
            self.results.bind("<<TreeviewSelect>>", lambda _e: self.preview_selected_result())
            self.results.bind("<Return>", lambda _e: self.open_selected_result())
            self.results.bind("<Double-1>", lambda _e: self.open_selected_result())
            ttk.Label(right, text="Preview / Metadata", style="Card.TLabel", font=("Sans", 11, "bold")).pack(anchor="w")
            self.preview_label = ttk.Label(right, text="Select an item to preview.", style="Muted.TLabel")
            self.preview_label.pack(anchor="center", pady=(10, 8), fill="both")
            self.preview_text = tk.Text(right, height=30, width=64, bg=THEME["panel"], fg=THEME["fg"], insertbackground=THEME["gold"], relief="flat", wrap="word")
            self.preview_text.pack(fill="both", expand=True)
            meta_buttons = ttk.Frame(right)
            meta_buttons.pack(fill="x", pady=(8, 0))
            ttk.Button(meta_buttons, text="Clean Metadata", command=self.clean_selected_metadata_gui).pack(side="left")
            ttk.Button(meta_buttons, text="Edit Metadata", command=self.edit_selected_metadata_gui).pack(side="left", padx=8)
            self.search_gui()

        def _build_duplicates(self) -> None:
            row = ttk.Frame(self.duplicates_tab)
            row.pack(fill="x")
            ttk.Button(row, text="Find Hash Duplicates", command=lambda: self.duplicates_gui("hash")).pack(side="left")
            ttk.Button(row, text="Find Name+Size Duplicates", command=lambda: self.duplicates_gui("name_size")).pack(side="left", padx=8)
            ttk.Button(row, text="Export Hash Duplicate Report", command=lambda: self.duplicate_report_gui("hash")).pack(side="left", padx=8)
            ttk.Button(row, text="Export Name+Size Report", command=lambda: self.duplicate_report_gui("name_size")).pack(side="left", padx=8)
            self.dupe_output = tk.Text(self.duplicates_tab, bg=THEME["panel"], fg=THEME["fg"], relief="flat", wrap="none")
            self.dupe_output.pack(fill="both", expand=True, pady=(12, 0))

        def _build_organise(self) -> None:
            top = ttk.Frame(self.organise_tab)
            top.pack(fill="x")
            ttk.Label(top, text="Indexed file path:").grid(row=0, column=0, sticky="w", pady=4)
            path_entry = ttk.Entry(top, textvariable=self.tag_path_var)
            path_entry.grid(row=0, column=1, sticky="ew", padx=8, pady=4)
            path_entry.bind("<Return>", lambda _e: self.add_tag_gui())
            ttk.Button(top, text="Use Selected Search Result", command=self.use_selected_for_tag).grid(row=0, column=2, padx=4)
            ttk.Label(top, text="Tag:").grid(row=1, column=0, sticky="w", pady=4)
            tag_entry = ttk.Entry(top, textvariable=self.tag_name_var)
            tag_entry.grid(row=1, column=1, sticky="ew", padx=8, pady=4)
            tag_entry.bind("<Return>", lambda _e: self.add_tag_gui())
            ttk.Button(top, text="Add Tag", command=self.add_tag_gui).grid(row=1, column=2, padx=4)
            ttk.Label(top, text="Collection:").grid(row=2, column=0, sticky="w", pady=4)
            collection_entry = ttk.Entry(top, textvariable=self.collection_name_var)
            collection_entry.grid(row=2, column=1, sticky="ew", padx=8, pady=4)
            collection_entry.bind("<Return>", lambda _e: self.add_collection_gui())
            ttk.Button(top, text="Add To Collection", command=self.add_collection_gui).grid(row=2, column=2, padx=4)
            ttk.Button(top, text="Refresh Tags / Collections", command=self.refresh_organise_gui).grid(row=3, column=1, sticky="w", pady=8)
            top.columnconfigure(1, weight=1)
            self.organise_output = tk.Text(self.organise_tab, bg=THEME["panel"], fg=THEME["fg"], relief="flat", wrap="word")
            self.organise_output.pack(fill="both", expand=True, pady=(12, 0))
            self.refresh_organise_gui()

        def _build_metadata_editor(self) -> None:
            top = ttk.Frame(self.metadata_tab)
            top.pack(fill="x")
            ttk.Label(top, text="Selected/indexed file:").grid(row=0, column=0, sticky="w", pady=4)
            path_entry = ttk.Entry(top, textvariable=self.meta_edit_path_var)
            path_entry.grid(row=0, column=1, sticky="ew", padx=8, pady=4)
            path_entry.bind("<Return>", lambda _e: self.load_metadata_editor_gui())
            ttk.Button(top, text="Load Selected Search Result", command=self.load_selected_into_metadata_editor).grid(row=0, column=2, padx=4)
            ttk.Button(top, text="Load Path", command=self.load_metadata_editor_gui).grid(row=0, column=3, padx=4)
            fields = [
                ("Title", self.meta_title_var),
                ("Artist", self.meta_artist_var),
                ("Album", self.meta_album_var),
                ("Genre", self.meta_genre_var),
                ("Date", self.meta_date_var),
                ("Rating", self.meta_rating_var),
            ]
            for idx, (label, var) in enumerate(fields, start=1):
                ttk.Label(top, text=f"{label}:").grid(row=idx, column=0, sticky="w", pady=3)
                ent = ttk.Entry(top, textvariable=var)
                ent.grid(row=idx, column=1, sticky="ew", padx=8, pady=3)
                ent.bind("<Return>", lambda _e: self.save_metadata_editor_gui())
            ttk.Label(top, text="Comment:").grid(row=7, column=0, sticky="nw", pady=3)
            comment_entry = ttk.Entry(top, textvariable=self.meta_comment_var)
            comment_entry.grid(row=7, column=1, sticky="ew", padx=8, pady=3)
            comment_entry.bind("<Return>", lambda _e: self.save_metadata_editor_gui())
            btnrow = ttk.Frame(top)
            btnrow.grid(row=8, column=1, sticky="w", pady=(10, 4))
            ttk.Button(btnrow, text="Save Metadata", command=self.save_metadata_editor_gui).pack(side="left")
            ttk.Button(btnrow, text="Clean Metadata", command=self.clean_metadata_editor_gui).pack(side="left", padx=8)
            ttk.Button(btnrow, text="Reindex Metadata", command=self.reindex_metadata_editor_gui).pack(side="left", padx=8)
            ttk.Button(btnrow, text="Dry-Run Edit Plan", command=self.metadata_edit_plan_gui).pack(side="left", padx=8)
            ttk.Button(btnrow, text="Batch Clean Plan", command=self.metadata_batch_plan_gui).pack(side="left", padx=8)
            ttk.Button(btnrow, text="Review Backups", command=self.metadata_backup_review_gui).pack(side="left", padx=8)
            ttk.Label(top, text="Writes use backend exiftool, create exiftool backup files where supported, and require confirmation.", style="Muted.TLabel").grid(row=9, column=1, sticky="w", pady=(2, 8))
            top.columnconfigure(1, weight=1)
            self.metadata_output = tk.Text(self.metadata_tab, height=16, bg=THEME["panel"], fg=THEME["fg"], relief="flat", wrap="word")
            self.metadata_output.pack(fill="both", expand=True, pady=(12, 0))

        def _build_tools(self) -> None:
            ttk.Label(
                self.tools_tab,
                text="Exports and Player handoff tools. Buttons are kept to two rows so they remain visible on laptop screens.",
                style="Muted.TLabel",
                wraplength=1050,
            ).pack(anchor="w", pady=(0, 8))
            buttons = ttk.Frame(self.tools_tab)
            buttons.pack(fill="x")
            button_specs = [
                ("Export CSV", self.export_csv_gui),
                ("Export JSON", self.export_json_gui),
                ("Backup Database", self.backup_gui),
                ("AEGIS Status", self.aegis_gui),
                ("Player Handoff", self.player_handoff_gui),
                ("Export Player Catalogue", self.export_player_catalogue_gui),
                ("Write Player Catalogue", self.write_player_catalogue_gui),
                ("Export M3U", self.m3u_gui),
                ("Organisation Report", self.organisation_report_gui),
                ("Duplicate Report", self.duplicate_report_gui),
                ("Player Contract", self.player_contract_gui),
                ("Open Exports", lambda: self.open_path(EXPORT_ROOT)),
                ("Open Thumbnails", lambda: self.open_path(THUMB_ROOT)),
                ("Open Player Handoffs", lambda: self.open_path(PLAYER_ROOT)),
            ]
            for idx, (label, command) in enumerate(button_specs):
                row = idx // 7
                col = idx % 7
                btn = ttk.Button(buttons, text=label, command=command)
                btn.grid(row=row, column=col, sticky="ew", padx=4, pady=4)
            for col in range(7):
                buttons.columnconfigure(col, weight=1, uniform="export_buttons")
            self.tools_output = tk.Text(self.tools_tab, bg=THEME["panel"], fg=THEME["fg"], relief="flat", wrap="word")
            self.tools_output.pack(fill="both", expand=True, pady=(12, 0))

        def _build_manual(self) -> None:
            ttk.Label(self.manual_tab, text="Sentinel Media Index Manual", style="Gold.TLabel").pack(anchor="w")
            manual = """
Program 118 controls the media catalogue. Sentinel Media Player reflects only the written fast catalogue.

Default scan files/folders:
  • ~/Documents/eBooks
  • ~/Videos/Movies
  • ~/Videos/TV Shows
  • ~/Pictures

No /home scan:
  The normal scanner does not walk /home, $HOME, Desktop, Downloads, cache folders, app folders, icons, themes, or package/build folders.

External and batch locations:
  • Clearly named mounted folders such as Movies, TV Shows, Television, TV, or Music can be discovered.
  • Use Add Batch Location for exact folders on other drives.

Recommended workflow:
  1. Put media in one of the default folders, or add an exact batch location.
  2. Press Scan Default Files.
  3. Press Write Player Catalogue if needed.
  4. In Sentinel Media Player, press Retrieve Media Index.

Rename workflow:
  1. Export/propose rename plan from the backend.
  2. Review the plan.
  3. Apply guarded renames only when approved.
  4. Write Player Catalogue again.

Safety:
  • Local-first.
  • No telemetry.
  • No deletion.
  • Source-file metadata edits and renames are guarded.
  • Scan cancellation is cooperative and stops after the current file.
""".strip()
            txt = tk.Text(self.manual_tab, bg=THEME["panel"], fg=THEME["fg"], relief="flat", wrap="word")
            txt.pack(fill="both", expand=True, pady=(12, 0))
            txt.insert("end", manual)
            txt.configure(state="disabled")

        def refresh_stats(self) -> None:
            data = db.stats()
            by_type = data.get("by_type") or {}
            if hasattr(self, "dashboard_vars"):
                self.dashboard_vars["total"].set(f"{data['total_items']} total\n{data['present_items']} present")
                self.dashboard_vars["size"].set(fmt_size(data['total_size_bytes']))
                type_bits = []
                for k in ("video", "audio", "ebook", "image", "playlist"):
                    if by_type.get(k):
                        type_bits.append(f"{k}: {by_type[k]}")
                self.dashboard_vars["types"].set("\n".join(type_bits) if type_bits else "No indexed media")
                self.dashboard_vars["thumbs"].set(str(data.get('thumbnail_count', 0)))
                self.dashboard_vars["metadata"].set(str(data.get('metadata_enriched_items', 0)))
                self.dashboard_vars["duplicates"].set(f"hash {data['duplicate_hash_groups']}\nname+size {data['duplicate_name_size_groups']}")
            lines = [
                f"{APP_NAME} v{VERSION}",
                f"Database: {data['db_path']}",
                "",
                "Default scan policy:",
                "  • Indexes exact approved media folders only: eBooks, Movies, TV Shows, Pictures, named external media roots, and user-added batch locations.",
                "  • Does not catalogue system icons, themes, cache thumbnails, app assets, cover-art files, or sidecars as library items.",
                "  • No network, no telemetry, no source file mutation unless guarded metadata write is explicitly confirmed.",
                "",
                "By type:",
            ]
            for k in sorted(by_type):
                lines.append(f"  {k}: {by_type[k]}")
            if data["last_scan"]:
                ls = data["last_scan"]
                lines += [
                    "", "Last scan:",
                    f"  Root: {ls['root_path']}",
                    f"  Indexed: {ls['media_indexed']} / seen {ls['files_seen']}",
                    f"  Errors: {ls['errors']}",
                ]
            self.stats_text.delete("1.0", "end")
            self.stats_text.insert("end", "\n".join(lines))
            self.status_var.set("Stats refreshed.")

        def handle_initial_context_action(self) -> None:
            path = self.initial_file.strip()
            action = (self.initial_action or "read").strip().lower()
            if not path:
                return
            self.nb.select(self.metadata_tab)
            self._fill_metadata_editor_from_path(path)
            payload = context_action_payload(action, Path(path))
            if hasattr(self, "metadata_output"):
                self.metadata_output.delete("1.0", "end")
                self.metadata_output.insert("end", json.dumps(payload, indent=2))
            if action == "clean":
                plan = metadata_clean_backend(Path(path), execute=False)
                if hasattr(self, "metadata_output"):
                    self.metadata_output.insert("end", "\n\n--- Metadata Clean Dry-Run Plan ---\n")
                    self.metadata_output.insert("end", json.dumps(plan, indent=2))
                self.status_var.set("Context clean loaded. Review plan, then press Clean Metadata to confirm.")
                messagebox.showinfo(APP_NAME, "Selected file loaded. Review the clean metadata dry-run plan, then press Clean Metadata if you want to proceed.")
            elif action == "edit":
                self.status_var.set("Context edit loaded. Metadata fields autofilled where available.")
            else:
                self.status_var.set("Context metadata read loaded.")

        def browse_scan_folder(self) -> None:
            p = filedialog.askdirectory(title="Select folder to scan")
            if p:
                self.scan_path.set(p)

        def add_batch_location_gui(self) -> None:
            p = filedialog.askdirectory(title="Add manual batch scan location")
            if not p:
                return
            result = add_manual_scan_location(Path(p))
            self.scan_output.delete("1.0", "end")
            self.scan_output.insert("end", json.dumps(scan_root_policy_report(), indent=2))
            if not result.get("ok"):
                self.scan_feedback_var.set(f"Batch location blocked: {result.get('path')}")
                self.status_var.set("Broad scan location blocked by no-home policy.")
                messagebox.showerror(APP_NAME, result.get("policy") or "Broad scan location blocked.")
                return
            self.scan_feedback_var.set(f"Added manual batch scan location: {result.get('added')}")
            self.status_var.set("Manual batch scan location added. Use Scan Default Files/Retrieve Media Index to include it.")

        def open_media_player_gui(self) -> None:
            if shutil.which("sentinel-media-player") is None:
                messagebox.showerror(APP_NAME, "sentinel-media-player command not found. Install Program 119 Sentinel Media Player first.")
                return
            try:
                subprocess.Popen(["sentinel-media-player"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                self.status_var.set("Opening Sentinel Media Player...")
            except Exception as exc:
                messagebox.showerror(APP_NAME, f"Could not open Sentinel Media Player: {exc}")

        def show_root_policy_gui(self) -> None:
            result = scan_root_policy_report()
            self.scan_output.delete("1.0", "end")
            self.scan_output.insert("end", json.dumps(result, indent=2))
            self.scan_feedback_var.set("Root policy shown. Effective scan roots are listed in the output below.")
            self.status_var.set("Root policy shown.")

        def scan_gui(self) -> None:
            if self.scan_running:
                messagebox.showinfo(APP_NAME, "A scan is already running.")
                return
            p = Path(self.scan_path.get()).expanduser()
            if not p.exists() or not p.is_dir():
                messagebox.showerror(APP_NAME, "Select a valid folder to scan.")
                return
            if not self.include_assets_var.get() and not is_in_default_media_roots(p):
                messagebox.showerror(APP_NAME, "Selected folder is outside the approved scan set. Choose ~/Documents/eBooks, ~/Videos/Movies, ~/Videos/TV Shows, ~/Pictures, a discovered named media folder, or add it first with Add Batch Location. Broad /home scans are blocked.")
                return
            self.scan_running = True
            self.scan_cancel_event.clear()
            self.scan_button.configure(state="disabled")
            self.stop_scan_button.configure(state="normal")
            self.scan_feedback_var.set("Scanning selected approved folder only. No broad /home scan. Add Batch Location first for external folders.")
            self.status_var.set("Scanning media library...")
            self.scan_output.delete("1.0", "end")
            self.scan_output.insert("end", f"Scan started: {p}\nPlease wait. Supported media files are indexed; online metadata enrichment is automatic unless disabled. No telemetry is used.\n")
            self.scan_progress.start(12)
            options = {
                "hash_enabled": self.hash_var.get(),
                "extract_metadata": self.metadata_var.get(),
                "thumbnails": self.thumb_var.get(),
                "include_assets": self.include_assets_var.get(),
                "auto_online_metadata": self.auto_online_var.get(),
                "online_provider": "auto",
                "omdb_api_key": os.environ.get("OMDB_API_KEY", ""),
            }

            def worker() -> None:
                try:
                    result = scan_directory(p, db=db, cancel_event=self.scan_cancel_event, **options)
                    self.after(0, lambda result=result: self._scan_finished(result, None))
                except Exception as exc:
                    self.after(0, lambda exc=exc: self._scan_finished(None, exc))

            threading.Thread(target=worker, daemon=True).start()

        def scan_default_roots_gui(self) -> None:
            if self.scan_running:
                messagebox.showinfo(APP_NAME, "A scan is already running.")
                return
            self.scan_running = True
            self.scan_cancel_event.clear()
            self.scan_button.configure(state="disabled")
            self.stop_scan_button.configure(state="normal")
            roots = approved_default_roots(existing_only=True)
            self.scan_feedback_var.set(f"Scanning {len(roots)} approved root/s only. Use Add Batch Location for extra drives/folders.")
            self.status_var.set("Scanning approved Media Index roots...")
            self.scan_output.delete("1.0", "end")
            self.scan_output.insert("end", "Scan Default Files started. Effective exact roots only:\n" + "\n".join(str(r) for r in roots) + "\n\nBroad saved locations such as /home or ~/Documents are ignored automatically.\n")
            self.scan_progress.start(12)
            options = {
                "hash_enabled": self.hash_var.get(),
                "extract_metadata": self.metadata_var.get(),
                "thumbnails": self.thumb_var.get(),
                "include_assets": self.include_assets_var.get(),
                "auto_online_metadata": self.auto_online_var.get(),
                "online_provider": "auto",
                "omdb_api_key": os.environ.get("OMDB_API_KEY", ""),
                "cancel_event": self.scan_cancel_event,
            }
            def worker() -> None:
                try:
                    result = scan_default_roots(db=db, **options)
                    self.after(0, lambda result=result: self._scan_finished(result, None))
                except Exception as exc:
                    self.after(0, lambda exc=exc: self._scan_finished(None, exc))
            threading.Thread(target=worker, daemon=True).start()

        def stop_scan_gui(self) -> None:
            if not self.scan_running:
                self.scan_feedback_var.set("No scan is currently running.")
                return
            self.scan_cancel_event.set()
            self.stop_scan_button.configure(state="disabled")
            self.scan_feedback_var.set("Stop requested. Finishing the current file, then the scan will stop safely.")
            self.status_var.set("Stopping scan safely...")
            try:
                self.scan_output.insert("end", "\nStop requested by user. The scanner will finish the current file and stop safely.\n")
                self.scan_output.see("end")
            except Exception:
                pass

        def _scan_finished(self, result: Optional[Dict[str, Any]], exc: Optional[BaseException]) -> None:
            self.scan_progress.stop()
            self.scan_running = False
            self.scan_button.configure(state="normal")
            self.stop_scan_button.configure(state="disabled")
            if exc is not None:
                self.scan_feedback_var.set("Scan failed. Review the error output below.")
                self.scan_output.delete("1.0", "end")
                self.scan_output.insert("end", f"Scan failed: {type(exc).__name__}: {exc}")
                self.status_var.set("Scan failed.")
                return
            result = result or {}
            self.scan_output.delete("1.0", "end")
            self.scan_output.insert("end", json.dumps(result, indent=2))
            self.refresh_stats()
            self.search_gui()
            if result.get("cancelled"):
                self.scan_feedback_var.set(
                    f"Scan stopped safely: {(result.get('media_indexed') if result.get('media_indexed') is not None else (result.get('totals') or {}).get('media_indexed', 0))} media files indexed before stop • "
                    f"{(result.get('skipped_system_assets') if result.get('skipped_system_assets') is not None else (result.get('totals') or {}).get('skipped_system_assets', 0))} system asset/icon entries skipped."
                )
                self.status_var.set(f"Scan stopped: {(result.get('media_indexed') if result.get('media_indexed') is not None else (result.get('totals') or {}).get('media_indexed', 0))} media files indexed.")
            else:
                self.scan_feedback_var.set(
                    f"Scan complete: {(result.get('media_indexed') if result.get('media_indexed') is not None else (result.get('totals') or {}).get('media_indexed', 0))} media files indexed • "
                    f"{(result.get('skipped_system_assets') if result.get('skipped_system_assets') is not None else (result.get('totals') or {}).get('skipped_system_assets', 0))} system asset/icon entries skipped • {(result.get('online_metadata_success') if result.get('online_metadata_success') is not None else (result.get('totals') or {}).get('online_metadata_success', 0))} online enrichments."
                )
                self.status_var.set(f"Scan complete: {(result.get('media_indexed') if result.get('media_indexed') is not None else (result.get('totals') or {}).get('media_indexed', 0))} media files indexed.")

        def _photoimage_from_file(self, thumb: str, max_side: int = 28) -> Optional[tk.PhotoImage]:
            if not thumb or not Path(thumb).exists() or Path(thumb).suffix.lower() not in {".png", ".gif"}:
                return None
            try:
                img = tk.PhotoImage(file=thumb)
                factor = max(1, min(8, max(img.width() // max_side, img.height() // max_side)))
                return img.subsample(factor, factor) if factor > 1 else img
            except Exception:
                return None

        def _fallback_media_icon(self, media_type: str, key: str) -> tk.PhotoImage:
            icon_key = f"fallback:{media_type}:{key}"
            if icon_key in self.result_images:
                return self.result_images[icon_key]
            colours = {
                "image": THEME["cyan"],
                "video": THEME["danger"],
                "audio": THEME["gold"],
                "ebook": THEME["ok"],
                "playlist": THEME["muted"],
                "sidecar": "#6B7280",
                "other": "#4B5563",
            }
            accent = colours.get(media_type, "#4B5563")
            img = tk.PhotoImage(width=28, height=22)
            img.put(THEME["panel2"], to=(0, 0, 28, 22))
            img.put(accent, to=(1, 1, 27, 21))
            img.put(THEME["panel"], to=(3, 3, 25, 19))
            img.put(accent, to=(6, 8, 22, 10))
            img.put(accent, to=(6, 14, 19, 16))
            self.result_images[icon_key] = img
            return img

        def _tree_thumbnail_for(self, row: Dict[str, Any]) -> str:
            key = str(row.get("id") or row.get("path") or "row")
            thumb = str(row.get("thumbnail_path") or "")
            # If older rows were indexed before thumbnails existed, generate on demand.
            if (not thumb or not Path(thumb).exists()) and row.get("path"):
                generated = generate_thumbnail(Path(str(row.get("path"))), str(row.get("media_type") or "other"))
                if generated:
                    thumb = generated
                    row["thumbnail_path"] = generated
            img = self._photoimage_from_file(thumb)
            if img is None:
                img = self._fallback_media_icon(str(row.get("media_type") or "other"), key)
            self.result_images[key] = img
            return key

        def search_gui(self) -> None:
            for item in self.results.get_children():
                self.results.delete(item)
            self.result_rows = {}
            self.result_images = {}
            grouped = db.categorized_search(self.query_var.get().strip(), self.type_var.get(), limit=1000)
            total = 0
            for category, rows in grouped.items():
                parent = self.results.insert("", "end", text="", values=(f"{category} ({len(rows)})", "", "", "", ""), open=True)
                for r in rows:
                    total += 1
                    meta = ""
                    if r.get("width") and r.get("height"):
                        meta = f"{r.get('width')}x{r.get('height')}"
                    elif r.get("duration_seconds"):
                        meta = f"{float(r.get('duration_seconds')):.1f}s"
                    img_key = self._tree_thumbnail_for(r)
                    kwargs = {}
                    if img_key and img_key in self.result_images:
                        kwargs["image"] = self.result_images[img_key]
                    iid = self.results.insert(parent, "end", text=" ", values=(r["filename"], str(r.get("media_type") or ""), fmt_size(r["size_bytes"]), meta, r["path"]), **kwargs)
                    self.result_rows[iid] = r
            if total == 0:
                self.results.insert("", "end", text="No indexed files found", values=("", "", "", "", ""))
            self.status_var.set(f"Search returned {total} items in {len(grouped)} categories.")

        def _selected_result_row(self) -> Optional[Dict[str, Any]]:
            sel = self.results.selection()
            if not sel:
                return None
            return self.result_rows.get(sel[0])

        def preview_selected_result(self) -> None:
            row = self._selected_result_row()
            if not row:
                return
            self.preview_text.delete("1.0", "end")
            thumb = row.get("thumbnail_path") or ""
            self.preview_img = None
            if (not thumb or not Path(str(thumb)).exists()) and row.get("path"):
                generated = generate_thumbnail(Path(str(row.get("path"))), str(row.get("media_type") or "other"))
                if generated:
                    thumb = generated
                    row["thumbnail_path"] = generated
            img = self._photoimage_from_file(str(thumb), max_side=180) if thumb else None
            if img is None:
                img = self._fallback_media_icon(str(row.get("media_type") or "other"), f"preview:{row.get('id') or row.get('path')}")
            self.preview_img = img
            self.preview_label.configure(image=img, text="")
            lines = [
                f"Name: {row.get('filename','')}",
                f"Type: {row.get('media_type','')}",
                f"Size: {fmt_size(int(row.get('size_bytes') or 0))}",
                f"Path: {row.get('path','')}",
                f"MIME: {row.get('mime_guess','')}",
                f"Dimensions: {row.get('width') or '-'} x {row.get('height') or '-'}",
                f"Duration: {row.get('duration_seconds') or '-'}",
                f"Codec: {row.get('codec') or '-'}",
                f"Container: {row.get('container') or '-'}",
                f"Metadata status: {row.get('metadata_status') or '-'}",
                f"Thumbnail: {thumb or '-'}",
            ]
            self.preview_text.insert("end", "\n".join(lines))

        def open_selected_result(self) -> None:
            row = self._selected_result_row()
            if not row:
                messagebox.showinfo(APP_NAME, "Select a media file row first. Category headings are not files.")
                return
            self.open_path(Path(str(row.get("path"))))

        def use_selected_for_tag(self) -> None:
            row = self._selected_result_row()
            if not row:
                messagebox.showinfo(APP_NAME, "Select a media file row first.")
                return
            self.tag_path_var.set(str(row.get("path")))

        def refresh_organise_gui(self) -> None:
            tags = db.list_tags()
            collections = db.list_collections()
            lines = ["Tags:"]
            lines += [f"  - {t['name']} ({t['item_count']} items)" for t in tags] or ["  none yet"]
            lines += ["", "Collections:"]
            lines += [f"  - {c['name']} ({c['item_count']} items)" for c in collections] or ["  none yet"]
            self.organise_output.delete("1.0", "end")
            self.organise_output.insert("end", "\n".join(lines))

        def add_tag_gui(self) -> None:
            result = db.add_tag(self.tag_path_var.get(), self.tag_name_var.get())
            if not result.get("ok"):
                messagebox.showerror(APP_NAME, f"Could not add tag: {result.get('error')}")
                return
            self.refresh_organise_gui()
            self.status_var.set(f"Tag added: {result.get('tag')}")

        def add_collection_gui(self) -> None:
            result = db.add_to_collection(self.collection_name_var.get(), self.tag_path_var.get())
            if not result.get("ok"):
                messagebox.showerror(APP_NAME, f"Could not add to collection: {result.get('error')}")
                return
            self.refresh_organise_gui()
            self.status_var.set(f"Added to collection: {result.get('collection')}")

        def _fill_metadata_editor_from_path(self, path: str) -> None:
            self.meta_edit_path_var.set(path)
            report = metadata_read_backend(Path(path))
            external = report.get("external_metadata") or {}
            basic = report.get("basic_metadata") or {}
            self.meta_title_var.set(str(external.get("Title") or basic.get("title") or ""))
            self.meta_artist_var.set(str(external.get("Artist") or ""))
            self.meta_album_var.set(str(external.get("Album") or ""))
            self.meta_genre_var.set(str(external.get("Genre") or ""))
            self.meta_date_var.set(str(external.get("DateTimeOriginal") or external.get("CreateDate") or ""))
            self.meta_comment_var.set(str(external.get("Comment") or ""))
            self.meta_rating_var.set(str(external.get("Rating") or ""))
            self.metadata_output.delete("1.0", "end")
            self.metadata_output.insert("end", json.dumps(report, indent=2))
            self.status_var.set("Metadata editor loaded.")

        def load_selected_into_metadata_editor(self) -> None:
            row = self._selected_result_row()
            if not row:
                messagebox.showinfo(APP_NAME, "Select a media file row first.")
                return
            self._fill_metadata_editor_from_path(str(row.get("path")))

        def load_metadata_editor_gui(self) -> None:
            path = self.meta_edit_path_var.get().strip()
            if not path:
                messagebox.showinfo(APP_NAME, "Enter a media file path first.")
                return
            self._fill_metadata_editor_from_path(path)

        def edit_selected_metadata_gui(self) -> None:
            row = self._selected_result_row()
            if not row:
                messagebox.showinfo(APP_NAME, "Select a media file row first.")
                return
            self.nb.select(self.metadata_tab)
            self._fill_metadata_editor_from_path(str(row.get("path")))

        def clean_selected_metadata_gui(self) -> None:
            row = self._selected_result_row()
            if not row:
                messagebox.showinfo(APP_NAME, "Select a media file row first.")
                return
            self._clean_metadata_path_gui(str(row.get("path")))

        def _metadata_editor_fields(self) -> Dict[str, str]:
            return {
                "title": self.meta_title_var.get(),
                "artist": self.meta_artist_var.get(),
                "album": self.meta_album_var.get(),
                "genre": self.meta_genre_var.get(),
                "date": self.meta_date_var.get(),
                "comment": self.meta_comment_var.get(),
                "rating": self.meta_rating_var.get(),
            }

        def metadata_edit_plan_gui(self) -> None:
            path = self.meta_edit_path_var.get().strip()
            result = metadata_edit_backend(Path(path), self._metadata_editor_fields(), execute=False)
            self.metadata_output.delete("1.0", "end")
            self.metadata_output.insert("end", json.dumps(result, indent=2))
            self.status_var.set("Metadata edit dry-run plan generated.")

        def save_metadata_editor_gui(self) -> None:
            path = self.meta_edit_path_var.get().strip()
            if not path:
                messagebox.showinfo(APP_NAME, "Load or enter a media file path first.")
                return
            if not messagebox.askyesno(APP_NAME, "This can write embedded metadata to the selected media file. ExifTool normally creates a FILE_original backup. Continue?"):
                return
            result = metadata_edit_backend(Path(path), self._metadata_editor_fields(), execute=True, confirm=METADATA_CONFIRM_WORD)
            if result.get("ok"):
                db.refresh_metadata_for_path(path, refresh_thumbnail=True)
                self.search_gui()
            self.metadata_output.delete("1.0", "end")
            self.metadata_output.insert("end", json.dumps(result, indent=2))
            self.status_var.set("Metadata save finished." if result.get("ok") else "Metadata save failed or unavailable.")

        def _clean_metadata_path_gui(self, path: str) -> None:
            if not messagebox.askyesno(APP_NAME, "Clean embedded metadata for this file? This can modify the source file and should create a FILE_original backup when ExifTool is available."):
                return
            result = metadata_clean_backend(Path(path), execute=True, confirm=METADATA_CONFIRM_WORD)
            if result.get("ok"):
                db.refresh_metadata_for_path(path, refresh_thumbnail=True)
                self.search_gui()
            if hasattr(self, "metadata_output"):
                self.metadata_output.delete("1.0", "end")
                self.metadata_output.insert("end", json.dumps(result, indent=2))
            messagebox.showinfo(APP_NAME, "Metadata cleaner finished. Review output/status for details.")
            self.status_var.set("Metadata cleaner finished." if result.get("ok") else "Metadata cleaner failed or unavailable.")

        def clean_metadata_editor_gui(self) -> None:
            path = self.meta_edit_path_var.get().strip()
            if not path:
                messagebox.showinfo(APP_NAME, "Load or enter a media file path first.")
                return
            self._clean_metadata_path_gui(path)

        def reindex_metadata_editor_gui(self) -> None:
            path = self.meta_edit_path_var.get().strip()
            if not path:
                messagebox.showinfo(APP_NAME, "Load or enter a media file path first.")
                return
            result = db.refresh_metadata_for_path(path, refresh_thumbnail=True)
            self.metadata_output.delete("1.0", "end")
            self.metadata_output.insert("end", json.dumps(result, indent=2))
            self.search_gui()
            self.status_var.set("Metadata reindexed." if result.get("ok") else "Metadata reindex failed.")

        def metadata_batch_plan_gui(self) -> None:
            folder = filedialog.askdirectory(title="Select folder for metadata batch clean plan")
            if not folder:
                return
            out = METADATA_BATCH_ROOT / f"metadata_batch_clean_plan_{_dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            result = metadata_batch_clean_plan([Path(folder)], include_assets=self.include_assets_var.get(), output=out)
            self.metadata_output.delete("1.0", "end")
            self.metadata_output.insert("end", json.dumps(result, indent=2))
            self.status_var.set(f"Batch metadata clean plan generated: {result.get('count', 0)} files.")

        def metadata_backup_review_gui(self) -> None:
            folder = filedialog.askdirectory(title="Select folder to review ExifTool FILE_original backups")
            if not folder:
                return
            out = METADATA_BACKUP_REVIEW_ROOT / f"metadata_backup_review_{_dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            result = metadata_backup_review(Path(folder), output=out)
            self.metadata_output.delete("1.0", "end")
            self.metadata_output.insert("end", json.dumps(result, indent=2))
            self.status_var.set(f"Metadata backup review complete: {result.get('count', 0)} backups found.")

        def duplicates_gui(self, mode: str) -> None:
            groups = db.duplicates(mode=mode, limit=100)
            self.dupe_output.delete("1.0", "end")
            if not groups:
                self.dupe_output.insert("end", "No duplicate groups found for this mode.\n")
            for g in groups:
                self.dupe_output.insert("end", f"\n[{mode}] {g['count']} items • {fmt_size(g['total_size_bytes'])}\nKey: {g['key']}\n")
                for item in g["items"]:
                    self.dupe_output.insert("end", f"  - {item['path']}\n")
            self.status_var.set(f"Duplicate check complete: {len(groups)} groups.")

        def export_csv_gui(self) -> None:
            out = EXPORT_ROOT / f"media_index_{_dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
            db.export_csv(out, query=self.query_var.get().strip(), media_type=self.type_var.get())
            self.tools_output.insert("end", f"CSV exported: {out}\n")
            self.status_var.set("CSV export complete.")

        def export_json_gui(self) -> None:
            out = EXPORT_ROOT / f"media_index_{_dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            db.export_json(out, query=self.query_var.get().strip(), media_type=self.type_var.get())
            self.tools_output.insert("end", f"JSON exported: {out}\n")
            self.status_var.set("JSON export complete.")

        def export_player_catalogue_gui(self) -> None:
            out = EXPORT_ROOT / f"sentinel_media_player_catalogue_{_dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            path = db.export_player_fast_catalogue(out, query=self.query_var.get().strip(), media_type=self.type_var.get())
            self.tools_output.insert("end", f"Export Player Catalogue complete: {path}\n")
            self.status_var.set("Export Player Catalogue complete.")

        def write_player_catalogue_gui(self) -> None:
            path = db.export_player_fast_catalogue(query=self.query_var.get().strip(), media_type=self.type_var.get())
            self.tools_output.insert("end", f"Default Player Catalogue written: {path}\n")
            self.tools_output.insert("end", f"Secondary player library path: {PLAYER_FAST_CATALOGUE_ALT_PATH}\n")
            self.status_var.set("Default Player Catalogue written for Sentinel Media Player.")

        def backup_gui(self) -> None:
            out = db.backup()
            self.tools_output.insert("end", f"Database backup: {out}\n")
            self.status_var.set("Backup complete.")

        def player_handoff_gui(self) -> None:
            out = PLAYER_ROOT / f"sentinel_player_handoff_{_dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            path = db.export_player_handoff(out, query=self.query_var.get().strip(), media_type=self.type_var.get())
            self.tools_output.insert("end", f"Media Player handoff exported: {path}\n")
            self.status_var.set("Media Player handoff export complete.")

        def m3u_gui(self) -> None:
            out = PLAYER_ROOT / f"sentinel_playlist_{_dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.m3u"
            path = db.export_m3u(out, query=self.query_var.get().strip(), media_type=self.type_var.get())
            self.tools_output.insert("end", f"M3U exported: {path}\n")
            self.status_var.set("M3U export complete.")

        def organisation_report_gui(self) -> None:
            out = ORG_ROOT / f"organisation_report_{_dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            path = db.export_organisation_report(out, query=self.query_var.get().strip(), media_type=self.type_var.get())
            self.tools_output.insert("end", f"Organisation report exported: {path}\n")
            self.status_var.set("Organisation report export complete.")

        def duplicate_report_gui(self, mode: str = "hash") -> None:
            out = ORG_ROOT / f"duplicate_report_{mode}_{_dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            path = db.export_duplicate_report(out, mode=mode)
            self.tools_output.insert("end", f"Duplicate report exported: {path}\n")
            self.status_var.set("Duplicate report export complete.")

        def player_contract_gui(self) -> None:
            out = PLAYER_CONTRACT_ROOT / f"sentinel_media_player_contract_{_dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            path = db.export_player_contract(out)
            self.tools_output.insert("end", f"Media Player contract exported: {path}\n")
            self.status_var.set("Media Player contract export complete.")

        def aegis_gui(self) -> None:
            report = readiness_report(db)
            self.tools_output.delete("1.0", "end")
            self.tools_output.insert("end", json.dumps(report, indent=2))
            self.status_var.set("AEGIS readiness report generated.")

        def mark_missing_gui(self) -> None:
            count = db.mark_missing()
            self.refresh_stats()
            messagebox.showinfo(APP_NAME, f"Marked {count} missing files.")

        def open_path(self, path: Path) -> None:
            path = Path(path)
            target = path if path.is_dir() else path.parent
            try:
                os.system(f'xdg-open "{target}" >/dev/null 2>&1 &')
            except Exception as exc:
                messagebox.showerror(APP_NAME, str(exc))

    app = App()
    app.mainloop()
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="sentinel-media-index",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        description=textwrap.dedent(
            f"""\
            {APP_NAME} v{VERSION} — Program {PROGRAM_ID}
            Media catalogue for images/photos, audio, video, TV shows, eBooks, and collections, with automatic online metadata enrichment during scans unless disabled; system assets excluded and cover art/sidecars used only as enrichment support files.
            """
        ),
    )
    p.add_argument("--version", action="store_true", help="print version")
    p.add_argument("--gui", action="store_true", help="launch GUI")
    p.add_argument("--context-read-metadata", metavar="FILE", help="launch GUI with selected file loaded for metadata read")
    p.add_argument("--context-clean-metadata", metavar="FILE", help="launch GUI with selected file loaded for metadata clean dry-run/confirmation")
    p.add_argument("--context-edit-metadata", metavar="FILE", help="launch GUI with selected file loaded for metadata editing")
    p.add_argument("--context-action-info", metavar="ACTION:FILE", help="print AEGIS-readable context action payload")
    p.add_argument("--install-caja-scripts", action="store_true", help="install per-user MATE/Caja right-click scripts for metadata read/clean/edit")
    p.add_argument("--caja-scripts-target", metavar="DIR", help="override target directory for --install-caja-scripts")
    p.add_argument("--init-db", action="store_true", help="initialize the SQLite database")
    p.add_argument("--scan", metavar="PATH", help="scan a folder recursively; default policy only indexes ~/Documents/eBooks, ~/Videos/Movies, ~/Videos/TV Shows, ~/Pictures unless --include-assets is used")
    p.add_argument("--scan-defaults", action="store_true", help="scan exact approved media folders plus named external/manual locations; no broad /home scan")
    p.add_argument("--scan-default-files", action="store_true", help="alias for --scan-defaults; scans exact default media folders plus approved batch locations")
    p.add_argument("--default-root-policy", action="store_true", help="print the default approved Media Index root policy")
    p.add_argument("--root-policy", action="store_true", help="print expanded approved root policy including named external and manual batch locations")
    p.add_argument("--list-scan-locations", action="store_true", help="list manual batch scan locations and named external roots")
    p.add_argument("--add-scan-location", metavar="PATH", help="add a manual batch scan location")
    p.add_argument("--remove-scan-location", metavar="PATH", help="remove a manual batch scan location")
    p.add_argument("--hash", action="store_true", help="compute SHA256 while scanning")
    p.add_argument("--metadata", action="store_true", help="extract local metadata where supported during scan")
    p.add_argument("--thumbnails", action="store_true", help="generate local thumbnails/previews during scan")
    p.add_argument("--preview", metavar="FILE", help="generate/print a local preview metadata report for one media file")
    p.add_argument("--online-metadata-plan", metavar="FILE", help="build an AEGIS-readable online metadata enrichment plan without network access")
    p.add_argument("--online-metadata", metavar="FILE", help="optionally fetch online metadata/artwork into the index for one already-indexed file")
    p.add_argument("--online-provider", default="auto", choices=ONLINE_PROVIDER_CHOICES, help="provider for --online-metadata/plan")
    p.add_argument("--allow-network", action="store_true", help="explicitly allow one-off online metadata lookups")
    p.add_argument("--no-online-metadata", action="store_true", help="disable automatic online metadata enrichment during scans")
    p.add_argument("--offline", action="store_true", help="alias/safety mode: disable automatic online metadata enrichment during scans")
    p.add_argument("--omdb-api-key", default="", help="OMDb API key for video metadata enrichment; can also use OMDB_API_KEY")
    p.add_argument("--no-online-artwork", action="store_true", help="do not cache online cover/poster artwork during --online-metadata")
    p.add_argument("--metadata-read", metavar="FILE", help="read editable embedded metadata fields where exiftool is available")
    p.add_argument("--metadata-clean", metavar="FILE", help="plan or execute embedded metadata cleaning for one media file")
    p.add_argument("--metadata-edit", metavar="FILE", help="plan or execute embedded metadata edits for one media file")
    p.add_argument("--set", dest="metadata_sets", action="append", default=[], metavar="KEY=VALUE", help="metadata edit field for --metadata-edit; allowed title, artist, album, genre, date, comment, rating")
    p.add_argument("--metadata-batch-clean", action="append", default=[], metavar="PATH", help="create a review-only batch metadata clean plan for one or more files/folders")
    p.add_argument("--metadata-batch-output", metavar="OUTPUT", help="optional output JSON path for --metadata-batch-clean")
    p.add_argument("--metadata-backup-review", metavar="PATH", help="review ExifTool FILE_original backups under a file/folder")
    p.add_argument("--metadata-backup-output", metavar="OUTPUT", help="optional output JSON path for --metadata-backup-review")
    p.add_argument("--metadata-restore-backup", metavar="FILE_original", help="guarded restore of one ExifTool FILE_original backup")
    p.add_argument("--execute", action="store_true", help="execute guarded write-capable metadata actions")
    p.add_argument("--confirm", default="", help="confirmation word for guarded write-capable actions")
    p.add_argument("--reindex-file", metavar="FILE", help="refresh indexed metadata/thumb for one already-indexed file")
    p.add_argument("--categorized", action="store_true", help="group search JSON output into clearly marked categories")
    p.add_argument("--tag-file", metavar="PATH", help="add a tag to an already-indexed file")
    p.add_argument("--tag-name", metavar="TAG", help="tag name for --tag-file")
    p.add_argument("--list-tags", action="store_true", help="list tags")
    p.add_argument("--collection", metavar="NAME", help="collection name for collection operations")
    p.add_argument("--collection-add", metavar="PATH", help="add an indexed file to --collection")
    p.add_argument("--list-collections", action="store_true", help="list collections")
    p.add_argument("--player-handoff", metavar="OUTPUT", help="export Sentinel Media Player handoff JSON")
    p.add_argument("--player-library", metavar="OUTPUT", help="export structured Sentinel Media Player library JSON with visual-board/cabinet data")
    p.add_argument("--player-fast-catalogue", metavar="OUTPUT", help="export fast flat Program 119 player catalogue JSON")
    p.add_argument("--write-player-catalogue", action="store_true", help="write default fast Program 119 player catalogue JSON for the Media Player")
    p.add_argument("--player-catalogue-status", action="store_true", help="print fast player catalogue contract status")
    p.add_argument("--propose-renames", nargs="?", const="", metavar="OUTPUT", help="dry-run movie filename cleanup proposals; optional JSON output path")
    p.add_argument("--apply-renames", metavar="PLAN", help="apply a reviewed rename proposal JSON with --execute --confirm RENAME_MEDIA")
    p.add_argument("--undo-last-rename", action="store_true", help="undo the most recent rename manifest with --execute --confirm UNDO_RENAME")
    p.add_argument("--rename-status", action="store_true", help="print movie rename engine/status JSON")
    p.add_argument("--visual-board", metavar="OUTPUT", help="export visual media cabinet board JSON for Sentinel Media Player")
    p.add_argument("--m3u", metavar="OUTPUT", help="export playable audio/video search results as M3U")
    p.add_argument("--player-contract", metavar="OUTPUT", help="export Sentinel Media Player v1 handoff contract JSON")
    p.add_argument("--duplicate-report", metavar="OUTPUT", help="export advanced duplicate report as JSON or Markdown")
    p.add_argument("--organisation-report", "--organization-report", dest="organisation_report", metavar="OUTPUT", help="export media library organisation report as JSON or Markdown")
    p.add_argument("--follow-symlinks", action="store_true", help="follow symbolic links while scanning")
    p.add_argument("--include-assets", action="store_true", help="include system icon/theme/cache/assets folders that are excluded by default")
    p.add_argument("--search", metavar="QUERY", default=None, help="search indexed items")
    p.add_argument("--type", default="all", choices=SCAN_TYPE_CHOICES, help="filter media type")
    p.add_argument("--limit", type=int, default=200, help="result limit")
    p.add_argument("--duplicates", action="store_true", help="show duplicate groups")
    p.add_argument("--mode", default="hash", choices=["hash", "name_size"], help="duplicate mode")
    p.add_argument("--stats", action="store_true", help="show index statistics")
    p.add_argument("--mark-missing", action="store_true", help="mark indexed files that no longer exist")
    p.add_argument("--export-csv", metavar="OUTPUT", help="export index/search results to CSV")
    p.add_argument("--export-json", metavar="OUTPUT", help="export index/search results to JSON")
    p.add_argument("--backup", action="store_true", help="backup the SQLite database")
    p.add_argument("--aegis-status", action="store_true", help="print AEGIS-readable status JSON")
    p.add_argument("--readiness", action="store_true", help="print readiness report JSON")
    p.add_argument("--aegis-actions", action="store_true", help="print AEGIS action contract JSON")
    p.add_argument("--final-audit", nargs="?", const="", metavar="OUTPUT", help="generate final non-mutating v1 readiness audit report; optional output path")
    p.add_argument("--stable-lock-report", nargs="?", const="", metavar="OUTPUT", help="generate non-mutating Program 118 v1.0.0 stable-lock report; optional output path")
    p.add_argument("--json", action="store_true", help="JSON output where applicable")
    return p


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    db = MediaIndexDB()
    if args.version:
        print(f"{APP_NAME} v{VERSION}")
        return 0
    if args.context_action_info:
        try:
            action, file_path = args.context_action_info.split(":", 1)
        except ValueError:
            print_json({"ok": False, "error": "expected ACTION:FILE"})
            return 2
        print_json(context_action_payload(action, Path(file_path)))
        return 0
    if args.install_caja_scripts:
        target = Path(args.caja_scripts_target).expanduser() if args.caja_scripts_target else None
        print_json(install_caja_scripts(target))
        return 0
    if args.context_read_metadata:
        return run_gui("read", args.context_read_metadata)
    if args.context_clean_metadata:
        return run_gui("clean", args.context_clean_metadata)
    if args.context_edit_metadata:
        return run_gui("edit", args.context_edit_metadata)
    if args.gui:
        return run_gui()
    if args.init_db:
        db.init()
        result = {"ok": True, "db_path": str(DB_PATH), "version": VERSION}
        print_json(result) if args.json else print(f"Initialized {DB_PATH}")
        return 0
    if args.default_root_policy or args.root_policy:
        result = default_root_policy_report()
        print_json(result) if args.json else print(json.dumps(result, indent=2))
        return 0
    if args.list_scan_locations:
        result = scan_root_policy_report()
        print_json(result) if args.json else print(json.dumps(result, indent=2))
        return 0
    if args.add_scan_location:
        result = add_manual_scan_location(Path(args.add_scan_location))
        print_json(result) if args.json else print(json.dumps(result, indent=2))
        return 0
    if args.remove_scan_location:
        result = remove_manual_scan_location(Path(args.remove_scan_location))
        print_json(result) if args.json else print(json.dumps(result, indent=2))
        return 0
    if args.scan_defaults or getattr(args, "scan_default_files", False):
        result = scan_default_roots(hash_enabled=args.hash, follow_symlinks=args.follow_symlinks, extract_metadata=args.metadata, thumbnails=args.thumbnails, db=db, include_assets=args.include_assets, auto_online_metadata=not (args.no_online_metadata or args.offline), online_provider=args.online_provider, omdb_api_key=args.omdb_api_key, download_online_artwork=not args.no_online_artwork)
        print_json(result) if args.json else print(f"Indexed {result['totals']['media_indexed']} media files from default roots ({result['totals']['errors']} errors)")
        return 0
    if args.scan:
        result = scan_directory(Path(args.scan), hash_enabled=args.hash, follow_symlinks=args.follow_symlinks, extract_metadata=args.metadata, thumbnails=args.thumbnails, db=db, include_assets=args.include_assets, auto_online_metadata=not (args.no_online_metadata or args.offline), online_provider=args.online_provider, omdb_api_key=args.omdb_api_key, download_online_artwork=not args.no_online_artwork)
        print_json(result) if args.json else print(f"Indexed {result['media_indexed']} media files from {result['root_path']} ({result['errors']} errors)")
        return 0
    if args.preview:
        result = preview_report_for(Path(args.preview), make_thumbnail=True)
        print_json(result) if args.json else print(json.dumps(result, indent=2))
        return 0
    if args.online_metadata_plan:
        row = db.get_item_by_path(args.online_metadata_plan)
        if not row:
            print_json({"ok": False, "error": "media_not_indexed", "path": safe_realpath(Path(args.online_metadata_plan))})
            return 2
        print_json(online_metadata_plan_for_row(row, provider=args.online_provider))
        return 0
    if args.online_metadata:
        result = db.online_enrich_path(args.online_metadata, provider=args.online_provider, allow_network=args.allow_network, omdb_api_key=args.omdb_api_key, download_artwork=not args.no_online_artwork)
        print_json(result) if args.json else print(json.dumps(result, indent=2))
        return 0
    if args.metadata_read:
        result = metadata_read_backend(Path(args.metadata_read))
        print_json(result) if args.json else print(json.dumps(result, indent=2))
        return 0
    if args.metadata_clean:
        result = metadata_clean_backend(Path(args.metadata_clean), execute=args.execute, confirm=args.confirm)
        if result.get("ok") and args.execute:
            db.refresh_metadata_for_path(args.metadata_clean, refresh_thumbnail=True)
        print_json(result) if args.json else print(json.dumps(result, indent=2))
        return 0
    if args.metadata_edit:
        try:
            fields = parse_metadata_set(args.metadata_sets)
        except ValueError as exc:
            print_json({"ok": False, "error": str(exc)})
            return 2
        result = metadata_edit_backend(Path(args.metadata_edit), fields, execute=args.execute, confirm=args.confirm)
        if result.get("ok") and args.execute:
            db.refresh_metadata_for_path(args.metadata_edit, refresh_thumbnail=True)
        print_json(result) if args.json else print(json.dumps(result, indent=2))
        return 0
    if args.metadata_batch_clean:
        targets = [Path(x) for x in args.metadata_batch_clean]
        output = Path(args.metadata_batch_output) if args.metadata_batch_output else None
        result = metadata_batch_clean_plan(targets, include_assets=args.include_assets, output=output)
        print_json(result) if args.json else print(json.dumps(result, indent=2))
        return 0
    if args.metadata_backup_review:
        output = Path(args.metadata_backup_output) if args.metadata_backup_output else None
        result = metadata_backup_review(Path(args.metadata_backup_review), output=output)
        print_json(result) if args.json else print(json.dumps(result, indent=2))
        return 0
    if args.metadata_restore_backup:
        result = metadata_restore_backup_backend(Path(args.metadata_restore_backup), execute=args.execute, confirm=args.confirm)
        print_json(result) if args.json else print(json.dumps(result, indent=2))
        return 0
    if args.reindex_file:
        result = db.refresh_metadata_for_path(args.reindex_file, refresh_thumbnail=args.thumbnails)
        print_json(result) if args.json else print(json.dumps(result, indent=2))
        return 0
    if args.tag_file:
        if not args.tag_name:
            print_json({"ok": False, "error": "--tag-name is required with --tag-file"})
            return 2
        print_json(db.add_tag(args.tag_file, args.tag_name))
        return 0
    if args.list_tags:
        print_json({"tags": db.list_tags(), "generated_at": utc_now()})
        return 0
    if args.collection_add:
        if not args.collection:
            print_json({"ok": False, "error": "--collection is required with --collection-add"})
            return 2
        print_json(db.add_to_collection(args.collection, args.collection_add))
        return 0
    if args.list_collections:
        print_json({"collections": db.list_collections(), "generated_at": utc_now()})
        return 0
    if args.rename_status:
        print_json(rename_status_payload(db))
        return 0
    if args.propose_renames is not None:
        output = Path(args.propose_renames).expanduser() if args.propose_renames else (RENAME_ROOT / "rename_proposals_latest.json")
        payload = propose_movie_renames(db, output=output)
        print_json(payload) if args.json else print(output)
        return 0
    if args.apply_renames:
        payload = apply_movie_renames(db, Path(args.apply_renames), execute=args.execute, confirm=args.confirm)
        print_json(payload) if args.json else print(json.dumps(payload, indent=2))
        return 0
    if args.undo_last_rename:
        payload = undo_last_rename(db, execute=args.execute, confirm=args.confirm)
        print_json(payload) if args.json else print(json.dumps(payload, indent=2))
        return 0
    if args.player_catalogue_status:
        print_json(db.player_fast_catalogue_status())
        return 0
    if args.write_player_catalogue:
        out = db.export_player_fast_catalogue(query=args.search or "", media_type=args.type, collection=args.collection or "")
        print_json({"ok": True, "player_fast_catalogue": str(out), "contract_version": PLAYER_FAST_CONTRACT_VERSION}) if args.json else print(out)
        return 0
    if args.player_fast_catalogue:
        out = db.export_player_fast_catalogue(Path(args.player_fast_catalogue), query=args.search or "", media_type=args.type, collection=args.collection or "")
        print_json({"ok": True, "player_fast_catalogue": str(out), "contract_version": PLAYER_FAST_CONTRACT_VERSION}) if args.json else print(out)
        return 0
    if args.player_library:
        out = db.export_player_library(Path(args.player_library), query=args.search or "", media_type=args.type, collection=args.collection or "")
        print_json({"ok": True, "player_library": str(out), "contract_version": "sentinel_media_player_library_v2"}) if args.json else print(out)
        return 0
    if args.visual_board:
        payload = db.player_library_payload(query=args.search or "", media_type=args.type, collection=args.collection or "")
        out = _ensure_safe_output_path(Path(args.visual_board), role="visual_board_export")
        _safe_write_text(out, json.dumps({"program": APP_NAME, "version": VERSION, "visual_board": payload.get("visual_board", {}), "generated_at": utc_now(), "local_only": True}, indent=2), role="visual_board_export")
        print_json({"ok": True, "visual_board": str(out), "contract_version": "sentinel_media_player_library_v2"}) if args.json else print(out)
        return 0
    if args.player_handoff:
        out = db.export_player_handoff(Path(args.player_handoff), query=args.search or "", media_type=args.type, collection=args.collection or "")
        print_json({"ok": True, "player_handoff": str(out)}) if args.json else print(out)
        return 0
    if args.m3u:
        out = db.export_m3u(Path(args.m3u), query=args.search or "", media_type=args.type, collection=args.collection or "")
        print_json({"ok": True, "m3u": str(out)}) if args.json else print(out)
        return 0
    if args.player_contract:
        out = db.export_player_contract(Path(args.player_contract))
        print_json({"ok": True, "player_contract": str(out), "contract_version": "sentinel_media_player_library_v2"}) if args.json else print(out)
        return 0
    if args.duplicate_report:
        out = db.export_duplicate_report(Path(args.duplicate_report), mode=args.mode, limit=args.limit)
        print_json({"ok": True, "duplicate_report": str(out), "mode": args.mode}) if args.json else print(out)
        return 0
    if args.organisation_report:
        out = db.export_organisation_report(Path(args.organisation_report), query=args.search or "", media_type=args.type, limit=args.limit)
        print_json({"ok": True, "organisation_report": str(out)}) if args.json else print(out)
        return 0
    if args.search is not None:
        db.init()
        if args.categorized:
            grouped = db.categorized_search(query=args.search, media_type=args.type, limit=args.limit)
            print_json({"count": sum(len(v) for v in grouped.values()), "categories": grouped})
        else:
            rows = db.search(query=args.search, media_type=args.type, limit=args.limit)
            if args.json:
                print_json({"count": len(rows), "items": rows})
            else:
                for r in rows:
                    print(f"{r['media_type']:8} {fmt_size(r['size_bytes']):>10}  {r['path']}")
        return 0
    if args.duplicates:
        db.init()
        groups = db.duplicates(mode=args.mode, limit=args.limit)
        if args.json:
            print_json({"mode": args.mode, "groups": groups})
        else:
            for g in groups:
                print(f"\n{g['count']} items • {fmt_size(g['total_size_bytes'])} • {g['key']}")
                for item in g["items"]:
                    print(f"  {item['path']}")
        return 0
    if args.stats:
        db.init()
        stats = db.stats()
        print_json(stats) if args.json else print(textwrap.dedent(f"""
            {APP_NAME} v{VERSION}
            Database: {stats['db_path']}
            Items: {stats['total_items']} present={stats['present_items']} missing={stats['missing_items']}
            Size: {fmt_size(stats['total_size_bytes'])}
            Types: {stats['by_type']}
        """).strip())
        return 0
    if args.mark_missing:
        db.init()
        count = db.mark_missing()
        print_json({"marked_missing": count}) if args.json else print(f"Marked missing: {count}")
        return 0
    if args.export_csv:
        db.init()
        out = db.export_csv(Path(args.export_csv), query=args.search or "", media_type=args.type)
        print_json({"export": str(out)}) if args.json else print(out)
        return 0
    if args.export_json:
        db.init()
        out = db.export_json(Path(args.export_json), query=args.search or "", media_type=args.type)
        print_json({"export": str(out)}) if args.json else print(out)
        return 0
    if args.backup:
        out = db.backup()
        print_json({"backup": str(out)}) if args.json else print(out)
        return 0
    if args.final_audit is not None:
        default = AUDIT_ROOT / f"sentinel_media_index_v{VERSION.replace('.', '_')}_final_audit.json"
        output = Path(args.final_audit) if args.final_audit else default
        result = final_audit_report(db, output=output)
        print_json(result) if args.json else print(output)
        return 0
    if args.stable_lock_report is not None:
        default = AUDIT_ROOT / f"sentinel_media_index_v{VERSION.replace('.', '_')}_stable_lock.json"
        output = Path(args.stable_lock_report) if args.stable_lock_report else default
        result = stable_lock_report(db, output=output)
        print_json(result) if args.json else print(output)
        return 0
    if args.aegis_status or args.readiness:
        print_json(readiness_report(db))
        return 0
    if args.aegis_actions:
        print_json(aegis_actions())
        return 0
    # Default behavior: GUI if interactive, otherwise stats.
    if sys.stdout.isatty() and "DISPLAY" in os.environ:
        return run_gui()
    db.init()
    print_json(readiness_report(db))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
