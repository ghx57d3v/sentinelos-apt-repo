# Sentinel Media Index v1.0.1

Program 118 of the Sentinel Desktop Suite.

Sentinel Media Index is the stable-locked catalogue authority for Sentinel Media Player. It indexes user media, enriches metadata/artwork, maintains tags and collections, exports Program 119 library contracts, and keeps system icons/assets out of the user-facing catalogue by default.

## Stable-lock status

- Version: v1.0.1
- Status: stable locked
- Program: 118
- Default catalogue authority for: Program 119 Sentinel Media Player

## Core features

- Local SQLite media catalogue
- Audio, video, TV/series, eBook, image/photo and collection support
- System icons, desktop assets, app assets, cache thumbnails, and generic asset folders excluded by default
- Cover/poster/folder art used as enrichment, not standalone clutter
- Search / Categories tab with compact rows and a widened Thumb column header
- Thumbnails, previews, metadata pane and dashboard cards
- Automatic online metadata enrichment during scans for audio/video/eBooks, with `--offline` / `--no-online-metadata` opt-outs
- ExifTool-backed metadata cleaner/editor with guarded write confirmation
- Caja/MATE right-click metadata actions
- Duplicate, organisation and final audit reports
- Program 119 exports: player library, visual board, handoff and contract JSON
- AEGIS status/actions and stable-lock report

## Safety posture

Normal scans and exports do not modify source media. Metadata clean/edit/restore actions are the only source-write workflows and require explicit guarded confirmation.

## Useful commands

```bash
sentinel-media-index --gui
sentinel-media-index --scan ~/Media --metadata --thumbnails --json
sentinel-media-index --scan ~/Media --offline --json
sentinel-media-index --search "" --categorized --json
sentinel-media-index --player-library ~/player_library.json --json
sentinel-media-index --visual-board ~/visual_board.json --json
sentinel-media-index --player-contract ~/player_contract.json --json
sentinel-media-index --final-audit ~/final_audit.json --json
sentinel-media-index --stable-lock-report ~/stable_lock.json --json
sentinel-media-index --aegis-status
sentinel-media-index --aegis-actions
```


## v1.0.3 Movie Rename / Metadata Match / Clean Catalogue Patch

Adds dry-run movie rename proposals, guarded apply/undo manifests, and clean rename metadata fields in the Program 119 fast player catalogue. The default movie format is `Movie Title (Year).ext`. Renaming is controlled by Sentinel Media Index, while Sentinel Media Player only reflects rename status and can launch the proposal workflow.


## v1.0.3 GUI patch

The Export / AEGIS / Player tab has a two-row button layout and includes `Export Player Catalogue` and `Write Player Catalogue`. The Scan tab includes `Stop Scan` for safe scan cancellation.
