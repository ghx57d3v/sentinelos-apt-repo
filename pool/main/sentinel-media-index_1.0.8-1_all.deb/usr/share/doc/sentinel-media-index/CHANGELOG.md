# Changelog

## 1.0.6
- Added Manual tab.
- Added Sentinel Jobs-style hero/sidebar/card GUI treatment.
- Changed default scan roots to exact media folders only.
- Added `--scan-default-files` alias.
- Blocked broad `/home`/whole-home scan contexts by default.
