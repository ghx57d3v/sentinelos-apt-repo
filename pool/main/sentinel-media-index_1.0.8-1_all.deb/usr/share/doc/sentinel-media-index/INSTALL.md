# Install

```bash
sudo apt install ./sentinel-media-index_1.0.3-1_all.deb
```
