# Sentinel Media Index v1.0.7 Build Notes

GUI/root-policy hotfix over v1.0.6. Adds Open Media Player sidebar action, blocks legacy broad manual scan roots from effective Scan Default Files, and rejects direct /home/$HOME/Documents/Videos/Music/Desktop/Downloads additions.
