# Sentinel Media Index v1.0.7

- Open Media Player button added to sidebar.
- Broad saved roots such as /home/stephen, $HOME, ~/Documents, ~/Videos, ~/Music, Desktop, and Downloads are ignored by Scan Default Files.
- Add Batch Location now rejects broad home/system roots and asks for exact media folders.
- Scan Default Files remains limited to ~/Documents/eBooks, ~/Videos/Movies, ~/Videos/TV Shows, ~/Pictures plus approved named external/manual exact locations.
