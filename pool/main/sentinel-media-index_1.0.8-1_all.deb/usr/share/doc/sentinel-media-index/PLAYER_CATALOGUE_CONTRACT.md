# Sentinel Media Index v1.0.1 Player Catalogue Contract

Adds a fast flat Program 119 catalogue export for Sentinel Media Player.

Default outputs:

- `~/.local/share/sentinel-media-index/player_catalogue.json`
- `~/.local/share/sentinel-media-index/player_libraries/sentinel_media_player_catalogue.json`

Commands:

```bash
sentinel-media-index --write-player-catalogue --json
sentinel-media-index --player-fast-catalogue /tmp/player_catalogue.json --json
sentinel-media-index --player-catalogue-status --json
```

The player should read this JSON first and only fall back to raw SQLite/CSV/JSON discovery if the fast catalogue is absent.


## v1.0.2 Movie Rename / Metadata Match / Clean Catalogue Patch

Adds dry-run movie rename proposals, guarded apply/undo manifests, and clean rename metadata fields in the Program 119 fast player catalogue. The default movie format is `Movie Title (Year).ext`. Renaming is controlled by Sentinel Media Index, while Sentinel Media Player only reflects rename status and can launch the proposal workflow.
