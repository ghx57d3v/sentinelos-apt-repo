# Security

Sentinel Media Index is local-first and does not send telemetry.

Automatic online metadata enrichment can run during scans for supported audio/video/eBook entries. Use `--offline` or `--no-online-metadata` to disable it. Online enrichment updates the local catalogue only and does not modify source media.

Metadata write operations are guarded:

- `MODIFY_METADATA` for clean/edit operations
- `RESTORE_METADATA_BACKUP` for ExifTool backup restore

System icons, desktop assets, app assets, cache thumbnails, generic asset folders and standalone support artwork are excluded from the visible library by default.
