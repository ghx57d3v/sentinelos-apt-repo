# SentinelOS v0.1.6b — Desktop Suite v1 Baseline Amendment

## Purpose

v0.1.6b amends the controlled Desktop Suite integration baseline using the newly supplied v1+ tool artifacts.

This patch:

- installs the canonical uploaded Terminal baseline package `sentinel-terminal_1.0.0-1_all.deb`;
- amends Program 106 to prefer canonical package `sentinel-terminal` over the legacy `sentinel-terminal-v1-0-1` adoption path;
- upgrades Program 102 Sentinel Notes from “built v0.8.5 / v1 lock not confirmed” to `Completed / v1.0.0`;
- integrates additional v1+ tools: Notes, System Monitor, Password Vault, and Pantry;
- keeps Ledger held because the uploaded Ledger ZIP did not contain a `.deb` package;
- keeps AEGIS runtime disabled and does not install AI models.

## Integrated packages in this pass

| Program | Package | Version | Decision |
|---:|---|---:|---|
| 102 | sentinel-notes | 1.0.0-1 | Accepted |
| 106 | sentinel-terminal | 1.0.0-1 | Accepted as canonical Terminal baseline |
| 108 | sentinel-system-monitor | 1.0.1-1 | Accepted |
| 113 | sentinel-password-vault | 1.0.0-1 | Accepted after script audit |
| 117 | sentinel-pantry | 1.0.0-1 | Accepted |

## Held

| Program | Artifact | Reason |
|---:|---|---|
| 107 | sentinel_ledger_v1_0_0(1).zip | Uploaded archive did not contain a `.deb` package. Source was present, but OS integration needs either the Debian package artifact or a separate explicit build decision. |

## Safety scope

This patch does not:

- enable AEGIS runtime;
- install AI models;
- install pending/planned apps;
- change MATE desktop settings;
- alter hardening;
- overwrite Debian `/etc/os-release`;
- perform app data migration.

The installer removes the legacy `sentinel-terminal-v1-0-1` package if present before installing the canonical `sentinel-terminal` package, to prevent dpkg file ownership conflicts and to make Program 106 package identity clean.
