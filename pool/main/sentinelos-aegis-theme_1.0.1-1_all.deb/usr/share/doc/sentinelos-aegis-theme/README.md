# AEGIS Navy/Gold Desktop Theme

Theme: `AEGIS-Navy-Gold`  
Icons: `SentinelOS-Dark`  
Cursor: `SentinelOS-Cursor-AEGIS-Navy-Gold`

The package is conditional on the public AEGIS suite and is passive at install
time. It does not modify live user settings or wallpaper.

Apply as the desktop user:

```bash
sentinelos-aegis-theme --apply --confirm APPLY_AEGIS_DESKTOP_THEME
```

Restore:

```bash
sentinelos-aegis-theme --restore-latest --confirm RESTORE_AEGIS_DESKTOP_THEME
```

## v1.0.1 cursor schema hotfix

Current MATE exposes GTK and icon selections through `org.mate.interface` but
uses `org.gnome.desktop.interface cursor-theme` for the pointer theme. The
controller now treats that GNOME key as canonical and any MATE cursor key as
optional compatibility only.

Repair an already partially applied desktop with:

```bash
sentinelos-aegis-theme --repair-cursor
```
