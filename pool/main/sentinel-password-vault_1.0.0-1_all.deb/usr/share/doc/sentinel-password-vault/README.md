# Sentinel Password Vault v1.0.0 — Program 113

Stable lock build for the SentinelOS local encrypted password vault.

## Locked baseline
- Local-first encrypted password vault
- AES-256-GCM encrypted vault file
- PBKDF2-HMAC-SHA256 master-password key derivation
- Passwords, notes, metadata, and TOTP/2FA records stored encrypted
- No cloud sync, no telemetry, no network dependency
- GUI, CLI, AEGIS JSON actions, doctor, repair, user setup, Debian package
- Sentinel Browser save/update provider endpoints
- Sentinel Browser 2FA provider and vault-owned browser 2FA popup receiver
- AEGIS Vault encrypted backup/restore support

## Install
```bash
sudo ./install.sh --system --clean-shadow
sentinel-password-vault-user-setup --clean-shadow
hash -r
sentinel-password-vault --version
sentinel-password-vault --self-check
sentinel-password-vault --stable-lock-report --no-unlock
sentinel-password-vault-doctor
```

## Browser 2FA popup command
```bash
sentinel-password-vault-browser-2fa-popup --browser-origin "$CURRENT_URL"
```

## Data preservation
Normal package reinstall/update must preserve user data under `~/.local/share/sentinel-password-vault/`.
Use AEGIS encrypted backup before major repairs or migration.
