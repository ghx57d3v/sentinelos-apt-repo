# Changelog — Sentinel Password Vault

## v1.0.0 — Stable Lock Build
- Locks Program 113 as the v1.0 SentinelOS Desktop Suite baseline.
- Adds `--stable-lock-report` and AEGIS `stable_lock_report`.
- Confirms browser save/update provider and browser 2FA popup receiver remain part of the locked contract.
- Fixes source installer parity by installing browser wrapper commands with `install.sh`, not only through the `.deb`.
- Preserves all v0.9.9.3 browser popup visible button work and prior v0.9.x security features.
