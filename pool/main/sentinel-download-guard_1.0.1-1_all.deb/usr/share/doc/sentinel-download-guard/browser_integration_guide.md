# Sentinel Download Guard Browser Integration Guide v1.0.0-rc18

## Browser-first model

For v1, Sentinel Browser owns active WebKit downloads. Download Guard must not be called repeatedly during live transfer.

Sequence:

1. Browser downloads to local staging/handoff storage.
2. Browser shows active progress and owns cancel action, similar to Firefox/Chrome.
3. After WebKit reports completion, Browser starts a background handoff.
4. Download Guard imports the completed file with `--import-completed-download`.
5. User reviews, releases, or abandons the quarantined item.

Active cancel queue APIs are retained for future experiments but are disabled by default for the v1 Browser path.
