# Sentinel Download Guard v1.0.0-rc18

Phase 5B browser-first download UX backend correction.

Download Guard is a post-completion quarantine/review/release backend. Browser owns live transfer/progress/cancel. The normal Browser handoff command is now:

```bash
sentinel-download-guard --import-completed-download --file FILE --source-url URL --suggested-filename NAME
```

`--browser-handoff` and `--register-download` remain compatible aliases. Active cancel APIs are retained for future/experimental use but are not part of the default v1 Browser hot path.

AEGIS integration is optional advisory status only; this package is expected to run on clean Debian with declared dependencies.


## v1.0.0-rc18 RC3-based v1 security gate

RC18 is built from the confirmed-good RC3 base, not from RC4/RC5. It preserves browser-first active downloads and Download Guard post-completion quarantine/review/release, while adding clean Debian independence and private-directory/security gate checks. No AEGIS/Sentinel Command runtime is required.

## v1.0.0-rc18
- Compatible backend bump for Sentinel Browser rc18 bookmarks/security-controls polish.
- No change to active transfer model: Browser owns live downloads; Download Guard imports completed files only.
