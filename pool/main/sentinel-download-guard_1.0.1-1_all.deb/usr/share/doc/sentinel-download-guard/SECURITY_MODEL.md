# Sentinel Download Guard v1.0.0-rc18 Security Model

- Local-first quarantine backend.
- No telemetry.
- No cloud scanning.
- Never auto-open downloads.
- Browser owns live WebKit download objects.
- Download Guard owns quarantine/release/delete/cancel queue state.
- AEGIS status is advisory only and does not release, execute, or delete files autonomously.
- Dangerous release paths such as `/`, `/usr`, `/bin`, `/sbin`, `/etc`, `/var`, and `/root` are blocked.
- Risky file types require explicit review/release.
