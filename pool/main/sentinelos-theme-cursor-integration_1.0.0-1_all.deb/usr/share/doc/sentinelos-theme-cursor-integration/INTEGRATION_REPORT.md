# SentinelOS Theme/Cursor Integration v1.0.0

## Purpose

Attach the original SentinelOS cursor variants to the respective MATE
desktop-theme colour identities.

## Binding rule

The binding is written to the desktop theme's `[X-GNOME-Metatheme]`
`CursorTheme` field. MATE Appearance can therefore treat GTK, Marco, icons and
cursor as one appearance selection.

The session synchronizer also aligns the current cursor from the active
`org.mate.interface gtk-theme` value. This supports selector workflows that
set GTK/Marco/icon keys directly rather than applying a complete MATE
metatheme.

## Base mapping

- Light Cyan → Light Cyan cursor
- Dark Cyan → Light Cyan cursor
- Light Green → Light Green cursor
- Light Purple → Light Purple cursor
- Dark Red → Dark Red cursor
- Dark Pink → Dark Pink cursor

## Neutral options

White and Black remain manual cursor choices pending corresponding official
desktop themes.

## AEGIS boundary

Navy/Gold is not included. It will be bundled with and selected by the
exclusive AEGIS Sentinel Suite desktop theme only.
