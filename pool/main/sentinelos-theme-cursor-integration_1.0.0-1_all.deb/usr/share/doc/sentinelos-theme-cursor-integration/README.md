# SentinelOS Theme/Cursor Integration

This package binds each official base desktop theme to its matching cursor
theme.

## Authoritative mappings

| Desktop theme | Cursor theme |
|---|---|
| `SentinelOS-Light-Cyan` | `SentinelOS-Cursor-Light-Cyan` |
| `SentinelOS-Dark-Cyan` | `SentinelOS-Cursor-Light-Cyan` |
| `SentinelOS-Light-Green` | `SentinelOS-Cursor-Light-Green` |
| `SentinelOS-Light-Purple` | `SentinelOS-Cursor-Light-Purple` |
| `SentinelOS-Dark-Red` | `SentinelOS-Cursor-Dark-Red` |
| `SentinelOS-Dark-Pink` | `SentinelOS-Cursor-Dark-Pink` |

White and Black remain neutral user-selectable cursor options because no
official White or Black desktop environments are currently part of the locked
SentinelOS theme family.

The AEGIS Navy/Gold mapping is deliberately excluded. It must be supplied
inside the exclusive AEGIS Sentinel Suite desktop-theme package.

## Install and apply

```bash
sudo apt install ./sentinelos-theme-cursor-integration_1.0.0-1_all.deb

sudo sentinelos-theme-cursor-integration   --apply-bindings   --confirm APPLY_SENTINELOS_CURSOR_BINDINGS

sentinelos-theme-cursor-integration --sync-current
sentinelos-theme-cursor-integration --current
sudo sentinelos-theme-cursor-integration --verify
```

The binding step amends only the `CursorTheme` value in the installed MATE
metatheme metadata. It creates restorable backups first.

## Restore package-owned theme metadata

```bash
sudo sentinelos-theme-cursor-integration   --restore-bindings   --confirm RESTORE_SENTINELOS_CURSOR_BINDINGS
```

## Safety

- no live theme change during package installation;
- explicit confirmation required to edit system theme metadata;
- live session sync refuses root;
- wallpaper/background keys are never modified;
- missing optional themes are skipped rather than created;
- AEGIS Gold/Navy remains outside the base package.
