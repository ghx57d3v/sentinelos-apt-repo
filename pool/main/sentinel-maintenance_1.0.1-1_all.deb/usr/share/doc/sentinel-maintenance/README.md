# Sentinel Maintenance v1.0.1

Program 114 — Sentinel Maintenance

## Status

Security Audit Hotfix over v1.0.0 Stable Lock / User-Ready Baseline.

## v1.0.1 hotfixes

- Hardened local database, backup, export, bridge, and AEGIS handoff file permissions to private `0600` files and private `0700` app-owned runtime directories where practical.
- Added CSV/spreadsheet formula-injection protection for table exports, Ledger bridge exports, Inventory bridge exports, and AEGIS handoff CSVs.
- Switched backup verification and restore preview to read-only SQLite connections.
- Added backup filename collision protection using microsecond timestamps and unique-path fallback.
- Fixed checksum manifest duplicate entries when bridge files are also under the exports tree.
- Hardened JSON sidecar/export writing and backup checksum sidecars to private file creation.
- Added AEGIS `verify_backup` path validation instead of accidentally checking the current directory when `--path` is omitted.

## v1.0.0 locked baseline preserved

- Local SQLite asset registry for household, workshop, vehicle, device, appliance, tool, and off-grid equipment records.
- Auto-generated Asset IDs and selected-asset autofill across Service Log, Reminders, Parts, and Documents.
- Service and repair history with parts used, cost, provider, receipt, notes, and next-service tracking.
- Service Queue plus recurring Service Plans & Templates.
- Parts, Documents, and Warranty Center.
- Inspections & Fault Register with condition tracking and Needs Service escalation.
- Costs & Bridges for Sentinel Ledger and Sentinel Inventory handoff.
- Recovery & Integrity tab and CLI workflows: integrity check, backup verification, restore preview, checksum manifest, compact/repair, audit log export.
- Manual & Status tab, first-run setup helper, self-test, completion report, and stable-lock report.
- Stable AEGIS JSON contract and handoff export.
- Sentinel Desktop Suite AEGIS Dark / Sentinel Gold theme.
- Wide tab-fit window: 1680x900 default, 1280x760 minimum.
- Desktop/menu launcher, icon, desktop launcher helper, repair launcher helper, and Ctrl+Q close.
- Local-only / no network / no telemetry posture.

## Install

```bash
sudo apt install ./sentinel-maintenance_1.0.1-1_all.deb
```

## Launch

```bash
sentinel-maintenance
```

## Useful commands

```bash
sentinel-maintenance --health-check
sentinel-maintenance --summary
sentinel-maintenance --status
sentinel-maintenance --self-test
sentinel-maintenance stable-lock-report
sentinel-maintenance completion-report
sentinel-maintenance aegis stable_lock_report
```

## Desktop launcher

```bash
sentinel-maintenance-install-desktop-launcher
sentinel-maintenance-repair-launcher
```
