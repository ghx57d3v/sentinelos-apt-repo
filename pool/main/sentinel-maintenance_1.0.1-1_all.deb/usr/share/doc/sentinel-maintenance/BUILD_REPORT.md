# Sentinel Maintenance v1.0.1 Security Hotfix Build Report

## Release

Program 114 — Sentinel Maintenance v1.0.1 security audit hotfix over the v1.0.0 stable lock.

## Built from

Uploaded `sentinel_maintenance_v1_0_0(2).zip`.

## Redteam result

No critical RCE, shell injection, network/telemetry, package path traversal, or archive symlink issue was found.

## v1.0.1 fixes

- CSV/spreadsheet formula-injection hardening for all CSV export paths.
- Private runtime data permissions for app-owned directories and generated local files.
- Read-only SQLite verification for backup verify and restore preview workflows.
- Backup filename collision prevention with microsecond timestamps and unique fallback.
- Checksum manifest de-duplication when bridge files are already included through the export tree.
- Private JSON sidecar/export writes for bridge metadata, audit logs, checksum manifests, and AEGIS handoff JSON.
- AEGIS `verify_backup` now requires `--path` explicitly.

## Validation checklist

- Input ZIP path traversal and symlink audit.
- Python compile.
- Debian package extraction audit.
- Shell wrapper syntax audit.
- Original v1.0.0 runtime smoke test.
- Patched source runtime smoke test.
- Patched package runtime smoke test after `.deb` extraction.
- CSV formula-injection regression.
- Private DB/export/backup/sidecar permission regression.
- Read-only backup verification regression.
- Checksum manifest duplicate-path regression.
- AEGIS path validation regression.
- Final ZIP integrity and SHA256 manifest.

## Preservation statement

v1.0.1 preserves the v1.0.0 stable-lock application scope and changes only security/bugfix hardening paths.
