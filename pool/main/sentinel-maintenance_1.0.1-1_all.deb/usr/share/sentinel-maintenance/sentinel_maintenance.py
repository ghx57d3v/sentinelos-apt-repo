#!/usr/bin/env python3
"""
Sentinel Maintenance - Program 114
Stable Lock / User-Ready Baseline: local household/workshop/vehicle/device/appliance/off-grid maintenance tracker.
Local-only. No network. No telemetry.
"""
from __future__ import annotations

import argparse
import csv
import errno
import datetime as _dt
import hashlib
import json
import os
import shutil
import sqlite3
import sys
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple
from urllib.parse import quote

VERSION = "1.0.1"
APP_NAME = "Sentinel Maintenance"
APP_ID = "sentinel-maintenance"
PROGRAM_NUMBER = "114"
DB_SCHEMA_VERSION = 10

DEFAULT_DATA_DIR = Path(os.environ.get("SENTINEL_MAINTENANCE_DATA_DIR", Path.home() / ".local" / "share" / "sentinel-maintenance"))
DB_PATH = Path(os.environ.get("SENTINEL_MAINTENANCE_DB", DEFAULT_DATA_DIR / "maintenance.db"))
BACKUP_DIR = Path(os.environ.get("SENTINEL_MAINTENANCE_BACKUP_DIR", DEFAULT_DATA_DIR / "backups"))
EXPORT_DIR = Path(os.environ.get("SENTINEL_MAINTENANCE_EXPORT_DIR", DEFAULT_DATA_DIR / "exports"))
BRIDGE_DIR = Path(os.environ.get("SENTINEL_MAINTENANCE_BRIDGE_DIR", EXPORT_DIR / "bridges"))
SETTINGS_DEFAULTS = {
    "household_name": "",
    "default_location": "Workshop",
    "preferred_provider": "",
    "currency": "AUD",
    "first_run_complete": "false",
}

ASSET_TYPES = [
    "Vehicle", "Device", "Appliance", "Tool", "Off-grid System", "Home Equipment", "Workshop Equipment", "Other"
]
ASSET_CATEGORIES = [
    "Vehicle", "Computer", "Phone", "Tablet", "Network Gear", "Appliance", "Power Tool",
    "Hand Tool", "Garden Equipment", "Generator", "Solar", "Battery Bank", "Water System",
    "Pump", "Fridge/Freezer", "Heating/Cooling", "Workshop", "Home", "Off-grid",
    "Safety", "Other"
]
SUPPLIER_PRESETS = [
    "", "Bunnings", "Repco", "Supercheap Auto", "Jaycar", "Officeworks", "Amazon",
    "eBay", "Local Supplier", "Manufacturer", "Repair Shop", "Hardware Store",
    "Auto Parts Store", "Electronics Supplier", "Other"
]
ASSET_STATUSES = ["Active", "Needs Service", "In Repair", "Retired", "Sold", "Archived"]
SERVICE_TYPES = ["Inspection", "Maintenance", "Repair", "Cleaning", "Upgrade", "Warranty", "Replacement", "Other"]
PRIORITIES = ["Low", "Normal", "High", "Urgent"]
LOCATION_PRESETS = ["House", "Kitchen", "Laundry", "Garage", "Shed", "Workshop", "Vehicle", "Off-grid Stores", "Toolbox", "Other"]
PART_STATUSES = ["In Stock", "Low Stock", "Used", "Ordered", "Archived"]
DOCUMENT_TYPES = ["Manual", "Warranty", "Receipt", "Diagram", "Service Record", "Photo", "Other"]
WARRANTY_STATES = ["Active", "Expiring Soon", "Expired", "Missing", "Archived"]
SERVICE_PLAN_STATUSES = ["Active", "Paused", "Completed", "Archived"]
SERVICE_INTERVAL_PRESETS = [7, 14, 30, 60, 90, 180, 365]
INSPECTION_CONDITIONS = ["Excellent", "Good", "Fair", "Poor", "Failed", "Unknown"]
INSPECTION_STATUSES = ["Open", "Action Required", "Recheck Scheduled", "Closed"]
FAULT_SEVERITIES = ["Low", "Medium", "High", "Critical"]
FAULT_STATUSES = ["Open", "Watching", "In Repair", "Resolved", "Closed"]

# SentinelOS / AEGIS Desktop Suite theme tokens.
# Opaque AEGIS Dark surfaces with Sentinel gold and minimal cyan accent.
THEME = {
    "bg": "#11151A",
    "panel": "#171D24",
    "panel2": "#202833",
    "field": "#202833",
    "field2": "#263241",
    "fg": "#E8EDF2",
    "muted": "#AAB4BF",
    "gold": "#E19B00",
    "gold2": "#FFD166",
    "cyan": "#03C8FF",
    "danger": "#F05D5E",
    "ok": "#77D977",
    "warning": "#FFD166",
}

DISPLAY_STATUS_FILTERS = [
    "", "Active", "Needs Service", "In Repair", "Service Due Soon",
    "Service Overdue", "Warranty Expiring", "Retired", "Sold", "Archived"
]



def now_iso() -> str:
    return _dt.datetime.now().replace(microsecond=0).isoformat()


def today_iso() -> str:
    return _dt.date.today().isoformat()


def parse_date(value: str | None) -> Optional[str]:
    if not value:
        return None
    value = value.strip()
    if not value:
        return None
    try:
        return _dt.date.fromisoformat(value).isoformat()
    except ValueError:
        raise SystemExit(f"Invalid date '{value}'. Use YYYY-MM-DD.")


def days_until(date_value: Optional[str]) -> Optional[int]:
    if not date_value:
        return None
    try:
        d = _dt.date.fromisoformat(date_value)
    except ValueError:
        return None
    return (d - _dt.date.today()).days


PRIVATE_DIR_MODE = 0o700
PRIVATE_FILE_MODE = 0o600
CSV_FORMULA_PREFIXES = ("=", "+", "-", "@")
CSV_DANGEROUS_LEADING = ("=", "+", "-", "@", "\t", "\r", "\n")


def _chmod_private_dir(path: Path) -> None:
    """Best-effort privacy hardening for application-owned directories."""
    try:
        if path.exists() and path.is_dir():
            path.chmod(PRIVATE_DIR_MODE)
    except OSError:
        pass


def _chmod_private_file(path: Path) -> None:
    """Best-effort privacy hardening for local database/export/backup files."""
    try:
        if path.exists() and path.is_file():
            path.chmod(PRIVATE_FILE_MODE)
    except OSError:
        pass


def _mkdir_private(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)
    _chmod_private_dir(path)


def _refuse_symlink_target(path: Path, label: str = "output") -> None:
    try:
        if path.exists() and path.is_symlink():
            raise SystemExit(f"Refusing to write {label} through symlink: {path}")
    except OSError as e:
        raise SystemExit(f"Unable to inspect {label} path {path}: {e}")


def _open_private_text(path: Path, mode: str = "w"):
    """Open a text file with 0600 permissions and avoid following symlink targets."""
    if mode not in {"w", "a"}:
        raise ValueError("_open_private_text only supports write/append modes")
    path = path.expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    _refuse_symlink_target(path)
    flags = os.O_WRONLY | os.O_CREAT
    flags |= os.O_APPEND if mode == "a" else os.O_TRUNC
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    try:
        fd = os.open(str(path), flags, PRIVATE_FILE_MODE)
    except OSError as e:
        if getattr(e, "errno", None) == errno.ELOOP:
            raise SystemExit(f"Refusing to write through symlink: {path}")
        raise
    _chmod_private_file(path)
    return os.fdopen(fd, mode, newline="" if mode == "w" else None, encoding="utf-8")


def _write_text_private(path: Path, text: str) -> None:
    with _open_private_text(path, "w") as f:
        f.write(text)
    _chmod_private_file(path)


def _csv_safe(value: Any) -> Any:
    """Prevent spreadsheet formula execution when CSVs are opened in office suites."""
    if not isinstance(value, str):
        return value
    if not value:
        return value
    stripped = value.lstrip()
    if value.startswith(CSV_DANGEROUS_LEADING) or (stripped and stripped.startswith(CSV_FORMULA_PREFIXES)):
        return "'" + value
    return value


def _csv_safe_row(row: Dict[str, Any], fields: Iterable[str]) -> Dict[str, Any]:
    return {field: _csv_safe(row.get(field, "")) for field in fields}


def _unique_path(path: Path) -> Path:
    """Avoid accidental overwrite when timestamped backups/exports collide."""
    if not path.exists():
        return path
    stem = path.stem
    suffix = path.suffix
    parent = path.parent
    for i in range(1, 1000):
        candidate = parent / f"{stem}-{i}{suffix}"
        if not candidate.exists():
            return candidate
    raise SystemExit(f"Unable to choose unique output path for {path}")


def _sqlite_readonly_connect(path: Path) -> sqlite3.Connection:
    """Open a SQLite database in read-only mode for verification/preview workflows."""
    path = path.expanduser()
    if not path.exists():
        raise FileNotFoundError(str(path))
    if not path.is_file():
        raise ValueError(f"Not a regular file: {path}")
    uri = "file:" + quote(str(path.resolve()), safe="/") + "?mode=ro"
    conn = sqlite3.connect(uri, uri=True)
    conn.row_factory = sqlite3.Row
    return conn


def ensure_dirs() -> None:
    _mkdir_private(DEFAULT_DATA_DIR)
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    # Only force the DB parent private when it is the application data directory.
    if DB_PATH.parent.resolve() == DEFAULT_DATA_DIR.resolve():
        _chmod_private_dir(DB_PATH.parent)
    _mkdir_private(BACKUP_DIR)
    _mkdir_private(EXPORT_DIR)
    _mkdir_private(BRIDGE_DIR)


def connect() -> sqlite3.Connection:
    ensure_dirs()
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    init_db(conn)
    _chmod_private_file(DB_PATH)
    return conn


def init_db(conn: sqlite3.Connection) -> None:
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS schema_meta (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS assets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            asset_type TEXT DEFAULT 'Other',
            category TEXT DEFAULT '',
            make TEXT DEFAULT '',
            model TEXT DEFAULT '',
            serial_number TEXT DEFAULT '',
            location TEXT DEFAULT '',
            purchase_date TEXT DEFAULT '',
            warranty_expiry TEXT DEFAULT '',
            next_service_date TEXT DEFAULT '',
            manual_path TEXT DEFAULT '',
            status TEXT DEFAULT 'Active',
            notes TEXT DEFAULT '',
            archived INTEGER DEFAULT 0,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_assets_name ON assets(name);
        CREATE INDEX IF NOT EXISTS idx_assets_type ON assets(asset_type);
        CREATE INDEX IF NOT EXISTS idx_assets_warranty ON assets(warranty_expiry);
        CREATE INDEX IF NOT EXISTS idx_assets_service_due ON assets(next_service_date);

        CREATE TABLE IF NOT EXISTS service_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            asset_id INTEGER NOT NULL,
            service_date TEXT NOT NULL,
            service_type TEXT DEFAULT 'Maintenance',
            summary TEXT NOT NULL,
            parts_used TEXT DEFAULT '',
            cost REAL DEFAULT 0,
            odometer_hours TEXT DEFAULT '',
            next_service_date TEXT DEFAULT '',
            provider TEXT DEFAULT '',
            receipt_path TEXT DEFAULT '',
            notes TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            FOREIGN KEY(asset_id) REFERENCES assets(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_service_asset ON service_logs(asset_id);
        CREATE INDEX IF NOT EXISTS idx_service_date ON service_logs(service_date);

        CREATE TABLE IF NOT EXISTS reminders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            asset_id INTEGER,
            title TEXT NOT NULL,
            due_date TEXT NOT NULL,
            priority TEXT DEFAULT 'Normal',
            status TEXT DEFAULT 'Open',
            notes TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            completed_at TEXT DEFAULT '',
            FOREIGN KEY(asset_id) REFERENCES assets(id) ON DELETE SET NULL
        );
        CREATE INDEX IF NOT EXISTS idx_reminders_due ON reminders(due_date);
        CREATE INDEX IF NOT EXISTS idx_reminders_status ON reminders(status);

        CREATE TABLE IF NOT EXISTS parts_catalog (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            asset_id INTEGER,
            part_name TEXT NOT NULL,
            part_number TEXT DEFAULT '',
            supplier TEXT DEFAULT '',
            quantity REAL DEFAULT 0,
            minimum_quantity REAL DEFAULT 0,
            unit TEXT DEFAULT 'each',
            cost_each REAL DEFAULT 0,
            location TEXT DEFAULT '',
            status TEXT DEFAULT 'In Stock',
            notes TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY(asset_id) REFERENCES assets(id) ON DELETE SET NULL
        );
        CREATE INDEX IF NOT EXISTS idx_parts_asset ON parts_catalog(asset_id);
        CREATE INDEX IF NOT EXISTS idx_parts_name ON parts_catalog(part_name);
        CREATE INDEX IF NOT EXISTS idx_parts_status ON parts_catalog(status);

        CREATE TABLE IF NOT EXISTS asset_documents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            asset_id INTEGER,
            doc_type TEXT DEFAULT 'Other',
            title TEXT NOT NULL,
            path TEXT NOT NULL,
            expiry_date TEXT DEFAULT '',
            notes TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY(asset_id) REFERENCES assets(id) ON DELETE SET NULL
        );
        CREATE INDEX IF NOT EXISTS idx_docs_asset ON asset_documents(asset_id);
        CREATE INDEX IF NOT EXISTS idx_docs_type ON asset_documents(doc_type);
        CREATE INDEX IF NOT EXISTS idx_docs_expiry ON asset_documents(expiry_date);

        CREATE TABLE IF NOT EXISTS warranty_claims (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            asset_id INTEGER NOT NULL,
            claim_date TEXT NOT NULL,
            claim_status TEXT DEFAULT 'Open',
            provider TEXT DEFAULT '',
            reference TEXT DEFAULT '',
            issue TEXT NOT NULL,
            resolution TEXT DEFAULT '',
            cost REAL DEFAULT 0,
            document_path TEXT DEFAULT '',
            notes TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY(asset_id) REFERENCES assets(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_claims_asset ON warranty_claims(asset_id);
        CREATE INDEX IF NOT EXISTS idx_claims_date ON warranty_claims(claim_date);
        CREATE INDEX IF NOT EXISTS idx_claims_status ON warranty_claims(claim_status);

        CREATE TABLE IF NOT EXISTS service_templates (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            asset_type TEXT DEFAULT 'Other',
            category TEXT DEFAULT '',
            service_type TEXT DEFAULT 'Maintenance',
            interval_days INTEGER DEFAULT 90,
            checklist TEXT DEFAULT '',
            parts_notes TEXT DEFAULT '',
            estimated_cost REAL DEFAULT 0,
            provider TEXT DEFAULT '',
            notes TEXT DEFAULT '',
            active INTEGER DEFAULT 1,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_templates_name ON service_templates(name);
        CREATE INDEX IF NOT EXISTS idx_templates_asset_type ON service_templates(asset_type);

        CREATE TABLE IF NOT EXISTS service_plans (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            asset_id INTEGER NOT NULL,
            template_id INTEGER,
            plan_name TEXT NOT NULL,
            service_type TEXT DEFAULT 'Maintenance',
            interval_days INTEGER DEFAULT 90,
            last_service_date TEXT DEFAULT '',
            next_service_date TEXT DEFAULT '',
            checklist TEXT DEFAULT '',
            parts_notes TEXT DEFAULT '',
            estimated_cost REAL DEFAULT 0,
            provider TEXT DEFAULT '',
            status TEXT DEFAULT 'Active',
            notes TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY(asset_id) REFERENCES assets(id) ON DELETE CASCADE,
            FOREIGN KEY(template_id) REFERENCES service_templates(id) ON DELETE SET NULL
        );
        CREATE INDEX IF NOT EXISTS idx_plans_asset ON service_plans(asset_id);
        CREATE INDEX IF NOT EXISTS idx_plans_next ON service_plans(next_service_date);
        CREATE INDEX IF NOT EXISTS idx_plans_status ON service_plans(status);


        CREATE TABLE IF NOT EXISTS inspection_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            asset_id INTEGER NOT NULL,
            inspection_date TEXT NOT NULL,
            condition_rating TEXT DEFAULT 'Unknown',
            checklist TEXT DEFAULT '',
            findings TEXT DEFAULT '',
            actions_required TEXT DEFAULT '',
            priority TEXT DEFAULT 'Normal',
            next_inspection_date TEXT DEFAULT '',
            photo_path TEXT DEFAULT '',
            status TEXT DEFAULT 'Open',
            notes TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY(asset_id) REFERENCES assets(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_inspections_asset ON inspection_records(asset_id);
        CREATE INDEX IF NOT EXISTS idx_inspections_date ON inspection_records(inspection_date);
        CREATE INDEX IF NOT EXISTS idx_inspections_next ON inspection_records(next_inspection_date);
        CREATE INDEX IF NOT EXISTS idx_inspections_status ON inspection_records(status);

        CREATE TABLE IF NOT EXISTS fault_reports (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            asset_id INTEGER NOT NULL,
            report_date TEXT NOT NULL,
            severity TEXT DEFAULT 'Medium',
            issue TEXT NOT NULL,
            symptom TEXT DEFAULT '',
            suspected_cause TEXT DEFAULT '',
            action_taken TEXT DEFAULT '',
            status TEXT DEFAULT 'Open',
            resolved_date TEXT DEFAULT '',
            service_log_id INTEGER,
            notes TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY(asset_id) REFERENCES assets(id) ON DELETE CASCADE,
            FOREIGN KEY(service_log_id) REFERENCES service_logs(id) ON DELETE SET NULL
        );
        CREATE INDEX IF NOT EXISTS idx_faults_asset ON fault_reports(asset_id);
        CREATE INDEX IF NOT EXISTS idx_faults_date ON fault_reports(report_date);
        CREATE INDEX IF NOT EXISTS idx_faults_status ON fault_reports(status);
        CREATE INDEX IF NOT EXISTS idx_faults_severity ON fault_reports(severity);

        CREATE TABLE IF NOT EXISTS app_settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS audit_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_type TEXT NOT NULL,
            entity_type TEXT DEFAULT '',
            entity_id INTEGER,
            message TEXT DEFAULT '',
            created_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_log(created_at);
        """
    )
    conn.execute("INSERT OR REPLACE INTO schema_meta(key, value) VALUES (?, ?)", ("schema_version", str(DB_SCHEMA_VERSION)))
    conn.execute("INSERT OR REPLACE INTO schema_meta(key, value) VALUES (?, ?)", ("app_version", VERSION))
    conn.execute("INSERT OR REPLACE INTO schema_meta(key, value) VALUES (?, ?)", ("theme", "AEGIS Dark / Sentinel Gold"))
    conn.execute("INSERT OR REPLACE INTO schema_meta(key, value) VALUES (?, ?)", ("ledger_bridge_ready", "true"))
    conn.execute("INSERT OR REPLACE INTO schema_meta(key, value) VALUES (?, ?)", ("inventory_bridge_ready", "true"))
    conn.execute("INSERT OR REPLACE INTO schema_meta(key, value) VALUES (?, ?)", ("inspection_tracking_ready", "true"))
    conn.execute("INSERT OR REPLACE INTO schema_meta(key, value) VALUES (?, ?)", ("fault_register_ready", "true"))
    conn.execute("INSERT OR REPLACE INTO schema_meta(key, value) VALUES (?, ?)", ("recovery_integrity_ready", "true"))
    conn.execute("INSERT OR REPLACE INTO schema_meta(key, value) VALUES (?, ?)", ("aegis_contract_version", "v1.0.0"))
    conn.execute("INSERT OR REPLACE INTO schema_meta(key, value) VALUES (?, ?)", ("user_ready_completion_ready", "true"))
    conn.execute("INSERT OR REPLACE INTO schema_meta(key, value) VALUES (?, ?)", ("self_test_ready", "true"))
    conn.execute("INSERT OR REPLACE INTO schema_meta(key, value) VALUES (?, ?)", ("manual_status_ready", "true"))
    conn.execute("INSERT OR REPLACE INTO schema_meta(key, value) VALUES (?, ?)", ("stable_lock_ready", "true"))
    conn.execute("INSERT OR REPLACE INTO schema_meta(key, value) VALUES (?, ?)", ("stable_lock_version", VERSION))
    for _k, _v in SETTINGS_DEFAULTS.items():
        conn.execute("INSERT OR IGNORE INTO app_settings(key, value, updated_at) VALUES (?, ?, ?)", (_k, _v, now_iso()))
    # Log only once per version to keep upgrades traceable without spamming every run.
    exists = conn.execute("SELECT 1 FROM audit_log WHERE event_type='schema_seen' AND message=? LIMIT 1", (f"schema_v{DB_SCHEMA_VERSION}_version_{VERSION}",)).fetchone()
    if not exists:
        conn.execute("INSERT INTO audit_log(event_type, entity_type, entity_id, message, created_at) VALUES (?, ?, ?, ?, ?)",
                     ("schema_seen", "schema", DB_SCHEMA_VERSION, f"schema_v{DB_SCHEMA_VERSION}_version_{VERSION}", now_iso()))
    conn.commit()


def audit(conn: sqlite3.Connection, event_type: str, entity_type: str = "", entity_id: Optional[int] = None, message: str = "") -> None:
    conn.execute(
        "INSERT INTO audit_log(event_type, entity_type, entity_id, message, created_at) VALUES (?, ?, ?, ?, ?)",
        (event_type, entity_type, entity_id, message, now_iso()),
    )
    conn.commit()


def row_to_dict(row: sqlite3.Row | None) -> Dict[str, Any]:
    return {} if row is None else {k: row[k] for k in row.keys()}

def asset_display_status(asset: Dict[str, Any], due_window_days: int = 30, warranty_window_days: int = 60) -> str:
    if int(asset.get("archived") or 0):
        return "Archived"
    explicit = asset.get("status") or "Active"
    if explicit in ("Needs Service", "In Repair", "Retired", "Sold", "Archived"):
        return explicit
    service_days = days_until(asset.get("next_service_date"))
    if service_days is not None:
        if service_days < 0:
            return "Service Overdue"
        if service_days <= due_window_days:
            return "Service Due Soon"
    warranty_days = days_until(asset.get("warranty_expiry"))
    if warranty_days is not None and 0 <= warranty_days <= warranty_window_days:
        return "Warranty Expiring"
    return explicit or "Active"


def enrich_asset(asset: Dict[str, Any]) -> Dict[str, Any]:
    d = dict(asset)
    d["days_until_service"] = days_until(d.get("next_service_date"))
    d["days_until_warranty_expiry"] = days_until(d.get("warranty_expiry"))
    d["display_status"] = asset_display_status(d)
    return d


def all_locations(conn: sqlite3.Connection) -> List[str]:
    rows = conn.execute("SELECT DISTINCT location FROM assets WHERE location!='' ORDER BY location COLLATE NOCASE ASC").fetchall()
    values = [r[0] for r in rows if r[0]]
    merged = []
    for item in LOCATION_PRESETS + values:
        if item and item not in merged:
            merged.append(item)
    return merged


def next_table_id(conn: sqlite3.Connection, table: str) -> int:
    """Return the next likely SQLite autoincrement ID for GUI preview/autofill."""
    seq = conn.execute("SELECT seq FROM sqlite_sequence WHERE name=?", (table,)).fetchone()
    if seq and seq[0] is not None:
        return int(seq[0]) + 1
    row = conn.execute(f"SELECT COALESCE(MAX(id), 0) + 1 FROM {table}").fetchone()
    return int(row[0] or 1)


def all_suppliers(conn: sqlite3.Connection) -> List[str]:
    values: List[str] = []
    for table, column in (("parts_catalog", "supplier"), ("service_logs", "provider"), ("warranty_claims", "provider"), ("service_templates", "provider"), ("service_plans", "provider")):
        try:
            rows = conn.execute(f"SELECT DISTINCT {column} FROM {table} WHERE {column}!='' ORDER BY {column} COLLATE NOCASE ASC").fetchall()
            values.extend([r[0] for r in rows if r[0]])
        except sqlite3.Error:
            pass
    merged: List[str] = []
    for item in SUPPLIER_PRESETS + values:
        if item and item not in merged:
            merged.append(item)
    return merged


def add_asset(conn: sqlite3.Connection, args: argparse.Namespace) -> int:
    created = now_iso()
    cur = conn.execute(
        """
        INSERT INTO assets(name, asset_type, category, make, model, serial_number, location, purchase_date,
                           warranty_expiry, next_service_date, manual_path, status, notes, archived, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?)
        """,
        (
            args.name,
            args.asset_type or "Other",
            args.category or "",
            args.make or "",
            args.model or "",
            args.serial or "",
            args.location or "",
            parse_date(args.purchase_date) or "",
            parse_date(args.warranty_expiry) or "",
            parse_date(args.next_service) or "",
            args.manual or "",
            args.status or "Active",
            args.notes or "",
            created,
            created,
        ),
    )
    asset_id = int(cur.lastrowid)
    audit(conn, "asset_added", "asset", asset_id, args.name)
    return asset_id


def list_assets(
    conn: sqlite3.Connection,
    include_archived: bool = False,
    asset_type: str = "",
    status: str = "",
    search: str = "",
    location: str = "",
    due_only: bool = False,
    warranty_only: bool = False,
    days: int = 30,
) -> List[Dict[str, Any]]:
    where = []
    params: List[Any] = []
    if not include_archived:
        where.append("archived=0")
    if asset_type:
        where.append("asset_type=?")
        params.append(asset_type)
    if status:
        where.append("status=?")
        params.append(status)
    if location:
        where.append("location=?")
        params.append(location)
    if search:
        where.append("(name LIKE ? OR make LIKE ? OR model LIKE ? OR serial_number LIKE ? OR category LIKE ? OR location LIKE ? OR notes LIKE ?)")
        q = f"%{search}%"
        params.extend([q, q, q, q, q, q, q])
    if due_only:
        cutoff = (_dt.date.today() + _dt.timedelta(days=days)).isoformat()
        where.append("next_service_date!='' AND next_service_date<=?")
        params.append(cutoff)
    if warranty_only:
        cutoff = (_dt.date.today() + _dt.timedelta(days=max(days, 60))).isoformat()
        where.append("warranty_expiry!='' AND warranty_expiry<=?")
        params.append(cutoff)
    sql = "SELECT * FROM assets"
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY archived ASC, name COLLATE NOCASE ASC, id ASC"
    return [enrich_asset(row_to_dict(r)) for r in conn.execute(sql, params).fetchall()]


def get_asset(conn: sqlite3.Connection, asset_id: int) -> Dict[str, Any]:
    row = conn.execute("SELECT * FROM assets WHERE id=?", (asset_id,)).fetchone()
    if not row:
        raise SystemExit(f"Asset ID {asset_id} not found.")
    return row_to_dict(row)


def set_asset_status(conn: sqlite3.Connection, asset_id: int, status: str) -> None:
    get_asset(conn, asset_id)
    conn.execute("UPDATE assets SET status=?, updated_at=? WHERE id=?", (status, now_iso(), asset_id))
    audit(conn, "asset_status", "asset", asset_id, status)


def archive_asset(conn: sqlite3.Connection, asset_id: int) -> None:
    get_asset(conn, asset_id)
    conn.execute("UPDATE assets SET archived=1, status='Archived', updated_at=? WHERE id=?", (now_iso(), asset_id))
    audit(conn, "asset_archived", "asset", asset_id, "Archived")


def add_service(conn: sqlite3.Connection, args: argparse.Namespace) -> int:
    asset = get_asset(conn, args.asset_id)
    service_date = parse_date(args.date) or today_iso()
    next_service = parse_date(args.next_service) or ""
    cur = conn.execute(
        """
        INSERT INTO service_logs(asset_id, service_date, service_type, summary, parts_used, cost, odometer_hours,
                                 next_service_date, provider, receipt_path, notes, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            args.asset_id,
            service_date,
            args.service_type or "Maintenance",
            args.summary,
            args.parts or "",
            float(args.cost or 0),
            args.meter or "",
            next_service,
            args.provider or "",
            args.receipt or "",
            args.notes or "",
            now_iso(),
        ),
    )
    service_id = int(cur.lastrowid)
    if next_service:
        conn.execute("UPDATE assets SET next_service_date=?, updated_at=? WHERE id=?", (next_service, now_iso(), args.asset_id))
    if asset.get("status") in ("Needs Service", "In Repair") and args.mark_active:
        conn.execute("UPDATE assets SET status='Active', updated_at=? WHERE id=?", (now_iso(), args.asset_id))
    audit(conn, "service_added", "service", service_id, f"{asset['name']}: {args.summary}")
    return service_id


def list_service(conn: sqlite3.Connection, asset_id: Optional[int] = None, limit: int = 100) -> List[Dict[str, Any]]:
    sql = """
        SELECT service_logs.*, assets.name AS asset_name
        FROM service_logs LEFT JOIN assets ON service_logs.asset_id=assets.id
    """
    params: List[Any] = []
    if asset_id:
        sql += " WHERE service_logs.asset_id=?"
        params.append(asset_id)
    sql += " ORDER BY service_date DESC, service_logs.id DESC LIMIT ?"
    params.append(limit)
    return [row_to_dict(r) for r in conn.execute(sql, params).fetchall()]


def add_reminder(conn: sqlite3.Connection, args: argparse.Namespace) -> int:
    if args.asset_id:
        get_asset(conn, args.asset_id)
    due_date = parse_date(args.due_date)
    if not due_date:
        raise SystemExit("Reminder due date is required in YYYY-MM-DD format.")
    cur = conn.execute(
        """
        INSERT INTO reminders(asset_id, title, due_date, priority, status, notes, created_at)
        VALUES (?, ?, ?, ?, 'Open', ?, ?)
        """,
        (args.asset_id, args.title, due_date, args.priority or "Normal", args.notes or "", now_iso()),
    )
    reminder_id = int(cur.lastrowid)
    audit(conn, "reminder_added", "reminder", reminder_id, args.title)
    return reminder_id


def list_reminders(conn: sqlite3.Connection, include_done: bool = False, days: int = 365) -> List[Dict[str, Any]]:
    cutoff = (_dt.date.today() + _dt.timedelta(days=days)).isoformat()
    where = ["due_date<=?"]
    params: List[Any] = [cutoff]
    if not include_done:
        where.append("reminders.status!='Done'")
    sql = """
        SELECT reminders.*, assets.name AS asset_name
        FROM reminders LEFT JOIN assets ON reminders.asset_id=assets.id
        WHERE """ + " AND ".join(where) + " ORDER BY due_date ASC, priority DESC, reminders.id ASC"
    return [row_to_dict(r) for r in conn.execute(sql, params).fetchall()]


def complete_reminder(conn: sqlite3.Connection, reminder_id: int) -> None:
    row = conn.execute("SELECT * FROM reminders WHERE id=?", (reminder_id,)).fetchone()
    if not row:
        raise SystemExit(f"Reminder ID {reminder_id} not found.")
    conn.execute("UPDATE reminders SET status='Done', completed_at=? WHERE id=?", (now_iso(), reminder_id))
    audit(conn, "reminder_done", "reminder", reminder_id, row["title"])


def due_assets(conn: sqlite3.Connection, days: int = 30) -> List[Dict[str, Any]]:
    cutoff = (_dt.date.today() + _dt.timedelta(days=days)).isoformat()
    rows = conn.execute(
        "SELECT * FROM assets WHERE archived=0 AND next_service_date!='' AND next_service_date<=? ORDER BY next_service_date ASC",
        (cutoff,),
    ).fetchall()
    out = []
    for r in rows:
        d = enrich_asset(row_to_dict(r))
        out.append(d)
    return out


def warranty_expiring(conn: sqlite3.Connection, days: int = 60) -> List[Dict[str, Any]]:
    cutoff = (_dt.date.today() + _dt.timedelta(days=days)).isoformat()
    rows = conn.execute(
        "SELECT * FROM assets WHERE archived=0 AND warranty_expiry!='' AND warranty_expiry<=? ORDER BY warranty_expiry ASC",
        (cutoff,),
    ).fetchall()
    out = []
    for r in rows:
        d = enrich_asset(row_to_dict(r))
        out.append(d)
    return out


def service_queue(conn: sqlite3.Connection, days: int = 60) -> List[Dict[str, Any]]:
    """Return an AEGIS-readable service queue with derived priority labels."""
    queue: List[Dict[str, Any]] = []
    for asset in due_assets(conn, days):
        days_left = asset.get("days_until_service")
        if days_left is None:
            priority = "Normal"
            queue_state = "Scheduled"
        elif days_left < 0:
            priority = "Urgent"
            queue_state = "Overdue"
        elif days_left <= 7:
            priority = "High"
            queue_state = "Due This Week"
        elif days_left <= 30:
            priority = "Normal"
            queue_state = "Due Soon"
        else:
            priority = "Low"
            queue_state = "Upcoming"
        item = dict(asset)
        item["service_queue_state"] = queue_state
        item["service_priority"] = priority
        item["recommended_action"] = "Log service now" if priority in ("Urgent", "High") else "Plan upcoming service"
        queue.append(item)
    return queue




def calculate_next_service_date(last_service_date: str | None = None, interval_days: int = 90) -> str:
    """Calculate the next service date from a last-service date and interval."""
    base = _dt.date.today()
    if last_service_date:
        try:
            base = _dt.date.fromisoformat(last_service_date)
        except ValueError:
            raise SystemExit(f"Invalid last service date '{last_service_date}'. Use YYYY-MM-DD.")
    return (base + _dt.timedelta(days=int(interval_days or 90))).isoformat()


def service_plan_state(plan: Dict[str, Any]) -> str:
    if plan.get("status") and plan.get("status") != "Active":
        return plan.get("status") or "Paused"
    due = days_until(plan.get("next_service_date"))
    if due is None:
        return "No Date"
    if due < 0:
        return "Overdue"
    if due <= 7:
        return "Due This Week"
    if due <= 30:
        return "Due Soon"
    return "Scheduled"


def add_service_template(conn: sqlite3.Connection, args: argparse.Namespace) -> int:
    created = now_iso()
    cur = conn.execute(
        """
        INSERT INTO service_templates(name, asset_type, category, service_type, interval_days, checklist,
                                      parts_notes, estimated_cost, provider, notes, active, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            args.name,
            args.asset_type or "Other",
            args.category or "",
            args.service_type or "Maintenance",
            int(args.interval_days or 90),
            args.checklist or "",
            args.parts or "",
            float(args.estimated_cost or 0),
            args.provider or "",
            args.notes or "",
            0 if getattr(args, "inactive", False) else 1,
            created,
            created,
        ),
    )
    tid = int(cur.lastrowid)
    audit(conn, "service_template_added", "service_template", tid, args.name)
    return tid


def list_service_templates(conn: sqlite3.Connection, include_inactive: bool = False, asset_type: str = "", search: str = "") -> List[Dict[str, Any]]:
    where: List[str] = []
    params: List[Any] = []
    if not include_inactive:
        where.append("active=1")
    if asset_type:
        where.append("asset_type=?"); params.append(asset_type)
    if search:
        where.append("(name LIKE ? OR category LIKE ? OR checklist LIKE ? OR parts_notes LIKE ? OR notes LIKE ?)")
        q = f"%{search}%"; params.extend([q, q, q, q, q])
    sql = "SELECT * FROM service_templates"
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY asset_type COLLATE NOCASE ASC, name COLLATE NOCASE ASC, id ASC"
    return [row_to_dict(r) for r in conn.execute(sql, params).fetchall()]


def get_service_template(conn: sqlite3.Connection, template_id: int) -> Dict[str, Any]:
    row = conn.execute("SELECT * FROM service_templates WHERE id=?", (template_id,)).fetchone()
    if not row:
        raise SystemExit(f"Service template ID {template_id} not found.")
    return row_to_dict(row)


def add_service_plan(conn: sqlite3.Connection, args: argparse.Namespace) -> int:
    asset = get_asset(conn, args.asset_id)
    template: Dict[str, Any] = {}
    if getattr(args, "template_id", None):
        template = get_service_template(conn, args.template_id)
    name = args.name or template.get("name") or f"{asset.get('name')} Service Plan"
    service_type = args.service_type or template.get("service_type") or "Maintenance"
    interval_days = int(args.interval_days or template.get("interval_days") or 90)
    last = parse_date(args.last_service) or ""
    next_date = parse_date(args.next_service) or calculate_next_service_date(last or None, interval_days)
    created = now_iso()
    cur = conn.execute(
        """
        INSERT INTO service_plans(asset_id, template_id, plan_name, service_type, interval_days, last_service_date,
                                  next_service_date, checklist, parts_notes, estimated_cost, provider, status,
                                  notes, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            args.asset_id,
            args.template_id or None,
            name,
            service_type,
            interval_days,
            last,
            next_date,
            args.checklist or template.get("checklist", ""),
            args.parts or template.get("parts_notes", ""),
            float(args.estimated_cost if args.estimated_cost is not None else template.get("estimated_cost", 0) or 0),
            args.provider or template.get("provider", ""),
            args.status or "Active",
            args.notes or template.get("notes", ""),
            created,
            created,
        ),
    )
    plan_id = int(cur.lastrowid)
    conn.execute("UPDATE assets SET next_service_date=COALESCE(NULLIF(next_service_date,''), ?), updated_at=? WHERE id=?",
                 (next_date, now_iso(), args.asset_id))
    audit(conn, "service_plan_added", "service_plan", plan_id, name)
    return plan_id


def list_service_plans(conn: sqlite3.Connection, asset_id: Optional[int] = None, status: str = "", days: int = 365, include_archived: bool = False, search: str = "") -> List[Dict[str, Any]]:
    where: List[str] = []
    params: List[Any] = []
    if asset_id:
        where.append("service_plans.asset_id=?"); params.append(asset_id)
    if status:
        where.append("service_plans.status=?"); params.append(status)
    elif not include_archived:
        where.append("service_plans.status!='Archived'")
    if days >= 0:
        cutoff = (_dt.date.today() + _dt.timedelta(days=days)).isoformat()
        where.append("(service_plans.next_service_date='' OR service_plans.next_service_date<=?)")
        params.append(cutoff)
    if search:
        where.append("(plan_name LIKE ? OR checklist LIKE ? OR parts_notes LIKE ? OR service_plans.notes LIKE ? OR assets.name LIKE ?)")
        q = f"%{search}%"; params.extend([q, q, q, q, q])
    sql = """
        SELECT service_plans.*, assets.name AS asset_name, assets.asset_type AS asset_type, assets.location AS asset_location
        FROM service_plans LEFT JOIN assets ON service_plans.asset_id=assets.id
    """
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY service_plans.next_service_date ASC, service_plans.id ASC"
    rows: List[Dict[str, Any]] = []
    for r in conn.execute(sql, params).fetchall():
        d = row_to_dict(r)
        d["days_until_service"] = days_until(d.get("next_service_date"))
        d["plan_state"] = service_plan_state(d)
        rows.append(d)
    return rows


def service_plan_summary(conn: sqlite3.Connection, days: int = 90) -> Dict[str, Any]:
    plans = list_service_plans(conn, days=days, include_archived=False)
    all_active = list_service_plans(conn, days=-1, include_archived=False)
    states: Dict[str, int] = {}
    est_total = 0.0
    for p in plans:
        st = p.get("plan_state") or "Scheduled"
        states[st] = states.get(st, 0) + 1
        est_total += float(p.get("estimated_cost") or 0)
    return {
        "window_days": days,
        "active_plans": len(all_active),
        "plans_in_window": len(plans),
        "state_counts": states,
        "estimated_cost_in_window": round(est_total, 2),
        "due_plans": plans,
        "templates": list_service_templates(conn),
        "updated_at": now_iso(),
    }


def complete_service_plan(conn: sqlite3.Connection, plan_id: int, service_date: str = "", cost: Optional[float] = None, notes: str = "") -> Dict[str, Any]:
    row = conn.execute("SELECT * FROM service_plans WHERE id=?", (plan_id,)).fetchone()
    if not row:
        raise SystemExit(f"Service plan ID {plan_id} not found.")
    plan = row_to_dict(row)
    service_date = parse_date(service_date) or today_iso()
    next_date = calculate_next_service_date(service_date, int(plan.get("interval_days") or 90))
    ns = argparse.Namespace(
        asset_id=int(plan["asset_id"]),
        date=service_date,
        service_type=plan.get("service_type") or "Maintenance",
        summary=f"Completed planned service: {plan.get('plan_name')}",
        parts=plan.get("parts_notes") or "",
        cost=float(cost if cost is not None else plan.get("estimated_cost") or 0),
        meter="",
        next_service=next_date,
        provider=plan.get("provider") or "",
        receipt="",
        notes=notes or plan.get("notes") or "",
        mark_active=True,
    )
    service_id = add_service(conn, ns)
    conn.execute("UPDATE service_plans SET last_service_date=?, next_service_date=?, updated_at=? WHERE id=?",
                 (service_date, next_date, now_iso(), plan_id))
    audit(conn, "service_plan_completed", "service_plan", plan_id, f"service_log={service_id}; next={next_date}")
    return {"plan_id": plan_id, "service_id": service_id, "last_service_date": service_date, "next_service_date": next_date}


def add_part(conn: sqlite3.Connection, args: argparse.Namespace) -> int:
    if getattr(args, "asset_id", None):
        get_asset(conn, args.asset_id)
    created = now_iso()
    cur = conn.execute(
        """
        INSERT INTO parts_catalog(asset_id, part_name, part_number, supplier, quantity, minimum_quantity, unit,
                                  cost_each, location, status, notes, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            args.asset_id or None,
            args.name,
            args.part_number or "",
            args.supplier or "",
            float(args.quantity or 0),
            float(args.minimum_quantity or 0),
            args.unit or "each",
            float(args.cost_each or 0),
            args.location or "",
            args.status or "In Stock",
            args.notes or "",
            created,
            created,
        ),
    )
    part_id = int(cur.lastrowid)
    audit(conn, "part_added", "part", part_id, args.name)
    return part_id


def list_parts(conn: sqlite3.Connection, asset_id: Optional[int] = None, low_only: bool = False, include_archived: bool = False, search: str = "") -> List[Dict[str, Any]]:
    where = []
    params: List[Any] = []
    if asset_id:
        where.append("parts_catalog.asset_id=?")
        params.append(asset_id)
    if not include_archived:
        where.append("parts_catalog.status!='Archived'")
    if low_only:
        where.append("quantity<=minimum_quantity AND minimum_quantity>0")
    if search:
        where.append("(part_name LIKE ? OR part_number LIKE ? OR supplier LIKE ? OR parts_catalog.location LIKE ? OR parts_catalog.notes LIKE ?)")
        q=f"%{search}%"
        params.extend([q,q,q,q,q])
    sql = """
        SELECT parts_catalog.*, assets.name AS asset_name
        FROM parts_catalog LEFT JOIN assets ON parts_catalog.asset_id=assets.id
    """
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY parts_catalog.status ASC, part_name COLLATE NOCASE ASC, parts_catalog.id ASC"
    rows=[]
    for r in conn.execute(sql, params).fetchall():
        d=row_to_dict(r)
        qty=float(d.get("quantity") or 0)
        minq=float(d.get("minimum_quantity") or 0)
        d["low_stock"] = bool(minq > 0 and qty <= minq)
        d["estimated_value"] = round(qty * float(d.get("cost_each") or 0), 2)
        rows.append(d)
    return rows


def use_part(conn: sqlite3.Connection, part_id: int, quantity: float, asset_id: Optional[int] = None, notes: str = "") -> Dict[str, Any]:
    row = conn.execute("SELECT * FROM parts_catalog WHERE id=?", (part_id,)).fetchone()
    if not row:
        raise SystemExit(f"Part ID {part_id} not found.")
    part = row_to_dict(row)
    qty = max(0.0, float(part.get("quantity") or 0) - float(quantity or 0))
    status = "Low Stock" if float(part.get("minimum_quantity") or 0) > 0 and qty <= float(part.get("minimum_quantity") or 0) else (part.get("status") or "In Stock")
    if qty <= 0 and status not in ("Ordered", "Archived"):
        status = "Used"
    conn.execute("UPDATE parts_catalog SET quantity=?, status=?, updated_at=? WHERE id=?", (qty, status, now_iso(), part_id))
    msg = f"Used {quantity} {part.get('unit') or ''} of {part.get('part_name')}"
    if asset_id:
        get_asset(conn, asset_id)
        msg += f" for asset {asset_id}"
    if notes:
        msg += f" - {notes}"
    audit(conn, "part_used", "part", part_id, msg)
    return {"part_id": part_id, "quantity_remaining": qty, "status": status, "message": msg}


def add_document(conn: sqlite3.Connection, args: argparse.Namespace) -> int:
    if getattr(args, "asset_id", None):
        get_asset(conn, args.asset_id)
    created = now_iso()
    cur = conn.execute(
        """
        INSERT INTO asset_documents(asset_id, doc_type, title, path, expiry_date, notes, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (args.asset_id or None, args.doc_type or "Other", args.title, str(Path(args.path).expanduser()), parse_date(args.expiry_date) or "", args.notes or "", created, created),
    )
    doc_id=int(cur.lastrowid)
    audit(conn, "document_added", "document", doc_id, args.title)
    return doc_id


def list_documents(conn: sqlite3.Connection, asset_id: Optional[int] = None, doc_type: str = "", search: str = "") -> List[Dict[str, Any]]:
    where=[]; params=[]
    if asset_id:
        where.append("asset_documents.asset_id=?"); params.append(asset_id)
    if doc_type:
        where.append("doc_type=?"); params.append(doc_type)
    if search:
        where.append("(title LIKE ? OR path LIKE ? OR asset_documents.notes LIKE ?)")
        q=f"%{search}%"; params.extend([q,q,q])
    sql="""
        SELECT asset_documents.*, assets.name AS asset_name
        FROM asset_documents LEFT JOIN assets ON asset_documents.asset_id=assets.id
    """
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY doc_type ASC, title COLLATE NOCASE ASC, asset_documents.id ASC"
    rows=[]
    for r in conn.execute(sql, params).fetchall():
        d=row_to_dict(r)
        d["path_exists"] = Path(d.get("path") or "").expanduser().exists() if d.get("path") else False
        d["days_until_expiry"] = days_until(d.get("expiry_date"))
        rows.append(d)
    return rows


def add_warranty_claim(conn: sqlite3.Connection, args: argparse.Namespace) -> int:
    get_asset(conn, args.asset_id)
    created = now_iso()
    cur = conn.execute(
        """
        INSERT INTO warranty_claims(asset_id, claim_date, claim_status, provider, reference, issue, resolution, cost, document_path, notes, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (args.asset_id, parse_date(args.date) or today_iso(), args.status or "Open", args.provider or "", args.reference or "", args.issue, args.resolution or "", float(args.cost or 0), args.document or "", args.notes or "", created, created),
    )
    claim_id=int(cur.lastrowid)
    audit(conn, "warranty_claim_added", "warranty_claim", claim_id, args.issue)
    return claim_id


def list_warranty_claims(conn: sqlite3.Connection, asset_id: Optional[int] = None, include_closed: bool = False, limit: int = 100) -> List[Dict[str, Any]]:
    where=[]; params=[]
    if asset_id:
        where.append("warranty_claims.asset_id=?"); params.append(asset_id)
    if not include_closed:
        where.append("claim_status NOT IN ('Closed','Resolved','Denied')")
    sql="""
        SELECT warranty_claims.*, assets.name AS asset_name
        FROM warranty_claims LEFT JOIN assets ON warranty_claims.asset_id=assets.id
    """
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY claim_date DESC, warranty_claims.id DESC LIMIT ?"
    params.append(limit)
    return [row_to_dict(r) for r in conn.execute(sql, params).fetchall()]


def warranty_state_for_asset(asset: Dict[str, Any], days: int = 90) -> str:
    if int(asset.get("archived") or 0):
        return "Archived"
    due = days_until(asset.get("warranty_expiry"))
    if due is None:
        return "Missing"
    if due < 0:
        return "Expired"
    if due <= days:
        return "Expiring Soon"
    return "Active"


def warranty_center(conn: sqlite3.Connection, days: int = 90) -> Dict[str, Any]:
    assets = list_assets(conn, include_archived=False)
    rows=[]; counts={"Active":0,"Expiring Soon":0,"Expired":0,"Missing":0,"Archived":0}
    for a in assets:
        st=warranty_state_for_asset(a, days)
        counts[st]=counts.get(st,0)+1
        if st != "Active" or days_until(a.get("warranty_expiry")) is not None:
            item=dict(a)
            item["warranty_state"] = st
            item["warranty_documents"] = len([d for d in list_documents(conn, asset_id=a["id"], doc_type="Warranty")])
            item["open_claims"] = len(list_warranty_claims(conn, asset_id=a["id"], include_closed=False))
            rows.append(item)
    rows.sort(key=lambda x: ("Expired", "Expiring Soon", "Missing", "Active", "Archived").index(x.get("warranty_state","Active")) if x.get("warranty_state") in ("Expired", "Expiring Soon", "Missing", "Active", "Archived") else 9)
    return {"days": days, "counts": counts, "items": rows, "claims_open": list_warranty_claims(conn, include_closed=False, limit=100), "updated_at": now_iso()}


def inspection_state(record: Dict[str, Any]) -> str:
    if record.get("status") in ("Closed",):
        return "Closed"
    cond = record.get("condition_rating") or "Unknown"
    priority = record.get("priority") or "Normal"
    if cond == "Failed" or priority == "Urgent":
        return "Critical Attention"
    if cond == "Poor" or priority == "High" or record.get("actions_required"):
        return "Action Required"
    due = days_until(record.get("next_inspection_date"))
    if due is not None and due <= 0:
        return "Recheck Due"
    if due is not None and due <= 30:
        return "Recheck Soon"
    return "Observed"


def add_inspection(conn: sqlite3.Connection, args: argparse.Namespace) -> int:
    get_asset(conn, int(args.asset_id))
    created = now_iso()
    cur = conn.execute(
        """
        INSERT INTO inspection_records(asset_id, inspection_date, condition_rating, checklist, findings,
                                       actions_required, priority, next_inspection_date, photo_path, status,
                                       notes, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            int(args.asset_id),
            parse_date(getattr(args, "date", "")) or today_iso(),
            getattr(args, "condition", "Unknown") or "Unknown",
            getattr(args, "checklist", "") or "",
            getattr(args, "findings", "") or "",
            getattr(args, "actions", "") or "",
            getattr(args, "priority", "Normal") or "Normal",
            parse_date(getattr(args, "next_inspection", "")) or "",
            getattr(args, "photo", "") or "",
            getattr(args, "status", "Open") or "Open",
            getattr(args, "notes", "") or "",
            created,
            created,
        ),
    )
    iid = int(cur.lastrowid)
    if (getattr(args, "condition", "") in ("Poor", "Failed")) or (getattr(args, "actions", "") or "").strip():
        conn.execute("UPDATE assets SET status='Needs Service', updated_at=? WHERE id=? AND status NOT IN ('In Repair','Retired','Sold','Archived')", (now_iso(), int(args.asset_id)))
    audit(conn, "inspection_added", "inspection", iid, f"asset {args.asset_id}: {getattr(args, 'condition', 'Unknown')}")
    return iid


def list_inspections(conn: sqlite3.Connection, asset_id: Optional[int] = None, include_closed: bool = False, limit: int = 100) -> List[Dict[str, Any]]:
    where: List[str] = []
    params: List[Any] = []
    if asset_id:
        where.append("inspection_records.asset_id=?")
        params.append(asset_id)
    if not include_closed:
        where.append("inspection_records.status!='Closed'")
    sql = """
        SELECT inspection_records.*, assets.name AS asset_name
        FROM inspection_records LEFT JOIN assets ON inspection_records.asset_id=assets.id
    """
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY inspection_date DESC, inspection_records.id DESC LIMIT ?"
    params.append(limit)
    rows = []
    for r in conn.execute(sql, params).fetchall():
        d = row_to_dict(r)
        d["inspection_state"] = inspection_state(d)
        d["days_until_next_inspection"] = days_until(d.get("next_inspection_date"))
        d["photo_exists"] = bool(d.get("photo_path") and Path(str(d.get("photo_path"))).expanduser().exists())
        rows.append(d)
    return rows


def inspection_summary(conn: sqlite3.Connection, days: int = 60) -> Dict[str, Any]:
    rows = list_inspections(conn, include_closed=True, limit=10000)
    open_rows = [r for r in rows if r.get("status") != "Closed"]
    due_window = [r for r in open_rows if r.get("days_until_next_inspection") is not None and r.get("days_until_next_inspection") <= days]
    action_required = [r for r in open_rows if r.get("inspection_state") in ("Critical Attention", "Action Required", "Recheck Due")]
    condition_counts: Dict[str, int] = {}
    state_counts: Dict[str, int] = {}
    for r in rows:
        condition_counts[r.get("condition_rating") or "Unknown"] = condition_counts.get(r.get("condition_rating") or "Unknown", 0) + 1
        state_counts[r.get("inspection_state") or "Observed"] = state_counts.get(r.get("inspection_state") or "Observed", 0) + 1
    return {
        "days": days,
        "total_inspections": len(rows),
        "open_inspections": len(open_rows),
        "inspections_due_window": len(due_window),
        "action_required_count": len(action_required),
        "condition_counts": condition_counts,
        "state_counts": state_counts,
        "due_window": due_window[:50],
        "action_required": action_required[:50],
        "updated_at": now_iso(),
    }


def add_fault(conn: sqlite3.Connection, args: argparse.Namespace) -> int:
    get_asset(conn, int(args.asset_id))
    created = now_iso()
    cur = conn.execute(
        """
        INSERT INTO fault_reports(asset_id, report_date, severity, issue, symptom, suspected_cause,
                                  action_taken, status, resolved_date, service_log_id, notes, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            int(args.asset_id),
            parse_date(getattr(args, "date", "")) or today_iso(),
            getattr(args, "severity", "Medium") or "Medium",
            getattr(args, "issue", "") or "",
            getattr(args, "symptom", "") or "",
            getattr(args, "cause", "") or "",
            getattr(args, "action", "") or "",
            getattr(args, "status", "Open") or "Open",
            parse_date(getattr(args, "resolved_date", "")) or "",
            getattr(args, "service_log_id", None),
            getattr(args, "notes", "") or "",
            created,
            created,
        ),
    )
    fid = int(cur.lastrowid)
    if getattr(args, "severity", "Medium") in ("High", "Critical"):
        conn.execute("UPDATE assets SET status='Needs Service', updated_at=? WHERE id=? AND status NOT IN ('In Repair','Retired','Sold','Archived')", (now_iso(), int(args.asset_id)))
    audit(conn, "fault_added", "fault", fid, f"asset {args.asset_id}: {getattr(args, 'issue', '')}")
    return fid


def set_fault_status(conn: sqlite3.Connection, fault_id: int, status: str, resolved_date: str = "") -> Dict[str, Any]:
    row = conn.execute("SELECT * FROM fault_reports WHERE id=?", (fault_id,)).fetchone()
    if not row:
        raise SystemExit(f"Fault ID {fault_id} not found.")
    resolved = parse_date(resolved_date) or (today_iso() if status in ("Resolved", "Closed") else "")
    conn.execute("UPDATE fault_reports SET status=?, resolved_date=?, updated_at=? WHERE id=?", (status, resolved, now_iso(), fault_id))
    audit(conn, "fault_status", "fault", fault_id, status)
    return row_to_dict(conn.execute("SELECT * FROM fault_reports WHERE id=?", (fault_id,)).fetchone())


def list_faults(conn: sqlite3.Connection, asset_id: Optional[int] = None, include_closed: bool = False, severity: str = "", limit: int = 100) -> List[Dict[str, Any]]:
    where: List[str] = []
    params: List[Any] = []
    if asset_id:
        where.append("fault_reports.asset_id=?")
        params.append(asset_id)
    if severity:
        where.append("fault_reports.severity=?")
        params.append(severity)
    if not include_closed:
        where.append("fault_reports.status NOT IN ('Resolved','Closed')")
    sql = """
        SELECT fault_reports.*, assets.name AS asset_name
        FROM fault_reports LEFT JOIN assets ON fault_reports.asset_id=assets.id
    """
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY CASE severity WHEN 'Critical' THEN 0 WHEN 'High' THEN 1 WHEN 'Medium' THEN 2 ELSE 3 END, report_date DESC, fault_reports.id DESC LIMIT ?"
    params.append(limit)
    return [row_to_dict(r) for r in conn.execute(sql, params).fetchall()]


def fault_summary(conn: sqlite3.Connection, limit: int = 100) -> Dict[str, Any]:
    rows = list_faults(conn, include_closed=True, limit=10000)
    open_rows = [r for r in rows if r.get("status") not in ("Resolved", "Closed")]
    severity_counts: Dict[str, int] = {}
    status_counts: Dict[str, int] = {}
    for r in rows:
        severity_counts[r.get("severity") or "Medium"] = severity_counts.get(r.get("severity") or "Medium", 0) + 1
        status_counts[r.get("status") or "Open"] = status_counts.get(r.get("status") or "Open", 0) + 1
    critical_open = [r for r in open_rows if r.get("severity") == "Critical"]
    high_open = [r for r in open_rows if r.get("severity") == "High"]
    return {
        "total_faults": len(rows),
        "open_faults": len(open_rows),
        "critical_open": len(critical_open),
        "high_open": len(high_open),
        "severity_counts": severity_counts,
        "status_counts": status_counts,
        "open_items": open_rows[:limit],
        "updated_at": now_iso(),
    }

def dashboard(conn: sqlite3.Connection) -> Dict[str, Any]:
    due_30 = due_assets(conn, 30)
    overdue = [a for a in due_30 if (a.get("days_until_service") is not None and a["days_until_service"] < 0)]
    warranty_60 = warranty_expiring(conn, 60)
    open_reminders = list_reminders(conn, include_done=False, days=365)
    active_assets = list_assets(conn, include_archived=False)
    parts_all = list_parts(conn)
    parts_low = list_parts(conn, low_only=True)
    documents_all = list_documents(conn)
    warranty_dash = warranty_center(conn, 90)
    plan_dash = service_plan_summary(conn, 90)
    insp_dash = inspection_summary(conn, 60)
    fault_dash = fault_summary(conn)
    status_counts: Dict[str, int] = {}
    type_counts: Dict[str, int] = {}
    location_counts: Dict[str, int] = {}
    for a in active_assets:
        status_counts[a.get("display_status") or a.get("status") or "Active"] = status_counts.get(a.get("display_status") or a.get("status") or "Active", 0) + 1
        type_counts[a.get("asset_type") or "Other"] = type_counts.get(a.get("asset_type") or "Other", 0) + 1
        loc = a.get("location") or "Unassigned"
        location_counts[loc] = location_counts.get(loc, 0) + 1
    recent_service = list_service(conn, limit=8)
    return {
        "program": PROGRAM_NUMBER,
        "application": APP_NAME,
        "version": VERSION,
        "phase": "stable_lock",
        "cards": {
            "active_assets": len(active_assets),
            "service_due_30_days": len(due_30),
            "service_overdue": len(overdue),
            "warranties_expiring_60_days": len(warranty_60),
            "open_reminders": len(open_reminders),
            "total_service_cost": round(float(conn.execute("SELECT COALESCE(SUM(cost), 0) FROM service_logs").fetchone()[0] or 0), 2),
            "parts_inventory_value": round(sum(float(p.get("estimated_value") or 0) for p in parts_all), 2),
            "maintenance_cost_365_days": cost_report(conn, days=365).get("total_service_cost", 0),
            "parts_catalog_items": len(parts_all),
            "low_stock_parts": len(parts_low),
            "asset_documents": len(documents_all),
            "warranty_claims_open": len(warranty_dash.get("claims_open", [])),
            "service_templates": len(list_service_templates(conn)),
            "active_service_plans": plan_dash.get("active_plans", 0),
            "service_plans_due_90_days": plan_dash.get("plans_in_window", 0),
            "service_plan_estimated_cost_90_days": plan_dash.get("estimated_cost_in_window", 0),
            "open_inspections": insp_dash.get("open_inspections", 0),
            "inspection_actions_required": insp_dash.get("action_required_count", 0),
            "inspections_due_60_days": insp_dash.get("inspections_due_window", 0),
            "open_faults": fault_dash.get("open_faults", 0),
            "critical_faults_open": fault_dash.get("critical_open", 0),
            "high_faults_open": fault_dash.get("high_open", 0),
        },
        "status_counts": status_counts,
        "type_counts": type_counts,
        "location_counts": location_counts,
        "service_due": due_30[:12],
        "warranty_expiring": warranty_60[:12],
        "open_reminders": open_reminders[:12],
        "service_queue": service_queue(conn, 60)[:12],
        "service_plan_summary": plan_dash,
        "inspection_summary": insp_dash,
        "fault_summary": fault_dash,
        "low_stock_parts": parts_low[:12],
        "warranty_center": warranty_dash,
        "recent_documents": documents_all[:12],
        "recent_service": recent_service,
        "theme": "AEGIS Dark / Sentinel Gold",
        "updated_at": now_iso(),
    }


def summary(conn: sqlite3.Connection) -> Dict[str, Any]:
    dash = dashboard(conn)
    archived = conn.execute("SELECT COUNT(*) FROM assets WHERE archived=1").fetchone()[0]
    service_logs = conn.execute("SELECT COUNT(*) FROM service_logs").fetchone()[0]
    cards = dash["cards"]
    return {
        "program": PROGRAM_NUMBER,
        "application": APP_NAME,
        "version": VERSION,
        "schema_version": DB_SCHEMA_VERSION,
        "database": str(DB_PATH),
        "local_only": True,
        "network": False,
        "telemetry": False,
        "phase": "stable_lock",
        "inspection_tracking_ready": True,
        "fault_register_ready": True,
        "recovery_integrity_ready": True,
        "tab_fit_window_ready": True,
        "manual_status_ready": True,
        "self_test_ready": True,
        "user_ready_completion_ready": True,
        "stable_lock_ready": True,
        "stable_lock_version": VERSION,
        "minimum_window_size": "1280x760",
        "aegis_contract_version": "v1.0.0",
        "active_assets": cards["active_assets"],
        "archived_assets": archived,
        "service_log_entries": service_logs,
        "open_reminders": cards["open_reminders"],
        "service_due_30_days": cards["service_due_30_days"],
        "service_overdue": cards["service_overdue"],
        "warranties_expiring_60_days": cards["warranties_expiring_60_days"],
        "total_service_cost": cards["total_service_cost"],
        "service_queue_60_days": len(service_queue(conn, 60)),
        "parts_catalog_items": cards.get("parts_catalog_items", 0),
        "low_stock_parts": cards.get("low_stock_parts", 0),
        "asset_documents": cards.get("asset_documents", 0),
        "warranty_claims_open": cards.get("warranty_claims_open", 0),
        "service_templates": cards.get("service_templates", 0),
        "active_service_plans": cards.get("active_service_plans", 0),
        "service_plans_due_90_days": cards.get("service_plans_due_90_days", 0),
        "service_plan_estimated_cost_90_days": cards.get("service_plan_estimated_cost_90_days", 0),
        "parts_inventory_value": cards.get("parts_inventory_value", 0),
        "maintenance_cost_365_days": cards.get("maintenance_cost_365_days", 0),
        "ledger_bridge_ready": True,
        "inventory_bridge_ready": True,
        "open_inspections": cards.get("open_inspections", 0),
        "inspection_actions_required": cards.get("inspection_actions_required", 0),
        "inspections_due_60_days": cards.get("inspections_due_60_days", 0),
        "open_faults": cards.get("open_faults", 0),
        "critical_faults_open": cards.get("critical_faults_open", 0),
        "high_faults_open": cards.get("high_faults_open", 0),
        "default_window_size": "1680x900",
        "theme": "AEGIS Dark / Sentinel Gold",
        "status_counts": dash["status_counts"],
        "type_counts": dash["type_counts"],
        "location_counts": dash["location_counts"],
        "updated_at": now_iso(),
    }


def health(conn: sqlite3.Connection) -> Dict[str, Any]:
    integrity = conn.execute("PRAGMA integrity_check").fetchone()[0]
    quick = conn.execute("PRAGMA quick_check").fetchone()[0]
    return {
        "status": "ok" if integrity == "ok" and quick == "ok" else "warning",
        "application": APP_NAME,
        "program": PROGRAM_NUMBER,
        "version": VERSION,
        "database": str(DB_PATH),
        "database_exists": DB_PATH.exists(),
        "schema_version": DB_SCHEMA_VERSION,
        "sqlite_integrity_check": integrity,
        "sqlite_quick_check": quick,
        "local_only": True,
        "network": False,
        "telemetry": False,
        "aegis_ready": True,
        "phase": "stable_lock",
        "theme": "AEGIS Dark / Sentinel Gold",
        "gui_layout": "scroll-stabilized-wide-tab-fit-window",
        "default_window_size": "1680x900",
        "service_planning_ready": True,
        "ledger_bridge_ready": True,
        "inventory_bridge_ready": True,
        "inspection_tracking_ready": True,
        "fault_register_ready": True,
        "recovery_integrity_ready": True,
        "tab_fit_window_ready": True,
        "manual_status_ready": True,
        "self_test_ready": True,
        "user_ready_completion_ready": True,
        "stable_lock_ready": True,
        "stable_lock_version": VERSION,
        "minimum_window_size": "1280x760",
        "aegis_contract_version": "v1.0.0",
        "asset_id_mode": "auto-generated-read-only-gui-preview",
        "checked_at": now_iso(),
    }


def aegis_manifest() -> Dict[str, Any]:
    return {
        "program": PROGRAM_NUMBER,
        "name": APP_NAME,
        "package": "sentinel-maintenance",
        "version": VERSION,
        "status": "v1_stable_lock",
        "capabilities": [
            "asset_registry", "asset_auto_ids", "selected_asset_autofill", "baseline_category_dropdown", "supplier_dropdown", "stable_scroll_layout", "asset_status_labels", "service_history", "repair_log", "warranty_tracking",
            "service_due_tracking", "dashboard_cards", "suite_theme", "asset_filters", "service_queue", "service_templates", "recurring_service_plans", "service_plan_completion", "quick_service_logging", "quick_reminder_workflow",
            "parts_catalog", "low_stock_parts", "asset_documents", "warranty_center", "warranty_claims",
            "parts_used_notes", "cost_tracking", "cost_reports", "ledger_bridge_export", "inventory_bridge_export", "manual_document_links", "reminders", "csv_export", "sqlite_backup",
            "aegis_summary", "aegis_dashboard", "aegis_cost_report", "aegis_bridge_summary", "inspection_tracking", "fault_register", "condition_reports", "aegis_inspection_summary", "aegis_fault_summary", "aegis_contract", "recovery_integrity", "wide_tab_fit_window", "tab_fit_notebook", "manual_status_tab", "first_run_setup", "self_test", "completion_report", "stable_lock_report", "launcher_repair", "backup_verification", "checksum_manifest", "compact_repair", "audit_export", "local_only"
        ],
        "commands": [
            "sentinel-maintenance", "sentinel-maintenance-gui", "sentinel-maintenance-cli", "aegis-maintenance"
        ],
        "aegis_actions": ["contract", "manifest", "health_check", "summary", "dashboard", "status", "self_test", "completion_report", "stable_lock_report", "service_queue", "service_due", "service_templates", "service_plans", "service_plan_summary", "cost_report", "ledger_bridge", "inventory_bridge", "bridge_summary", "inspections", "inspection_summary", "faults", "fault_summary", "warranty_expiring", "warranty_center", "parts", "documents", "warranty_claims", "reminders", "integrity_check", "backup", "verify_backup", "checksum_manifest", "audit_log", "recovery_status", "vault_export"],
        "data_paths": {"database": str(DB_PATH), "backups": str(BACKUP_DIR), "exports": str(EXPORT_DIR), "bridges": str(BRIDGE_DIR)},
        "theme": "AEGIS Dark / Sentinel Gold",
        "gui_layout": "scroll-stabilized-wide-tab-fit-window",
        "default_window_size": "1680x900",
        "service_planning_ready": True,
        "ledger_bridge_ready": True,
        "inventory_bridge_ready": True,
        "inspection_tracking_ready": True,
        "fault_register_ready": True,
        "recovery_integrity_ready": True,
        "tab_fit_window_ready": True,
        "manual_status_ready": True,
        "self_test_ready": True,
        "user_ready_completion_ready": True,
        "stable_lock_ready": True,
        "stable_lock_version": VERSION,
        "minimum_window_size": "1280x760",
        "aegis_contract_version": "v1.0.0",
        "asset_id_mode": "auto-generated-read-only-gui-preview",
        "local_only": True,
        "network": False,
        "telemetry": False,
    }




def get_settings(conn: sqlite3.Connection) -> Dict[str, str]:
    rows = conn.execute("SELECT key, value FROM app_settings").fetchall()
    data = dict(SETTINGS_DEFAULTS)
    data.update({r["key"]: r["value"] for r in rows})
    return data


def set_settings(conn: sqlite3.Connection, updates: Dict[str, str]) -> Dict[str, str]:
    cleaned = {k: str(v) for k, v in updates.items() if v is not None and str(v) != ""}
    if cleaned:
        for key, value in cleaned.items():
            conn.execute("INSERT OR REPLACE INTO app_settings(key, value, updated_at) VALUES (?, ?, ?)", (key, value, now_iso()))
        conn.execute("INSERT OR REPLACE INTO app_settings(key, value, updated_at) VALUES (?, ?, ?)", ("first_run_complete", "true", now_iso()))
        audit(conn, "settings_update", "app_settings", None, ", ".join(sorted(cleaned.keys())))
    return get_settings(conn)


def app_status(conn: sqlite3.Connection) -> Dict[str, Any]:
    return {
        "program": PROGRAM_NUMBER,
        "application": APP_NAME,
        "version": VERSION,
        "status": "v1_stable_lock",
        "phase": "stable_lock",
        "schema_version": DB_SCHEMA_VERSION,
        "database": str(DB_PATH),
        "database_exists": DB_PATH.exists(),
        "data_dir": str(DEFAULT_DATA_DIR),
        "backup_dir": str(BACKUP_DIR),
        "export_dir": str(EXPORT_DIR),
        "bridge_dir": str(BRIDGE_DIR),
        "default_window_size": "1680x900",
        "minimum_window_size": "1280x760",
        "theme": "AEGIS Dark / Sentinel Gold",
        "settings": get_settings(conn),
        "counts": {
            "assets": conn.execute("SELECT COUNT(*) FROM assets").fetchone()[0],
            "service_logs": conn.execute("SELECT COUNT(*) FROM service_logs").fetchone()[0],
            "reminders": conn.execute("SELECT COUNT(*) FROM reminders").fetchone()[0],
            "parts": conn.execute("SELECT COUNT(*) FROM parts_catalog").fetchone()[0],
            "documents": conn.execute("SELECT COUNT(*) FROM asset_documents").fetchone()[0],
            "service_plans": conn.execute("SELECT COUNT(*) FROM service_plans").fetchone()[0],
            "inspections": conn.execute("SELECT COUNT(*) FROM inspection_records").fetchone()[0],
            "faults": conn.execute("SELECT COUNT(*) FROM fault_reports").fetchone()[0],
        },
        "aegis_ready": True,
        "local_only": True,
        "network": False,
        "telemetry": False,
        "checked_at": now_iso(),
    }


def self_test(conn: sqlite3.Connection) -> Dict[str, Any]:
    checks: List[Dict[str, Any]] = []
    def add(name: str, ok: bool, detail: str = "") -> None:
        checks.append({"name": name, "ok": bool(ok), "detail": detail})
    integ = integrity_report(conn)
    add("sqlite_integrity", integ.get("status") == "ok", integ.get("status", ""))
    add("database_path", DB_PATH.exists(), str(DB_PATH))
    add("backup_dir", BACKUP_DIR.exists(), str(BACKUP_DIR))
    add("export_dir", EXPORT_DIR.exists(), str(EXPORT_DIR))
    h = health(conn)
    add("theme_metadata", h.get("theme") == "AEGIS Dark / Sentinel Gold", h.get("theme", ""))
    acts = aegis_manifest().get("aegis_actions", [])
    add("aegis_contract", "contract" in acts, "contract action present")
    add("status_action", "status" in acts, "status action present")
    add("self_test_action", "self_test" in acts, "self_test action present")
    add("completion_report_action", "completion_report" in acts, "completion_report action present")
    add("stable_lock_report_action", "stable_lock_report" in acts, "stable_lock_report action present")
    add("stable_version", VERSION == "1.0.1", VERSION)
    add("private_data_dir", (DEFAULT_DATA_DIR.stat().st_mode & 0o777) <= PRIVATE_DIR_MODE if DEFAULT_DATA_DIR.exists() else False, oct(DEFAULT_DATA_DIR.stat().st_mode & 0o777) if DEFAULT_DATA_DIR.exists() else str(DEFAULT_DATA_DIR))
    add("private_database_file", (DB_PATH.stat().st_mode & 0o777) <= PRIVATE_FILE_MODE if DB_PATH.exists() else False, oct(DB_PATH.stat().st_mode & 0o777) if DB_PATH.exists() else str(DB_PATH))
    script_dir = Path(__file__).resolve().parent
    share_dir = script_dir.parent
    usr_dir = share_dir.parent
    desktop_candidates = [Path("/usr/share/applications/sentinel-maintenance.desktop"), share_dir / "applications" / "sentinel-maintenance.desktop"]
    icon_candidates = [Path("/usr/share/pixmaps/sentinel-maintenance.svg"), script_dir / "sentinel-maintenance.svg", share_dir / "pixmaps" / "sentinel-maintenance.svg"]
    wrapper_candidates = [Path("/usr/bin/sentinel-maintenance"), usr_dir / "bin" / "sentinel-maintenance", Path(sys.argv[0])]
    add("desktop_launcher_file", any(p.exists() for p in desktop_candidates), "; ".join(str(p) for p in desktop_candidates))
    add("icon_file", any(p.exists() for p in icon_candidates), "; ".join(str(p) for p in icon_candidates))
    add("installed_wrapper", any(p.exists() for p in wrapper_candidates), "; ".join(str(p) for p in wrapper_candidates))
    add("runtime_python", True, sys.executable)
    ok = all(c["ok"] for c in checks)
    return {"program": PROGRAM_NUMBER, "application": APP_NAME, "version": VERSION, "status": "ok" if ok else "warning", "checks": checks, "checked_at": now_iso(), "local_only": True, "network": False, "telemetry": False}


def completion_report(conn: sqlite3.Connection) -> Dict[str, Any]:
    st = app_status(conn)
    tst = self_test(conn)
    criteria = {
        "asset_registry": True,
        "service_history": True,
        "reminders": True,
        "parts_documents_warranty": True,
        "service_plans_templates": True,
        "cost_ledger_inventory_bridges": True,
        "inspections_faults": True,
        "recovery_integrity": True,
        "manual_status_tab": True,
        "wide_tab_fit_window": True,
        "aegis_contract": True,
        "desktop_launcher": True,
        "local_only_no_telemetry": True,
    }
    return {
        "program": PROGRAM_NUMBER,
        "application": APP_NAME,
        "version": VERSION,
        "report": "v1_stable_lock_report",
        "status": "stable_locked" if tst.get("status") == "ok" else "needs_attention",
        "criteria": criteria,
        "status_snapshot": st,
        "self_test_status": tst.get("status"),
        "next_recommended_target": "v1.0.x hotfixes only for defects, or v1.1+ feature expansion",
        "created_at": now_iso(),
    }




def stable_lock_report(conn: sqlite3.Connection) -> Dict[str, Any]:
    """Stable v1 release-lock report for Program 114."""
    st = app_status(conn)
    tst = self_test(conn)
    comp = completion_report(conn)
    locked_criteria = {
        "asset_registry": True,
        "asset_auto_ids_and_autofill": True,
        "service_and_repair_history": True,
        "service_queue": True,
        "service_plans_and_templates": True,
        "parts_documents_warranty_center": True,
        "cost_reports": True,
        "ledger_bridge": True,
        "inventory_bridge": True,
        "inspections_and_fault_register": True,
        "recovery_and_integrity": True,
        "manual_status_and_self_test": True,
        "aegis_contract_and_handoff": True,
        "desktop_launcher_and_repair": True,
        "wide_tab_fit_window": True,
        "local_only_no_network_no_telemetry": True,
    }
    return {
        "program": PROGRAM_NUMBER,
        "application": APP_NAME,
        "version": VERSION,
        "debian_version": "1.0.0-1",
        "report": "stable_lock_report",
        "status": "stable_locked" if tst.get("status") == "ok" else "needs_attention",
        "stable_lock": True,
        "stable_lock_scope": "Program 114 Sentinel Maintenance v1.0.0 user-ready baseline",
        "criteria": locked_criteria,
        "status_snapshot": st,
        "self_test_status": tst.get("status"),
        "completion_report_status": comp.get("status"),
        "maintenance_policy": "Future changes should be v1.0.x defect hotfixes or v1.1+ feature releases.",
        "local_only": True,
        "network": False,
        "telemetry": False,
        "created_at": now_iso(),
    }

def _service_log_rows_for_period(conn: sqlite3.Connection, start: str = "", end: str = "", asset_id: Optional[int] = None, limit: int = 10000) -> List[Dict[str, Any]]:
    where: List[str] = []
    params: List[Any] = []
    if start:
        where.append("service_date>=?")
        params.append(parse_date(start) or start)
    if end:
        where.append("service_date<=?")
        params.append(parse_date(end) or end)
    if asset_id:
        where.append("service_logs.asset_id=?")
        params.append(asset_id)
    sql = """
        SELECT service_logs.*, assets.name AS asset_name, assets.asset_type AS asset_type, assets.category AS asset_category,
               assets.location AS asset_location, assets.make AS asset_make, assets.model AS asset_model
        FROM service_logs LEFT JOIN assets ON service_logs.asset_id=assets.id
    """
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY service_date DESC, service_logs.id DESC LIMIT ?"
    params.append(limit)
    return [row_to_dict(r) for r in conn.execute(sql, params).fetchall()]


def cost_report(conn: sqlite3.Connection, start: str = "", end: str = "", asset_id: Optional[int] = None, days: Optional[int] = None) -> Dict[str, Any]:
    if days is not None and not start and not end:
        start = (_dt.date.today() - _dt.timedelta(days=max(0, int(days)))).isoformat()
        end = today_iso()
    rows = _service_log_rows_for_period(conn, start, end, asset_id)
    by_asset: Dict[str, Dict[str, Any]] = {}
    by_type: Dict[str, Dict[str, Any]] = {}
    by_month: Dict[str, Dict[str, Any]] = {}
    total = 0.0
    for r in rows:
        cost = float(r.get("cost") or 0)
        total += cost
        asset_key = str(r.get("asset_id") or "Unassigned")
        by_asset.setdefault(asset_key, {"asset_id": r.get("asset_id"), "asset_name": r.get("asset_name") or "Unknown", "count": 0, "total_cost": 0.0})
        by_asset[asset_key]["count"] += 1
        by_asset[asset_key]["total_cost"] += cost
        typ = r.get("service_type") or "Other"
        by_type.setdefault(typ, {"service_type": typ, "count": 0, "total_cost": 0.0})
        by_type[typ]["count"] += 1
        by_type[typ]["total_cost"] += cost
        month = (r.get("service_date") or "")[:7] or "Unknown"
        by_month.setdefault(month, {"month": month, "count": 0, "total_cost": 0.0})
        by_month[month]["count"] += 1
        by_month[month]["total_cost"] += cost
    for group in (by_asset, by_type, by_month):
        for item in group.values():
            item["total_cost"] = round(float(item.get("total_cost") or 0), 2)
    parts = list_parts(conn, include_archived=True)
    parts_value = round(sum(float(p.get("estimated_value") or 0) for p in parts), 2)
    low_parts_value = round(sum(float(p.get("estimated_value") or 0) for p in parts if p.get("low_stock")), 2)
    return {
        "program": PROGRAM_NUMBER,
        "application": APP_NAME,
        "version": VERSION,
        "start": start,
        "end": end,
        "asset_id": asset_id,
        "service_log_count": len(rows),
        "total_service_cost": round(total, 2),
        "average_service_cost": round(total / len(rows), 2) if rows else 0,
        "parts_catalog_items": len(parts),
        "parts_inventory_value": parts_value,
        "low_stock_parts_value": low_parts_value,
        "by_asset": sorted(by_asset.values(), key=lambda x: (-float(x.get("total_cost") or 0), str(x.get("asset_name") or ""))),
        "by_service_type": sorted(by_type.values(), key=lambda x: (-float(x.get("total_cost") or 0), str(x.get("service_type") or ""))),
        "by_month": sorted(by_month.values(), key=lambda x: str(x.get("month") or "")),
        "recent_cost_items": rows[:50],
        "updated_at": now_iso(),
    }


def ledger_bridge_rows(conn: sqlite3.Connection, start: str = "", end: str = "", asset_id: Optional[int] = None) -> List[Dict[str, Any]]:
    rows = _service_log_rows_for_period(conn, start, end, asset_id)
    out: List[Dict[str, Any]] = []
    for r in rows:
        amount = round(float(r.get("cost") or 0), 2)
        if amount <= 0:
            continue
        asset_name = r.get("asset_name") or f"Asset {r.get('asset_id')}"
        out.append({
            "date": r.get("service_date") or "",
            "description": f"{r.get('service_type') or 'Maintenance'} - {asset_name}: {r.get('summary') or ''}",
            "category": "Repairs & Maintenance",
            "asset_id": r.get("asset_id"),
            "asset_name": asset_name,
            "asset_type": r.get("asset_type") or "",
            "provider": r.get("provider") or "",
            "amount": amount,
            "source_app": APP_NAME,
            "source_table": "service_logs",
            "source_id": r.get("id"),
            "receipt_path": r.get("receipt_path") or "",
            "notes": r.get("notes") or "",
        })
    return out


def export_rows_csv(rows: List[Dict[str, Any]], path: Path, default_fields: List[str]) -> Path:
    path = path.expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = list(rows[0].keys()) if rows else default_fields
    with _open_private_text(path, "w") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow(_csv_safe_row(row, fields))
    _chmod_private_file(path)
    return path


def export_ledger_bridge(conn: sqlite3.Connection, path: Optional[Path] = None, start: str = "", end: str = "", asset_id: Optional[int] = None) -> Dict[str, Any]:
    rows = ledger_bridge_rows(conn, start, end, asset_id)
    if path is None:
        path = BRIDGE_DIR / "sentinel-ledger" / f"sentinel-maintenance-ledger-bridge-{_dt.datetime.now().strftime('%Y%m%d-%H%M%S')}.csv"
    fields = ["date", "description", "category", "asset_id", "asset_name", "asset_type", "provider", "amount", "source_app", "source_table", "source_id", "receipt_path", "notes"]
    out = export_rows_csv(rows, path, fields)
    total = round(sum(float(r.get("amount") or 0) for r in rows), 2)
    meta = {"bridge": "sentinel-ledger", "path": str(out), "rows": len(rows), "total_amount": total, "start": start, "end": end, "asset_id": asset_id, "created_at": now_iso()}
    _write_text_private(out.with_suffix(out.suffix + ".json"), json.dumps(meta, indent=2))
    audit(conn, "ledger_bridge_export", "bridge", None, str(out))
    return meta


def inventory_bridge_rows(conn: sqlite3.Connection, low_only: bool = False, include_archived: bool = False) -> List[Dict[str, Any]]:
    parts = list_parts(conn, low_only=low_only, include_archived=include_archived)
    out: List[Dict[str, Any]] = []
    for p in parts:
        out.append({
            "source_app": APP_NAME,
            "source_table": "parts_catalog",
            "source_id": p.get("id"),
            "linked_asset_id": p.get("asset_id") or "",
            "linked_asset_name": p.get("asset_name") or "",
            "item_name": p.get("part_name") or "",
            "sku_or_part_number": p.get("part_number") or "",
            "category": "Maintenance Part",
            "supplier": p.get("supplier") or "",
            "quantity": p.get("quantity") or 0,
            "minimum_quantity": p.get("minimum_quantity") or 0,
            "unit": p.get("unit") or "each",
            "unit_value": p.get("cost_each") or 0,
            "estimated_value": p.get("estimated_value") or 0,
            "location": p.get("location") or "",
            "status": p.get("status") or "",
            "low_stock": bool(p.get("low_stock")),
            "notes": p.get("notes") or "",
        })
    return out


def export_inventory_bridge(conn: sqlite3.Connection, path: Optional[Path] = None, low_only: bool = False, include_archived: bool = False) -> Dict[str, Any]:
    rows = inventory_bridge_rows(conn, low_only=low_only, include_archived=include_archived)
    if path is None:
        path = BRIDGE_DIR / "sentinel-inventory" / f"sentinel-maintenance-inventory-bridge-{_dt.datetime.now().strftime('%Y%m%d-%H%M%S')}.csv"
    fields = ["source_app", "source_table", "source_id", "linked_asset_id", "linked_asset_name", "item_name", "sku_or_part_number", "category", "supplier", "quantity", "minimum_quantity", "unit", "unit_value", "estimated_value", "location", "status", "low_stock", "notes"]
    out = export_rows_csv(rows, path, fields)
    total_value = round(sum(float(r.get("estimated_value") or 0) for r in rows), 2)
    meta = {"bridge": "sentinel-inventory", "path": str(out), "rows": len(rows), "total_estimated_value": total_value, "low_only": low_only, "include_archived": include_archived, "created_at": now_iso()}
    _write_text_private(out.with_suffix(out.suffix + ".json"), json.dumps(meta, indent=2))
    audit(conn, "inventory_bridge_export", "bridge", None, str(out))
    return meta


def bridge_summary(conn: sqlite3.Connection) -> Dict[str, Any]:
    cost = cost_report(conn, days=365)
    ledger_rows = ledger_bridge_rows(conn)
    inventory_rows = inventory_bridge_rows(conn)
    return {
        "program": PROGRAM_NUMBER,
        "application": APP_NAME,
        "version": VERSION,
        "ledger_bridge_ready": True,
        "inventory_bridge_ready": True,
        "bridge_dir": str(BRIDGE_DIR),
        "ledger_rows_available": len(ledger_rows),
        "ledger_total_available": round(sum(float(r.get("amount") or 0) for r in ledger_rows), 2),
        "inventory_rows_available": len(inventory_rows),
        "inventory_total_value": round(sum(float(r.get("estimated_value") or 0) for r in inventory_rows), 2),
        "cost_report_365_days": {k: cost[k] for k in ("service_log_count", "total_service_cost", "parts_inventory_value", "average_service_cost")},
        "updated_at": now_iso(),
    }



def database_table_counts(conn: sqlite3.Connection) -> Dict[str, int]:
    tables = ["assets", "service_logs", "reminders", "parts_catalog", "asset_documents", "warranty_claims", "service_templates", "service_plans", "inspection_records", "fault_reports", "audit_log"]
    counts: Dict[str, int] = {}
    for t in tables:
        try:
            counts[t] = int(conn.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0] or 0)
        except sqlite3.Error:
            counts[t] = -1
    return counts


def integrity_report(conn: sqlite3.Connection) -> Dict[str, Any]:
    fk = [row_to_dict(r) for r in conn.execute("PRAGMA foreign_key_check").fetchall()]
    try:
        page_count = int(conn.execute("PRAGMA page_count").fetchone()[0] or 0)
        page_size = int(conn.execute("PRAGMA page_size").fetchone()[0] or 0)
    except sqlite3.Error:
        page_count = page_size = 0
    integrity = conn.execute("PRAGMA integrity_check").fetchone()[0]
    quick = conn.execute("PRAGMA quick_check").fetchone()[0]
    status = "ok" if integrity == "ok" and quick == "ok" and not fk else "warning"
    return {
        "program": PROGRAM_NUMBER,
        "application": APP_NAME,
        "version": VERSION,
        "schema_version": DB_SCHEMA_VERSION,
        "status": status,
        "database": str(DB_PATH),
        "database_exists": DB_PATH.exists(),
        "database_size_bytes": DB_PATH.stat().st_size if DB_PATH.exists() else 0,
        "sqlite_integrity_check": integrity,
        "sqlite_quick_check": quick,
        "foreign_key_errors": fk,
        "table_counts": database_table_counts(conn),
        "page_count": page_count,
        "page_size": page_size,
        "checked_at": now_iso(),
    }


def backup_verification(path: Path) -> Dict[str, Any]:
    path = path.expanduser()
    out: Dict[str, Any] = {"path": str(path), "exists": path.exists(), "checked_at": now_iso()}
    if not path.exists():
        out.update({"status": "missing"})
        return out
    out["size_bytes"] = path.stat().st_size
    out["sha256"] = sha256_file(path)
    sidecar = path.with_suffix(path.suffix + ".sha256")
    out["sha256_sidecar"] = str(sidecar)
    out["sidecar_exists"] = sidecar.exists()
    if sidecar.exists():
        sidecar_text = sidecar.read_text(encoding="utf-8", errors="replace").strip()
        first = sidecar_text.split()[0] if sidecar_text else ""
        out["sidecar_sha256"] = first
        out["sidecar_matches"] = (first == out["sha256"])
    else:
        out["sidecar_matches"] = False
    try:
        tmp = _sqlite_readonly_connect(path)
        try:
            integrity = tmp.execute("PRAGMA integrity_check").fetchone()[0]
            quick = tmp.execute("PRAGMA quick_check").fetchone()[0]
        finally:
            tmp.close()
        out["sqlite_integrity_check"] = integrity
        out["sqlite_quick_check"] = quick
        out["status"] = "ok" if integrity == "ok" and quick == "ok" and (out["sidecar_matches"] or not sidecar.exists()) else "warning"
    except Exception as e:
        out["status"] = "error"
        out["error"] = str(e)
    return out


def restore_preview(path: Path) -> Dict[str, Any]:
    path = path.expanduser()
    out = backup_verification(path)
    if not path.exists() or out.get("status") == "error":
        return out
    try:
        tmp = _sqlite_readonly_connect(path)
        counts = {}
        for t in ["assets", "service_logs", "reminders", "parts_catalog", "asset_documents", "warranty_claims", "service_templates", "service_plans", "inspection_records", "fault_reports", "audit_log"]:
            try:
                counts[t] = int(tmp.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0] or 0)
            except sqlite3.Error:
                counts[t] = -1
        schema = tmp.execute("SELECT value FROM schema_meta WHERE key='schema_version'").fetchone()
        appver = tmp.execute("SELECT value FROM schema_meta WHERE key='app_version'").fetchone()
        tmp.close()
        out["preview"] = {"schema_version": schema[0] if schema else "unknown", "app_version": appver[0] if appver else "unknown", "table_counts": counts}
        out["restore_preview_only"] = True
    except Exception as e:
        out["status"] = "error"
        out["error"] = str(e)
    return out


def checksum_manifest(conn: sqlite3.Connection, path: Optional[Path] = None) -> Dict[str, Any]:
    if path is None:
        path = EXPORT_DIR / f"sentinel-maintenance-checksum-manifest-{_dt.datetime.now().strftime('%Y%m%d-%H%M%S-%f')}.json"
    path = path.expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    files: List[Dict[str, Any]] = []
    seen: set[str] = set()

    def add_file(p: Path) -> None:
        try:
            if p == path or p.is_symlink() or not p.is_file():
                return
            rp = str(p.resolve())
            if rp in seen:
                return
            seen.add(rp)
            files.append({"path": str(p), "sha256": sha256_file(p), "size_bytes": p.stat().st_size})
        except OSError:
            pass

    add_file(DB_PATH)
    for folder in [BACKUP_DIR, EXPORT_DIR, BRIDGE_DIR]:
        if folder.exists():
            for p in sorted(folder.rglob("*")):
                add_file(p)
    manifest = {"program": PROGRAM_NUMBER, "application": APP_NAME, "version": VERSION, "created_at": now_iso(), "file_count": len(files), "files": files}
    _write_text_private(path, json.dumps(manifest, indent=2))
    audit(conn, "checksum_manifest", "export", None, str(path))
    manifest["manifest_path"] = str(path)
    return manifest


def compact_repair(conn: sqlite3.Connection) -> Dict[str, Any]:
    before = DB_PATH.stat().st_size if DB_PATH.exists() else 0
    pre = backup_db(conn)
    conn.execute("PRAGMA optimize")
    conn.execute("REINDEX")
    conn.execute("VACUUM")
    conn.commit()
    after = DB_PATH.stat().st_size if DB_PATH.exists() else 0
    report = integrity_report(conn)
    audit(conn, "compact_repair", "database", None, f"before={before};after={after}")
    return {"status": report.get("status"), "pre_repair_backup": pre, "size_before_bytes": before, "size_after_bytes": after, "integrity": report, "completed_at": now_iso()}


def audit_log_export(conn: sqlite3.Connection, path: Optional[Path] = None, limit: int = 1000) -> Dict[str, Any]:
    rows = [row_to_dict(r) for r in conn.execute("SELECT * FROM audit_log ORDER BY id DESC LIMIT ?", (limit,)).fetchall()]
    if path is None:
        path = EXPORT_DIR / f"sentinel-maintenance-audit-log-{_dt.datetime.now().strftime('%Y%m%d-%H%M%S')}.json"
    path = path.expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {"program": PROGRAM_NUMBER, "application": APP_NAME, "version": VERSION, "rows": rows, "count": len(rows), "created_at": now_iso()}
    _write_text_private(path, json.dumps(payload, indent=2))
    audit(conn, "audit_export", "export", None, str(path))
    return {"path": str(path), "count": len(rows), "created_at": now_iso()}


def recovery_status(conn: sqlite3.Connection) -> Dict[str, Any]:
    latest_backup = None
    if BACKUP_DIR.exists():
        backups = sorted([p for p in BACKUP_DIR.glob("*.db") if p.is_file()], key=lambda p: p.stat().st_mtime, reverse=True)
        latest_backup = str(backups[0]) if backups else None
    return {
        "program": PROGRAM_NUMBER,
        "application": APP_NAME,
        "version": VERSION,
        "recovery_integrity_ready": True,
        "database": str(DB_PATH),
        "backups_dir": str(BACKUP_DIR),
        "exports_dir": str(EXPORT_DIR),
        "latest_backup": latest_backup,
        "integrity": integrity_report(conn),
        "updated_at": now_iso(),
    }

def export_csv(conn: sqlite3.Connection, table: str, path: Path) -> Path:
    allowed = {"assets", "service_logs", "reminders", "parts_catalog", "asset_documents", "warranty_claims", "service_templates", "service_plans", "inspection_records", "fault_reports", "audit_log"}
    if table not in allowed:
        raise SystemExit(f"Unsupported CSV export table: {table}")
    rows = conn.execute(f"SELECT * FROM {table} ORDER BY id ASC").fetchall()
    path = path.expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    with _open_private_text(path, "w") as f:
        if rows:
            fields = list(rows[0].keys())
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            for r in rows:
                writer.writerow(_csv_safe_row(row_to_dict(r), fields))
        else:
            # write table columns even if empty
            cols = [r[1] for r in conn.execute(f"PRAGMA table_info({table})").fetchall()]
            writer = csv.DictWriter(f, fieldnames=cols)
            writer.writeheader()
    _chmod_private_file(path)
    audit(conn, "csv_export", table, None, str(path))
    return path


def backup_db(conn: sqlite3.Connection, path: Optional[Path] = None) -> Dict[str, Any]:
    if path is None:
        path = BACKUP_DIR / f"sentinel-maintenance-backup-{_dt.datetime.now().strftime('%Y%m%d-%H%M%S-%f')}.db"
    path = _unique_path(path.expanduser())
    path.parent.mkdir(parents=True, exist_ok=True)
    _refuse_symlink_target(path, "backup")
    # Use SQLite backup API.
    dest = sqlite3.connect(path)
    try:
        with dest:
            conn.backup(dest)
    finally:
        dest.close()
    _chmod_private_file(path)
    digest = sha256_file(path)
    sidecar = path.with_suffix(path.suffix + ".sha256")
    _write_text_private(sidecar, f"{digest}  {path.name}\n")
    audit(conn, "backup", "database", None, str(path))
    return {"backup_path": str(path), "sha256": digest, "sha256_sidecar": str(sidecar)}


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def aegis_export(conn: sqlite3.Connection) -> Dict[str, Any]:
    vault = Path.home() / "AEGIS_Vault"
    if vault.exists():
        base = vault / "Knowledge" / "Household" / "Sentinel Maintenance" / "Exports"
    else:
        base = EXPORT_DIR / "aegis-handoff"
    stamp = _dt.datetime.now().strftime("%Y%m%d-%H%M%S-%f")
    outdir = base / stamp
    _mkdir_private(outdir)
    files = {}
    payloads = {
        "summary.json": summary(conn),
        "dashboard.json": dashboard(conn),
        "health.json": health(conn),
        "manifest.json": aegis_manifest(),
        "service_queue.json": {"items": service_queue(conn, 60)},
        "service_plan_summary.json": service_plan_summary(conn, 90),
        "cost_report.json": cost_report(conn, days=365),
        "bridge_summary.json": bridge_summary(conn),
        "inspection_summary.json": inspection_summary(conn, 60),
        "fault_summary.json": fault_summary(conn),
        "integrity_check.json": integrity_report(conn),
        "recovery_status.json": recovery_status(conn),
        "inspections.json": {"items": list_inspections(conn, include_closed=True, limit=1000)},
        "faults.json": {"items": list_faults(conn, include_closed=True, limit=1000)},
        "service_templates.json": {"items": list_service_templates(conn)},
        "service_plans.json": {"items": list_service_plans(conn, days=365, include_archived=True)},
        "service_due.json": {"items": due_assets(conn, 60)},
        "warranty_expiring.json": {"items": warranty_expiring(conn, 90)},
        "open_reminders.json": {"items": list_reminders(conn, include_done=False, days=365)},
        "parts_catalog.json": {"items": list_parts(conn)},
        "asset_documents.json": {"items": list_documents(conn)},
        "warranty_center.json": warranty_center(conn, 90),
        "warranty_claims.json": {"items": list_warranty_claims(conn, include_closed=True, limit=500)},
    }
    for name, payload in payloads.items():
        p = outdir / name
        _write_text_private(p, json.dumps(payload, indent=2))
        files[name] = str(p)
    export_csv(conn, "assets", outdir / "assets.csv")
    export_csv(conn, "service_logs", outdir / "service_logs.csv")
    export_csv(conn, "parts_catalog", outdir / "parts_catalog.csv")
    export_csv(conn, "asset_documents", outdir / "asset_documents.csv")
    export_csv(conn, "warranty_claims", outdir / "warranty_claims.csv")
    export_csv(conn, "inspection_records", outdir / "inspection_records.csv")
    export_csv(conn, "fault_reports", outdir / "fault_reports.csv")
    files["assets.csv"] = str(outdir / "assets.csv")
    files["service_logs.csv"] = str(outdir / "service_logs.csv")
    files["parts_catalog.csv"] = str(outdir / "parts_catalog.csv")
    files["asset_documents.csv"] = str(outdir / "asset_documents.csv")
    files["warranty_claims.csv"] = str(outdir / "warranty_claims.csv")
    files["inspection_records.csv"] = str(outdir / "inspection_records.csv")
    files["fault_reports.csv"] = str(outdir / "fault_reports.csv")
    ledger_meta = export_ledger_bridge(conn, outdir / "ledger_bridge.csv")
    inventory_meta = export_inventory_bridge(conn, outdir / "inventory_bridge.csv", include_archived=True)
    files["ledger_bridge.csv"] = ledger_meta["path"]
    files["ledger_bridge.csv.json"] = ledger_meta["path"] + ".json"
    files["inventory_bridge.csv"] = inventory_meta["path"]
    files["inventory_bridge.csv.json"] = inventory_meta["path"] + ".json"
    manifest = {"export_dir": str(outdir), "used_aegis_vault": vault.exists(), "files": files, "created_at": now_iso()}
    _write_text_private(outdir / "export_manifest.json", json.dumps(manifest, indent=2))
    audit(conn, "aegis_export", "export", None, str(outdir))
    return manifest


def print_json(obj: Any) -> None:
    print(json.dumps(obj, indent=2, default=str))


def print_table(rows: List[Dict[str, Any]], fields: List[str]) -> None:
    if not rows:
        print("No records found.")
        return
    widths = {f: max(len(f), *(len(str(r.get(f, ""))) for r in rows)) for f in fields}
    print("  ".join(f.ljust(widths[f]) for f in fields))
    print("  ".join("-" * widths[f] for f in fields))
    for r in rows:
        print("  ".join(str(r.get(f, "")).ljust(widths[f]) for f in fields))


# ----------------------------- GUI ---------------------------------------

def run_gui() -> None:
    try:
        import tkinter as tk
        from tkinter import filedialog, messagebox, ttk
    except Exception as e:  # pragma: no cover
        raise SystemExit(f"Tkinter GUI unavailable: {e}")

    conn = connect()

    class App:
        def __init__(self, root: tk.Tk):
            self.root = root
            root.title(f"{APP_NAME} v{VERSION}")
            root.geometry("1680x900")
            root.minsize(1280, 760)
            root.configure(bg=THEME["bg"])
            root.bind("<Control-q>", lambda e: self.close())
            root.protocol("WM_DELETE_WINDOW", self.close)
            self.style = ttk.Style()
            try:
                self.style.theme_use("clam")
            except Exception:
                pass
            self.style.configure(".", background=THEME["bg"], foreground=THEME["fg"], fieldbackground=THEME["field"], bordercolor=THEME["panel"])
            self.style.configure("TFrame", background=THEME["bg"])
            self.style.configure("Panel.TFrame", background=THEME["panel"], relief="flat")
            self.style.configure("Card.TFrame", background=THEME["panel2"], relief="flat")
            self.style.configure("TLabel", background=THEME["bg"], foreground=THEME["fg"])
            self.style.configure("Title.TLabel", background=THEME["bg"], foreground=THEME["gold"], font=("Sans", 18, "bold"))
            self.style.configure("Muted.TLabel", background=THEME["bg"], foreground=THEME["muted"])
            self.style.configure("Status.TLabel", background=THEME["panel"], foreground=THEME["cyan"], font=("Sans", 10, "bold"))
            self.style.configure("TNotebook", background=THEME["bg"], borderwidth=0)
            self.style.configure("TNotebook.Tab", padding=(10, 8), font=("Sans", 9), background=THEME["panel"], foreground=THEME["fg"])
            self.style.map("TNotebook.Tab", background=[("selected", THEME["field"])], foreground=[("selected", THEME["gold"])])
            self.style.configure("Treeview", background=THEME["field"], foreground=THEME["fg"], fieldbackground=THEME["field"], rowheight=26, borderwidth=0)
            self.style.configure("Treeview.Heading", background=THEME["panel"], foreground=THEME["gold"], font=("Sans", 10, "bold"))
            self.style.map("Treeview", background=[("selected", THEME["gold"])], foreground=[("selected", "#050505")])
            self.style.configure("TButton", background=THEME["field"], foreground=THEME["fg"], padding=6)
            self.style.map("TButton", background=[("active", THEME["gold"])], foreground=[("active", "#050505")])
            self.style.configure("TCombobox", fieldbackground=THEME["field"], background=THEME["field"], foreground=THEME["fg"], arrowcolor=THEME["gold"])
            self.root.option_add("*Entry.Background", THEME["field"])
            self.root.option_add("*Entry.Foreground", THEME["fg"])
            self.root.option_add("*Entry.InsertBackground", THEME["fg"])
            self.root.option_add("*Text.Background", THEME["field"])
            self.root.option_add("*Text.Foreground", THEME["fg"])
            self.root.option_add("*selectBackground", THEME["gold"])
            self.root.option_add("*selectForeground", "#050505")

            self.nb = ttk.Notebook(root)
            self.nb.pack(fill="both", expand=True, padx=8, pady=8)
            self.status = tk.StringVar(value="Ready. Ctrl+Q closes.")
            tk.Label(root, textvariable=self.status, anchor="w", bg=THEME["panel"], fg=THEME["muted"], padx=8).pack(fill="x", side="bottom")
            self.make_dashboard()
            self.make_service_queue()
            self.make_service_plans()
            self.make_inspections_faults()
            self.make_parts_documents()
            self.make_cost_bridges()
            self.make_assets()
            self.make_service()
            self.make_reminders()
            self.make_recovery()
            self.make_exports()
            self.make_manual()
            self.refresh_all()

        def frame(self, title: str):
            f = tk.Frame(self.nb, bg=THEME["bg"])
            self.nb.add(f, text=title)
            return f

        def label(self, parent, text, size=10, gold=False):
            return tk.Label(parent, text=text, bg=THEME["bg"], fg=(THEME["gold"] if gold else THEME["fg"]), font=("Sans", size, "bold" if gold else "normal"))

        def labelframe(self, parent, text, **kw):
            # v0.3.1 hotfix: allow callers to override padding without passing
            # duplicate padx/pady to tkinter.LabelFrame, which caused the v0.3.0
            # GUI to abort during startup on the Filters panel.
            padx = kw.pop("padx", 8)
            pady = kw.pop("pady", 8)
            return tk.LabelFrame(parent, text=text, bg=THEME["panel"], fg=THEME["gold"],
                                 highlightbackground=THEME["gold"], highlightcolor=THEME["gold"],
                                 bd=1, padx=padx, pady=pady, **kw)

        def panel(self, parent, **kw):
            return tk.Frame(parent, bg=THEME["panel"], highlightbackground=THEME["gold"], highlightthickness=1, **kw)

        def entry_row(self, parent, row, label, var, width=24):
            tk.Label(parent, text=label, bg=THEME["bg"], fg=THEME["fg"]).grid(row=row, column=0, sticky="w", padx=4, pady=3)
            e = tk.Entry(parent, textvariable=var, width=width, bg=THEME["field"], fg=THEME["fg"], insertbackground=THEME["fg"])
            e.grid(row=row, column=1, sticky="ew", padx=4, pady=3)
            return e

        def combo_row(self, parent, row, label, var, values, width=22):
            tk.Label(parent, text=label, bg=THEME["bg"], fg=THEME["fg"]).grid(row=row, column=0, sticky="w", padx=4, pady=3)
            cb = ttk.Combobox(parent, textvariable=var, values=values, width=width)
            cb.grid(row=row, column=1, sticky="ew", padx=4, pady=3)
            return cb

        def readonly_entry_row(self, parent, row, label, var, width=24):
            tk.Label(parent, text=label, bg=THEME["bg"], fg=THEME["fg"]).grid(row=row, column=0, sticky="w", padx=4, pady=3)
            e = tk.Entry(parent, textvariable=var, width=width, bg=THEME["field2"], fg=THEME["gold"], insertbackground=THEME["fg"], state="readonly", readonlybackground=THEME["field2"])
            e.grid(row=row, column=1, sticky="ew", padx=4, pady=3)
            return e

        def scrollable_panel(self, parent, width=330):
            outer = tk.Frame(parent, bg=THEME["bg"], width=width)
            outer.pack_propagate(False)
            canvas = tk.Canvas(outer, bg=THEME["bg"], highlightthickness=0, width=width)
            scrollbar = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
            inner = tk.Frame(canvas, bg=THEME["bg"])
            inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
            canvas.create_window((0, 0), window=inner, anchor="nw")
            canvas.configure(yscrollcommand=scrollbar.set)
            canvas.pack(side="left", fill="both", expand=True)
            scrollbar.pack(side="right", fill="y")
            def _wheel(event):
                try:
                    canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
                except Exception:
                    pass
            canvas.bind_all("<MouseWheel>", _wheel)
            return outer, inner

        def update_asset_id_preview(self, force: bool = False):
            if hasattr(self, "asset_vars") and "id" in self.asset_vars:
                current = self.asset_vars["id"].get().strip()
                if force or not current or current.startswith("Auto:"):
                    self.asset_vars["id"].set(f"Auto: {next_table_id(conn, 'assets')}")

        def autofill_selected_asset_context(self, asset_id: int):
            value = str(asset_id)
            for name in ("service_vars", "rem_vars", "part_vars", "doc_vars", "plan_vars", "inspection_vars", "fault_vars"):
                obj = getattr(self, name, None)
                if isinstance(obj, dict) and "asset_id" in obj:
                    obj["asset_id"].set(value)

        def selected_asset_from_anywhere(self):
            # Main asset list is the primary selector. Other tables fill their own selected IDs.
            return self.selected_asset_id()

        def make_dashboard(self):
            f = self.frame("Dashboard")
            header = tk.Frame(f, bg=THEME["panel"], highlightbackground=THEME["gold"], highlightthickness=1)
            header.pack(fill="x", padx=12, pady=(12, 8))
            tk.Label(header, text="Sentinel Maintenance", bg=THEME["panel"], fg=THEME["gold"], font=("Sans", 20, "bold")).pack(anchor="w", padx=12, pady=(10, 2))
            tk.Label(header, text="Program 114 — household, workshop, vehicle, device, appliance, and off-grid maintenance.", bg=THEME["panel"], fg=THEME["fg"]).pack(anchor="w", padx=12)
            tk.Label(header, text="AEGIS Dark / Sentinel Gold suite theme active • local-only • Ctrl+Q closes", bg=THEME["panel"], fg=THEME["cyan"]).pack(anchor="w", padx=12, pady=(2, 10))
            self.cards = tk.Frame(f, bg=THEME["bg"])
            self.cards.pack(fill="x", padx=12, pady=12)
            self.card_vars = {k: tk.StringVar(value="0") for k in ["assets", "due", "overdue", "warranty", "reminders", "cost"]}
            for i, (key, title) in enumerate([
                ("assets", "Active Assets"), ("due", "Service Due 30d"), ("overdue", "Overdue"),
                ("warranty", "Warranty 60d"), ("reminders", "Open Reminders"), ("cost", "Service Cost")]):
                box = tk.Frame(self.cards, bg=THEME["field"], highlightbackground=THEME["gold"], highlightthickness=1)
                box.grid(row=0, column=i, padx=5, sticky="nsew")
                self.cards.grid_columnconfigure(i, weight=1)
                tk.Label(box, text=title, bg=THEME["field"], fg=THEME["gold"], font=("Sans", 10, "bold")).pack(pady=(8,2))
                tk.Label(box, textvariable=self.card_vars[key], bg=THEME["field"], fg=THEME["fg"], font=("Sans", 16, "bold")).pack(pady=(0,8))
            btns = tk.Frame(f, bg=THEME["bg"])
            btns.pack(fill="x", padx=12, pady=4)
            ttk.Button(btns, text="Add Asset", command=lambda: self.nb.select(self.assets_tab)).pack(side="left", padx=4)
            ttk.Button(btns, text="Service Queue", command=lambda: self.nb.select(self.service_queue_tab)).pack(side="left", padx=4)
            ttk.Button(btns, text="Service Plans", command=lambda: self.nb.select(self.service_plans_tab)).pack(side="left", padx=4)
            ttk.Button(btns, text="Parts & Docs", command=lambda: self.nb.select(self.parts_docs_tab)).pack(side="left", padx=4)
            ttk.Button(btns, text="Costs & Bridges", command=lambda: self.nb.select(self.cost_bridge_tab)).pack(side="left", padx=4)
            ttk.Button(btns, text="Service Log", command=lambda: self.nb.select(self.service_tab)).pack(side="left", padx=4)
            ttk.Button(btns, text="Reminders", command=lambda: self.nb.select(self.reminders_tab)).pack(side="left", padx=4)
            ttk.Button(btns, text="Backup", command=self.gui_backup).pack(side="left", padx=4)
            ttk.Button(btns, text="Refresh", command=self.refresh_all).pack(side="left", padx=4)
            ttk.Button(btns, text="Close", command=self.close).pack(side="right", padx=4)
            lists = tk.Frame(f, bg=THEME["bg"])
            lists.pack(fill="both", expand=True, padx=12, pady=8)
            self.due_tree = self.tree(lists, ["id", "name", "type", "next_service", "days"], height=8)
            self.due_tree.pack(side="left", fill="both", expand=True, padx=(0,6))
            self.warranty_tree = self.tree(lists, ["id", "name", "type", "warranty", "days"], height=8)
            self.warranty_tree.pack(side="left", fill="both", expand=True, padx=(6,0))

        def make_service_queue(self):
            self.service_queue_tab = f = self.frame("Service Queue")
            self.label(f, "Service Queue", 16, True).pack(anchor="w", padx=12, pady=(12, 4))
            self.label(f, "Upcoming, due, and overdue maintenance with AEGIS-readable priority labels.").pack(anchor="w", padx=12)
            bar = tk.Frame(f, bg=THEME["bg"])
            bar.pack(fill="x", padx=12, pady=8)
            self.service_queue_days = tk.StringVar(value="60")
            tk.Label(bar, text="Window days", bg=THEME["bg"], fg=THEME["fg"]).pack(side="left", padx=(0, 4))
            tk.Entry(bar, textvariable=self.service_queue_days, width=8, bg=THEME["field"], fg=THEME["fg"], insertbackground=THEME["fg"]).pack(side="left", padx=4)
            ttk.Button(bar, text="Refresh Queue", command=self.refresh_service_queue).pack(side="left", padx=4)
            ttk.Button(bar, text="Service Selected", command=self.queue_service_selected).pack(side="left", padx=4)
            ttk.Button(bar, text="Mark Needs Service", command=lambda:self.queue_status_selected("Needs Service")).pack(side="left", padx=4)
            ttk.Button(bar, text="Mark In Repair", command=lambda:self.queue_status_selected("In Repair")).pack(side="left", padx=4)
            ttk.Button(bar, text="Mark Active", command=lambda:self.queue_status_selected("Active")).pack(side="left", padx=4)
            self.service_queue_tree = self.tree(f, ["id","name","type","location","next_service","days","queue_state","priority","recommended"], height=24)
            self.service_queue_tree.pack(fill="both", expand=True, padx=12, pady=8)
            self.service_queue_tree.bind("<Double-1>", lambda e: self.queue_service_selected())

        def refresh_service_queue(self):
            try:
                days = int(self.service_queue_days.get() or "60")
            except ValueError:
                days = 60
                self.service_queue_days.set("60")
            rows = service_queue(conn, days)
            out = [{"id":r["id"],"name":r["name"],"type":r["asset_type"],"location":r["location"],"next_service":r["next_service_date"],"days":r.get("days_until_service"),"queue_state":r.get("service_queue_state"),"priority":r.get("service_priority"),"recommended":r.get("recommended_action")} for r in rows]
            self.set_tree(self.service_queue_tree, out, ["id","name","type","location","next_service","days","queue_state","priority","recommended"])

        def selected_queue_asset_id(self):
            sel = self.service_queue_tree.selection()
            if not sel: raise ValueError("Select a queued asset first.")
            return int(self.service_queue_tree.item(sel[0], "values")[0])

        def queue_service_selected(self):
            try:
                aid = self.selected_queue_asset_id()
                self.service_vars["asset_id"].set(str(aid))
                self.service_vars["date"].set(today_iso())
                self.service_vars["type"].set("Maintenance")
                self.service_vars["summary"].set("Routine service from queue")
                self.nb.select(self.service_tab)
                self.status.set(f"Service form prepared from queue for asset ID {aid}.")
            except Exception as e: messagebox.showerror(APP_NAME, str(e))

        def queue_status_selected(self, status):
            try:
                set_asset_status(conn, self.selected_queue_asset_id(), status); conn.commit(); self.refresh_all()
            except Exception as e: messagebox.showerror(APP_NAME, str(e))


        def make_service_plans(self):
            self.service_plans_tab = f = self.frame("Service Plans")
            self.label(f, "Service Plans & Templates", 16, True).pack(anchor="w", padx=12, pady=(12,4))
            self.label(f, "Create recurring maintenance plans, reusable checklists, and planned-service schedules.").pack(anchor="w", padx=12)
            outer = tk.Frame(f, bg=THEME["bg"])
            outer.pack(fill="both", expand=True, padx=10, pady=10)
            left, left_inner = self.scrollable_panel(outer, width=370)
            left.pack(side="left", fill="y", padx=(0,10))

            pf = self.labelframe(left_inner, "Service Plan")
            pf.pack(fill="x")
            self.plan_vars = {k: tk.StringVar() for k in ["asset_id","template_id","name","type","interval","last","next","checklist","parts","cost","provider","status","notes"]}
            self.plan_vars["type"].set("Maintenance"); self.plan_vars["interval"].set("90"); self.plan_vars["status"].set("Active")
            r=0
            self.readonly_entry_row(pf,r,"Asset ID",self.plan_vars["asset_id"],18); r+=1
            self.entry_row(pf,r,"Template ID",self.plan_vars["template_id"],18); r+=1
            self.entry_row(pf,r,"Plan Name",self.plan_vars["name"],18); r+=1
            self.combo_row(pf,r,"Service Type",self.plan_vars["type"],SERVICE_TYPES,18); r+=1
            self.combo_row(pf,r,"Interval Days",self.plan_vars["interval"],[str(x) for x in SERVICE_INTERVAL_PRESETS],18); r+=1
            self.entry_row(pf,r,"Last Service",self.plan_vars["last"],18); r+=1
            self.entry_row(pf,r,"Next Service",self.plan_vars["next"],18); r+=1
            self.combo_row(pf,r,"Provider",self.plan_vars["provider"],all_suppliers(conn),18); r+=1
            self.combo_row(pf,r,"Status",self.plan_vars["status"],SERVICE_PLAN_STATUSES,18); r+=1
            self.entry_row(pf,r,"Est. Cost",self.plan_vars["cost"],18); r+=1
            self.entry_row(pf,r,"Checklist",self.plan_vars["checklist"],18); r+=1
            self.entry_row(pf,r,"Parts Notes",self.plan_vars["parts"],18); r+=1
            self.entry_row(pf,r,"Notes",self.plan_vars["notes"],18); r+=1
            ttk.Button(pf, text="Add Plan", command=self.gui_add_service_plan).grid(row=r,column=0,sticky="ew",padx=4,pady=6)
            ttk.Button(pf, text="Complete Selected", command=self.gui_complete_service_plan).grid(row=r,column=1,sticky="ew",padx=4,pady=6)

            tf = self.labelframe(left_inner, "Reusable Template")
            tf.pack(fill="x", pady=(8,0))
            self.template_vars = {k: tk.StringVar() for k in ["name","asset_type","category","service_type","interval","checklist","parts","cost","provider","notes"]}
            self.template_vars["asset_type"].set("Other"); self.template_vars["service_type"].set("Maintenance"); self.template_vars["interval"].set("90")
            r=0
            self.entry_row(tf,r,"Name",self.template_vars["name"],18); r+=1
            self.combo_row(tf,r,"Asset Type",self.template_vars["asset_type"],ASSET_TYPES,18); r+=1
            self.combo_row(tf,r,"Category",self.template_vars["category"],ASSET_CATEGORIES,18); r+=1
            self.combo_row(tf,r,"Service Type",self.template_vars["service_type"],SERVICE_TYPES,18); r+=1
            self.combo_row(tf,r,"Interval Days",self.template_vars["interval"],[str(x) for x in SERVICE_INTERVAL_PRESETS],18); r+=1
            self.entry_row(tf,r,"Checklist",self.template_vars["checklist"],18); r+=1
            self.entry_row(tf,r,"Parts Notes",self.template_vars["parts"],18); r+=1
            self.entry_row(tf,r,"Est. Cost",self.template_vars["cost"],18); r+=1
            self.combo_row(tf,r,"Provider",self.template_vars["provider"],all_suppliers(conn),18); r+=1
            self.entry_row(tf,r,"Notes",self.template_vars["notes"],18); r+=1
            ttk.Button(tf, text="Add Template", command=self.gui_add_service_template).grid(row=r,column=0,columnspan=2,sticky="ew",padx=4,pady=6)

            right = tk.Frame(outer, bg=THEME["bg"])
            right.pack(side="left", fill="both", expand=True)
            self.plan_tree = self.tree(right, ["id","asset","plan","type","interval","last","next","state","est_cost"], height=12)
            self.plan_tree.pack(fill="both", expand=True, padx=4, pady=(0,8))
            self.plan_tree.bind("<Double-1>", self.load_service_plan_selected)
            self.template_tree = self.tree(right, ["id","name","asset_type","service_type","interval","est_cost"], height=8)
            self.template_tree.pack(fill="both", expand=True, padx=4, pady=(8,0))
            self.template_tree.bind("<Double-1>", self.load_template_selected)

        def refresh_service_plans(self):
            if not hasattr(self, "plan_tree"):
                return
            plans = list_service_plans(conn, days=3650, include_archived=True)
            out = [{"id":p["id"],"asset":p.get("asset_name"),"plan":p["plan_name"],"type":p["service_type"],"interval":p["interval_days"],"last":p["last_service_date"],"next":p["next_service_date"],"state":p.get("plan_state"),"est_cost":p.get("estimated_cost")} for p in plans]
            self.set_tree(self.plan_tree, out, ["id","asset","plan","type","interval","last","next","state","est_cost"])
            templates = list_service_templates(conn, include_inactive=True)
            tout = [{"id":t["id"],"name":t["name"],"asset_type":t["asset_type"],"service_type":t["service_type"],"interval":t["interval_days"],"est_cost":t["estimated_cost"]} for t in templates]
            self.set_tree(self.template_tree, tout, ["id","name","asset_type","service_type","interval","est_cost"])

        def gui_add_service_template(self):
            try:
                ns = argparse.Namespace(name=self.template_vars["name"].get().strip(), asset_type=self.template_vars["asset_type"].get(), category=self.template_vars["category"].get(), service_type=self.template_vars["service_type"].get(), interval_days=int(self.template_vars["interval"].get() or 90), checklist=self.template_vars["checklist"].get(), parts=self.template_vars["parts"].get(), estimated_cost=float(self.template_vars["cost"].get() or 0), provider=self.template_vars["provider"].get(), notes=self.template_vars["notes"].get(), inactive=False)
                if not ns.name: raise ValueError("Template name is required.")
                tid = add_service_template(conn, ns); conn.commit(); self.refresh_all(); self.status.set(f"Added service template ID {tid}.")
            except Exception as e: messagebox.showerror(APP_NAME, str(e))

        def gui_add_service_plan(self):
            try:
                aid = self.plan_vars["asset_id"].get().strip()
                if not aid: raise ValueError("Select an asset first so Asset ID can autofill.")
                tid_raw = self.plan_vars["template_id"].get().strip()
                ns = argparse.Namespace(asset_id=int(aid), template_id=int(tid_raw) if tid_raw else None, name=self.plan_vars["name"].get().strip(), service_type=self.plan_vars["type"].get(), interval_days=int(self.plan_vars["interval"].get() or 90), last_service=self.plan_vars["last"].get(), next_service=self.plan_vars["next"].get(), checklist=self.plan_vars["checklist"].get(), parts=self.plan_vars["parts"].get(), estimated_cost=float(self.plan_vars["cost"].get() or 0), provider=self.plan_vars["provider"].get(), status=self.plan_vars["status"].get(), notes=self.plan_vars["notes"].get())
                pid = add_service_plan(conn, ns); conn.commit(); self.refresh_all(); self.status.set(f"Added service plan ID {pid}.")
            except Exception as e: messagebox.showerror(APP_NAME, str(e))

        def selected_plan_id(self):
            sel = self.plan_tree.selection()
            if not sel: raise ValueError("Select a service plan first.")
            return int(self.plan_tree.item(sel[0], "values")[0])

        def gui_complete_service_plan(self):
            try:
                info = complete_service_plan(conn, self.selected_plan_id()); conn.commit(); self.refresh_all(); self.status.set(f"Completed plan {info['plan_id']}; next service {info['next_service_date']}.")
            except Exception as e: messagebox.showerror(APP_NAME, str(e))

        def load_service_plan_selected(self, event=None):
            try:
                pid = self.selected_plan_id()
                row = conn.execute("SELECT * FROM service_plans WHERE id=?", (pid,)).fetchone()
                if not row: return
                p = row_to_dict(row)
                mapping = {"asset_id":"asset_id","template_id":"template_id","name":"plan_name","type":"service_type","interval":"interval_days","last":"last_service_date","next":"next_service_date","checklist":"checklist","parts":"parts_notes","cost":"estimated_cost","provider":"provider","status":"status","notes":"notes"}
                for k,col in mapping.items(): self.plan_vars[k].set(str(p.get(col) or ""))
            except Exception as e: messagebox.showerror(APP_NAME, str(e))

        def load_template_selected(self, event=None):
            try:
                sel = self.template_tree.selection()
                if not sel: return
                tid = int(self.template_tree.item(sel[0], "values")[0])
                t = get_service_template(conn, tid)
                self.plan_vars["template_id"].set(str(tid))
                self.plan_vars["name"].set(t.get("name") or "")
                self.plan_vars["type"].set(t.get("service_type") or "Maintenance")
                self.plan_vars["interval"].set(str(t.get("interval_days") or 90))
                self.plan_vars["checklist"].set(t.get("checklist") or "")
                self.plan_vars["parts"].set(t.get("parts_notes") or "")
                self.plan_vars["cost"].set(str(t.get("estimated_cost") or 0))
                self.plan_vars["provider"].set(t.get("provider") or "")
                self.plan_vars["notes"].set(t.get("notes") or "")
                self.status.set(f"Loaded template ID {tid} into Service Plan form.")
            except Exception as e: messagebox.showerror(APP_NAME, str(e))



        def make_inspections_faults(self):
            self.inspect_tab = f = self.frame("Inspections & Faults")
            self.label(f, "Inspections, Condition Reports & Fault Register", 16, True).pack(anchor="w", padx=12, pady=(12,4))
            self.label(f, "Record inspections, condition ratings, action-required findings, and active faults for selected assets.").pack(anchor="w", padx=12)
            outer = tk.Frame(f, bg=THEME["bg"])
            outer.pack(fill="both", expand=True, padx=10, pady=10)
            left, left_inner = self.scrollable_panel(outer, width=350)
            left.pack(side="left", fill="y", padx=(0,10))
            inf = self.labelframe(left_inner, "Inspection Record")
            inf.pack(fill="x")
            self.inspection_vars = {k: tk.StringVar() for k in ["asset_id","date","condition","checklist","findings","actions","priority","next","photo","status","notes"]}
            self.inspection_vars["date"].set(today_iso()); self.inspection_vars["condition"].set("Good"); self.inspection_vars["priority"].set("Normal"); self.inspection_vars["status"].set("Open")
            r=0
            self.readonly_entry_row(inf,r,"Asset ID",self.inspection_vars["asset_id"],18); r+=1
            self.entry_row(inf,r,"Date",self.inspection_vars["date"],18); r+=1
            self.combo_row(inf,r,"Condition",self.inspection_vars["condition"],INSPECTION_CONDITIONS,18); r+=1
            self.entry_row(inf,r,"Checklist",self.inspection_vars["checklist"],18); r+=1
            self.entry_row(inf,r,"Findings",self.inspection_vars["findings"],18); r+=1
            self.entry_row(inf,r,"Actions",self.inspection_vars["actions"],18); r+=1
            self.combo_row(inf,r,"Priority",self.inspection_vars["priority"],PRIORITIES,18); r+=1
            self.entry_row(inf,r,"Next Inspect",self.inspection_vars["next"],18); r+=1
            self.entry_row(inf,r,"Photo/Path",self.inspection_vars["photo"],18); r+=1
            self.combo_row(inf,r,"Status",self.inspection_vars["status"],INSPECTION_STATUSES,18); r+=1
            self.entry_row(inf,r,"Notes",self.inspection_vars["notes"],18); r+=1
            ttk.Button(inf,text="Browse Photo",command=self.gui_browse_inspection_photo).grid(row=r,column=0,sticky="ew",pady=3)
            ttk.Button(inf,text="Add Inspection",command=self.gui_add_inspection).grid(row=r,column=1,sticky="ew",pady=3); r+=1

            ff = self.labelframe(left_inner, "Fault Report")
            ff.pack(fill="x", pady=(10,0))
            self.fault_vars = {k: tk.StringVar() for k in ["asset_id","date","severity","issue","symptom","cause","action","status","notes"]}
            self.fault_vars["date"].set(today_iso()); self.fault_vars["severity"].set("Medium"); self.fault_vars["status"].set("Open")
            r=0
            self.readonly_entry_row(ff,r,"Asset ID",self.fault_vars["asset_id"],18); r+=1
            self.entry_row(ff,r,"Date",self.fault_vars["date"],18); r+=1
            self.combo_row(ff,r,"Severity",self.fault_vars["severity"],FAULT_SEVERITIES,18); r+=1
            self.entry_row(ff,r,"Issue",self.fault_vars["issue"],18); r+=1
            self.entry_row(ff,r,"Symptom",self.fault_vars["symptom"],18); r+=1
            self.entry_row(ff,r,"Cause",self.fault_vars["cause"],18); r+=1
            self.entry_row(ff,r,"Action",self.fault_vars["action"],18); r+=1
            self.combo_row(ff,r,"Status",self.fault_vars["status"],FAULT_STATUSES,18); r+=1
            self.entry_row(ff,r,"Notes",self.fault_vars["notes"],18); r+=1
            ttk.Button(ff,text="Add Fault",command=self.gui_add_fault).grid(row=r,column=0,columnspan=2,sticky="ew",pady=3); r+=1
            ttk.Button(ff,text="Mark Selected Resolved",command=self.gui_resolve_selected_fault).grid(row=r,column=0,columnspan=2,sticky="ew",pady=3)

            right = tk.Frame(outer, bg=THEME["bg"])
            right.pack(side="left", fill="both", expand=True)
            self.inspection_tree = self.tree(right, ["id","asset","date","condition","state","priority","next","photo"], height=11)
            self.inspection_tree.pack(fill="both", expand=True, padx=4, pady=(0,8))
            self.fault_tree = self.tree(right, ["id","asset","date","severity","issue","status"], height=10)
            self.fault_tree.pack(fill="both", expand=True, padx=4, pady=(8,8))
            self.inspection_summary_text = tk.Text(right, bg=THEME["field"], fg=THEME["fg"], height=8, wrap="word")
            self.inspection_summary_text.pack(fill="both", expand=True, padx=4, pady=(8,0))

        def refresh_inspections_faults(self):
            if not hasattr(self, "inspection_tree"):
                return
            inspections = list_inspections(conn, include_closed=True, limit=250)
            self.set_tree(self.inspection_tree, [{"id":i["id"],"asset":i.get("asset_name") or "","date":i.get("inspection_date"),"condition":i.get("condition_rating"),"state":i.get("inspection_state"),"priority":i.get("priority"),"next":i.get("next_inspection_date"),"photo":"yes" if i.get("photo_path") else ""} for i in inspections], ["id","asset","date","condition","state","priority","next","photo"])
            faults = list_faults(conn, include_closed=True, limit=250)
            self.set_tree(self.fault_tree, [{"id":f["id"],"asset":f.get("asset_name") or "","date":f.get("report_date"),"severity":f.get("severity"),"issue":f.get("issue"),"status":f.get("status")} for f in faults], ["id","asset","date","severity","issue","status"])
            payload = {"inspection_summary": inspection_summary(conn, 60), "fault_summary": fault_summary(conn)}
            self.inspection_summary_text.delete("1.0", "end")
            self.inspection_summary_text.insert("end", json.dumps(payload, indent=2, default=str))

        def gui_browse_inspection_photo(self):
            p = filedialog.askopenfilename(title="Select inspection photo or evidence file")
            if p: self.inspection_vars["photo"].set(p)

        def gui_add_inspection(self):
            try:
                aid = self.inspection_vars["asset_id"].get().strip()
                if not aid: raise ValueError("Select an asset first so Asset ID can autofill.")
                ns = argparse.Namespace(asset_id=int(aid), date=self.inspection_vars["date"].get(), condition=self.inspection_vars["condition"].get(), checklist=self.inspection_vars["checklist"].get(), findings=self.inspection_vars["findings"].get(), actions=self.inspection_vars["actions"].get(), priority=self.inspection_vars["priority"].get(), next_inspection=self.inspection_vars["next"].get(), photo=self.inspection_vars["photo"].get(), status=self.inspection_vars["status"].get(), notes=self.inspection_vars["notes"].get())
                iid = add_inspection(conn, ns); conn.commit(); self.refresh_all(); self.status.set(f"Added inspection ID {iid}.")
            except Exception as e: messagebox.showerror(APP_NAME, str(e))

        def gui_add_fault(self):
            try:
                aid = self.fault_vars["asset_id"].get().strip()
                if not aid: raise ValueError("Select an asset first so Asset ID can autofill.")
                ns = argparse.Namespace(asset_id=int(aid), date=self.fault_vars["date"].get(), severity=self.fault_vars["severity"].get(), issue=self.fault_vars["issue"].get().strip(), symptom=self.fault_vars["symptom"].get(), cause=self.fault_vars["cause"].get(), action=self.fault_vars["action"].get(), status=self.fault_vars["status"].get(), resolved_date="", service_log_id=None, notes=self.fault_vars["notes"].get())
                if not ns.issue: raise ValueError("Fault issue is required.")
                fid = add_fault(conn, ns); conn.commit(); self.refresh_all(); self.status.set(f"Added fault ID {fid}.")
            except Exception as e: messagebox.showerror(APP_NAME, str(e))

        def selected_fault_id(self):
            sel = self.fault_tree.selection()
            if not sel: raise ValueError("Select a fault first.")
            return int(self.fault_tree.item(sel[0], "values")[0])

        def gui_resolve_selected_fault(self):
            try:
                row = set_fault_status(conn, self.selected_fault_id(), "Resolved"); conn.commit(); self.refresh_all(); self.status.set(f"Resolved fault ID {row.get('id')}.")
            except Exception as e: messagebox.showerror(APP_NAME, str(e))

        def make_parts_documents(self):
            self.parts_docs_tab = f = self.frame("Parts & Documents")
            self.label(f, "Parts, Documents & Warranty Center", 16, True).pack(anchor="w", padx=12, pady=(12,4))
            self.label(f, "Track spare parts, manuals, receipts, warranty documents, and claim records for household/workshop assets.").pack(anchor="w", padx=12)
            outer = tk.Frame(f, bg=THEME["bg"])
            outer.pack(fill="both", expand=True, padx=10, pady=10)
            left, left_inner = self.scrollable_panel(outer, width=330)
            left.pack(side="left", fill="y", padx=(0,10))
            pf = self.labelframe(left_inner, "Part / Spare")
            pf.pack(fill="x")
            self.part_vars = {k: tk.StringVar() for k in ["asset_id","name","number","supplier","qty","min","unit","cost","location","status","notes"]}
            self.part_vars["unit"].set("each"); self.part_vars["status"].set("In Stock")
            r=0
            self.entry_row(pf,r,"Asset ID",self.part_vars["asset_id"],18); r+=1
            self.entry_row(pf,r,"Part Name",self.part_vars["name"],18); r+=1
            self.entry_row(pf,r,"Part Number",self.part_vars["number"],18); r+=1
            self.combo_row(pf,r,"Supplier",self.part_vars["supplier"],all_suppliers(conn),18); r+=1
            self.entry_row(pf,r,"Quantity",self.part_vars["qty"],18); r+=1
            self.entry_row(pf,r,"Minimum",self.part_vars["min"],18); r+=1
            self.entry_row(pf,r,"Unit",self.part_vars["unit"],18); r+=1
            self.entry_row(pf,r,"Cost Each",self.part_vars["cost"],18); r+=1
            self.combo_row(pf,r,"Location",self.part_vars["location"],LOCATION_PRESETS,18); r+=1
            self.combo_row(pf,r,"Status",self.part_vars["status"],PART_STATUSES,18); r+=1
            self.entry_row(pf,r,"Notes",self.part_vars["notes"],18); r+=1
            ttk.Button(pf,text="Add Part",command=self.gui_add_part).grid(row=r,column=0,columnspan=2,sticky="ew",pady=3); r+=1
            ttk.Button(pf,text="Use Selected Part",command=self.gui_use_selected_part).grid(row=r,column=0,columnspan=2,sticky="ew",pady=3); r+=1
            ttk.Button(pf,text="Refresh",command=self.refresh_parts_documents).grid(row=r,column=0,columnspan=2,sticky="ew",pady=3)
            df = self.labelframe(left, "Document Link")
            df.pack(fill="x", pady=(10,0))
            self.doc_vars = {k: tk.StringVar() for k in ["asset_id","type","title","path","expiry","notes"]}
            self.doc_vars["type"].set("Manual")
            r=0
            self.entry_row(df,r,"Asset ID",self.doc_vars["asset_id"],18); r+=1
            self.combo_row(df,r,"Doc Type",self.doc_vars["type"],DOCUMENT_TYPES,18); r+=1
            self.entry_row(df,r,"Title",self.doc_vars["title"],18); r+=1
            self.entry_row(df,r,"Path",self.doc_vars["path"],18); r+=1
            self.entry_row(df,r,"Expiry",self.doc_vars["expiry"],18); r+=1
            self.entry_row(df,r,"Notes",self.doc_vars["notes"],18); r+=1
            ttk.Button(df,text="Browse",command=self.gui_browse_doc).grid(row=r,column=0,sticky="ew",pady=3)
            ttk.Button(df,text="Add Document",command=self.gui_add_document).grid(row=r,column=1,sticky="ew",pady=3)
            right=tk.Frame(outer,bg=THEME["bg"])
            right.pack(side="left",fill="both",expand=True)
            trees=tk.Frame(right,bg=THEME["bg"])
            trees.pack(fill="both",expand=True)
            self.parts_tree=self.tree(trees,["id","asset","part","number","qty","min","unit","status","location","low"],height=10)
            self.parts_tree.pack(fill="both",expand=True,pady=(0,6))
            self.docs_tree=self.tree(trees,["id","asset","type","title","path_exists","expiry","days"],height=8)
            self.docs_tree.pack(fill="both",expand=True,pady=6)
            self.warranty_center_tree=self.tree(trees,["id","name","type","warranty","days","state","docs","claims"],height=8)
            self.warranty_center_tree.pack(fill="both",expand=True,pady=(6,0))
            self.parts_tree.bind("<<TreeviewSelect>>", self.on_part_selected)
            self.docs_tree.bind("<<TreeviewSelect>>", self.on_doc_selected)

        def refresh_parts_documents(self):
            parts=list_parts(conn)
            self.set_tree(self.parts_tree,[{"id":p["id"],"asset":p.get("asset_name") or "","part":p.get("part_name"),"number":p.get("part_number"),"qty":p.get("quantity"),"min":p.get("minimum_quantity"),"unit":p.get("unit"),"status":p.get("status"),"location":p.get("location"),"low":"yes" if p.get("low_stock") else ""} for p in parts],["id","asset","part","number","qty","min","unit","status","location","low"])
            docs=list_documents(conn)
            self.set_tree(self.docs_tree,[{"id":d["id"],"asset":d.get("asset_name") or "","type":d.get("doc_type"),"title":d.get("title"),"path_exists":"yes" if d.get("path_exists") else "no","expiry":d.get("expiry_date"),"days":d.get("days_until_expiry")} for d in docs],["id","asset","type","title","path_exists","expiry","days"])
            wc=warranty_center(conn,90)["items"]
            self.set_tree(self.warranty_center_tree,[{"id":w["id"],"name":w["name"],"type":w["asset_type"],"warranty":w.get("warranty_expiry"),"days":w.get("days_until_warranty_expiry"),"state":w.get("warranty_state"),"docs":w.get("warranty_documents"),"claims":w.get("open_claims")} for w in wc],["id","name","type","warranty","days","state","docs","claims"])

        def gui_add_part(self):
            try:
                ns=argparse.Namespace(asset_id=int(self.part_vars["asset_id"].get()) if self.part_vars["asset_id"].get().strip() else None, name=self.part_vars["name"].get().strip(), part_number=self.part_vars["number"].get(), supplier=self.part_vars["supplier"].get(), quantity=float(self.part_vars["qty"].get() or 0), minimum_quantity=float(self.part_vars["min"].get() or 0), unit=self.part_vars["unit"].get(), cost_each=float(self.part_vars["cost"].get() or 0), location=self.part_vars["location"].get(), status=self.part_vars["status"].get(), notes=self.part_vars["notes"].get())
                if not ns.name: raise ValueError("Part name is required.")
                pid=add_part(conn,ns); conn.commit(); self.status.set(f"Added part ID {pid}."); self.refresh_all()
            except Exception as e: messagebox.showerror(APP_NAME,str(e))

        def selected_part_id(self):
            sel=self.parts_tree.selection()
            if not sel: raise ValueError("Select a part first.")
            return int(self.parts_tree.item(sel[0],"values")[0])

        def gui_use_selected_part(self):
            try:
                info=use_part(conn,self.selected_part_id(),1); conn.commit(); self.status.set(info["message"]); self.refresh_all()
            except Exception as e: messagebox.showerror(APP_NAME,str(e))

        def gui_browse_doc(self):
            p=filedialog.askopenfilename(title="Select maintenance document")
            if p: self.doc_vars["path"].set(p)

        def gui_add_document(self):
            try:
                ns=argparse.Namespace(asset_id=int(self.doc_vars["asset_id"].get()) if self.doc_vars["asset_id"].get().strip() else None, doc_type=self.doc_vars["type"].get(), title=self.doc_vars["title"].get().strip(), path=self.doc_vars["path"].get().strip(), expiry_date=self.doc_vars["expiry"].get(), notes=self.doc_vars["notes"].get())
                if not ns.title or not ns.path: raise ValueError("Document title and path are required.")
                did=add_document(conn,ns); conn.commit(); self.status.set(f"Added document ID {did}."); self.refresh_all()
            except Exception as e: messagebox.showerror(APP_NAME,str(e))

        def on_part_selected(self, event=None):
            sel=self.parts_tree.selection()
            if sel:
                vals=self.parts_tree.item(sel[0],"values")
                self.part_vars["asset_id"].set("")
                self.part_vars["name"].set(vals[2] if len(vals)>2 else "")
                self.part_vars["number"].set(vals[3] if len(vals)>3 else "")

        def on_doc_selected(self, event=None):
            sel=self.docs_tree.selection()
            if sel:
                vals=self.docs_tree.item(sel[0],"values")
                self.doc_vars["type"].set(vals[2] if len(vals)>2 else "Other")
                self.doc_vars["title"].set(vals[3] if len(vals)>3 else "")

        def make_assets(self):
            self.assets_tab = f = self.frame("Assets")
            wrap = tk.Frame(f, bg=THEME["bg"])
            wrap.pack(fill="both", expand=True, padx=10, pady=10)

            left, left_inner = self.scrollable_panel(wrap, width=340)
            left.pack(side="left", fill="y", padx=(0,10))
            form = self.labelframe(left_inner, "Asset Details")
            form.pack(fill="x")
            self.asset_vars = {k: tk.StringVar() for k in ["id", "name", "type", "category", "make", "model", "serial", "location", "purchase", "warranty", "service", "manual", "status", "notes"]}
            self.asset_vars["type"].set("Other")
            self.asset_vars["category"].set("Other")
            self.asset_vars["status"].set("Active")
            self.update_asset_id_preview(force=True)
            r=0
            self.readonly_entry_row(form,r,"Asset ID",self.asset_vars["id"]); r+=1
            self.entry_row(form,r,"Name",self.asset_vars["name"]); r+=1
            self.combo_row(form,r,"Type",self.asset_vars["type"],ASSET_TYPES); r+=1
            self.combo_row(form,r,"Category",self.asset_vars["category"],ASSET_CATEGORIES); r+=1
            self.entry_row(form,r,"Make",self.asset_vars["make"]); r+=1
            self.entry_row(form,r,"Model",self.asset_vars["model"]); r+=1
            self.entry_row(form,r,"Serial",self.asset_vars["serial"]); r+=1
            self.combo_row(form,r,"Location",self.asset_vars["location"],LOCATION_PRESETS); r+=1
            self.entry_row(form,r,"Purchase Date",self.asset_vars["purchase"]); r+=1
            self.entry_row(form,r,"Warranty Expiry",self.asset_vars["warranty"]); r+=1
            self.entry_row(form,r,"Next Service",self.asset_vars["service"]); r+=1
            self.entry_row(form,r,"Manual/Doc Path",self.asset_vars["manual"]); r+=1
            self.combo_row(form,r,"Status",self.asset_vars["status"],ASSET_STATUSES); r+=1
            self.entry_row(form,r,"Notes",self.asset_vars["notes"]); r+=1
            ttk.Button(form, text="Add Asset", command=self.gui_add_asset).grid(row=r, column=0, columnspan=2, sticky="ew", pady=3); r+=1
            ttk.Button(form, text="Mark Needs Service", command=lambda:self.gui_status("Needs Service")).grid(row=r, column=0, columnspan=2, sticky="ew", pady=3); r+=1
            ttk.Button(form, text="Quick Service Selected", command=self.quick_service_selected).grid(row=r, column=0, columnspan=2, sticky="ew", pady=3); r+=1
            ttk.Button(form, text="Quick Reminder Selected", command=self.quick_reminder_selected).grid(row=r, column=0, columnspan=2, sticky="ew", pady=3); r+=1
            ttk.Button(form, text="Archive Selected", command=self.gui_archive_asset).grid(row=r, column=0, columnspan=2, sticky="ew", pady=3); r+=1
            ttk.Button(form, text="Clear Form", command=self.clear_asset_form).grid(row=r, column=0, columnspan=2, sticky="ew", pady=3)

            detail = self.labelframe(left_inner, "Selected Asset Detail")
            detail.pack(fill="both", expand=True, pady=(10,0))
            self.asset_detail_text = tk.Text(detail, bg=THEME["field"], fg=THEME["fg"], height=12, width=36, wrap="word")
            self.asset_detail_text.pack(fill="both", expand=True)
            self.asset_detail_text.insert("end", "Select an asset to view service/warranty status and quick action context.")
            self.asset_detail_text.configure(state="disabled")

            tablebox = tk.Frame(wrap, bg=THEME["bg"])
            tablebox.pack(side="left", fill="both", expand=True)
            top = self.labelframe(tablebox, "Filters", padx=6, pady=6)
            top.pack(fill="x")
            self.asset_search = tk.StringVar()
            self.asset_filter_type = tk.StringVar()
            self.asset_filter_location = tk.StringVar()
            self.asset_filter_status = tk.StringVar()
            self.asset_include_archived = tk.BooleanVar(value=False)
            self.asset_due_only = tk.BooleanVar(value=False)
            self.asset_warranty_only = tk.BooleanVar(value=False)
            tk.Label(top, text="Search", bg=THEME["bg"], fg=THEME["fg"]).grid(row=0,column=0,sticky="w",padx=3,pady=3)
            tk.Entry(top, textvariable=self.asset_search, bg=THEME["field"], fg=THEME["fg"]).grid(row=0,column=1,sticky="ew",padx=3,pady=3)
            tk.Label(top, text="Type", bg=THEME["bg"], fg=THEME["fg"]).grid(row=0,column=2,sticky="w",padx=3,pady=3)
            ttk.Combobox(top, textvariable=self.asset_filter_type, values=[""]+ASSET_TYPES, width=18).grid(row=0,column=3,sticky="ew",padx=3,pady=3)
            tk.Label(top, text="Location", bg=THEME["bg"], fg=THEME["fg"]).grid(row=1,column=0,sticky="w",padx=3,pady=3)
            self.location_filter_combo = ttk.Combobox(top, textvariable=self.asset_filter_location, values=[""]+all_locations(conn), width=18)
            self.location_filter_combo.grid(row=1,column=1,sticky="ew",padx=3,pady=3)
            tk.Label(top, text="Status", bg=THEME["bg"], fg=THEME["fg"]).grid(row=1,column=2,sticky="w",padx=3,pady=3)
            ttk.Combobox(top, textvariable=self.asset_filter_status, values=DISPLAY_STATUS_FILTERS, width=18).grid(row=1,column=3,sticky="ew",padx=3,pady=3)
            tk.Checkbutton(top, text="Due only", variable=self.asset_due_only, bg=THEME["bg"], fg=THEME["fg"], selectcolor=THEME["field"], activebackground=THEME["bg"]).grid(row=2,column=0,sticky="w",padx=3,pady=3)
            tk.Checkbutton(top, text="Warranty only", variable=self.asset_warranty_only, bg=THEME["bg"], fg=THEME["fg"], selectcolor=THEME["field"], activebackground=THEME["bg"]).grid(row=2,column=1,sticky="w",padx=3,pady=3)
            tk.Checkbutton(top, text="Show archived", variable=self.asset_include_archived, bg=THEME["bg"], fg=THEME["fg"], selectcolor=THEME["field"], activebackground=THEME["bg"]).grid(row=2,column=2,sticky="w",padx=3,pady=3)
            ttk.Button(top, text="Apply Filters", command=self.refresh_assets).grid(row=2,column=3,sticky="ew",padx=3,pady=3)
            top.grid_columnconfigure(1, weight=1)
            top.grid_columnconfigure(3, weight=1)
            self.assets_tree = self.tree(tablebox, ["id","name","type","location","display_status","next_service","warranty","make","model","serial"], height=22)
            self.assets_tree.pack(fill="both", expand=True, pady=8)
            self.assets_tree.bind("<Double-1>", self.load_asset_selected)
            self.assets_tree.bind("<<TreeviewSelect>>", self.on_asset_selected)

        def make_service(self):
            self.service_tab = f = self.frame("Service Log")
            wrap = tk.Frame(f, bg=THEME["bg"])
            wrap.pack(fill="both", expand=True, padx=10, pady=10)
            form_outer, form = self.scrollable_panel(wrap, width=340)
            form_outer.pack(side="left", fill="y", padx=(0,10))
            form = self.labelframe(form, "Add Service / Repair Entry")
            form.pack(fill="x")
            self.service_vars = {k: tk.StringVar() for k in ["asset_id","date","type","summary","parts","cost","meter","next","provider","receipt","notes"]}
            self.service_vars["date"].set(today_iso()); self.service_vars["type"].set("Maintenance")
            r=0
            self.readonly_entry_row(form,r,"Asset ID",self.service_vars["asset_id"]); r+=1
            self.entry_row(form,r,"Date",self.service_vars["date"]); r+=1
            self.combo_row(form,r,"Type",self.service_vars["type"],SERVICE_TYPES); r+=1
            self.entry_row(form,r,"Summary",self.service_vars["summary"]); r+=1
            self.entry_row(form,r,"Parts Used",self.service_vars["parts"]); r+=1
            self.entry_row(form,r,"Cost",self.service_vars["cost"]); r+=1
            self.entry_row(form,r,"Odometer/Hours",self.service_vars["meter"]); r+=1
            self.entry_row(form,r,"Next Service",self.service_vars["next"]); r+=1
            self.combo_row(form,r,"Provider",self.service_vars["provider"],all_suppliers(conn)); r+=1
            self.entry_row(form,r,"Receipt Path",self.service_vars["receipt"]); r+=1
            self.entry_row(form,r,"Notes",self.service_vars["notes"]); r+=1
            ttk.Button(form, text="Add Log Entry", command=self.gui_add_service).grid(row=r, column=0, columnspan=2, sticky="ew", pady=4)
            box = tk.Frame(wrap, bg=THEME["bg"])
            box.pack(side="left", fill="both", expand=True)
            self.service_tree = self.tree(box, ["id","asset","date","type","summary","parts","cost","next_service"], height=25)
            self.service_tree.pack(fill="both", expand=True)

        def make_reminders(self):
            self.reminders_tab = f = self.frame("Reminders")
            wrap = tk.Frame(f, bg=THEME["bg"])
            wrap.pack(fill="both", expand=True, padx=10, pady=10)
            form_outer, form = self.scrollable_panel(wrap, width=320)
            form_outer.pack(side="left", fill="y", padx=(0,10))
            form = self.labelframe(form, "Add Reminder")
            form.pack(fill="x")
            self.rem_vars = {k: tk.StringVar() for k in ["asset_id","title","due","priority","notes"]}
            self.rem_vars["priority"].set("Normal")
            r=0
            self.readonly_entry_row(form,r,"Asset ID",self.rem_vars["asset_id"]); r+=1
            self.entry_row(form,r,"Title",self.rem_vars["title"]); r+=1
            self.entry_row(form,r,"Due Date",self.rem_vars["due"]); r+=1
            self.combo_row(form,r,"Priority",self.rem_vars["priority"],PRIORITIES); r+=1
            self.entry_row(form,r,"Notes",self.rem_vars["notes"]); r+=1
            ttk.Button(form, text="Add Reminder", command=self.gui_add_reminder).grid(row=r, column=0, columnspan=2, sticky="ew", pady=4); r+=1
            ttk.Button(form, text="Mark Selected Done", command=self.gui_done_reminder).grid(row=r, column=0, columnspan=2, sticky="ew", pady=4)
            box = tk.Frame(wrap, bg=THEME["bg"])
            box.pack(side="left", fill="both", expand=True)
            self.rem_tree = self.tree(box, ["id","asset","title","due","priority","status"], height=25)
            self.rem_tree.pack(fill="both", expand=True)

        def make_cost_bridges(self):
            self.cost_bridge_tab = f = self.frame("Costs & Bridges")
            self.label(f, "Costs & Bridges", 16, True).pack(anchor="w", padx=12, pady=(12, 4))
            self.label(f, "Maintenance spend summaries plus Sentinel Ledger and Sentinel Inventory bridge exports.").pack(anchor="w", padx=12)
            bar = tk.Frame(f, bg=THEME["bg"])
            bar.pack(fill="x", padx=12, pady=8)
            self.cost_days_var = tk.StringVar(value="365")
            tk.Label(bar, text="Report days", bg=THEME["bg"], fg=THEME["fg"]).pack(side="left", padx=(0, 4))
            tk.Entry(bar, textvariable=self.cost_days_var, width=8, bg=THEME["field"], fg=THEME["fg"], insertbackground=THEME["fg"]).pack(side="left", padx=4)
            ttk.Button(bar, text="Refresh Cost Report", command=self.gui_cost_report).pack(side="left", padx=4)
            ttk.Button(bar, text="Export Ledger Bridge", command=self.gui_ledger_bridge).pack(side="left", padx=4)
            ttk.Button(bar, text="Export Inventory Bridge", command=self.gui_inventory_bridge).pack(side="left", padx=4)
            ttk.Button(bar, text="Bridge Summary", command=self.gui_bridge_summary).pack(side="left", padx=4)
            self.cost_text = tk.Text(f, bg=THEME["field"], fg=THEME["fg"], height=26, wrap="word")
            self.cost_text.pack(fill="both", expand=True, padx=12, pady=12)

        def gui_cost_report(self):
            try:
                days = int(self.cost_days_var.get() or 365)
                out = cost_report(conn, days=days)
                self.cost_text.delete("1.0", "end")
                self.cost_text.insert("end", json.dumps(out, indent=2, default=str))
                self.status.set(f"Cost report refreshed for {days} days.")
            except Exception as e: messagebox.showerror(APP_NAME, str(e))

        def gui_ledger_bridge(self):
            try:
                out = export_ledger_bridge(conn); conn.commit()
                self.cost_text.delete("1.0", "end")
                self.cost_text.insert("end", json.dumps(out, indent=2))
                self.status.set(f"Ledger bridge exported: {out.get('path')}")
            except Exception as e: messagebox.showerror(APP_NAME, str(e))

        def gui_inventory_bridge(self):
            try:
                out = export_inventory_bridge(conn, include_archived=True); conn.commit()
                self.cost_text.delete("1.0", "end")
                self.cost_text.insert("end", json.dumps(out, indent=2))
                self.status.set(f"Inventory bridge exported: {out.get('path')}")
            except Exception as e: messagebox.showerror(APP_NAME, str(e))

        def gui_bridge_summary(self):
            try:
                out = bridge_summary(conn)
                self.cost_text.delete("1.0", "end")
                self.cost_text.insert("end", json.dumps(out, indent=2))
                self.status.set("Bridge summary refreshed.")
            except Exception as e: messagebox.showerror(APP_NAME, str(e))

        def make_recovery(self):
            f = self.frame("Recovery & Integrity")
            self.label(f, "Recovery & Integrity", 16, True).pack(anchor="w", padx=12, pady=12)
            bar = tk.Frame(f, bg=THEME["bg"])
            bar.pack(fill="x", padx=12, pady=4)
            ttk.Button(bar, text="Integrity Check", command=self.gui_integrity).pack(side="left", padx=4)
            ttk.Button(bar, text="Create Backup", command=self.gui_backup).pack(side="left", padx=4)
            ttk.Button(bar, text="Checksum Manifest", command=self.gui_checksum_manifest).pack(side="left", padx=4)
            ttk.Button(bar, text="Compact / Repair", command=self.gui_compact_repair).pack(side="left", padx=4)
            ttk.Button(bar, text="Audit Export", command=self.gui_audit_export).pack(side="left", padx=4)
            self.recovery_text = tk.Text(f, bg=THEME["field"], fg=THEME["fg"], height=26, wrap="word")
            self.recovery_text.pack(fill="both", expand=True, padx=12, pady=12)

        def _recovery_show(self, payload):
            self.recovery_text.delete("1.0", "end")
            self.recovery_text.insert("end", json.dumps(payload, indent=2, default=str))

        def gui_integrity(self):
            try:
                out = integrity_report(conn)
                self._recovery_show(out)
                self.status.set(f"Integrity check: {out.get('status')}")
            except Exception as e: messagebox.showerror(APP_NAME, str(e))

        def gui_checksum_manifest(self):
            try:
                out = checksum_manifest(conn); conn.commit()
                self._recovery_show(out)
                self.status.set(f"Checksum manifest exported: {out.get('manifest_path')}")
            except Exception as e: messagebox.showerror(APP_NAME, str(e))

        def gui_compact_repair(self):
            try:
                if not messagebox.askyesno(APP_NAME, "Create a safety backup and compact/repair the database now?"):
                    return
                out = compact_repair(conn); conn.commit()
                self._recovery_show(out)
                self.status.set("Compact/repair completed.")
            except Exception as e: messagebox.showerror(APP_NAME, str(e))

        def gui_audit_export(self):
            try:
                out = audit_log_export(conn); conn.commit()
                self._recovery_show(out)
                self.status.set(f"Audit log exported: {out.get('path')}")
            except Exception as e: messagebox.showerror(APP_NAME, str(e))

        def make_exports(self):
            f = self.frame("Export / Backup")
            self.label(f, "Export, Backup, and AEGIS Handoff", 16, True).pack(anchor="w", padx=12, pady=12)
            panel = tk.Frame(f, bg=THEME["bg"])
            panel.pack(anchor="nw", padx=12, pady=6)
            ttk.Button(panel, text="Export Assets CSV", command=lambda:self.gui_export("assets")).grid(row=0,column=0,sticky="ew",padx=4,pady=4)
            ttk.Button(panel, text="Export Service Logs CSV", command=lambda:self.gui_export("service_logs")).grid(row=0,column=1,sticky="ew",padx=4,pady=4)
            ttk.Button(panel, text="Export Reminders CSV", command=lambda:self.gui_export("reminders")).grid(row=0,column=2,sticky="ew",padx=4,pady=4)
            ttk.Button(panel, text="SQLite Backup", command=self.gui_backup).grid(row=1,column=0,sticky="ew",padx=4,pady=4)
            ttk.Button(panel, text="AEGIS Export", command=self.gui_aegis_export).grid(row=1,column=1,sticky="ew",padx=4,pady=4)
            self.export_text = tk.Text(f, bg=THEME["field"], fg=THEME["fg"], height=20)
            self.export_text.pack(fill="both", expand=True, padx=12, pady=12)

        def make_manual(self):
            f = self.frame("Manual / Status")
            bar = tk.Frame(f, bg=THEME["bg"])
            bar.pack(fill="x", padx=12, pady=(12, 4))
            ttk.Button(bar, text="Refresh Status", command=self.gui_manual_status).pack(side="left", padx=4)
            ttk.Button(bar, text="Self-Test", command=self.gui_manual_self_test).pack(side="left", padx=4)
            ttk.Button(bar, text="Completion Report", command=self.gui_manual_completion_report).pack(side="left", padx=4)
            ttk.Button(bar, text="Stable Lock Report", command=self.gui_manual_stable_lock_report).pack(side="left", padx=4)
            ttk.Button(bar, text="Apply Default Setup", command=self.gui_manual_setup_defaults).pack(side="left", padx=4)
            text = tk.Text(f, bg=THEME["field"], fg=THEME["fg"], wrap="word")
            self.manual_text = text
            text.pack(fill="both", expand=True, padx=12, pady=12)
            text.insert("end", f"{APP_NAME} v{VERSION}\nProgram 114 — Sentinel Desktop Suite\nStable Lock / User-Ready Baseline\n\n")
            text.insert("end", "Purpose:\nTrack household, workshop, vehicle, device, appliance, and off-grid maintenance records.\n\n")
            text.insert("end", "Daily workflow:\n1. Add assets.\n2. Log repairs/services.\n3. Set next service dates and warranty expiry.\n4. Use reminders for jobs due later.\n5. Export/backup regularly.\n\n")
            text.insert("end", "Theme:\nAEGIS Dark / Sentinel Gold suite theme, matching the Sentinel Desktop Suite visual language.\n\n")
            text.insert("end", "Service Queue:\nUse the Service Queue tab to view due/overdue assets, prepare service logs, and mark items Needs Service/In Repair/Active.\n\n")
            text.insert("end", "Parts & Documents:\nUse the Parts & Documents tab to track spare parts, manuals, receipts, warranty papers, diagrams, and warranty claims. Supplier/provider fields use practical dropdown presets but still allow custom entries.\n\n")
            text.insert("end", "Autofill workflow:\nAsset IDs are generated by SQLite and previewed as Auto: next ID. Selecting an asset autofills Service Log, Reminders, Parts, and Documents asset fields so you do not need to type IDs manually.\n\n")
            text.insert("end", "Costs & Bridges:\nUse the Costs & Bridges tab or CLI to summarize service spend and export Ledger/Inventory bridge CSV files. These are local handoff files only; no cloud or network is used.\n\n")
            text.insert("end", "Inspections & Faults:\nUse the Inspections & Faults tab to record condition checks, photo/evidence paths, action-required findings, and active faults. High/Critical faults and failed inspections can mark assets as needing service.\n\n")
            text.insert("end", "Recovery & Integrity:\nUse the Recovery & Integrity tab or CLI to run integrity checks, create verified backups, export checksum manifests, compact/repair the database, and export audit logs.\n\n")
            text.insert("end", "Keyboard:\nCtrl+Q closes the application.\n\n")
            text.insert("end", "Local-only posture: no cloud, no network, no telemetry.\n")
            text.configure(state="disabled")

        def _manual_show(self, payload):
            self.manual_text.configure(state="normal")
            self.manual_text.delete("1.0", "end")
            self.manual_text.insert("end", json.dumps(payload, indent=2, default=str))
            self.manual_text.configure(state="disabled")

        def gui_manual_status(self):
            try:
                self._manual_show(app_status(conn))
                self.status.set("Status refreshed.")
            except Exception as e: messagebox.showerror(APP_NAME, str(e))

        def gui_manual_self_test(self):
            try:
                out = self_test(conn)
                self._manual_show(out)
                self.status.set(f"Self-test: {out.get('status')}")
            except Exception as e: messagebox.showerror(APP_NAME, str(e))

        def gui_manual_completion_report(self):
            try:
                out = completion_report(conn)
                self._manual_show(out)
                self.status.set(f"Completion report: {out.get('status')}")
            except Exception as e: messagebox.showerror(APP_NAME, str(e))

        def gui_manual_stable_lock_report(self):
            try:
                out = stable_lock_report(conn)
                self._manual_show(out)
                self.status.set(f"Stable lock report: {out.get('status')}")
            except Exception as e: messagebox.showerror(APP_NAME, str(e))

        def gui_manual_setup_defaults(self):
            try:
                out = set_settings(conn, {"default_location": "Workshop", "currency": "AUD"})
                conn.commit()
                self._manual_show({"settings": out})
                self.status.set("Default setup saved.")
            except Exception as e: messagebox.showerror(APP_NAME, str(e))

        def tree(self, parent, cols, height=10):
            tr = ttk.Treeview(parent, columns=cols, show="headings", height=height)
            for c in cols:
                tr.heading(c, text=c.replace("_", " ").title())
                tr.column(c, width=110, anchor="w")
            return tr

        def set_tree(self, tree, rows, cols):
            for i in tree.get_children(): tree.delete(i)
            for r in rows:
                tree.insert("", "end", values=[r.get(c, "") for c in cols])

        def refresh_all(self):
            s = summary(conn)
            self.card_vars["assets"].set(str(s["active_assets"]))
            self.card_vars["due"].set(str(s["service_due_30_days"]))
            self.card_vars["overdue"].set(str(s["service_overdue"]))
            self.card_vars["warranty"].set(str(s["warranties_expiring_60_days"]))
            self.card_vars["reminders"].set(str(s["open_reminders"]))
            self.card_vars["cost"].set(f"${s['total_service_cost']:.2f}")
            self.set_tree(self.due_tree, [{"id":a["id"],"name":a["name"],"type":a["asset_type"],"next_service":a["next_service_date"],"days":a.get("days_until_service")} for a in due_assets(conn,30)], ["id","name","type","next_service","days"])
            self.set_tree(self.warranty_tree, [{"id":a["id"],"name":a["name"],"type":a["asset_type"],"warranty":a["warranty_expiry"],"days":a.get("days_until_warranty_expiry")} for a in warranty_expiring(conn,60)], ["id","name","type","warranty","days"])
            self.refresh_inspections_faults(); self.refresh_parts_documents(); self.refresh_assets(); self.refresh_service(); self.refresh_reminders(); self.refresh_service_queue(); self.update_asset_id_preview()
            self.status.set(f"Ready. AEGIS Dark theme active | DB: {DB_PATH} | Ctrl+Q closes.")

        def refresh_assets(self):
            if hasattr(self, "location_filter_combo"):
                self.location_filter_combo.configure(values=[""] + all_locations(conn))
            rows = list_assets(
                conn,
                include_archived=getattr(self, "asset_include_archived", tk.BooleanVar(value=False)).get(),
                asset_type=getattr(self, "asset_filter_type", tk.StringVar()).get(),
                status=(getattr(self, "asset_filter_status", tk.StringVar()).get() if getattr(self, "asset_filter_status", tk.StringVar()).get() in ASSET_STATUSES else ""),
                search=getattr(self, 'asset_search', tk.StringVar()).get() if hasattr(self, 'asset_search') else "",
                location=getattr(self, "asset_filter_location", tk.StringVar()).get(),
                due_only=getattr(self, "asset_due_only", tk.BooleanVar(value=False)).get(),
                warranty_only=getattr(self, "asset_warranty_only", tk.BooleanVar(value=False)).get(),
                days=30,
            )
            chosen_status = getattr(self, "asset_filter_status", tk.StringVar()).get()
            if chosen_status and chosen_status not in ASSET_STATUSES:
                rows = [r for r in rows if r.get("display_status") == chosen_status]
            out = [{"id":r["id"],"name":r["name"],"type":r["asset_type"],"location":r["location"],"display_status":r.get("display_status", r.get("status")),"next_service":r["next_service_date"],"warranty":r["warranty_expiry"],"make":r["make"],"model":r["model"],"serial":r["serial_number"]} for r in rows]
            self.set_tree(self.assets_tree, out, ["id","name","type","location","display_status","next_service","warranty","make","model","serial"])
            if hasattr(self, "asset_detail_text"):
                self.update_asset_detail()

        def refresh_service(self):
            rows = list_service(conn, limit=250)
            out = [{"id":r["id"],"asset":r.get("asset_name"),"date":r["service_date"],"type":r["service_type"],"summary":r["summary"],"parts":r["parts_used"],"cost":r["cost"],"next_service":r["next_service_date"]} for r in rows]
            self.set_tree(self.service_tree, out, ["id","asset","date","type","summary","parts","cost","next_service"])

        def refresh_reminders(self):
            rows = list_reminders(conn, include_done=True, days=3650)
            out = [{"id":r["id"],"asset":r.get("asset_name") or "", "title":r["title"],"due":r["due_date"],"priority":r["priority"],"status":r["status"]} for r in rows]
            self.set_tree(self.rem_tree, out, ["id","asset","title","due","priority","status"])

        def clear_asset_form(self):
            for v in self.asset_vars.values(): v.set("")
            self.asset_vars["type"].set("Other"); self.asset_vars["category"].set("Other"); self.asset_vars["status"].set("Active")
            self.update_asset_id_preview(force=True)

        def gui_add_asset(self):
            try:
                ns = argparse.Namespace(name=self.asset_vars["name"].get(), asset_type=self.asset_vars["type"].get(), category=self.asset_vars["category"].get(), make=self.asset_vars["make"].get(), model=self.asset_vars["model"].get(), serial=self.asset_vars["serial"].get(), location=self.asset_vars["location"].get(), purchase_date=self.asset_vars["purchase"].get(), warranty_expiry=self.asset_vars["warranty"].get(), next_service=self.asset_vars["service"].get(), manual=self.asset_vars["manual"].get(), status=self.asset_vars["status"].get(), notes=self.asset_vars["notes"].get())
                if not ns.name.strip(): raise ValueError("Asset name is required.")
                aid = add_asset(conn, ns); conn.commit(); self.asset_vars["id"].set(str(aid)); self.autofill_selected_asset_context(aid); self.refresh_all(); self.status.set(f"Added asset ID {aid}. Related forms autofilled.")
            except Exception as e:
                messagebox.showerror(APP_NAME, str(e))

        def selected_asset_id(self):
            sel = self.assets_tree.selection()
            if not sel: raise ValueError("Select an asset first.")
            return int(self.assets_tree.item(sel[0], "values")[0])

        def load_asset_selected(self, event=None):
            try:
                a = get_asset(conn, self.selected_asset_id())
                mapping = {"id":"id","name":"name","type":"asset_type","category":"category","make":"make","model":"model","serial":"serial_number","location":"location","purchase":"purchase_date","warranty":"warranty_expiry","service":"next_service_date","manual":"manual_path","status":"status","notes":"notes"}
                for k,col in mapping.items(): self.asset_vars[k].set(str(a.get(col) or ""))
                self.autofill_selected_asset_context(int(a.get("id")))
                self.update_asset_detail()
            except Exception as e: messagebox.showerror(APP_NAME, str(e))

        def on_asset_selected(self, event=None):
            try:
                aid = self.selected_asset_id()
                self.autofill_selected_asset_context(aid)
                self.status.set(f"Selected asset ID {aid}. Service, reminder, part, and document forms autofilled.")
            except Exception:
                pass
            self.update_asset_detail(event)

        def update_asset_detail(self, event=None):
            if not hasattr(self, "asset_detail_text"):
                return
            self.asset_detail_text.configure(state="normal")
            self.asset_detail_text.delete("1.0", "end")
            try:
                asset_id = self.selected_asset_id()
                a = enrich_asset(get_asset(conn, asset_id))
                logs = list_service(conn, asset_id=asset_id, limit=3)
                plans = list_service_plans(conn, asset_id=asset_id, days=3650, include_archived=False)
                lines = [
                    f"ID: {a.get('id')}",
                    f"Name: {a.get('name')}",
                    f"Type: {a.get('asset_type')}",
                    f"Location: {a.get('location') or 'Unassigned'}",
                    f"Status: {a.get('display_status')}",
                    f"Next service: {a.get('next_service_date') or 'Not set'} ({a.get('days_until_service')} days)",
                    f"Warranty: {a.get('warranty_expiry') or 'Not set'} ({a.get('days_until_warranty_expiry')} days)",
                    f"Manual/doc: {a.get('manual_path') or 'Not linked'}",
                    "",
                    "Recent service:",
                ]
                if plans:
                    lines.append("")
                    lines.append("Service plans:")
                    for plan in plans[:3]:
                        lines.append(f"- {plan.get('plan_name')}: next {plan.get('next_service_date') or 'not set'} ({plan.get('plan_state')})")
                if logs:
                    for log in logs:
                        lines.append(f"- {log.get('service_date')}: {log.get('summary')} (${float(log.get('cost') or 0):.2f})")
                else:
                    lines.append("- No service records yet.")
                self.asset_detail_text.insert("end", "\n".join(lines))
            except Exception:
                self.asset_detail_text.insert("end", "Select an asset to view service/warranty status and quick action context.")
            self.asset_detail_text.configure(state="disabled")

        def quick_service_selected(self):
            try:
                aid = self.selected_asset_id()
                self.service_vars["asset_id"].set(str(aid))
                self.service_vars["date"].set(today_iso())
                self.service_vars["type"].set("Maintenance")
                self.service_vars["summary"].set("Routine service")
                self.nb.select(self.service_tab)
                self.status.set(f"Service form prepared for asset ID {aid}.")
            except Exception as e: messagebox.showerror(APP_NAME, str(e))

        def quick_reminder_selected(self):
            try:
                aid = self.selected_asset_id()
                a = get_asset(conn, aid)
                self.rem_vars["asset_id"].set(str(aid))
                self.rem_vars["title"].set(f"Service {a.get('name')}")
                self.rem_vars["due"].set(a.get("next_service_date") or today_iso())
                self.rem_vars["priority"].set("Normal")
                self.nb.select(self.reminders_tab)
                self.status.set(f"Reminder form prepared for asset ID {aid}.")
            except Exception as e: messagebox.showerror(APP_NAME, str(e))

        def gui_status(self, status):
            try:
                set_asset_status(conn, self.selected_asset_id(), status); conn.commit(); self.refresh_all()
            except Exception as e: messagebox.showerror(APP_NAME, str(e))

        def gui_archive_asset(self):
            try:
                archive_asset(conn, self.selected_asset_id()); conn.commit(); self.refresh_all()
            except Exception as e: messagebox.showerror(APP_NAME, str(e))

        def gui_add_service(self):
            try:
                ns = argparse.Namespace(asset_id=int(self.service_vars["asset_id"].get()), date=self.service_vars["date"].get(), service_type=self.service_vars["type"].get(), summary=self.service_vars["summary"].get(), parts=self.service_vars["parts"].get(), cost=self.service_vars["cost"].get() or 0, meter=self.service_vars["meter"].get(), next_service=self.service_vars["next"].get(), provider=self.service_vars["provider"].get(), receipt=self.service_vars["receipt"].get(), notes=self.service_vars["notes"].get(), mark_active=True)
                if not ns.summary.strip(): raise ValueError("Summary is required.")
                sid = add_service(conn, ns); conn.commit(); self.refresh_all(); self.status.set(f"Added service entry ID {sid}.")
            except Exception as e: messagebox.showerror(APP_NAME, str(e))

        def gui_add_reminder(self):
            try:
                aid = self.rem_vars["asset_id"].get().strip()
                ns = argparse.Namespace(asset_id=int(aid) if aid else None, title=self.rem_vars["title"].get(), due_date=self.rem_vars["due"].get(), priority=self.rem_vars["priority"].get(), notes=self.rem_vars["notes"].get())
                rid = add_reminder(conn, ns); conn.commit(); self.refresh_all(); self.status.set(f"Added reminder ID {rid}.")
            except Exception as e: messagebox.showerror(APP_NAME, str(e))

        def gui_done_reminder(self):
            try:
                sel = self.rem_tree.selection()
                if not sel: raise ValueError("Select a reminder first.")
                rid = int(self.rem_tree.item(sel[0], "values")[0]); complete_reminder(conn, rid); conn.commit(); self.refresh_all()
            except Exception as e: messagebox.showerror(APP_NAME, str(e))

        def gui_export(self, table):
            p = filedialog.asksaveasfilename(defaultextension=".csv", initialfile=f"sentinel-maintenance-{table}.csv")
            if p:
                out = export_csv(conn, table, Path(p)); conn.commit(); self.export_text.insert("end", f"Exported {table}: {out}\n")

        def gui_backup(self):
            info = backup_db(conn); self.export_text.insert("end", json.dumps(info, indent=2)+"\n") if hasattr(self, 'export_text') else None; self.status.set(f"Backup created: {info['backup_path']}")

        def gui_aegis_export(self):
            info = aegis_export(conn); self.export_text.insert("end", json.dumps(info, indent=2)+"\n")

        def close(self):
            try: conn.close()
            finally: self.root.destroy()

    root = tk.Tk()
    try:
        App(root)
    except Exception:
        # Fail cleanly if a startup regression occurs before mainloop.
        try:
            root.destroy()
        except Exception:
            pass
        raise
    root.mainloop()


# ----------------------------- CLI ---------------------------------------

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="sentinel-maintenance", description="Sentinel Maintenance Program 114")
    p.add_argument("--version", action="store_true", help="Print version")
    p.add_argument("--health-check", action="store_true", help="Print health JSON")
    p.add_argument("--summary", dest="show_summary", action="store_true", help="Print summary JSON")
    p.add_argument("--dashboard", action="store_true", help="Print dashboard JSON")
    p.add_argument("--status", dest="show_status", action="store_true", help="Print application status JSON")
    p.add_argument("--self-test", action="store_true", help="Run package/application self-test JSON")
    p.add_argument("--stable-lock-report", action="store_true", help="Print v1 stable-lock report JSON")
    p.add_argument("--manifest", action="store_true", help="Print AEGIS manifest JSON")
    p.add_argument("--gui", action="store_true", help="Launch GUI")
    sub = p.add_subparsers(dest="command")

    a = sub.add_parser("add-asset", help="Add an asset")
    a.add_argument("name")
    a.add_argument("--asset-type", default="Other", choices=ASSET_TYPES)
    a.add_argument("--category", default="")
    a.add_argument("--make", default="")
    a.add_argument("--model", default="")
    a.add_argument("--serial", default="")
    a.add_argument("--location", default="")
    a.add_argument("--purchase-date", default="")
    a.add_argument("--warranty-expiry", default="")
    a.add_argument("--next-service", default="")
    a.add_argument("--manual", default="")
    a.add_argument("--status", default="Active", choices=ASSET_STATUSES)
    a.add_argument("--notes", default="")
    a.add_argument("--json", action="store_true")

    la = sub.add_parser("list-assets", help="List assets")
    la.add_argument("--include-archived", action="store_true")
    la.add_argument("--asset-type", default="")
    la.add_argument("--status", default="")
    la.add_argument("--location", default="")
    la.add_argument("--search", default="")
    la.add_argument("--due-only", action="store_true")
    la.add_argument("--warranty-only", action="store_true")
    la.add_argument("--days", type=int, default=30)
    la.add_argument("--json", action="store_true")

    det = sub.add_parser("asset", help="Asset detail/status/archive")
    det.add_argument("id", type=int)
    det.add_argument("--status", choices=ASSET_STATUSES)
    det.add_argument("--archive", action="store_true")
    det.add_argument("--json", action="store_true")

    s = sub.add_parser("add-service", help="Add service or repair log")
    s.add_argument("asset_id", type=int)
    s.add_argument("--date", default=today_iso())
    s.add_argument("--service-type", default="Maintenance", choices=SERVICE_TYPES)
    s.add_argument("--summary", required=True)
    s.add_argument("--parts", default="")
    s.add_argument("--cost", default=0, type=float)
    s.add_argument("--meter", default="")
    s.add_argument("--next-service", default="")
    s.add_argument("--provider", default="")
    s.add_argument("--receipt", default="")
    s.add_argument("--notes", default="")
    s.add_argument("--mark-active", action="store_true")
    s.add_argument("--json", action="store_true")

    ls = sub.add_parser("list-service", help="List service logs")
    ls.add_argument("--asset-id", type=int)
    ls.add_argument("--limit", type=int, default=100)
    ls.add_argument("--json", action="store_true")

    r = sub.add_parser("reminders", help="Reminder workflow")
    r.add_argument("--add", action="store_true")
    r.add_argument("--asset-id", type=int)
    r.add_argument("--title", default="")
    r.add_argument("--due-date", default="")
    r.add_argument("--priority", default="Normal", choices=PRIORITIES)
    r.add_argument("--notes", default="")
    r.add_argument("--done", type=int)
    r.add_argument("--include-done", action="store_true")
    r.add_argument("--days", type=int, default=365)
    r.add_argument("--json", action="store_true")

    sq = sub.add_parser("service-queue", help="List AEGIS-readable service queue")
    sq.add_argument("--days", type=int, default=60)
    sq.add_argument("--json", action="store_true")

    due = sub.add_parser("due", help="List service due soon")
    due.add_argument("--days", type=int, default=30)
    due.add_argument("--json", action="store_true")

    w = sub.add_parser("warranty", help="List warranties expiring soon")
    w.add_argument("--days", type=int, default=60)
    w.add_argument("--json", action="store_true")


    parts = sub.add_parser("parts", help="Parts/spares catalog workflow")
    parts.add_argument("--add", action="store_true")
    parts.add_argument("--asset-id", type=int)
    parts.add_argument("--name", default="")
    parts.add_argument("--part-number", default="")
    parts.add_argument("--supplier", default="")
    parts.add_argument("--quantity", type=float, default=0)
    parts.add_argument("--minimum-quantity", type=float, default=0)
    parts.add_argument("--unit", default="each")
    parts.add_argument("--cost-each", type=float, default=0)
    parts.add_argument("--location", default="")
    parts.add_argument("--status", default="In Stock", choices=PART_STATUSES)
    parts.add_argument("--notes", default="")
    parts.add_argument("--use", type=int, metavar="PART_ID")
    parts.add_argument("--use-qty", type=float, default=1)
    parts.add_argument("--low-only", action="store_true")
    parts.add_argument("--include-archived", action="store_true")
    parts.add_argument("--search", default="")
    parts.add_argument("--json", action="store_true")

    docs = sub.add_parser("documents", help="Asset documents/manuals/warranty links")
    docs.add_argument("--add", action="store_true")
    docs.add_argument("--asset-id", type=int)
    docs.add_argument("--doc-type", default="Other", choices=DOCUMENT_TYPES)
    docs.add_argument("--title", default="")
    docs.add_argument("--path", default="")
    docs.add_argument("--expiry-date", default="")
    docs.add_argument("--notes", default="")
    docs.add_argument("--search", default="")
    docs.add_argument("--json", action="store_true")

    wc = sub.add_parser("warranty-center", help="Warranty center with states, documents, and claims")
    wc.add_argument("--days", type=int, default=90)
    wc.add_argument("--json", action="store_true")

    claims = sub.add_parser("warranty-claims", help="Warranty claim workflow")
    claims.add_argument("--add", action="store_true")
    claims.add_argument("--asset-id", type=int)
    claims.add_argument("--date", default=today_iso())
    claims.add_argument("--status", default="Open")
    claims.add_argument("--provider", default="")
    claims.add_argument("--reference", default="")
    claims.add_argument("--issue", default="")
    claims.add_argument("--resolution", default="")
    claims.add_argument("--cost", type=float, default=0)
    claims.add_argument("--document", default="")
    claims.add_argument("--notes", default="")
    claims.add_argument("--include-closed", action="store_true")
    claims.add_argument("--limit", type=int, default=100)
    claims.add_argument("--json", action="store_true")

    tmpl = sub.add_parser("service-templates", help="Reusable service checklist/template workflow")
    tmpl.add_argument("--add", action="store_true")
    tmpl.add_argument("--name", default="")
    tmpl.add_argument("--asset-type", default="Other", choices=ASSET_TYPES)
    tmpl.add_argument("--category", default="")
    tmpl.add_argument("--service-type", default="Maintenance", choices=SERVICE_TYPES)
    tmpl.add_argument("--interval-days", type=int, default=90)
    tmpl.add_argument("--checklist", default="")
    tmpl.add_argument("--parts", default="")
    tmpl.add_argument("--estimated-cost", type=float, default=0)
    tmpl.add_argument("--provider", default="")
    tmpl.add_argument("--notes", default="")
    tmpl.add_argument("--inactive", action="store_true")
    tmpl.add_argument("--include-inactive", action="store_true")
    tmpl.add_argument("--search", default="")
    tmpl.add_argument("--json", action="store_true")

    plans = sub.add_parser("service-plans", help="Recurring service plan workflow")
    plans.add_argument("--add", action="store_true")
    plans.add_argument("--asset-id", type=int)
    plans.add_argument("--template-id", type=int)
    plans.add_argument("--name", default="")
    plans.add_argument("--service-type", default="Maintenance", choices=SERVICE_TYPES)
    plans.add_argument("--interval-days", type=int)
    plans.add_argument("--last-service", default="")
    plans.add_argument("--next-service", default="")
    plans.add_argument("--checklist", default="")
    plans.add_argument("--parts", default="")
    plans.add_argument("--estimated-cost", type=float)
    plans.add_argument("--provider", default="")
    plans.add_argument("--status", default="Active", choices=SERVICE_PLAN_STATUSES)
    plans.add_argument("--notes", default="")
    plans.add_argument("--complete", type=int, metavar="PLAN_ID")
    plans.add_argument("--service-date", default="")
    plans.add_argument("--cost", type=float)
    plans.add_argument("--days", type=int, default=365)
    plans.add_argument("--include-archived", action="store_true")
    plans.add_argument("--search", default="")
    plans.add_argument("--json", action="store_true")

    ps = sub.add_parser("service-plan-summary", help="Summarize recurring service plan state")
    ps.add_argument("--days", type=int, default=90)
    ps.add_argument("--json", action="store_true")

    cr = sub.add_parser("cost-report", help="Summarize maintenance costs and parts value")
    cr.add_argument("--start", default="")
    cr.add_argument("--end", default="")
    cr.add_argument("--asset-id", type=int)
    cr.add_argument("--days", type=int)
    cr.add_argument("--json", action="store_true")

    lb = sub.add_parser("ledger-bridge", help="Export maintenance costs for Sentinel Ledger handoff")
    lb.add_argument("--path", default="")
    lb.add_argument("--start", default="")
    lb.add_argument("--end", default="")
    lb.add_argument("--asset-id", type=int)
    lb.add_argument("--json", action="store_true")

    ib = sub.add_parser("inventory-bridge", help="Export maintenance parts/spares for Sentinel Inventory handoff")
    ib.add_argument("--path", default="")
    ib.add_argument("--low-only", action="store_true")
    ib.add_argument("--include-archived", action="store_true")
    ib.add_argument("--json", action="store_true")

    bs = sub.add_parser("bridge-summary", help="Summarize Ledger/Inventory bridge readiness")
    bs.add_argument("--json", action="store_true")


    ins = sub.add_parser("inspections", help="Inspection and condition report workflow")
    ins.add_argument("--add", action="store_true")
    ins.add_argument("--asset-id", type=int)
    ins.add_argument("--date", default=today_iso())
    ins.add_argument("--condition", default="Unknown", choices=INSPECTION_CONDITIONS)
    ins.add_argument("--checklist", default="")
    ins.add_argument("--findings", default="")
    ins.add_argument("--actions", default="")
    ins.add_argument("--priority", default="Normal", choices=PRIORITIES)
    ins.add_argument("--next-inspection", default="")
    ins.add_argument("--photo", default="")
    ins.add_argument("--status", default="Open", choices=INSPECTION_STATUSES)
    ins.add_argument("--notes", default="")
    ins.add_argument("--include-closed", action="store_true")
    ins.add_argument("--limit", type=int, default=100)
    ins.add_argument("--summary", action="store_true")
    ins.add_argument("--days", type=int, default=60)
    ins.add_argument("--json", action="store_true")

    faults = sub.add_parser("faults", help="Fault register workflow")
    faults.add_argument("--add", action="store_true")
    faults.add_argument("--asset-id", type=int)
    faults.add_argument("--date", default=today_iso())
    faults.add_argument("--severity", default="Medium", choices=FAULT_SEVERITIES)
    faults.add_argument("--issue", default="")
    faults.add_argument("--symptom", default="")
    faults.add_argument("--cause", default="")
    faults.add_argument("--action", default="")
    faults.add_argument("--status", default="Open", choices=FAULT_STATUSES)
    faults.add_argument("--close", type=int, metavar="FAULT_ID")
    faults.add_argument("--resolved-date", default="")
    faults.add_argument("--service-log-id", type=int)
    faults.add_argument("--notes", default="")
    faults.add_argument("--include-closed", action="store_true")
    faults.add_argument("--limit", type=int, default=100)
    faults.add_argument("--summary", action="store_true")
    faults.add_argument("--json", action="store_true")

    setup = sub.add_parser("setup", help="First-run/default settings helper")
    setup.add_argument("--household-name", default="")
    setup.add_argument("--default-location", default="")
    setup.add_argument("--preferred-provider", default="")
    setup.add_argument("--currency", default="")
    setup.add_argument("--show", action="store_true")
    setup.add_argument("--json", action="store_true")

    comp = sub.add_parser("completion-report", help="Pre-v1 user-ready completion report")
    comp.add_argument("--json", action="store_true")

    stc = sub.add_parser("self-test", help="Run package/application self-test")
    stc.add_argument("--json", action="store_true")

    statcmd = sub.add_parser("status", help="Print application status")
    statcmd.add_argument("--json", action="store_true")

    slr = sub.add_parser("stable-lock-report", help="Print v1 stable-lock report")
    slr.add_argument("--json", action="store_true")

    ex = sub.add_parser("export-csv", help="Export table CSV")
    ex.add_argument("table", choices=["assets", "service_logs", "reminders", "parts_catalog", "asset_documents", "warranty_claims", "service_templates", "service_plans", "audit_log", "inspection_records", "fault_reports"])
    ex.add_argument("path")
    ex.add_argument("--json", action="store_true")

    b = sub.add_parser("backup", help="Create SQLite backup")
    b.add_argument("--path", default="")
    b.add_argument("--json", action="store_true")

    rec = sub.add_parser("recovery", help="Integrity, backup verification, checksum manifest, compact/repair, and audit export")
    rec.add_argument("--integrity", action="store_true")
    rec.add_argument("--verify-backup", default="")
    rec.add_argument("--restore-preview", default="")
    rec.add_argument("--checksum-manifest", default="")
    rec.add_argument("--compact", action="store_true")
    rec.add_argument("--audit-json", default="")
    rec.add_argument("--limit", type=int, default=1000)
    rec.add_argument("--json", action="store_true")

    ae = sub.add_parser("aegis", help="AEGIS JSON actions")
    ae.add_argument("action", choices=["contract", "manifest", "health_check", "summary", "dashboard", "status", "self_test", "completion_report", "stable_lock_report", "service_queue", "service_due", "service_templates", "service_plans", "service_plan_summary", "cost_report", "ledger_bridge", "inventory_bridge", "bridge_summary", "inspections", "inspection_summary", "faults", "fault_summary", "warranty_expiring", "warranty_center", "parts", "documents", "warranty_claims", "reminders", "integrity_check", "verify_backup", "checksum_manifest", "audit_log", "recovery_status", "backup", "vault_export"])
    ae.add_argument("--days", type=int, default=60)
    ae.add_argument("--path", default="")
    ae.add_argument("--limit", type=int, default=1000)

    return p


def main(argv: Optional[List[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.version:
        print(f"{APP_NAME} {VERSION}")
        return 0
    if args.gui:
        run_gui(); return 0

    conn = connect()
    try:
        if args.health_check:
            print_json(health(conn)); return 0
        if getattr(args, "show_summary", False):
            print_json(summary(conn)); return 0
        if args.dashboard:
            print_json(dashboard(conn)); return 0
        if getattr(args, "show_status", False):
            print_json(app_status(conn)); return 0
        if getattr(args, "self_test", False):
            print_json(self_test(conn)); return 0
        if getattr(args, "stable_lock_report", False):
            print_json(stable_lock_report(conn)); return 0
        if args.manifest:
            print_json(aegis_manifest()); return 0
        if args.command is None:
            run_gui(); return 0

        if args.command == "add-asset":
            aid = add_asset(conn, args); conn.commit();
            out = {"asset_id": aid, "asset": get_asset(conn, aid)}
            print_json(out) if args.json else print(f"Added asset ID {aid}: {args.name}")
        elif args.command == "list-assets":
            rows = list_assets(conn, args.include_archived, args.asset_type, args.status, args.search, args.location, args.due_only, args.warranty_only, args.days)
            print_json({"assets": rows}) if args.json else print_table(rows, ["id","name","asset_type","make","model","serial_number","location","display_status","next_service_date","warranty_expiry"])
        elif args.command == "asset":
            if args.status: set_asset_status(conn, args.id, args.status); conn.commit()
            if args.archive: archive_asset(conn, args.id); conn.commit()
            asset = get_asset(conn, args.id)
            print_json(asset) if args.json else print_table([asset], ["id","name","asset_type","make","model","serial_number","location","status","next_service_date","warranty_expiry"])
        elif args.command == "add-service":
            sid = add_service(conn, args); conn.commit()
            out = {"service_id": sid}
            print_json(out) if args.json else print(f"Added service entry ID {sid}.")
        elif args.command == "list-service":
            rows = list_service(conn, args.asset_id, args.limit)
            print_json({"service_logs": rows}) if args.json else print_table(rows, ["id","asset_name","service_date","service_type","summary","parts_used","cost","next_service_date"])
        elif args.command == "reminders":
            if args.add:
                if not args.title: raise SystemExit("--title is required with --add")
                rid = add_reminder(conn, args); conn.commit(); out={"reminder_id":rid}
                print_json(out) if args.json else print(f"Added reminder ID {rid}.")
            elif args.done:
                complete_reminder(conn, args.done); conn.commit(); print_json({"done": args.done}) if args.json else print(f"Reminder {args.done} marked done.")
            else:
                rows = list_reminders(conn, args.include_done, args.days)
                print_json({"reminders": rows}) if args.json else print_table(rows, ["id","asset_name","title","due_date","priority","status"])
        elif args.command == "service-queue":
            rows = service_queue(conn, args.days)
            print_json({"service_queue": rows}) if args.json else print_table(rows, ["id","name","asset_type","location","next_service_date","days_until_service","service_queue_state","service_priority","recommended_action"])
        elif args.command == "due":
            rows = due_assets(conn, args.days)
            print_json({"service_due": rows}) if args.json else print_table(rows, ["id","name","asset_type","next_service_date","days_until_service","status"])
        elif args.command == "warranty":
            rows = warranty_expiring(conn, args.days)
            print_json({"warranty_expiring": rows}) if args.json else print_table(rows, ["id","name","asset_type","warranty_expiry","days_until_warranty_expiry","status"])

        elif args.command == "parts":
            if args.add:
                if not args.name: raise SystemExit("--name is required with parts --add")
                pid = add_part(conn, args); conn.commit(); out={"part_id": pid}
                print_json(out) if args.json else print(f"Added part ID {pid}.")
            elif args.use:
                out = use_part(conn, args.use, args.use_qty, args.asset_id, args.notes); conn.commit()
                print_json(out) if args.json else print(out["message"])
            else:
                rows = list_parts(conn, args.asset_id, args.low_only, args.include_archived, args.search)
                print_json({"parts": rows}) if args.json else print_table(rows, ["id","asset_name","part_name","part_number","quantity","minimum_quantity","unit","status","location","low_stock"])
        elif args.command == "documents":
            if args.add:
                if not args.title or not args.path: raise SystemExit("--title and --path are required with documents --add")
                did = add_document(conn, args); conn.commit(); out={"document_id": did}
                print_json(out) if args.json else print(f"Added document ID {did}.")
            else:
                rows = list_documents(conn, args.asset_id, args.doc_type if args.doc_type != "Other" else "", args.search)
                print_json({"documents": rows}) if args.json else print_table(rows, ["id","asset_name","doc_type","title","path","path_exists","expiry_date","days_until_expiry"])
        elif args.command == "warranty-center":
            out = warranty_center(conn, args.days)
            print_json(out) if args.json else print_table(out["items"], ["id","name","asset_type","warranty_expiry","days_until_warranty_expiry","warranty_state","warranty_documents","open_claims"])
        elif args.command == "warranty-claims":
            if args.add:
                if not args.asset_id or not args.issue: raise SystemExit("--asset-id and --issue are required with warranty-claims --add")
                cid = add_warranty_claim(conn, args); conn.commit(); out={"claim_id": cid}
                print_json(out) if args.json else print(f"Added warranty claim ID {cid}.")
            else:
                rows = list_warranty_claims(conn, args.asset_id, args.include_closed, args.limit)
                print_json({"warranty_claims": rows}) if args.json else print_table(rows, ["id","asset_name","claim_date","claim_status","provider","reference","issue","cost"])
        elif args.command == "service-templates":
            if args.add:
                if not args.name: raise SystemExit("--name is required with service-templates --add")
                tid = add_service_template(conn, args); conn.commit(); out={"template_id": tid}
                print_json(out) if args.json else print(f"Added service template ID {tid}.")
            else:
                rows = list_service_templates(conn, args.include_inactive, args.asset_type if args.asset_type != "Other" else "", args.search)
                print_json({"service_templates": rows}) if args.json else print_table(rows, ["id","name","asset_type","service_type","interval_days","estimated_cost","provider","active"])
        elif args.command == "service-plans":
            if args.add:
                if not args.asset_id: raise SystemExit("--asset-id is required with service-plans --add")
                pid = add_service_plan(conn, args); conn.commit(); out={"plan_id": pid}
                print_json(out) if args.json else print(f"Added service plan ID {pid}.")
            elif args.complete:
                out = complete_service_plan(conn, args.complete, args.service_date, args.cost, args.notes); conn.commit()
                print_json(out) if args.json else print(f"Completed service plan {out['plan_id']}; next service {out['next_service_date']}.")
            else:
                rows = list_service_plans(conn, args.asset_id, args.status if args.status != "Active" else "", args.days, args.include_archived, args.search)
                print_json({"service_plans": rows}) if args.json else print_table(rows, ["id","asset_name","plan_name","service_type","interval_days","last_service_date","next_service_date","plan_state","estimated_cost"])
        elif args.command == "service-plan-summary":
            out = service_plan_summary(conn, args.days)
            print_json(out) if args.json else print_table(out["due_plans"], ["id","asset_name","plan_name","next_service_date","days_until_service","plan_state","estimated_cost"])
        elif args.command == "cost-report":
            out = cost_report(conn, args.start, args.end, args.asset_id, args.days)
            print_json(out) if args.json else print_table(out["by_asset"], ["asset_id","asset_name","count","total_cost"])
        elif args.command == "ledger-bridge":
            out = export_ledger_bridge(conn, Path(args.path) if args.path else None, args.start, args.end, args.asset_id); conn.commit()
            print_json(out) if args.json else print(f"Ledger bridge exported: {out['path']}")
        elif args.command == "inventory-bridge":
            out = export_inventory_bridge(conn, Path(args.path) if args.path else None, args.low_only, args.include_archived); conn.commit()
            print_json(out) if args.json else print(f"Inventory bridge exported: {out['path']}")
        elif args.command == "bridge-summary":
            out = bridge_summary(conn)
            print_json(out) if args.json else print_table([out], ["ledger_rows_available","ledger_total_available","inventory_rows_available","inventory_total_value"])

        elif args.command == "inspections":
            if args.add:
                if not args.asset_id: raise SystemExit("--asset-id is required with inspections --add")
                iid = add_inspection(conn, args); conn.commit(); out={"inspection_id": iid}
                print_json(out) if args.json else print(f"Added inspection ID {iid}.")
            elif args.summary:
                out = inspection_summary(conn, args.days)
                print_json(out) if args.json else print_table(out["action_required"], ["id","asset_name","inspection_date","condition_rating","inspection_state","priority","next_inspection_date"])
            else:
                rows = list_inspections(conn, args.asset_id, args.include_closed, args.limit)
                print_json({"inspections": rows}) if args.json else print_table(rows, ["id","asset_name","inspection_date","condition_rating","inspection_state","priority","next_inspection_date","status"])
        elif args.command == "faults":
            if args.add:
                if not args.asset_id or not args.issue: raise SystemExit("--asset-id and --issue are required with faults --add")
                fid = add_fault(conn, args); conn.commit(); out={"fault_id": fid}
                print_json(out) if args.json else print(f"Added fault ID {fid}.")
            elif args.close:
                row = set_fault_status(conn, args.close, "Resolved", args.resolved_date); conn.commit()
                print_json(row) if args.json else print(f"Fault {args.close} marked resolved.")
            elif args.summary:
                out = fault_summary(conn)
                print_json(out) if args.json else print_table(out["open_items"], ["id","asset_name","report_date","severity","issue","status"])
            else:
                rows = list_faults(conn, args.asset_id, args.include_closed, args.severity if args.severity != "Medium" else "", args.limit)
                print_json({"faults": rows}) if args.json else print_table(rows, ["id","asset_name","report_date","severity","issue","status"])
        elif args.command == "recovery":
            if args.verify_backup:
                out = backup_verification(Path(args.verify_backup))
            elif args.restore_preview:
                out = restore_preview(Path(args.restore_preview))
            elif args.checksum_manifest:
                out = checksum_manifest(conn, Path(args.checksum_manifest)); conn.commit()
            elif args.compact:
                out = compact_repair(conn); conn.commit()
            elif args.audit_json:
                out = audit_log_export(conn, Path(args.audit_json), args.limit); conn.commit()
            else:
                out = integrity_report(conn)
            print_json(out) if args.json else print_json(out)
        elif args.command == "setup":
            if args.show or not any([args.household_name, args.default_location, args.preferred_provider, args.currency]):
                out = get_settings(conn)
            else:
                out = set_settings(conn, {"household_name": args.household_name, "default_location": args.default_location, "preferred_provider": args.preferred_provider, "currency": args.currency})
                conn.commit()
            print_json({"settings": out}) if args.json or args.show else print("Sentinel Maintenance setup saved.")
        elif args.command == "completion-report":
            out = completion_report(conn)
            print_json(out) if args.json else print_json(out)
        elif args.command == "self-test":
            out = self_test(conn)
            print_json(out) if args.json else print_json(out)
        elif args.command == "status":
            out = app_status(conn)
            print_json(out) if args.json else print_json(out)
        elif args.command == "stable-lock-report":
            out = stable_lock_report(conn)
            print_json(out) if args.json else print_json(out)
        elif args.command == "export-csv":
            out = export_csv(conn, args.table, Path(args.path)); conn.commit();
            print_json({"exported": str(out)}) if args.json else print(f"Exported {args.table}: {out}")
        elif args.command == "backup":
            info = backup_db(conn, Path(args.path) if args.path else None); conn.commit();
            print_json(info) if args.json else print(f"Backup created: {info['backup_path']}")
        elif args.command == "aegis":
            action = args.action
            if action == "contract": print_json({"program": PROGRAM_NUMBER, "application": APP_NAME, "version": VERSION, "contract_version": "v1.0.0", "actions": aegis_manifest()["aegis_actions"], "local_only": True, "network": False, "telemetry": False})
            elif action == "manifest": print_json(aegis_manifest())
            elif action == "health_check": print_json(health(conn))
            elif action == "summary": print_json(summary(conn))
            elif action == "dashboard": print_json(dashboard(conn))
            elif action == "status": print_json(app_status(conn))
            elif action == "self_test": print_json(self_test(conn))
            elif action == "completion_report": print_json(completion_report(conn))
            elif action == "stable_lock_report": print_json(stable_lock_report(conn))
            elif action == "service_queue": print_json({"service_queue": service_queue(conn, args.days)})
            elif action == "service_due": print_json({"service_due": due_assets(conn, args.days)})
            elif action == "service_templates": print_json({"service_templates": list_service_templates(conn)})
            elif action == "service_plans": print_json({"service_plans": list_service_plans(conn, days=args.days, include_archived=True)})
            elif action == "service_plan_summary": print_json(service_plan_summary(conn, args.days))
            elif action == "cost_report": print_json(cost_report(conn, days=args.days))
            elif action == "ledger_bridge": print_json(export_ledger_bridge(conn))
            elif action == "inventory_bridge": print_json(export_inventory_bridge(conn, include_archived=True))
            elif action == "bridge_summary": print_json(bridge_summary(conn))
            elif action == "inspections": print_json({"inspections": list_inspections(conn, include_closed=True, limit=1000)})
            elif action == "inspection_summary": print_json(inspection_summary(conn, args.days))
            elif action == "faults": print_json({"faults": list_faults(conn, include_closed=True, limit=1000)})
            elif action == "fault_summary": print_json(fault_summary(conn))
            elif action == "warranty_expiring": print_json({"warranty_expiring": warranty_expiring(conn, args.days)})
            elif action == "warranty_center": print_json(warranty_center(conn, args.days))
            elif action == "parts": print_json({"parts": list_parts(conn)})
            elif action == "documents": print_json({"documents": list_documents(conn)})
            elif action == "warranty_claims": print_json({"warranty_claims": list_warranty_claims(conn, include_closed=True, limit=500)})
            elif action == "reminders": print_json({"reminders": list_reminders(conn, include_done=False, days=args.days)})
            elif action == "integrity_check": print_json(integrity_report(conn))
            elif action == "verify_backup":
                if not args.path: raise SystemExit("--path is required for aegis verify_backup")
                print_json(backup_verification(Path(args.path)))
            elif action == "checksum_manifest": print_json(checksum_manifest(conn, Path(args.path) if args.path else None))
            elif action == "audit_log": print_json({"audit_log": [row_to_dict(r) for r in conn.execute("SELECT * FROM audit_log ORDER BY id DESC LIMIT ?", (args.limit,)).fetchall()]})
            elif action == "recovery_status": print_json(recovery_status(conn))
            elif action == "backup": print_json(backup_db(conn))
            elif action == "vault_export": print_json(aegis_export(conn))
        return 0
    finally:
        conn.close()


if __name__ == "__main__":
    raise SystemExit(main())
