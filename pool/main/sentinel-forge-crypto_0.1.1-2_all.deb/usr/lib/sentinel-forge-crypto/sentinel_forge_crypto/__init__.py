VERSION = "0.1.1"
APP_ID = "sentinel-forge-crypto"
