# sentinel-forge-crypto v0.1.1 Redteam Security Cleanup

Hardens symlink output handling, tar extraction, folder packing, mountpoint handling and device/container path validation.
