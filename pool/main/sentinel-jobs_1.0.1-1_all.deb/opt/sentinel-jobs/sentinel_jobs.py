#!/usr/bin/env python3
"""
Sentinel Jobs - local-first job/opportunity tracker.
Program 112 stable lock baseline for local-first job and opportunity tracking.
No network, no telemetry, no cloud dependency.
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import shutil
import sqlite3
import sys
import tempfile
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

APP_NAME = "Sentinel Jobs"
APP_ID = "sentinel-jobs"
VERSION = "1.0.1"
DEBIAN_VERSION = "1.0.1-1"
SCHEMA_VERSION = 5
DEFAULT_CODE_PREFIX = "JOB"
DEFAULT_CURRENCY = "AUD"
STATUSES = ["saved", "applied", "interview", "offer", "rejected", "withdrawn", "accepted", "closed"]
JOB_TYPES = ["employment", "contract", "side_job", "repair_job", "apprenticeship", "training", "other"]
ACTION_TYPES = ["apply", "follow_up", "interview", "call", "email", "resume", "cover_letter", "test", "document", "other"]
DOCUMENT_TYPES = ["resume", "cover_letter", "portfolio", "certificate", "licence", "reference", "selection_criteria", "identity", "other"]
REQUIRED_APPLICATION_DOC_TYPES = ["resume", "cover_letter"]

REMOTE_MODES = ["", "onsite", "hybrid", "remote", "field", "mobile", "unspecified"]
SORT_OPTIONS = ["priority", "fit", "due", "updated", "created", "company", "status"]
CONTACT_TYPES = ["recruiter", "hiring_manager", "client", "referee", "agency", "colleague", "other"]
CONTACT_EVENT_TYPES = ["call", "email", "message", "meeting", "follow_up", "note", "other"]
SKILL_LEVEL_MIN = 1
SKILL_LEVEL_MAX = 5

SENTINEL_GTK_CSS = r"""
/* Sentinel Jobs v1.0.1 - F.O.R.G.E-style AEGIS/Sentinel command theme
   Security hardening patch: private file modes, CSV injection guard, robust imports.
   Stable lock patch: completed responsive GUI, validated backup buttons,
   stable reports, audit exports, and v1 handoff bundle. */
* {
    font-family: Sans, "Noto Sans", "DejaVu Sans";
    -GtkWidget-focus-line-width: 1;
    -GtkWidget-focus-padding: 1;
    text-shadow: none;
    background-image: none;
}
window, .sentinel-root {
    background-color: #05090C;
    color: #E6E0D2;
}
box, grid, paned, viewport, scrolledwindow {
    background-color: #05090C;
    color: #E6E0D2;
}
.sentinel-body-shell {
    background-color: #05090C;
    color: #E6E0D2;
    padding: 10px;
}
.sentinel-program-header {
    background-color: #101923;
    color: #E6E0D2;
    border-bottom: 1px solid #000000;
    padding: 12px;
}
.sentinel-logo-frame {
    background-color: #101923;
    border: 0px solid #101923;
}
.sentinel-app-name {
    color: #E19B00;
    font-weight: 800;
    font-size: 20px;
    letter-spacing: 5px;
}
.sentinel-app-subtitle {
    color: #AAB3BC;
    font-size: 10.5pt;
}
.sentinel-content-shell {
    background-color: #05090C;
    color: #E6E0D2;
}
.sentinel-sidebar {
    background-color: #101923;
    color: #E6E0D2;
    border-right: 1px solid #000000;
    padding: 8px;
    min-width: 224px;
}
.sentinel-sidebar button {
    background-image: none;
    background-color: #16242E;
    color: #E6E0D2;
    border: 1px solid #0A1118;
    border-radius: 0px;
    padding: 8px 10px;
    text-shadow: none;
    box-shadow: none;
}
.sentinel-sidebar button:hover {
    background-color: #20313D;
    color: #E19B00;
    border-color: #E19B00;
}
.sentinel-sidebar button:active, .sentinel-sidebar button:checked {
    background-color: #1C2D39;
    color: #E19B00;
    border-color: #E19B00;
}
.sentinel-sidebar button.sentinel-nav-active {
    background-color: #1C2D39;
    color: #E19B00;
    border-color: #E19B00;
    font-weight: 800;
}
.sentinel-sidebar button.sentinel-nav-active label {
    color: #E19B00;
}
.dashboard-shell, .sentinel-page, .sentinel-stack {
    background-color: #05090C;
    color: #E6E0D2;
}
.dashboard-hero {
    background-color: #0C131A;
    color: #E6E0D2;
    border: 1px solid #101923;
    border-radius: 0px;
    padding: 12px;
}
.sentinel-card, .sentinel-panel {
    background-color: #0C131A;
    color: #E6E0D2;
    border: 1px solid #101923;
    border-radius: 0px;
    padding: 10px;
}
.sentinel-card-accent {
    background-color: #101923;
    border: 1px solid #1D2B36;
}
.sentinel-output-frame {
    background-color: #05090C;
    border: 2px solid #D8D8D8;
    border-radius: 0px;
}
label {
    color: #E6E0D2;
}
label.sentinel-title, .sentinel-title {
    color: #E19B00;
    font-weight: 700;
}
label.sentinel-hero-title {
    color: #E19B00;
    font-weight: 800;
    font-size: 21px;
}
label.sentinel-subtitle {
    color: #AAB3BC;
    font-size: 10.5pt;
}
label.sentinel-muted {
    color: #AAB3BC;
}
label.sentinel-cyan {
    color: #03C8FF;
}
label.sentinel-good {
    color: #75D67A;
}
label.sentinel-warn {
    color: #FFD37A;
}
label.sentinel-danger {
    color: #FF8E7A;
}
.sentinel-kpi-value {
    color: #E19B00;
    font-weight: 800;
    font-size: 22px;
}
.sentinel-kpi-value-cyan {
    color: #03C8FF;
    font-weight: 800;
    font-size: 22px;
}
.sentinel-kpi-value-danger {
    color: #FF8E7A;
    font-weight: 800;
    font-size: 22px;
}
.sentinel-kpi-label {
    color: #E19B00;
    font-weight: 700;
}
.sentinel-status-pill {
    background-color: #111B24;
    color: #E6E0D2;
    border: 1px solid #263743;
    border-radius: 0px;
    padding: 4px 7px;
}
entry, spinbutton, spinbutton entry {
    background-image: none;
    background-color: #141C23;
    color: #F1E8D4;
    border: 1px solid #46515A;
    border-radius: 0px;
    padding: 7px;
    box-shadow: none;
}
entry:focus, spinbutton:focus, spinbutton entry:focus {
    border-color: #E19B00;
    background-color: #0F171E;
}
entry selection, spinbutton entry selection, textview text selection {
    background-color: #E19B00;
    color: #05090C;
}
combobox, combobox box, combobox button, combobox arrow, combobox cellview {
    background-image: none;
    background-color: #141C23;
    color: #F1E8D4;
    border-color: #46515A;
    box-shadow: none;
}
combobox button {
    background-image: none;
    background-color: #141C23;
    border: 1px solid #46515A;
    border-radius: 0px;
    padding: 5px 7px;
    color: #F1E8D4;
}
combobox button:focus, combobox button:hover {
    border-color: #E19B00;
    color: #E19B00;
    background-color: #19242D;
}
menu, menuitem, popover, window.popup {
    background-color: #2E3034;
    color: #F1E8D4;
    border: 1px solid #0A0C0F;
}
menuitem:hover, menuitem:selected {
    background-color: #3B3D42;
    color: #E19B00;
}
menubar {
    background-color: #202326;
    color: #F1E8D4;
    border-bottom: 1px solid #0A0C0F;
}
menubar > menuitem {
    color: #F1E8D4;
    padding: 5px 10px;
}
menubar > menuitem:hover {
    background-color: #3B3D42;
    color: #E19B00;
}
button {
    background-image: none;
    background-color: #17232C;
    color: #E6E0D2;
    border: 1px solid #D8D8D8;
    border-radius: 0px;
    padding: 7px 10px;
    text-shadow: none;
    box-shadow: none;
}
button:hover {
    background-color: #20313D;
    color: #E19B00;
    border-color: #E19B00;
}
button:active {
    background-color: #0B1218;
    color: #03C8FF;
    border-color: #03C8FF;
}
textview, textview text {
    background-color: #05090C;
    color: #E6E0D2;
    border-radius: 0px;
}
textview.sentinel-output text, .sentinel-output text {
    background-color: #05090C;
    color: #E6E0D2;
}
textview border, scrolledwindow {
    border: 1px solid #101923;
    border-radius: 0px;
}
separator {
    background-color: #182631;
}
progressbar trough {
    background-color: #05090C;
    border: 1px solid #101923;
    border-radius: 0px;
}
progressbar progress {
    background-color: #E19B00;
    border-radius: 0px;
}
scrollbar, scrollbar trough {
    background-color: #0A1118;
    border: 1px solid #101923;
    min-width: 13px;
    min-height: 13px;
}
scrollbar slider {
    background-color: #4A5560;
    border: 1px solid #D8D8D8;
    border-radius: 0px;
    min-width: 13px;
    min-height: 13px;
}
scrollbar slider:hover, scrollbar slider:active {
    background-color: #E19B00;
    border-color: #E19B00;
}
scrollbar button {
    background-color: #101923;
    color: #E19B00;
    border: 1px solid #0A1118;
    min-width: 13px;
    min-height: 13px;
}
.sentinel-scroll {
    background-color: #05090C;
    border: 1px solid #101923;
}
.sentinel-menu-bar, menubar {
    background-color: #202326;
    color: #F1E8D4;
}
.sentinel-menu-bar menuitem, menuitem label, menubar menuitem label {
    color: #F1E8D4;
}
.sentinel-menu-bar menuitem:hover label, menuitem:hover label, menuitem:selected label {
    color: #E19B00;
}
.sentinel-dashboard-grid, .sentinel-equal-grid {
    background-color: #05090C;
}

.sentinel-page-frame {
    background-color: #05090C;
    color: #E6E0D2;
    padding-left: 10px;
    padding-right: 10px;
}
.sentinel-stack {
    background-color: #05090C;
    color: #E6E0D2;
}
.sentinel-dashboard-grid > * {
    margin: 0px;
}
.sentinel-manual-text text, textview.sentinel-manual-text text {
    background-color: #05090C;
    color: #E6E0D2;
    padding: 12px;
}
.sentinel-hotkey-label {
    color: #03C8FF;
    font-weight: 700;
}
"""

def now_iso() -> str:
    return datetime.now().replace(microsecond=0).isoformat()


def today_iso() -> str:
    return date.today().isoformat()


def app_data_dir() -> Path:
    override = os.environ.get("SENTINEL_JOBS_HOME")
    if override:
        return Path(override).expanduser()
    return Path.home() / ".local" / "share" / APP_ID


def default_db_path() -> Path:
    override = os.environ.get("SENTINEL_JOBS_DB")
    if override:
        return Path(override).expanduser()
    return app_data_dir() / "jobs.sqlite3"


def export_dir() -> Path:
    override = os.environ.get("SENTINEL_JOBS_EXPORT_DIR")
    path = Path(override).expanduser() if override else app_data_dir() / "exports"
    return ensure_private_dir(path)


def backup_dir() -> Path:
    override = os.environ.get("SENTINEL_JOBS_BACKUP_DIR")
    path = Path(override).expanduser() if override else app_data_dir() / "backups"
    return ensure_private_dir(path)


PRIVATE_DIR_MODE = 0o700
PRIVATE_FILE_MODE = 0o600
CSV_FORMULA_PREFIXES = ("=", "+", "-", "@", "\t", "\r", "\n")


def ensure_private_dir(path: Path) -> Path:
    """Create a local data directory with owner-only permissions."""
    path = Path(path).expanduser()
    path.mkdir(parents=True, exist_ok=True)
    try:
        path.chmod(PRIVATE_DIR_MODE)
    except PermissionError:
        # Non-fatal for unusual filesystems, but default local stores are hardened.
        pass
    return path


def harden_file(path: Path) -> Path:
    """Set owner-only permissions on a local database/export/backup file."""
    path = Path(path).expanduser()
    try:
        if path.exists() and path.is_file():
            path.chmod(PRIVATE_FILE_MODE)
    except PermissionError:
        pass
    return path


def secure_parent(path: Path) -> Path:
    path = Path(path).expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def safe_csv_value(value: Any) -> Any:
    """Neutralise spreadsheet formula injection while preserving normal CSV values."""
    if isinstance(value, str) and value.startswith(CSV_FORMULA_PREFIXES):
        return "'" + value
    return value


def safe_csv_row(row: Any) -> Any:
    if isinstance(row, dict):
        return {k: safe_csv_value(v) for k, v in row.items()}
    if isinstance(row, (list, tuple)):
        return [safe_csv_value(v) for v in row]
    return safe_csv_value(row)


def csv_writerow_safe(writer: Any, row: Any) -> None:
    writer.writerow(safe_csv_row(row))


def csv_writerows_safe(writer: Any, rows: Iterable[Any]) -> None:
    for row in rows:
        csv_writerow_safe(writer, row)


def safe_float(value: Any, default: float = 0.0) -> float:
    try:
        if value in (None, ""):
            return default
        return float(value)
    except (TypeError, ValueError):
        return default


def safe_int(value: Any, default: int = 0) -> int:
    try:
        if value in (None, ""):
            return default
        return int(value)
    except (TypeError, ValueError):
        return default


def connect(db_path: Optional[Path] = None) -> sqlite3.Connection:
    db_path = Path(db_path or default_db_path()).expanduser()
    ensure_private_dir(db_path.parent)
    if db_path.exists() and db_path.is_symlink():
        raise ValueError(f"Refusing to open symlinked database path: {db_path}")
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    harden_file(db_path)
    return conn


def init_db(conn: sqlite3.Connection) -> None:
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS metadata (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS jobs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            job_code TEXT UNIQUE NOT NULL,
            title TEXT NOT NULL,
            company TEXT DEFAULT '',
            job_type TEXT DEFAULT 'employment',
            location TEXT DEFAULT '',
            remote_mode TEXT DEFAULT '',
            source TEXT DEFAULT '',
            source_url TEXT DEFAULT '',
            salary_min REAL DEFAULT 0,
            salary_max REAL DEFAULT 0,
            currency TEXT DEFAULT 'AUD',
            status TEXT DEFAULT 'saved',
            priority INTEGER DEFAULT 3,
            fit_score INTEGER DEFAULT 0,
            applied_date TEXT DEFAULT '',
            due_date TEXT DEFAULT '',
            contact_name TEXT DEFAULT '',
            contact_email TEXT DEFAULT '',
            notes TEXT DEFAULT '',
            archived INTEGER DEFAULT 0,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS actions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            job_id INTEGER NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
            action_type TEXT DEFAULT 'other',
            description TEXT NOT NULL,
            due_date TEXT DEFAULT '',
            status TEXT DEFAULT 'open',
            completed_at TEXT DEFAULT '',
            notes TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS documents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            job_id INTEGER NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
            path TEXT NOT NULL,
            document_type TEXT DEFAULT 'other',
            notes TEXT DEFAULT '',
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS interviews (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            job_id INTEGER NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
            interview_type TEXT DEFAULT 'interview',
            scheduled_date TEXT DEFAULT '',
            scheduled_time TEXT DEFAULT '',
            mode TEXT DEFAULT '',
            location TEXT DEFAULT '',
            interviewer TEXT DEFAULT '',
            status TEXT DEFAULT 'scheduled',
            prep_notes TEXT DEFAULT '',
            questions TEXT DEFAULT '',
            outcome_notes TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS saved_views (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            query TEXT DEFAULT '',
            status TEXT DEFAULT '',
            company TEXT DEFAULT '',
            job_type TEXT DEFAULT '',
            remote_mode TEXT DEFAULT '',
            priority_max INTEGER DEFAULT 0,
            fit_min INTEGER DEFAULT 0,
            due_days INTEGER DEFAULT 0,
            include_archived INTEGER DEFAULT 0,
            sort TEXT DEFAULT 'priority',
            limit_count INTEGER DEFAULT 50,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS companies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            industry TEXT DEFAULT '',
            website TEXT DEFAULT '',
            phone TEXT DEFAULT '',
            email TEXT DEFAULT '',
            address TEXT DEFAULT '',
            notes TEXT DEFAULT '',
            follow_up_date TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS contacts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            company_id INTEGER REFERENCES companies(id) ON DELETE SET NULL,
            name TEXT NOT NULL,
            contact_type TEXT DEFAULT 'other',
            title TEXT DEFAULT '',
            email TEXT DEFAULT '',
            phone TEXT DEFAULT '',
            source TEXT DEFAULT '',
            notes TEXT DEFAULT '',
            follow_up_date TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS contact_interactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            contact_id INTEGER REFERENCES contacts(id) ON DELETE CASCADE,
            company_id INTEGER REFERENCES companies(id) ON DELETE SET NULL,
            job_id INTEGER REFERENCES jobs(id) ON DELETE SET NULL,
            event_type TEXT DEFAULT 'note',
            event_date TEXT DEFAULT '',
            summary TEXT NOT NULL,
            next_follow_up TEXT DEFAULT '',
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS profile_skills (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            skill TEXT UNIQUE NOT NULL,
            level INTEGER DEFAULT 3,
            notes TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS job_skills (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            job_id INTEGER NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
            skill TEXT NOT NULL,
            required_level INTEGER DEFAULT 3,
            importance INTEGER DEFAULT 3,
            source TEXT DEFAULT 'manual',
            notes TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            UNIQUE(job_id, skill)
        );
        CREATE TABLE IF NOT EXISTS audit_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_ts TEXT NOT NULL,
            action TEXT NOT NULL,
            entity_type TEXT NOT NULL,
            entity_id TEXT NOT NULL,
            details TEXT DEFAULT ''
        );
        CREATE INDEX IF NOT EXISTS idx_jobs_code ON jobs(job_code);
        CREATE INDEX IF NOT EXISTS idx_jobs_status ON jobs(status);
        CREATE INDEX IF NOT EXISTS idx_jobs_company ON jobs(company);
        CREATE INDEX IF NOT EXISTS idx_jobs_due ON jobs(due_date);
        CREATE INDEX IF NOT EXISTS idx_jobs_archived ON jobs(archived);
        CREATE INDEX IF NOT EXISTS idx_actions_due ON actions(due_date);
        CREATE INDEX IF NOT EXISTS idx_actions_status ON actions(status);
        CREATE INDEX IF NOT EXISTS idx_interviews_job ON interviews(job_id);
        CREATE INDEX IF NOT EXISTS idx_interviews_date ON interviews(scheduled_date);
        CREATE INDEX IF NOT EXISTS idx_interviews_status ON interviews(status);
        CREATE INDEX IF NOT EXISTS idx_saved_views_name ON saved_views(name);
        CREATE INDEX IF NOT EXISTS idx_saved_views_updated ON saved_views(updated_at);
        CREATE INDEX IF NOT EXISTS idx_companies_name ON companies(name);
        CREATE INDEX IF NOT EXISTS idx_companies_follow_up ON companies(follow_up_date);
        CREATE INDEX IF NOT EXISTS idx_contacts_name ON contacts(name);
        CREATE INDEX IF NOT EXISTS idx_contacts_company ON contacts(company_id);
        CREATE INDEX IF NOT EXISTS idx_contacts_follow_up ON contacts(follow_up_date);
        CREATE INDEX IF NOT EXISTS idx_contact_interactions_contact ON contact_interactions(contact_id);
        CREATE INDEX IF NOT EXISTS idx_contact_interactions_next ON contact_interactions(next_follow_up);
        CREATE INDEX IF NOT EXISTS idx_profile_skills_skill ON profile_skills(skill);
        CREATE INDEX IF NOT EXISTS idx_job_skills_job ON job_skills(job_id);
        CREATE INDEX IF NOT EXISTS idx_job_skills_skill ON job_skills(skill);
        """
    )
    defaults = {
        "schema_version": str(SCHEMA_VERSION),
        "app_version": VERSION,
        "job_code_prefix": DEFAULT_CODE_PREFIX,
        "currency": DEFAULT_CURRENCY,
        "local_only": "true",
        "network_access": "disabled",
        "telemetry": "disabled",
        "sentinel_theme": "aegis_dark_sentinel_gold",
        "text_fields_themed": "true",
        "dropdown_menus_themed": "true",
        "document_pack_ready": "true",
        "forge_style_theme": "true",
        "left_sidebar_layout": "true",
        "command_header_layout": "true",
        "interview_prep_ready": "true",
        "interview_pack_ready": "true",
        "saved_views_ready": "true",
        "pipeline_board_ready": "true",
        "search_filter_ready": "true",
        "company_contact_tracking_ready": "true",
        "networking_followup_ready": "true",
        "skills_match_ready": "true",
        "job_skill_gap_ready": "true",
        "manual_tab_ready": "true",
        "ctrl_q_quit_hotkey_ready": "true",
        "fullscreen_proportion_guard_ready": "true",
        "responsive_fullscreen_layout_ready": "true",
        "required_application_docs": ",".join(REQUIRED_APPLICATION_DOC_TYPES),
    }
    for key, value in defaults.items():
        conn.execute("INSERT OR IGNORE INTO metadata(key,value) VALUES(?,?)", (key, value))
    conn.execute("UPDATE metadata SET value=? WHERE key='app_version'", (VERSION,))
    conn.execute("UPDATE metadata SET value=? WHERE key='schema_version'", (str(SCHEMA_VERSION),))
    conn.execute("UPDATE metadata SET value=? WHERE key='sentinel_theme'", ("aegis_dark_sentinel_gold",))
    conn.execute("UPDATE metadata SET value='true' WHERE key='text_fields_themed'")
    conn.execute("UPDATE metadata SET value='true' WHERE key='dropdown_menus_themed'")
    conn.execute("UPDATE metadata SET value='true' WHERE key='document_pack_ready'")
    conn.execute("INSERT OR IGNORE INTO metadata(key,value) VALUES('forge_style_theme','true')")
    conn.execute("UPDATE metadata SET value='true' WHERE key='forge_style_theme'")
    conn.execute("INSERT OR IGNORE INTO metadata(key,value) VALUES('left_sidebar_layout','true')")
    conn.execute("UPDATE metadata SET value='true' WHERE key='left_sidebar_layout'")
    conn.execute("INSERT OR IGNORE INTO metadata(key,value) VALUES('layout_hotfix','true')")
    conn.execute("UPDATE metadata SET value='true' WHERE key='layout_hotfix'")
    conn.execute("INSERT OR IGNORE INTO metadata(key,value) VALUES('command_header_layout','true')")
    conn.execute("UPDATE metadata SET value='true' WHERE key='command_header_layout'")
    conn.execute("INSERT OR IGNORE INTO metadata(key,value) VALUES('interview_prep_ready','true')")
    conn.execute("UPDATE metadata SET value='true' WHERE key='interview_prep_ready'")
    conn.execute("INSERT OR IGNORE INTO metadata(key,value) VALUES('interview_pack_ready','true')")
    conn.execute("UPDATE metadata SET value='true' WHERE key='interview_pack_ready'")
    conn.execute("INSERT OR IGNORE INTO metadata(key,value) VALUES('saved_views_ready','true')")
    conn.execute("UPDATE metadata SET value='true' WHERE key='saved_views_ready'")
    conn.execute("INSERT OR IGNORE INTO metadata(key,value) VALUES('pipeline_board_ready','true')")
    conn.execute("UPDATE metadata SET value='true' WHERE key='pipeline_board_ready'")
    conn.execute("INSERT OR IGNORE INTO metadata(key,value) VALUES('search_filter_ready','true')")
    conn.execute("UPDATE metadata SET value='true' WHERE key='search_filter_ready'")
    conn.execute("INSERT OR IGNORE INTO metadata(key,value) VALUES('company_contact_tracking_ready','true')")
    conn.execute("UPDATE metadata SET value='true' WHERE key='company_contact_tracking_ready'")
    conn.execute("INSERT OR IGNORE INTO metadata(key,value) VALUES('networking_followup_ready','true')")
    conn.execute("UPDATE metadata SET value='true' WHERE key='networking_followup_ready'")
    conn.execute("INSERT OR IGNORE INTO metadata(key,value) VALUES('skills_match_ready','true')")
    conn.execute("UPDATE metadata SET value='true' WHERE key='skills_match_ready'")
    conn.execute("INSERT OR IGNORE INTO metadata(key,value) VALUES('job_skill_gap_ready','true')")
    conn.execute("UPDATE metadata SET value='true' WHERE key='job_skill_gap_ready'")
    conn.execute("INSERT OR IGNORE INTO metadata(key,value) VALUES('manual_tab_ready','true')")
    conn.execute("UPDATE metadata SET value='true' WHERE key='manual_tab_ready'")
    conn.execute("INSERT OR IGNORE INTO metadata(key,value) VALUES('ctrl_q_quit_hotkey_ready','true')")
    conn.execute("UPDATE metadata SET value='true' WHERE key='ctrl_q_quit_hotkey_ready'")
    conn.execute("INSERT OR IGNORE INTO metadata(key,value) VALUES('fullscreen_proportion_guard_ready','true')")
    conn.execute("UPDATE metadata SET value='true' WHERE key='fullscreen_proportion_guard_ready'")
    conn.execute("INSERT OR IGNORE INTO metadata(key,value) VALUES('responsive_fullscreen_layout_ready','true')")
    conn.execute("UPDATE metadata SET value='true' WHERE key='responsive_fullscreen_layout_ready'")
    conn.execute("UPDATE metadata SET value=? WHERE key='required_application_docs'", (",".join(REQUIRED_APPLICATION_DOC_TYPES),))
    conn.commit()


def audit(conn: sqlite3.Connection, action: str, entity_type: str, entity_id: Any, details: str = "") -> None:
    conn.execute(
        "INSERT INTO audit_log(event_ts, action, entity_type, entity_id, details) VALUES(?,?,?,?,?)",
        (now_iso(), action, entity_type, str(entity_id), details),
    )


def get_meta(conn: sqlite3.Connection, key: str, default: str = "") -> str:
    row = conn.execute("SELECT value FROM metadata WHERE key=?", (key,)).fetchone()
    return row[0] if row else default


def set_meta(conn: sqlite3.Connection, key: str, value: str) -> None:
    conn.execute("INSERT INTO metadata(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, value))
    audit(conn, "set_meta", "metadata", key, value)
    conn.commit()


def normalize_status(status: str) -> str:
    status = (status or "saved").strip().lower().replace(" ", "_")
    if status not in STATUSES:
        raise ValueError(f"Invalid status '{status}'. Valid: {', '.join(STATUSES)}")
    return status


def normalize_job_type(job_type: str) -> str:
    job_type = (job_type or "employment").strip().lower().replace(" ", "_")
    if job_type not in JOB_TYPES:
        job_type = "other"
    return job_type


def next_job_code(conn: sqlite3.Connection, prefix: Optional[str] = None) -> str:
    prefix = (prefix or get_meta(conn, "job_code_prefix", DEFAULT_CODE_PREFIX) or DEFAULT_CODE_PREFIX).strip().upper()
    rows = conn.execute("SELECT job_code FROM jobs WHERE job_code LIKE ?", (f"{prefix}-%",)).fetchall()
    highest = 0
    for row in rows:
        code = row[0]
        try:
            suffix = code.rsplit("-", 1)[1]
            if suffix.isdigit():
                highest = max(highest, int(suffix))
        except Exception:
            continue
    return f"{prefix}-{highest + 1:04d}"


def resolve_job(conn: sqlite3.Connection, ident: str) -> sqlite3.Row:
    row = conn.execute("SELECT * FROM jobs WHERE job_code=? COLLATE NOCASE", (ident,)).fetchone()
    if row:
        return row
    if ident.isdigit():
        row = conn.execute("SELECT * FROM jobs WHERE id=?", (int(ident),)).fetchone()
        if row:
            return row
    raise SystemExit(f"Job not found: {ident}")


def add_job(conn: sqlite3.Connection, args: argparse.Namespace) -> str:
    code = args.code or next_job_code(conn, args.code_prefix)
    status = normalize_status(args.status)
    job_type = normalize_job_type(args.job_type)
    ts = now_iso()
    conn.execute(
        """
        INSERT INTO jobs(job_code,title,company,job_type,location,remote_mode,source,source_url,
                         salary_min,salary_max,currency,status,priority,fit_score,applied_date,due_date,
                         contact_name,contact_email,notes,created_at,updated_at)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """,
        (
            code,
            args.title,
            args.company or "",
            job_type,
            args.location or "",
            args.remote_mode or "",
            args.source or "",
            args.source_url or "",
            args.salary_min or 0,
            args.salary_max or 0,
            args.currency or get_meta(conn, "currency", DEFAULT_CURRENCY),
            status,
            args.priority,
            args.fit_score,
            args.applied_date or "",
            args.due_date or "",
            args.contact_name or "",
            args.contact_email or "",
            args.notes or "",
            ts,
            ts,
        ),
    )
    job_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    audit(conn, "add_job", "job", job_id, f"{code} {args.title}")
    if getattr(args, "skills", ""):
        add_job_skills(conn, argparse.Namespace(job=code, skills=args.skills, required_level=getattr(args, "skill_level", 3), importance=getattr(args, "skill_importance", 3), source="job-add", notes="added during job creation"), commit=False)
    if args.due_date and args.create_action:
        conn.execute(
            """INSERT INTO actions(job_id, action_type, description, due_date, status, notes, created_at, updated_at)
                 VALUES(?,?,?,?,?,?,?,?)""",
            (job_id, "apply" if status == "saved" else "follow_up", args.create_action, args.due_date, "open", "auto-created from job due date", ts, ts),
        )
        audit(conn, "add_action", "job", job_id, args.create_action)
    conn.commit()
    return f"Added job #{job_id}: {code} — {args.title}"



def job_sort_clause(sort_name: str) -> str:
    sort_name = (sort_name or "priority").strip().lower()
    if sort_name == "fit":
        return "fit_score DESC, priority ASC, updated_at DESC"
    if sort_name == "due":
        return "due_date='' ASC, date(due_date) ASC, priority ASC"
    if sort_name == "updated":
        return "datetime(updated_at) DESC"
    if sort_name == "created":
        return "datetime(created_at) DESC"
    if sort_name == "company":
        return "company COLLATE NOCASE ASC, priority ASC, title COLLATE NOCASE ASC"
    if sort_name == "status":
        return "status ASC, priority ASC, updated_at DESC"
    return "priority ASC, fit_score DESC, updated_at DESC"


def list_jobs(conn: sqlite3.Connection, args: argparse.Namespace) -> List[sqlite3.Row]:
    clauses = []
    params: List[Any] = []
    if not getattr(args, "include_archived", False):
        clauses.append("archived=0")
    status = getattr(args, "status", None)
    if status:
        clauses.append("status=?")
        params.append(normalize_status(status))
    company = getattr(args, "company", None)
    if company:
        clauses.append("company LIKE ?")
        params.append(f"%{company}%")
    query = getattr(args, "query", None)
    if query:
        clauses.append("(title LIKE ? OR company LIKE ? OR job_code LIKE ? OR notes LIKE ? OR location LIKE ? OR source LIKE ? OR source_url LIKE ? OR contact_name LIKE ? OR contact_email LIKE ?)")
        q = f"%{query}%"
        params.extend([q, q, q, q, q, q, q, q, q])
    job_type = getattr(args, "job_type", None)
    if job_type:
        clauses.append("job_type=?")
        params.append(normalize_job_type(job_type))
    remote_mode = getattr(args, "remote_mode", None)
    if remote_mode:
        clauses.append("remote_mode=?")
        params.append(remote_mode)
    priority_max = getattr(args, "priority_max", None)
    if priority_max is not None:
        try:
            if int(priority_max) > 0:
                clauses.append("priority<=?")
                params.append(int(priority_max))
        except Exception:
            pass
    fit_min = getattr(args, "fit_min", None)
    if fit_min is not None:
        try:
            if int(fit_min) > 0:
                clauses.append("fit_score>=?")
                params.append(int(fit_min))
        except Exception:
            pass
    due_days = getattr(args, "due_days", None)
    if due_days is not None:
        try:
            if int(due_days) >= 0:
                clauses.append("due_date!='' AND date(due_date) <= date('now', ?)")
                params.append(f"+{int(due_days)} day")
        except Exception:
            pass
    where = " WHERE " + " AND ".join(clauses) if clauses else ""
    limit = max(1, int(getattr(args, "limit", 50) or 50))
    order = job_sort_clause(getattr(args, "sort", "priority"))
    sql = f"SELECT * FROM jobs{where} ORDER BY archived ASC, {order} LIMIT ?"
    params.append(limit)
    return conn.execute(sql, params).fetchall()

def format_jobs(rows: Iterable[sqlite3.Row]) -> str:
    rows = list(rows)
    if not rows:
        return "No jobs found."
    widths = {
        "code": max(8, max(len(r["job_code"]) for r in rows)),
        "status": max(8, max(len(r["status"]) for r in rows)),
        "company": min(26, max(7, max(len(r["company"] or "") for r in rows))),
    }
    out = [f"{'Code':<{widths['code']}}  {'Status':<{widths['status']}}  {'Priority':<8}  {'Company':<{widths['company']}}  Title"]
    out.append("-" * (widths["code"] + widths["status"] + widths["company"] + 37))
    for r in rows:
        company = (r["company"] or "")[: widths["company"]]
        title = r["title"]
        if r["archived"]:
            title += " [archived]"
        out.append(f"{r['job_code']:<{widths['code']}}  {r['status']:<{widths['status']}}  {r['priority']:<8}  {company:<{widths['company']}}  {title}")
    return "\n".join(out)



def pipeline_board_data(conn: sqlite3.Connection, limit_per_status: int = 8) -> Dict[str, Any]:
    limit_per_status = max(1, int(limit_per_status or 8))
    columns: Dict[str, List[Dict[str, Any]]] = {}
    counts: Dict[str, int] = {}
    for status in STATUSES:
        counts[status] = conn.execute("SELECT COUNT(*) FROM jobs WHERE archived=0 AND status=?", (status,)).fetchone()[0]
        rows = conn.execute(
            """SELECT job_code,title,company,job_type,location,remote_mode,priority,fit_score,due_date,updated_at
                 FROM jobs WHERE archived=0 AND status=?
                 ORDER BY priority ASC, fit_score DESC, due_date='' ASC, date(due_date) ASC, updated_at DESC LIMIT ?""",
            (status, limit_per_status),
        ).fetchall()
        columns[status] = [dict(r) for r in rows]
    total_active = conn.execute("SELECT COUNT(*) FROM jobs WHERE archived=0").fetchone()[0]
    return {
        "app": APP_NAME,
        "version": VERSION,
        "schema_version": SCHEMA_VERSION,
        "generated_at": now_iso(),
        "limit_per_status": limit_per_status,
        "total_active_jobs": total_active,
        "status_counts": counts,
        "columns": columns,
        "local_only": True,
        "network_access": False,
        "telemetry": False,
    }


def format_pipeline_board(data: Dict[str, Any]) -> str:
    lines = [f"{APP_NAME} Pipeline Board", f"Active jobs: {data.get('total_active_jobs', 0)}", ""]
    columns = data.get("columns", {})
    counts = data.get("status_counts", {})
    for status in STATUSES:
        lines.append(f"[{status.upper()}] {counts.get(status, 0)}")
        rows = columns.get(status, [])
        if not rows:
            lines.append("  - no jobs")
        else:
            for r in rows:
                due = f" | due {r.get('due_date','')}" if r.get("due_date") else ""
                lines.append(f"  - {r.get('job_code','')} | fit {r.get('fit_score',0):>3} | P{r.get('priority',0)} | {r.get('company','')} | {r.get('title','')}{due}")
        lines.append("")
    return "\n".join(lines).rstrip()


def export_pipeline_json(conn: sqlite3.Connection, path: Optional[str] = None, limit_per_status: int = 50) -> Path:
    out = Path(path).expanduser() if path else export_dir() / f"sentinel_jobs_pipeline_board_{date.today().isoformat()}.json"
    secure_parent(out)
    data = pipeline_board_data(conn, limit_per_status=limit_per_status)
    out.write_text(json.dumps(data, indent=2), encoding="utf-8")
    harden_file(out)
    audit(conn, "export_pipeline_json", "file", out, str(out))
    conn.commit()
    return out


def save_view(conn: sqlite3.Connection, args: argparse.Namespace) -> str:
    name = (args.name or "").strip()
    if not name:
        raise ValueError("Saved view name is required")
    status = normalize_status(args.status) if getattr(args, "status", None) else ""
    job_type = normalize_job_type(args.job_type) if getattr(args, "job_type", None) else ""
    remote_mode = getattr(args, "remote_mode", "") or ""
    sort = getattr(args, "sort", "priority") or "priority"
    if sort not in SORT_OPTIONS:
        sort = "priority"
    priority_max = int(getattr(args, "priority_max", 0) or 0)
    fit_min = int(getattr(args, "fit_min", 0) or 0)
    due_days = int(getattr(args, "due_days", 0) or 0)
    include_archived = 1 if getattr(args, "include_archived", False) else 0
    limit = max(1, int(getattr(args, "limit", 50) or 50))
    ts = now_iso()
    conn.execute(
        """INSERT INTO saved_views(name,query,status,company,job_type,remote_mode,priority_max,fit_min,due_days,include_archived,sort,limit_count,created_at,updated_at)
             VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)
             ON CONFLICT(name) DO UPDATE SET
               query=excluded.query,status=excluded.status,company=excluded.company,job_type=excluded.job_type,remote_mode=excluded.remote_mode,
               priority_max=excluded.priority_max,fit_min=excluded.fit_min,due_days=excluded.due_days,include_archived=excluded.include_archived,
               sort=excluded.sort,limit_count=excluded.limit_count,updated_at=excluded.updated_at""",
        (name, getattr(args, "query", "") or "", status, getattr(args, "company", "") or "", job_type, remote_mode,
         priority_max, fit_min, due_days, include_archived, sort, limit, ts, ts),
    )
    audit(conn, "save_view", "saved_view", name, name)
    conn.commit()
    return f"Saved view: {name}"


def list_saved_views(conn: sqlite3.Connection) -> List[sqlite3.Row]:
    return conn.execute("SELECT * FROM saved_views ORDER BY name COLLATE NOCASE ASC").fetchall()


def format_saved_views(rows: Iterable[sqlite3.Row]) -> str:
    rows = list(rows)
    if not rows:
        return "No saved views found."
    lines = ["Name                 Status      Query/Company                 Filters"]
    lines.append("-" * 96)
    for r in rows:
        bits = []
        if r["job_type"]: bits.append(f"type={r['job_type']}")
        if r["remote_mode"]: bits.append(f"remote={r['remote_mode']}")
        if r["fit_min"]: bits.append(f"fit>={r['fit_min']}")
        if r["priority_max"]: bits.append(f"P<={r['priority_max']}")
        if r["due_days"]: bits.append(f"due<={r['due_days']}d")
        if r["include_archived"]: bits.append("archived")
        qc = " / ".join([x for x in [r["query"], r["company"]] if x])
        lines.append(f"{r['name'][:20]:<20} {r['status'][:10]:<10} {qc[:28]:<28} {', '.join(bits)}")
    return "\n".join(lines)


def saved_view_namespace(row: sqlite3.Row) -> argparse.Namespace:
    return argparse.Namespace(
        query=row["query"] or None,
        status=row["status"] or None,
        company=row["company"] or None,
        job_type=row["job_type"] or None,
        remote_mode=row["remote_mode"] or None,
        priority_max=row["priority_max"] or None,
        fit_min=row["fit_min"] or None,
        due_days=row["due_days"] or None,
        include_archived=bool(row["include_archived"]),
        sort=row["sort"] or "priority",
        limit=row["limit_count"] or 50,
    )


def run_saved_view(conn: sqlite3.Connection, name: str) -> List[sqlite3.Row]:
    row = conn.execute("SELECT * FROM saved_views WHERE name=? COLLATE NOCASE", (name,)).fetchone()
    if not row:
        raise SystemExit(f"Saved view not found: {name}")
    return list_jobs(conn, saved_view_namespace(row))


def delete_saved_view(conn: sqlite3.Connection, name: str) -> str:
    cur = conn.execute("DELETE FROM saved_views WHERE name=? COLLATE NOCASE", (name,))
    if cur.rowcount == 0:
        raise SystemExit(f"Saved view not found: {name}")
    audit(conn, "delete_view", "saved_view", name, name)
    conn.commit()
    return f"Deleted saved view: {name}"


def export_saved_views_json(conn: sqlite3.Connection, path: Optional[str] = None) -> Path:
    out = Path(path).expanduser() if path else export_dir() / f"sentinel_jobs_saved_views_{date.today().isoformat()}.json"
    secure_parent(out)
    data = {"app": APP_NAME, "version": VERSION, "schema_version": SCHEMA_VERSION, "exported_at": now_iso(), "saved_views": [dict(r) for r in list_saved_views(conn)]}
    out.write_text(json.dumps(data, indent=2), encoding="utf-8")
    harden_file(out)
    audit(conn, "export_saved_views_json", "file", out, str(out))
    conn.commit()
    return out


def normalize_contact_type(value: str) -> str:
    ctype = (value or "other").strip().lower().replace(" ", "_")
    return ctype if ctype in CONTACT_TYPES else "other"


def normalize_contact_event_type(value: str) -> str:
    etype = (value or "note").strip().lower().replace(" ", "_")
    return etype if etype in CONTACT_EVENT_TYPES else "other"


def resolve_company(conn: sqlite3.Connection, ident: str) -> sqlite3.Row:
    ident = (ident or "").strip()
    if not ident:
        raise ValueError("company name or id is required")
    row = None
    if ident.isdigit():
        row = conn.execute("SELECT * FROM companies WHERE id=?", (int(ident),)).fetchone()
    if row is None:
        row = conn.execute("SELECT * FROM companies WHERE lower(name)=lower(?)", (ident,)).fetchone()
    if row is None:
        row = conn.execute("SELECT * FROM companies WHERE name LIKE ? ORDER BY name LIMIT 1", (f"%{ident}%",)).fetchone()
    if row is None:
        raise ValueError(f"company not found: {ident}")
    return row


def get_or_create_company(conn: sqlite3.Connection, name: str) -> Optional[int]:
    name = (name or "").strip()
    if not name:
        return None
    row = conn.execute("SELECT id FROM companies WHERE lower(name)=lower(?)", (name,)).fetchone()
    if row:
        return int(row["id"])
    ts = now_iso()
    conn.execute("INSERT INTO companies(name,created_at,updated_at) VALUES(?,?,?)", (name, ts, ts))
    company_id = int(conn.execute("SELECT last_insert_rowid()").fetchone()[0])
    audit(conn, "auto_add_company", "company", company_id, name)
    return company_id


def resolve_contact(conn: sqlite3.Connection, ident: str) -> sqlite3.Row:
    ident = (ident or "").strip()
    if not ident:
        raise ValueError("contact name or id is required")
    row = None
    if ident.isdigit():
        row = conn.execute("SELECT * FROM contacts WHERE id=?", (int(ident),)).fetchone()
    if row is None:
        row = conn.execute("SELECT * FROM contacts WHERE lower(name)=lower(?)", (ident,)).fetchone()
    if row is None:
        row = conn.execute("SELECT * FROM contacts WHERE name LIKE ? ORDER BY name LIMIT 1", (f"%{ident}%",)).fetchone()
    if row is None:
        raise ValueError(f"contact not found: {ident}")
    return row


def company_add(conn: sqlite3.Connection, args: argparse.Namespace) -> str:
    name = (args.name or "").strip()
    if not name:
        raise ValueError("company name is required")
    ts = now_iso()
    existing = conn.execute("SELECT id FROM companies WHERE lower(name)=lower(?)", (name,)).fetchone()
    if existing:
        conn.execute(
            """UPDATE companies SET industry=?,website=?,phone=?,email=?,address=?,notes=?,follow_up_date=?,updated_at=? WHERE id=?""",
            (args.industry or "", args.website or "", args.phone or "", args.email or "", args.address or "", args.notes or "", args.follow_up or "", ts, existing["id"]),
        )
        audit(conn, "update_company", "company", existing["id"], name)
        conn.commit()
        return f"Updated company #{existing['id']}: {name}"
    conn.execute(
        """INSERT INTO companies(name,industry,website,phone,email,address,notes,follow_up_date,created_at,updated_at)
             VALUES(?,?,?,?,?,?,?,?,?,?)""",
        (name, args.industry or "", args.website or "", args.phone or "", args.email or "", args.address or "", args.notes or "", args.follow_up or "", ts, ts),
    )
    cid = int(conn.execute("SELECT last_insert_rowid()").fetchone()[0])
    audit(conn, "add_company", "company", cid, name)
    conn.commit()
    return f"Added company #{cid}: {name}"


def list_companies(conn: sqlite3.Connection, args: argparse.Namespace) -> List[sqlite3.Row]:
    clauses = []
    params: List[Any] = []
    q = getattr(args, "query", None)
    if q:
        clauses.append("(c.name LIKE ? OR c.industry LIKE ? OR c.website LIKE ? OR c.email LIKE ? OR c.notes LIKE ?)")
        qq = f"%{q}%"; params.extend([qq, qq, qq, qq, qq])
    due_days = getattr(args, "due_days", None)
    if due_days is not None:
        try:
            if int(due_days) >= 0:
                clauses.append("c.follow_up_date!='' AND date(c.follow_up_date) <= date('now', ?)")
                params.append(f"+{int(due_days)} day")
        except Exception:
            pass
    where = " WHERE " + " AND ".join(clauses) if clauses else ""
    limit = max(1, int(getattr(args, "limit", 100) or 100))
    params.append(limit)
    return conn.execute(
        f"""SELECT c.*, COUNT(DISTINCT j.id) AS job_count, COUNT(DISTINCT ct.id) AS contact_count
              FROM companies c
              LEFT JOIN jobs j ON lower(j.company)=lower(c.name)
              LEFT JOIN contacts ct ON ct.company_id=c.id
              {where}
              GROUP BY c.id
              ORDER BY c.name COLLATE NOCASE ASC LIMIT ?""",
        params,
    ).fetchall()


def format_companies(rows: Iterable[sqlite3.Row]) -> str:
    rows = list(rows)
    if not rows:
        return "No companies found."
    out = [f"{'ID':<4}  {'Company':<28}  {'Contacts':<8}  {'Jobs':<4}  {'Follow-up':<12}  Industry"]
    out.append("-" * 86)
    for r in rows:
        out.append(f"{r['id']:<4}  {(r['name'] or '')[:28]:<28}  {r['contact_count']:<8}  {r['job_count']:<4}  {(r['follow_up_date'] or ''):<12}  {(r['industry'] or '')[:24]}")
    return "\n".join(out)


def company_view(conn: sqlite3.Connection, ident: str) -> str:
    c = resolve_company(conn, ident)
    lines = [f"Company #{c['id']} — {c['name']}", f"Industry: {c['industry']}", f"Website: {c['website']}", f"Email: {c['email']}", f"Phone: {c['phone']}", f"Address: {c['address']}", f"Follow-up: {c['follow_up_date']}", "", "Notes:", c['notes'] or ""]
    contacts = conn.execute("SELECT * FROM contacts WHERE company_id=? ORDER BY name", (c['id'],)).fetchall()
    if contacts:
        lines.append("\nContacts:")
        for ct in contacts:
            lines.append(f"  #{ct['id']} {ct['name']} [{ct['contact_type']}] {ct['title']} <{ct['email']}> {ct['phone']}")
    jobs = conn.execute("SELECT job_code,title,status,fit_score,due_date FROM jobs WHERE lower(company)=lower(?) ORDER BY archived ASC, updated_at DESC LIMIT 20", (c['name'],)).fetchall()
    if jobs:
        lines.append("\nLinked jobs:")
        for j in jobs:
            lines.append(f"  {j['job_code']} [{j['status']}] fit {j['fit_score']} due {j['due_date']}: {j['title']}")
    return "\n".join(lines)


def contact_add(conn: sqlite3.Connection, args: argparse.Namespace) -> str:
    name = (args.name or "").strip()
    if not name:
        raise ValueError("contact name is required")
    company_id = get_or_create_company(conn, args.company or "")
    ts = now_iso()
    conn.execute(
        """INSERT INTO contacts(company_id,name,contact_type,title,email,phone,source,notes,follow_up_date,created_at,updated_at)
             VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
        (company_id, name, normalize_contact_type(args.type), args.title or "", args.email or "", args.phone or "", args.source or "", args.notes or "", args.follow_up or "", ts, ts),
    )
    contact_id = int(conn.execute("SELECT last_insert_rowid()").fetchone()[0])
    audit(conn, "add_contact", "contact", contact_id, name)
    conn.commit()
    return f"Added contact #{contact_id}: {name}"


def list_contacts(conn: sqlite3.Connection, args: argparse.Namespace) -> List[sqlite3.Row]:
    clauses = []
    params: List[Any] = []
    q = getattr(args, "query", None)
    if q:
        clauses.append("(ct.name LIKE ? OR ct.title LIKE ? OR ct.email LIKE ? OR ct.phone LIKE ? OR ct.notes LIKE ? OR c.name LIKE ?)")
        qq = f"%{q}%"; params.extend([qq, qq, qq, qq, qq, qq])
    company = getattr(args, "company", None)
    if company:
        clauses.append("c.name LIKE ?")
        params.append(f"%{company}%")
    ctype = getattr(args, "type", None)
    if ctype:
        clauses.append("ct.contact_type=?")
        params.append(normalize_contact_type(ctype))
    due_days = getattr(args, "due_days", None)
    if due_days is not None:
        try:
            if int(due_days) >= 0:
                clauses.append("ct.follow_up_date!='' AND date(ct.follow_up_date) <= date('now', ?)")
                params.append(f"+{int(due_days)} day")
        except Exception:
            pass
    where = " WHERE " + " AND ".join(clauses) if clauses else ""
    limit = max(1, int(getattr(args, "limit", 100) or 100))
    params.append(limit)
    return conn.execute(
        f"""SELECT ct.*, COALESCE(c.name,'') AS company_name
              FROM contacts ct LEFT JOIN companies c ON c.id=ct.company_id
              {where}
              ORDER BY ct.follow_up_date='' ASC, date(ct.follow_up_date) ASC, ct.name COLLATE NOCASE ASC LIMIT ?""",
        params,
    ).fetchall()


def format_contacts(rows: Iterable[sqlite3.Row]) -> str:
    rows = list(rows)
    if not rows:
        return "No contacts found."
    out = [f"{'ID':<4}  {'Name':<24}  {'Type':<14}  {'Company':<24}  {'Follow-up':<12}  Email/Phone"]
    out.append("-" * 104)
    for r in rows:
        contact = f"{r['email'] or ''} {r['phone'] or ''}".strip()
        out.append(f"{r['id']:<4}  {(r['name'] or '')[:24]:<24}  {r['contact_type']:<14}  {(r['company_name'] or '')[:24]:<24}  {(r['follow_up_date'] or ''):<12}  {contact}")
    return "\n".join(out)


def contact_log(conn: sqlite3.Connection, args: argparse.Namespace) -> str:
    contact = resolve_contact(conn, args.contact)
    company_id = contact["company_id"]
    job_id = None
    if args.job:
        job_id = resolve_job(conn, args.job)["id"]
    ts = now_iso()
    event_date = args.date or today_iso()
    next_follow = args.next_follow_up or ""
    conn.execute(
        """INSERT INTO contact_interactions(contact_id,company_id,job_id,event_type,event_date,summary,next_follow_up,created_at)
             VALUES(?,?,?,?,?,?,?,?)""",
        (contact["id"], company_id, job_id, normalize_contact_event_type(args.type), event_date, args.summary, next_follow, ts),
    )
    if next_follow:
        conn.execute("UPDATE contacts SET follow_up_date=?, updated_at=? WHERE id=?", (next_follow, ts, contact["id"]))
    audit(conn, "contact_log", "contact", contact["id"], args.summary)
    conn.commit()
    return f"Logged {args.type or 'note'} for contact #{contact['id']}: {contact['name']}"


def contact_history(conn: sqlite3.Connection, args: argparse.Namespace) -> List[sqlite3.Row]:
    clauses = []
    params: List[Any] = []
    if getattr(args, "contact", None):
        ct = resolve_contact(conn, args.contact)
        clauses.append("ci.contact_id=?")
        params.append(ct["id"])
    if getattr(args, "company", None):
        c = resolve_company(conn, args.company)
        clauses.append("ci.company_id=?")
        params.append(c["id"])
    where = " WHERE " + " AND ".join(clauses) if clauses else ""
    limit = max(1, int(getattr(args, "limit", 100) or 100))
    params.append(limit)
    return conn.execute(
        f"""SELECT ci.*, ct.name AS contact_name, COALESCE(c.name,'') AS company_name, COALESCE(j.job_code,'') AS job_code, COALESCE(j.title,'') AS job_title
              FROM contact_interactions ci
              LEFT JOIN contacts ct ON ct.id=ci.contact_id
              LEFT JOIN companies c ON c.id=ci.company_id
              LEFT JOIN jobs j ON j.id=ci.job_id
              {where}
              ORDER BY ci.event_date DESC, ci.created_at DESC LIMIT ?""",
        params,
    ).fetchall()


def format_contact_history(rows: Iterable[sqlite3.Row]) -> str:
    rows = list(rows)
    if not rows:
        return "No contact history found."
    out = [f"{'Date':<12}  {'Type':<10}  {'Contact':<22}  {'Company':<22}  {'Next':<12}  Summary"]
    out.append("-" * 112)
    for r in rows:
        out.append(f"{(r['event_date'] or ''):<12}  {r['event_type']:<10}  {(r['contact_name'] or '')[:22]:<22}  {(r['company_name'] or '')[:22]:<22}  {(r['next_follow_up'] or ''):<12}  {r['summary']}")
    return "\n".join(out)


def networking_due(conn: sqlite3.Connection, days: int = 14) -> Dict[str, Any]:
    days = max(0, int(days or 14))
    companies = conn.execute("SELECT * FROM companies WHERE follow_up_date!='' AND date(follow_up_date) <= date('now', ?) ORDER BY date(follow_up_date) ASC", (f"+{days} day",)).fetchall()
    contacts = conn.execute("""SELECT ct.*, COALESCE(c.name,'') AS company_name FROM contacts ct LEFT JOIN companies c ON c.id=ct.company_id
                              WHERE ct.follow_up_date!='' AND date(ct.follow_up_date) <= date('now', ?)
                              ORDER BY date(ct.follow_up_date) ASC""", (f"+{days} day",)).fetchall()
    interactions = conn.execute("""SELECT ci.*, ct.name AS contact_name, COALESCE(c.name,'') AS company_name FROM contact_interactions ci
                                   LEFT JOIN contacts ct ON ct.id=ci.contact_id LEFT JOIN companies c ON c.id=ci.company_id
                                   WHERE ci.next_follow_up!='' AND date(ci.next_follow_up) <= date('now', ?)
                                   ORDER BY date(ci.next_follow_up) ASC""", (f"+{days} day",)).fetchall()
    return {"days": days, "companies": [dict(r) for r in companies], "contacts": [dict(r) for r in contacts], "interactions": [dict(r) for r in interactions]}


def format_networking_due(data: Dict[str, Any]) -> str:
    lines = [f"Networking follow-ups due within {data['days']} days"]
    if not data["companies"] and not data["contacts"] and not data["interactions"]:
        return lines[0] + "\nNo networking follow-ups due."
    if data["companies"]:
        lines.append("\nCompanies:")
        for c in data["companies"]:
            lines.append(f"  {c['follow_up_date']} — {c['name']} {c.get('email','')}")
    if data["contacts"]:
        lines.append("\nContacts:")
        for ct in data["contacts"]:
            lines.append(f"  {ct['follow_up_date']} — {ct['name']} @ {ct.get('company_name','')} {ct.get('email','')}")
    if data["interactions"]:
        lines.append("\nInteraction follow-ups:")
        for ev in data["interactions"]:
            lines.append(f"  {ev['next_follow_up']} — {ev.get('contact_name','')} @ {ev.get('company_name','')}: {ev['summary']}")
    return "\n".join(lines)


def export_companies_csv(conn: sqlite3.Connection, path: Optional[str] = None) -> Path:
    out = Path(path).expanduser() if path else export_dir() / f"sentinel_jobs_companies_{date.today().isoformat()}.csv"
    secure_parent(out)
    rows = [dict(r) for r in list_companies(conn, argparse.Namespace(query=None, due_days=None, limit=100000))]
    with out.open("w", newline="", encoding="utf-8") as fh:
        fieldnames = ["id", "name", "industry", "website", "phone", "email", "address", "notes", "follow_up_date", "contact_count", "job_count", "created_at", "updated_at"]
        writer = csv.DictWriter(fh, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader(); csv_writerows_safe(writer, rows)
    harden_file(out)
    audit(conn, "export_companies_csv", "file", out, str(out)); conn.commit()
    return out


def export_companies_json(conn: sqlite3.Connection, path: Optional[str] = None) -> Path:
    out = Path(path).expanduser() if path else export_dir() / f"sentinel_jobs_companies_{date.today().isoformat()}.json"
    secure_parent(out)
    data = {"app": APP_NAME, "version": VERSION, "schema_version": SCHEMA_VERSION, "exported_at": now_iso(), "companies": [dict(r) for r in list_companies(conn, argparse.Namespace(query=None, due_days=None, limit=100000))]}
    out.write_text(json.dumps(data, indent=2), encoding="utf-8")
    harden_file(out)
    audit(conn, "export_companies_json", "file", out, str(out)); conn.commit()
    return out


def export_contacts_csv(conn: sqlite3.Connection, path: Optional[str] = None) -> Path:
    out = Path(path).expanduser() if path else export_dir() / f"sentinel_jobs_contacts_{date.today().isoformat()}.csv"
    secure_parent(out)
    rows = [dict(r) for r in list_contacts(conn, argparse.Namespace(query=None, company=None, type=None, due_days=None, limit=100000))]
    with out.open("w", newline="", encoding="utf-8") as fh:
        fieldnames = ["id", "name", "contact_type", "title", "company_name", "email", "phone", "source", "notes", "follow_up_date", "created_at", "updated_at"]
        writer = csv.DictWriter(fh, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader(); csv_writerows_safe(writer, rows)
    harden_file(out)
    audit(conn, "export_contacts_csv", "file", out, str(out)); conn.commit()
    return out


def export_contacts_json(conn: sqlite3.Connection, path: Optional[str] = None) -> Path:
    out = Path(path).expanduser() if path else export_dir() / f"sentinel_jobs_contacts_{date.today().isoformat()}.json"
    secure_parent(out)
    data = {"app": APP_NAME, "version": VERSION, "schema_version": SCHEMA_VERSION, "exported_at": now_iso(), "contacts": [dict(r) for r in list_contacts(conn, argparse.Namespace(query=None, company=None, type=None, due_days=None, limit=100000))], "history": [dict(r) for r in contact_history(conn, argparse.Namespace(contact=None, company=None, limit=100000))]}
    out.write_text(json.dumps(data, indent=2), encoding="utf-8")
    harden_file(out)
    audit(conn, "export_contacts_json", "file", out, str(out)); conn.commit()
    return out


def clamp_int(value: Any, low: int, high: int, default: int) -> int:
    try:
        n = int(value)
    except Exception:
        n = default
    return max(low, min(high, n))


def normalize_skill(skill: str) -> str:
    return " ".join((skill or "").strip().lower().replace("_", " ").split())


def split_skills(skills: str) -> List[str]:
    raw = (skills or "").replace(";", ",").replace("\n", ",").split(",")
    out: List[str] = []
    seen = set()
    for item in raw:
        skill = normalize_skill(item)
        if skill and skill not in seen:
            out.append(skill)
            seen.add(skill)
    return out


def set_profile_skills(conn: sqlite3.Connection, args: argparse.Namespace) -> str:
    skills = split_skills(args.skills)
    if not skills:
        raise ValueError("At least one profile skill is required")
    level = clamp_int(getattr(args, "level", 3), SKILL_LEVEL_MIN, SKILL_LEVEL_MAX, 3)
    notes = getattr(args, "notes", "") or ""
    ts = now_iso()
    for skill in skills:
        conn.execute(
            """INSERT INTO profile_skills(skill,level,notes,created_at,updated_at)
                 VALUES(?,?,?,?,?)
                 ON CONFLICT(skill) DO UPDATE SET level=excluded.level, notes=excluded.notes, updated_at=excluded.updated_at""",
            (skill, level, notes, ts, ts),
        )
    audit(conn, "set_profile_skills", "profile", "skills", ", ".join(skills))
    conn.commit()
    return f"Saved {len(skills)} profile skill(s) at level {level}."


def list_profile_skills(conn: sqlite3.Connection) -> List[sqlite3.Row]:
    return conn.execute("SELECT * FROM profile_skills ORDER BY skill COLLATE NOCASE ASC").fetchall()


def format_profile_skills(rows: Iterable[sqlite3.Row]) -> str:
    rows = list(rows)
    if not rows:
        return "No profile skills recorded yet."
    lines = ["Skill                          Level  Notes", "-" * 72]
    for r in rows:
        lines.append(f"{r['skill'][:30]:<30} {r['level']:<5}  {(r['notes'] or '')[:34]}")
    return "\n".join(lines)


def add_job_skills(conn: sqlite3.Connection, args: argparse.Namespace, commit: bool = True) -> str:
    job = resolve_job(conn, args.job)
    skills = split_skills(args.skills)
    if not skills:
        raise ValueError("At least one job skill is required")
    required_level = clamp_int(getattr(args, "required_level", 3), SKILL_LEVEL_MIN, SKILL_LEVEL_MAX, 3)
    importance = clamp_int(getattr(args, "importance", 3), 1, 5, 3)
    source = getattr(args, "source", "manual") or "manual"
    notes = getattr(args, "notes", "") or ""
    ts = now_iso()
    for skill in skills:
        conn.execute(
            """INSERT INTO job_skills(job_id,skill,required_level,importance,source,notes,created_at,updated_at)
                 VALUES(?,?,?,?,?,?,?,?)
                 ON CONFLICT(job_id, skill) DO UPDATE SET
                   required_level=excluded.required_level, importance=excluded.importance,
                   source=excluded.source, notes=excluded.notes, updated_at=excluded.updated_at""",
            (job["id"], skill, required_level, importance, source, notes, ts, ts),
        )
    audit(conn, "add_job_skills", "job", job["job_code"], ", ".join(skills))
    if commit:
        conn.commit()
    return f"Saved {len(skills)} required skill(s) for {job['job_code']}."


def list_job_skills(conn: sqlite3.Connection, ident: str) -> List[sqlite3.Row]:
    job = resolve_job(conn, ident)
    return conn.execute("SELECT * FROM job_skills WHERE job_id=? ORDER BY importance DESC, skill COLLATE NOCASE ASC", (job["id"],)).fetchall()


def format_job_skills(rows: Iterable[sqlite3.Row]) -> str:
    rows = list(rows)
    if not rows:
        return "No required skills recorded for this job."
    lines = ["Skill                          Required  Importance  Source", "-" * 78]
    for r in rows:
        lines.append(f"{r['skill'][:30]:<30} {r['required_level']:<8}  {r['importance']:<10}  {r['source']}")
    return "\n".join(lines)


def skill_match_data(conn: sqlite3.Connection, ident: str) -> Dict[str, Any]:
    job = resolve_job(conn, ident)
    required = conn.execute("SELECT * FROM job_skills WHERE job_id=? ORDER BY importance DESC, skill COLLATE NOCASE ASC", (job["id"],)).fetchall()
    profile_rows = conn.execute("SELECT skill, level, notes FROM profile_skills").fetchall()
    profile = {r["skill"]: int(r["level"] or 0) for r in profile_rows}
    rows: List[Dict[str, Any]] = []
    total_weight = 0.0
    scored = 0.0
    missing: List[str] = []
    partial: List[str] = []
    matched: List[str] = []
    for r in required:
        skill = r["skill"]
        req = clamp_int(r["required_level"], SKILL_LEVEL_MIN, SKILL_LEVEL_MAX, 3)
        importance = clamp_int(r["importance"], 1, 5, 3)
        have = profile.get(skill, 0)
        total_weight += importance
        ratio = 1.0 if req <= 0 else min(1.0, max(0.0, have / float(req)))
        scored += ratio * importance
        if have <= 0:
            status = "missing"; missing.append(skill)
        elif have < req:
            status = "partial"; partial.append(skill)
        else:
            status = "matched"; matched.append(skill)
        rows.append({
            "skill": skill,
            "required_level": req,
            "profile_level": have,
            "importance": importance,
            "status": status,
            "score_contribution": round(ratio * importance, 2),
            "source": r["source"],
            "notes": r["notes"],
        })
    match_percent = round((scored / total_weight) * 100, 1) if total_weight else 0.0
    return {
        "app": APP_NAME,
        "version": VERSION,
        "schema_version": SCHEMA_VERSION,
        "generated_at": now_iso(),
        "job": {"job_code": job["job_code"], "title": job["title"], "company": job["company"], "status": job["status"], "fit_score": job["fit_score"]},
        "required_skill_count": len(required),
        "profile_skill_count": len(profile_rows),
        "match_percent": match_percent,
        "matched": matched,
        "partial": partial,
        "missing": missing,
        "skills": rows,
        "local_only": True,
        "network_access": False,
        "telemetry": False,
    }


def format_skill_match(data: Dict[str, Any]) -> str:
    job = data["job"]
    lines = [f"Skill Match: {job['job_code']} — {job['title']}", f"Company/client: {job.get('company','')}", f"Match: {data['match_percent']}% | Required skills: {data['required_skill_count']} | Profile skills: {data['profile_skill_count']}", ""]
    if not data.get("skills"):
        lines.append("No required skills have been recorded for this job yet.")
        return "\n".join(lines)
    lines.append("Skill                          Need  Have  Imp  Status")
    lines.append("-" * 78)
    for r in data["skills"]:
        lines.append(f"{r['skill'][:30]:<30} {r['required_level']:<5} {r['profile_level']:<5} {r['importance']:<4} {r['status']}")
    if data.get("missing"):
        lines += ["", "Skill gaps:", "  " + ", ".join(data["missing"][:20])]
    if data.get("partial"):
        lines += ["", "Needs strengthening:", "  " + ", ".join(data["partial"][:20])]
    return "\n".join(lines)


def skill_gaps_data(conn: sqlite3.Connection, limit: int = 50) -> Dict[str, Any]:
    rows = conn.execute(
        """SELECT js.skill, COUNT(*) AS job_count, SUM(js.importance) AS total_importance
             FROM job_skills js JOIN jobs j ON j.id=js.job_id
             LEFT JOIN profile_skills ps ON ps.skill=js.skill
             WHERE j.archived=0 AND (ps.id IS NULL OR ps.level < js.required_level)
             GROUP BY js.skill
             ORDER BY total_importance DESC, job_count DESC, js.skill COLLATE NOCASE ASC
             LIMIT ?""",
        (max(1, int(limit or 50)),),
    ).fetchall()
    return {"app": APP_NAME, "version": VERSION, "generated_at": now_iso(), "gaps": [dict(r) for r in rows], "local_only": True}


def format_skill_gaps(data: Dict[str, Any]) -> str:
    rows = data.get("gaps", [])
    if not rows:
        return "No skill gaps found against active jobs."
    lines = ["Skill gap summary across active jobs", "Skill                          Jobs  Weight", "-" * 64]
    for r in rows:
        lines.append(f"{r['skill'][:30]:<30} {r['job_count']:<5} {r['total_importance']}")
    return "\n".join(lines)


def export_skill_match_json(conn: sqlite3.Connection, path: Optional[str] = None) -> Path:
    out = Path(path).expanduser() if path else export_dir() / f"sentinel_jobs_skill_match_{date.today().isoformat()}.json"
    secure_parent(out)
    jobs = conn.execute("SELECT job_code FROM jobs WHERE archived=0 ORDER BY priority ASC, fit_score DESC").fetchall()
    data = {"app": APP_NAME, "version": VERSION, "schema_version": SCHEMA_VERSION, "exported_at": now_iso(), "matches": [skill_match_data(conn, r["job_code"]) for r in jobs]}
    out.write_text(json.dumps(data, indent=2), encoding="utf-8")
    harden_file(out)
    audit(conn, "export_skill_match_json", "file", out, str(out)); conn.commit()
    return out


def export_skill_match_csv(conn: sqlite3.Connection, path: Optional[str] = None) -> Path:
    out = Path(path).expanduser() if path else export_dir() / f"sentinel_jobs_skill_match_{date.today().isoformat()}.csv"
    secure_parent(out)
    jobs = conn.execute("SELECT job_code FROM jobs WHERE archived=0 ORDER BY priority ASC, fit_score DESC").fetchall()
    with out.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["job_code", "title", "company", "match_percent", "skill", "required_level", "profile_level", "importance", "status"])
        writer.writeheader()
        for j in jobs:
            data = skill_match_data(conn, j["job_code"])
            job = data["job"]
            if not data["skills"]:
                csv_writerow_safe(writer, {"job_code": job["job_code"], "title": job["title"], "company": job["company"], "match_percent": data["match_percent"], "skill": "", "required_level": "", "profile_level": "", "importance": "", "status": "no_required_skills"})
            for r in data["skills"]:
                csv_writerow_safe(writer, {"job_code": job["job_code"], "title": job["title"], "company": job["company"], "match_percent": data["match_percent"], "skill": r["skill"], "required_level": r["required_level"], "profile_level": r["profile_level"], "importance": r["importance"], "status": r["status"]})
    harden_file(out)
    audit(conn, "export_skill_match_csv", "file", out, str(out)); conn.commit()
    return out


def export_profile_skills_json(conn: sqlite3.Connection, path: Optional[str] = None) -> Path:
    out = Path(path).expanduser() if path else export_dir() / f"sentinel_jobs_profile_skills_{date.today().isoformat()}.json"
    secure_parent(out)
    data = {"app": APP_NAME, "version": VERSION, "schema_version": SCHEMA_VERSION, "exported_at": now_iso(), "profile_skills": [dict(r) for r in list_profile_skills(conn)]}
    out.write_text(json.dumps(data, indent=2), encoding="utf-8")
    harden_file(out)
    audit(conn, "export_profile_skills_json", "file", out, str(out)); conn.commit()
    return out

def dashboard_data(conn: sqlite3.Connection) -> Dict[str, Any]:
    counts = {row["status"]: row["count"] for row in conn.execute("SELECT status, COUNT(*) AS count FROM jobs WHERE archived=0 GROUP BY status")}
    total_active = conn.execute("SELECT COUNT(*) FROM jobs WHERE archived=0").fetchone()[0]
    archived = conn.execute("SELECT COUNT(*) FROM jobs WHERE archived=1").fetchone()[0]
    due_soon = conn.execute(
        "SELECT COUNT(*) FROM jobs WHERE archived=0 AND due_date!='' AND date(due_date) BETWEEN date('now') AND date('now','+14 day')"
    ).fetchone()[0]
    overdue_actions = conn.execute(
        "SELECT COUNT(*) FROM actions WHERE status!='done' AND due_date!='' AND date(due_date) < date('now')"
    ).fetchone()[0]
    due_actions = conn.execute(
        "SELECT COUNT(*) FROM actions WHERE status!='done' AND due_date!='' AND date(due_date) BETWEEN date('now') AND date('now','+14 day')"
    ).fetchone()[0]
    interviews = conn.execute(
        """SELECT COUNT(*) FROM interviews WHERE status NOT IN ('done','cancelled')
              AND scheduled_date!='' AND date(scheduled_date) >= date('now')"""
    ).fetchone()[0]
    next_interviews = conn.execute(
        """SELECT i.id,i.interview_type,i.scheduled_date,i.scheduled_time,i.mode,i.location,i.interviewer,i.status,
                  j.job_code,j.title,j.company,j.fit_score,j.priority
           FROM interviews i JOIN jobs j ON j.id=i.job_id
           WHERE i.status NOT IN ('done','cancelled') AND i.scheduled_date!='' AND date(i.scheduled_date) >= date('now')
           ORDER BY date(i.scheduled_date) ASC, i.scheduled_time ASC LIMIT 6"""
    ).fetchall()
    top = conn.execute(
        "SELECT job_code,title,company,fit_score,priority,status FROM jobs WHERE archived=0 ORDER BY fit_score DESC, priority ASC LIMIT 5"
    ).fetchall()
    closest_due_jobs = conn.execute(
        """SELECT job_code,title,company,status,due_date,fit_score,priority
           FROM jobs
           WHERE archived=0 AND due_date!='' AND date(due_date) >= date('now')
           ORDER BY date(due_date) ASC, priority ASC LIMIT 8"""
    ).fetchall()
    upcoming_actions = conn.execute(
        """SELECT a.id,a.action_type,a.description,a.due_date,a.status,j.job_code,j.title,j.company
           FROM actions a JOIN jobs j ON j.id=a.job_id
           WHERE a.status!='done' AND a.due_date!='' AND date(a.due_date) >= date('now')
           ORDER BY date(a.due_date) ASC, a.created_at DESC LIMIT 8"""
    ).fetchall()
    recent_jobs = conn.execute(
        """SELECT job_code,title,company,status,fit_score,priority,created_at
           FROM jobs WHERE archived=0
           ORDER BY datetime(created_at) DESC LIMIT 6"""
    ).fetchall()
    return {
        "app": APP_NAME,
        "version": VERSION,
        "schema_version": SCHEMA_VERSION,
        "database": str(default_db_path()),
        "total_active_jobs": total_active,
        "archived_jobs": archived,
        "status_counts": counts,
        "jobs_due_next_14_days": due_soon,
        "actions_due_next_14_days": due_actions,
        "overdue_actions": overdue_actions,
        "upcoming_interviews": interviews,
        "next_interviews": [dict(r) for r in next_interviews],
        "top_fit_jobs": [dict(r) for r in top],
        "closest_due_jobs": [dict(r) for r in closest_due_jobs],
        "upcoming_actions": [dict(r) for r in upcoming_actions],
        "recent_jobs": [dict(r) for r in recent_jobs],
        "saved_views_count": conn.execute("SELECT COUNT(*) FROM saved_views").fetchone()[0],
        "company_count": conn.execute("SELECT COUNT(*) FROM companies").fetchone()[0],
        "contact_count": conn.execute("SELECT COUNT(*) FROM contacts").fetchone()[0],
        "networking_due_next_14_days": len(networking_due(conn, 14)["contacts"]) + len(networking_due(conn, 14)["companies"]) + len(networking_due(conn, 14)["interactions"]),
        "profile_skill_count": conn.execute("SELECT COUNT(*) FROM profile_skills").fetchone()[0],
        "job_skill_count": conn.execute("SELECT COUNT(*) FROM job_skills").fetchone()[0],
        "jobs_with_skill_requirements": conn.execute("SELECT COUNT(DISTINCT job_id) FROM job_skills").fetchone()[0],
        "open_skill_gap_count": len(skill_gaps_data(conn, 100000)["gaps"]),
        "local_only": True,
        "network_access": False,
        "telemetry": False,
    }


def format_dashboard(data: Dict[str, Any]) -> str:
    lines = [f"{APP_NAME} v{VERSION}", f"Database: {data['database']}", "", "Dashboard"]
    lines.append(f"  Active jobs: {data['total_active_jobs']}")
    lines.append(f"  Archived jobs: {data['archived_jobs']}")
    lines.append(f"  Jobs due next 14 days: {data['jobs_due_next_14_days']}")
    lines.append(f"  Actions due next 14 days: {data['actions_due_next_14_days']}")
    lines.append(f"  Overdue actions: {data['overdue_actions']}")
    lines.append(f"  Upcoming interviews: {data['upcoming_interviews']}")
    lines.append(f"  Companies tracked: {data.get('company_count', 0)}")
    lines.append(f"  Contacts tracked: {data.get('contact_count', 0)}")
    lines.append(f"  Networking due next 14 days: {data.get('networking_due_next_14_days', 0)}")
    lines.append(f"  Profile skills: {data.get('profile_skill_count', 0)}")
    lines.append(f"  Job skill requirements: {data.get('job_skill_count', 0)}")
    lines.append(f"  Open skill gaps: {data.get('open_skill_gap_count', 0)}")
    lines.append("  Status counts:")
    for status in STATUSES:
        lines.append(f"    {status}: {data['status_counts'].get(status, 0)}")
    if data["top_fit_jobs"]:
        lines.append("\nTop fit jobs:")
        for r in data["top_fit_jobs"]:
            lines.append(f"  {r['job_code']} | fit {r['fit_score']} | P{r['priority']} | {r['company']} | {r['title']} [{r['status']}]")
    return "\n".join(lines)


def view_job(conn: sqlite3.Connection, ident: str) -> str:
    j = resolve_job(conn, ident)
    lines = [f"{j['job_code']} — {j['title']}", f"Company: {j['company']}", f"Status: {j['status']}", f"Type: {j['job_type']}"]
    lines += [f"Location: {j['location']}", f"Remote: {j['remote_mode']}", f"Source: {j['source']} {j['source_url']}"]
    lines += [f"Salary: {j['currency']} {j['salary_min']} - {j['salary_max']}", f"Priority: {j['priority']}", f"Fit score: {j['fit_score']}"]
    lines += [f"Applied: {j['applied_date']}", f"Due: {j['due_date']}", f"Contact: {j['contact_name']} <{j['contact_email']}>"]
    lines += [f"Created: {j['created_at']}", f"Updated: {j['updated_at']}", "", "Notes:", j['notes'] or ""]
    actions = conn.execute("SELECT * FROM actions WHERE job_id=? ORDER BY status ASC, due_date ASC, created_at DESC", (j["id"],)).fetchall()
    if actions:
        lines.append("\nActions:")
        for a in actions:
            lines.append(f"  #{a['id']} {a['status']} {a['action_type']} due {a['due_date']}: {a['description']}")
    docs = conn.execute("SELECT * FROM documents WHERE job_id=? ORDER BY created_at DESC", (j["id"],)).fetchall()
    if docs:
        lines.append("\nDocuments:")
        for d in docs:
            lines.append(f"  #{d['id']} {d['document_type']}: {d['path']} {d['notes']}")
    return "\n".join(lines)


def update_status(conn: sqlite3.Connection, ident: str, status: str, applied_date: str = "") -> str:
    j = resolve_job(conn, ident)
    status = normalize_status(status)
    applied = applied_date
    if status == "applied" and not applied:
        applied = today_iso()
    if applied:
        conn.execute("UPDATE jobs SET status=?, applied_date=?, updated_at=? WHERE id=?", (status, applied, now_iso(), j["id"]))
    else:
        conn.execute("UPDATE jobs SET status=?, updated_at=? WHERE id=?", (status, now_iso(), j["id"]))
    audit(conn, "update_status", "job", j["id"], f"{j['job_code']} -> {status}")
    conn.commit()
    return f"Updated {j['job_code']} to {status}"


def archive_job(conn: sqlite3.Connection, ident: str, archived: int) -> str:
    j = resolve_job(conn, ident)
    conn.execute("UPDATE jobs SET archived=?, updated_at=? WHERE id=?", (archived, now_iso(), j["id"]))
    audit(conn, "archive" if archived else "unarchive", "job", j["id"], j["job_code"])
    conn.commit()
    return f"{'Archived' if archived else 'Unarchived'} {j['job_code']}"


def add_action(conn: sqlite3.Connection, args: argparse.Namespace) -> str:
    j = resolve_job(conn, args.job)
    ts = now_iso()
    action_type = (args.type or "other").strip().lower().replace(" ", "_")
    if action_type not in ACTION_TYPES:
        action_type = "other"
    conn.execute(
        """INSERT INTO actions(job_id,action_type,description,due_date,status,notes,created_at,updated_at)
             VALUES(?,?,?,?,?,?,?,?)""",
        (j["id"], action_type, args.description, args.due_date or "", "open", args.notes or "", ts, ts),
    )
    action_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    audit(conn, "add_action", "action", action_id, f"{j['job_code']} {args.description}")
    conn.commit()
    return f"Added action #{action_id} for {j['job_code']}"


def list_actions(conn: sqlite3.Connection, args: argparse.Namespace) -> List[sqlite3.Row]:
    clauses = []
    params: List[Any] = []
    if not args.all:
        clauses.append("a.status!='done'")
    if args.job:
        j = resolve_job(conn, args.job)
        clauses.append("a.job_id=?")
        params.append(j["id"])
    if args.type:
        clauses.append("a.action_type=?")
        params.append(args.type)
    if args.due_days is not None:
        clauses.append("a.due_date!='' AND date(a.due_date) <= date('now', ?)")
        params.append(f"+{args.due_days} day")
    where = " WHERE " + " AND ".join(clauses) if clauses else ""
    params.append(max(1, args.limit))
    return conn.execute(
        f"""SELECT a.*, j.job_code, j.title, j.company FROM actions a JOIN jobs j ON j.id=a.job_id
             {where} ORDER BY a.status ASC, a.due_date='' ASC, a.due_date ASC, a.created_at DESC LIMIT ?""",
        params,
    ).fetchall()


def format_actions(rows: Iterable[sqlite3.Row]) -> str:
    rows = list(rows)
    if not rows:
        return "No actions found."
    lines = ["ID   Status   Due         Type        Job        Company                 Description"]
    lines.append("-" * 96)
    for a in rows:
        lines.append(f"{a['id']:<4} {a['status']:<8} {a['due_date']:<11} {a['action_type']:<11} {a['job_code']:<10} {(a['company'] or '')[:22]:<22} {a['description']}")
    return "\n".join(lines)



def schedule_interview(conn: sqlite3.Connection, args: argparse.Namespace) -> str:
    j = resolve_job(conn, args.job)
    ts = now_iso()
    interview_type = (getattr(args, "type", "interview") or "interview").strip().lower().replace(" ", "_")
    mode = (getattr(args, "mode", "") or "").strip().lower().replace(" ", "_")
    conn.execute(
        """INSERT INTO interviews(job_id,interview_type,scheduled_date,scheduled_time,mode,location,interviewer,status,prep_notes,questions,outcome_notes,created_at,updated_at)
             VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (
            j["id"],
            interview_type,
            getattr(args, "date", "") or "",
            getattr(args, "time", "") or "",
            mode,
            getattr(args, "location", "") or "",
            getattr(args, "interviewer", "") or "",
            getattr(args, "status", "scheduled") or "scheduled",
            getattr(args, "prep_notes", "") or "",
            getattr(args, "questions", "") or "",
            "",
            ts,
            ts,
        ),
    )
    interview_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    if getattr(args, "create_action", True) and getattr(args, "date", ""):
        desc_bits = ["Interview"]
        if getattr(args, "type", ""):
            desc_bits.append(f"({interview_type.replace('_',' ')})")
        if getattr(args, "time", ""):
            desc_bits.append(f"at {getattr(args, 'time')}")
        if getattr(args, "interviewer", ""):
            desc_bits.append(f"with {getattr(args, 'interviewer')}")
        conn.execute(
            """INSERT INTO actions(job_id, action_type, description, due_date, status, notes, created_at, updated_at)
                 VALUES(?,?,?,?,?,?,?,?)""",
            (j["id"], "interview", " ".join(desc_bits), getattr(args, "date"), "open", "auto-created from interview schedule", ts, ts),
        )
    audit(conn, "schedule_interview", "interview", interview_id, f"{j['job_code']} {getattr(args, 'date', '')} {getattr(args, 'time', '')}")
    conn.commit()
    return f"Scheduled interview #{interview_id} for {j['job_code']}"


def list_interviews(conn: sqlite3.Connection, args: argparse.Namespace) -> List[sqlite3.Row]:
    clauses = []
    params: List[Any] = []
    if not getattr(args, "all", False):
        clauses.append("i.status NOT IN ('done','cancelled')")
    if getattr(args, "job", None):
        j = resolve_job(conn, args.job)
        clauses.append("i.job_id=?")
        params.append(j["id"])
    if getattr(args, "upcoming", False):
        clauses.append("i.scheduled_date!='' AND date(i.scheduled_date) >= date('now')")
    where = " WHERE " + " AND ".join(clauses) if clauses else ""
    params.append(max(1, int(getattr(args, "limit", 50) or 50)))
    return conn.execute(
        f"""SELECT i.*, j.job_code, j.title, j.company, j.status AS job_status, j.fit_score, j.priority
              FROM interviews i JOIN jobs j ON j.id=i.job_id
              {where}
              ORDER BY i.scheduled_date='' ASC, date(i.scheduled_date) ASC, i.scheduled_time ASC, i.created_at DESC
              LIMIT ?""",
        params,
    ).fetchall()


def format_interviews(rows: Iterable[sqlite3.Row]) -> str:
    rows = list(rows)
    if not rows:
        return "No interviews found."
    lines = ["ID   Date        Time   Type            Mode        Job        Company                 Interviewer / Location"]
    lines.append("-" * 112)
    for r in rows:
        where = r["interviewer"] or r["location"] or ""
        if r["interviewer"] and r["location"]:
            where = f"{r['interviewer']} @ {r['location']}"
        lines.append(f"{r['id']:<4} {r['scheduled_date']:<11} {r['scheduled_time']:<6} {r['interview_type']:<15} {r['mode']:<11} {r['job_code']:<10} {(r['company'] or '')[:22]:<22} {where}")
    return "\n".join(lines)


def interview_prep_data(conn: sqlite3.Connection, ident: str) -> Dict[str, Any]:
    j = resolve_job(conn, ident)
    interviews = conn.execute(
        """SELECT * FROM interviews WHERE job_id=?
              ORDER BY scheduled_date='' ASC, date(scheduled_date) ASC, scheduled_time ASC, created_at DESC""",
        (j["id"],),
    ).fetchall()
    actions = conn.execute(
        """SELECT * FROM actions WHERE job_id=? AND status!='done'
              ORDER BY due_date='' ASC, date(due_date) ASC, created_at DESC""",
        (j["id"],),
    ).fetchall()
    docs = document_check_data(conn, ident)
    suggested_questions = [
        "Can you describe the day-to-day work for this role?",
        "What would success look like in the first 30, 60, and 90 days?",
        "What tools, systems, or environments would I be expected to work with?",
        "How is training, mentoring, or onboarding handled?",
        "What are the next steps after this interview?",
    ]
    checklist = [
        "Review the job description and company/client notes.",
        "Prepare a short introduction and two practical examples of relevant work.",
        "Check resume, cover letter, certificates, licences, and references.",
        "Confirm time, location/link, interviewer name, and travel/setup requirements.",
        "Prepare follow-up action for after the interview.",
    ]
    return {
        "app": APP_NAME,
        "version": VERSION,
        "schema_version": SCHEMA_VERSION,
        "generated_at": now_iso(),
        "job": dict(j),
        "interviews": [dict(r) for r in interviews],
        "open_actions": [dict(r) for r in actions],
        "document_check": docs,
        "suggested_questions": suggested_questions,
        "prep_checklist": checklist,
        "local_only": True,
        "network_access": False,
        "telemetry": False,
    }


def format_interview_prep(data: Dict[str, Any]) -> str:
    j = data["job"]
    lines = [f"Interview Prep: {j['job_code']} — {j['title']}", f"Company/client: {j.get('company','')}", f"Status: {j.get('status','')} | Fit: {j.get('fit_score',0)} | Priority: {j.get('priority',0)}", ""]
    if data["interviews"]:
        lines.append("Scheduled interviews:")
        for i in data["interviews"]:
            lines.append(f"  #{i['id']} {i.get('scheduled_date','')} {i.get('scheduled_time','')} {i.get('interview_type','interview')} {i.get('mode','')} {i.get('interviewer','')} {i.get('location','')}")
            if i.get("prep_notes"):
                lines.append(f"     Prep notes: {i['prep_notes']}")
            if i.get("questions"):
                lines.append(f"     Questions: {i['questions']}")
    else:
        lines.append("Scheduled interviews: none recorded yet.")
    lines.append("\nDocument readiness:")
    lines.append(f"  Ready for pack: {data['document_check']['ready_for_application_pack']}")
    missing = data['document_check'].get('missing_required_types', [])
    if missing:
        lines.append(f"  Missing required: {', '.join(missing)}")
    else:
        lines.append("  Required documents present.")
    if data["open_actions"]:
        lines.append("\nOpen actions:")
        for a in data["open_actions"][:10]:
            lines.append(f"  #{a['id']} {a['due_date']} {a['action_type']}: {a['description']}")
    lines.append("\nPrep checklist:")
    for item in data["prep_checklist"]:
        lines.append(f"  [ ] {item}")
    lines.append("\nGood questions to ask:")
    for q in data["suggested_questions"]:
        lines.append(f"  - {q}")
    return "\n".join(lines)


def export_interviews_csv(conn: sqlite3.Connection, path: Optional[str] = None) -> Path:
    out = Path(path).expanduser() if path else export_dir() / f"sentinel_jobs_interviews_{date.today().isoformat()}.csv"
    secure_parent(out)
    rows = list_interviews(conn, argparse.Namespace(all=True, job=None, upcoming=False, limit=100000))
    fields = ["id", "job_code", "title", "company", "interview_type", "scheduled_date", "scheduled_time", "mode", "location", "interviewer", "status", "prep_notes", "questions", "outcome_notes", "created_at", "updated_at"]
    with out.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for r in rows:
            csv_writerow_safe(writer, {k: r[k] for k in fields if k in r.keys()})
    harden_file(out)
    audit(conn, "export_interviews_csv", "file", out, str(out))
    conn.commit()
    return out


def export_interviews_json(conn: sqlite3.Connection, path: Optional[str] = None) -> Path:
    out = Path(path).expanduser() if path else export_dir() / f"sentinel_jobs_interviews_{date.today().isoformat()}.json"
    secure_parent(out)
    rows = list_interviews(conn, argparse.Namespace(all=True, job=None, upcoming=False, limit=100000))
    data = {"app": APP_NAME, "version": VERSION, "schema_version": SCHEMA_VERSION, "exported_at": now_iso(), "interviews": [dict(r) for r in rows]}
    out.write_text(json.dumps(data, indent=2), encoding="utf-8")
    harden_file(out)
    audit(conn, "export_interviews_json", "file", out, str(out))
    conn.commit()
    return out


def export_interview_pack(conn: sqlite3.Connection, ident: str, output: Optional[str] = None) -> Path:
    data = interview_prep_data(conn, ident)
    j = data["job"]
    base = Path(output).expanduser() if output else export_dir() / f"sentinel_jobs_interview_pack_{j['job_code']}_{date.today().isoformat()}"
    ensure_private_dir(base)
    (base / "interview_prep.json").write_text(json.dumps(data, indent=2), encoding="utf-8")
    (base / "README.txt").write_text(format_interview_prep(data) + "\n\nGenerated locally by Sentinel Jobs. No network or telemetry used.\n", encoding="utf-8")
    audit(conn, "export_interview_pack", "job", j["id"], str(base))
    conn.commit()
    return base

def complete_action(conn: sqlite3.Connection, action_id: int, notes: str = "") -> str:
    row = conn.execute("SELECT * FROM actions WHERE id=?", (action_id,)).fetchone()
    if not row:
        raise SystemExit(f"Action not found: {action_id}")
    conn.execute("UPDATE actions SET status='done', completed_at=?, notes=CASE WHEN ?!='' THEN ? ELSE notes END, updated_at=? WHERE id=?", (now_iso(), notes, notes, now_iso(), action_id))
    audit(conn, "complete_action", "action", action_id, notes)
    conn.commit()
    return f"Completed action #{action_id}"


def add_document(conn: sqlite3.Connection, args: argparse.Namespace) -> str:
    j = resolve_job(conn, args.job)
    path = str(Path(args.path).expanduser())
    conn.execute(
        "INSERT INTO documents(job_id,path,document_type,notes,created_at) VALUES(?,?,?,?,?)",
        (j["id"], path, args.type or "other", args.notes or "", now_iso()),
    )
    doc_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    audit(conn, "add_document", "document", doc_id, f"{j['job_code']} {path}")
    conn.commit()
    return f"Added document #{doc_id} for {j['job_code']}"



def list_documents(conn: sqlite3.Connection, args: argparse.Namespace) -> List[sqlite3.Row]:
    clauses = []
    params: List[Any] = []
    if getattr(args, "job", None):
        j = resolve_job(conn, args.job)
        clauses.append("d.job_id=?")
        params.append(j["id"])
    if getattr(args, "type", None):
        clauses.append("d.document_type=?")
        params.append(args.type)
    where = " WHERE " + " AND ".join(clauses) if clauses else ""
    limit = max(1, int(getattr(args, "limit", 100) or 100))
    params.append(limit)
    return conn.execute(
        f"""SELECT d.*, j.job_code, j.title, j.company
              FROM documents d JOIN jobs j ON j.id=d.job_id
              {where} ORDER BY d.created_at DESC LIMIT ?""",
        params,
    ).fetchall()


def format_documents(rows: Iterable[sqlite3.Row]) -> str:
    rows = list(rows)
    if not rows:
        return "No documents found."
    lines = ["ID   Job        Type                 Exists  Path"]
    lines.append("-" * 92)
    for d in rows:
        exists = "yes" if Path(d["path"]).expanduser().exists() else "no"
        lines.append(f"{d['id']:<4} {d['job_code']:<10} {d['document_type']:<20} {exists:<6} {d['path']}")
    return "\n".join(lines)


def required_doc_types(conn: sqlite3.Connection) -> List[str]:
    raw = get_meta(conn, "required_application_docs", ",".join(REQUIRED_APPLICATION_DOC_TYPES))
    values = [x.strip().lower().replace(" ", "_") for x in raw.split(",") if x.strip()]
    return values or list(REQUIRED_APPLICATION_DOC_TYPES)


def set_required_docs(conn: sqlite3.Connection, raw: str) -> str:
    values = []
    for part in raw.replace(";", ",").split(","):
        value = part.strip().lower().replace(" ", "_")
        if value:
            values.append(value)
    if not values:
        values = list(REQUIRED_APPLICATION_DOC_TYPES)
    set_meta(conn, "required_application_docs", ",".join(values))
    return "Required application documents set to: " + ", ".join(values)


def document_check_data(conn: sqlite3.Connection, ident: str) -> Dict[str, Any]:
    j = resolve_job(conn, ident)
    docs = conn.execute("SELECT * FROM documents WHERE job_id=? ORDER BY created_at DESC", (j["id"],)).fetchall()
    by_type: Dict[str, List[Dict[str, Any]]] = {}
    missing_files: List[Dict[str, Any]] = []
    for d in docs:
        item = dict(d)
        item["exists"] = Path(d["path"]).expanduser().exists()
        by_type.setdefault(d["document_type"], []).append(item)
        if not item["exists"]:
            missing_files.append(item)
    required = required_doc_types(conn)
    missing_required = [doc_type for doc_type in required if not by_type.get(doc_type)]
    present_required = [doc_type for doc_type in required if by_type.get(doc_type)]
    return {
        "app": APP_NAME,
        "version": VERSION,
        "job": {"id": j["id"], "job_code": j["job_code"], "title": j["title"], "company": j["company"], "status": j["status"]},
        "required_document_types": required,
        "present_required_types": present_required,
        "missing_required_types": missing_required,
        "document_count": len(docs),
        "missing_file_count": len(missing_files),
        "documents": [{**dict(d), "exists": Path(d["path"]).expanduser().exists()} for d in docs],
        "ready_for_application_pack": not missing_required,
    }


def format_document_check(data: Dict[str, Any]) -> str:
    j = data["job"]
    lines = [f"Document check: {j['job_code']} — {j['title']}", f"Company: {j.get('company','')}", f"Ready for application pack: {data['ready_for_application_pack']}", ""]
    lines.append("Required documents:")
    for doc_type in data["required_document_types"]:
        status = "present" if doc_type in data["present_required_types"] else "missing"
        lines.append(f"  {doc_type}: {status}")
    if data["documents"]:
        lines.append("\nAttached documents:")
        for d in data["documents"]:
            exists = "exists" if d["exists"] else "missing file"
            lines.append(f"  #{d['id']} {d['document_type']}: {d['path']} [{exists}]")
    else:
        lines.append("\nNo documents attached yet.")
    if data["missing_file_count"]:
        lines.append(f"\nWarning: {data['missing_file_count']} attached document path(s) do not currently exist on disk.")
    return "\n".join(lines)


def safe_name(text: str) -> str:
    allowed = []
    for ch in text:
        if ch.isalnum() or ch in ("-", "_", "."):
            allowed.append(ch)
        elif ch.isspace():
            allowed.append("_")
    value = "".join(allowed).strip("._-")
    return value or "untitled"


def export_application_pack(conn: sqlite3.Connection, ident: str, output: Optional[str] = None, copy_files: bool = True) -> Path:
    data = document_check_data(conn, ident)
    j = data["job"]
    base = Path(output).expanduser() if output else export_dir() / f"sentinel_jobs_application_pack_{j['job_code']}_{date.today().isoformat()}"
    ensure_private_dir(base)
    docs_dir = base / "documents"
    ensure_private_dir(docs_dir)
    copied: List[Dict[str, Any]] = []
    missing: List[Dict[str, Any]] = []
    for d in data["documents"]:
        src = Path(d["path"]).expanduser()
        entry = dict(d)
        if copy_files and src.exists() and src.is_file():
            dest = docs_dir / f"{d['document_type']}_{safe_name(src.name)}"
            try:
                shutil.copy2(src, dest)
                harden_file(dest)
                entry["copied_to"] = str(dest)
                copied.append(entry)
            except Exception as e:
                entry["copy_error"] = str(e)
                missing.append(entry)
        else:
            missing.append(entry)
    manifest = {
        "app": APP_NAME,
        "version": VERSION,
        "schema_version": SCHEMA_VERSION,
        "exported_at": now_iso(),
        "application_pack_version": "0.4.0",
        "job": j,
        "document_check": data,
        "copied_documents": copied,
        "missing_or_uncopied_documents": missing,
        "local_only": True,
        "network_access": False,
        "telemetry": False,
    }
    (base / "application_pack_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    summary = [
        f"{APP_NAME} Application Pack",
        f"Job: {j['job_code']} — {j['title']}",
        f"Company: {j.get('company','')}",
        f"Status: {j.get('status','')}",
        f"Exported: {manifest['exported_at']}",
        "",
        "Document readiness:",
        f"  Ready: {data['ready_for_application_pack']}",
        f"  Required: {', '.join(data['required_document_types'])}",
        f"  Missing required: {', '.join(data['missing_required_types']) or 'none'}",
        f"  Copied documents: {len(copied)}",
        f"  Missing/uncopied: {len(missing)}",
        "",
        "This pack was generated locally by Sentinel Jobs. No network or telemetry used.",
    ]
    (base / "README.txt").write_text("\n".join(summary), encoding="utf-8")
    for item in base.rglob("*"):
        if item.is_file():
            harden_file(item)
    audit(conn, "export_application_pack", "job", j["id"], str(base))
    conn.commit()
    return base


def export_documents_csv(conn: sqlite3.Connection, path: Optional[str] = None) -> Path:
    out = Path(path).expanduser() if path else export_dir() / f"sentinel_jobs_documents_{date.today().isoformat()}.csv"
    secure_parent(out)
    fields = ["id", "job_code", "title", "company", "document_type", "path", "exists", "notes", "created_at"]
    rows = list_documents(conn, argparse.Namespace(job=None, type=None, limit=100000))
    with out.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for d in rows:
            csv_writerow_safe(writer, {
                "id": d["id"], "job_code": d["job_code"], "title": d["title"], "company": d["company"],
                "document_type": d["document_type"], "path": d["path"], "exists": Path(d["path"]).expanduser().exists(),
                "notes": d["notes"], "created_at": d["created_at"],
            })
    harden_file(out)
    audit(conn, "export_documents_csv", "file", out, str(out))
    conn.commit()
    return out


def export_documents_json(conn: sqlite3.Connection, path: Optional[str] = None) -> Path:
    out = Path(path).expanduser() if path else export_dir() / f"sentinel_jobs_documents_{date.today().isoformat()}.json"
    secure_parent(out)
    rows = list_documents(conn, argparse.Namespace(job=None, type=None, limit=100000))
    data = {
        "app": APP_NAME,
        "version": VERSION,
        "exported_at": now_iso(),
        "documents": [{**dict(d), "exists": Path(d["path"]).expanduser().exists()} for d in rows],
    }
    out.write_text(json.dumps(data, indent=2), encoding="utf-8")
    harden_file(out)
    audit(conn, "export_documents_json", "file", out, str(out))
    conn.commit()
    return out

def export_jobs_csv(conn: sqlite3.Connection, path: Optional[str] = None) -> Path:
    out = Path(path).expanduser() if path else export_dir() / f"sentinel_jobs_export_{date.today().isoformat()}.csv"
    secure_parent(out)
    rows = conn.execute("SELECT * FROM jobs ORDER BY created_at DESC").fetchall()
    fields = [d[0] for d in conn.execute("SELECT * FROM jobs LIMIT 1").description] if rows else [
        "id", "job_code", "title", "company", "job_type", "location", "remote_mode", "source", "source_url", "salary_min", "salary_max", "currency", "status", "priority", "fit_score", "applied_date", "due_date", "contact_name", "contact_email", "notes", "archived", "created_at", "updated_at"
    ]
    with out.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            csv_writerow_safe(writer, {k: row[k] for k in fields})
    harden_file(out)
    audit(conn, "export_jobs_csv", "file", out, str(out))
    conn.commit()
    return out


def export_jobs_json(conn: sqlite3.Connection, path: Optional[str] = None) -> Path:
    out = Path(path).expanduser() if path else export_dir() / f"sentinel_jobs_export_{date.today().isoformat()}.json"
    secure_parent(out)
    data = {
        "app": APP_NAME,
        "version": VERSION,
        "schema_version": SCHEMA_VERSION,
        "exported_at": now_iso(),
        "jobs": [dict(r) for r in conn.execute("SELECT * FROM jobs ORDER BY created_at DESC")],
        "actions": [dict(r) for r in conn.execute("SELECT * FROM actions ORDER BY created_at DESC")],
        "documents": [dict(r) for r in conn.execute("SELECT * FROM documents ORDER BY created_at DESC")],
        "interviews": [dict(r) for r in conn.execute("SELECT * FROM interviews ORDER BY created_at DESC")],
    }
    out.write_text(json.dumps(data, indent=2), encoding="utf-8")
    harden_file(out)
    audit(conn, "export_jobs_json", "file", out, str(out))
    conn.commit()
    return out


def export_calendar_csv(conn: sqlite3.Connection, path: Optional[str] = None) -> Path:
    out = Path(path).expanduser() if path else export_dir() / f"sentinel_jobs_calendar_bridge_{date.today().isoformat()}.csv"
    secure_parent(out)
    fields = ["subject", "start_date", "description", "job_code", "company", "action_type", "source"]
    rows = conn.execute(
        """SELECT a.*, j.job_code, j.title, j.company FROM actions a JOIN jobs j ON j.id=a.job_id
              WHERE a.due_date!='' AND a.status!='done' ORDER BY a.due_date ASC"""
    ).fetchall()
    with out.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for a in rows:
            csv_writerow_safe(writer, {
                "subject": f"{APP_NAME}: {a['action_type']} — {a['company']} / {a['title']}",
                "start_date": a["due_date"],
                "description": a["description"],
                "job_code": a["job_code"],
                "company": a["company"],
                "action_type": a["action_type"],
                "source": "sentinel-jobs",
            })
        interview_rows = conn.execute(
            """SELECT i.*, j.job_code, j.title, j.company FROM interviews i JOIN jobs j ON j.id=i.job_id
                  WHERE i.scheduled_date!='' AND i.status NOT IN ('done','cancelled') ORDER BY i.scheduled_date ASC"""
        ).fetchall()
        for irow in interview_rows:
            desc = f"Interview {irow['interview_type']} {irow['scheduled_time']} {irow['mode']} {irow['location']} {irow['interviewer']}".strip()
            csv_writerow_safe(writer, {
                "subject": f"{APP_NAME}: interview — {irow['company']} / {irow['title']}",
                "start_date": irow["scheduled_date"],
                "description": desc,
                "job_code": irow["job_code"],
                "company": irow["company"],
                "action_type": "interview",
                "source": "sentinel-jobs-interview",
            })
    harden_file(out)
    audit(conn, "export_calendar_csv", "file", out, str(out))
    conn.commit()
    return out


def import_jobs_csv(conn: sqlite3.Connection, path: str) -> str:
    p = Path(path).expanduser()
    if not p.exists():
        raise SystemExit(f"CSV not found: {p}")
    count = 0
    with p.open("r", newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            ns = argparse.Namespace(
                code=row.get("job_code") or row.get("code") or None,
                code_prefix=None,
                title=row.get("title") or "Untitled job",
                company=row.get("company") or "",
                job_type=row.get("job_type") or "employment",
                location=row.get("location") or "",
                remote_mode=row.get("remote_mode") or "",
                source=row.get("source") or "",
                source_url=row.get("source_url") or "",
                salary_min=safe_float(row.get("salary_min"), 0.0),
                salary_max=safe_float(row.get("salary_max"), 0.0),
                currency=row.get("currency") or get_meta(conn, "currency", DEFAULT_CURRENCY),
                status=row.get("status") or "saved",
                priority=max(1, safe_int(row.get("priority"), 3)),
                fit_score=max(0, min(100, safe_int(row.get("fit_score"), 0))),
                applied_date=row.get("applied_date") or "",
                due_date=row.get("due_date") or "",
                contact_name=row.get("contact_name") or "",
                contact_email=row.get("contact_email") or "",
                notes=row.get("notes") or "",
                create_action="",
            )
            try:
                add_job(conn, ns)
                count += 1
            except sqlite3.IntegrityError:
                continue
    audit(conn, "import_jobs_csv", "file", p, f"{count} rows")
    conn.commit()
    return f"Imported {count} jobs from {p}"


def verify_backup_file(path: Path) -> Tuple[bool, str]:
    p = Path(path).expanduser()
    if not p.exists():
        return False, "backup file does not exist"
    if p.stat().st_size <= 0:
        return False, "backup file is empty"
    try:
        probe = sqlite3.connect(f"file:{p}?mode=ro", uri=True)
        try:
            result = probe.execute("PRAGMA integrity_check").fetchone()[0]
        finally:
            probe.close()
        if result != "ok":
            return False, f"sqlite integrity check returned: {result}"
    except Exception as e:
        return False, f"backup verification error: {e}"
    return True, "sqlite integrity check ok"


def backup_database(conn: sqlite3.Connection, path: Optional[str] = None) -> Path:
    src = default_db_path()
    if path:
        out = Path(path).expanduser()
    else:
        ensure_private_dir(backup_dir())
        out = backup_dir() / f"sentinel_jobs_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.sqlite3"
    secure_parent(out)
    conn.commit()
    shutil.copy2(src, out)
    harden_file(out)
    ok, detail = verify_backup_file(out)
    if not ok:
        raise RuntimeError(f"Backup created at {out} but verification failed: {detail}")
    audit(conn, "backup_database", "file", out, f"verified: {detail}")
    conn.commit()
    return out


def backup_database_report(conn: sqlite3.Connection, path: Optional[str] = None) -> str:
    out = backup_database(conn, path)
    ok, detail = verify_backup_file(out)
    status = "VERIFIED" if ok else "FAILED"
    return f"Backup {status}: {out}\n{detail}"



def audit_report_data(conn: sqlite3.Connection, limit: int = 50) -> Dict[str, Any]:
    try:
        integrity = conn.execute("PRAGMA integrity_check").fetchone()[0]
    except Exception as e:
        integrity = f"error: {e}"
    tables = {}
    for table in [
        "jobs", "actions", "interviews", "documents", "saved_views", "companies",
        "contacts", "contact_interactions", "profile_skills", "job_skills", "audit_log"
    ]:
        try:
            tables[table] = conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
        except Exception:
            tables[table] = None
    recent = conn.execute(
        "SELECT event_ts, action, entity_type, entity_id, details FROM audit_log ORDER BY id DESC LIMIT ?",
        (int(limit),),
    ).fetchall()
    return {
        "app": APP_NAME,
        "program_number": 112,
        "version": VERSION,
        "schema_version": SCHEMA_VERSION,
        "generated_at": now_iso(),
        "database_path": str(default_db_path()),
        "database_integrity": integrity,
        "table_counts": tables,
        "recent_audit_events": [dict(r) for r in recent],
        "local_only": True,
        "network_access": False,
        "telemetry": False,
    }


def format_audit_report(data: Dict[str, Any]) -> str:
    lines = [
        f"{data['app']} v{data['version']} Audit Report",
        f"Generated: {data['generated_at']}",
        f"Database: {data['database_path']}",
        f"SQLite integrity: {data['database_integrity']}",
        "",
        "Table counts:",
    ]
    for k, v in data["table_counts"].items():
        lines.append(f"  {k}: {v}")
    lines += ["", "Recent audit events:"]
    for ev in data["recent_audit_events"]:
        lines.append(f"  {ev.get('event_ts','')} | {ev.get('action','')} | {ev.get('entity_type','')} | {ev.get('entity_id','')} | {ev.get('details','')}")
    return "\n".join(lines)


def stable_lock_report_data(conn: sqlite3.Connection) -> Dict[str, Any]:
    health = health_json(conn)
    audit_data = audit_report_data(conn, limit=10)
    return {
        "app": APP_NAME,
        "package": "sentinel-jobs",
        "program_number": 112,
        "version": VERSION,
        "debian_version": DEBIAN_VERSION,
        "schema_version": SCHEMA_VERSION,
        "stable_lock": True,
        "stable_lock_name": "Sentinel Jobs v1.0.0 Stable Lock",
        "generated_at": now_iso(),
        "database_path": str(default_db_path()),
        "database_integrity": audit_data["database_integrity"],
        "local_only": True,
        "network_access": False,
        "telemetry": False,
        "locked_capabilities": [
            "local SQLite job/opportunity tracking",
            "F.O.R.G.E-style AEGIS/Sentinel GTK GUI",
            "responsive no-horizontal-scroll dashboard layout",
            "fixed sidebar navigation and top menu behaviour",
            "Ctrl+Q close hotkey and GUI manual page",
            "job application pipeline and saved views",
            "actions, due dates, interviews, and calendar bridge CSV",
            "application documents and local pack export",
            "companies, contacts, and networking follow-up tracking",
            "profile skills, job requirements, match scoring, and gap reports",
            "CSV/JSON exports and local handoff files",
            "verified local database backups from GUI and CLI",
            "audit report and v1 handoff bundle",
            "MATE desktop/menu launcher and Sentinel icon",
            "AEGIS/Sentinel Command health JSON",
        ],
        "health": health,
    }


def format_stable_lock_report(data: Dict[str, Any]) -> str:
    lines = [
        data["stable_lock_name"],
        f"Program: {data['program_number']} — {data['app']}",
        f"Version: {data['version']}",
        f"Debian package version: {data['debian_version']}",
        f"Schema version: {data['schema_version']}",
        f"Generated: {data['generated_at']}",
        f"Database: {data['database_path']}",
        f"SQLite integrity: {data['database_integrity']}",
        "Posture: local-only / no network / no telemetry",
        "",
        "Locked capabilities:",
    ]
    lines += [f"  - {cap}" for cap in data["locked_capabilities"]]
    lines += ["", "Stable lock: READY"]
    return "\n".join(lines)


def export_audit_json(conn: sqlite3.Connection, output: Optional[str] = None) -> Path:
    out = Path(output).expanduser() if output else export_dir() / "sentinel_jobs_audit_report.json"
    secure_parent(out)
    out.write_text(json.dumps(audit_report_data(conn, limit=500), indent=2), encoding="utf-8")
    harden_file(out)
    audit(conn, "export_audit_json", "file", out, str(out))
    conn.commit()
    return out


def export_audit_csv(conn: sqlite3.Connection, output: Optional[str] = None) -> Path:
    out = Path(output).expanduser() if output else export_dir() / "sentinel_jobs_audit_log.csv"
    secure_parent(out)
    rows = conn.execute("SELECT event_ts, action, entity_type, entity_id, details FROM audit_log ORDER BY id DESC").fetchall()
    with out.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["event_ts", "action", "entity_type", "entity_id", "details"])
        for r in rows:
            csv_writerow_safe(writer, [r["event_ts"], r["action"], r["entity_type"], r["entity_id"], r["details"]])
    harden_file(out)
    audit(conn, "export_audit_csv", "file", out, str(out))
    conn.commit()
    return out


def export_v1_bundle(conn: sqlite3.Connection, output: Optional[str] = None) -> Path:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    base = Path(output).expanduser() if output else export_dir() / f"sentinel_jobs_v1_handoff_{stamp}"
    ensure_private_dir(base)
    (base / "sentinel_jobs_stable_lock_report.md").write_text(format_stable_lock_report(stable_lock_report_data(conn)) + "\n", encoding="utf-8")
    (base / "sentinel_jobs_health.json").write_text(json.dumps(health_json(conn), indent=2), encoding="utf-8")
    (base / "sentinel_jobs_audit_report.json").write_text(json.dumps(audit_report_data(conn, limit=500), indent=2), encoding="utf-8")
    # Core exports use explicit paths so the bundle is self-contained.
    export_jobs_csv(conn, str(base / "sentinel_jobs_jobs.csv"))
    export_jobs_json(conn, str(base / "sentinel_jobs_jobs.json"))
    export_calendar_csv(conn, str(base / "sentinel_jobs_calendar_bridge.csv"))
    export_pipeline_json(conn, str(base / "sentinel_jobs_pipeline.json"), 50)
    export_saved_views_json(conn, str(base / "sentinel_jobs_saved_views.json"))
    export_companies_csv(conn, str(base / "sentinel_jobs_companies.csv"))
    export_companies_json(conn, str(base / "sentinel_jobs_companies.json"))
    export_contacts_csv(conn, str(base / "sentinel_jobs_contacts.csv"))
    export_contacts_json(conn, str(base / "sentinel_jobs_contacts.json"))
    export_documents_csv(conn, str(base / "sentinel_jobs_documents.csv"))
    export_documents_json(conn, str(base / "sentinel_jobs_documents.json"))
    export_interviews_csv(conn, str(base / "sentinel_jobs_interviews.csv"))
    export_interviews_json(conn, str(base / "sentinel_jobs_interviews.json"))
    export_skill_match_csv(conn, str(base / "sentinel_jobs_skill_match.csv"))
    export_skill_match_json(conn, str(base / "sentinel_jobs_skill_match.json"))
    export_profile_skills_json(conn, str(base / "sentinel_jobs_profile_skills.json"))
    export_audit_csv(conn, str(base / "sentinel_jobs_audit_log.csv"))
    backup_path = backup_database(conn, str(base / "sentinel_jobs_v1_database_backup.sqlite3"))
    manifest = {
        "app": APP_NAME,
        "program_number": 112,
        "version": VERSION,
        "schema_version": SCHEMA_VERSION,
        "created_at": now_iso(),
        "bundle_path": str(base),
        "backup_path": str(backup_path),
        "local_only": True,
        "network_access": False,
        "telemetry": False,
        "files": sorted([p.name for p in base.iterdir() if p.is_file()]),
    }
    (base / "sentinel_jobs_v1_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    for item in base.iterdir():
        if item.is_file():
            harden_file(item)
    audit(conn, "export_v1_bundle", "directory", base, str(base))
    conn.commit()
    return base


def restore_backup_database(conn: sqlite3.Connection, backup_path: str, confirm: str = "") -> str:
    if confirm != "RESTORE_SENTINEL_JOBS":
        raise ValueError("restore requires --confirm RESTORE_SENTINEL_JOBS")
    src = Path(backup_path).expanduser()
    ok, detail = verify_backup_file(src)
    if not ok:
        raise ValueError(f"backup validation failed: {detail}")
    target = default_db_path()
    safety = None
    secure_parent(target)
    if target.exists():
        safety = backup_dir() / f"pre_restore_sentinel_jobs_{datetime.now().strftime('%Y%m%d_%H%M%S')}.sqlite3"
        secure_parent(safety)
        conn.commit()
        shutil.copy2(target, safety)
        harden_file(safety)
        ok2, detail2 = verify_backup_file(safety)
        if not ok2:
            raise RuntimeError(f"pre-restore safety copy failed: {detail2}")
    try:
        conn.close()
    except Exception:
        pass
    shutil.copy2(src, target)
    harden_file(target)
    ok3, detail3 = verify_backup_file(target)
    if not ok3:
        raise RuntimeError(f"restore wrote database but integrity check failed: {detail3}")
    return f"Restore VERIFIED: {target}\n{detail3}\nPre-restore safety copy: {safety if safety else 'not needed'}"

def health_json(conn: sqlite3.Connection) -> Dict[str, Any]:
    db = default_db_path()
    try:
        integrity = conn.execute("PRAGMA integrity_check").fetchone()[0]
    except Exception as e:
        integrity = f"error: {e}"
    return {
        "app": APP_NAME,
        "package": "sentinel-jobs",
        "program_number": 112,
        "version": VERSION,
        "debian_version": DEBIAN_VERSION,
        "schema_version": SCHEMA_VERSION,
        "database_path": str(db),
        "database_exists": db.exists(),
        "database_integrity": integrity,
        "readiness": "v1_stable_locked",
        "local_only": True,
        "network_access": False,
        "telemetry": False,
        "gui_ready": True,
        "cli_ready": True,
        "desktop_launcher_ready": True,
        "job_tracking_ready": True,
        "application_tracking_ready": True,
        "action_followup_ready": True,
        "interview_tracking_ready": True,
        "interview_schedule_ready": True,
        "interview_prep_ready": True,
        "interview_pack_export_ready": True,
        "interview_calendar_bridge_ready": True,
        "interview_csv_json_export_ready": True,
        "interview_prep_tab_ready": True,
        "search_filter_ready": True,
        "advanced_filter_ready": True,
        "saved_views_ready": True,
        "saved_view_run_ready": True,
        "pipeline_board_ready": True,
        "pipeline_json_export_ready": True,
        "search_views_tab_ready": True,
        "company_tracking_ready": True,
        "contact_tracking_ready": True,
        "company_contact_crm_ready": True,
        "networking_followup_ready": True,
        "contact_history_ready": True,
        "company_contact_export_ready": True,
        "contacts_companies_tab_ready": True,
        "profile_skills_ready": True,
        "job_skill_requirements_ready": True,
        "skill_match_ready": True,
        "skill_gap_report_ready": True,
        "skill_match_export_ready": True,
        "skills_match_tab_ready": True,
        "ctrl_q_quit_hotkey_ready": True,
        "gui_hotkeys_ready": True,
        "manual_tab_ready": True,
        "manual_tab_command_reference_ready": True,
        "fullscreen_proportion_guard_ready": True,
        "centered_page_frame_ready": True,
        "responsive_fullscreen_layout_ready": True,
        "proportional_gui_layout_ready": True,
        "gui_completion_ready": True,
        "v1_gui_candidate_ready": True,
        "stable_lock_ready": True,
        "v1_stable_baseline_locked": True,
        "stable_lock_report_ready": True,
        "audit_report_ready": True,
        "audit_export_ready": True,
        "v1_handoff_bundle_ready": True,
        "security_hardening_patch": "1.0.1",
        "private_file_permissions_ready": True,
        "csv_formula_injection_guard_ready": True,
        "robust_csv_import_ready": True,
        "backup_restore_ready": True,
        "guarded_restore_ready": True,
        "sentinel_jobs_v1_ready": True,
        "horizontal_scrollbar_removed_ready": True,
        "left_anchored_layout_ready": True,
        "dashboard_two_column_responsive_ready": True,
        "pipeline_two_column_responsive_ready": True,
        "backup_button_file_menu_ready": True,
        "backup_button_sidebar_ready": True,
        "backup_button_export_tab_ready": True,
        "backup_verification_ready": True,
        "backup_buttons_v1_ready": True,
        "document_reference_ready": True,
        "documents_tab_ready": True,
        "document_check_ready": True,
        "required_document_tracking_ready": True,
        "resume_cover_letter_tracking_ready": True,
        "application_pack_export_ready": True,
        "application_pack_manifest_ready": True,
        "documents_csv_json_export_ready": True,
        "calendar_bridge_csv_ready": True,
        "import_export_ready": True,
        "backup_ready": True,
        "aegis_status_ready": True,
        "sentinel_command_ready": True,
        "sentinel_theme_ready": True,
        "gtk_css_theme_ready": True,
        "gtk_css_compatibility_hotfix_ready": True,
        "gtk_invalid_selection_property_removed": True,
        "theme_safe_fallback_ready": True,
        "aegis_dark_theme_ready": True,
        "sentinel_gold_accents_ready": True,
        "text_field_theme_ready": True,
        "dropdown_menu_theme_ready": True,
        "menu_bar_theme_ready": True,
        "button_theme_ready": True,
        "manual_status_theme_ready": True,
        "dashboard_polish_ready": True,
        "dashboard_cards_ready": True,
        "dashboard_pipeline_status_ready": True,
        "dashboard_top_fit_panel_ready": True,
        "dashboard_due_actions_panel_ready": True,
        "aegis_sentinel_gui_theme_ready": True,
        "sentinel_card_theme_ready": True,
        "sentinel_output_panel_theme_ready": True,
        "forge_style_theme_ready": True,
        "forge_reference_layout_ready": True,
        "left_sidebar_navigation_ready": True,
        "program_header_theme_ready": True,
        "dark_command_panel_theme_ready": True,
        "square_button_theme_ready": True,
        "white_border_output_theme_ready": True,
        "mate_screenshot_theme_alignment_ready": True,
        "scrollbar_theme_adjusted_ready": True,
        "navigation_hotfix_ready": True,
        "top_menu_hotfix_ready": True,
        "responsive_dashboard_layout_ready": True,
        "symmetrical_gui_layout_ready": True,
        "dashboard_grid_homogeneous_ready": True,
        "overlay_scrollbars_disabled_ready": True,
        "sidebar_revisit_hotfix_ready": True,
        "sidebar_button_state_guard_ready": True,
        "stack_visible_child_guard_ready": True,
        "menu_navigation_guard_ready": True,
        "previous_sidebar_tabs_fixed_ready": True,
        "permission_default": "Disabled",
        "permission_maximum": "Full Local Control",
        "counts": dashboard_data(conn),
    }


def self_test() -> str:
    old_db = os.environ.get("SENTINEL_JOBS_DB")
    old_export = os.environ.get("SENTINEL_JOBS_EXPORT_DIR")
    old_backup = os.environ.get("SENTINEL_JOBS_BACKUP_DIR")
    try:
        with tempfile.TemporaryDirectory(prefix="sentinel-jobs-test-") as td:
            db = Path(td) / "test.sqlite3"
            os.environ["SENTINEL_JOBS_DB"] = str(db)
            os.environ["SENTINEL_JOBS_EXPORT_DIR"] = str(Path(td) / "exports")
            os.environ["SENTINEL_JOBS_BACKUP_DIR"] = str(Path(td) / "backups")
            conn = connect(db)
            init_db(conn)
            ns = argparse.Namespace(
                code=None, code_prefix=None, title="Junior Network Technician", company="Example Co", job_type="employment",
                location="Local", remote_mode="hybrid", source="manual", source_url="", salary_min=0, salary_max=0,
                currency="AUD", status="saved", priority=2, fit_score=80, applied_date="", due_date=today_iso(),
                contact_name="", contact_email="", notes="self-test", create_action="Apply"
            )
            msg = add_job(conn, ns)
            assert "JOB-0001" in msg
            assert next_job_code(conn) == "JOB-0002"
            rows = list_jobs(conn, argparse.Namespace(include_archived=False, status=None, company=None, query=None, limit=20))
            assert len(rows) == 1
            assert rows[0]["job_code"] == "JOB-0001"
            filtered = list_jobs(conn, argparse.Namespace(include_archived=False, status="saved", company="Example", query="network", limit=20, job_type="employment", remote_mode="hybrid", priority_max=3, fit_min=70, due_days=30, sort="fit"))
            assert len(filtered) == 1
            assert "JOB-0001" in format_pipeline_board(pipeline_board_data(conn, limit_per_status=5))
            save_view(conn, argparse.Namespace(name="High Fit", query="network", status="saved", company="Example", job_type="employment", remote_mode="hybrid", priority_max=3, fit_min=70, due_days=30, include_archived=False, sort="fit", limit=20))
            assert len(list_saved_views(conn)) == 1
            assert len(run_saved_view(conn, "High Fit")) == 1
            company_add(conn, argparse.Namespace(name="Example Co", industry="Technology", website="https://example.invalid", phone="", email="hr@example.invalid", address="", notes="self-test company", follow_up=today_iso()))
            contact_add(conn, argparse.Namespace(name="Jane Recruiter", company="Example Co", type="recruiter", title="Recruiter", email="jane@example.invalid", phone="", source="manual", notes="self-test contact", follow_up=today_iso()))
            assert len(list_companies(conn, argparse.Namespace(query="Example", due_days=None, limit=20))) == 1
            assert len(list_contacts(conn, argparse.Namespace(query="Jane", company="Example", type="recruiter", due_days=14, limit=20))) == 1
            contact_log(conn, argparse.Namespace(contact="Jane Recruiter", type="email", date=today_iso(), summary="Sent intro email", next_follow_up=today_iso(), job="JOB-0001"))
            assert contact_history(conn, argparse.Namespace(contact="Jane Recruiter", company=None, limit=20))
            assert networking_due(conn, 14)["contacts"]
            assert export_companies_csv(conn).exists() and export_companies_json(conn).exists()
            assert export_contacts_csv(conn).exists() and export_contacts_json(conn).exists()
            assert "Saved" in set_profile_skills(conn, argparse.Namespace(skills="networking, linux, customer service", level=4, notes="self-test profile"))
            assert "Saved" in add_job_skills(conn, argparse.Namespace(job="JOB-0001", skills="networking, linux, python", required_level=3, importance=4, source="self-test", notes="required skills"))
            match = skill_match_data(conn, "JOB-0001")
            assert match["match_percent"] > 0 and "python" in match["missing"]
            assert skill_gaps_data(conn, 20)["gaps"]
            assert export_skill_match_csv(conn).exists() and export_skill_match_json(conn).exists() and export_profile_skills_json(conn).exists()
            pipeline_path = export_pipeline_json(conn)
            views_path = export_saved_views_json(conn)
            assert pipeline_path.exists() and views_path.exists()
            add_action(conn, argparse.Namespace(job="JOB-0001", type="interview", description="Phone screen", due_date=today_iso(), notes=""))
            schedule_interview(conn, argparse.Namespace(job="JOB-0001", type="phone", date=today_iso(), time="10:00", mode="phone", location="", interviewer="Example HR", status="scheduled", prep_notes="Review networking examples", questions="Ask about tools", create_action=True))
            interviews = list_interviews(conn, argparse.Namespace(all=False, job=None, upcoming=True, limit=20))
            assert len(interviews) >= 1
            prep = interview_prep_data(conn, "JOB-0001")
            assert prep["interviews"] and prep["prep_checklist"]
            int_csv = export_interviews_csv(conn)
            int_json = export_interviews_json(conn)
            int_pack = export_interview_pack(conn, "JOB-0001")
            assert int_csv.exists() and int_json.exists() and (int_pack / "interview_prep.json").exists()
            actions = list_actions(conn, argparse.Namespace(all=False, job=None, type=None, due_days=14, limit=20))
            assert len(actions) >= 1
            update_status(conn, "JOB-0001", "applied")
            assert resolve_job(conn, "JOB-0001")["status"] == "applied"
            sample_resume = Path(td) / "resume.txt"
            sample_cover = Path(td) / "cover_letter.txt"
            sample_resume.write_text("resume", encoding="utf-8")
            sample_cover.write_text("cover", encoding="utf-8")
            add_document(conn, argparse.Namespace(job="JOB-0001", path=str(sample_resume), type="resume", notes="self-test resume"))
            add_document(conn, argparse.Namespace(job="JOB-0001", path=str(sample_cover), type="cover_letter", notes="self-test cover"))
            doc_check = document_check_data(conn, "JOB-0001")
            assert doc_check["ready_for_application_pack"] is True
            docs_csv = export_documents_csv(conn)
            docs_json = export_documents_json(conn)
            pack_dir = export_application_pack(conn, "JOB-0001")
            assert docs_csv.exists() and docs_json.exists() and (pack_dir / "application_pack_manifest.json").exists()
            csv_path = export_jobs_csv(conn)
            json_path = export_jobs_json(conn)
            cal_path = export_calendar_csv(conn)
            assert csv_path.exists() and json_path.exists() and cal_path.exists()
            h = health_json(conn)
            assert h["job_tracking_ready"] is True
            assert h["sentinel_theme_ready"] is True
            assert h["text_field_theme_ready"] is True
            assert h["dropdown_menu_theme_ready"] is True
            assert h["dashboard_polish_ready"] is True
            assert h["dashboard_cards_ready"] is True
            assert h["aegis_sentinel_gui_theme_ready"] is True
            assert h["forge_style_theme_ready"] is True
            assert h["left_sidebar_navigation_ready"] is True
            assert h["program_header_theme_ready"] is True
            assert h["scrollbar_theme_adjusted_ready"] is True
            assert h["navigation_hotfix_ready"] is True
            assert h["top_menu_hotfix_ready"] is True
            assert h["responsive_dashboard_layout_ready"] is True
            assert h["symmetrical_gui_layout_ready"] is True
            assert h["interview_schedule_ready"] is True
            assert h["interview_prep_ready"] is True
            assert h["interview_pack_export_ready"] is True
            assert h["search_filter_ready"] is True
            assert h["advanced_filter_ready"] is True
            assert h["saved_views_ready"] is True
            assert h["pipeline_board_ready"] is True
            assert h["pipeline_json_export_ready"] is True
            assert h["search_views_tab_ready"] is True
            assert h["company_tracking_ready"] is True
            assert h["contact_tracking_ready"] is True
            assert h["company_contact_crm_ready"] is True
            assert h["networking_followup_ready"] is True
            assert h["contact_history_ready"] is True
            assert h["company_contact_export_ready"] is True
            assert h["contacts_companies_tab_ready"] is True
            assert h["profile_skills_ready"] is True
            assert h["skill_match_ready"] is True
            assert h["skill_gap_report_ready"] is True
            assert h["skills_match_tab_ready"] is True
            assert h["document_check_ready"] is True
            assert h["application_pack_export_ready"] is True
            assert h["documents_tab_ready"] is True
            assert h["database_integrity"] == "ok"
            assert h["gui_completion_ready"] is True
            assert h["horizontal_scrollbar_removed_ready"] is True
            assert h["backup_verification_ready"] is True
            assert h["backup_buttons_v1_ready"] is True
            b = backup_database(conn)
            assert b.exists()
            ok, detail = verify_backup_file(b)
            assert ok, detail
            report = backup_database_report(conn)
            assert "Backup VERIFIED" in report
            conn.close()
        return "Sentinel Jobs self-test passed."
    finally:
        if old_db is None:
            os.environ.pop("SENTINEL_JOBS_DB", None)
        else:
            os.environ["SENTINEL_JOBS_DB"] = old_db
        if old_export is None:
            os.environ.pop("SENTINEL_JOBS_EXPORT_DIR", None)
        else:
            os.environ["SENTINEL_JOBS_EXPORT_DIR"] = old_export
        if old_backup is None:
            os.environ.pop("SENTINEL_JOBS_BACKUP_DIR", None)
        else:
            os.environ["SENTINEL_JOBS_BACKUP_DIR"] = old_backup

def install_desktop_launcher() -> str:
    src_candidates = [
        Path("/usr/share/applications/sentinel-jobs.desktop"),
        Path(__file__).resolve().parent.parent / "share" / "applications" / "sentinel-jobs.desktop",
    ]
    src = next((p for p in src_candidates if p.exists()), None)
    if not src:
        return "Desktop launcher template not found. Install the .deb package first."
    desktop_dir = Path.home() / "Desktop"
    desktop_dir.mkdir(parents=True, exist_ok=True)
    dest = desktop_dir / "sentinel-jobs.desktop"
    shutil.copy2(src, dest)
    dest.chmod(0o755)
    return f"Desktop launcher installed: {dest}"


def run_gui() -> int:
    try:
        import gi  # type: ignore
        gi.require_version("Gtk", "3.0")
        from gi.repository import Gtk, Gdk, Pango  # type: ignore
    except Exception as e:
        print("Sentinel Jobs GUI requires GTK3 Python bindings: python3-gi gir1.2-gtk-3.0", file=sys.stderr)
        print(f"Import error: {e}", file=sys.stderr)
        return 2

    def apply_sentinel_theme() -> None:
        provider = Gtk.CssProvider()
        try:
            provider.load_from_data(SENTINEL_GTK_CSS.encode("utf-8"))
        except Exception as e:
            print(f"Sentinel Jobs theme warning: GTK rejected the full CSS theme, using safe fallback: {e}", file=sys.stderr)
            fallback_css = b"""
window, notebook, scrolledwindow, viewport, paned, box, grid { background-color: #101216; color: #F2E7C8; }
label { color: #F2E7C8; }
entry, spinbutton, spinbutton entry, textview, textview text { background-color: #151922; color: #F7EBCB; border: 1px solid #8F650C; }
button { background-image: none; background-color: #171C24; color: #E19B00; border: 1px solid #8F650C; }
notebook tab { background-color: #12161C; color: #D8CBAA; border: 1px solid #2A2112; }
notebook tab:checked { background-color: #1A1F27; color: #E19B00; }
menubar, menu, menuitem { background-color: #080A0D; color: #E19B00; }
"""
            provider.load_from_data(fallback_css)
        screen = Gdk.Screen.get_default()
        if screen is not None:
            Gtk.StyleContext.add_provider_for_screen(screen, provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)

    def make_combo(values: Iterable[str], active_value: str = ""):
        combo = Gtk.ComboBoxText()
        values = list(values)
        active_index = 0
        for i, value in enumerate(values):
            display = value.replace("_", " ").title() if value else "Unspecified"
            combo.append_text(display)
            if value == active_value:
                active_index = i
        combo.set_active(active_index)
        combo.sentinel_values = values  # type: ignore[attr-defined]
        return combo

    def combo_value(combo) -> str:
        values = getattr(combo, "sentinel_values", [])
        idx = combo.get_active()
        if idx is None or idx < 0 or idx >= len(values):
            return ""
        return values[idx]

    apply_sentinel_theme()
    conn = connect()
    init_db(conn)

    class App(Gtk.Window):
        def __init__(self) -> None:
            super().__init__(title=f"{APP_NAME} v{VERSION}")
            self.set_default_size(1440, 840)
            self.set_size_request(1100, 680)
            self.accel_group = Gtk.AccelGroup()
            self.add_accel_group(self.accel_group)
            key, mod = Gtk.accelerator_parse("<Primary>q")
            self.accel_group.connect(key, mod, Gtk.AccelFlags.VISIBLE, self.on_quit_accel)
            self.set_border_width(0)
            self.get_style_context().add_class("sentinel-root")
            icon_path = Path("/usr/share/icons/hicolor/256x256/apps/sentinel-jobs.png")
            if icon_path.exists():
                try:
                    self.set_icon_from_file(str(icon_path))
                except Exception:
                    pass

            root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
            root.get_style_context().add_class("sentinel-root")
            self.add(root)
            root.pack_start(self._menu_bar(), False, False, 0)
            root.pack_start(self._program_header(), False, False, 0)

            body = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            body.set_halign(Gtk.Align.FILL)
            body.set_valign(Gtk.Align.FILL)
            body.set_hexpand(True)
            body.set_vexpand(True)
            body.get_style_context().add_class("sentinel-content-shell")
            body.get_style_context().add_class("sentinel-body-shell")
            root.pack_start(body, True, True, 0)

            self.dashboard_widgets: Dict[str, Any] = {}
            self.dashboard_status_labels: Dict[str, Any] = {}
            self.nav_buttons: Dict[str, Any] = {}
            self.current_page_name = "dashboard"
            self._nav_guard = False
            body.pack_start(self._sidebar(), False, False, 0)

            self.stack = Gtk.Stack()
            # Disable animated stack transitions on MATE/GTK3. The prior crossfade could leave
            # old pages visually/statefully confused when revisiting earlier sidebar tabs.
            self.stack.set_transition_type(Gtk.StackTransitionType.NONE)
            self.stack.set_transition_duration(0)
            self.stack.get_style_context().add_class("sentinel-stack")
            body.pack_start(self.stack, True, True, 0)

            self.dashboard_page = self._dashboard_tab()
            self.stack.add_titled(self._scrolled(self._page_frame(self.dashboard_page)), "dashboard", "Dashboard")
            self.stack.add_titled(self._scrolled(self._page_frame(self._jobs_tab())), "jobs", "Jobs")
            self.stack.add_titled(self._scrolled(self._page_frame(self._actions_tab())), "actions", "Actions")
            self.stack.add_titled(self._scrolled(self._page_frame(self._interviews_tab())), "interviews", "Interview Prep")
            self.stack.add_titled(self._scrolled(self._page_frame(self._search_views_tab())), "search", "Search / Views")
            self.stack.add_titled(self._scrolled(self._page_frame(self._contacts_companies_tab())), "contacts", "Contacts / Companies")
            self.stack.add_titled(self._scrolled(self._page_frame(self._skills_match_tab())), "skills", "Skills / Match")
            self.stack.add_titled(self._scrolled(self._page_frame(self._documents_tab())), "documents", "Documents / Packs")
            self.stack.add_titled(self._scrolled(self._page_frame(self._export_tab())), "export", "Import / Export")
            self.stack.add_titled(self._scrolled(self._page_frame(self._manual_tab())), "manual", "Manual")
            self.show_page("dashboard")
            self.refresh_all()

        def on_quit_accel(self, *_):
            Gtk.main_quit()
            return True

        def _menu_bar(self):
            menubar = Gtk.MenuBar()
            self._class(menubar, "sentinel-menu-bar")
            file_item = Gtk.MenuItem(label="File")
            file_menu = Gtk.Menu()
            for label, callback in [
                ("Install Desktop Launcher", lambda *_: self.message(install_desktop_launcher())),
                ("Backup Local Database", lambda *_: self.message(backup_database_report(conn))),
                ("Refresh", lambda *_: self.refresh_all()),
            ]:
                item = Gtk.MenuItem(label=label)
                item.connect("activate", callback)
                file_menu.append(item)
            file_menu.append(Gtk.SeparatorMenuItem())
            quit_item = Gtk.MenuItem(label="Quit")
            quit_item.connect("activate", lambda *_: Gtk.main_quit())
            try:
                key, mod = Gtk.accelerator_parse("<Primary>q")
                quit_item.add_accelerator("activate", self.accel_group, key, mod, Gtk.AccelFlags.VISIBLE)
            except Exception:
                pass
            file_menu.append(quit_item)
            file_item.set_submenu(file_menu)
            menubar.append(file_item)

            view_item = Gtk.MenuItem(label="View")
            view_menu = Gtk.Menu()
            for page_name, label in self.page_specs():
                item = Gtk.MenuItem(label=label)
                item.connect("activate", lambda _item, name=page_name: self.show_page(name))
                view_menu.append(item)
            view_item.set_submenu(view_menu)
            menubar.append(view_item)

            help_item = Gtk.MenuItem(label="Help")
            help_menu = Gtk.Menu()
            manual_item = Gtk.MenuItem(label="Manual")
            manual_item.connect("activate", lambda *_: self.show_page("manual"))
            help_menu.append(manual_item)
            hotkeys_item = Gtk.MenuItem(label="Hotkeys")
            hotkeys_item.connect("activate", lambda *_: self.message("Hotkeys: Ctrl+Q closes Sentinel Jobs. Sidebar buttons switch pages. File > Refresh reloads local data."))
            help_menu.append(hotkeys_item)
            help_item.set_submenu(help_menu)
            menubar.append(help_item)
            menubar.show_all()
            return menubar

        def page_specs(self):
            return [
                ("dashboard", "Dashboard"),
                ("jobs", "Jobs"),
                ("actions", "Actions"),
                ("interviews", "Interview Prep"),
                ("search", "Search / Views"),
                ("contacts", "Contacts / Companies"),
                ("skills", "Skills / Match"),
                ("documents", "Documents / Packs"),
                ("export", "Import / Export"),
                ("manual", "Manual"),
            ]

        def _program_header(self):
            header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=16)
            header.set_border_width(12)
            header.get_style_context().add_class("sentinel-program-header")
            icon_path = Path("/usr/share/icons/hicolor/128x128/apps/sentinel-jobs.png")
            if not icon_path.exists():
                icon_path = Path(__file__).resolve().parent.parent / "share" / "icons" / "hicolor" / "128x128" / "apps" / "sentinel-jobs.png"
            if icon_path.exists():
                img = Gtk.Image.new_from_file(str(icon_path))
                img.set_pixel_size(86)
                img.get_style_context().add_class("sentinel-logo-frame")
                header.pack_start(img, False, False, 0)
            title_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
            title_box.pack_start(self._dash_label("SENTINEL JOBS", "sentinel-app-name"), False, False, 0)
            title_box.pack_start(self._dash_label("Job & Opportunity Tracker — Program 112", "sentinel-app-subtitle"), False, False, 0)
            title_box.pack_start(self._dash_label("Applications • Interview Prep • Follow-ups • Skills Match • Documents • Local Handoff", "sentinel-muted"), False, False, 0)
            header.pack_start(title_box, True, True, 0)
            return header

        def _sidebar(self):
            sidebar_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
            sidebar_box.set_size_request(224, -1)
            sidebar_box.set_border_width(8)
            sidebar_box.get_style_context().add_class("sentinel-sidebar")

            # Use plain command buttons rather than ToggleButton state. GTK toggle state caused
            # unreliable revisits to previous sidebar pages on MATE/GTK3 in the F.O.R.G.E-style
            # layout. Active state is now CSS-class based and guarded by show_page().
            for name, label in self.page_specs():
                button = Gtk.Button(label=label)
                button.set_halign(Gtk.Align.FILL)
                button.set_hexpand(True)
                button.set_can_focus(False)
                button.connect("clicked", lambda _button, n=name: self.show_page(n))
                sidebar_box.pack_start(button, False, True, 0)
                self.nav_buttons[name] = button

            sidebar_box.pack_start(Gtk.Separator(), False, False, 8)
            for label, callback in [
                ("New Backup", lambda *_: self.message(backup_database_report(conn))),
                ("Repair Launchers", lambda *_: self.message(install_desktop_launcher())),
                ("Refresh", lambda *_: self.refresh_all()),
            ]:
                b = Gtk.Button(label=label)
                b.connect("clicked", callback)
                sidebar_box.pack_start(b, False, False, 0)

            # Keep the sidebar usable at smaller heights without overlay scrollbars.
            sw = Gtk.ScrolledWindow()
            sw.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
            sw.set_overlay_scrolling(False)
            self._class(sw, "sentinel-sidebar-scroll")
            sw.add(sidebar_box)
            return sw

        def show_page(self, name: str) -> None:
            valid_names = {page_name for page_name, _label in self.page_specs()}
            if name not in valid_names:
                name = "dashboard"
            if getattr(self, "_nav_guard", False):
                return
            self._nav_guard = True
            try:
                if hasattr(self, "stack"):
                    child = None
                    try:
                        child = self.stack.get_child_by_name(name)
                    except Exception:
                        child = None
                    if child is not None:
                        self.stack.set_visible_child(child)
                        child.show_all()
                    else:
                        self.stack.set_visible_child_name("dashboard")
                        name = "dashboard"
                self.current_page_name = name
                self._sync_nav_buttons(name)
            finally:
                self._nav_guard = False

        def _sync_nav_buttons(self, active_name: str) -> None:
            for page_name, button in getattr(self, "nav_buttons", {}).items():
                ctx = button.get_style_context()
                if page_name == active_name:
                    if not ctx.has_class("sentinel-nav-active"):
                        ctx.add_class("sentinel-nav-active")
                else:
                    if ctx.has_class("sentinel-nav-active"):
                        ctx.remove_class("sentinel-nav-active")

        def _page_frame(self, child, width: int = 0):
            # v0.9.1: fill the available stack width and prevent the previous fullscreen/window
            # clipping bug caused by a fixed-width centered frame. Individual grids stay
            # symmetrical through homogeneous columns while the outer shell remains left-anchored.
            frame = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
            frame.set_halign(Gtk.Align.FILL)
            frame.set_valign(Gtk.Align.FILL)
            frame.set_hexpand(True)
            frame.set_vexpand(True)
            self._class(frame, "sentinel-page-frame")
            child.set_hexpand(True)
            child.set_vexpand(True)
            frame.pack_start(child, True, True, 0)
            return frame

        def _scrolled(self, child, *, shadow=True, min_height: int = 0):
            sw = Gtk.ScrolledWindow()
            # Keep the main app from producing horizontal scrollbars. Pages wrap or use
            # vertical scrolling only, matching the F.O.R.G.E-style command-console layout.
            sw.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
            sw.set_overlay_scrolling(False)
            if min_height:
                try:
                    sw.set_min_content_height(min_height)
                except Exception:
                    pass
            if shadow:
                try:
                    sw.set_shadow_type(Gtk.ShadowType.IN)
                except Exception:
                    pass
            self._class(sw, "sentinel-scroll")
            sw.add(child)
            return sw

        def _class(self, widget, *classes):
            ctx = widget.get_style_context()
            for cls in classes:
                if cls:
                    ctx.add_class(cls)
            return widget

        def _dash_label(self, text: str = "", *classes, xalign: float = 0.0):
            label = Gtk.Label(label=text, xalign=xalign)
            label.set_selectable(False)
            label.set_line_wrap(True)
            try:
                label.set_line_wrap_mode(Pango.WrapMode.WORD_CHAR)
                label.set_max_width_chars(120)
            except Exception:
                pass
            for cls in classes:
                label.get_style_context().add_class(cls)
            return label

        def _card(self, title: str, accent: bool = False):
            card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
            card.set_border_width(12)
            card.set_hexpand(True)
            card.set_vexpand(True)
            self._class(card, "sentinel-card", "sentinel-card-accent" if accent else "")
            if title:
                card.pack_start(self._dash_label(title, "sentinel-kpi-label"), False, False, 0)
            return card

        def _metric_card(self, key: str, title: str, subtitle: str = "", value_class: str = "sentinel-kpi-value"):
            card = self._card(title, accent=True)
            value = self._dash_label("0", value_class)
            subtitle_label = self._dash_label(subtitle, "sentinel-muted")
            card.pack_start(value, False, False, 0)
            if subtitle:
                card.pack_start(subtitle_label, False, False, 0)
            self.dashboard_widgets[key] = value
            return card

        def _dashboard_text_panel(self, key: str, title: str):
            card = self._card(title, accent=False)
            tv = Gtk.TextView()
            tv.set_editable(False)
            tv.set_cursor_visible(False)
            tv.set_monospace(True)
            self._class(tv, "sentinel-output")
            card.pack_start(self._scrolled(tv, min_height=150), True, True, 0)
            self.dashboard_widgets[key] = tv
            return card

        def _dashboard_tab(self):
            outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
            outer.set_border_width(14)
            self._class(outer, "dashboard-shell")

            hero = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
            hero.set_border_width(14)
            self._class(hero, "dashboard-hero")
            hero.pack_start(self._dash_label("Sentinel Jobs Command Dashboard", "sentinel-hero-title"), False, False, 0)
            hero.pack_start(self._dash_label("Applications, interviews, side work, follow-ups, documents, and local handoff status in one Sentinel/AEGIS view.", "sentinel-subtitle"), False, False, 0)
            posture = self._dash_label("Local-only • No network • No telemetry • SQLite protected workspace", "sentinel-cyan")
            hero.pack_start(posture, False, False, 0)
            outer.pack_start(hero, False, False, 0)
            self.dashboard_widgets["posture"] = posture

            metrics = Gtk.Grid(column_spacing=10, row_spacing=10)
            self._class(metrics, "sentinel-dashboard-grid", "sentinel-equal-grid")
            metrics.set_column_homogeneous(True)
            metrics.set_row_homogeneous(True)
            metrics.set_hexpand(True)
            metric_specs = [
                ("active_jobs", "Active Jobs", "open opportunities", "sentinel-kpi-value"),
                ("due_jobs", "Jobs Due", "next 14 days", "sentinel-kpi-value-cyan"),
                ("due_actions", "Actions Due", "next 14 days", "sentinel-kpi-value-cyan"),
                ("overdue_actions", "Overdue", "needs attention", "sentinel-kpi-value-danger"),
                ("interviews", "Interviews", "upcoming", "sentinel-kpi-value"),
                ("archived_jobs", "Archived", "closed/parked", "sentinel-kpi-value"),
            ]
            for i, (key, title, subtitle, value_class) in enumerate(metric_specs):
                metrics.attach(self._metric_card(key, title, subtitle, value_class), i % 2, i // 2, 1, 1)
            outer.pack_start(metrics, False, False, 0)

            status_card = self._card("Pipeline Status", accent=False)
            status_grid = Gtk.Grid(column_spacing=8, row_spacing=7)
            self._class(status_grid, "sentinel-equal-grid")
            status_grid.set_column_homogeneous(True)
            status_grid.set_row_homogeneous(True)
            status_grid.set_hexpand(True)
            for i, status in enumerate(STATUSES):
                pill = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
                pill.set_border_width(6)
                pill.set_hexpand(True)
                self._class(pill, "sentinel-status-pill")
                name = self._dash_label(status.replace("_", " ").title(), "sentinel-muted")
                value = self._dash_label("0", "sentinel-title", xalign=1.0)
                pill.pack_start(name, True, True, 0)
                pill.pack_start(value, False, False, 0)
                self.dashboard_status_labels[status] = value
                status_grid.attach(pill, i % 2, i // 2, 1, 1)
            status_card.pack_start(status_grid, False, False, 0)
            outer.pack_start(status_card, False, False, 0)

            panels = Gtk.Grid(column_spacing=10, row_spacing=10)
            self._class(panels, "sentinel-dashboard-grid", "sentinel-equal-grid")
            panels.set_column_homogeneous(True)
            panels.set_row_homogeneous(True)
            panels.set_hexpand(True)
            panels.set_vexpand(True)
            panels.attach(self._dashboard_text_panel("top_fit", "Top Fit Jobs"), 0, 0, 1, 1)
            panels.attach(self._dashboard_text_panel("closest_due", "Closest Due Jobs"), 1, 0, 1, 1)
            panels.attach(self._dashboard_text_panel("upcoming_actions", "Upcoming Actions"), 0, 1, 1, 1)
            panels.attach(self._dashboard_text_panel("recent_jobs", "Recently Added"), 1, 1, 1, 1)
            outer.pack_start(panels, True, True, 0)

            footer = self._dash_label("Tip: keep due dates and follow-up actions current so Sentinel Jobs can surface what needs attention first.", "sentinel-muted")
            outer.pack_start(footer, False, False, 0)
            return outer

        def _set_text_panel(self, key: str, text: str) -> None:
            widget = self.dashboard_widgets.get(key)
            if widget and hasattr(widget, "get_buffer"):
                widget.get_buffer().set_text(text)

        def populate_dashboard(self, data: Dict[str, Any]) -> None:
            metric_values = {
                "active_jobs": data.get("total_active_jobs", 0),
                "archived_jobs": data.get("archived_jobs", 0),
                "due_jobs": data.get("jobs_due_next_14_days", 0),
                "due_actions": data.get("actions_due_next_14_days", 0),
                "overdue_actions": data.get("overdue_actions", 0),
                "interviews": data.get("upcoming_interviews", 0),
            }
            for key, value in metric_values.items():
                if key in self.dashboard_widgets:
                    self.dashboard_widgets[key].set_text(str(value))
            posture = self.dashboard_widgets.get("posture")
            if posture:
                posture.set_text(f"{APP_NAME} v{VERSION} • Local-only • No network • No telemetry • Database: {data.get('database', '')}")
            counts = data.get("status_counts", {})
            for status in STATUSES:
                label = self.dashboard_status_labels.get(status)
                if label:
                    label.set_text(str(counts.get(status, 0)))

            def fmt_job_rows(rows: List[Dict[str, Any]], include_due: bool = False) -> str:
                if not rows:
                    return "No records yet."
                lines = []
                for r in rows:
                    due = f" | due {r.get('due_date', '')}" if include_due and r.get('due_date') else ""
                    lines.append(f"{r.get('job_code','')} | fit {r.get('fit_score',0):>3} | P{r.get('priority',0)} | {r.get('company','')[:18]} | {r.get('title','')[:38]} [{r.get('status','')}]{due}")
                return "\n".join(lines)

            def fmt_action_rows(rows: List[Dict[str, Any]]) -> str:
                if not rows:
                    return "No upcoming actions."
                lines = []
                for r in rows:
                    lines.append(f"{r.get('due_date','')} | {r.get('job_code','')} | {r.get('action_type','').replace('_',' ')} | {r.get('description','')[:48]}")
                return "\n".join(lines)

            self._set_text_panel("top_fit", fmt_job_rows(data.get("top_fit_jobs", [])))
            self._set_text_panel("closest_due", fmt_job_rows(data.get("closest_due_jobs", []), include_due=True))
            self._set_text_panel("upcoming_actions", fmt_action_rows(data.get("upcoming_actions", [])))
            self._set_text_panel("recent_jobs", fmt_job_rows(data.get("recent_jobs", [])))

        def manual_text(self) -> str:
            return (
                f"{APP_NAME} v{VERSION}\n\n"
                "Sentinel-themed local-first job/opportunity tracker for applications, side work, interviews, follow-ups, contacts, companies, skills, and document packs.\n\n"
                "GUI hotkeys:\n"
                "  Ctrl+Q  Close Sentinel Jobs immediately.\n\n"
                "Layout notes:\n"
                "  v0.9.0 uses centered page frames so fullscreen windows keep dashboard cards, forms, and output panels proportional instead of stretching across the entire display.\n"
                "  Sidebar navigation is guarded and stack animation remains disabled for reliable MATE/GTK3 page revisits.\n\n"
                "Theme status:\n"
                "  AEGIS Dark / Sentinel Gold GTK theme: active\n"
                "  Text fields: themed\n"
                "  Drop-down menus: themed\n"
                "  Menu bar and buttons: themed\n"
                "  Scrollbars: non-overlay, visible MATE-friendly styling\n\n"
                "CLI examples:\n"
                "  sentinel-jobs add 'Junior Network Technician' --company 'Example Co' --fit-score 80 --due-date 2026-07-15\n"
                "  sentinel-jobs update-status JOB-0001 applied\n"
                "  sentinel-jobs schedule-interview JOB-0001 --type phone --date 2026-07-20 --time 10:00 --interviewer 'Hiring Manager'\n"
                "  sentinel-jobs interview-prep JOB-0001\n"
                "  sentinel-jobs search --query technician --fit-min 70 --sort fit\n"
                "  sentinel-jobs save-view 'High Fit' --fit-min 70 --sort fit\n"
                "  sentinel-jobs pipeline-board\n"
                "  sentinel-jobs company-add 'Example Co' --industry Technology\n"
                "  sentinel-jobs contact-add 'Jane Recruiter' --company 'Example Co' --type recruiter\n"
                "  sentinel-jobs set-profile-skills 'linux, networking, customer service' --level 4\n"
                "  sentinel-jobs add-job-skills JOB-0001 'linux, python, customer service' --required-level 3\n"
                "  sentinel-jobs skill-match JOB-0001\n"
                "  sentinel-jobs skill-gaps\n"
                "  sentinel-jobs export-application-pack JOB-0001\n"
                "  sentinel-jobs export-interview-pack JOB-0001\n"
                "  sentinel-jobs export-calendar-csv\n"
                "  sentinel-jobs health-json\n\n"
                "Network: disabled. Telemetry: disabled. Storage: local SQLite only.\n"
            )

        def _jobs_tab(self):
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
            box.set_border_width(10)
            self._class(box, "sentinel-page")
            grid = Gtk.Grid(column_spacing=8, row_spacing=8)
            grid.set_hexpand(True)
            self.title_entry = Gtk.Entry(); self.title_entry.set_placeholder_text("Job title / opportunity")
            self.company_entry = Gtk.Entry(); self.company_entry.set_placeholder_text("Company / client")
            self.location_entry = Gtk.Entry(); self.location_entry.set_placeholder_text("Location")
            self.source_entry = Gtk.Entry(); self.source_entry.set_placeholder_text("Source")
            self.due_entry = Gtk.Entry(); self.due_entry.set_placeholder_text("Due date YYYY-MM-DD")
            self.job_type_combo = make_combo(JOB_TYPES, "employment")
            self.remote_mode_combo = make_combo(REMOTE_MODES, "")
            self.status_combo = make_combo(STATUSES, "saved")
            self.fit_spin = Gtk.SpinButton.new_with_range(0, 100, 1); self.fit_spin.set_value(50)
            self.priority_spin = Gtk.SpinButton.new_with_range(1, 5, 1); self.priority_spin.set_value(3)
            self.notes_entry = Gtk.Entry(); self.notes_entry.set_placeholder_text("Notes")
            rows = [
                ("Title", self.title_entry),
                ("Company", self.company_entry),
                ("Job Type", self.job_type_combo),
                ("Status", self.status_combo),
                ("Location", self.location_entry),
                ("Remote", self.remote_mode_combo),
                ("Source", self.source_entry),
                ("Due", self.due_entry),
                ("Fit", self.fit_spin),
                ("Priority", self.priority_spin),
                ("Notes", self.notes_entry),
            ]
            for i, (label, widget) in enumerate(rows):
                grid.attach(Gtk.Label(label=label, xalign=1), 0, i, 1, 1)
                grid.attach(widget, 1, i, 1, 1)
            add_btn = Gtk.Button(label="Add Job")
            add_btn.connect("clicked", self.on_add_job)
            refresh_btn = Gtk.Button(label="Refresh")
            refresh_btn.connect("clicked", lambda *_: self.refresh_all())
            btn_box = Gtk.Box(spacing=8)
            btn_box.pack_start(add_btn, False, False, 0)
            btn_box.pack_start(refresh_btn, False, False, 0)
            self.jobs_text = Gtk.TextView(); self.jobs_text.set_editable(False); self.jobs_text.set_monospace(True)
            box.pack_start(grid, False, False, 0)
            box.pack_start(btn_box, False, False, 0)
            box.pack_start(self._scrolled(self.jobs_text), True, True, 0)
            return box

        def _actions_tab(self):
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
            box.set_border_width(10)
            self._class(box, "sentinel-page")
            grid = Gtk.Grid(column_spacing=8, row_spacing=8)
            grid.set_hexpand(True)
            self.action_job_entry = Gtk.Entry(); self.action_job_entry.set_placeholder_text("JOB-0001")
            self.action_type_combo = make_combo(ACTION_TYPES, "follow_up")
            self.action_desc_entry = Gtk.Entry(); self.action_desc_entry.set_placeholder_text("Action description")
            self.action_due_entry = Gtk.Entry(); self.action_due_entry.set_placeholder_text("YYYY-MM-DD")
            for i, (label, widget) in enumerate([("Job", self.action_job_entry), ("Type", self.action_type_combo), ("Description", self.action_desc_entry), ("Due", self.action_due_entry)]):
                grid.attach(Gtk.Label(label=label, xalign=1), 0, i, 1, 1)
                grid.attach(widget, 1, i, 1, 1)
            add_btn = Gtk.Button(label="Add Action")
            add_btn.connect("clicked", self.on_add_action)
            refresh_btn = Gtk.Button(label="Refresh")
            refresh_btn.connect("clicked", lambda *_: self.refresh_all())
            btns = Gtk.Box(spacing=8)
            btns.pack_start(add_btn, False, False, 0)
            btns.pack_start(refresh_btn, False, False, 0)
            self.actions_text = Gtk.TextView(); self.actions_text.set_editable(False); self.actions_text.set_monospace(True)
            box.pack_start(grid, False, False, 0)
            box.pack_start(btns, False, False, 0)
            box.pack_start(self._scrolled(self.actions_text), True, True, 0)
            return box


        def _interviews_tab(self):
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
            box.set_border_width(10)
            self._class(box, "sentinel-page")
            grid = Gtk.Grid(column_spacing=8, row_spacing=8)
            grid.set_hexpand(True)
            self.interview_job_entry = Gtk.Entry(); self.interview_job_entry.set_placeholder_text("JOB-0001")
            self.interview_type_entry = Gtk.Entry(); self.interview_type_entry.set_placeholder_text("phone / video / in_person / technical")
            self.interview_date_entry = Gtk.Entry(); self.interview_date_entry.set_placeholder_text("YYYY-MM-DD")
            self.interview_time_entry = Gtk.Entry(); self.interview_time_entry.set_placeholder_text("HH:MM")
            self.interview_mode_entry = Gtk.Entry(); self.interview_mode_entry.set_placeholder_text("phone / video / onsite")
            self.interview_location_entry = Gtk.Entry(); self.interview_location_entry.set_placeholder_text("Address, room, or local note")
            self.interview_interviewer_entry = Gtk.Entry(); self.interview_interviewer_entry.set_placeholder_text("Interviewer / contact")
            self.interview_notes_entry = Gtk.Entry(); self.interview_notes_entry.set_placeholder_text("Prep notes")
            self.interview_questions_entry = Gtk.Entry(); self.interview_questions_entry.set_placeholder_text("Questions to ask")
            rows = [
                ("Job", self.interview_job_entry),
                ("Type", self.interview_type_entry),
                ("Date", self.interview_date_entry),
                ("Time", self.interview_time_entry),
                ("Mode", self.interview_mode_entry),
                ("Location", self.interview_location_entry),
                ("Interviewer", self.interview_interviewer_entry),
                ("Prep Notes", self.interview_notes_entry),
                ("Questions", self.interview_questions_entry),
            ]
            for i, (label, widget) in enumerate(rows):
                grid.attach(Gtk.Label(label=label, xalign=1), 0, i, 1, 1)
                grid.attach(widget, 1, i, 1, 1)
            schedule_btn = Gtk.Button(label="Schedule Interview")
            schedule_btn.connect("clicked", self.on_schedule_interview)
            prep_btn = Gtk.Button(label="Build Prep View")
            prep_btn.connect("clicked", self.on_interview_prep)
            pack_btn = Gtk.Button(label="Export Interview Pack")
            pack_btn.connect("clicked", self.on_export_interview_pack)
            export_csv_btn = Gtk.Button(label="Export Interviews CSV")
            export_csv_btn.connect("clicked", lambda *_: self.message(str(export_interviews_csv(conn))))
            refresh_btn = Gtk.Button(label="Refresh")
            refresh_btn.connect("clicked", lambda *_: self.refresh_all())
            btns = Gtk.Box(spacing=8)
            for b in [schedule_btn, prep_btn, pack_btn, export_csv_btn, refresh_btn]:
                btns.pack_start(b, False, False, 0)
            self.interviews_text = Gtk.TextView(); self.interviews_text.set_editable(False); self.interviews_text.set_monospace(True)
            self._class(self.interviews_text, "sentinel-output")
            box.pack_start(grid, False, False, 0)
            box.pack_start(btns, False, False, 0)
            box.pack_start(self._scrolled(self.interviews_text), True, True, 0)
            return box



        def _search_views_tab(self):
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
            box.set_border_width(10)
            self._class(box, "sentinel-page")
            title = self._dash_label("Search / Saved Views / Pipeline", "sentinel-title")
            box.pack_start(title, False, False, 0)
            grid = Gtk.Grid(column_spacing=8, row_spacing=8)
            grid.set_hexpand(True)
            self.search_query_entry = Gtk.Entry(); self.search_query_entry.set_placeholder_text("Search title, company, code, notes, location, source, contact")
            self.search_company_entry = Gtk.Entry(); self.search_company_entry.set_placeholder_text("Company/client contains")
            self.search_status_combo = make_combo([""] + STATUSES, "")
            self.search_type_combo = make_combo([""] + JOB_TYPES, "")
            self.search_remote_combo = make_combo(REMOTE_MODES, "")
            self.search_fit_spin = Gtk.SpinButton.new_with_range(0, 100, 1); self.search_fit_spin.set_value(0)
            self.search_priority_spin = Gtk.SpinButton.new_with_range(0, 5, 1); self.search_priority_spin.set_value(0)
            self.search_due_spin = Gtk.SpinButton.new_with_range(0, 365, 1); self.search_due_spin.set_value(0)
            self.search_view_name_entry = Gtk.Entry(); self.search_view_name_entry.set_placeholder_text("Saved view name")
            rows = [
                ("Query", self.search_query_entry),
                ("Company", self.search_company_entry),
                ("Status", self.search_status_combo),
                ("Job Type", self.search_type_combo),
                ("Remote", self.search_remote_combo),
                ("Fit Min", self.search_fit_spin),
                ("Priority Max", self.search_priority_spin),
                ("Due Days", self.search_due_spin),
                ("View Name", self.search_view_name_entry),
            ]
            for i, (label, widget) in enumerate(rows):
                grid.attach(Gtk.Label(label=label, xalign=1), 0, i, 1, 1)
                grid.attach(widget, 1, i, 1, 1)
            btns = Gtk.Box(spacing=8)
            for label, callback in [
                ("Search", self.on_search_jobs),
                ("Pipeline Board", self.on_pipeline_board),
                ("Save View", self.on_save_view),
                ("List Views", self.on_list_views),
                ("Run View", self.on_run_view),
                ("Export Pipeline JSON", lambda *_: self.message(str(export_pipeline_json(conn)))),
            ]:
                b = Gtk.Button(label=label)
                b.connect("clicked", callback)
                btns.pack_start(b, False, False, 0)
            self.search_text = Gtk.TextView(); self.search_text.set_editable(False); self.search_text.set_monospace(True)
            box.pack_start(grid, False, False, 0)
            box.pack_start(btns, False, False, 0)
            box.pack_start(self._scrolled(self.search_text), True, True, 0)
            return box

        def _search_args(self):
            return argparse.Namespace(
                query=self.search_query_entry.get_text().strip() or None,
                company=self.search_company_entry.get_text().strip() or None,
                status=combo_value(self.search_status_combo) or None,
                job_type=combo_value(self.search_type_combo) or None,
                remote_mode=combo_value(self.search_remote_combo) or None,
                fit_min=int(self.search_fit_spin.get_value()) or None,
                priority_max=int(self.search_priority_spin.get_value()) or None,
                due_days=int(self.search_due_spin.get_value()) or None,
                include_archived=False,
                sort="fit",
                limit=100,
            )

        def on_search_jobs(self, *_):
            try:
                self.set_textview(self.search_text, format_jobs(list_jobs(conn, self._search_args())))
            except Exception as e:
                self.message(f"Error: {e}")

        def on_pipeline_board(self, *_):
            try:
                self.set_textview(self.search_text, format_pipeline_board(pipeline_board_data(conn)))
            except Exception as e:
                self.message(f"Error: {e}")

        def on_save_view(self, *_):
            try:
                ns = self._search_args()
                ns.name = self.search_view_name_entry.get_text().strip() or "GUI Search"
                ns.sort = "fit"
                self.message(save_view(conn, ns))
                self.set_textview(self.search_text, format_saved_views(list_saved_views(conn)))
            except Exception as e:
                self.message(f"Error: {e}")

        def on_list_views(self, *_):
            try:
                self.set_textview(self.search_text, format_saved_views(list_saved_views(conn)))
            except Exception as e:
                self.message(f"Error: {e}")

        def on_run_view(self, *_):
            try:
                name = self.search_view_name_entry.get_text().strip()
                if not name:
                    self.message("Enter a saved view name first.")
                    return
                self.set_textview(self.search_text, format_jobs(run_saved_view(conn, name)))
            except Exception as e:
                self.message(f"Error: {e}")

        def _contacts_companies_tab(self):
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
            box.set_border_width(10)
            self._class(box, "sentinel-page")
            grid = Gtk.Grid(column_spacing=8, row_spacing=8)
            self.company_name_entry = Gtk.Entry(); self.company_name_entry.set_placeholder_text("Company / client name")
            self.company_industry_entry = Gtk.Entry(); self.company_industry_entry.set_placeholder_text("Industry")
            self.company_email_entry = Gtk.Entry(); self.company_email_entry.set_placeholder_text("Company email")
            self.company_follow_entry = Gtk.Entry(); self.company_follow_entry.set_placeholder_text("YYYY-MM-DD follow-up")
            self.contact_name_entry = Gtk.Entry(); self.contact_name_entry.set_placeholder_text("Contact name")
            self.contact_company_entry = Gtk.Entry(); self.contact_company_entry.set_placeholder_text("Company")
            self.contact_type_combo = make_combo(CONTACT_TYPES, "recruiter")
            self.contact_email_entry = Gtk.Entry(); self.contact_email_entry.set_placeholder_text("Contact email")
            self.contact_follow_entry = Gtk.Entry(); self.contact_follow_entry.set_placeholder_text("YYYY-MM-DD follow-up")
            widgets = [
                ("Company", self.company_name_entry), ("Industry", self.company_industry_entry),
                ("Company Email", self.company_email_entry), ("Company Follow-up", self.company_follow_entry),
                ("Contact", self.contact_name_entry), ("Contact Company", self.contact_company_entry),
                ("Contact Type", self.contact_type_combo), ("Contact Email", self.contact_email_entry),
                ("Contact Follow-up", self.contact_follow_entry),
            ]
            for i, (label, widget) in enumerate(widgets):
                grid.attach(Gtk.Label(label=label, xalign=1), 0, i, 1, 1)
                grid.attach(widget, 1, i, 1, 1)
            btns = Gtk.Box(spacing=8)
            for label, callback in [
                ("Add / Update Company", self.on_add_company),
                ("Add Contact", self.on_add_contact),
                ("List Companies", self.on_list_companies),
                ("List Contacts", self.on_list_contacts),
                ("Networking Due", self.on_networking_due),
                ("Export Contacts JSON", lambda *_: self.message(str(export_contacts_json(conn)))),
            ]:
                b = Gtk.Button(label=label); b.connect("clicked", callback); btns.pack_start(b, False, False, 0)
            self.contacts_text = Gtk.TextView(); self.contacts_text.set_editable(False); self.contacts_text.set_monospace(True)
            box.pack_start(grid, False, False, 0)
            box.pack_start(btns, False, False, 0)
            box.pack_start(self._scrolled(self.contacts_text), True, True, 0)
            return box

        def on_add_company(self, *_):
            try:
                if not self.company_name_entry.get_text().strip():
                    self.message("Company name is required.")
                    return
                ns = argparse.Namespace(name=self.company_name_entry.get_text(), industry=self.company_industry_entry.get_text(), website="", phone="", email=self.company_email_entry.get_text(), address="", notes="GUI entry", follow_up=self.company_follow_entry.get_text())
                self.message(company_add(conn, ns))
                self.set_textview(self.contacts_text, format_companies(list_companies(conn, argparse.Namespace(query=None, due_days=None, limit=100))))
            except Exception as e:
                self.message(f"Error: {e}")

        def on_add_contact(self, *_):
            try:
                if not self.contact_name_entry.get_text().strip():
                    self.message("Contact name is required.")
                    return
                ns = argparse.Namespace(name=self.contact_name_entry.get_text(), company=self.contact_company_entry.get_text() or self.company_name_entry.get_text(), type=combo_value(self.contact_type_combo) or "other", title="", email=self.contact_email_entry.get_text(), phone="", source="GUI", notes="GUI entry", follow_up=self.contact_follow_entry.get_text())
                self.message(contact_add(conn, ns))
                self.set_textview(self.contacts_text, format_contacts(list_contacts(conn, argparse.Namespace(query=None, company=None, type=None, due_days=None, limit=100))))
            except Exception as e:
                self.message(f"Error: {e}")

        def on_list_companies(self, *_):
            try:
                self.set_textview(self.contacts_text, format_companies(list_companies(conn, argparse.Namespace(query=None, due_days=None, limit=100))))
            except Exception as e:
                self.message(f"Error: {e}")

        def on_list_contacts(self, *_):
            try:
                self.set_textview(self.contacts_text, format_contacts(list_contacts(conn, argparse.Namespace(query=None, company=None, type=None, due_days=None, limit=100))))
            except Exception as e:
                self.message(f"Error: {e}")

        def on_networking_due(self, *_):
            try:
                self.set_textview(self.contacts_text, format_networking_due(networking_due(conn, 14)))
            except Exception as e:
                self.message(f"Error: {e}")


        def _skills_match_tab(self):
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
            box.set_border_width(10)
            self._class(box, "sentinel-page")
            grid = Gtk.Grid(column_spacing=8, row_spacing=8)
            self.profile_skills_entry = Gtk.Entry(); self.profile_skills_entry.set_placeholder_text("Your skills: linux, networking, python")
            self.profile_level_spin = Gtk.SpinButton.new_with_range(1, 5, 1); self.profile_level_spin.set_value(3)
            self.skill_job_entry = Gtk.Entry(); self.skill_job_entry.set_placeholder_text("JOB-0001")
            self.job_skills_entry = Gtk.Entry(); self.job_skills_entry.set_placeholder_text("Required skills: linux, customer service, tickets")
            self.job_skill_level_spin = Gtk.SpinButton.new_with_range(1, 5, 1); self.job_skill_level_spin.set_value(3)
            self.job_skill_importance_spin = Gtk.SpinButton.new_with_range(1, 5, 1); self.job_skill_importance_spin.set_value(3)
            widgets = [
                ("Profile Skills", self.profile_skills_entry), ("Profile Level", self.profile_level_spin),
                ("Job Code", self.skill_job_entry), ("Job Skills", self.job_skills_entry),
                ("Required Level", self.job_skill_level_spin), ("Importance", self.job_skill_importance_spin),
            ]
            for i, (label, widget) in enumerate(widgets):
                grid.attach(Gtk.Label(label=label, xalign=1), 0, i, 1, 1)
                grid.attach(widget, 1, i, 1, 1)
            btns = Gtk.Box(spacing=8)
            for label, callback in [
                ("Save Profile Skills", self.on_save_profile_skills),
                ("Add Job Skills", self.on_add_job_skills),
                ("Skill Match", self.on_skill_match),
                ("Skill Gaps", self.on_skill_gaps),
                ("Export Match JSON", lambda *_: self.message(str(export_skill_match_json(conn)))),
                ("Refresh", lambda *_: self.refresh_all()),
            ]:
                b = Gtk.Button(label=label); b.connect("clicked", callback); btns.pack_start(b, False, False, 0)
            self.skills_text = Gtk.TextView(); self.skills_text.set_editable(False); self.skills_text.set_monospace(True)
            box.pack_start(grid, False, False, 0)
            box.pack_start(btns, False, False, 0)
            box.pack_start(self._scrolled(self.skills_text), True, True, 0)
            return box

        def on_save_profile_skills(self, *_):
            try:
                skills = self.profile_skills_entry.get_text().strip()
                if not skills:
                    self.message("Enter at least one profile skill.")
                    return
                ns = argparse.Namespace(skills=skills, level=int(self.profile_level_spin.get_value()), notes="GUI profile skill")
                self.message(set_profile_skills(conn, ns))
                self.set_textview(self.skills_text, format_profile_skills(list_profile_skills(conn)))
            except Exception as e:
                self.message(f"Error: {e}")

        def on_add_job_skills(self, *_):
            try:
                job = self.skill_job_entry.get_text().strip()
                skills = self.job_skills_entry.get_text().strip()
                if not job or not skills:
                    self.message("Enter job code and at least one required skill.")
                    return
                ns = argparse.Namespace(job=job, skills=skills, required_level=int(self.job_skill_level_spin.get_value()), importance=int(self.job_skill_importance_spin.get_value()), source="GUI", notes="GUI job skill")
                self.message(add_job_skills(conn, ns))
                self.set_textview(self.skills_text, format_job_skills(list_job_skills(conn, job)))
            except Exception as e:
                self.message(f"Error: {e}")

        def on_skill_match(self, *_):
            try:
                job = self.skill_job_entry.get_text().strip()
                if not job:
                    self.message("Enter a job code first.")
                    return
                self.set_textview(self.skills_text, format_skill_match(skill_match_data(conn, job)))
            except Exception as e:
                self.message(f"Error: {e}")

        def on_skill_gaps(self, *_):
            try:
                self.set_textview(self.skills_text, format_skill_gaps(skill_gaps_data(conn, 50)))
            except Exception as e:
                self.message(f"Error: {e}")

        def _documents_tab(self):
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
            box.set_border_width(10)
            self._class(box, "sentinel-page")
            grid = Gtk.Grid(column_spacing=8, row_spacing=8)
            self.doc_job_entry = Gtk.Entry(); self.doc_job_entry.set_placeholder_text("JOB-0001")
            self.doc_path_entry = Gtk.Entry(); self.doc_path_entry.set_placeholder_text("/path/to/resume.pdf or cover_letter.pdf")
            self.doc_type_combo = make_combo(DOCUMENT_TYPES, "resume")
            self.doc_notes_entry = Gtk.Entry(); self.doc_notes_entry.set_placeholder_text("Document notes")
            for i, (label, widget) in enumerate([("Job", self.doc_job_entry), ("Type", self.doc_type_combo), ("Path", self.doc_path_entry), ("Notes", self.doc_notes_entry)]):
                grid.attach(Gtk.Label(label=label, xalign=1), 0, i, 1, 1)
                grid.attach(widget, 1, i, 1, 1)
            add_btn = Gtk.Button(label="Add Document")
            add_btn.connect("clicked", self.on_add_document)
            check_btn = Gtk.Button(label="Check Job Documents")
            check_btn.connect("clicked", self.on_document_check)
            pack_btn = Gtk.Button(label="Export Application Pack")
            pack_btn.connect("clicked", self.on_export_application_pack)
            export_csv_btn = Gtk.Button(label="Export Documents CSV")
            export_csv_btn.connect("clicked", lambda *_: self.message(str(export_documents_csv(conn))))
            export_json_btn = Gtk.Button(label="Export Documents JSON")
            export_json_btn.connect("clicked", lambda *_: self.message(str(export_documents_json(conn))))
            refresh_btn = Gtk.Button(label="Refresh")
            refresh_btn.connect("clicked", lambda *_: self.refresh_all())
            btns = Gtk.Box(spacing=8)
            for b in [add_btn, check_btn, pack_btn, export_csv_btn, export_json_btn, refresh_btn]:
                btns.pack_start(b, False, False, 0)
            self.documents_text = Gtk.TextView(); self.documents_text.set_editable(False); self.documents_text.set_monospace(True)
            box.pack_start(grid, False, False, 0)
            box.pack_start(btns, False, False, 0)
            box.pack_start(self._scrolled(self.documents_text), True, True, 0)
            return box

        def _manual_tab(self):
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
            box.set_border_width(10)
            self._class(box, "sentinel-page")
            box.pack_start(self._dash_label("Sentinel Jobs Manual", "sentinel-hero-title"), False, False, 0)
            box.pack_start(self._dash_label("Hotkeys, local workflow, CLI examples, and v0.9 layout notes.", "sentinel-subtitle"), False, False, 0)
            hotkeys = self._dash_label("Hotkey: Ctrl+Q closes the program", "sentinel-hotkey-label")
            box.pack_start(hotkeys, False, False, 0)
            self.manual_textview = Gtk.TextView()
            self.manual_textview.set_editable(False)
            self.manual_textview.set_cursor_visible(False)
            self.manual_textview.set_monospace(True)
            self.manual_textview.get_buffer().set_text(self.manual_text())
            self._class(self.manual_textview, "sentinel-output", "sentinel-manual-text")
            box.pack_start(self._scrolled(self.manual_textview), True, True, 0)
            btns = Gtk.Box(spacing=8)
            for label, callback in [
                ("Refresh", lambda *_: self.refresh_all()),
                ("Health JSON", lambda *_: self.set_textview(self.manual_textview, json.dumps(health_json(conn), indent=2))),
                ("Close Program", lambda *_: Gtk.main_quit()),
            ]:
                b = Gtk.Button(label=label)
                b.connect("clicked", callback)
                btns.pack_start(b, False, False, 0)
            box.pack_start(btns, False, False, 0)
            return box

        def _export_tab(self):
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
            box.set_border_width(10)
            self._class(box, "sentinel-page")
            for label, callback in [
                ("Export Jobs CSV", lambda *_: self.message(str(export_jobs_csv(conn)))),
                ("Export Jobs JSON", lambda *_: self.message(str(export_jobs_json(conn)))),
                ("Export Calendar Bridge CSV", lambda *_: self.message(str(export_calendar_csv(conn)))),
                ("Backup Local Database", lambda *_: self.message(backup_database_report(conn))),
                ("Install Desktop Launcher", lambda *_: self.message(install_desktop_launcher())),
                ("Refresh Dashboard", lambda *_: self.refresh_all()),
            ]:
                b = Gtk.Button(label=label); b.connect("clicked", callback); box.pack_start(b, False, False, 0)
            self.export_status = Gtk.Label(xalign=0)
            self.export_status.set_selectable(True)
            box.pack_start(self.export_status, False, False, 0)
            return box

        def set_textview(self, tv, text: str) -> None:
            tv.get_buffer().set_text(text)

        def message(self, text: str) -> None:
            self.export_status.set_text(text) if hasattr(self, "export_status") else None
            self.refresh_all()

        def refresh_all(self) -> None:
            init_db(conn)
            self.populate_dashboard(dashboard_data(conn))
            self.set_textview(self.jobs_text, format_jobs(list_jobs(conn, argparse.Namespace(include_archived=False, status=None, company=None, query=None, limit=100))))
            self.set_textview(self.actions_text, format_actions(list_actions(conn, argparse.Namespace(all=False, job=None, type=None, due_days=30, limit=100))))
            if hasattr(self, "interviews_text"):
                self.set_textview(self.interviews_text, format_interviews(list_interviews(conn, argparse.Namespace(all=False, job=None, upcoming=False, limit=100))))
            if hasattr(self, "contacts_text"):
                self.set_textview(self.contacts_text, format_contacts(list_contacts(conn, argparse.Namespace(query=None, company=None, type=None, due_days=None, limit=100))))
            if hasattr(self, "skills_text"):
                self.set_textview(self.skills_text, format_profile_skills(list_profile_skills(conn)))
            if hasattr(self, "documents_text"):
                self.set_textview(self.documents_text, format_documents(list_documents(conn, argparse.Namespace(job=None, type=None, limit=100))))

        def on_add_job(self, *_):
            title = self.title_entry.get_text().strip()
            if not title:
                self.message("Title is required.")
                return
            ns = argparse.Namespace(
                code=None, code_prefix=None, title=title, company=self.company_entry.get_text(),
                job_type=combo_value(self.job_type_combo) or "employment", location=self.location_entry.get_text(),
                remote_mode=combo_value(self.remote_mode_combo), source=self.source_entry.get_text(), source_url="",
                salary_min=0, salary_max=0, currency="AUD", status=combo_value(self.status_combo) or "saved",
                priority=int(self.priority_spin.get_value()), fit_score=int(self.fit_spin.get_value()), applied_date="",
                due_date=self.due_entry.get_text(), contact_name="", contact_email="", notes=self.notes_entry.get_text(),
                create_action="Apply / follow up" if self.due_entry.get_text() else ""
            )
            try:
                self.message(add_job(conn, ns))
                self.title_entry.set_text(""); self.company_entry.set_text(""); self.location_entry.set_text(""); self.source_entry.set_text(""); self.due_entry.set_text(""); self.notes_entry.set_text("")
                self.status_combo.set_active(STATUSES.index("saved")); self.job_type_combo.set_active(JOB_TYPES.index("employment")); self.remote_mode_combo.set_active(0)
            except Exception as e:
                self.message(f"Error: {e}")


        def on_schedule_interview(self, *_):
            try:
                job = self.interview_job_entry.get_text().strip()
                if not job:
                    self.message("Enter a job code first.")
                    return
                ns = argparse.Namespace(
                    job=job,
                    type=self.interview_type_entry.get_text() or "interview",
                    date=self.interview_date_entry.get_text(),
                    time=self.interview_time_entry.get_text(),
                    mode=self.interview_mode_entry.get_text(),
                    location=self.interview_location_entry.get_text(),
                    interviewer=self.interview_interviewer_entry.get_text(),
                    status="scheduled",
                    prep_notes=self.interview_notes_entry.get_text(),
                    questions=self.interview_questions_entry.get_text(),
                    create_action=True,
                )
                self.message(schedule_interview(conn, ns))
            except Exception as e:
                self.message(f"Error: {e}")

        def on_interview_prep(self, *_):
            try:
                job = self.interview_job_entry.get_text().strip()
                if not job:
                    self.message("Enter a job code first.")
                    return
                self.set_textview(self.interviews_text, format_interview_prep(interview_prep_data(conn, job)))
            except Exception as e:
                self.message(f"Error: {e}")

        def on_export_interview_pack(self, *_):
            try:
                job = self.interview_job_entry.get_text().strip()
                if not job:
                    self.message("Enter a job code first.")
                    return
                self.message(str(export_interview_pack(conn, job)))
            except Exception as e:
                self.message(f"Error: {e}")


        def on_add_document(self, *_):
            try:
                ns = argparse.Namespace(job=self.doc_job_entry.get_text(), path=self.doc_path_entry.get_text(), type=combo_value(self.doc_type_combo) or "other", notes=self.doc_notes_entry.get_text())
                self.message(add_document(conn, ns))
                self.doc_path_entry.set_text(""); self.doc_notes_entry.set_text("")
            except Exception as e:
                self.message(f"Error: {e}")

        def on_document_check(self, *_):
            try:
                job = self.doc_job_entry.get_text().strip()
                if not job:
                    self.message("Enter a job code first.")
                    return
                self.set_textview(self.documents_text, format_document_check(document_check_data(conn, job)))
            except Exception as e:
                self.message(f"Error: {e}")

        def on_export_application_pack(self, *_):
            try:
                job = self.doc_job_entry.get_text().strip()
                if not job:
                    self.message("Enter a job code first.")
                    return
                self.message(str(export_application_pack(conn, job)))
            except Exception as e:
                self.message(f"Error: {e}")

        def on_add_action(self, *_):
            try:
                ns = argparse.Namespace(job=self.action_job_entry.get_text(), type=combo_value(self.action_type_combo) or "other", description=self.action_desc_entry.get_text(), due_date=self.action_due_entry.get_text(), notes="")
                self.message(add_action(conn, ns))
                self.action_desc_entry.set_text(""); self.action_due_entry.set_text("")
            except Exception as e:
                self.message(f"Error: {e}")

    win = App()
    win.connect("destroy", Gtk.main_quit)
    win.show_all()
    Gtk.main()
    return 0

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="sentinel-jobs", description="Sentinel Jobs local-first job/opportunity tracker")
    sub = parser.add_subparsers(dest="command")
    sub.add_parser("init")
    sub.add_parser("gui")
    sub.add_parser("dashboard")
    sub.add_parser("manual")
    sub.add_parser("health-json")
    sub.add_parser("aegis-status")
    sub.add_parser("self-test")
    sub.add_parser("next-code")
    p = sub.add_parser("set-code-prefix"); p.add_argument("prefix")
    p = sub.add_parser("add")
    p.add_argument("title")
    p.add_argument("--code")
    p.add_argument("--code-prefix")
    p.add_argument("--company", default="")
    p.add_argument("--job-type", default="employment", choices=JOB_TYPES)
    p.add_argument("--location", default="")
    p.add_argument("--remote-mode", default="")
    p.add_argument("--source", default="")
    p.add_argument("--source-url", default="")
    p.add_argument("--salary-min", type=float, default=0)
    p.add_argument("--salary-max", type=float, default=0)
    p.add_argument("--currency", default=DEFAULT_CURRENCY)
    p.add_argument("--status", default="saved")
    p.add_argument("--priority", type=int, default=3)
    p.add_argument("--fit-score", type=int, default=0)
    p.add_argument("--applied-date", default="")
    p.add_argument("--due-date", default="")
    p.add_argument("--contact-name", default="")
    p.add_argument("--contact-email", default="")
    p.add_argument("--notes", default="")
    p.add_argument("--skills", default="", help="Comma-separated required skills for this job")
    p.add_argument("--skill-level", type=int, default=3, help="Required skill level 1-5 for --skills")
    p.add_argument("--skill-importance", type=int, default=3, help="Skill importance 1-5 for --skills")
    p.add_argument("--create-action", default="")
    p = sub.add_parser("list")
    p.add_argument("--status")
    p.add_argument("--company")
    p.add_argument("--query")
    p.add_argument("--job-type", choices=JOB_TYPES)
    p.add_argument("--remote-mode")
    p.add_argument("--priority-max", type=int)
    p.add_argument("--fit-min", type=int)
    p.add_argument("--due-days", type=int)
    p.add_argument("--sort", choices=SORT_OPTIONS, default="priority")
    p.add_argument("--limit", type=int, default=50)
    p.add_argument("--include-archived", action="store_true")
    p = sub.add_parser("search")
    p.add_argument("--status")
    p.add_argument("--company")
    p.add_argument("--query")
    p.add_argument("--job-type", choices=JOB_TYPES)
    p.add_argument("--remote-mode")
    p.add_argument("--priority-max", type=int)
    p.add_argument("--fit-min", type=int)
    p.add_argument("--due-days", type=int)
    p.add_argument("--sort", choices=SORT_OPTIONS, default="fit")
    p.add_argument("--limit", type=int, default=50)
    p.add_argument("--include-archived", action="store_true")
    p = sub.add_parser("pipeline-board")
    p.add_argument("--limit-per-status", type=int, default=8)
    p = sub.add_parser("export-pipeline-json")
    p.add_argument("--output")
    p.add_argument("--limit-per-status", type=int, default=50)
    p = sub.add_parser("save-view")
    p.add_argument("name")
    p.add_argument("--status")
    p.add_argument("--company", default="")
    p.add_argument("--query", default="")
    p.add_argument("--job-type", choices=JOB_TYPES)
    p.add_argument("--remote-mode", default="")
    p.add_argument("--priority-max", type=int, default=0)
    p.add_argument("--fit-min", type=int, default=0)
    p.add_argument("--due-days", type=int, default=0)
    p.add_argument("--sort", choices=SORT_OPTIONS, default="priority")
    p.add_argument("--limit", type=int, default=50)
    p.add_argument("--include-archived", action="store_true")
    sub.add_parser("views")
    p = sub.add_parser("run-view"); p.add_argument("name")
    p = sub.add_parser("delete-view"); p.add_argument("name")
    p = sub.add_parser("export-saved-views-json"); p.add_argument("--output")
    p = sub.add_parser("view"); p.add_argument("job")
    p = sub.add_parser("update-status"); p.add_argument("job"); p.add_argument("status", choices=STATUSES); p.add_argument("--applied-date", default="")
    p = sub.add_parser("archive"); p.add_argument("job")
    p = sub.add_parser("unarchive"); p.add_argument("job")
    p = sub.add_parser("add-action")
    p.add_argument("job")
    p.add_argument("--type", default="other")
    p.add_argument("--description", required=True)
    p.add_argument("--due-date", default="")
    p.add_argument("--notes", default="")
    p = sub.add_parser("actions")
    p.add_argument("--job")
    p.add_argument("--type")
    p.add_argument("--due-days", type=int)
    p.add_argument("--limit", type=int, default=50)
    p.add_argument("--all", action="store_true")
    p = sub.add_parser("due")
    p.add_argument("--days", type=int, default=14)
    p = sub.add_parser("interviews")
    p.add_argument("--job")
    p.add_argument("--upcoming", action="store_true")
    p.add_argument("--all", action="store_true")
    p.add_argument("--limit", type=int, default=50)
    p = sub.add_parser("complete-action"); p.add_argument("action_id", type=int); p.add_argument("--notes", default="")
    p = sub.add_parser("schedule-interview")
    p.add_argument("job")
    p.add_argument("--type", default="interview")
    p.add_argument("--date", default="")
    p.add_argument("--time", default="")
    p.add_argument("--mode", default="")
    p.add_argument("--location", default="")
    p.add_argument("--interviewer", default="")
    p.add_argument("--status", default="scheduled")
    p.add_argument("--prep-notes", default="")
    p.add_argument("--questions", default="")
    p.add_argument("--no-action", dest="create_action", action="store_false")
    p.set_defaults(create_action=True)
    p = sub.add_parser("interview-list")
    p.add_argument("--job")
    p.add_argument("--upcoming", action="store_true")
    p.add_argument("--all", action="store_true")
    p.add_argument("--limit", type=int, default=50)
    p = sub.add_parser("interview-prep"); p.add_argument("job"); p.add_argument("--json", action="store_true")
    p = sub.add_parser("export-interview-pack"); p.add_argument("job"); p.add_argument("--output")
    p = sub.add_parser("export-interviews-csv"); p.add_argument("--output")
    p = sub.add_parser("export-interviews-json"); p.add_argument("--output")
    p = sub.add_parser("add-document"); p.add_argument("job"); p.add_argument("path"); p.add_argument("--type", default="other", choices=DOCUMENT_TYPES); p.add_argument("--notes", default="")
    p = sub.add_parser("documents"); p.add_argument("--job"); p.add_argument("--type", choices=DOCUMENT_TYPES); p.add_argument("--limit", type=int, default=100)
    p = sub.add_parser("document-check"); p.add_argument("job"); p.add_argument("--json", action="store_true")
    p = sub.add_parser("set-required-docs"); p.add_argument("types", help="Comma-separated document types, e.g. resume,cover_letter,certificate")
    p = sub.add_parser("export-application-pack"); p.add_argument("job"); p.add_argument("--output"); p.add_argument("--no-copy", action="store_true")
    p = sub.add_parser("export-documents-csv"); p.add_argument("--output")
    p = sub.add_parser("export-documents-json"); p.add_argument("--output")
    p = sub.add_parser("company-add")
    p.add_argument("name")
    p.add_argument("--industry", default="")
    p.add_argument("--website", default="")
    p.add_argument("--phone", default="")
    p.add_argument("--email", default="")
    p.add_argument("--address", default="")
    p.add_argument("--notes", default="")
    p.add_argument("--follow-up", default="")
    p = sub.add_parser("companies")
    p.add_argument("--query")
    p.add_argument("--due-days", type=int)
    p.add_argument("--limit", type=int, default=100)
    p = sub.add_parser("company-view"); p.add_argument("company")
    p = sub.add_parser("contact-add")
    p.add_argument("name")
    p.add_argument("--company", default="")
    p.add_argument("--type", default="other", choices=CONTACT_TYPES)
    p.add_argument("--title", default="")
    p.add_argument("--email", default="")
    p.add_argument("--phone", default="")
    p.add_argument("--source", default="")
    p.add_argument("--notes", default="")
    p.add_argument("--follow-up", default="")
    p = sub.add_parser("contacts")
    p.add_argument("--query")
    p.add_argument("--company")
    p.add_argument("--type", choices=CONTACT_TYPES)
    p.add_argument("--due-days", type=int)
    p.add_argument("--limit", type=int, default=100)
    p = sub.add_parser("contact-log")
    p.add_argument("contact")
    p.add_argument("--type", default="note", choices=CONTACT_EVENT_TYPES)
    p.add_argument("--date", default="")
    p.add_argument("--summary", required=True)
    p.add_argument("--next-follow-up", default="")
    p.add_argument("--job", default="")
    p = sub.add_parser("contact-history")
    p.add_argument("--contact")
    p.add_argument("--company")
    p.add_argument("--limit", type=int, default=100)
    p = sub.add_parser("networking-due")
    p.add_argument("--days", type=int, default=14)
    p.add_argument("--json", action="store_true")
    p = sub.add_parser("export-companies-csv"); p.add_argument("--output")
    p = sub.add_parser("export-companies-json"); p.add_argument("--output")
    p = sub.add_parser("export-contacts-csv"); p.add_argument("--output")
    p = sub.add_parser("export-contacts-json"); p.add_argument("--output")
    p = sub.add_parser("set-profile-skills")
    p.add_argument("skills", help="Comma-separated profile skills")
    p.add_argument("--level", type=int, default=3)
    p.add_argument("--notes", default="")
    sub.add_parser("profile-skills")
    p = sub.add_parser("add-job-skills")
    p.add_argument("job")
    p.add_argument("skills", help="Comma-separated required job skills")
    p.add_argument("--required-level", type=int, default=3)
    p.add_argument("--importance", type=int, default=3)
    p.add_argument("--source", default="manual")
    p.add_argument("--notes", default="")
    p = sub.add_parser("job-skills"); p.add_argument("job")
    p = sub.add_parser("skill-match"); p.add_argument("job"); p.add_argument("--json", action="store_true")
    p = sub.add_parser("skill-gaps"); p.add_argument("--limit", type=int, default=50); p.add_argument("--json", action="store_true")
    p = sub.add_parser("export-skill-match-json"); p.add_argument("--output")
    p = sub.add_parser("export-skill-match-csv"); p.add_argument("--output")
    p = sub.add_parser("export-profile-skills-json"); p.add_argument("--output")
    p = sub.add_parser("export-csv"); p.add_argument("--output")
    p = sub.add_parser("export-json"); p.add_argument("--output")
    p = sub.add_parser("export-calendar-csv"); p.add_argument("--output")
    p = sub.add_parser("import-csv"); p.add_argument("path")
    p = sub.add_parser("backup"); p.add_argument("--output")
    p = sub.add_parser("stable-lock-report"); p.add_argument("--json", action="store_true")
    p = sub.add_parser("audit-report"); p.add_argument("--json", action="store_true"); p.add_argument("--limit", type=int, default=50)
    p = sub.add_parser("export-audit-json"); p.add_argument("--output")
    p = sub.add_parser("export-audit-csv"); p.add_argument("--output")
    p = sub.add_parser("export-v1-bundle"); p.add_argument("--output")
    p = sub.add_parser("restore-backup"); p.add_argument("backup_path"); p.add_argument("--confirm", default="")
    sub.add_parser("install-desktop-launcher")
    return parser


def main(argv: Optional[List[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if not args.command:
        args.command = "dashboard"
    if args.command == "self-test":
        print(self_test())
        return 0
    if args.command == "gui":
        return run_gui()
    conn = connect()
    init_db(conn)
    try:
        cmd = args.command
        if cmd == "init":
            print(f"Initialised {APP_NAME} database: {default_db_path()}")
        elif cmd in ("dashboard",):
            print(format_dashboard(dashboard_data(conn)))
        elif cmd == "manual":
            print(f"{APP_NAME} v{VERSION} manual\n\nHotkeys:\n  Ctrl+Q  Close the GUI.\n\nMain workflows:\n  add/list/update jobs, schedule interviews, track actions, manage application documents, save views, build pipeline board, track contacts/companies, and compare job skill requirements against profile skills.\n\nLayout:\n  GUI pages use a completed responsive F.O.R.G.E-style layout with no main horizontal scrollbar on MATE/GTK3.\n")
        elif cmd in ("health-json", "aegis-status"):
            print(json.dumps(health_json(conn), indent=2))
        elif cmd == "next-code":
            print(next_job_code(conn))
        elif cmd == "set-code-prefix":
            set_meta(conn, "job_code_prefix", args.prefix.strip().upper())
            print(f"Default job code prefix set to {args.prefix.strip().upper()}")
        elif cmd == "add":
            print(add_job(conn, args))
        elif cmd in ("list", "search"):
            print(format_jobs(list_jobs(conn, args)))
        elif cmd == "pipeline-board":
            print(format_pipeline_board(pipeline_board_data(conn, args.limit_per_status)))
        elif cmd == "export-pipeline-json":
            print(export_pipeline_json(conn, args.output, args.limit_per_status))
        elif cmd == "save-view":
            print(save_view(conn, args))
        elif cmd == "views":
            print(format_saved_views(list_saved_views(conn)))
        elif cmd == "run-view":
            print(format_jobs(run_saved_view(conn, args.name)))
        elif cmd == "delete-view":
            print(delete_saved_view(conn, args.name))
        elif cmd == "export-saved-views-json":
            print(export_saved_views_json(conn, args.output))
        elif cmd == "view":
            print(view_job(conn, args.job))
        elif cmd == "update-status":
            print(update_status(conn, args.job, args.status, args.applied_date))
        elif cmd == "archive":
            print(archive_job(conn, args.job, 1))
        elif cmd == "unarchive":
            print(archive_job(conn, args.job, 0))
        elif cmd == "add-action":
            print(add_action(conn, args))
        elif cmd == "actions":
            print(format_actions(list_actions(conn, args)))
        elif cmd == "due":
            args.due_days = args.days; args.all = False; args.job = None; args.type = None; args.limit = 100
            print(format_actions(list_actions(conn, args)))
        elif cmd == "interviews":
            print(format_interviews(list_interviews(conn, args)))
        elif cmd == "complete-action":
            print(complete_action(conn, args.action_id, args.notes))
        elif cmd == "schedule-interview":
            print(schedule_interview(conn, args))
        elif cmd == "interview-list":
            print(format_interviews(list_interviews(conn, args)))
        elif cmd == "interview-prep":
            data = interview_prep_data(conn, args.job)
            print(json.dumps(data, indent=2) if args.json else format_interview_prep(data))
        elif cmd == "export-interview-pack":
            print(export_interview_pack(conn, args.job, args.output))
        elif cmd == "export-interviews-csv":
            print(export_interviews_csv(conn, args.output))
        elif cmd == "export-interviews-json":
            print(export_interviews_json(conn, args.output))
        elif cmd == "add-document":
            print(add_document(conn, args))
        elif cmd == "documents":
            print(format_documents(list_documents(conn, args)))
        elif cmd == "document-check":
            data = document_check_data(conn, args.job)
            print(json.dumps(data, indent=2) if args.json else format_document_check(data))
        elif cmd == "set-required-docs":
            print(set_required_docs(conn, args.types))
        elif cmd == "export-application-pack":
            print(export_application_pack(conn, args.job, args.output, copy_files=not args.no_copy))
        elif cmd == "export-documents-csv":
            print(export_documents_csv(conn, args.output))
        elif cmd == "export-documents-json":
            print(export_documents_json(conn, args.output))
        elif cmd == "company-add":
            print(company_add(conn, args))
        elif cmd == "companies":
            print(format_companies(list_companies(conn, args)))
        elif cmd == "company-view":
            print(company_view(conn, args.company))
        elif cmd == "contact-add":
            print(contact_add(conn, args))
        elif cmd == "contacts":
            print(format_contacts(list_contacts(conn, args)))
        elif cmd == "contact-log":
            print(contact_log(conn, args))
        elif cmd == "contact-history":
            print(format_contact_history(contact_history(conn, args)))
        elif cmd == "networking-due":
            data = networking_due(conn, args.days)
            print(json.dumps(data, indent=2) if args.json else format_networking_due(data))
        elif cmd == "export-companies-csv":
            print(export_companies_csv(conn, args.output))
        elif cmd == "export-companies-json":
            print(export_companies_json(conn, args.output))
        elif cmd == "export-contacts-csv":
            print(export_contacts_csv(conn, args.output))
        elif cmd == "export-contacts-json":
            print(export_contacts_json(conn, args.output))
        elif cmd == "set-profile-skills":
            print(set_profile_skills(conn, args))
        elif cmd == "profile-skills":
            print(format_profile_skills(list_profile_skills(conn)))
        elif cmd == "add-job-skills":
            print(add_job_skills(conn, args))
        elif cmd == "job-skills":
            print(format_job_skills(list_job_skills(conn, args.job)))
        elif cmd == "skill-match":
            data = skill_match_data(conn, args.job)
            print(json.dumps(data, indent=2) if args.json else format_skill_match(data))
        elif cmd == "skill-gaps":
            data = skill_gaps_data(conn, args.limit)
            print(json.dumps(data, indent=2) if args.json else format_skill_gaps(data))
        elif cmd == "export-skill-match-json":
            print(export_skill_match_json(conn, args.output))
        elif cmd == "export-skill-match-csv":
            print(export_skill_match_csv(conn, args.output))
        elif cmd == "export-profile-skills-json":
            print(export_profile_skills_json(conn, args.output))
        elif cmd == "export-csv":
            print(export_jobs_csv(conn, args.output))
        elif cmd == "export-json":
            print(export_jobs_json(conn, args.output))
        elif cmd == "export-calendar-csv":
            print(export_calendar_csv(conn, args.output))
        elif cmd == "import-csv":
            print(import_jobs_csv(conn, args.path))
        elif cmd == "backup":
            print(backup_database_report(conn, args.output))
        elif cmd == "stable-lock-report":
            data = stable_lock_report_data(conn)
            print(json.dumps(data, indent=2) if args.json else format_stable_lock_report(data))
        elif cmd == "audit-report":
            data = audit_report_data(conn, args.limit)
            print(json.dumps(data, indent=2) if args.json else format_audit_report(data))
        elif cmd == "export-audit-json":
            print(export_audit_json(conn, args.output))
        elif cmd == "export-audit-csv":
            print(export_audit_csv(conn, args.output))
        elif cmd == "export-v1-bundle":
            print(export_v1_bundle(conn, args.output))
        elif cmd == "restore-backup":
            print(restore_backup_database(conn, args.backup_path, args.confirm))
        elif cmd == "install-desktop-launcher":
            print(install_desktop_launcher())
        else:
            parser.error(f"unknown command: {cmd}")
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        try:
            conn.close()
        except Exception:
            pass
        return 2
    try:
        conn.close()
    except Exception:
        pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
