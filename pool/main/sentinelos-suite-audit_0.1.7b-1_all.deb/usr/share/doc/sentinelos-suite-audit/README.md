SentinelOS v0.1.7b suite audit catalog.
