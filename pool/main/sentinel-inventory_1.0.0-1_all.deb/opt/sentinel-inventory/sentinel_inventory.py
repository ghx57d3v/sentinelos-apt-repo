#!/usr/bin/env python3
"""Sentinel Inventory v1.0.0

Local-first household / business inventory manager for SentinelOS.
No network access. No telemetry. SQLite-backed. Fast scanner, expiry rotation, Ledger/Pantry bridge ready, and v1 stable locked.
"""
from __future__ import annotations

import argparse
import csv
import datetime as _dt
import html
import json
import os
import shutil
import time
import sqlite3
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

APP_NAME = "Sentinel Inventory"
APP_ID = "sentinel-inventory"
VERSION = "1.0.0"
SCHEMA_VERSION = 3
DEFAULT_DB_DIR = Path.home() / ".local" / "share" / "sentinel_inventory"
DEFAULT_DB_PATH = DEFAULT_DB_DIR / "sentinel_inventory.db"
DEFAULT_EXPORT_DIR = Path.home() / "AEGIS_Vault" / "03_Project_Records" / "Sentinel" / "Inventory"
DEFAULT_LABEL_DIR = DEFAULT_EXPORT_DIR / "Labels"
DEFAULT_BRIDGE_DIR = DEFAULT_EXPORT_DIR / "Bridges"
DEFAULT_EXPIRY_WARNING_DAYS = 30
DEFAULT_SKU_PREFIX = "INV"
DEFAULT_SKU_PADDING = 4
DEFAULT_SCANNER_SUFFIX = "enter"
DEFAULT_SCAN_QUANTITY = 1.0
DEFAULT_SCANNER_FAST_MODE = "lookup"
DEFAULT_SCANNER_DEBOUNCE_SECONDS = 1.0
SCAN_MODES = {"lookup", "restock", "consume", "adjust", "transfer"}

AEGIS_DARK = "#0b0d10"
AEGIS_PANEL = "#14181d"
AEGIS_CARD = "#1b2027"
AEGIS_GOLD = "#E19B00"
AEGIS_CYAN = "#03C8FF"
AEGIS_TEXT = "#f0f3f5"
AEGIS_MUTED = "#a9b0b7"
AEGIS_RED = "#e05252"
AEGIS_GREEN = "#4caf50"


def now_iso() -> str:
    return _dt.datetime.now().replace(microsecond=0).isoformat()


def coerce_float(value: Any, default: float = 0.0) -> float:
    if value is None or value == "":
        return default
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def coerce_int(value: Any, default: int = 0) -> int:
    if value is None or value == "":
        return default
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return default


def normalize_sku_prefix(value: Any, default: str = DEFAULT_SKU_PREFIX) -> str:
    """Return a safe uppercase SKU prefix for generated inventory codes."""
    text = str(value or "").strip().upper()
    safe = "".join(ch for ch in text if ch.isalnum() or ch in {"-", "_"})
    return safe or default


def normalize_sku_padding(value: Any, default: int = DEFAULT_SKU_PADDING) -> int:
    """Keep SKU padding sensible for readable local inventory numbers."""
    return max(3, min(8, coerce_int(value, default)))


def normalize_scan_code(value: Any) -> str:
    """Normalize keyboard-wedge scanner input without altering meaningful barcode data."""
    text = str(value or "").strip()
    # USB HID scanners often append Enter, Tab, or whitespace; strip outer control characters only.
    return "".join(ch for ch in text if ch not in {"\r", "\n", "\t"}).strip()


def scan_reference(code: str) -> str:
    return f"scan:{normalize_scan_code(code)}"


def safe_filename(value: Any, fallback: str = "item") -> str:
    """Create a conservative filename stem from local inventory data."""
    text = str(value or "").strip() or fallback
    safe = "".join(ch if ch.isalnum() or ch in {"-", "_", "."} else "_" for ch in text)
    safe = safe.strip("._-")
    return safe or fallback


def item_label_payload(row: Any) -> str:
    """Stable local QR payload URI used by Sentinel Inventory labels."""
    sku = str(row["sku"] if row and row["sku"] is not None else "").strip()
    return f"sentinel-inventory://item/{sku}"


def item_scan_code(row: Any) -> str:
    """Prefer the physical barcode, then SKU, then serial for human-readable label scan text."""
    for key in ("barcode", "sku", "serial_number"):
        value = str(row[key] if row and row[key] is not None else "").strip()
        if value:
            return value
    return ""


def fmt_money(value: Any) -> str:
    return f"${coerce_float(value):,.2f}"


def parse_date(value: Any) -> Optional[_dt.date]:
    """Parse common local date strings without guessing ambiguous data."""
    if value is None:
        return None
    text = str(value).strip()
    if not text:
        return None
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%Y/%m/%d"):
        try:
            return _dt.datetime.strptime(text, fmt).date()
        except ValueError:
            continue
    try:
        return _dt.date.fromisoformat(text[:10])
    except ValueError:
        return None


def today() -> _dt.date:
    return _dt.date.today()


def days_until(value: Any) -> Optional[int]:
    parsed = parse_date(value)
    if not parsed:
        return None
    return (parsed - today()).days


def desktop_entry_text() -> str:
    return """[Desktop Entry]
Type=Application
Name=Sentinel Inventory
GenericName=Inventory Manager
Comment=Program 115 v1 stable local-first stock, asset, barcode scanner, expiry, warranty, service, repair, audit, backup, and bridge inventory manager
Exec=sentinel-inventory-gui
Icon=sentinel-inventory
Terminal=false
Categories=Office;Utility;Database;X-SentinelOS;
Keywords=inventory;stock;assets;parts;tools;barcode;scanner;qr;expiry;expiration;best-before;freshness;rotation;warranty;service;maintenance;audit;backup;restore;SentinelOS;AEGIS;
StartupNotify=true
"""


def install_desktop_launcher(dest_dir: Optional[Path] = None) -> Path:
    """Install a per-user desktop shortcut for MATE/XDG desktops."""
    desktop_dir = Path(dest_dir or (Path.home() / "Desktop")).expanduser()
    desktop_dir.mkdir(parents=True, exist_ok=True)
    dest = desktop_dir / "Sentinel Inventory.desktop"
    source_candidates = [
        Path("/usr/share/applications/sentinel-inventory.desktop"),
        Path("/usr/local/share/applications/sentinel-inventory.desktop"),
        Path(__file__).resolve().parent.parent.parent / "sentinel-inventory.desktop",
        Path.cwd() / "sentinel-inventory.desktop",
    ]
    for candidate in source_candidates:
        if candidate.exists():
            shutil.copy2(candidate, dest)
            break
    else:
        dest.write_text(desktop_entry_text(), encoding="utf-8")
    dest.chmod(0o755)
    # Also provide/update the user's local application entry for source installs.
    local_apps = Path.home() / ".local" / "share" / "applications"
    try:
        local_apps.mkdir(parents=True, exist_ok=True)
        local_entry = local_apps / "sentinel-inventory.desktop"
        shutil.copy2(dest, local_entry)
        local_entry.chmod(0o644)
    except OSError:
        pass
    if shutil.which("gio"):
        os.system(f"gio set {json.dumps(str(dest))} metadata::trusted true >/dev/null 2>&1")
    return dest


def ensure_parent(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)


def find_icon_path() -> Optional[Path]:
    """Return the best available Sentinel Inventory icon path for desktop/window use."""
    candidates = [
        Path("/usr/share/icons/hicolor/256x256/apps/sentinel-inventory.png"),
        Path("/usr/share/pixmaps/sentinel-inventory.png"),
        Path(__file__).resolve().parent.parent.parent / "assets" / "sentinel-inventory.png",
        Path.cwd() / "assets" / "sentinel-inventory.png",
    ]
    for candidate in candidates:
        try:
            if candidate.exists():
                return candidate
        except OSError:
            continue
    return None


@dataclass
class Item:
    id: Optional[int]
    sku: str
    name: str
    category: str = "General"
    location: str = "Unsorted"
    quantity: float = 0.0
    unit: str = "ea"
    low_stock_threshold: float = 0.0
    cost_each: float = 0.0
    sale_price_each: float = 0.0
    vendor: str = ""
    serial_number: str = ""
    barcode: str = ""
    warranty_expiry: str = ""
    expiry_date: str = ""
    condition: str = "Good"
    status: str = "active"
    notes: str = ""


class InventoryDB:
    def __init__(self, db_path: Optional[Path] = None) -> None:
        self.db_path = Path(db_path or DEFAULT_DB_PATH).expanduser()
        ensure_parent(self.db_path)
        self.conn = sqlite3.connect(str(self.db_path))
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys = ON")
        self.migrate()

    def close(self) -> None:
        self.conn.close()

    def migrate(self) -> None:
        cur = self.conn.cursor()
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            )
            """
        )
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                sku TEXT UNIQUE NOT NULL,
                name TEXT NOT NULL,
                category TEXT NOT NULL DEFAULT 'General',
                location TEXT NOT NULL DEFAULT 'Unsorted',
                quantity REAL NOT NULL DEFAULT 0,
                unit TEXT NOT NULL DEFAULT 'ea',
                low_stock_threshold REAL NOT NULL DEFAULT 0,
                cost_each REAL NOT NULL DEFAULT 0,
                sale_price_each REAL NOT NULL DEFAULT 0,
                vendor TEXT NOT NULL DEFAULT '',
                serial_number TEXT NOT NULL DEFAULT '',
                barcode TEXT NOT NULL DEFAULT '',
                warranty_expiry TEXT NOT NULL DEFAULT '',
                expiry_date TEXT NOT NULL DEFAULT '',
                condition TEXT NOT NULL DEFAULT 'Good',
                status TEXT NOT NULL DEFAULT 'active',
                notes TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
            """
        )
        cur.execute("CREATE INDEX IF NOT EXISTS idx_items_name ON items(name)")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_items_category ON items(category)")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_items_location ON items(location)")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_items_status ON items(status)")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_items_barcode ON items(barcode)")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_items_serial_number ON items(serial_number)")
        existing_item_columns = {r[1] for r in cur.execute("PRAGMA table_info(items)").fetchall()}
        if "expiry_date" not in existing_item_columns:
            cur.execute("ALTER TABLE items ADD COLUMN expiry_date TEXT NOT NULL DEFAULT ''")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_items_expiry_date ON items(expiry_date)")
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS movements (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                item_id INTEGER,
                sku TEXT NOT NULL DEFAULT '',
                movement_type TEXT NOT NULL,
                qty_delta REAL NOT NULL DEFAULT 0,
                qty_after REAL NOT NULL DEFAULT 0,
                note TEXT NOT NULL DEFAULT '',
                reference TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL,
                FOREIGN KEY(item_id) REFERENCES items(id) ON DELETE SET NULL
            )
            """
        )
        cur.execute("CREATE INDEX IF NOT EXISTS idx_movements_item_id ON movements(item_id)")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_movements_created_at ON movements(created_at)")
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS service_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                item_id INTEGER,
                sku TEXT NOT NULL DEFAULT '',
                service_type TEXT NOT NULL DEFAULT 'service',
                description TEXT NOT NULL DEFAULT '',
                cost REAL NOT NULL DEFAULT 0,
                provider TEXT NOT NULL DEFAULT '',
                performed_at TEXT NOT NULL DEFAULT '',
                next_due TEXT NOT NULL DEFAULT '',
                reference TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL,
                FOREIGN KEY(item_id) REFERENCES items(id) ON DELETE SET NULL
            )
            """
        )
        cur.execute("CREATE INDEX IF NOT EXISTS idx_service_records_item_id ON service_records(item_id)")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_service_records_next_due ON service_records(next_due)")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_service_records_performed_at ON service_records(performed_at)")
        cur.execute(
            "INSERT OR REPLACE INTO settings(key, value) VALUES (?, ?)",
            ("schema_version", str(SCHEMA_VERSION)),
        )
        cur.execute(
            "INSERT OR IGNORE INTO settings(key, value) VALUES (?, ?)",
            ("created_by", f"{APP_NAME} v{VERSION}"),
        )
        cur.execute(
            "INSERT OR IGNORE INTO settings(key, value) VALUES (?, ?)",
            ("sku_prefix", DEFAULT_SKU_PREFIX),
        )
        cur.execute(
            "INSERT OR IGNORE INTO settings(key, value) VALUES (?, ?)",
            ("sku_padding", str(DEFAULT_SKU_PADDING)),
        )
        cur.execute(
            "INSERT OR IGNORE INTO settings(key, value) VALUES (?, ?)",
            ("scanner_suffix", DEFAULT_SCANNER_SUFFIX),
        )
        cur.execute(
            "INSERT OR IGNORE INTO settings(key, value) VALUES (?, ?)",
            ("scanner_default_quantity", str(DEFAULT_SCAN_QUANTITY)),
        )
        cur.execute(
            "INSERT OR IGNORE INTO settings(key, value) VALUES (?, ?)",
            ("scanner_fast_mode", DEFAULT_SCANNER_FAST_MODE),
        )
        cur.execute(
            "INSERT OR IGNORE INTO settings(key, value) VALUES (?, ?)",
            ("scanner_debounce_seconds", str(DEFAULT_SCANNER_DEBOUNCE_SECONDS)),
        )
        self.conn.commit()

    def init_db(self) -> Path:
        self.migrate()
        return self.db_path

    def get_setting(self, key: str, default: str = "") -> str:
        row = self.conn.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
        return str(row["value"]) if row else default

    def set_setting(self, key: str, value: str) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO settings(key, value) VALUES (?, ?)",
            (key, str(value)),
        )
        self.conn.commit()

    def sku_prefix(self) -> str:
        return normalize_sku_prefix(self.get_setting("sku_prefix", DEFAULT_SKU_PREFIX))

    def sku_padding(self) -> int:
        return normalize_sku_padding(self.get_setting("sku_padding", str(DEFAULT_SKU_PADDING)))

    def set_sku_prefix(self, prefix: str) -> str:
        clean = normalize_sku_prefix(prefix)
        self.set_setting("sku_prefix", clean)
        return clean

    def scanner_fast_mode(self) -> str:
        mode = self.get_setting("scanner_fast_mode", DEFAULT_SCANNER_FAST_MODE).strip().lower()
        return mode if mode in SCAN_MODES else DEFAULT_SCANNER_FAST_MODE

    def scanner_default_quantity(self) -> float:
        return coerce_float(self.get_setting("scanner_default_quantity", str(DEFAULT_SCAN_QUANTITY)), DEFAULT_SCAN_QUANTITY)

    def scanner_debounce_seconds(self) -> float:
        return max(0.0, coerce_float(self.get_setting("scanner_debounce_seconds", str(DEFAULT_SCANNER_DEBOUNCE_SECONDS)), DEFAULT_SCANNER_DEBOUNCE_SECONDS))

    def set_scanner_defaults(
        self,
        mode: str = "",
        quantity: Optional[float] = None,
        debounce_seconds: Optional[float] = None,
        suffix: str = "",
    ) -> Dict[str, Any]:
        if mode:
            clean_mode = mode.strip().lower()
            if clean_mode not in SCAN_MODES:
                raise ValueError(f"Unsupported scanner mode: {mode}")
            self.set_setting("scanner_fast_mode", clean_mode)
        if quantity is not None:
            self.set_setting("scanner_default_quantity", str(max(0.0, coerce_float(quantity, DEFAULT_SCAN_QUANTITY))))
        if debounce_seconds is not None:
            self.set_setting("scanner_debounce_seconds", str(max(0.0, coerce_float(debounce_seconds, DEFAULT_SCANNER_DEBOUNCE_SECONDS))))
        if suffix:
            self.set_setting("scanner_suffix", str(suffix).strip().lower())
        return {
            "scanner_fast_mode": self.scanner_fast_mode(),
            "scanner_default_quantity": self.scanner_default_quantity(),
            "scanner_debounce_seconds": self.scanner_debounce_seconds(),
            "scanner_suffix": self.get_setting("scanner_suffix", DEFAULT_SCANNER_SUFFIX),
        }

    def next_sku(self, prefix: str = "", padding: Optional[int] = None) -> str:
        clean_prefix = normalize_sku_prefix(prefix or self.sku_prefix())
        width = normalize_sku_padding(padding if padding is not None else self.sku_padding())
        rows = self.conn.execute(
            "SELECT sku FROM items WHERE sku LIKE ?",
            (f"{clean_prefix}-%",),
        ).fetchall()
        highest = 0
        needle = f"{clean_prefix}-"
        for row in rows:
            sku = str(row["sku"] or "").strip().upper()
            if not sku.startswith(needle):
                continue
            suffix = sku[len(needle):]
            if suffix.isdigit():
                highest = max(highest, int(suffix))
        return f"{clean_prefix}-{highest + 1:0{width}d}"

    def sku_exists(self, sku: str) -> bool:
        return self.get_item_by_sku(str(sku).strip()) is not None

    def add_item(self, item: Item, movement_note: str = "Initial item creation") -> int:
        item.sku = item.sku.strip() or self.next_sku()
        item.name = item.name.strip()
        if not item.name:
            raise ValueError("Item name is required")
        ts = now_iso()
        cur = self.conn.execute(
            """
            INSERT INTO items(
                sku, name, category, location, quantity, unit, low_stock_threshold,
                cost_each, sale_price_each, vendor, serial_number, barcode,
                warranty_expiry, expiry_date, condition, status, notes, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                item.sku,
                item.name,
                item.category or "General",
                item.location or "Unsorted",
                coerce_float(item.quantity),
                item.unit or "ea",
                coerce_float(item.low_stock_threshold),
                coerce_float(item.cost_each),
                coerce_float(item.sale_price_each),
                item.vendor or "",
                item.serial_number or "",
                item.barcode or "",
                item.warranty_expiry or "",
                item.expiry_date or "",
                item.condition or "Good",
                item.status or "active",
                item.notes or "",
                ts,
                ts,
            ),
        )
        item_id = int(cur.lastrowid)
        self.record_movement(item_id, item.sku, "create", coerce_float(item.quantity), coerce_float(item.quantity), movement_note)
        self.conn.commit()
        return item_id

    def update_item(self, item_id: int, fields: Dict[str, Any], note: str = "Item details updated") -> None:
        allowed = {
            "sku", "name", "category", "location", "quantity", "unit", "low_stock_threshold",
            "cost_each", "sale_price_each", "vendor", "serial_number", "barcode",
            "warranty_expiry", "expiry_date", "condition", "status", "notes",
        }
        clean = {k: v for k, v in fields.items() if k in allowed}
        if not clean:
            return
        before = self.get_item(item_id)
        if not before:
            raise ValueError(f"Item id {item_id} not found")
        clean["updated_at"] = now_iso()
        assignments = ", ".join(f"{k} = ?" for k in clean.keys())
        values = list(clean.values()) + [item_id]
        self.conn.execute(f"UPDATE items SET {assignments} WHERE id = ?", values)
        after = self.get_item(item_id)
        if after:
            delta = coerce_float(after["quantity"]) - coerce_float(before["quantity"])
            self.record_movement(item_id, after["sku"], "update", delta, coerce_float(after["quantity"]), note)
        self.conn.commit()

    def delete_item(self, item_id: int) -> None:
        row = self.get_item(item_id)
        if not row:
            return
        self.record_movement(item_id, row["sku"], "delete", -coerce_float(row["quantity"]), 0, "Item deleted")
        self.conn.execute("DELETE FROM items WHERE id = ?", (item_id,))
        self.conn.commit()

    def archive_item(self, item_id: int, archived: bool = True) -> None:
        self.update_item(item_id, {"status": "archived" if archived else "active"}, "Item archived" if archived else "Item restored")

    def adjust_quantity(self, item_id: int, delta: float, movement_type: str = "adjust", note: str = "", reference: str = "") -> float:
        row = self.get_item(item_id)
        if not row:
            raise ValueError(f"Item id {item_id} not found")
        new_qty = coerce_float(row["quantity"]) + coerce_float(delta)
        ts = now_iso()
        self.conn.execute("UPDATE items SET quantity = ?, updated_at = ? WHERE id = ?", (new_qty, ts, item_id))
        self.record_movement(item_id, row["sku"], movement_type, coerce_float(delta), new_qty, note, reference)
        self.conn.commit()
        return new_qty

    def get_item(self, item_id: int) -> Optional[sqlite3.Row]:
        return self.conn.execute("SELECT * FROM items WHERE id = ?", (item_id,)).fetchone()

    def get_item_by_sku(self, sku: str) -> Optional[sqlite3.Row]:
        return self.conn.execute("SELECT * FROM items WHERE sku = ?", (sku,)).fetchone()

    def get_item_by_barcode(self, barcode: str) -> Optional[sqlite3.Row]:
        code = normalize_scan_code(barcode)
        if not code:
            return None
        return self.conn.execute("SELECT * FROM items WHERE barcode = ?", (code,)).fetchone()

    def get_item_by_serial(self, serial: str) -> Optional[sqlite3.Row]:
        code = normalize_scan_code(serial)
        if not code:
            return None
        return self.conn.execute("SELECT * FROM items WHERE serial_number = ?", (code,)).fetchone()

    def resolve_scan(self, code: str) -> Optional[sqlite3.Row]:
        scan = normalize_scan_code(code)
        if not scan:
            return None
        # Scanner workflow checks barcode first, then SKU, then serial number.
        return self.get_item_by_barcode(scan) or self.get_item_by_sku(scan) or self.get_item_by_serial(scan)

    def scan_lookup(self, code: str) -> Dict[str, Any]:
        scan = normalize_scan_code(code)
        row = self.resolve_scan(scan)
        if not row:
            return {"found": False, "scan_code": scan, "message": "No matching barcode, SKU, or serial number found."}
        match_type = "barcode" if scan == str(row["barcode"] or "") else "sku" if scan == str(row["sku"] or "") else "serial_number"
        return {
            "found": True,
            "scan_code": scan,
            "match_type": match_type,
            "item": dict(row),
        }

    def scan_movement(self, code: str, quantity: float = 1.0, mode: str = "restock", note: str = "", reference: str = "") -> Dict[str, Any]:
        scan = normalize_scan_code(code)
        row = self.resolve_scan(scan)
        if not row:
            return {"found": False, "scan_code": scan, "message": "No matching barcode, SKU, or serial number found."}
        qty = coerce_float(quantity, DEFAULT_SCAN_QUANTITY)
        if mode == "consume":
            delta = -abs(qty)
            movement_type = "scan_consume"
        elif mode == "adjust":
            delta = qty
            movement_type = "scan_adjust"
        else:
            delta = abs(qty)
            movement_type = "scan_restock"
        ref = reference or scan_reference(scan)
        final_note = note or f"USB scanner {mode} via {scan}"
        after = self.adjust_quantity(int(row["id"]), delta, movement_type, final_note, ref)
        updated = self.get_item(int(row["id"]))
        return {
            "found": True,
            "scan_code": scan,
            "movement_type": movement_type,
            "qty_delta": delta,
            "qty_after": after,
            "item": dict(updated) if updated else dict(row),
        }

    def scan_transfer(self, code: str, location: str, note: str = "", reference: str = "") -> Dict[str, Any]:
        scan = normalize_scan_code(code)
        row = self.resolve_scan(scan)
        if not row:
            return {"found": False, "scan_code": scan, "message": "No matching barcode, SKU, or serial number found."}
        target = str(location or "").strip()
        if not target:
            raise ValueError("Target location is required for scan transfer.")
        before_location = str(row["location"] or "")
        self.update_item(int(row["id"]), {"location": target}, note or f"Scanner transfer from {before_location or 'Unsorted'} to {target}")
        updated = self.get_item(int(row["id"]))
        self.record_movement(
            int(row["id"]),
            row["sku"],
            "scan_transfer",
            0,
            coerce_float(row["quantity"]),
            note or f"USB scanner transfer from {before_location or 'Unsorted'} to {target}",
            reference or scan_reference(scan),
        )
        self.conn.commit()
        return {
            "found": True,
            "scan_code": scan,
            "movement_type": "scan_transfer",
            "from_location": before_location,
            "to_location": target,
            "qty_delta": 0,
            "qty_after": coerce_float(row["quantity"]),
            "item": dict(updated) if updated else dict(row),
        }

    def fast_scan(
        self,
        code: str,
        mode: str = "",
        quantity: Optional[float] = None,
        location: str = "",
        note: str = "",
        reference: str = "",
    ) -> Dict[str, Any]:
        clean_mode = (mode or self.scanner_fast_mode()).strip().lower()
        if clean_mode not in SCAN_MODES:
            raise ValueError(f"Unsupported scanner mode: {mode}")
        qty = self.scanner_default_quantity() if quantity is None else coerce_float(quantity, self.scanner_default_quantity())
        if clean_mode == "lookup":
            result = self.scan_lookup(code)
            result["movement_type"] = "scan_lookup"
            return result
        if clean_mode == "transfer":
            return self.scan_transfer(code, location, note, reference)
        return self.scan_movement(code, qty, clean_mode, note, reference)

    def scan_batch(
        self,
        codes: Iterable[str],
        mode: str = "restock",
        quantity: float = 1.0,
        location: str = "",
        note: str = "",
        debounce_consecutive: bool = True,
    ) -> Dict[str, Any]:
        clean_mode = (mode or self.scanner_fast_mode()).strip().lower()
        if clean_mode not in SCAN_MODES:
            raise ValueError(f"Unsupported scanner mode: {mode}")
        results: List[Dict[str, Any]] = []
        last_code = ""
        skipped_duplicates = 0
        for raw in codes:
            code = normalize_scan_code(raw)
            if not code:
                continue
            if debounce_consecutive and code == last_code:
                skipped_duplicates += 1
                results.append({"found": False, "scan_code": code, "skipped": True, "reason": "duplicate_debounce"})
                continue
            last_code = code
            try:
                result = self.fast_scan(code, clean_mode, quantity, location, note or f"Batch scanner {clean_mode}")
            except Exception as exc:
                result = {"found": False, "scan_code": code, "error": str(exc)}
            results.append(result)
        found = sum(1 for r in results if r.get("found"))
        unknown = sum(1 for r in results if not r.get("found") and not r.get("skipped"))
        moved = sum(1 for r in results if r.get("found") and str(r.get("movement_type", "")) not in {"scan_lookup", ""})
        return {
            "mode": clean_mode,
            "total_scans": len(results),
            "found": found,
            "unknown": unknown,
            "moved": moved,
            "skipped_duplicates": skipped_duplicates,
            "results": results,
        }

    def recent_scan_movements(self, limit: int = 100) -> List[sqlite3.Row]:
        return list(self.conn.execute(
            """
            SELECT * FROM movements
            WHERE movement_type LIKE 'scan_%'
            ORDER BY created_at DESC, id DESC
            LIMIT ?
            """,
            (max(1, int(limit)),),
        ).fetchall())

    def export_recent_scan_csv(self, path: Path, limit: int = 500) -> Path:
        ensure_parent(path)
        fields = ["id", "sku", "movement_type", "qty_delta", "qty_after", "reference", "created_at", "note"]
        with path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            for row in self.recent_scan_movements(limit=limit):
                writer.writerow({field: row[field] for field in fields})
        return path

    def resolve_item(self, identifier: str) -> Optional[sqlite3.Row]:
        if str(identifier).isdigit():
            found = self.get_item(int(identifier))
            if found:
                return found
        return self.get_item_by_sku(identifier) or self.get_item_by_barcode(identifier) or self.get_item_by_serial(identifier)

    def record_movement(
        self,
        item_id: Optional[int],
        sku: str,
        movement_type: str,
        qty_delta: float,
        qty_after: float,
        note: str = "",
        reference: str = "",
    ) -> None:
        self.conn.execute(
            """
            INSERT INTO movements(item_id, sku, movement_type, qty_delta, qty_after, note, reference, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (item_id, sku or "", movement_type, coerce_float(qty_delta), coerce_float(qty_after), note or "", reference or "", now_iso()),
        )

    def list_items(
        self,
        query: str = "",
        include_archived: bool = False,
        low_stock_only: bool = False,
        category: str = "",
        location: str = "",
    ) -> List[sqlite3.Row]:
        where: List[str] = []
        args: List[Any] = []
        if not include_archived:
            where.append("status != 'archived'")
        if query:
            where.append("(sku LIKE ? OR name LIKE ? OR category LIKE ? OR location LIKE ? OR barcode LIKE ? OR serial_number LIKE ? OR vendor LIKE ? OR notes LIKE ?)")
            like = f"%{query}%"
            args.extend([like] * 8)
        if low_stock_only:
            where.append("quantity <= low_stock_threshold AND low_stock_threshold > 0")
        if category:
            where.append("category = ?")
            args.append(category)
        if location:
            where.append("location = ?")
            args.append(location)
        sql = "SELECT * FROM items"
        if where:
            sql += " WHERE " + " AND ".join(where)
        sql += " ORDER BY status, category, name COLLATE NOCASE"
        return list(self.conn.execute(sql, tuple(args)).fetchall())

    def list_movements(self, limit: int = 200) -> List[sqlite3.Row]:
        return list(self.conn.execute("SELECT * FROM movements ORDER BY created_at DESC, id DESC LIMIT ?", (limit,)).fetchall())

    def distinct_values(self, column: str) -> List[str]:
        if column not in {"category", "location", "vendor", "condition", "status", "unit"}:
            raise ValueError("Unsupported column")
        return [r[0] for r in self.conn.execute(f"SELECT DISTINCT {column} FROM items WHERE {column} != '' ORDER BY {column} COLLATE NOCASE")]

    def dashboard(self) -> Dict[str, Any]:
        cur = self.conn.cursor()
        total_items = cur.execute("SELECT COUNT(*) FROM items WHERE status != 'archived'").fetchone()[0]
        archived_items = cur.execute("SELECT COUNT(*) FROM items WHERE status = 'archived'").fetchone()[0]
        total_units = cur.execute("SELECT COALESCE(SUM(quantity),0) FROM items WHERE status != 'archived'").fetchone()[0]
        inventory_cost_value = cur.execute("SELECT COALESCE(SUM(quantity * cost_each),0) FROM items WHERE status != 'archived'").fetchone()[0]
        inventory_sale_value = cur.execute("SELECT COALESCE(SUM(quantity * sale_price_each),0) FROM items WHERE status != 'archived'").fetchone()[0]
        low_stock = cur.execute("SELECT COUNT(*) FROM items WHERE status != 'archived' AND low_stock_threshold > 0 AND quantity <= low_stock_threshold").fetchone()[0]
        categories = cur.execute("SELECT COUNT(DISTINCT category) FROM items WHERE status != 'archived'").fetchone()[0]
        locations = cur.execute("SELECT COUNT(DISTINCT location) FROM items WHERE status != 'archived'").fetchone()[0]
        movements = cur.execute("SELECT COUNT(*) FROM movements").fetchone()[0]
        service_records = cur.execute("SELECT COUNT(*) FROM service_records").fetchone()[0]
        warranty_expiring = len(self.warranty_report(days=90))
        service_due = len(self.service_due(days=30))
        expiry_summary = self.expiry_summary(DEFAULT_EXPIRY_WARNING_DAYS)
        items_with_barcodes = cur.execute("SELECT COUNT(*) FROM items WHERE status != 'archived' AND barcode != ''").fetchone()[0]
        items_with_serials = cur.execute("SELECT COUNT(*) FROM items WHERE status != 'archived' AND serial_number != ''").fetchone()[0]
        label_ready_items = cur.execute("SELECT COUNT(*) FROM items WHERE status != 'archived' AND (barcode != '' OR sku != '' OR serial_number != '')").fetchone()[0]
        return {
            "app": APP_NAME,
            "version": VERSION,
            "schema_version": SCHEMA_VERSION,
            "db_path": str(self.db_path),
            "total_items": int(total_items or 0),
            "archived_items": int(archived_items or 0),
            "total_units": float(total_units or 0),
            "low_stock_items": int(low_stock or 0),
            "categories": int(categories or 0),
            "locations": int(locations or 0),
            "movement_records": int(movements or 0),
            "service_records": int(service_records or 0),
            "warranty_expiring_90_days": int(warranty_expiring or 0),
            "service_due_30_days": int(service_due or 0),
            "stock_expiry_window_days": DEFAULT_EXPIRY_WARNING_DAYS,
            "stock_expired_items": int(expiry_summary["expired"]),
            "stock_expiring_soon_items": int(expiry_summary["expiring"]),
            "stock_good_date_items": int(expiry_summary["good"]),
            "stock_unknown_expiry_items": int(expiry_summary["unknown"]),
            "freshest_stock_item": expiry_summary.get("freshest_sku", ""),
            "items_with_barcodes": int(items_with_barcodes or 0),
            "items_with_serials": int(items_with_serials or 0),
            "label_ready_items": int(label_ready_items or 0),
            "label_payload_scheme": "sentinel-inventory://item/{SKU}",
            "print_label_sheet_ready": True,
            "label_export_ready": True,
            "qr_payload_ready": True,
            "qr_png_export_optional": True,
            "scanner_suffix": self.get_setting("scanner_suffix", DEFAULT_SCANNER_SUFFIX),
            "scanner_default_quantity": self.scanner_default_quantity(),
            "scanner_fast_mode": self.scanner_fast_mode(),
            "scanner_debounce_seconds": self.scanner_debounce_seconds(),
            "recent_scan_movements": len(self.recent_scan_movements(limit=10000)),
            "scanner_hid_keyboard_wedge_ready": True,
            "fast_stock_movement_ready": True,
            "batch_scan_queue_ready": True,
            "scan_transfer_ready": True,
            "duplicate_scan_debounce_ready": True,
            "inventory_cost_value": float(inventory_cost_value or 0),
            "inventory_sale_value": float(inventory_sale_value or 0),
            "ledger_bridge_rows": len(self.ledger_bridge_rows(include_archived=False, include_zero=True)),
            "pantry_bridge_rows": len(self.pantry_bridge_rows(include_all=False, include_archived=False)),
            "supplier_reorder_rows": len(self.supplier_reorder_rows()),
            "bridge_contract_version": "1.0.0",
            "sku_prefix": self.sku_prefix(),
            "next_sku": self.next_sku(),
            "sku_autofill_sequence": True,
            "local_only": True,
            "network_required": False,
            "telemetry": False,
        }

    def low_stock_items(self) -> List[sqlite3.Row]:
        return self.list_items(low_stock_only=True)

    def category_summary(self) -> List[sqlite3.Row]:
        return list(self.conn.execute(
            """
            SELECT
                category,
                COUNT(*) AS item_count,
                COALESCE(SUM(quantity), 0) AS total_units,
                COALESCE(SUM(quantity * cost_each), 0) AS cost_value,
                COALESCE(SUM(quantity * sale_price_each), 0) AS sale_value
            FROM items
            WHERE status != 'archived'
            GROUP BY category
            ORDER BY category COLLATE NOCASE
            """
        ).fetchall())

    def location_summary(self) -> List[sqlite3.Row]:
        return list(self.conn.execute(
            """
            SELECT
                location,
                COUNT(*) AS item_count,
                COALESCE(SUM(quantity), 0) AS total_units,
                COALESCE(SUM(quantity * cost_each), 0) AS cost_value,
                COALESCE(SUM(quantity * sale_price_each), 0) AS sale_value
            FROM items
            WHERE status != 'archived'
            GROUP BY location
            ORDER BY location COLLATE NOCASE
            """
        ).fetchall())

    def reorder_items(self) -> List[sqlite3.Row]:
        return list(self.conn.execute(
            """
            SELECT
                id, sku, name, category, location, quantity, unit, low_stock_threshold,
                CASE
                    WHEN low_stock_threshold > 0 THEN MAX((low_stock_threshold * 2) - quantity, low_stock_threshold)
                    ELSE 0
                END AS suggested_order_qty,
                vendor, notes
            FROM items
            WHERE status != 'archived'
              AND low_stock_threshold > 0
              AND quantity <= low_stock_threshold
            ORDER BY category COLLATE NOCASE, name COLLATE NOCASE
            """
        ).fetchall())

    def expiry_status(self, expiry_date: Any, warning_days: int = DEFAULT_EXPIRY_WARNING_DAYS) -> Dict[str, Any]:
        """Classify stock freshness from an item-level expiry/best-before date."""
        remaining = days_until(expiry_date)
        horizon = max(0, int(warning_days))
        if remaining is None:
            return {"status": "unknown", "days_remaining": ""}
        if remaining < 0:
            status = "expired"
        elif remaining <= horizon:
            status = "expiring"
        else:
            status = "good"
        return {"status": status, "days_remaining": remaining}

    def expiry_report(
        self,
        days: int = DEFAULT_EXPIRY_WARNING_DAYS,
        status: str = "all",
        include_unknown: bool = False,
    ) -> List[Dict[str, Any]]:
        """Return item-level stock expiry/freshness records.

        Status values:
        - expired: expiry_date is before today
        - expiring: expiry_date is within the warning window
        - good: expiry_date is beyond the warning window
        - unknown: no parseable expiry_date has been recorded
        """
        wanted = (status or "all").strip().lower()
        if wanted not in {"all", "expired", "expiring", "good", "unknown"}:
            raise ValueError(f"Unsupported expiry status: {status}")
        rows: List[Dict[str, Any]] = []
        for item in self.list_items(include_archived=False):
            info = self.expiry_status(item["expiry_date"], days)
            item_status = str(info["status"])
            if item_status == "unknown" and not include_unknown and wanted != "unknown":
                continue
            if wanted != "all" and item_status != wanted:
                continue
            rows.append({
                "id": item["id"],
                "sku": item["sku"],
                "name": item["name"],
                "category": item["category"],
                "location": item["location"],
                "quantity": coerce_float(item["quantity"]),
                "unit": item["unit"],
                "expiry_date": item["expiry_date"],
                "days_remaining": info["days_remaining"],
                "status": item_status,
                "barcode": item["barcode"],
                "vendor": item["vendor"],
                "notes": item["notes"],
            })
        def sort_key(row: Dict[str, Any]) -> Tuple[int, int, str]:
            dr = row.get("days_remaining", "")
            if dr == "":
                return (1, 999999, str(row.get("name", "")).lower())
            return (0, int(dr), str(row.get("name", "")).lower())
        rows.sort(key=sort_key)
        return rows

    def freshest_stock(self, limit: int = 20) -> List[Dict[str, Any]]:
        """Return stock with the furthest future expiry dates first."""
        records = [r for r in self.expiry_report(days=0, status="all") if isinstance(r.get("days_remaining"), int) and int(r["days_remaining"]) >= 0]
        records.sort(key=lambda r: (int(r["days_remaining"]), str(r.get("name", "")).lower()), reverse=True)
        return records[:max(1, int(limit))]

    def expiry_summary(self, days: int = DEFAULT_EXPIRY_WARNING_DAYS) -> Dict[str, Any]:
        counts = {"expired": 0, "expiring": 0, "good": 0, "unknown": 0}
        for item in self.list_items(include_archived=False):
            counts[self.expiry_status(item["expiry_date"], days)["status"]] += 1
        freshest = self.freshest_stock(limit=1)
        counts["freshest_sku"] = freshest[0]["sku"] if freshest else ""
        counts["freshest_name"] = freshest[0]["name"] if freshest else ""
        counts["freshest_expiry_date"] = freshest[0]["expiry_date"] if freshest else ""
        return counts

    def export_expiry_csv(
        self,
        path: Path,
        days: int = DEFAULT_EXPIRY_WARNING_DAYS,
        status: str = "all",
        include_unknown: bool = False,
    ) -> Path:
        ensure_parent(path)
        fields = ["id", "sku", "name", "category", "location", "quantity", "unit", "expiry_date", "days_remaining", "status", "barcode", "vendor", "notes"]
        with path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            writer.writerows(self.expiry_report(days=days, status=status, include_unknown=include_unknown))
        return path

    def warranty_report(self, days: int = 90, include_expired: bool = True) -> List[Dict[str, Any]]:
        rows: List[Dict[str, Any]] = []
        horizon = max(0, int(days))
        for item in self.list_items(include_archived=False):
            remaining = days_until(item["warranty_expiry"])
            if remaining is None:
                continue
            if remaining <= horizon and (include_expired or remaining >= 0):
                status = "expired" if remaining < 0 else "expiring" if remaining <= horizon else "active"
                rows.append({
                    "id": item["id"],
                    "sku": item["sku"],
                    "name": item["name"],
                    "category": item["category"],
                    "location": item["location"],
                    "serial_number": item["serial_number"],
                    "warranty_expiry": item["warranty_expiry"],
                    "days_remaining": remaining,
                    "status": status,
                    "vendor": item["vendor"],
                })
        rows.sort(key=lambda r: (r["days_remaining"], str(r["name"]).lower()))
        return rows

    def add_service_record(
        self,
        item_id: int,
        service_type: str = "service",
        description: str = "",
        cost: float = 0.0,
        provider: str = "",
        performed_at: str = "",
        next_due: str = "",
        reference: str = "",
    ) -> int:
        item = self.get_item(item_id)
        if not item:
            raise ValueError(f"Item id {item_id} not found")
        cur = self.conn.execute(
            """
            INSERT INTO service_records(
                item_id, sku, service_type, description, cost, provider,
                performed_at, next_due, reference, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                item_id, item["sku"], service_type or "service", description or "",
                coerce_float(cost), provider or "", performed_at or today().isoformat(),
                next_due or "", reference or "", now_iso(),
            ),
        )
        service_id = int(cur.lastrowid)
        self.record_movement(item_id, item["sku"], "service", 0, coerce_float(item["quantity"]), description or service_type, reference)
        self.conn.commit()
        return service_id

    def service_records(self, item_id: Optional[int] = None, limit: int = 500) -> List[sqlite3.Row]:
        sql = """
            SELECT sr.*, COALESCE(i.name, '') AS item_name, COALESCE(i.category, '') AS category, COALESCE(i.location, '') AS location
            FROM service_records sr
            LEFT JOIN items i ON i.id = sr.item_id
        """
        args: List[Any] = []
        if item_id is not None:
            sql += " WHERE sr.item_id = ?"
            args.append(item_id)
        sql += " ORDER BY COALESCE(NULLIF(sr.next_due, ''), sr.performed_at) ASC, sr.id DESC LIMIT ?"
        args.append(limit)
        return list(self.conn.execute(sql, tuple(args)).fetchall())

    def service_due(self, days: int = 30, include_overdue: bool = True) -> List[Dict[str, Any]]:
        horizon_date = today() + _dt.timedelta(days=max(0, int(days)))
        out: List[Dict[str, Any]] = []
        for row in self.service_records(limit=10000):
            due = parse_date(row["next_due"])
            if not due:
                continue
            remaining = (due - today()).days
            if due <= horizon_date and (include_overdue or remaining >= 0):
                out.append({
                    "id": row["id"],
                    "sku": row["sku"],
                    "item_name": row["item_name"],
                    "service_type": row["service_type"],
                    "next_due": row["next_due"],
                    "days_remaining": remaining,
                    "provider": row["provider"],
                    "reference": row["reference"],
                    "description": row["description"],
                })
        out.sort(key=lambda r: (r["days_remaining"], str(r["item_name"]).lower()))
        return out

    def export_warranty_csv(self, path: Path, days: int = 90) -> Path:
        ensure_parent(path)
        fields = ["id", "sku", "name", "category", "location", "serial_number", "warranty_expiry", "days_remaining", "status", "vendor"]
        with path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            writer.writerows(self.warranty_report(days=days))
        return path

    def export_service_csv(self, path: Path) -> Path:
        ensure_parent(path)
        fields = [
            "id", "sku", "item_name", "category", "location", "service_type",
            "description", "cost", "provider", "performed_at", "next_due", "reference", "created_at",
        ]
        with path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            for row in self.service_records(limit=10000):
                writer.writerow({field: row[field] for field in fields})
        return path


    def label_record(self, row: sqlite3.Row) -> Dict[str, Any]:
        """Return one flat label/export record for a SQLite item row."""
        scan_code = item_scan_code(row)
        return {
            "id": row["id"],
            "sku": row["sku"],
            "name": row["name"],
            "category": row["category"],
            "location": row["location"],
            "quantity": coerce_float(row["quantity"]),
            "unit": row["unit"],
            "barcode": row["barcode"],
            "serial_number": row["serial_number"],
            "vendor": row["vendor"],
            "condition": row["condition"],
            "warranty_expiry": row["warranty_expiry"],
            "expiry_date": row["expiry_date"],
            "expiry_status": self.expiry_status(row["expiry_date"], DEFAULT_EXPIRY_WARNING_DAYS)["status"],
            "scan_code": scan_code,
            "qr_payload": item_label_payload(row),
            "label_title": f"{row['sku']} — {row['name']}",
        }

    def label_rows(
        self,
        query: str = "",
        include_archived: bool = False,
        low_stock_only: bool = False,
        category: str = "",
        location: str = "",
        identifiers: Optional[Sequence[str]] = None,
    ) -> List[Dict[str, Any]]:
        """Collect label-ready item records by filter or explicit id/SKU/barcode/serial identifiers."""
        rows: List[sqlite3.Row] = []
        seen: set[int] = set()
        if identifiers:
            for ident in identifiers:
                row = self.resolve_item(str(ident))
                if row and int(row["id"]) not in seen:
                    rows.append(row)
                    seen.add(int(row["id"]))
        else:
            rows = self.list_items(query=query, include_archived=include_archived, low_stock_only=low_stock_only, category=category, location=location)
        return [self.label_record(row) for row in rows]

    def export_label_csv(
        self,
        path: Path,
        query: str = "",
        include_archived: bool = False,
        low_stock_only: bool = False,
        category: str = "",
        location: str = "",
        identifiers: Optional[Sequence[str]] = None,
    ) -> Path:
        ensure_parent(path)
        fields = [
            "id", "sku", "name", "category", "location", "quantity", "unit", "barcode",
            "serial_number", "vendor", "condition", "warranty_expiry", "expiry_date", "expiry_status", "scan_code", "qr_payload", "label_title",
        ]
        with path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            for row in self.label_rows(query, include_archived, low_stock_only, category, location, identifiers):
                writer.writerow({field: row.get(field, "") for field in fields})
        return path

    def export_label_json(
        self,
        path: Path,
        query: str = "",
        include_archived: bool = False,
        low_stock_only: bool = False,
        category: str = "",
        location: str = "",
        identifiers: Optional[Sequence[str]] = None,
    ) -> Path:
        ensure_parent(path)
        payload = {
            "app": APP_NAME,
            "version": VERSION,
            "schema_version": SCHEMA_VERSION,
            "exported_at": now_iso(),
            "label_payload_scheme": "sentinel-inventory://item/{SKU}",
            "records": self.label_rows(query, include_archived, low_stock_only, category, location, identifiers),
        }
        with path.open("w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)
        return path

    def export_label_html(
        self,
        path: Path,
        query: str = "",
        include_archived: bool = False,
        low_stock_only: bool = False,
        category: str = "",
        location: str = "",
        identifiers: Optional[Sequence[str]] = None,
        copies: int = 1,
    ) -> Path:
        """Export a local printable HTML label sheet. This stores QR-ready payload text, not remote assets."""
        ensure_parent(path)
        copies = max(1, min(20, int(copies or 1)))
        records = self.label_rows(query, include_archived, low_stock_only, category, location, identifiers)
        repeated: List[Dict[str, Any]] = []
        for rec in records:
            for _ in range(copies):
                repeated.append(rec)
        css = """
        @page { size: A4; margin: 10mm; }
        * { box-sizing: border-box; }
        body { margin: 0; font-family: Arial, sans-serif; color: #111; background: #fff; }
        .sheet { display: grid; grid-template-columns: repeat(3, 1fr); gap: 6mm; }
        .label { border: 1px solid #111; border-radius: 3mm; min-height: 42mm; padding: 4mm; page-break-inside: avoid; }
        .sku { font-size: 16pt; font-weight: 800; letter-spacing: 0.5pt; }
        .name { font-size: 10pt; font-weight: 700; margin-top: 1.5mm; }
        .meta { font-size: 8pt; margin-top: 1mm; }
        .scan { margin-top: 3mm; padding: 1.5mm; border: 1px dashed #333; font-family: 'DejaVu Sans Mono', monospace; font-size: 10pt; overflow-wrap: anywhere; }
        .qr { margin-top: 1.5mm; font-family: 'DejaVu Sans Mono', monospace; font-size: 6.8pt; overflow-wrap: anywhere; }
        .hint { font-size: 7pt; color: #333; margin-top: 1mm; }
        @media print { .no-print { display: none; } }
        """
        parts = ["<!doctype html><html><head><meta charset='utf-8'><title>Sentinel Inventory Labels</title><style>", css, "</style></head><body>"]
        parts.append("<div class='no-print' style='padding:8px;font-size:10pt'>Sentinel Inventory printable labels — use browser print. QR payload text is local-only.</div>")
        parts.append("<main class='sheet'>")
        for rec in repeated:
            parts.append("<section class='label'>")
            parts.append(f"<div class='sku'>{html.escape(str(rec['sku']))}</div>")
            parts.append(f"<div class='name'>{html.escape(str(rec['name']))}</div>")
            parts.append(f"<div class='meta'>Category: {html.escape(str(rec['category']))}</div>")
            parts.append(f"<div class='meta'>Location: {html.escape(str(rec['location']))}</div>")
            parts.append(f"<div class='meta'>Qty: {html.escape(str(rec['quantity']))} {html.escape(str(rec['unit']))}</div>")
            parts.append(f"<div class='scan'>{html.escape(str(rec['scan_code']))}</div>")
            parts.append(f"<div class='qr'>{html.escape(str(rec['qr_payload']))}</div>")
            parts.append("<div class='hint'>Print prep: scan human-readable code or encode QR payload with exported QR PNGs.</div>")
            parts.append("</section>")
        parts.append("</main></body></html>")
        path.write_text("\n".join(parts), encoding="utf-8")
        return path

    def export_qr_pngs(
        self,
        dest_dir: Path,
        query: str = "",
        include_archived: bool = False,
        low_stock_only: bool = False,
        category: str = "",
        location: str = "",
        identifiers: Optional[Sequence[str]] = None,
    ) -> Dict[str, Any]:
        """Export one QR PNG per item using the optional python qrcode module when installed."""
        try:
            import qrcode  # type: ignore
        except Exception as exc:
            raise RuntimeError("QR PNG export requires the optional python3-qrcode package/module.") from exc
        dest_dir = Path(dest_dir).expanduser()
        dest_dir.mkdir(parents=True, exist_ok=True)
        created: List[str] = []
        for rec in self.label_rows(query, include_archived, low_stock_only, category, location, identifiers):
            filename = f"{safe_filename(rec['sku'])}_qr.png"
            out = dest_dir / filename
            img = qrcode.make(rec["qr_payload"])
            img.save(out)
            created.append(str(out))
        return {"created": len(created), "directory": str(dest_dir), "files": created, "qr_payload_scheme": "sentinel-inventory://item/{SKU}"}



    def ledger_bridge_rows(self, include_archived: bool = False, include_zero: bool = True) -> List[Dict[str, Any]]:
        """Return stable stock valuation rows for Sentinel Ledger bridge imports."""
        records: List[Dict[str, Any]] = []
        for row in self.list_items(include_archived=include_archived):
            qty = coerce_float(row["quantity"])
            if not include_zero and abs(qty) < 0.000001:
                continue
            cost_each = coerce_float(row["cost_each"])
            sale_each = coerce_float(row["sale_price_each"])
            expiry = self.expiry_status(row["expiry_date"], DEFAULT_EXPIRY_WARNING_DAYS)
            records.append({
                "bridge_type": "sentinel_ledger_inventory_valuation",
                "source_app": APP_NAME,
                "source_version": VERSION,
                "exported_at": now_iso(),
                "sku": row["sku"],
                "name": row["name"],
                "category": row["category"],
                "location": row["location"],
                "quantity": qty,
                "unit": row["unit"],
                "cost_each": cost_each,
                "inventory_cost_value": qty * cost_each,
                "sale_price_each": sale_each,
                "potential_sale_value": qty * sale_each,
                "vendor": row["vendor"],
                "barcode": row["barcode"],
                "serial_number": row["serial_number"],
                "warranty_expiry": row["warranty_expiry"],
                "expiry_date": row["expiry_date"],
                "expiry_status": expiry["status"],
                "days_until_expiry": expiry["days_remaining"],
                "condition": row["condition"],
                "status": row["status"],
                "ledger_account_hint": "Inventory Asset",
                "ledger_offset_hint": "Inventory Adjustment / Opening Stock",
                "tax_code_hint": "",
                "notes": row["notes"],
                "updated_at": row["updated_at"],
            })
        return records

    def pantry_candidate_reason(self, row: sqlite3.Row) -> str:
        """Classify likely Pantry handoff candidates from existing inventory fields."""
        text = " ".join(str(row[key] or "") for key in ("name", "category", "location", "unit", "vendor", "notes")).lower()
        keyword_groups = [
            ("pantry", ["pantry", "food", "rice", "flour", "sugar", "salt", "beans", "pasta", "tinned", "canned", "meal", "recipe", "drink", "water"]),
            ("expiry_tracked", []),
            ("consumable", ["consumable", "battery", "batteries", "filter", "chemical", "adhesive", "sealant", "oil", "fuel", "medicine", "medical", "first aid", "cleaner", "soap"]),
            ("low_stock_tracked", []),
        ]
        if str(row["expiry_date"] or "").strip():
            return "expiry_tracked"
        if coerce_float(row["low_stock_threshold"]) > 0:
            # Keep this below explicit food/consumable keyword checks by checking keywords first.
            low_reason = "low_stock_tracked"
        else:
            low_reason = ""
        for reason, words in keyword_groups:
            if words and any(word in text for word in words):
                return reason
        return low_reason

    def pantry_bridge_rows(self, include_all: bool = False, include_archived: bool = False) -> List[Dict[str, Any]]:
        """Return stock rotation/reorder rows for Sentinel Pantry and household consumables."""
        records: List[Dict[str, Any]] = []
        for row in self.list_items(include_archived=include_archived):
            reason = self.pantry_candidate_reason(row)
            if not include_all and not reason:
                continue
            qty = coerce_float(row["quantity"])
            low = coerce_float(row["low_stock_threshold"])
            suggested = max((low * 2) - qty, low) if low > 0 and qty <= low else 0.0
            expiry = self.expiry_status(row["expiry_date"], DEFAULT_EXPIRY_WARNING_DAYS)
            records.append({
                "bridge_type": "sentinel_pantry_inventory_rotation",
                "source_app": APP_NAME,
                "source_version": VERSION,
                "exported_at": now_iso(),
                "sku": row["sku"],
                "name": row["name"],
                "category": row["category"],
                "location": row["location"],
                "quantity": qty,
                "unit": row["unit"],
                "low_stock_threshold": low,
                "suggested_reorder_qty": suggested,
                "vendor": row["vendor"],
                "barcode": row["barcode"],
                "expiry_date": row["expiry_date"],
                "expiry_status": expiry["status"],
                "days_until_expiry": expiry["days_remaining"],
                "freshness_priority": {"expired": 0, "expiring": 1, "unknown": 2, "good": 3}.get(str(expiry["status"]), 2),
                "pantry_candidate_reason": reason or "manual_include_all",
                "notes": row["notes"],
                "status": row["status"],
                "updated_at": row["updated_at"],
            })
        records.sort(key=lambda r: (r["freshness_priority"], r["days_until_expiry"] if r["days_until_expiry"] is not None else 999999, str(r["name"]).lower()))
        return records

    def supplier_reorder_rows(self) -> List[Dict[str, Any]]:
        """Return reorder records shaped for supplier/vendor and Ledger handoff."""
        records: List[Dict[str, Any]] = []
        for row in self.reorder_items():
            expiry = self.expiry_status(row["expiry_date"] if "expiry_date" in row.keys() else "", DEFAULT_EXPIRY_WARNING_DAYS) if hasattr(row, "keys") else {"status": "unknown", "days_remaining": None}
            records.append({
                "bridge_type": "sentinel_supplier_reorder_handoff",
                "source_app": APP_NAME,
                "source_version": VERSION,
                "exported_at": now_iso(),
                "sku": row["sku"],
                "name": row["name"],
                "category": row["category"],
                "location": row["location"],
                "quantity": coerce_float(row["quantity"]),
                "unit": row["unit"],
                "low_stock_threshold": coerce_float(row["low_stock_threshold"]),
                "suggested_order_qty": coerce_float(row["suggested_order_qty"]),
                "vendor": row["vendor"],
                "expiry_status": expiry["status"],
                "days_until_expiry": expiry["days_remaining"],
                "ledger_document_hint": "supplier_bill_or_purchase_receipt",
                "notes": row["notes"],
            })
        return records

    def bridge_status(self) -> Dict[str, Any]:
        ledger_rows = self.ledger_bridge_rows(include_archived=False, include_zero=True)
        pantry_rows = self.pantry_bridge_rows(include_all=False, include_archived=False)
        reorder_rows = self.supplier_reorder_rows()
        return {
            "app": APP_NAME,
            "version": VERSION,
            "schema_version": SCHEMA_VERSION,
            "bridge_contract_version": "1.0.0",
            "ledger_bridge_export_ready": True,
            "pantry_bridge_export_ready": True,
            "supplier_reorder_handoff_ready": True,
            "bridge_bundle_ready": True,
            "bridge_manifest_ready": True,
            "v1_bridge_contract_prep_ready": True,
            "ledger_rows": len(ledger_rows),
            "pantry_candidate_rows": len(pantry_rows),
            "supplier_reorder_rows": len(reorder_rows),
            "local_only": True,
            "network_required": False,
            "telemetry": False,
            "contracts": {
                "sentinel_ledger": "stock valuation, inventory asset value, supplier purchase/reorder handoff",
                "sentinel_pantry": "expiry rotation, freshest/oldest stock, consumable and pantry stock handoff",
                "sentinel_command": "machine-readable health JSON and bridge status JSON",
                "aegis": "local-readable status/export manifest"
            }
        }

    def _write_csv_records(self, path: Path, fields: Sequence[str], records: Sequence[Dict[str, Any]]) -> Path:
        ensure_parent(path)
        with path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(fields))
            writer.writeheader()
            for rec in records:
                writer.writerow({field: rec.get(field, "") for field in fields})
        return path

    def _write_json_payload(self, path: Path, payload: Dict[str, Any]) -> Path:
        ensure_parent(path)
        with path.open("w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)
        return path

    def export_ledger_bridge_csv(self, path: Path, include_archived: bool = False, include_zero: bool = True) -> Path:
        records = self.ledger_bridge_rows(include_archived=include_archived, include_zero=include_zero)
        fields = ["bridge_type", "source_app", "source_version", "exported_at", "sku", "name", "category", "location", "quantity", "unit", "cost_each", "inventory_cost_value", "sale_price_each", "potential_sale_value", "vendor", "barcode", "serial_number", "warranty_expiry", "expiry_date", "expiry_status", "days_until_expiry", "condition", "status", "ledger_account_hint", "ledger_offset_hint", "tax_code_hint", "notes", "updated_at"]
        return self._write_csv_records(path, fields, records)

    def export_ledger_bridge_json(self, path: Path, include_archived: bool = False, include_zero: bool = True) -> Path:
        return self._write_json_payload(path, {"app": APP_NAME, "version": VERSION, "schema_version": SCHEMA_VERSION, "bridge_type": "sentinel_ledger_inventory_bridge", "exported_at": now_iso(), "bridge_status": self.bridge_status(), "records": self.ledger_bridge_rows(include_archived=include_archived, include_zero=include_zero)})

    def export_pantry_bridge_csv(self, path: Path, include_all: bool = False, include_archived: bool = False) -> Path:
        records = self.pantry_bridge_rows(include_all=include_all, include_archived=include_archived)
        fields = ["bridge_type", "source_app", "source_version", "exported_at", "sku", "name", "category", "location", "quantity", "unit", "low_stock_threshold", "suggested_reorder_qty", "vendor", "barcode", "expiry_date", "expiry_status", "days_until_expiry", "freshness_priority", "pantry_candidate_reason", "notes", "status", "updated_at"]
        return self._write_csv_records(path, fields, records)

    def export_pantry_bridge_json(self, path: Path, include_all: bool = False, include_archived: bool = False) -> Path:
        return self._write_json_payload(path, {"app": APP_NAME, "version": VERSION, "schema_version": SCHEMA_VERSION, "bridge_type": "sentinel_pantry_inventory_bridge", "exported_at": now_iso(), "bridge_status": self.bridge_status(), "records": self.pantry_bridge_rows(include_all=include_all, include_archived=include_archived)})

    def export_bridge_bundle(self, dest_dir: Path) -> Dict[str, Any]:
        dest = Path(dest_dir).expanduser()
        if dest.suffix:
            dest = dest.with_suffix("")
        dest.mkdir(parents=True, exist_ok=True)
        files = {
            "ledger_csv": self.export_ledger_bridge_csv(dest / "sentinel_inventory_ledger_bridge.csv"),
            "ledger_json": self.export_ledger_bridge_json(dest / "sentinel_inventory_ledger_bridge.json"),
            "pantry_csv": self.export_pantry_bridge_csv(dest / "sentinel_inventory_pantry_bridge.csv"),
            "pantry_json": self.export_pantry_bridge_json(dest / "sentinel_inventory_pantry_bridge.json"),
            "reorder_csv": self.export_reorder_csv(dest / "sentinel_inventory_supplier_reorder.csv"),
            "expiry_csv": self.export_expiry_csv(dest / "sentinel_inventory_expiry_rotation.csv"),
            "labels_json": self.export_label_json(dest / "sentinel_inventory_label_payloads.json"),
        }
        manifest = {
            "app": APP_NAME,
            "version": VERSION,
            "schema_version": SCHEMA_VERSION,
            "bridge_contract_version": "1.0.0",
            "exported_at": now_iso(),
            "directory": str(dest),
            "status": self.bridge_status(),
            "files": {key: str(path) for key, path in files.items()},
            "local_only": True,
            "network_required": False,
            "telemetry": False,
        }
        manifest_path = dest / "sentinel_inventory_bridge_manifest.json"
        self._write_json_payload(manifest_path, manifest)
        manifest["files"]["manifest"] = str(manifest_path)
        return manifest

    def export_reorder_csv(self, path: Path) -> Path:
        ensure_parent(path)
        fields = [
            "id", "sku", "name", "category", "location", "quantity", "unit",
            "low_stock_threshold", "suggested_order_qty", "vendor", "notes",
        ]
        with path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            for row in self.reorder_items():
                writer.writerow({field: row[field] for field in fields})
        return path

    def export_csv(self, path: Path) -> Path:
        ensure_parent(path)
        rows = self.list_items(include_archived=True)
        fields = [
            "id", "sku", "name", "category", "location", "quantity", "unit", "low_stock_threshold",
            "cost_each", "sale_price_each", "vendor", "serial_number", "barcode", "warranty_expiry", "expiry_date",
            "condition", "status", "notes", "created_at", "updated_at",
        ]
        with path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            for row in rows:
                writer.writerow({field: row[field] for field in fields})
        return path

    def export_json(self, path: Path) -> Path:
        ensure_parent(path)
        rows = [dict(row) for row in self.list_items(include_archived=True)]
        movements = [dict(row) for row in self.list_movements(limit=10000)]
        service_records = [dict(row) for row in self.service_records(limit=10000)]
        recent_scan_movements = [dict(row) for row in self.recent_scan_movements(limit=10000)]
        payload = {
            "app": APP_NAME,
            "version": VERSION,
            "schema_version": SCHEMA_VERSION,
            "exported_at": now_iso(),
            "db_path": str(self.db_path),
            "items": rows,
            "movements": movements,
            "service_records": service_records,
            "recent_scan_movements": recent_scan_movements,
        }
        with path.open("w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)
        return path

    def import_csv(self, path: Path, update_existing: bool = True) -> Dict[str, int]:
        created = 0
        updated = 0
        skipped = 0
        with Path(path).open("r", newline="", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            for raw in reader:
                sku = (raw.get("sku") or "").strip() or self.next_sku()
                name = (raw.get("name") or "").strip()
                if not name:
                    skipped += 1
                    continue
                existing = self.get_item_by_sku(sku)
                fields = {
                    "sku": sku,
                    "name": name,
                    "category": raw.get("category") or "General",
                    "location": raw.get("location") or "Unsorted",
                    "quantity": coerce_float(raw.get("quantity")),
                    "unit": raw.get("unit") or "ea",
                    "low_stock_threshold": coerce_float(raw.get("low_stock_threshold")),
                    "cost_each": coerce_float(raw.get("cost_each")),
                    "sale_price_each": coerce_float(raw.get("sale_price_each")),
                    "vendor": raw.get("vendor") or "",
                    "serial_number": raw.get("serial_number") or "",
                    "barcode": raw.get("barcode") or "",
                    "warranty_expiry": raw.get("warranty_expiry") or "",
                    "expiry_date": raw.get("expiry_date") or raw.get("expiry") or raw.get("best_before") or "",
                    "condition": raw.get("condition") or "Good",
                    "status": raw.get("status") or "active",
                    "notes": raw.get("notes") or "",
                }
                if existing and update_existing:
                    self.update_item(int(existing["id"]), fields, "CSV import update")
                    updated += 1
                elif existing:
                    skipped += 1
                else:
                    self.add_item(Item(id=None, **fields), "CSV import create")
                    created += 1
        return {"created": created, "updated": updated, "skipped": skipped}

    def backup(self, dest_dir: Optional[Path] = None) -> Path:
        dest_dir = Path(dest_dir or DEFAULT_EXPORT_DIR / "Backups").expanduser()
        dest_dir.mkdir(parents=True, exist_ok=True)
        stamp = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
        dest = dest_dir / f"sentinel_inventory_backup_{stamp}.db"
        self.conn.commit()
        shutil.copy2(self.db_path, dest)
        return dest

    def restore_backup(self, backup_path: Path, confirm: str = "") -> Dict[str, Any]:
        """Restore a SQLite backup into the active database path with explicit confirmation."""
        source = Path(backup_path).expanduser()
        if confirm != "RESTORE_INVENTORY":
            raise ValueError("Restore requires --confirm RESTORE_INVENTORY")
        if not source.exists() or not source.is_file():
            raise FileNotFoundError(f"Backup not found: {source}")
        stamp = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
        pre_restore = self.db_path.with_name(f"{self.db_path.stem}_pre_restore_{stamp}{self.db_path.suffix}")
        self.conn.commit()
        if self.db_path.exists():
            shutil.copy2(self.db_path, pre_restore)
        self.conn.close()
        ensure_parent(self.db_path)
        shutil.copy2(source, self.db_path)
        self.conn = sqlite3.connect(str(self.db_path))
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys = ON")
        self.migrate()
        integrity = self.conn.execute("PRAGMA integrity_check").fetchone()[0]
        return {
            "restored": integrity == "ok",
            "source_backup": str(source),
            "database": str(self.db_path),
            "pre_restore_backup": str(pre_restore) if pre_restore.exists() else "",
            "sqlite_integrity": integrity,
            "restored_at": now_iso(),
            "schema_version": SCHEMA_VERSION,
        }

    def _duplicate_values(self, column: str) -> List[Dict[str, Any]]:
        if column not in {"barcode", "serial_number", "sku"}:
            raise ValueError("Unsupported duplicate audit column")
        rows = self.conn.execute(
            f"""
            SELECT {column} AS value, COUNT(*) AS count
            FROM items
            WHERE TRIM({column}) != ''
            GROUP BY {column}
            HAVING COUNT(*) > 1
            ORDER BY COUNT(*) DESC, {column} COLLATE NOCASE
            """
        ).fetchall()
        return [{"value": r["value"], "count": int(r["count"])} for r in rows]

    def _invalid_date_count(self, column: str) -> int:
        if column not in {"expiry_date", "warranty_expiry"}:
            raise ValueError("Unsupported date audit column")
        count = 0
        for row in self.conn.execute(f"SELECT {column} FROM items WHERE TRIM({column}) != ''").fetchall():
            if parse_date(row[column]) is None:
                count += 1
        return count

    def audit_report(self) -> Dict[str, Any]:
        """Return a v1 integrity/audit report suitable for AEGIS and Sentinel Command."""
        integrity = self.conn.execute("PRAGMA integrity_check").fetchone()[0]
        dash = self.dashboard()
        duplicate_barcodes = self._duplicate_values("barcode")
        duplicate_serials = self._duplicate_values("serial_number")
        duplicate_skus = self._duplicate_values("sku")
        empty_skus = int(self.conn.execute("SELECT COUNT(*) FROM items WHERE TRIM(sku) = ''").fetchone()[0])
        unnamed_items = int(self.conn.execute("SELECT COUNT(*) FROM items WHERE TRIM(name) = ''").fetchone()[0])
        negative_quantity = int(self.conn.execute("SELECT COUNT(*) FROM items WHERE quantity < 0 AND status != 'archived'").fetchone()[0])
        invalid_expiry_dates = self._invalid_date_count("expiry_date")
        invalid_warranty_dates = self._invalid_date_count("warranty_expiry")
        movement_orphans = int(self.conn.execute("SELECT COUNT(*) FROM movements WHERE item_id IS NOT NULL AND item_id NOT IN (SELECT id FROM items)").fetchone()[0])
        service_orphans = int(self.conn.execute("SELECT COUNT(*) FROM service_records WHERE item_id IS NOT NULL AND item_id NOT IN (SELECT id FROM items)").fetchone()[0])
        checks = [
            {"name": "sqlite_integrity", "status": "ok" if integrity == "ok" else "fail", "detail": integrity},
            {"name": "schema_version", "status": "ok" if int(dash.get("schema_version", 0)) == SCHEMA_VERSION else "fail", "detail": str(dash.get("schema_version", ""))},
            {"name": "empty_skus", "status": "ok" if empty_skus == 0 else "fail", "count": empty_skus},
            {"name": "unnamed_items", "status": "ok" if unnamed_items == 0 else "fail", "count": unnamed_items},
            {"name": "duplicate_skus", "status": "ok" if not duplicate_skus else "fail", "count": len(duplicate_skus)},
            {"name": "duplicate_barcodes", "status": "ok" if not duplicate_barcodes else "warning", "count": len(duplicate_barcodes)},
            {"name": "duplicate_serials", "status": "ok" if not duplicate_serials else "warning", "count": len(duplicate_serials)},
            {"name": "invalid_expiry_dates", "status": "ok" if invalid_expiry_dates == 0 else "warning", "count": invalid_expiry_dates},
            {"name": "invalid_warranty_dates", "status": "ok" if invalid_warranty_dates == 0 else "warning", "count": invalid_warranty_dates},
            {"name": "negative_quantity", "status": "ok" if negative_quantity == 0 else "warning", "count": negative_quantity},
            {"name": "movement_orphans", "status": "ok" if movement_orphans == 0 else "warning", "count": movement_orphans},
            {"name": "service_orphans", "status": "ok" if service_orphans == 0 else "warning", "count": service_orphans},
        ]
        fail_count = sum(1 for c in checks if c.get("status") == "fail")
        warning_count = sum(1 for c in checks if c.get("status") == "warning")
        overall = "fail" if fail_count else "warning" if warning_count else "ok"
        return {
            "app": APP_NAME,
            "package": APP_ID,
            "program_number": 115,
            "version": VERSION,
            "stable_lock_version": "1.0.0",
            "schema_version": SCHEMA_VERSION,
            "generated_at": now_iso(),
            "db_path": str(self.db_path),
            "overall_status": overall,
            "fail_count": fail_count,
            "warning_count": warning_count,
            "checks": checks,
            "counts": {
                "total_items": dash.get("total_items", 0),
                "archived_items": dash.get("archived_items", 0),
                "movement_records": dash.get("movement_records", 0),
                "service_records": dash.get("service_records", 0),
                "low_stock_items": dash.get("low_stock_items", 0),
                "stock_expired_items": dash.get("stock_expired_items", 0),
                "stock_expiring_soon_items": dash.get("stock_expiring_soon_items", 0),
                "stock_good_date_items": dash.get("stock_good_date_items", 0),
                "stock_unknown_expiry_items": dash.get("stock_unknown_expiry_items", 0),
            },
            "duplicate_barcodes": duplicate_barcodes,
            "duplicate_serials": duplicate_serials,
            "duplicate_skus": duplicate_skus,
            "local_only": True,
            "network_required": False,
            "telemetry": False,
        }

    def stable_lock_report(self) -> Dict[str, Any]:
        audit = self.audit_report()
        health = self.health()
        return {
            "app": APP_NAME,
            "package": APP_ID,
            "program_number": 115,
            "version": VERSION,
            "stable_lock": "v1.0.0",
            "status": "stable_locked" if audit.get("overall_status") in {"ok", "warning"} and health.get("sqlite_integrity") == "ok" else "needs_attention",
            "generated_at": now_iso(),
            "schema_version": SCHEMA_VERSION,
            "database": str(self.db_path),
            "locked_capabilities": [
                "local SQLite inventory",
                "desktop/menu launcher and supplied Sentinel inventory icon",
                "sequential SKU autofill",
                "USB HID keyboard-wedge barcode/QR scanner intake",
                "fast scan stock movement and batch scanner queue",
                "barcode/SKU/serial lookup",
                "labels, QR payloads, and printable HTML label sheets",
                "expiry/best-before freshness and stock rotation reports",
                "warranty and service/repair records",
                "category/location valuation reports",
                "low-stock reorder reports",
                "Ledger/Pantry bridge exports and bridge bundle",
                "backup, restore, audit, and v1 handoff bundle",
                "AEGIS/Sentinel Command health JSON",
            ],
            "audit_overall_status": audit.get("overall_status"),
            "health_status": health.get("status"),
            "sqlite_integrity": health.get("sqlite_integrity"),
            "local_only": True,
            "network_required": False,
            "telemetry": False,
        }

    def export_audit_json(self, path: Path) -> Path:
        return self._write_json_payload(path, self.audit_report())

    def export_audit_csv(self, path: Path) -> Path:
        report = self.audit_report()
        ensure_parent(path)
        fields = ["name", "status", "count", "detail"]
        with path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            for check in report["checks"]:
                writer.writerow({field: check.get(field, "") for field in fields})
        return path

    def export_v1_bundle(self, dest_dir: Path) -> Dict[str, Any]:
        """Export a complete v1 handoff bundle without contacting any network service."""
        dest = Path(dest_dir).expanduser()
        if dest.suffix:
            dest = dest.with_suffix("")
        dest.mkdir(parents=True, exist_ok=True)
        files: Dict[str, Path] = {
            "inventory_csv": self.export_csv(dest / "sentinel_inventory_items.csv"),
            "inventory_json": self.export_json(dest / "sentinel_inventory_full_export.json"),
            "audit_json": self.export_audit_json(dest / "sentinel_inventory_audit.json"),
            "audit_csv": self.export_audit_csv(dest / "sentinel_inventory_audit.csv"),
            "expiry_csv": self.export_expiry_csv(dest / "sentinel_inventory_expiry_rotation.csv"),
            "reorder_csv": self.export_reorder_csv(dest / "sentinel_inventory_reorder.csv"),
            "labels_json": self.export_label_json(dest / "sentinel_inventory_label_payloads.json"),
            "backup_db": self.backup(dest / "Backups"),
        }
        bridge_manifest = self.export_bridge_bundle(dest / "Bridge_Handoff")
        stable_report_path = dest / "sentinel_inventory_v1_stable_lock_report.json"
        self._write_json_payload(stable_report_path, self.stable_lock_report())
        files["stable_lock_report"] = stable_report_path
        manifest = {
            "app": APP_NAME,
            "package": APP_ID,
            "program_number": 115,
            "version": VERSION,
            "stable_lock": "v1.0.0",
            "schema_version": SCHEMA_VERSION,
            "exported_at": now_iso(),
            "directory": str(dest),
            "files": {key: str(path) for key, path in files.items()},
            "bridge_bundle": bridge_manifest,
            "local_only": True,
            "network_required": False,
            "telemetry": False,
        }
        manifest_path = dest / "sentinel_inventory_v1_handoff_manifest.json"
        self._write_json_payload(manifest_path, manifest)
        manifest["files"]["manifest"] = str(manifest_path)
        return manifest

    def health(self) -> Dict[str, Any]:
        dash = self.dashboard()
        integrity = self.conn.execute("PRAGMA integrity_check").fetchone()[0]
        dash.update({
            "package": APP_ID,
            "program_number": 115,
            "status": "ok" if integrity == "ok" else "warning",
            "sqlite_integrity": integrity,
            "aegis_readable": True,
            "sentinel_command_ready": True,
            "ledger_bridge_ready": True,
            "pantry_bridge_ready": True,
            "desktop_icon_ready": find_icon_path() is not None,
            "desktop_launcher_ready": Path("/usr/share/applications/sentinel-inventory.desktop").exists(),
            "reporting_ready": True,
            "reorder_ready": True,
            "warranty_tracking_ready": True,
            "service_tracking_ready": True,
            "stock_expiry_tracking_ready": True,
            "expiry_rotation_ready": True,
            "freshest_stock_report_ready": True,
            "good_date_stock_report_ready": True,
            "expiry_csv_export_ready": True,
            "expiry_tab_ready": True,
            "desktop_shortcut_helper_ready": True,
            "sku_autofill_ready": True,
            "sequential_sku_ready": True,
            "usb_hid_scanner_ready": True,
            "scanner_tab_ready": True,
            "barcode_lookup_ready": True,
            "sku_scan_lookup_ready": True,
            "serial_scan_lookup_ready": True,
            "scan_movement_ready": True,
            "unknown_scan_create_ready": True,
            "fast_stock_movement_ready": True,
            "batch_scan_queue_ready": True,
            "scan_transfer_ready": True,
            "duplicate_scan_debounce_ready": True,
            "recent_scan_panel_ready": True,
            "scanner_driver_required": False,
            "ledger_bridge_export_ready": True,
            "pantry_bridge_export_ready": True,
            "supplier_reorder_handoff_ready": True,
            "bridge_bundle_ready": True,
            "bridge_manifest_ready": True,
            "v1_bridge_contract_prep_ready": True,
            "bridge_tab_ready": True,
            "label_csv_ready": True,
            "label_json_ready": True,
            "label_html_print_sheet_ready": True,
            "qr_payload_export_ready": True,
            "qr_png_export_ready_if_python3_qrcode_installed": True,
            "label_tab_ready": True,
            "stable_lock_ready": True,
            "v1_stable_baseline_locked": True,
            "audit_report_ready": True,
            "database_integrity_audit_ready": True,
            "backup_restore_ready": True,
            "v1_handoff_bundle_ready": True,
            "stable_lock_report_ready": True,
        })
        return dash


def print_table(rows: Sequence[sqlite3.Row], columns: Sequence[str]) -> None:
    if not rows:
        print("No records found.")
        return
    widths: Dict[str, int] = {}
    for col in columns:
        widths[col] = max(len(col), *(len(str(r[col])) for r in rows))
    header = "  ".join(col.ljust(widths[col]) for col in columns)
    print(header)
    print("  ".join("-" * widths[col] for col in columns))
    for r in rows:
        print("  ".join(str(r[col]).ljust(widths[col]) for col in columns))




def print_records_table(records: Sequence[Dict[str, Any]], columns: Sequence[str]) -> None:
    if not records:
        print("No records found.")
        return
    widths: Dict[str, int] = {}
    for col in columns:
        widths[col] = max(len(col), *(len(str(r.get(col, ""))) for r in records))
    header = "  ".join(col.ljust(widths[col]) for col in columns)
    print(header)
    print("  ".join("-" * widths[col] for col in columns))
    for r in records:
        print("  ".join(str(r.get(col, "")).ljust(widths[col]) for col in columns))


def default_export_path(suffix: str) -> Path:
    stamp = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    return DEFAULT_EXPORT_DIR / "Exports" / f"sentinel_inventory_{stamp}.{suffix}"


def make_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="sentinel-inventory", description=f"{APP_NAME} v{VERSION}")
    parser.add_argument("--db", default=str(DEFAULT_DB_PATH), help="Path to inventory SQLite database")
    parser.add_argument("--version", action="store_true", help="Print version and exit")
    sub = parser.add_subparsers(dest="command")

    sub.add_parser("init", help="Initialise the local inventory database")
    sub.add_parser("gui", help="Launch the graphical interface")
    sub.add_parser("dashboard", help="Show inventory dashboard summary")
    sub.add_parser("health-json", help="Print AEGIS/Sentinel Command readable JSON status")
    sub.add_parser("self-test", help="Run a non-destructive application self-test")
    next_sku_p = sub.add_parser("next-sku", help="Print the next generated sequential SKU")
    next_sku_p.add_argument("--prefix", default="", help="Optional SKU prefix override")
    prefix_p = sub.add_parser("set-sku-prefix", help="Set the default prefix used for generated SKUs")
    prefix_p.add_argument("prefix", help="Prefix such as INV, TOOL, PART, or STOCK")

    add = sub.add_parser("add", help="Add an inventory item")
    add.add_argument("name")
    add.add_argument("--sku", default="")
    add.add_argument("--sku-prefix", default="", help="Generate the next SKU with this prefix when --sku is omitted")
    add.add_argument("--category", default="General")
    add.add_argument("--location", default="Unsorted")
    add.add_argument("--quantity", type=float, default=0.0)
    add.add_argument("--unit", default="ea")
    add.add_argument("--low-stock", type=float, default=0.0)
    add.add_argument("--cost", type=float, default=0.0)
    add.add_argument("--price", type=float, default=0.0)
    add.add_argument("--vendor", default="")
    add.add_argument("--serial", default="")
    add.add_argument("--barcode", default="")
    add.add_argument("--warranty", default="")
    add.add_argument("--expiry", default="", help="Stock expiry / best-before date, preferably YYYY-MM-DD")
    add.add_argument("--condition", default="Good")
    add.add_argument("--notes", default="")

    listp = sub.add_parser("list", help="List inventory items")
    listp.add_argument("--query", default="")
    listp.add_argument("--archived", action="store_true")
    listp.add_argument("--low-stock", action="store_true")
    listp.add_argument("--category", default="")
    listp.add_argument("--location", default="")

    for name, help_text in [
        ("adjust", "Adjust quantity by positive/negative delta"),
        ("restock", "Increase quantity"),
        ("consume", "Decrease quantity"),
    ]:
        p = sub.add_parser(name, help=help_text)
        p.add_argument("identifier", help="Item id or SKU")
        p.add_argument("quantity", type=float, help="Quantity amount")
        p.add_argument("--note", default="")
        p.add_argument("--reference", default="")

    arch = sub.add_parser("archive", help="Archive an item")
    arch.add_argument("identifier")
    unarch = sub.add_parser("unarchive", help="Restore an archived item")
    unarch.add_argument("identifier")

    expc = sub.add_parser("export-csv", help="Export inventory to CSV")
    expc.add_argument("path", nargs="?", default="")
    expj = sub.add_parser("export-json", help="Export inventory and movements to JSON")
    expj.add_argument("path", nargs="?", default="")

    imp = sub.add_parser("import-csv", help="Import inventory from CSV")
    imp.add_argument("path")
    imp.add_argument("--no-update", action="store_true")

    b = sub.add_parser("backup", help="Create a database backup")
    b.add_argument("dest_dir", nargs="?", default="")
    rb = sub.add_parser("restore-backup", help="Restore a Sentinel Inventory SQLite backup; requires explicit confirmation")
    rb.add_argument("backup_path", help="Path to a sentinel_inventory_backup_*.db file")
    rb.add_argument("--confirm", default="", help="Required value: RESTORE_INVENTORY")
    audit = sub.add_parser("audit-report", help="Run v1 database integrity/audit checks")
    audit.add_argument("--json", action="store_true", help="Print machine-readable audit JSON")
    audit_json = sub.add_parser("export-audit-json", help="Export v1 audit report to JSON")
    audit_json.add_argument("path", nargs="?", default="")
    audit_csv = sub.add_parser("export-audit-csv", help="Export v1 audit checks to CSV")
    audit_csv.add_argument("path", nargs="?", default="")
    sub.add_parser("stable-lock-report", help="Print v1 stable lock report JSON")
    v1_bundle = sub.add_parser("export-v1-bundle", help="Export complete v1 local handoff bundle")
    v1_bundle.add_argument("dest_dir", nargs="?", default="")

    sub.add_parser("movements", help="Show recent movement/audit records")
    sub.add_parser("low-stock", help="Show low stock items")
    sub.add_parser("categories", help="List categories")
    sub.add_parser("locations", help="List locations")
    rep = sub.add_parser("summary", help="Show category or location valuation summary")
    rep.add_argument("--by", choices=["category", "location"], default="category")
    sub.add_parser("reorder-list", help="Show low-stock reorder list with suggested order quantities")
    reorder_exp = sub.add_parser("export-reorder-csv", help="Export low-stock reorder list to CSV")
    reorder_exp.add_argument("path", nargs="?", default="")

    warr = sub.add_parser("warranty-report", help="Show warranty items expired or expiring soon")
    warr.add_argument("--days", type=int, default=90, help="Lookahead window in days")
    warr.add_argument("--no-expired", action="store_true", help="Hide already expired warranty records")
    warr_exp = sub.add_parser("export-warranty-csv", help="Export warranty expiry report to CSV")
    warr_exp.add_argument("path", nargs="?", default="")
    warr_exp.add_argument("--days", type=int, default=90)

    exp_report = sub.add_parser("expiry-report", help="Show expired, expiring-soon, good-date, or all date-tracked stock")
    exp_report.add_argument("--days", type=int, default=DEFAULT_EXPIRY_WARNING_DAYS, help="Lookahead window for close-to-expiry stock")
    exp_report.add_argument("--status", choices=["all", "expired", "expiring", "good", "unknown"], default="all")
    exp_report.add_argument("--include-unknown", action="store_true")
    fresh = sub.add_parser("freshest-stock", help="Show stock with the furthest expiry/best-before dates")
    fresh.add_argument("--limit", type=int, default=20)
    exp_csv = sub.add_parser("export-expiry-csv", help="Export stock expiry / freshness report to CSV")
    exp_csv.add_argument("path", nargs="?", default="")
    exp_csv.add_argument("--days", type=int, default=DEFAULT_EXPIRY_WARNING_DAYS)
    exp_csv.add_argument("--status", choices=["all", "expired", "expiring", "good", "unknown"], default="all")
    exp_csv.add_argument("--include-unknown", action="store_true")

    svc_add = sub.add_parser("service-add", help="Add a service/repair/maintenance record for an item")
    svc_add.add_argument("identifier", help="Item id or SKU")
    svc_add.add_argument("--type", default="service")
    svc_add.add_argument("--description", default="")
    svc_add.add_argument("--cost", type=float, default=0.0)
    svc_add.add_argument("--provider", default="")
    svc_add.add_argument("--performed", default="")
    svc_add.add_argument("--next-due", default="")
    svc_add.add_argument("--reference", default="")
    svc_list = sub.add_parser("service-list", help="List service/repair/maintenance records")
    svc_list.add_argument("--identifier", default="", help="Optional item id or SKU")
    svc_due = sub.add_parser("service-due", help="Show service records due soon")
    svc_due.add_argument("--days", type=int, default=30)
    svc_exp = sub.add_parser("export-service-csv", help="Export service records to CSV")
    svc_exp.add_argument("path", nargs="?", default="")

    scan = sub.add_parser("scan", help="Lookup an item by USB scanner barcode, SKU, or serial input")
    scan.add_argument("code", help="Scanned barcode, SKU, or serial number")
    scan.add_argument("--json", action="store_true", help="Print machine-readable lookup JSON")
    for scan_cmd, help_text in [
        ("scan-restock", "Lookup a scan code and increase quantity"),
        ("scan-consume", "Lookup a scan code and decrease quantity"),
        ("scan-adjust", "Lookup a scan code and apply a signed quantity delta"),
    ]:
        sp = sub.add_parser(scan_cmd, help=help_text)
        sp.add_argument("code", help="Scanned barcode, SKU, or serial number")
        sp.add_argument("quantity", type=float, nargs="?", default=1.0, help="Quantity amount, default 1")
        sp.add_argument("--note", default="")
        sp.add_argument("--reference", default="")
        sp.add_argument("--json", action="store_true")
    scan_create = sub.add_parser("scan-create", help="Create a new item from an unknown scanned barcode/SKU/serial")
    scan_create.add_argument("code", help="Scanned code to save")
    scan_create.add_argument("name", help="New item name")
    scan_create.add_argument("--code-field", choices=["barcode", "sku", "serial"], default="barcode", help="Where to store the scanned code")
    scan_create.add_argument("--sku", default="", help="Manual SKU; otherwise the next sequence is used unless --code-field sku is selected")
    scan_create.add_argument("--category", default="General")
    scan_create.add_argument("--location", default="Unsorted")
    scan_create.add_argument("--quantity", type=float, default=0.0)
    scan_create.add_argument("--unit", default="ea")
    scan_create.add_argument("--low-stock", type=float, default=0.0)
    scan_create.add_argument("--cost", type=float, default=0.0)
    scan_create.add_argument("--price", type=float, default=0.0)
    scan_create.add_argument("--vendor", default="")
    scan_create.add_argument("--condition", default="Good")
    scan_create.add_argument("--expiry", default="", help="Stock expiry / best-before date, preferably YYYY-MM-DD")
    scan_create.add_argument("--notes", default="")

    set_scan = sub.add_parser("set-scanner-defaults", help="Set scanner fast-mode defaults")
    set_scan.add_argument("--mode", choices=sorted(SCAN_MODES), default="")
    set_scan.add_argument("--quantity", type=float, default=None)
    set_scan.add_argument("--debounce", type=float, default=None, help="Duplicate debounce window in seconds")
    set_scan.add_argument("--suffix", default="", help="Expected scanner suffix, usually enter or tab")

    scan_fast = sub.add_parser("scan-fast", help="Apply the configured scanner fast mode to one scanned code")
    scan_fast.add_argument("code", help="Scanned barcode, SKU, or serial number")
    scan_fast.add_argument("--mode", choices=sorted(SCAN_MODES), default="", help="Override configured fast mode")
    scan_fast.add_argument("--quantity", type=float, default=None)
    scan_fast.add_argument("--location", default="", help="Target location for transfer mode")
    scan_fast.add_argument("--note", default="")
    scan_fast.add_argument("--reference", default="")
    scan_fast.add_argument("--json", action="store_true")

    scan_transfer = sub.add_parser("scan-transfer", help="Lookup a scan code and transfer the item to a location")
    scan_transfer.add_argument("code", help="Scanned barcode, SKU, or serial number")
    scan_transfer.add_argument("location", help="New item location")
    scan_transfer.add_argument("--note", default="")
    scan_transfer.add_argument("--reference", default="")
    scan_transfer.add_argument("--json", action="store_true")

    scan_batch = sub.add_parser("scan-batch", help="Run a batch of scanned codes from a text/CSV file")
    scan_batch.add_argument("path", help="Text/CSV file containing one scan code per line or first column")
    scan_batch.add_argument("--mode", choices=sorted(SCAN_MODES), default="restock")
    scan_batch.add_argument("--quantity", type=float, default=1.0)
    scan_batch.add_argument("--location", default="", help="Target location for transfer mode")
    scan_batch.add_argument("--note", default="")
    scan_batch.add_argument("--no-debounce", action="store_true", help="Do not skip consecutive duplicate scans")
    scan_batch.add_argument("--json", action="store_true")

    recent = sub.add_parser("recent-scans", help="Show recent scanner movement records")
    recent.add_argument("--limit", type=int, default=100)
    recent_exp = sub.add_parser("export-recent-scans-csv", help="Export recent scanner movement records to CSV")
    recent_exp.add_argument("path", nargs="?", default="")
    recent_exp.add_argument("--limit", type=int, default=500)


    label_prev = sub.add_parser("label-preview", help="Show one label/QR payload record for an item id/SKU/barcode/serial")
    label_prev.add_argument("identifier")

    labels = sub.add_parser("labels", help="List label-ready item records")
    labels.add_argument("--query", default="")
    labels.add_argument("--category", default="")
    labels.add_argument("--location", default="")
    labels.add_argument("--low-stock", action="store_true")
    labels.add_argument("--archived", action="store_true")

    label_csv = sub.add_parser("export-label-csv", help="Export item label/QR payload data to CSV")
    label_csv.add_argument("path", nargs="?", default="")
    label_csv.add_argument("--query", default="")
    label_csv.add_argument("--category", default="")
    label_csv.add_argument("--location", default="")
    label_csv.add_argument("--low-stock", action="store_true")
    label_csv.add_argument("--archived", action="store_true")
    label_csv.add_argument("--identifier", action="append", default=[], help="Explicit item id/SKU/barcode/serial; may be repeated")

    label_json = sub.add_parser("export-label-json", help="Export item label/QR payload data to JSON")
    label_json.add_argument("path", nargs="?", default="")
    label_json.add_argument("--query", default="")
    label_json.add_argument("--category", default="")
    label_json.add_argument("--location", default="")
    label_json.add_argument("--low-stock", action="store_true")
    label_json.add_argument("--archived", action="store_true")
    label_json.add_argument("--identifier", action="append", default=[])

    label_html = sub.add_parser("export-label-html", help="Export a printable local HTML label sheet")
    label_html.add_argument("path", nargs="?", default="")
    label_html.add_argument("--query", default="")
    label_html.add_argument("--category", default="")
    label_html.add_argument("--location", default="")
    label_html.add_argument("--low-stock", action="store_true")
    label_html.add_argument("--archived", action="store_true")
    label_html.add_argument("--identifier", action="append", default=[])
    label_html.add_argument("--copies", type=int, default=1)

    qr_png = sub.add_parser("export-qr-png", help="Export one local QR PNG per item using optional python3-qrcode")
    qr_png.add_argument("dest_dir", nargs="?", default="")
    qr_png.add_argument("--query", default="")
    qr_png.add_argument("--category", default="")
    qr_png.add_argument("--location", default="")
    qr_png.add_argument("--low-stock", action="store_true")
    qr_png.add_argument("--archived", action="store_true")
    qr_png.add_argument("--identifier", action="append", default=[])


    bridge_status = sub.add_parser("bridge-status", help="Show Ledger/Pantry bridge readiness JSON")
    bridge_status.add_argument("--json", action="store_true", help="Print full machine-readable bridge status")

    ledger_csv = sub.add_parser("export-ledger-bridge-csv", help="Export Sentinel Ledger inventory valuation bridge CSV")
    ledger_csv.add_argument("path", nargs="?", default="")
    ledger_csv.add_argument("--archived", action="store_true")
    ledger_csv.add_argument("--no-zero", action="store_true", help="Skip zero-quantity items")
    ledger_json = sub.add_parser("export-ledger-bridge-json", help="Export Sentinel Ledger inventory valuation bridge JSON")
    ledger_json.add_argument("path", nargs="?", default="")
    ledger_json.add_argument("--archived", action="store_true")
    ledger_json.add_argument("--no-zero", action="store_true")

    pantry_csv = sub.add_parser("export-pantry-bridge-csv", help="Export Sentinel Pantry/consumables rotation bridge CSV")
    pantry_csv.add_argument("path", nargs="?", default="")
    pantry_csv.add_argument("--all", action="store_true", help="Include every item instead of only likely pantry/consumable candidates")
    pantry_csv.add_argument("--archived", action="store_true")
    pantry_json = sub.add_parser("export-pantry-bridge-json", help="Export Sentinel Pantry/consumables rotation bridge JSON")
    pantry_json.add_argument("path", nargs="?", default="")
    pantry_json.add_argument("--all", action="store_true")
    pantry_json.add_argument("--archived", action="store_true")

    bridge_bundle = sub.add_parser("export-bridge-bundle", help="Export Ledger/Pantry/reorder/expiry bridge handoff bundle")
    bridge_bundle.add_argument("dest_dir", nargs="?", default="")

    dl = sub.add_parser("install-desktop-launcher", help="Install a Sentinel Inventory shortcut onto this user's Desktop")
    dl.add_argument("dest_dir", nargs="?", default="")
    return parser


def cmd_self_test(db_path: Path) -> int:
    import tempfile
    with tempfile.TemporaryDirectory(prefix="sentinel_inventory_test_") as td:
        test_db = Path(td) / "test.db"
        db = InventoryDB(test_db)
        first_auto_sku = db.next_sku()
        auto_iid = db.add_item(Item(None, "", "Auto SKU Item", "Test", "Bench", 1, "ea", 0, 1.00, 2.00), "self-test auto sku create")
        second_auto_sku = db.next_sku()
        iid = db.add_item(Item(None, "TST-0001", "Self Test Item", "Test", "Bench", 5, "ea", 2, 1.25, 2.5, serial_number="SER-TST-001", barcode="BC-TST-001"), "self-test create")
        scan_lookup = db.scan_lookup("BC-TST-001")
        serial_lookup = db.scan_lookup("SER-TST-001")
        db.scan_movement("BC-TST-001", 1, "consume", "self-test scanner consume")
        db.scan_movement("TST-0001", 2, "restock", "self-test scanner restock")
        db.scan_transfer("SER-TST-001", "Service Bench", "self-test scanner transfer")
        db.update_item(iid, {"expiry_date": (today() + _dt.timedelta(days=10)).isoformat()}, "self-test expiry update")
        fresh_id = db.add_item(Item(None, "TST-FRESH", "Fresh Stock", "Test", "Cool Room", 3, "ea", 0, 1.25, 2.5, barcode="BC-FRESH", expiry_date=(today() + _dt.timedelta(days=365)).isoformat()), "self-test freshest stock")
        batch_result = db.scan_batch(["BC-TST-001", "BC-TST-001", "TST-0001"], mode="lookup", debounce_consecutive=True)
        db.adjust_quantity(iid, -1, "consume", "self-test consume")
        dash = db.dashboard()
        auto_row = db.get_item(auto_iid)
        ok = (
            dash["total_items"] == 3
            and abs(dash["total_units"] - 9) < 0.0001
            and auto_row is not None
            and auto_row["sku"] == first_auto_sku
            and second_auto_sku == "INV-0002"
            and scan_lookup.get("found") is True
            and serial_lookup.get("found") is True
            and batch_result.get("skipped_duplicates") == 1
            and dash.get("scan_transfer_ready") is True
        )
        db.export_csv(Path(td) / "export.csv")
        db.export_json(Path(td) / "export.json")
        db.add_service_record(iid, "test", "self-test service record", 0, "Sentinel", today().isoformat(), (today() + _dt.timedelta(days=7)).isoformat(), "SELFTEST")
        db.update_item(iid, {"warranty_expiry": (today() + _dt.timedelta(days=14)).isoformat()}, "self-test warranty update")
        db.export_reorder_csv(Path(td) / "reorder.csv")
        db.export_warranty_csv(Path(td) / "warranty.csv")
        db.export_expiry_csv(Path(td) / "expiry.csv")
        db.export_service_csv(Path(td) / "service.csv")
        db.export_recent_scan_csv(Path(td) / "recent_scans.csv")
        db.export_label_csv(Path(td) / "labels.csv")
        db.export_label_json(Path(td) / "labels.json")
        db.export_label_html(Path(td) / "labels.html")
        db.export_ledger_bridge_csv(Path(td) / "ledger_bridge.csv")
        db.export_ledger_bridge_json(Path(td) / "ledger_bridge.json")
        db.export_pantry_bridge_csv(Path(td) / "pantry_bridge.csv")
        db.export_pantry_bridge_json(Path(td) / "pantry_bridge.json")
        bundle = db.export_bridge_bundle(Path(td) / "bridge_bundle")
        audit = db.audit_report()
        db.export_audit_json(Path(td) / "audit.json")
        db.export_audit_csv(Path(td) / "audit.csv")
        v1_bundle = db.export_v1_bundle(Path(td) / "v1_bundle")
        backup_path = db.backup(Path(td) / "restore_test")
        restore_result = db.restore_backup(backup_path, confirm="RESTORE_INVENTORY")
        try:
            db.export_qr_pngs(Path(td) / "qr_png")
        except RuntimeError:
            pass
        _label_rows = db.label_rows()
        _category_rows = db.category_summary()
        _location_rows = db.location_summary()
        _reorder_rows = db.reorder_items()
        _warranty_rows = db.warranty_report()
        _expiry_rows = db.expiry_report(days=30)
        _freshest_rows = db.freshest_stock(limit=5)
        _service_due = db.service_due()
        health = db.health()
        ok = ok and bool(_expiry_rows) and bool(_freshest_rows) and _freshest_rows[0]["sku"] == "TST-FRESH" and health.get("stock_expiry_tracking_ready") is True
        ok = ok and health.get("ledger_bridge_export_ready") is True and health.get("pantry_bridge_export_ready") is True and bool(bundle.get("files", {}).get("manifest"))
        ok = ok and audit.get("overall_status") in {"ok", "warning"} and bool(v1_bundle.get("files", {}).get("manifest")) and restore_result.get("restored") is True
        ok = ok and health.get("v1_stable_baseline_locked") is True and health.get("audit_report_ready") is True and health.get("backup_restore_ready") is True
        db.close()
        if not ok or health.get("sqlite_integrity") != "ok":
            print("Sentinel Inventory self-test failed.")
            return 1
        print(f"{APP_NAME} v{VERSION} self-test passed.")
        print("Checks: schema, sequential SKU autofill, expiry/freshness rotation, barcode/SKU/serial scanner lookup, fast scanner movement, scan transfer, batch scan duplicate debounce, add item, quantity movement, dashboard, summaries, warranty/service tracking, reorder CSV, scan CSV export, label CSV/JSON/HTML export, optional QR PNG export, Ledger/Pantry bridge exports, bridge bundle manifest, backup/restore, v1 audit report, v1 handoff bundle, stable lock flags, CSV export, JSON export, integrity.")
        return 0


def run_cli(argv: Optional[Sequence[str]] = None) -> int:
    parser = make_parser()
    args = parser.parse_args(argv)
    if args.version:
        print(f"{APP_NAME} v{VERSION}")
        return 0
    if args.command == "gui" or args.command is None:
        return launch_gui(Path(args.db))
    if args.command == "self-test":
        return cmd_self_test(Path(args.db))

    db = InventoryDB(Path(args.db))
    try:
        if args.command == "init":
            print(f"Initialised {APP_NAME} database: {db.init_db()}")
            return 0
        if args.command == "dashboard":
            d = db.dashboard()
            print(f"{APP_NAME} v{VERSION}")
            print(f"Database: {d['db_path']}")
            print(f"Items: {d['total_items']} active / {d['archived_items']} archived")
            print(f"Units: {d['total_units']:,.2f}")
            print(f"Low stock: {d['low_stock_items']}")
            print(f"Expiry: {d['stock_expired_items']} expired | {d['stock_expiring_soon_items']} close | {d['stock_good_date_items']} good-date | freshest {d['freshest_stock_item'] or 'None'}")
            print(f"Categories: {d['categories']} | Locations: {d['locations']}")
            print(f"Cost value: {fmt_money(d['inventory_cost_value'])}")
            print(f"Sale value: {fmt_money(d['inventory_sale_value'])}")
            return 0
        if args.command == "health-json":
            print(json.dumps(db.health(), indent=2))
            return 0
        if args.command == "stable-lock-report":
            print(json.dumps(db.stable_lock_report(), indent=2))
            return 0
        if args.command == "audit-report":
            report = db.audit_report()
            if args.json:
                print(json.dumps(report, indent=2))
            else:
                print(f"{APP_NAME} v{VERSION} audit: {report['overall_status']}")
                print_records_table(report["checks"], ["name", "status", "count", "detail"])
            return 0
        if args.command == "export-audit-json":
            path = Path(args.path).expanduser() if args.path else default_export_path("audit.json")
            print(f"Exported audit JSON: {db.export_audit_json(path)}")
            return 0
        if args.command == "export-audit-csv":
            path = Path(args.path).expanduser() if args.path else default_export_path("audit.csv")
            print(f"Exported audit CSV: {db.export_audit_csv(path)}")
            return 0
        if args.command == "export-v1-bundle":
            stamp = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
            dest = Path(args.dest_dir).expanduser() if args.dest_dir else DEFAULT_EXPORT_DIR / f"sentinel_inventory_v1_handoff_{stamp}"
            print(json.dumps(db.export_v1_bundle(dest), indent=2))
            return 0
        if args.command == "next-sku":
            print(db.next_sku(args.prefix))
            return 0
        if args.command == "set-sku-prefix":
            print(f"Default SKU prefix set to {db.set_sku_prefix(args.prefix)}")
            print(f"Next SKU: {db.next_sku()}")
            return 0
        if args.command == "add":
            supplied_sku = args.sku.strip() or (db.next_sku(args.sku_prefix) if args.sku_prefix else "")
            iid = db.add_item(
                Item(
                    id=None,
                    sku=supplied_sku,
                    name=args.name,
                    category=args.category,
                    location=args.location,
                    quantity=args.quantity,
                    unit=args.unit,
                    low_stock_threshold=args.low_stock,
                    cost_each=args.cost,
                    sale_price_each=args.price,
                    vendor=args.vendor,
                    serial_number=args.serial,
                    barcode=args.barcode,
                    warranty_expiry=args.warranty,
                    expiry_date=args.expiry,
                    condition=args.condition,
                    notes=args.notes,
                )
            )
            row = db.get_item(iid)
            print(f"Added item #{iid}: {row['sku']} — {row['name']}")
            return 0
        if args.command == "list":
            rows = db.list_items(args.query, args.archived, args.low_stock, args.category, args.location)
            print_table(rows, ["id", "sku", "name", "category", "location", "quantity", "unit", "status"])
            return 0
        if args.command in {"adjust", "restock", "consume"}:
            row = db.resolve_item(args.identifier)
            if not row:
                print(f"Item not found: {args.identifier}", file=sys.stderr)
                return 2
            qty = coerce_float(args.quantity)
            if args.command == "consume":
                delta = -abs(qty)
                mtype = "consume"
            elif args.command == "restock":
                delta = abs(qty)
                mtype = "restock"
            else:
                delta = qty
                mtype = "adjust"
            after = db.adjust_quantity(int(row["id"]), delta, mtype, args.note, args.reference)
            print(f"{row['sku']} quantity is now {after:g} {row['unit']}")
            return 0
        if args.command == "scan":
            result = db.scan_lookup(args.code)
            if args.json:
                print(json.dumps(result, indent=2))
                return 0 if result.get("found") else 2
            if not result.get("found"):
                print(f"UNKNOWN SCAN: {normalize_scan_code(args.code)}")
                print(result.get("message", "No matching item."))
                return 2
            item = result["item"]
            print(f"FOUND via {result['match_type']}: {item['sku']} — {item['name']}")
            print(f"Quantity: {coerce_float(item['quantity']):g} {item['unit']} | Location: {item['location']} | Barcode: {item['barcode']} | Serial: {item['serial_number']}")
            return 0
        if args.command in {"scan-restock", "scan-consume", "scan-adjust"}:
            mode = {"scan-restock": "restock", "scan-consume": "consume", "scan-adjust": "adjust"}[args.command]
            result = db.scan_movement(args.code, args.quantity, mode, args.note, args.reference)
            if args.json:
                print(json.dumps(result, indent=2))
                return 0 if result.get("found") else 2
            if not result.get("found"):
                print(f"UNKNOWN SCAN: {normalize_scan_code(args.code)}", file=sys.stderr)
                return 2
            item = result["item"]
            print(f"{item['sku']} — {item['name']} quantity is now {coerce_float(result['qty_after']):g} {item['unit']}")
            return 0
        if args.command == "scan-create":
            code = normalize_scan_code(args.code)
            if not code:
                print("Scan code is required.", file=sys.stderr)
                return 2
            existing = db.resolve_scan(code)
            if existing:
                print(f"Scan code already resolves to {existing['sku']} — {existing['name']}", file=sys.stderr)
                return 2
            sku = args.sku.strip()
            barcode = ""
            serial = ""
            if args.code_field == "sku":
                sku = sku or code
            elif args.code_field == "serial":
                serial = code
            else:
                barcode = code
            iid = db.add_item(Item(
                id=None, sku=sku, name=args.name, category=args.category, location=args.location,
                quantity=args.quantity, unit=args.unit, low_stock_threshold=args.low_stock,
                cost_each=args.cost, sale_price_each=args.price, vendor=args.vendor,
                serial_number=serial, barcode=barcode, expiry_date=args.expiry, condition=args.condition, notes=args.notes,
            ), f"Created from scanner input {code}")
            row = db.get_item(iid)
            print(f"Created item #{iid}: {row['sku']} — {row['name']} from scan {code}")
            return 0
        if args.command == "set-scanner-defaults":
            result = db.set_scanner_defaults(args.mode, args.quantity, args.debounce, args.suffix)
            print(json.dumps(result, indent=2))
            return 0
        if args.command == "scan-fast":
            result = db.fast_scan(args.code, args.mode, args.quantity, args.location, args.note, args.reference)
            if args.json:
                print(json.dumps(result, indent=2))
                return 0 if result.get("found") else 2
            if not result.get("found"):
                print(f"UNKNOWN SCAN: {normalize_scan_code(args.code)}", file=sys.stderr)
                return 2
            item = result.get("item", {})
            action = str(result.get("movement_type", "scan_lookup")).replace("_", " ").title()
            if result.get("movement_type") == "scan_lookup":
                print(f"FOUND: {item['sku']} — {item['name']} | Quantity {coerce_float(item['quantity']):g} {item['unit']} | Location {item['location']}")
            elif result.get("movement_type") == "scan_transfer":
                print(f"{action}: {item['sku']} — {item['name']} moved to {result.get('to_location', item.get('location', ''))}")
            else:
                print(f"{action}: {item['sku']} — {item['name']} quantity is now {coerce_float(result.get('qty_after')):g} {item['unit']}")
            return 0
        if args.command == "scan-transfer":
            result = db.scan_transfer(args.code, args.location, args.note, args.reference)
            if args.json:
                print(json.dumps(result, indent=2))
                return 0 if result.get("found") else 2
            if not result.get("found"):
                print(f"UNKNOWN SCAN: {normalize_scan_code(args.code)}", file=sys.stderr)
                return 2
            item = result["item"]
            print(f"{item['sku']} — {item['name']} moved to {result['to_location']}")
            return 0
        if args.command == "scan-batch":
            path = Path(args.path).expanduser()
            if not path.exists():
                print(f"Batch file not found: {path}", file=sys.stderr)
                return 2
            codes: List[str] = []
            with path.open("r", encoding="utf-8-sig", newline="") as f:
                sample = f.read()
            for row in csv.reader(sample.splitlines()):
                if row:
                    codes.append(row[0])
            result = db.scan_batch(codes, args.mode, args.quantity, args.location, args.note, debounce_consecutive=not args.no_debounce)
            if args.json:
                print(json.dumps(result, indent=2))
            else:
                print(f"Batch mode: {result['mode']}")
                print(f"Total: {result['total_scans']} | Found: {result['found']} | Moved: {result['moved']} | Unknown/errors: {result['unknown']} | Debounced duplicates: {result['skipped_duplicates']}")
                for r in result["results"]:
                    if r.get("skipped"):
                        print(f"SKIPPED duplicate: {r.get('scan_code')}")
                    elif r.get("found"):
                        item = r.get("item", {})
                        print(f"OK {r.get('movement_type', 'scan')}: {item.get('sku', '')} — {item.get('name', '')}")
                    else:
                        print(f"UNKNOWN/ERROR: {r.get('scan_code', '')} {r.get('message', r.get('error', ''))}")
            return 0 if result.get("unknown", 0) == 0 else 2
        if args.command == "recent-scans":
            rows = db.recent_scan_movements(limit=args.limit)
            print_table(rows, ["id", "sku", "movement_type", "qty_delta", "qty_after", "reference", "created_at", "note"])
            return 0
        if args.command == "export-recent-scans-csv":
            path = Path(args.path).expanduser() if args.path else default_export_path("recent_scans.csv")
            print(f"Exported recent scan CSV: {db.export_recent_scan_csv(path, limit=args.limit)}")
            return 0
        if args.command == "label-preview":
            row = db.resolve_item(args.identifier)
            if not row:
                print(f"Item not found: {args.identifier}", file=sys.stderr)
                return 2
            print(json.dumps(db.label_record(row), indent=2))
            return 0
        if args.command == "labels":
            records = db.label_rows(args.query, args.archived, args.low_stock, args.category, args.location)
            print_records_table(records, ["id", "sku", "name", "category", "location", "scan_code", "qr_payload"])
            return 0
        if args.command == "export-label-csv":
            path = Path(args.path).expanduser() if args.path else default_export_path("labels.csv")
            out = db.export_label_csv(path, args.query, args.archived, args.low_stock, args.category, args.location, args.identifier or None)
            print(f"Exported label CSV: {out}")
            return 0
        if args.command == "export-label-json":
            path = Path(args.path).expanduser() if args.path else default_export_path("labels.json")
            out = db.export_label_json(path, args.query, args.archived, args.low_stock, args.category, args.location, args.identifier or None)
            print(f"Exported label JSON: {out}")
            return 0
        if args.command == "export-label-html":
            path = Path(args.path).expanduser() if args.path else default_export_path("labels.html")
            out = db.export_label_html(path, args.query, args.archived, args.low_stock, args.category, args.location, args.identifier or None, args.copies)
            print(f"Exported printable label HTML: {out}")
            return 0
        if args.command == "export-qr-png":
            dest = Path(args.dest_dir).expanduser() if args.dest_dir else DEFAULT_LABEL_DIR / "QR_PNG"
            try:
                result = db.export_qr_pngs(dest, args.query, args.archived, args.low_stock, args.category, args.location, args.identifier or None)
            except RuntimeError as exc:
                print(str(exc), file=sys.stderr)
                return 2
            print(json.dumps(result, indent=2))
            return 0

        if args.command == "bridge-status":
            status = db.bridge_status()
            if args.json:
                print(json.dumps(status, indent=2))
            else:
                print(f"{APP_NAME} bridge contract v{status['bridge_contract_version']}")
                print(f"Ledger rows: {status['ledger_rows']}")
                print(f"Pantry candidate rows: {status['pantry_candidate_rows']}")
                print(f"Supplier reorder rows: {status['supplier_reorder_rows']}")
                print("Ready: Ledger bridge, Pantry bridge, supplier reorder handoff, bridge bundle manifest")
            return 0
        if args.command == "export-ledger-bridge-csv":
            path = Path(args.path).expanduser() if args.path else default_export_path("ledger_bridge.csv")
            print(f"Exported Ledger bridge CSV: {db.export_ledger_bridge_csv(path, include_archived=args.archived, include_zero=not args.no_zero)}")
            return 0
        if args.command == "export-ledger-bridge-json":
            path = Path(args.path).expanduser() if args.path else default_export_path("ledger_bridge.json")
            print(f"Exported Ledger bridge JSON: {db.export_ledger_bridge_json(path, include_archived=args.archived, include_zero=not args.no_zero)}")
            return 0
        if args.command == "export-pantry-bridge-csv":
            path = Path(args.path).expanduser() if args.path else default_export_path("pantry_bridge.csv")
            print(f"Exported Pantry bridge CSV: {db.export_pantry_bridge_csv(path, include_all=args.all, include_archived=args.archived)}")
            return 0
        if args.command == "export-pantry-bridge-json":
            path = Path(args.path).expanduser() if args.path else default_export_path("pantry_bridge.json")
            print(f"Exported Pantry bridge JSON: {db.export_pantry_bridge_json(path, include_all=args.all, include_archived=args.archived)}")
            return 0
        if args.command == "export-bridge-bundle":
            stamp = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
            dest = Path(args.dest_dir).expanduser() if args.dest_dir else DEFAULT_BRIDGE_DIR / f"sentinel_inventory_bridge_bundle_{stamp}"
            result = db.export_bridge_bundle(dest)
            print(json.dumps(result, indent=2))
            return 0
        if args.command in {"archive", "unarchive"}:
            row = db.resolve_item(args.identifier)
            if not row:
                print(f"Item not found: {args.identifier}", file=sys.stderr)
                return 2
            db.archive_item(int(row["id"]), archived=args.command == "archive")
            print(("Archived" if args.command == "archive" else "Restored") + f" {row['sku']} — {row['name']}")
            return 0
        if args.command == "export-csv":
            path = Path(args.path).expanduser() if args.path else default_export_path("csv")
            print(f"Exported CSV: {db.export_csv(path)}")
            return 0
        if args.command == "export-json":
            path = Path(args.path).expanduser() if args.path else default_export_path("json")
            print(f"Exported JSON: {db.export_json(path)}")
            return 0
        if args.command == "import-csv":
            result = db.import_csv(Path(args.path).expanduser(), update_existing=not args.no_update)
            print(json.dumps(result, indent=2))
            return 0
        if args.command == "backup":
            dest = Path(args.dest_dir).expanduser() if args.dest_dir else None
            print(f"Backup created: {db.backup(dest)}")
            return 0
        if args.command == "restore-backup":
            result = db.restore_backup(Path(args.backup_path).expanduser(), confirm=args.confirm)
            print(json.dumps(result, indent=2))
            return 0
        if args.command == "movements":
            rows = db.list_movements()
            print_table(rows, ["id", "sku", "movement_type", "qty_delta", "qty_after", "created_at", "note"])
            return 0
        if args.command == "low-stock":
            rows = db.low_stock_items()
            print_table(rows, ["id", "sku", "name", "quantity", "unit", "low_stock_threshold", "location"])
            return 0
        if args.command == "summary":
            if args.by == "location":
                rows = db.location_summary()
                print_table(rows, ["location", "item_count", "total_units", "cost_value", "sale_value"])
            else:
                rows = db.category_summary()
                print_table(rows, ["category", "item_count", "total_units", "cost_value", "sale_value"])
            return 0
        if args.command == "reorder-list":
            rows = db.reorder_items()
            print_table(rows, ["id", "sku", "name", "quantity", "unit", "low_stock_threshold", "suggested_order_qty", "vendor"])
            return 0
        if args.command == "export-reorder-csv":
            path = Path(args.path).expanduser() if args.path else default_export_path("reorder.csv")
            print(f"Exported reorder CSV: {db.export_reorder_csv(path)}")
            return 0
        if args.command == "warranty-report":
            rows = db.warranty_report(days=args.days, include_expired=not args.no_expired)
            print_table(rows, ["id", "sku", "name", "warranty_expiry", "days_remaining", "status", "vendor"])
            return 0
        if args.command == "expiry-report":
            rows = db.expiry_report(days=args.days, status=args.status, include_unknown=args.include_unknown)
            print_records_table(rows, ["id", "sku", "name", "category", "location", "quantity", "unit", "expiry_date", "days_remaining", "status"])
            return 0
        if args.command == "freshest-stock":
            rows = db.freshest_stock(limit=args.limit)
            print_records_table(rows, ["id", "sku", "name", "category", "location", "quantity", "unit", "expiry_date", "days_remaining", "status"])
            return 0
        if args.command == "export-expiry-csv":
            path = Path(args.path).expanduser() if args.path else default_export_path("expiry.csv")
            print(f"Exported expiry CSV: {db.export_expiry_csv(path, days=args.days, status=args.status, include_unknown=args.include_unknown)}")
            return 0
        if args.command == "export-warranty-csv":
            path = Path(args.path).expanduser() if args.path else default_export_path("warranty.csv")
            print(f"Exported warranty CSV: {db.export_warranty_csv(path, days=args.days)}")
            return 0
        if args.command == "service-add":
            row = db.resolve_item(args.identifier)
            if not row:
                print(f"Item not found: {args.identifier}", file=sys.stderr)
                return 2
            sid = db.add_service_record(
                int(row["id"]), args.type, args.description, args.cost, args.provider,
                args.performed, args.next_due, args.reference,
            )
            print(f"Added service record #{sid} for {row['sku']} — {row['name']}")
            return 0
        if args.command == "service-list":
            item_id = None
            if args.identifier:
                row = db.resolve_item(args.identifier)
                if not row:
                    print(f"Item not found: {args.identifier}", file=sys.stderr)
                    return 2
                item_id = int(row["id"])
            rows = db.service_records(item_id=item_id)
            print_table(rows, ["id", "sku", "item_name", "service_type", "performed_at", "next_due", "cost", "provider", "description"])
            return 0
        if args.command == "service-due":
            rows = db.service_due(days=args.days)
            print_table(rows, ["id", "sku", "item_name", "service_type", "next_due", "days_remaining", "provider", "description"])
            return 0
        if args.command == "export-service-csv":
            path = Path(args.path).expanduser() if args.path else default_export_path("service.csv")
            print(f"Exported service CSV: {db.export_service_csv(path)}")
            return 0
        if args.command == "install-desktop-launcher":
            dest_dir = Path(args.dest_dir).expanduser() if args.dest_dir else None
            print(f"Installed desktop launcher: {install_desktop_launcher(dest_dir)}")
            return 0
        if args.command == "categories":
            print("\n".join(db.distinct_values("category")))
            return 0
        if args.command == "locations":
            print("\n".join(db.distinct_values("location")))
            return 0
        parser.print_help()
        return 1
    finally:
        db.close()


# GUI layer intentionally kept in the same file so source installs and .deb installs behave identically.
def launch_gui(db_path: Path) -> int:
    try:
        import tkinter as tk
        from tkinter import filedialog, messagebox, ttk
    except Exception as exc:  # pragma: no cover - only environment-dependent
        print("The graphical interface requires python3-tk.", file=sys.stderr)
        print(str(exc), file=sys.stderr)
        return 1

    class InventoryApp(tk.Tk):
        def __init__(self) -> None:
            super().__init__()
            self.title(f"{APP_NAME} v{VERSION}")
            self.geometry("1240x760")
            self.minsize(1000, 640)
            self.configure(bg=AEGIS_DARK)
            self._set_window_icon()
            self.db = InventoryDB(db_path)
            self.selected_item_id: Optional[int] = None
            self._last_scan_code = ""
            self._last_scan_time = 0.0
            self._build_style()
            self._build_menu()
            self._build_ui()
            self.refresh_all()
            self.protocol("WM_DELETE_WINDOW", self.on_close)
            self.bind("<Control-q>", lambda _e: self.on_close())
            self.bind("<F5>", lambda _e: self.refresh_all())

        def _set_window_icon(self) -> None:
            icon_path = find_icon_path()
            if not icon_path:
                return
            try:
                self._sentinel_icon = tk.PhotoImage(file=str(icon_path))
                self.iconphoto(True, self._sentinel_icon)
            except Exception:
                pass

        def _build_style(self) -> None:
            style = ttk.Style(self)
            try:
                style.theme_use("clam")
            except tk.TclError:
                pass
            style.configure(".", background=AEGIS_DARK, foreground=AEGIS_TEXT, fieldbackground=AEGIS_PANEL)
            style.configure("TFrame", background=AEGIS_DARK)
            style.configure("Panel.TFrame", background=AEGIS_PANEL)
            style.configure("Card.TFrame", background=AEGIS_CARD)
            style.configure("TLabel", background=AEGIS_DARK, foreground=AEGIS_TEXT)
            style.configure("Muted.TLabel", background=AEGIS_DARK, foreground=AEGIS_MUTED)
            style.configure("Panel.TLabel", background=AEGIS_PANEL, foreground=AEGIS_TEXT)
            style.configure("Card.TLabel", background=AEGIS_CARD, foreground=AEGIS_TEXT)
            style.configure("Title.TLabel", background=AEGIS_DARK, foreground=AEGIS_GOLD, font=("Sans", 18, "bold"))
            style.configure("Subtitle.TLabel", background=AEGIS_DARK, foreground=AEGIS_CYAN, font=("Sans", 10, "bold"))
            style.configure("TButton", background=AEGIS_CARD, foreground=AEGIS_TEXT, padding=6)
            style.map("TButton", background=[("active", AEGIS_GOLD)], foreground=[("active", "#050505")])
            style.configure("Treeview", background=AEGIS_PANEL, fieldbackground=AEGIS_PANEL, foreground=AEGIS_TEXT, rowheight=28)
            style.configure("Treeview.Heading", background=AEGIS_CARD, foreground=AEGIS_GOLD, font=("Sans", 9, "bold"))
            style.map("Treeview", background=[("selected", AEGIS_GOLD)], foreground=[("selected", "#050505")])
            style.configure("TNotebook", background=AEGIS_DARK, borderwidth=0)
            style.configure("TNotebook.Tab", background=AEGIS_PANEL, foreground=AEGIS_TEXT, padding=(10, 6))
            style.map("TNotebook.Tab", background=[("selected", AEGIS_GOLD)], foreground=[("selected", "#050505")])
            style.configure("TEntry", fieldbackground=AEGIS_PANEL, foreground=AEGIS_TEXT, insertcolor=AEGIS_TEXT)
            style.configure("TCombobox", fieldbackground=AEGIS_PANEL, foreground=AEGIS_TEXT)

        def _build_menu(self) -> None:
            menu = tk.Menu(self, bg=AEGIS_PANEL, fg=AEGIS_TEXT, activebackground=AEGIS_GOLD, activeforeground="#050505")
            file_menu = tk.Menu(menu, tearoff=0, bg=AEGIS_PANEL, fg=AEGIS_TEXT, activebackground=AEGIS_GOLD)
            file_menu.add_command(label="New Item", command=self.clear_form, accelerator="Ctrl+N")
            file_menu.add_command(label="Backup Database", command=self.backup_db)
            file_menu.add_separator()
            file_menu.add_command(label="Export CSV", command=self.export_csv)
            file_menu.add_command(label="Export JSON", command=self.export_json)
            file_menu.add_command(label="Import CSV", command=self.import_csv)
            file_menu.add_separator()
            file_menu.add_command(label="Install Desktop Launcher", command=self.install_desktop_launcher_gui)
            file_menu.add_separator()
            file_menu.add_command(label="Quit", command=self.on_close, accelerator="Ctrl+Q")
            menu.add_cascade(label="File", menu=file_menu)

            view_menu = tk.Menu(menu, tearoff=0, bg=AEGIS_PANEL, fg=AEGIS_TEXT, activebackground=AEGIS_GOLD)
            view_menu.add_command(label="Refresh", command=self.refresh_all, accelerator="F5")
            view_menu.add_command(label="Focus Scanner", command=self.focus_scanner, accelerator="Ctrl+S")
            view_menu.add_command(label="Show Low Stock", command=lambda: self.set_low_stock_filter(True))
            view_menu.add_command(label="Show All Active", command=lambda: self.set_low_stock_filter(False))
            menu.add_cascade(label="View", menu=view_menu)

            help_menu = tk.Menu(menu, tearoff=0, bg=AEGIS_PANEL, fg=AEGIS_TEXT, activebackground=AEGIS_GOLD)
            help_menu.add_command(label="Health / AEGIS Status", command=self.show_health)
            help_menu.add_command(label="About", command=lambda: messagebox.showinfo(APP_NAME, f"{APP_NAME} v{VERSION}\nProgram 115\nLocal-only SQLite inventory, barcode scanner, warranty, and service manager."))
            menu.add_cascade(label="Help", menu=help_menu)
            self.config(menu=menu)
            self.bind("<Control-n>", lambda _e: self.clear_form())
            self.bind("<Control-s>", lambda _e: self.focus_scanner())

        def _build_ui(self) -> None:
            header = ttk.Frame(self, style="Panel.TFrame", padding=14)
            header.pack(fill="x")
            ttk.Label(header, text="Sentinel Inventory", style="Title.TLabel").pack(side="left")
            ttk.Label(header, text="Program 115 • local-first stock, asset, scanner, and business inventory", style="Subtitle.TLabel").pack(side="left", padx=14)
            self.status_label = ttk.Label(header, text="Ready", style="Panel.TLabel")
            self.status_label.pack(side="right")

            self.notebook = ttk.Notebook(self)
            self.notebook.pack(fill="both", expand=True, padx=10, pady=10)
            self.dashboard_tab = ttk.Frame(self.notebook)
            self.items_tab = ttk.Frame(self.notebook)
            self.scanner_tab = ttk.Frame(self.notebook)
            self.movements_tab = ttk.Frame(self.notebook)
            self.reports_tab = ttk.Frame(self.notebook)
            self.maintenance_tab = ttk.Frame(self.notebook)
            self.expiry_tab = ttk.Frame(self.notebook)
            self.labels_tab = ttk.Frame(self.notebook)
            self.bridge_tab = ttk.Frame(self.notebook)
            self.utilities_tab = ttk.Frame(self.notebook)
            self.notebook.add(self.dashboard_tab, text="Dashboard")
            self.notebook.add(self.items_tab, text="Items")
            self.notebook.add(self.scanner_tab, text="Scanner")
            self.notebook.add(self.movements_tab, text="Movements")
            self.notebook.add(self.reports_tab, text="Reports")
            self.notebook.add(self.maintenance_tab, text="Warranty / Service")
            self.notebook.add(self.expiry_tab, text="Expiry / Rotation")
            self.notebook.add(self.labels_tab, text="Labels / QR")
            self.notebook.add(self.bridge_tab, text="Bridge / Handoff")
            self.notebook.add(self.utilities_tab, text="Import / Export / Backup")
            self._build_dashboard_tab()
            self._build_items_tab()
            self._build_scanner_tab()
            self._build_movements_tab()
            self._build_reports_tab()
            self._build_maintenance_tab()
            self._build_expiry_tab()
            self._build_labels_tab()
            self._build_bridge_tab()
            self._build_utilities_tab()

        def _build_dashboard_tab(self) -> None:
            frame = ttk.Frame(self.dashboard_tab, padding=16)
            frame.pack(fill="both", expand=True)
            self.dashboard_text = tk.Text(frame, bg=AEGIS_PANEL, fg=AEGIS_TEXT, insertbackground=AEGIS_TEXT, relief="flat", height=20, wrap="word")
            self.dashboard_text.pack(fill="both", expand=True)
            self.dashboard_text.tag_configure("gold", foreground=AEGIS_GOLD, font=("Sans", 13, "bold"))
            self.dashboard_text.tag_configure("cyan", foreground=AEGIS_CYAN, font=("Sans", 11, "bold"))
            ttk.Button(frame, text="Refresh Dashboard", command=self.refresh_dashboard).pack(anchor="e", pady=10)

        def _build_items_tab(self) -> None:
            outer = ttk.Frame(self.items_tab, padding=10)
            outer.pack(fill="both", expand=True)
            left = ttk.Frame(outer, style="Panel.TFrame", padding=10)
            left.pack(side="left", fill="y", padx=(0, 10))
            right = ttk.Frame(outer)
            right.pack(side="right", fill="both", expand=True)

            self.fields: Dict[str, tk.StringVar] = {}
            self.field_widgets: Dict[str, Any] = {}
            field_specs = [
                ("sku", "SKU"), ("name", "Name *"), ("category", "Category"), ("location", "Location"),
                ("quantity", "Quantity"), ("unit", "Unit"), ("low_stock_threshold", "Low Stock"),
                ("cost_each", "Cost Each"), ("sale_price_each", "Sale Price"), ("vendor", "Vendor"),
                ("serial_number", "Serial"), ("barcode", "Barcode"), ("warranty_expiry", "Warranty Expiry"),
                ("expiry_date", "Stock Expiry / Best Before"),
                ("condition", "Condition"), ("notes", "Notes"),
            ]
            for key, label in field_specs:
                ttk.Label(left, text=label, style="Panel.TLabel").pack(anchor="w", pady=(6, 0))
                var = tk.StringVar()
                self.fields[key] = var
                if key == "notes":
                    entry = ttk.Entry(left, textvariable=var, width=34)
                elif key in {"condition", "unit"}:
                    values = ["Good", "Used", "Needs Repair", "Broken", "New"] if key == "condition" else ["ea", "kg", "g", "L", "mL", "m", "box", "pack", "set"]
                    entry = ttk.Combobox(left, textvariable=var, width=31, values=values)
                else:
                    entry = ttk.Entry(left, textvariable=var, width=34)
                entry.pack(fill="x")
                self.field_widgets[key] = entry
                if key == "sku":
                    sku_tools = ttk.Frame(left, style="Panel.TFrame")
                    sku_tools.pack(fill="x", pady=(3, 2))
                    ttk.Button(sku_tools, text="Use Next SKU", command=self.autofill_next_sku).pack(side="left", fill="x", expand=True, padx=(0, 3))
                    ttk.Button(sku_tools, text="Clear SKU", command=lambda: self.fields["sku"].set("")).pack(side="left", fill="x", expand=True, padx=(3, 0))
            self.fields["unit"].set("ea")
            self.fields["condition"].set("Good")
            self.fields["category"].set("General")
            self.fields["location"].set("Unsorted")
            self.fields["quantity"].set("0")
            self.fields["low_stock_threshold"].set("0")
            self.fields["cost_each"].set("0")
            self.fields["sale_price_each"].set("0")
            self.autofill_next_sku(silent=True)

            buttons = ttk.Frame(left, style="Panel.TFrame")
            buttons.pack(fill="x", pady=10)
            ttk.Button(buttons, text="Save New", command=self.save_new_item).pack(side="left", fill="x", expand=True, padx=(0, 3))
            ttk.Button(buttons, text="Update", command=self.update_selected_item).pack(side="left", fill="x", expand=True, padx=3)
            ttk.Button(buttons, text="Clear", command=self.clear_form).pack(side="left", fill="x", expand=True, padx=(3, 0))
            qty_buttons = ttk.Frame(left, style="Panel.TFrame")
            qty_buttons.pack(fill="x", pady=(0, 8))
            ttk.Button(qty_buttons, text="Restock +", command=lambda: self.quantity_popup("restock")).pack(side="left", fill="x", expand=True, padx=(0, 3))
            ttk.Button(qty_buttons, text="Use/Sell -", command=lambda: self.quantity_popup("consume")).pack(side="left", fill="x", expand=True, padx=3)
            ttk.Button(qty_buttons, text="Archive", command=self.archive_selected).pack(side="left", fill="x", expand=True, padx=(3, 0))

            filter_frame = ttk.Frame(right, style="Panel.TFrame", padding=8)
            filter_frame.pack(fill="x")
            ttk.Label(filter_frame, text="Search", style="Panel.TLabel").pack(side="left")
            self.search_var = tk.StringVar()
            search_entry = ttk.Entry(filter_frame, textvariable=self.search_var, width=32)
            search_entry.pack(side="left", padx=6)
            search_entry.bind("<Return>", lambda _e: self.refresh_items())
            self.low_stock_var = tk.BooleanVar(value=False)
            self.archived_var = tk.BooleanVar(value=False)
            ttk.Checkbutton(filter_frame, text="Low Stock", variable=self.low_stock_var, command=self.refresh_items).pack(side="left", padx=6)
            ttk.Checkbutton(filter_frame, text="Include Archived", variable=self.archived_var, command=self.refresh_items).pack(side="left", padx=6)
            ttk.Button(filter_frame, text="Refresh", command=self.refresh_items).pack(side="right")

            columns = ("id", "sku", "name", "category", "location", "quantity", "unit", "low", "expiry", "freshness", "cost", "value", "condition", "status")
            self.item_tree = ttk.Treeview(right, columns=columns, show="headings")
            headings = {
                "id": "ID", "sku": "SKU", "name": "Name", "category": "Category", "location": "Location",
                "quantity": "Qty", "unit": "Unit", "low": "Low", "expiry": "Expiry", "freshness": "Freshness", "cost": "Cost", "value": "Value",
                "condition": "Condition", "status": "Status",
            }
            widths = {"id": 50, "sku": 95, "name": 220, "category": 110, "location": 120, "quantity": 80, "unit": 60, "low": 70, "expiry": 105, "freshness": 90, "cost": 80, "value": 90, "condition": 100, "status": 80}
            for col in columns:
                self.item_tree.heading(col, text=headings[col])
                self.item_tree.column(col, width=widths[col], anchor="w")
            self.item_tree.pack(fill="both", expand=True, pady=(8, 0))
            self.item_tree.bind("<<TreeviewSelect>>", self.on_item_select)

        def _build_scanner_tab(self) -> None:
            frame = ttk.Frame(self.scanner_tab, padding=16)
            frame.pack(fill="both", expand=True)
            ttk.Label(frame, text="USB Barcode / QR Scanner Intake", style="Title.TLabel").pack(anchor="w")
            ttk.Label(
                frame,
                text="Fast stock movement mode supports keyboard-wedge USB scanners: scan, auto-lookup, restock, consume, adjust, or transfer location.",
                style="Muted.TLabel",
            ).pack(anchor="w", pady=(4, 12))

            scan_panel = ttk.Frame(frame, style="Panel.TFrame", padding=12)
            scan_panel.pack(fill="x")
            ttk.Label(scan_panel, text="Scan barcode, SKU, or serial", style="Panel.TLabel").pack(anchor="w")
            self.scan_var = tk.StringVar()
            self.scan_entry = ttk.Entry(scan_panel, textvariable=self.scan_var, font=("Sans", 18), width=42)
            self.scan_entry.pack(fill="x", pady=(6, 8))
            self.scan_entry.bind("<Return>", self.on_scan_enter)

            controls = ttk.Frame(scan_panel, style="Panel.TFrame")
            controls.pack(fill="x", pady=(0, 6))
            self.scan_qty_var = tk.StringVar(value=str(self.db.scanner_default_quantity()).rstrip("0").rstrip("."))
            self.scan_note_var = tk.StringVar()
            self.scan_mode_var = tk.StringVar(value=self.db.scanner_fast_mode())
            self.scan_transfer_location_var = tk.StringVar(value="")
            self.scan_auto_apply_var = tk.BooleanVar(value=False)
            self.scan_debounce_var = tk.StringVar(value=str(self.db.scanner_debounce_seconds()))
            ttk.Label(controls, text="Mode", style="Panel.TLabel").pack(side="left")
            ttk.Combobox(controls, textvariable=self.scan_mode_var, values=["lookup", "restock", "consume", "adjust", "transfer"], width=10, state="readonly").pack(side="left", padx=(4, 10))
            ttk.Label(controls, text="Qty", style="Panel.TLabel").pack(side="left")
            ttk.Entry(controls, textvariable=self.scan_qty_var, width=8).pack(side="left", padx=(4, 10))
            ttk.Label(controls, text="Transfer Location", style="Panel.TLabel").pack(side="left")
            ttk.Entry(controls, textvariable=self.scan_transfer_location_var, width=18).pack(side="left", padx=(4, 10))
            ttk.Checkbutton(controls, text="Auto-apply on Enter", variable=self.scan_auto_apply_var).pack(side="left", padx=6)

            controls2 = ttk.Frame(scan_panel, style="Panel.TFrame")
            controls2.pack(fill="x")
            ttk.Label(controls2, text="Note", style="Panel.TLabel").pack(side="left")
            ttk.Entry(controls2, textvariable=self.scan_note_var, width=30).pack(side="left", padx=(4, 10))
            ttk.Label(controls2, text="Debounce sec", style="Panel.TLabel").pack(side="left")
            ttk.Entry(controls2, textvariable=self.scan_debounce_var, width=6).pack(side="left", padx=(4, 10))
            ttk.Button(controls2, text="Lookup", command=self.lookup_scan).pack(side="left", padx=3)
            ttk.Button(controls2, text="Apply Fast Mode", command=self.scanner_apply_fast_mode).pack(side="left", padx=3)
            ttk.Button(controls2, text="Restock +", command=lambda: self.scanner_apply_movement("restock")).pack(side="left", padx=3)
            ttk.Button(controls2, text="Use/Sell -", command=lambda: self.scanner_apply_movement("consume")).pack(side="left", padx=3)
            ttk.Button(controls2, text="Adjust ±", command=lambda: self.scanner_apply_movement("adjust")).pack(side="left", padx=3)
            ttk.Button(controls2, text="Create New From Scan", command=self.create_item_from_scan).pack(side="left", padx=3)
            ttk.Button(controls2, text="Clear Recent", command=self.clear_recent_scans).pack(side="right", padx=3)

            panes = ttk.Panedwindow(frame, orient="horizontal")
            panes.pack(fill="both", expand=True, pady=(12, 0))
            left = ttk.Frame(panes, style="Panel.TFrame", padding=8)
            right = ttk.Frame(panes, style="Panel.TFrame", padding=8)
            panes.add(left, weight=2)
            panes.add(right, weight=1)

            ttk.Label(left, text="Scan Result", style="Panel.TLabel").pack(anchor="w")
            self.scan_result_text = tk.Text(left, bg=AEGIS_PANEL, fg=AEGIS_TEXT, insertbackground=AEGIS_TEXT, relief="flat", height=18, wrap="word")
            self.scan_result_text.pack(fill="both", expand=True, pady=(6, 0))
            self.scan_result_text.tag_configure("gold", foreground=AEGIS_GOLD, font=("Sans", 12, "bold"))
            self.scan_result_text.tag_configure("cyan", foreground=AEGIS_CYAN, font=("Sans", 10, "bold"))

            ttk.Label(right, text="Recent Scanner Queue", style="Panel.TLabel").pack(anchor="w")
            self.scan_recent_tree = ttk.Treeview(right, columns=("time", "code", "action", "sku", "result"), show="headings", height=18)
            for col, width in {"time": 120, "code": 120, "action": 100, "sku": 90, "result": 180}.items():
                self.scan_recent_tree.heading(col, text=col.title())
                self.scan_recent_tree.column(col, width=width, anchor="w")
            self.scan_recent_tree.pack(fill="both", expand=True, pady=(6, 0))

            self.scan_write("Scanner ready. Choose a mode, click the scan field, scan a code, then press Enter. Auto-apply can turn scans directly into stock movements.\n")

        def _build_movements_tab(self) -> None:
            frame = ttk.Frame(self.movements_tab, padding=10)
            frame.pack(fill="both", expand=True)
            columns = ("id", "sku", "movement_type", "qty_delta", "qty_after", "reference", "created_at", "note")
            self.move_tree = ttk.Treeview(frame, columns=columns, show="headings")
            for col in columns:
                self.move_tree.heading(col, text=col.replace("_", " ").title())
                self.move_tree.column(col, width=120 if col != "note" else 280)
            self.move_tree.pack(fill="both", expand=True)
            ttk.Button(frame, text="Refresh Movements", command=self.refresh_movements).pack(anchor="e", pady=8)

        def _build_reports_tab(self) -> None:
            frame = ttk.Frame(self.reports_tab, padding=10)
            frame.pack(fill="both", expand=True)
            top = ttk.Frame(frame, style="Panel.TFrame", padding=8)
            top.pack(fill="x")
            ttk.Label(top, text="Inventory Reports", style="Panel.TLabel").pack(side="left")
            ttk.Button(top, text="Refresh Reports", command=self.refresh_reports).pack(side="right", padx=4)
            ttk.Button(top, text="Export Reorder CSV", command=self.export_reorder_csv).pack(side="right", padx=4)

            panes = ttk.Panedwindow(frame, orient="horizontal")
            panes.pack(fill="both", expand=True, pady=(8, 0))

            left = ttk.Frame(panes, style="Panel.TFrame", padding=8)
            mid = ttk.Frame(panes, style="Panel.TFrame", padding=8)
            right = ttk.Frame(panes, style="Panel.TFrame", padding=8)
            panes.add(left, weight=1)
            panes.add(mid, weight=1)
            panes.add(right, weight=1)

            ttk.Label(left, text="By Category", style="Panel.TLabel").pack(anchor="w")
            self.category_tree = ttk.Treeview(left, columns=("category", "item_count", "total_units", "cost_value", "sale_value"), show="headings", height=18)
            for col in ("category", "item_count", "total_units", "cost_value", "sale_value"):
                self.category_tree.heading(col, text=col.replace("_", " ").title())
                self.category_tree.column(col, width=105, anchor="w")
            self.category_tree.pack(fill="both", expand=True, pady=(6, 0))

            ttk.Label(mid, text="By Location", style="Panel.TLabel").pack(anchor="w")
            self.location_tree = ttk.Treeview(mid, columns=("location", "item_count", "total_units", "cost_value", "sale_value"), show="headings", height=18)
            for col in ("location", "item_count", "total_units", "cost_value", "sale_value"):
                self.location_tree.heading(col, text=col.replace("_", " ").title())
                self.location_tree.column(col, width=105, anchor="w")
            self.location_tree.pack(fill="both", expand=True, pady=(6, 0))

            ttk.Label(right, text="Reorder / Low Stock", style="Panel.TLabel").pack(anchor="w")
            self.reorder_tree = ttk.Treeview(right, columns=("sku", "name", "quantity", "unit", "low_stock_threshold", "suggested_order_qty", "vendor"), show="headings", height=18)
            for col in ("sku", "name", "quantity", "unit", "low_stock_threshold", "suggested_order_qty", "vendor"):
                self.reorder_tree.heading(col, text=col.replace("_", " ").title())
                self.reorder_tree.column(col, width=100 if col != "name" else 160, anchor="w")
            self.reorder_tree.pack(fill="both", expand=True, pady=(6, 0))

        def _build_maintenance_tab(self) -> None:
            frame = ttk.Frame(self.maintenance_tab, padding=10)
            frame.pack(fill="both", expand=True)
            top = ttk.Frame(frame, style="Panel.TFrame", padding=8)
            top.pack(fill="x")
            ttk.Label(top, text="Warranty / Service Register", style="Panel.TLabel").pack(side="left")
            ttk.Button(top, text="Add Service Record", command=self.service_popup).pack(side="right", padx=4)
            ttk.Button(top, text="Export Service CSV", command=self.export_service_csv).pack(side="right", padx=4)
            ttk.Button(top, text="Export Warranty CSV", command=self.export_warranty_csv).pack(side="right", padx=4)
            ttk.Button(top, text="Refresh", command=self.refresh_maintenance).pack(side="right", padx=4)

            panes = ttk.Panedwindow(frame, orient="horizontal")
            panes.pack(fill="both", expand=True, pady=(8, 0))
            left = ttk.Frame(panes, style="Panel.TFrame", padding=8)
            right = ttk.Frame(panes, style="Panel.TFrame", padding=8)
            panes.add(left, weight=1)
            panes.add(right, weight=1)

            ttk.Label(left, text="Warranty Expired / Expiring within 90 Days", style="Panel.TLabel").pack(anchor="w")
            self.warranty_tree = ttk.Treeview(left, columns=("sku", "name", "warranty_expiry", "days_remaining", "status", "vendor"), show="headings", height=18)
            for col in ("sku", "name", "warranty_expiry", "days_remaining", "status", "vendor"):
                self.warranty_tree.heading(col, text=col.replace("_", " ").title())
                self.warranty_tree.column(col, width=120 if col != "name" else 190, anchor="w")
            self.warranty_tree.pack(fill="both", expand=True, pady=(6, 0))

            ttk.Label(right, text="Service / Maintenance Due within 30 Days", style="Panel.TLabel").pack(anchor="w")
            self.service_due_tree = ttk.Treeview(right, columns=("sku", "item_name", "service_type", "next_due", "days_remaining", "provider", "description"), show="headings", height=18)
            for col in ("sku", "item_name", "service_type", "next_due", "days_remaining", "provider", "description"):
                self.service_due_tree.heading(col, text=col.replace("_", " ").title())
                self.service_due_tree.column(col, width=120 if col not in {"item_name", "description"} else 180, anchor="w")
            self.service_due_tree.pack(fill="both", expand=True, pady=(6, 0))


        def _build_expiry_tab(self) -> None:
            frame = ttk.Frame(self.expiry_tab, padding=10)
            frame.pack(fill="both", expand=True)
            top = ttk.Frame(frame, style="Panel.TFrame", padding=8)
            top.pack(fill="x")
            ttk.Label(top, text="Expiry / Freshness / Stock Rotation", style="Panel.TLabel").pack(side="left")
            ttk.Button(top, text="Export Expiry CSV", command=self.export_expiry_csv).pack(side="right", padx=4)
            ttk.Button(top, text="Refresh", command=self.refresh_expiry).pack(side="right", padx=4)

            panes = ttk.Panedwindow(frame, orient="vertical")
            panes.pack(fill="both", expand=True, pady=(8, 0))

            top_row = ttk.Panedwindow(panes, orient="horizontal")
            bottom_row = ttk.Panedwindow(panes, orient="horizontal")
            panes.add(top_row, weight=1)
            panes.add(bottom_row, weight=1)

            expiring_frame = ttk.Frame(top_row, style="Panel.TFrame", padding=8)
            good_frame = ttk.Frame(top_row, style="Panel.TFrame", padding=8)
            fresh_frame = ttk.Frame(bottom_row, style="Panel.TFrame", padding=8)
            help_frame = ttk.Frame(bottom_row, style="Panel.TFrame", padding=8)
            top_row.add(expiring_frame, weight=1)
            top_row.add(good_frame, weight=1)
            bottom_row.add(fresh_frame, weight=1)
            bottom_row.add(help_frame, weight=1)

            ttk.Label(expiring_frame, text=f"Expired / Close To Expiry ({DEFAULT_EXPIRY_WARNING_DAYS} days)", style="Panel.TLabel").pack(anchor="w")
            self.expiry_tree_expiring = ttk.Treeview(expiring_frame, columns=("sku", "name", "expiry_date", "days_remaining", "quantity", "unit", "location", "status"), show="headings", height=10)
            for col in ("sku", "name", "expiry_date", "days_remaining", "quantity", "unit", "location", "status"):
                self.expiry_tree_expiring.heading(col, text=col.replace("_", " ").title())
                self.expiry_tree_expiring.column(col, width=100 if col != "name" else 180, anchor="w")
            self.expiry_tree_expiring.pack(fill="both", expand=True, pady=(6, 0))

            ttk.Label(good_frame, text="Still In Good Date", style="Panel.TLabel").pack(anchor="w")
            self.expiry_tree_good = ttk.Treeview(good_frame, columns=("sku", "name", "expiry_date", "days_remaining", "quantity", "unit", "location"), show="headings", height=10)
            for col in ("sku", "name", "expiry_date", "days_remaining", "quantity", "unit", "location"):
                self.expiry_tree_good.heading(col, text=col.replace("_", " ").title())
                self.expiry_tree_good.column(col, width=100 if col != "name" else 180, anchor="w")
            self.expiry_tree_good.pack(fill="both", expand=True, pady=(6, 0))

            ttk.Label(fresh_frame, text="Freshest Stock", style="Panel.TLabel").pack(anchor="w")
            self.expiry_tree_freshest = ttk.Treeview(fresh_frame, columns=("sku", "name", "expiry_date", "days_remaining", "quantity", "unit", "location"), show="headings", height=10)
            for col in ("sku", "name", "expiry_date", "days_remaining", "quantity", "unit", "location"):
                self.expiry_tree_freshest.heading(col, text=col.replace("_", " ").title())
                self.expiry_tree_freshest.column(col, width=100 if col != "name" else 180, anchor="w")
            self.expiry_tree_freshest.pack(fill="both", expand=True, pady=(6, 0))

            self.expiry_help_text = tk.Text(help_frame, bg=AEGIS_PANEL, fg=AEGIS_TEXT, relief="flat", height=10, wrap="word")
            self.expiry_help_text.pack(fill="both", expand=True)
            self.expiry_help_text.insert("end", "Use the item field 'Stock Expiry / Best Before' for food, chemicals, batteries, medical supplies, consumables, or any stock that should rotate by date.\n\nStatus rules:\n- Expired: date is before today.\n- Close to expiry: within the warning window.\n- Good date: beyond the warning window.\n- Freshest: furthest future expiry dates first.\n")
            self.expiry_help_text.configure(state="disabled")


        def _build_labels_tab(self) -> None:
            frame = ttk.Frame(self.labels_tab, padding=16)
            frame.pack(fill="both", expand=True)
            ttk.Label(frame, text="Labels / QR / Print Prep", style="Title.TLabel").pack(anchor="w")
            ttk.Label(frame, text="Export printable label sheets, label CSV/JSON, and optional local QR PNG payloads for item/SKU workflows.", style="Muted.TLabel").pack(anchor="w", pady=(4, 12))
            controls = ttk.Frame(frame, style="Panel.TFrame", padding=10)
            controls.pack(fill="x")
            self.label_query_var = tk.StringVar()
            self.label_category_var = tk.StringVar()
            self.label_location_var = tk.StringVar()
            self.label_low_stock_var = tk.BooleanVar(value=False)
            ttk.Label(controls, text="Search", style="Panel.TLabel").pack(side="left")
            ttk.Entry(controls, textvariable=self.label_query_var, width=22).pack(side="left", padx=(4, 10))
            ttk.Label(controls, text="Category", style="Panel.TLabel").pack(side="left")
            ttk.Entry(controls, textvariable=self.label_category_var, width=16).pack(side="left", padx=(4, 10))
            ttk.Label(controls, text="Location", style="Panel.TLabel").pack(side="left")
            ttk.Entry(controls, textvariable=self.label_location_var, width=16).pack(side="left", padx=(4, 10))
            ttk.Checkbutton(controls, text="Low stock only", variable=self.label_low_stock_var).pack(side="left", padx=8)
            ttk.Button(controls, text="Preview", command=self.refresh_labels).pack(side="right", padx=4)

            actions = ttk.Frame(frame, style="Panel.TFrame", padding=10)
            actions.pack(fill="x", pady=(8, 8))
            ttk.Button(actions, text="Export Label CSV", command=self.export_label_csv_gui).pack(side="left", padx=4)
            ttk.Button(actions, text="Export Label JSON", command=self.export_label_json_gui).pack(side="left", padx=4)
            ttk.Button(actions, text="Export Printable HTML", command=self.export_label_html_gui).pack(side="left", padx=4)
            ttk.Button(actions, text="Export QR PNGs", command=self.export_qr_png_gui).pack(side="left", padx=4)

            self.label_text = tk.Text(frame, bg=AEGIS_PANEL, fg=AEGIS_TEXT, relief="flat", height=20, wrap="none")
            self.label_text.pack(fill="both", expand=True)
            self.label_text.insert("end", "Use Preview to show label-ready records. HTML export is printable; QR PNG export uses optional python3-qrcode when installed.\n")
            self.label_text.configure(state="disabled")



        def _build_bridge_tab(self) -> None:
            frame = ttk.Frame(self.bridge_tab, padding=12)
            frame.pack(fill="both", expand=True)
            ttk.Label(frame, text="Ledger / Pantry / Supplier Bridge Handoff", style="Title.TLabel").pack(anchor="w")
            ttk.Label(frame, text="Local-only bridge exports for Sentinel Ledger, Sentinel Pantry, reorder handoff, Sentinel Command, and AEGIS status readers.", style="Muted.TLabel").pack(anchor="w", pady=(2, 8))
            actions = ttk.Frame(frame)
            actions.pack(fill="x", pady=(0, 8))
            ttk.Button(actions, text="Refresh Bridge Status", command=self.refresh_bridge).pack(side="left", padx=4)
            ttk.Button(actions, text="Export Ledger CSV", command=self.export_ledger_bridge_csv_gui).pack(side="left", padx=4)
            ttk.Button(actions, text="Export Pantry CSV", command=self.export_pantry_bridge_csv_gui).pack(side="left", padx=4)
            ttk.Button(actions, text="Export Bridge Bundle", command=self.export_bridge_bundle_gui).pack(side="left", padx=4)
            self.bridge_text = tk.Text(frame, bg=AEGIS_PANEL, fg=AEGIS_TEXT, relief="flat", height=22, wrap="word")
            self.bridge_text.pack(fill="both", expand=True)

        def refresh_bridge(self) -> None:
            status = self.db.bridge_status()
            self.bridge_text.configure(state="normal")
            self.bridge_text.delete("1.0", "end")
            lines = [
                f"Sentinel Inventory Bridge Contract v{status['bridge_contract_version']}",
                "",
                f"Ledger valuation rows: {status['ledger_rows']}",
                f"Pantry / consumable candidate rows: {status['pantry_candidate_rows']}",
                f"Supplier reorder rows: {status['supplier_reorder_rows']}",
                "",
                "Ready exports:",
                "- Sentinel Ledger inventory valuation CSV/JSON",
                "- Sentinel Pantry expiry/rotation CSV/JSON",
                "- Supplier reorder handoff CSV",
                "- Expiry rotation CSV",
                "- Label payload JSON",
                "- Bridge bundle manifest JSON",
                "",
                "Posture: local-only, no network requirement, no telemetry.",
            ]
            self.bridge_text.insert("end", "\n".join(lines))
            self.bridge_text.configure(state="disabled")

        def _build_utilities_tab(self) -> None:
            frame = ttk.Frame(self.utilities_tab, padding=16)
            frame.pack(fill="both", expand=True)
            ttk.Label(frame, text="Import / Export / Backup", style="Title.TLabel").pack(anchor="w")
            ttk.Label(frame, text="Exports default to the AEGIS Vault project-records path when available.", style="Muted.TLabel").pack(anchor="w", pady=(4, 12))
            actions = ttk.Frame(frame, style="Panel.TFrame", padding=12)
            actions.pack(fill="x")
            ttk.Button(actions, text="Export CSV", command=self.export_csv).pack(side="left", padx=4)
            ttk.Button(actions, text="Export JSON", command=self.export_json).pack(side="left", padx=4)
            ttk.Button(actions, text="Export Bridge Bundle", command=self.export_bridge_bundle_gui).pack(side="left", padx=4)
            ttk.Button(actions, text="Export Reorder CSV", command=self.export_reorder_csv).pack(side="left", padx=4)
            ttk.Button(actions, text="Export Warranty CSV", command=self.export_warranty_csv).pack(side="left", padx=4)
            ttk.Button(actions, text="Export Service CSV", command=self.export_service_csv).pack(side="left", padx=4)
            ttk.Button(actions, text="Export Expiry CSV", command=self.export_expiry_csv).pack(side="left", padx=4)
            ttk.Button(actions, text="Import CSV", command=self.import_csv).pack(side="left", padx=4)
            ttk.Button(actions, text="Backup Database", command=self.backup_db).pack(side="left", padx=4)
            ttk.Button(actions, text="Show Health JSON", command=self.show_health).pack(side="left", padx=4)
            ttk.Button(actions, text="Install Desktop Launcher", command=self.install_desktop_launcher_gui).pack(side="left", padx=4)
            self.utility_text = tk.Text(frame, bg=AEGIS_PANEL, fg=AEGIS_TEXT, relief="flat", height=18, wrap="word")
            self.utility_text.pack(fill="both", expand=True, pady=12)

        def set_status(self, text: str) -> None:
            self.status_label.configure(text=text)
            self.utility_text_insert(text + "\n") if hasattr(self, "utility_text") else None

        def utility_text_insert(self, text: str) -> None:
            self.utility_text.insert("end", text)
            self.utility_text.see("end")

        def refresh_all(self) -> None:
            self.refresh_dashboard()
            self.refresh_items()
            self.refresh_movements()
            if hasattr(self, "category_tree"):
                self.refresh_reports()
            if hasattr(self, "warranty_tree"):
                self.refresh_maintenance()
            if hasattr(self, "expiry_tree_expiring"):
                self.refresh_expiry()
            if hasattr(self, "label_text"):
                self.refresh_labels()
            if hasattr(self, "bridge_text"):
                self.refresh_bridge()
            self.set_status("Refreshed")

        def refresh_dashboard(self) -> None:
            d = self.db.dashboard()
            self.dashboard_text.configure(state="normal")
            self.dashboard_text.delete("1.0", "end")
            self.dashboard_text.insert("end", f"{APP_NAME} v{VERSION}\n", "gold")
            self.dashboard_text.insert("end", "Program 115 • Local-first household / business inventory\n\n", "cyan")
            lines = [
                f"Database: {d['db_path']}",
                "",
                f"Active items: {d['total_items']}",
                f"Archived items: {d['archived_items']}",
                f"Total units: {d['total_units']:,.2f}",
                f"Low-stock items: {d['low_stock_items']}",
                f"Categories: {d['categories']}",
                f"Locations: {d['locations']}",
                f"Next SKU: {d['next_sku']} ({d['sku_prefix']} sequence)",
                f"Barcode-linked items: {d['items_with_barcodes']}",
                f"Serial-linked items: {d['items_with_serials']}",
                f"Label-ready items: {d['label_ready_items']}",
                f"Label payload scheme: {d['label_payload_scheme']}",
                f"Scanner mode: USB HID keyboard-wedge ready, suffix={d['scanner_suffix']}",
                f"Movement records: {d['movement_records']}",
                f"Service records: {d['service_records']}",
                f"Warranty expired/expiring within 90 days: {d['warranty_expiring_90_days']}",
                f"Service due within 30 days: {d['service_due_30_days']}",
                f"Stock expired: {d['stock_expired_items']}",
                f"Stock close to expiry within {d['stock_expiry_window_days']} days: {d['stock_expiring_soon_items']}",
                f"Stock still in good date: {d['stock_good_date_items']}",
                f"Unknown stock expiry dates: {d['stock_unknown_expiry_items']}",
                f"Freshest stock SKU: {d['freshest_stock_item'] or 'None'}",
                "",
                f"Inventory cost value: {fmt_money(d['inventory_cost_value'])}",
                f"Potential sale value: {fmt_money(d['inventory_sale_value'])}",
                "",
                "Doctrine: local-only, no telemetry, no forced cloud, no network requirement.",
                "SKU entry: new items auto-fill the next sequential SKU, while manual override remains available.",
                f"Scanner: barcode/SKU/serial lookup, fast mode '{d['scanner_fast_mode']}', batch queue, transfer, and duplicate debounce ready.",
                "Reporting: category summary, location summary, low-stock reorder list, reorder CSV export.",
                "Warranty/service: warranty warnings, service history, maintenance due list, CSV exports.",
                "Expiry rotation: expired, close-to-expiry, good-date, and freshest stock reports with CSV export.",
                "Labels/QR: printable HTML sheets, label CSV/JSON, local QR payloads, and optional QR PNG export.",
                f"Bridge rows: Ledger {d['ledger_bridge_rows']} | Pantry candidates {d['pantry_bridge_rows']} | Supplier reorder {d['supplier_reorder_rows']}.",
                "Bridge posture: Ledger/Pantry bridge exports, supplier reorder handoff, and bridge bundle manifest ready.",
            ]
            self.dashboard_text.insert("end", "\n".join(lines))
            self.dashboard_text.configure(state="disabled")

        def refresh_items(self) -> None:
            for item in self.item_tree.get_children():
                self.item_tree.delete(item)
            rows = self.db.list_items(
                query=self.search_var.get().strip(),
                include_archived=self.archived_var.get(),
                low_stock_only=self.low_stock_var.get(),
            )
            for r in rows:
                value = coerce_float(r["quantity"]) * coerce_float(r["cost_each"])
                self.item_tree.insert("", "end", values=(
                    r["id"], r["sku"], r["name"], r["category"], r["location"], f"{coerce_float(r['quantity']):g}",
                    r["unit"], f"{coerce_float(r['low_stock_threshold']):g}", r["expiry_date"], self.db.expiry_status(r["expiry_date"], DEFAULT_EXPIRY_WARNING_DAYS)["status"], fmt_money(r["cost_each"]), fmt_money(value), r["condition"], r["status"],
                ))
            self.set_status(f"{len(rows)} item(s) shown")

        def refresh_reports(self) -> None:
            for tree in (self.category_tree, self.location_tree, self.reorder_tree):
                for item in tree.get_children():
                    tree.delete(item)
            for r in self.db.category_summary():
                self.category_tree.insert("", "end", values=(r["category"], r["item_count"], f"{coerce_float(r['total_units']):g}", fmt_money(r["cost_value"]), fmt_money(r["sale_value"])))
            for r in self.db.location_summary():
                self.location_tree.insert("", "end", values=(r["location"], r["item_count"], f"{coerce_float(r['total_units']):g}", fmt_money(r["cost_value"]), fmt_money(r["sale_value"])))
            for r in self.db.reorder_items():
                self.reorder_tree.insert("", "end", values=(r["sku"], r["name"], f"{coerce_float(r['quantity']):g}", r["unit"], f"{coerce_float(r['low_stock_threshold']):g}", f"{coerce_float(r['suggested_order_qty']):g}", r["vendor"]))

        def refresh_maintenance(self) -> None:
            for tree in (self.warranty_tree, self.service_due_tree):
                for item in tree.get_children():
                    tree.delete(item)
            for r in self.db.warranty_report(days=90):
                self.warranty_tree.insert("", "end", values=(r["sku"], r["name"], r["warranty_expiry"], r["days_remaining"], r["status"], r["vendor"]))
            for r in self.db.service_due(days=30):
                self.service_due_tree.insert("", "end", values=(r["sku"], r["item_name"], r["service_type"], r["next_due"], r["days_remaining"], r["provider"], r["description"]))


        def refresh_expiry(self) -> None:
            if not hasattr(self, "expiry_tree_expiring"):
                return
            for tree in (self.expiry_tree_expiring, self.expiry_tree_good, self.expiry_tree_freshest):
                for item in tree.get_children():
                    tree.delete(item)
            expiring = [r for r in self.db.expiry_report(days=DEFAULT_EXPIRY_WARNING_DAYS, status="all") if r["status"] in {"expired", "expiring"}]
            good = self.db.expiry_report(days=DEFAULT_EXPIRY_WARNING_DAYS, status="good")
            freshest = self.db.freshest_stock(limit=50)
            for r in expiring:
                self.expiry_tree_expiring.insert("", "end", values=(r["sku"], r["name"], r["expiry_date"], r["days_remaining"], f"{coerce_float(r['quantity']):g}", r["unit"], r["location"], r["status"]))
            for r in good:
                self.expiry_tree_good.insert("", "end", values=(r["sku"], r["name"], r["expiry_date"], r["days_remaining"], f"{coerce_float(r['quantity']):g}", r["unit"], r["location"]))
            for r in freshest:
                self.expiry_tree_freshest.insert("", "end", values=(r["sku"], r["name"], r["expiry_date"], r["days_remaining"], f"{coerce_float(r['quantity']):g}", r["unit"], r["location"]))



        def refresh_labels(self) -> None:
            if not hasattr(self, "label_text"):
                return
            records = self.db.label_rows(
                query=self.label_query_var.get().strip() if hasattr(self, "label_query_var") else "",
                category=self.label_category_var.get().strip() if hasattr(self, "label_category_var") else "",
                location=self.label_location_var.get().strip() if hasattr(self, "label_location_var") else "",
                low_stock_only=self.label_low_stock_var.get() if hasattr(self, "label_low_stock_var") else False,
            )
            self.label_text.configure(state="normal")
            self.label_text.delete("1.0", "end")
            self.label_text.insert("end", f"Label-ready records: {len(records)}\n")
            self.label_text.insert("end", "Payload scheme: sentinel-inventory://item/{SKU}\n\n")
            for rec in records[:250]:
                self.label_text.insert("end", f"{rec['sku']} | {rec['name']} | scan={rec['scan_code']} | qr={rec['qr_payload']}\n")
            if len(records) > 250:
                self.label_text.insert("end", f"\n... {len(records) - 250} more record(s) not shown. Export to capture all.\n")
            self.label_text.configure(state="disabled")


        def refresh_movements(self) -> None:
            for item in self.move_tree.get_children():
                self.move_tree.delete(item)
            for r in self.db.list_movements():
                self.move_tree.insert("", "end", values=(r["id"], r["sku"], r["movement_type"], f"{coerce_float(r['qty_delta']):g}", f"{coerce_float(r['qty_after']):g}", r["reference"], r["created_at"], r["note"]))

        def scan_write(self, text: str, tag: str = "") -> None:
            if not hasattr(self, "scan_result_text"):
                return
            self.scan_result_text.configure(state="normal")
            if tag:
                self.scan_result_text.insert("end", text, tag)
            else:
                self.scan_result_text.insert("end", text)
            self.scan_result_text.see("end")
            self.scan_result_text.configure(state="disabled")

        def current_scan_code(self) -> str:
            return normalize_scan_code(self.scan_var.get() if hasattr(self, "scan_var") else "")

        def on_scan_enter(self, _event: Any = None) -> None:
            mode = self.scan_mode_var.get().strip().lower() if hasattr(self, "scan_mode_var") else "lookup"
            if getattr(self, "scan_auto_apply_var", None) and self.scan_auto_apply_var.get() and mode != "lookup":
                self.scanner_apply_fast_mode()
            else:
                self.lookup_scan()

        def scan_is_debounced(self, code: str) -> bool:
            try:
                debounce = max(0.0, coerce_float(self.scan_debounce_var.get(), self.db.scanner_debounce_seconds()))
            except Exception:
                debounce = self.db.scanner_debounce_seconds()
            now = time.monotonic()
            if debounce > 0 and code and code == self._last_scan_code and (now - self._last_scan_time) < debounce:
                self._last_scan_time = now
                return True
            self._last_scan_code = code
            self._last_scan_time = now
            return False

        def append_recent_scan(self, code: str, action: str, sku: str = "", result: str = "") -> None:
            if not hasattr(self, "scan_recent_tree"):
                return
            stamp = _dt.datetime.now().strftime("%H:%M:%S")
            self.scan_recent_tree.insert("", 0, values=(stamp, code, action, sku, result))
            children = self.scan_recent_tree.get_children()
            for iid in children[80:]:
                self.scan_recent_tree.delete(iid)

        def clear_recent_scans(self) -> None:
            if hasattr(self, "scan_recent_tree"):
                for iid in self.scan_recent_tree.get_children():
                    self.scan_recent_tree.delete(iid)
            self.set_status("Recent scanner queue cleared")

        def scanner_apply_fast_mode(self) -> None:
            code = self.current_scan_code()
            if not code:
                messagebox.showwarning(APP_NAME, "Scan or enter a barcode, SKU, or serial first.")
                return
            if self.scan_is_debounced(code):
                self.append_recent_scan(code, "debounced", "", "duplicate skipped")
                self.set_status(f"Duplicate scan debounced: {code}")
                return
            mode = self.scan_mode_var.get().strip().lower() if hasattr(self, "scan_mode_var") else "lookup"
            try:
                result = self.db.fast_scan(
                    code,
                    mode=mode,
                    quantity=coerce_float(self.scan_qty_var.get(), self.db.scanner_default_quantity()),
                    location=self.scan_transfer_location_var.get() if hasattr(self, "scan_transfer_location_var") else "",
                    note=self.scan_note_var.get() if hasattr(self, "scan_note_var") else "",
                )
                self.scan_result_text.configure(state="normal")
                self.scan_result_text.delete("1.0", "end")
                self.scan_result_text.configure(state="disabled")
                if not result.get("found"):
                    self.scan_write(f"UNKNOWN SCAN: {code}\n", "gold")
                    self.scan_write(result.get("message", "No matching item.") + "\n")
                    self.append_recent_scan(code, mode, "", "unknown")
                    self.set_status(f"Unknown scan: {code}")
                    return
                item = result.get("item", {})
                action = str(result.get("movement_type", "scan_lookup")).replace("_", " ").title()
                self.scan_write(f"{action} complete\n", "gold")
                if result.get("movement_type") == "scan_transfer":
                    self.scan_write(f"{item['sku']} — {item['name']} moved to {result.get('to_location', item.get('location', ''))}\n")
                    status = f"moved to {result.get('to_location', '')}"
                elif result.get("movement_type") == "scan_lookup":
                    self.scan_write(f"{item['sku']} — {item['name']} has {coerce_float(item['quantity']):g} {item['unit']} at {item['location']}\n")
                    status = "found"
                else:
                    self.scan_write(f"{item['sku']} — {item['name']} now has {coerce_float(result.get('qty_after')):g} {item['unit']}\n")
                    status = f"qty {coerce_float(result.get('qty_after')):g}"
                self.append_recent_scan(code, mode, item.get("sku", ""), status)
                self.refresh_all()
                self.set_status(f"Fast scan {mode} applied to {item.get('sku', code)}")
                try:
                    self.scan_var.set("")
                    self.scan_entry.focus_set()
                except Exception:
                    pass
            except Exception as exc:
                messagebox.showerror(APP_NAME, str(exc))
                self.append_recent_scan(code, mode, "", f"error: {exc}")

        def lookup_scan(self) -> None:
            code = self.current_scan_code()
            if not code:
                self.set_status("Scanner field is empty.")
                return
            result = self.db.scan_lookup(code)
            self.scan_result_text.configure(state="normal")
            self.scan_result_text.delete("1.0", "end")
            self.scan_result_text.configure(state="disabled")
            if not result.get("found"):
                self.scan_write(f"UNKNOWN SCAN: {code}\n", "gold")
                self.scan_write("No matching barcode, SKU, or serial number was found. Use Create New From Scan to pre-fill a new item.\n")
                self.append_recent_scan(code, "lookup", "", "unknown")
                self.set_status(f"Unknown scan: {code}")
                return
            item = result["item"]
            self.selected_item_id = int(item["id"])
            self.scan_write(f"FOUND via {result['match_type']}: {item['sku']} — {item['name']}\n", "gold")
            lines = [
                f"Quantity: {coerce_float(item['quantity']):g} {item['unit']}",
                f"Category: {item['category']}",
                f"Location: {item['location']}",
                f"Barcode: {item['barcode']}",
                f"Serial: {item['serial_number']}",
                f"Low stock threshold: {coerce_float(item['low_stock_threshold']):g}",
                f"Condition: {item['condition']}",
                f"Vendor: {item['vendor']}",
            ]
            self.scan_write("\n".join(lines) + "\n")
            try:
                self.load_item_into_form(int(item["id"]))
            except Exception:
                pass
            self.append_recent_scan(code, "lookup", item["sku"], "found")
            self.set_status(f"Scan matched {item['sku']}")

        def scanner_apply_movement(self, mode: str) -> None:
            code = self.current_scan_code()
            if not code:
                messagebox.showwarning(APP_NAME, "Scan or enter a barcode, SKU, or serial first.")
                return
            try:
                result = self.db.scan_movement(code, coerce_float(self.scan_qty_var.get(), 1.0), mode, self.scan_note_var.get())
                if not result.get("found"):
                    messagebox.showwarning(APP_NAME, f"Unknown scan: {code}")
                    self.lookup_scan()
                    return
                item = result["item"]
                self.refresh_all()
                self.scan_result_text.configure(state="normal")
                self.scan_result_text.delete("1.0", "end")
                self.scan_result_text.configure(state="disabled")
                self.scan_write(f"{result['movement_type'].replace('_', ' ').title()} complete\n", "gold")
                self.scan_write(f"{item['sku']} — {item['name']} now has {coerce_float(result['qty_after']):g} {item['unit']}\n")
                self.set_status(f"Scanner movement applied to {item['sku']}")
            except Exception as exc:
                messagebox.showerror(APP_NAME, str(exc))

        def load_item_into_form(self, item_id: int) -> None:
            row = self.db.get_item(item_id)
            if not row or not hasattr(self, "fields"):
                return
            self.selected_item_id = item_id
            for key in self.fields:
                self.fields[key].set(str(row[key] if row[key] is not None else ""))
            for iid in self.item_tree.get_children():
                values = self.item_tree.item(iid, "values")
                if values and int(values[0]) == item_id:
                    self.item_tree.selection_set(iid)
                    self.item_tree.see(iid)
                    break

        def create_item_from_scan(self) -> None:
            code = self.current_scan_code()
            if not code:
                messagebox.showwarning(APP_NAME, "Scan or enter a code first.")
                return
            existing = self.db.resolve_scan(code)
            if existing:
                self.load_item_into_form(int(existing["id"]))
                self.notebook.select(self.items_tab)
                messagebox.showinfo(APP_NAME, f"This scan already matches {existing['sku']} — {existing['name']}.")
                return
            self.clear_form()
            self.fields["barcode"].set(code)
            self.fields["notes"].set(f"Created from scanner input {code}")
            self.notebook.select(self.items_tab)
            try:
                self.field_widgets["name"].focus_set()
            except Exception:
                pass
            self.set_status(f"New item form prepared from scan {code}")

        def focus_scanner(self) -> None:
            self.notebook.select(self.scanner_tab)
            try:
                self.scan_entry.focus_set()
            except Exception:
                pass

        def autofill_next_sku(self, silent: bool = False) -> None:
            if self.selected_item_id:
                if not silent:
                    self.set_status("SKU autofill is for new items. Clear the form first to create a new item.")
                return
            try:
                next_code = self.db.next_sku()
                self.fields["sku"].set(next_code)
                if not silent:
                    self.set_status(f"Next SKU loaded: {next_code}")
            except Exception as exc:
                if not silent:
                    self.set_status(f"Could not load next SKU: {exc}")

        def form_item(self) -> Item:
            return Item(
                id=self.selected_item_id,
                sku=self.fields["sku"].get().strip(),
                name=self.fields["name"].get().strip(),
                category=self.fields["category"].get().strip() or "General",
                location=self.fields["location"].get().strip() or "Unsorted",
                quantity=coerce_float(self.fields["quantity"].get()),
                unit=self.fields["unit"].get().strip() or "ea",
                low_stock_threshold=coerce_float(self.fields["low_stock_threshold"].get()),
                cost_each=coerce_float(self.fields["cost_each"].get()),
                sale_price_each=coerce_float(self.fields["sale_price_each"].get()),
                vendor=self.fields["vendor"].get().strip(),
                serial_number=self.fields["serial_number"].get().strip(),
                barcode=self.fields["barcode"].get().strip(),
                warranty_expiry=self.fields["warranty_expiry"].get().strip(),
                expiry_date=self.fields["expiry_date"].get().strip(),
                condition=self.fields["condition"].get().strip() or "Good",
                notes=self.fields["notes"].get().strip(),
            )

        def save_new_item(self) -> None:
            try:
                item = self.form_item()
                iid = self.db.add_item(item)
                saved_sku = self.db.get_item(iid)["sku"]
                self.refresh_all()
                self.clear_form()
                messagebox.showinfo(APP_NAME, f"Saved {saved_sku} — {item.name}")
            except Exception as exc:
                messagebox.showerror(APP_NAME, str(exc))

        def update_selected_item(self) -> None:
            if not self.selected_item_id:
                messagebox.showwarning(APP_NAME, "Select an item first.")
                return
            try:
                item = self.form_item()
                self.db.update_item(self.selected_item_id, {
                    "sku": item.sku or self.db.get_item(self.selected_item_id)["sku"],
                    "name": item.name,
                    "category": item.category,
                    "location": item.location,
                    "quantity": item.quantity,
                    "unit": item.unit,
                    "low_stock_threshold": item.low_stock_threshold,
                    "cost_each": item.cost_each,
                    "sale_price_each": item.sale_price_each,
                    "vendor": item.vendor,
                    "serial_number": item.serial_number,
                    "barcode": item.barcode,
                    "warranty_expiry": item.warranty_expiry,
                    "expiry_date": item.expiry_date,
                    "condition": item.condition,
                    "notes": item.notes,
                })
                self.refresh_all()
                messagebox.showinfo(APP_NAME, "Item updated.")
            except Exception as exc:
                messagebox.showerror(APP_NAME, str(exc))

        def on_item_select(self, _event: Any = None) -> None:
            sel = self.item_tree.selection()
            if not sel:
                return
            values = self.item_tree.item(sel[0], "values")
            if not values:
                return
            item_id = int(values[0])
            row = self.db.get_item(item_id)
            if not row:
                return
            self.selected_item_id = item_id
            for key in self.fields:
                self.fields[key].set(str(row[key] if row[key] is not None else ""))
            self.set_status(f"Selected {row['sku']}")

        def clear_form(self) -> None:
            self.selected_item_id = None
            defaults = {
                "sku": self.db.next_sku(), "name": "", "category": "General", "location": "Unsorted",
                "quantity": "0", "unit": "ea", "low_stock_threshold": "0", "cost_each": "0",
                "sale_price_each": "0", "vendor": "", "serial_number": "", "barcode": "",
                "warranty_expiry": "", "expiry_date": "", "condition": "Good", "notes": "",
            }
            for k, v in defaults.items():
                self.fields[k].set(v)
            self.item_tree.selection_remove(self.item_tree.selection())
            try:
                self.field_widgets["name"].focus_set()
            except Exception:
                pass
            self.set_status(f"New item form ready — SKU {self.fields['sku'].get()}")

        def quantity_popup(self, mode: str) -> None:
            if not self.selected_item_id:
                messagebox.showwarning(APP_NAME, "Select an item first.")
                return
            row = self.db.get_item(self.selected_item_id)
            if not row:
                return
            win = tk.Toplevel(self)
            win.title("Quantity Movement")
            win.configure(bg=AEGIS_DARK)
            win.geometry("360x230")
            ttk.Label(win, text=f"{mode.title()} {row['sku']} — {row['name']}", style="Title.TLabel").pack(anchor="w", padx=12, pady=(12, 4))
            qty_var = tk.StringVar(value="1")
            note_var = tk.StringVar()
            ref_var = tk.StringVar()
            for label, var in [("Quantity", qty_var), ("Note", note_var), ("Reference", ref_var)]:
                ttk.Label(win, text=label).pack(anchor="w", padx=12, pady=(6, 0))
                ttk.Entry(win, textvariable=var).pack(fill="x", padx=12)
            def apply() -> None:
                try:
                    qty = coerce_float(qty_var.get())
                    delta = abs(qty) if mode == "restock" else -abs(qty)
                    self.db.adjust_quantity(self.selected_item_id or 0, delta, mode, note_var.get(), ref_var.get())
                    win.destroy()
                    self.refresh_all()
                except Exception as exc:
                    messagebox.showerror(APP_NAME, str(exc))
            ttk.Button(win, text="Apply", command=apply).pack(anchor="e", padx=12, pady=12)

        def archive_selected(self) -> None:
            if not self.selected_item_id:
                messagebox.showwarning(APP_NAME, "Select an item first.")
                return
            row = self.db.get_item(self.selected_item_id)
            if not row:
                return
            archived = row["status"] != "archived"
            self.db.archive_item(self.selected_item_id, archived=archived)
            self.refresh_all()
            self.set_status("Archived" if archived else "Restored")

        def set_low_stock_filter(self, value: bool) -> None:
            self.low_stock_var.set(value)
            self.refresh_items()
            self.notebook.select(self.items_tab)


        def export_ledger_bridge_csv_gui(self) -> None:
            path = filedialog.asksaveasfilename(title="Export Ledger Bridge CSV", defaultextension=".csv", initialfile=f"sentinel_inventory_ledger_bridge_{_dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.csv", filetypes=[("CSV files", "*.csv"), ("All files", "*")])
            if not path:
                return
            out = self.db.export_ledger_bridge_csv(Path(path))
            self.set_status(f"Exported Ledger bridge CSV: {out}")
            messagebox.showinfo(APP_NAME, f"Exported Ledger bridge CSV:\n{out}")

        def export_pantry_bridge_csv_gui(self) -> None:
            path = filedialog.asksaveasfilename(title="Export Pantry Bridge CSV", defaultextension=".csv", initialfile=f"sentinel_inventory_pantry_bridge_{_dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.csv", filetypes=[("CSV files", "*.csv"), ("All files", "*")])
            if not path:
                return
            out = self.db.export_pantry_bridge_csv(Path(path))
            self.set_status(f"Exported Pantry bridge CSV: {out}")
            messagebox.showinfo(APP_NAME, f"Exported Pantry bridge CSV:\n{out}")

        def export_bridge_bundle_gui(self) -> None:
            dest = filedialog.askdirectory(title="Export Bridge Bundle Folder")
            if not dest:
                return
            result = self.db.export_bridge_bundle(Path(dest))
            self.set_status(f"Exported bridge bundle: {result['directory']}")
            messagebox.showinfo(APP_NAME, f"Exported bridge bundle:\n{result['directory']}\n\nManifest:\n{result['files'].get('manifest', '')}")

        def export_csv(self) -> None:
            path = filedialog.asksaveasfilename(title="Export CSV", defaultextension=".csv", initialfile=f"sentinel_inventory_{_dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.csv", filetypes=[("CSV files", "*.csv"), ("All files", "*")])
            if not path:
                return
            out = self.db.export_csv(Path(path))
            self.set_status(f"Exported CSV: {out}")
            messagebox.showinfo(APP_NAME, f"Exported CSV:\n{out}")

        def export_json(self) -> None:
            path = filedialog.asksaveasfilename(title="Export JSON", defaultextension=".json", initialfile=f"sentinel_inventory_{_dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.json", filetypes=[("JSON files", "*.json"), ("All files", "*")])
            if not path:
                return
            out = self.db.export_json(Path(path))
            self.set_status(f"Exported JSON: {out}")
            messagebox.showinfo(APP_NAME, f"Exported JSON:\n{out}")

        def export_reorder_csv(self) -> None:
            path = filedialog.asksaveasfilename(title="Export Reorder CSV", defaultextension=".csv", initialfile=f"sentinel_inventory_reorder_{_dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.csv", filetypes=[("CSV files", "*.csv"), ("All files", "*")])
            if not path:
                return
            out = self.db.export_reorder_csv(Path(path))
            self.set_status(f"Exported reorder CSV: {out}")
            messagebox.showinfo(APP_NAME, f"Exported reorder CSV:\n{out}")

        def export_warranty_csv(self) -> None:
            path = filedialog.asksaveasfilename(title="Export Warranty CSV", defaultextension=".csv", initialfile=f"sentinel_inventory_warranty_{_dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.csv", filetypes=[("CSV files", "*.csv"), ("All files", "*")])
            if not path:
                return
            out = self.db.export_warranty_csv(Path(path))
            self.set_status(f"Exported warranty CSV: {out}")
            messagebox.showinfo(APP_NAME, f"Exported warranty CSV:\n{out}")

        def export_service_csv(self) -> None:
            path = filedialog.asksaveasfilename(title="Export Service CSV", defaultextension=".csv", initialfile=f"sentinel_inventory_service_{_dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.csv", filetypes=[("CSV files", "*.csv"), ("All files", "*")])
            if not path:
                return
            out = self.db.export_service_csv(Path(path))
            self.set_status(f"Exported service CSV: {out}")
            messagebox.showinfo(APP_NAME, f"Exported service CSV:\n{out}")

        def export_expiry_csv(self) -> None:
            path = filedialog.asksaveasfilename(title="Export Expiry CSV", defaultextension=".csv", initialfile=f"sentinel_inventory_expiry_{_dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.csv", filetypes=[("CSV files", "*.csv"), ("All files", "*")])
            if not path:
                return
            out = self.db.export_expiry_csv(Path(path))
            self.set_status(f"Exported expiry CSV: {out}")
            messagebox.showinfo(APP_NAME, f"Exported expiry CSV:\n{out}")

        def _label_filter_kwargs(self) -> Dict[str, Any]:
            return {
                "query": self.label_query_var.get().strip() if hasattr(self, "label_query_var") else "",
                "category": self.label_category_var.get().strip() if hasattr(self, "label_category_var") else "",
                "location": self.label_location_var.get().strip() if hasattr(self, "label_location_var") else "",
                "low_stock_only": self.label_low_stock_var.get() if hasattr(self, "label_low_stock_var") else False,
            }

        def export_label_csv_gui(self) -> None:
            path = filedialog.asksaveasfilename(title="Export Label CSV", defaultextension=".csv", initialfile=f"sentinel_inventory_labels_{_dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.csv", filetypes=[("CSV files", "*.csv"), ("All files", "*")])
            if not path:
                return
            out = self.db.export_label_csv(Path(path), **self._label_filter_kwargs())
            self.set_status(f"Exported label CSV: {out}")
            messagebox.showinfo(APP_NAME, f"Exported label CSV:\n{out}")

        def export_label_json_gui(self) -> None:
            path = filedialog.asksaveasfilename(title="Export Label JSON", defaultextension=".json", initialfile=f"sentinel_inventory_labels_{_dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.json", filetypes=[("JSON files", "*.json"), ("All files", "*")])
            if not path:
                return
            out = self.db.export_label_json(Path(path), **self._label_filter_kwargs())
            self.set_status(f"Exported label JSON: {out}")
            messagebox.showinfo(APP_NAME, f"Exported label JSON:\n{out}")

        def export_label_html_gui(self) -> None:
            path = filedialog.asksaveasfilename(title="Export Printable Label HTML", defaultextension=".html", initialfile=f"sentinel_inventory_labels_{_dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.html", filetypes=[("HTML files", "*.html"), ("All files", "*")])
            if not path:
                return
            out = self.db.export_label_html(Path(path), **self._label_filter_kwargs())
            self.set_status(f"Exported printable labels: {out}")
            messagebox.showinfo(APP_NAME, f"Exported printable label sheet:\n{out}")

        def export_qr_png_gui(self) -> None:
            dest = filedialog.askdirectory(title="Export QR PNGs to Folder")
            if not dest:
                return
            try:
                result = self.db.export_qr_pngs(Path(dest), **self._label_filter_kwargs())
            except RuntimeError as exc:
                messagebox.showerror(APP_NAME, str(exc))
                return
            self.set_status(f"Exported {result['created']} QR PNG(s) to {result['directory']}")
            messagebox.showinfo(APP_NAME, f"Exported {result['created']} QR PNG(s):\n{result['directory']}")

        def service_popup(self) -> None:
            if not self.selected_item_id:
                messagebox.showwarning(APP_NAME, "Select an item first in the Items tab.")
                self.notebook.select(self.items_tab)
                return
            row = self.db.get_item(self.selected_item_id)
            if not row:
                return
            win = tk.Toplevel(self)
            win.title("Add Service Record")
            win.configure(bg=AEGIS_DARK)
            win.geometry("460x430")
            ttk.Label(win, text=f"Service for {row['sku']} — {row['name']}", style="Title.TLabel").pack(anchor="w", padx=12, pady=(12, 4))
            vars_: Dict[str, tk.StringVar] = {
                "type": tk.StringVar(value="service"),
                "description": tk.StringVar(),
                "cost": tk.StringVar(value="0"),
                "provider": tk.StringVar(),
                "performed": tk.StringVar(value=today().isoformat()),
                "next_due": tk.StringVar(),
                "reference": tk.StringVar(),
            }
            labels = [
                ("Service Type", "type"), ("Description", "description"), ("Cost", "cost"),
                ("Provider", "provider"), ("Performed Date YYYY-MM-DD", "performed"),
                ("Next Due YYYY-MM-DD", "next_due"), ("Reference", "reference"),
            ]
            for label, key in labels:
                ttk.Label(win, text=label).pack(anchor="w", padx=12, pady=(6, 0))
                ttk.Entry(win, textvariable=vars_[key]).pack(fill="x", padx=12)
            def save() -> None:
                try:
                    self.db.add_service_record(
                        self.selected_item_id or 0, vars_["type"].get(), vars_["description"].get(),
                        coerce_float(vars_["cost"].get()), vars_["provider"].get(), vars_["performed"].get(),
                        vars_["next_due"].get(), vars_["reference"].get(),
                    )
                    win.destroy()
                    self.refresh_all()
                    messagebox.showinfo(APP_NAME, "Service record saved.")
                except Exception as exc:
                    messagebox.showerror(APP_NAME, str(exc))
            ttk.Button(win, text="Save Service Record", command=save).pack(anchor="e", padx=12, pady=14)

        def install_desktop_launcher_gui(self) -> None:
            try:
                dest = install_desktop_launcher()
                self.set_status(f"Desktop launcher installed: {dest}")
                messagebox.showinfo(APP_NAME, f"Desktop launcher installed:\n{dest}")
            except Exception as exc:
                messagebox.showerror(APP_NAME, str(exc))


        def import_csv(self) -> None:
            path = filedialog.askopenfilename(title="Import CSV", filetypes=[("CSV files", "*.csv"), ("All files", "*")])
            if not path:
                return
            try:
                result = self.db.import_csv(Path(path))
                self.refresh_all()
                messagebox.showinfo(APP_NAME, "Import complete:\n" + json.dumps(result, indent=2))
            except Exception as exc:
                messagebox.showerror(APP_NAME, str(exc))

        def backup_db(self) -> None:
            path = filedialog.askdirectory(title="Choose backup folder")
            dest = Path(path) if path else None
            out = self.db.backup(dest)
            self.set_status(f"Backup created: {out}")
            messagebox.showinfo(APP_NAME, f"Backup created:\n{out}")

        def show_health(self) -> None:
            payload = json.dumps(self.db.health(), indent=2)
            if hasattr(self, "utility_text"):
                self.utility_text_insert(payload + "\n")
            top = tk.Toplevel(self)
            top.title("AEGIS / Sentinel Command Status")
            top.configure(bg=AEGIS_DARK)
            text = tk.Text(top, bg=AEGIS_PANEL, fg=AEGIS_TEXT, relief="flat", width=90, height=30)
            text.pack(fill="both", expand=True, padx=10, pady=10)
            text.insert("1.0", payload)
            text.configure(state="disabled")

        def on_close(self) -> None:
            try:
                self.db.close()
            finally:
                self.destroy()

    app = InventoryApp()
    app.mainloop()
    return 0


def main() -> None:
    raise SystemExit(run_cli())


if __name__ == "__main__":
    main()
