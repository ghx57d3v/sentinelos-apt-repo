# Sentinel Notes v1.0.0 — Program 102 Stable Lock

Sentinel Notes is the Program 102 SentinelOS desktop notes application. It is a lightweight, local-first notes app with plain/Markdown notes, numbered task lists, Finance Tables, optional encrypted save/open, and AEGIS-ready CLI/JSON control.

## Stable v1.0 scope

- Notes mode for plain/Markdown notes
- Tasks mode with numbered-list default
- Finance Tables mode for lightweight price/debt/parts/cost tables
- Optional encrypted save/open for notes, tasks, and Finance Tables
- Markdown toolbar and preview
- Desktop/menu launcher and Sentinel Notes icon
- Safe system install plus user setup helpers
- AEGIS manifest, JSON action mode, review status, audit tail, summaries, Vault export, and self-check

## Install

```bash
sudo ./install.sh --system --clean-shadow
sudo sentinel-notes-repair stephen
sentinel-notes-user-setup --clean-shadow
hash -r
sentinel-notes --version
sentinel-notes --self-check
sentinel-notes-doctor
```

Expected version:

```text
Sentinel Notes 1.0.0 (Program 102)
```

Do not run the app with sudo. User notes belong under the normal user's local data folder, not `/root`.

## Tasks mode

Tasks now opens as a numbered list by default:

```text
1. 
```

Pressing ENTER continues the numbering. Checklist formatting is still available through the toolbar for users who want checkbox lines.

## AEGIS readiness

Sentinel Notes remains AEGIS-ready from the start: CLI commands, JSON actions, manifest, permission model, audit logs, safe read/write boundaries, local-first storage, and user-controlled encrypted access.
