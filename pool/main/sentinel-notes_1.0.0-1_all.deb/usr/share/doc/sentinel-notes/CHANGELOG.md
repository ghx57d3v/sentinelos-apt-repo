# Changelog

## v1.0.0

- Stable lock build for Program 102 Sentinel Notes.
- Tasks mode now defaults to numbered lists instead of checklist lines.
- ENTER in Tasks mode continues the numbered sequence.
- Checklist line insertion remains available through the toolbar.
- Ctrl+Q now uses the normal close/unsaved-change path.
- Version, package metadata, docs, manifests, and self-tests updated for v1.0.0.

## Earlier

- v0.9.1: Ctrl+Q GUI close hotkey.
- v0.9.0: stabilization and self-check.
- v0.8.x: AEGIS review/export/audit, Finance Tables, install repair policy.
- v0.7.0: spreadsheet-style Finance Table cell editing direction.
- v0.6.x: desktop launcher/icon and GUI polish.
