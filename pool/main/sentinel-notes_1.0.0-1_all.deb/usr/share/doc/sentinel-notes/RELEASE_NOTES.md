# Sentinel Notes v1.0.0 Release Notes

Program 102 Sentinel Notes v1.0.0 is the stable lock build for the SentinelOS Desk Suite notes application.

## v1.0.0 changes

- Promotes Sentinel Notes to v1.0.0 stable lock status.
- Changes Tasks mode default from checklist lines to numbered-list lines.
- ENTER in Tasks mode now continues the numbered list.
- Keeps checklist formatting available from the toolbar.
- Ctrl+Q closes the GUI through the normal unsaved-changes confirmation path.
- Updates version text, docs, package version, self-test, manifests, and checksums.

## Preserved from earlier builds

- Notes mode
- Tasks mode
- Finance Tables mode
- Optional encrypted save/open
- Markdown toolbar and preview
- Desktop/menu launcher and icon support
- `sentinel-notes-doctor`
- `sentinel-notes-user-setup`
- `sentinel-notes-repair`
- AEGIS JSON/action mode
- AEGIS manifest/review/audit/summary/Vault export tools
- Self-check
- Local-first storage
- Debian package

## Install flow

```bash
sudo ./install.sh --system --clean-shadow
sudo sentinel-notes-repair stephen
sentinel-notes-user-setup --clean-shadow
hash -r
sentinel-notes --version
sentinel-notes --self-check
sentinel-notes-doctor
```
