# Source attribution

Source archive: `theme.zip`  
SHA-256: `96de1292631d48c57508f818ceab6dcbe4d5bf5f87072e2f134dc9d768bb3353`

The supplied GTK/Marco source identifies itself as **hercules-dark-compact**.
Its embedded Metacity metadata and GTK comments remain inside the installed
source files. SentinelOS renamed and recoloured the source into three complete
MATE metathemes, corrected their component references, added preview images and
added an explicit Caja desktop transparency contract.

The uploaded `Sentinel-theme` icon directory was not substituted for the
approved SentinelOS icon packages. SentinelOS Dark and Light use the approved
cyan icon family; AEGIS uses the approved gold icon family.
