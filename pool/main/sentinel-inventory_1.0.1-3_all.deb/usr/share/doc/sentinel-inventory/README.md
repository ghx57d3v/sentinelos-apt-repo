# Sentinel Inventory v1.0.0

**Program 115 — Sentinel Inventory** is the v1 stable local-first inventory manager for Sentinel Linux.

This release is the **Stable Lock / Audit / Backup Restore Patch** over v0.9.0.

## v1 stable baseline

v1.0.0 locks the completed user-ready baseline:

- Local SQLite inventory database, schema v3
- GUI and CLI workflows
- MATE menu entry and desktop launcher support
- User-supplied gold inventory/shield icon
- Sequential SKU autofill
- USB HID keyboard-wedge barcode / QR scanner workflow
- Scanner lookup by barcode, SKU, then serial number
- Fast stock movement, transfer mode, batch scan queue, duplicate debounce, and recent scans
- Expiry / best-before tracking with expired, close-to-expiry, good-date, freshest, and unknown status reports
- Warranty and service/repair records
- Category/location valuation summaries
- Low-stock reorder reports
- Label/QR payload exports and local printable HTML label sheets
- Sentinel Ledger bridge exports
- Sentinel Pantry bridge exports
- Supplier reorder handoff and bridge bundle
- Backup, restore, audit report, stable lock report, and v1 handoff bundle
- AEGIS / Sentinel Command readable health JSON
- Local-only / no network / no telemetry posture

## Install

```bash
sudo apt install ./sentinel-inventory_1.0.1-3_all.deb
```

Repair menu/launcher/icon cache:

```bash
sentinel-inventory-repair-launchers
```

Launch GUI:

```bash
sentinel-inventory-gui
```

Run validation:

```bash
sentinel-inventory-self-test
```

## New v1 commands

```bash
sentinel-inventory audit-report
sentinel-inventory audit-report --json
sentinel-inventory export-audit-json
sentinel-inventory export-audit-csv
sentinel-inventory stable-lock-report
sentinel-inventory export-v1-bundle
sentinel-inventory backup
sentinel-inventory restore-backup ./sentinel_inventory_backup_YYYYMMDD_HHMMSS.db --confirm RESTORE_INVENTORY
```

Restore is intentionally guarded. It creates a pre-restore copy of the current database before replacing it.

## Bridge / handoff exports

```bash
sentinel-inventory bridge-status
sentinel-inventory bridge-status --json
sentinel-inventory export-ledger-bridge-csv
sentinel-inventory export-ledger-bridge-json
sentinel-inventory export-pantry-bridge-csv
sentinel-inventory export-pantry-bridge-json
sentinel-inventory export-bridge-bundle
sentinel-inventory export-v1-bundle
```

The bridge layer still does not directly write into Ledger or Pantry. It provides stable local CSV/JSON contracts for future importer patches.

## Expiry / freshness / rotation

The app classifies date-tracked stock as:

- **Expired** — expiry date is before today.
- **Close to expiry** — expiry date is within the warning window, default 30 days.
- **Good date** — expiry date is beyond the warning window.
- **Freshest** — future-dated stock sorted by furthest expiry date first.
- **Unknown** — no parseable expiry/best-before date recorded.

```bash
sentinel-inventory add "Rice" --quantity 10 --unit kg --expiry 2027-01-31
sentinel-inventory expiry-report --days 30
sentinel-inventory freshest-stock --limit 20
sentinel-inventory export-expiry-csv
```

## USB scanner support

Most USB barcode scanners present as **keyboard-wedge HID devices**. Linux sees them like a keyboard. When you scan a code, the scanner types the code into the focused field and often sends Enter.

```bash
sentinel-inventory scan 9312345678901
sentinel-inventory scan-restock 9312345678901 1
sentinel-inventory scan-consume 9312345678901 1
sentinel-inventory scan-fast 9312345678901
sentinel-inventory scan-batch ./scans.txt --mode restock --quantity 1
```

## Label / QR / print prep

Labels use the stable local QR payload pattern:

```text
sentinel-inventory://item/{SKU}
```

```bash
sentinel-inventory labels
sentinel-inventory export-label-csv
sentinel-inventory export-label-json
sentinel-inventory export-label-html --copies 2
sentinel-inventory export-qr-png ./qr_labels
```

## Schema

Database schema remains **v3**. The v1 stable lock adds audit, restore, stable-lock reporting, and v1 handoff/export workflows without requiring another database migration.
