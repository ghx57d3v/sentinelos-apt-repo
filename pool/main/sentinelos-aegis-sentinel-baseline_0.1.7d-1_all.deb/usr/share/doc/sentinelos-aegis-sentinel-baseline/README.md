Meta-package for AEGIS Sentinel v1.0 stable baseline option gate.
