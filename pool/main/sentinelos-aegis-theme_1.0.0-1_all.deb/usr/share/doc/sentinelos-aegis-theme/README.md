# AEGIS Navy/Gold Desktop Theme

Theme: `AEGIS-Navy-Gold`  
Icons: `SentinelOS-Dark`  
Cursor: `SentinelOS-Cursor-AEGIS-Navy-Gold`

The package is conditional on the public AEGIS suite and is passive at install
time. It does not modify live user settings or wallpaper.

Apply as the desktop user:

```bash
sentinelos-aegis-theme --apply --confirm APPLY_AEGIS_DESKTOP_THEME
```

Restore:

```bash
sentinelos-aegis-theme --restore-latest --confirm RESTORE_AEGIS_DESKTOP_THEME
```
