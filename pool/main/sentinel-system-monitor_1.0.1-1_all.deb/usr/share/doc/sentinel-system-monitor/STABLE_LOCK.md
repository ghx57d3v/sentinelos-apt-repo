# Sentinel System Monitor v1.0.1 Stable Lock Hotfix

v1.0.1 preserves the v1.0.0 stable capability set and applies one launch-stability correction: the widget now uses a safe managed, non-topmost window policy by default so it opens reliably from the main application and menu entry.

AEGIS integration remains read-only, local-only, JSON-first, and unable to execute cleanup or process-control actions.
