# Sentinel System Monitor v1.0.1

Program 108 of the Sentinel Desktop Suite.

This is a stable hotfix over v1.0.0. It fixes the widget failing to open or appearing to hang on some MATE/Marco desktops by removing the aggressive desktop/splash window-type behavior from the default widget path.

## Widget behavior
Default widget behavior is now:

- managed Tk window
- not topmost
- coverable by normal open windows
- 50% translucent by default
- live coloured metric bars enabled
- available from the main app and the applications menu

The widget is intentionally no longer forced into fragile Tk/X11 desktop-layer hints by default. Those hints can make the widget disappear behind the desktop window on some systems.

## Launch

```bash
sentinel-system-monitor
sentinel-system-monitor-widget
```

## Repair old settings

```bash
sentinel-system-monitor-cli repair --widget-defaults
sentinel-system-monitor-install-launchers
```

## Widget error log

```text
~/.local/state/sentinel-system-monitor/widget-error.log
```
