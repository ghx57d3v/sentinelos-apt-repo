# Sentinel System Monitor Changelog

## v1.0.1 — Widget Launch Stability Hotfix
- Fixes the widget failing to open or appearing to hang from the menu/main app on some MATE/Marco setups.
- Changes the default widget window policy to a safe managed, non-topmost Tk window.
- Removes forced desktop/splash window-type behavior from the default path.
- Disables xprop/wmctrl BELOW/SKIP hints by default because they can hide the widget behind the desktop window.
- Keeps the widget coverable by normal open windows.
- Keeps the widget menu entry.
- Keeps the main app Open Widget button and File → Open Widget action.
- Keeps the supplied System Monitor icon from the v1 line.
- Preserves v1.0.0 stable-lock capabilities.

## v1.0.0 — Stable Lock
- Stable baseline for Program 108 Sentinel System Monitor.
