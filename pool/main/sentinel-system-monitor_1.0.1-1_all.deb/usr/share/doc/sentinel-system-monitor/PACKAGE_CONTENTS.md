# Sentinel System Monitor Package Contents

Program 108 — Sentinel System Monitor v1.0.1

Included commands:
- `sentinel-system-monitor`
- `sentinel-system-monitor-widget`
- `sentinel-system-monitor-cli`
- `sentinel-system-monitor-aegis`
- `sentinel-system-monitor-doctor`
- `sentinel-system-monitor-install-launchers`

Included capabilities:
- Main GUI system monitor
- Widget menu entry
- Main desktop/menu launcher
- Open Widget button in the main app
- CPU/RAM/swap/disk/temperature/battery/network/uptime metrics
- Live coloured widget bars
- Process viewer/details
- Preview-first cleanup
- Local alert thresholds
- AEGIS read-only local JSON helper
- Doctor/repair tools
- Stable-lock report
- v1.0.1 safe widget launch policy
