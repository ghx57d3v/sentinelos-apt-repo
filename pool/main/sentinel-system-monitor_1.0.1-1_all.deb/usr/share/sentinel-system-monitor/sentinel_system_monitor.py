#!/usr/bin/env python3
"""
Sentinel System Monitor v1.0.1
Program 108 — local-first system visibility and desktop widget for SentinelOS.

Design rules:
- Local-only. No telemetry, no cloud, no external APIs, no outbound network actions.
- Uses local OS counters only through psutil, /proc-compatible metrics, and Python stdlib.
- Desktop widget is compact, draggable, and closeable with Ctrl+Q or Esc.
- Widget background is 50% translucent by default and configurable in settings.
- Widget supports desktop-layer placement by default, compact/normal/expanded modes, saved position, lock position, and right-click controls.
- Cleanup is conservative, preview-first, user-level only, and logs actions locally.
- Process management is confirmation-first; terminate/kill actions are never available through AEGIS.
- Widget can show live visual metric bars for CPU/RAM/disk/temp/battery/network.
- AEGIS local AI integration is read-only, JSON-first, and local-only.
- v1.0.1 is a stable widget launch hotfix. It preserves the v1 stable lock while changing the default widget to a safe managed non-topmost window so the widget opens reliably from the menu and main application.
"""
from __future__ import annotations

import argparse
import json
import os
import platform
import shutil
import socket
import subprocess
import stat
import sys
import tempfile
import time
import traceback
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

try:
    import psutil
except Exception as exc:  # pragma: no cover
    print("Sentinel System Monitor requires python3-psutil. Install package: python3-psutil", file=sys.stderr)
    raise

APP_NAME = "Sentinel System Monitor"
APP_ID = "sentinel-system-monitor"
VERSION = "1.0.1"
AEGIS_CONTRACT_VERSION = "1.0"
THEME = {
    "bg": "#0B0F14",
    "panel": "#111821",
    "panel2": "#151E29",
    "text": "#E8EEF2",
    "muted": "#93A4B3",
    "gold": "#E19B00",
    "cyan": "#03C8FF",
    "red": "#D9534F",
    "green": "#5CB85C",
}
NETWORK_POLICY = {
    "network_allowed": False,
    "cloud_sync": False,
    "telemetry": False,
    "remote_accounts": False,
    "external_api_calls": False,
    "policy": "local-only; reads local system counters only; no outbound network actions",
}
WIDGET_MODES = {
    "compact": {"geometry": "280x144", "metrics": ["cpu", "ram", "disk"]},
    "normal": {"geometry": "300x184", "metrics": ["cpu", "ram", "disk", "temp", "net"]},
    "expanded": {"geometry": "340x258", "metrics": ["cpu", "ram", "swap", "disk", "temp", "battery", "net", "uptime"]},
}
WIDGET_METRIC_ORDER = ["cpu", "ram", "swap", "disk", "temp", "battery", "net", "uptime"]
WIDGET_LAYERS = {
    "desktop": "Desktop layer — sits on desktop and stays behind normal windows",
    "normal": "Normal floating window — not always-on-top",
    "topmost": "Always on top — only when explicitly selected",
}
DEFAULT_WIDGET_VISIBLE_METRICS = {
    "cpu": True,
    "ram": True,
    "swap": True,
    "disk": True,
    "temp": True,
    "battery": True,
    "net": True,
    "uptime": True,
}
SETTINGS_FILE_NAME = "settings.json"
AEGIS_POLICY_FILE_NAME = "aegis_policy.json"
DEFAULT_SETTINGS = {
    "version": 1,
    "widget_opacity": 0.50,
    "widget_mode": "normal",
    "widget_always_on_top": False,
    "widget_layer": "desktop",
    "widget_layer_user_set": False,
    "widget_lock_position": False,
    "widget_refresh_ms": 1500,
    "widget_position": {"x": 40, "y": 40},
    "widget_visible_metrics": dict(DEFAULT_WIDGET_VISIBLE_METRICS),
    "widget_visual_bars": True,
    "alert_thresholds": {
        "cpu_percent": 90,
        "memory_percent": 90,
        "disk_percent": 90,
        "temperature_c": 85,
        "battery_percent": 15
    },
    "desktop_notifications": False,
    "aegis_enabled": True,
    "aegis_read_only": True,
    "local_only": True,
}
DEFAULT_AEGIS_POLICY = {
    "version": 1,
    "enabled": True,
    "read_only": True,
    "local_only": True,
    "network_allowed": False,
    "interface": "sentinel-system-monitor-aegis",
    "allowed_commands": ["status", "metrics", "hardware", "cleanup-preview", "alerts", "widget-settings", "widget-profile", "processes", "process-details", "permissions", "alert-thresholds", "validate-policy", "contract", "health-summary", "recommendations", "stable-lock"],
    "control_actions_require_user_confirmation": True,
    "notes": "Approved local AEGIS access path. Reports local metrics only; no network transport or destructive actions.",
}


def human_bytes(num: float) -> str:
    for unit in ("B", "KB", "MB", "GB", "TB", "PB"):
        if abs(num) < 1024.0:
            return f"{num:3.1f} {unit}"
        num /= 1024.0
    return f"{num:.1f} EB"


def human_seconds(seconds: float) -> str:
    try:
        td = timedelta(seconds=int(seconds))
        days = td.days
        hours, rem = divmod(td.seconds, 3600)
        mins, _ = divmod(rem, 60)
        parts = []
        if days:
            parts.append(f"{days}d")
        if hours:
            parts.append(f"{hours}h")
        parts.append(f"{mins}m")
        return " ".join(parts)
    except Exception:
        return "unknown"


def percent_bar(value: Optional[float], width: int = 18) -> str:
    if value is None:
        return "[unknown]"
    value = max(0.0, min(100.0, float(value)))
    filled = int(round(width * value / 100.0))
    return "[" + "#" * filled + "-" * (width - filled) + f"] {value:5.1f}%"


def safe_stat_mode(path: Path) -> Optional[int]:
    try:
        return stat.S_IMODE(path.stat().st_mode)
    except OSError:
        return None




def config_dir() -> Path:
    return Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")) / APP_ID


def ensure_private_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(path, 0o700)
    except OSError:
        pass


def write_private_json(path: Path, payload: Dict[str, Any]) -> None:
    ensure_private_dir(path.parent)
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, indent=2, sort_keys=True)
            fh.write("\n")
        os.chmod(tmp, 0o600)
        os.replace(tmp, path)
        os.chmod(path, 0o600)
    finally:
        if os.path.exists(tmp):
            try:
                os.unlink(tmp)
            except OSError:
                pass


def read_private_json(path: Path, defaults: Dict[str, Any]) -> Dict[str, Any]:
    if not path.exists():
        write_private_json(path, dict(defaults))
        return dict(defaults)
    try:
        with path.open("r", encoding="utf-8") as fh:
            data = json.load(fh)
        merged = dict(defaults)
        if isinstance(data, dict):
            merged.update(data)
        return merged
    except Exception:
        return dict(defaults)


def settings_path() -> Path:
    return config_dir() / SETTINGS_FILE_NAME


def aegis_policy_path() -> Path:
    return config_dir() / AEGIS_POLICY_FILE_NAME


def cleanup_log_path() -> Path:
    return config_dir() / "cleanup.log"


def append_cleanup_log(payload: Dict[str, Any]) -> None:
    ensure_private_dir(config_dir())
    record = dict(payload)
    record["timestamp"] = datetime.now().isoformat(timespec="seconds")
    try:
        with cleanup_log_path().open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(record, sort_keys=True) + "\n")
        os.chmod(cleanup_log_path(), 0o600)
    except OSError:
        pass


def sanitize_widget_settings(settings: Dict[str, Any]) -> Dict[str, Any]:
    merged = dict(DEFAULT_SETTINGS)
    merged.update(settings or {})
    try:
        merged["widget_opacity"] = max(0.20, min(1.0, float(merged.get("widget_opacity", 0.50))))
    except Exception:
        merged["widget_opacity"] = 0.50
    mode = str(merged.get("widget_mode", "normal")).lower()
    if mode not in WIDGET_MODES:
        mode = "normal"
    merged["widget_mode"] = mode
    try:
        merged["widget_refresh_ms"] = max(750, min(10000, int(merged.get("widget_refresh_ms", 1500))))
    except Exception:
        merged["widget_refresh_ms"] = 1500
    position = merged.get("widget_position")
    if not isinstance(position, dict):
        position = {"x": 40, "y": 40}
    try:
        position = {"x": int(position.get("x", 40)), "y": int(position.get("y", 40))}
    except Exception:
        position = {"x": 40, "y": 40}
    merged["widget_position"] = position
    visible = dict(DEFAULT_WIDGET_VISIBLE_METRICS)
    supplied = merged.get("widget_visible_metrics")
    if isinstance(supplied, dict):
        for key in WIDGET_METRIC_ORDER:
            if key in supplied:
                visible[key] = bool(supplied[key])
    merged["widget_visible_metrics"] = visible
    merged["widget_visual_bars"] = bool(merged.get("widget_visual_bars", True))
    layer = str(merged.get("widget_layer", "desktop")).lower().strip()
    if layer not in WIDGET_LAYERS:
        layer = "desktop"
    # v0.7.0 migration: old builds could leave topmost/normal behavior in user settings.
    # Unless the user explicitly saves a layer with the new setting, the default is desktop:
    # coverable by open windows and never forced above them.
    layer_user_set = bool(merged.get("widget_layer_user_set", False))
    if not layer_user_set:
        layer = "desktop"
    merged["widget_layer"] = layer
    merged["widget_layer_user_set"] = layer_user_set
    merged["widget_always_on_top"] = (layer == "topmost" and layer_user_set)
    merged["widget_lock_position"] = bool(merged.get("widget_lock_position", False))
    default_thresholds = dict(DEFAULT_SETTINGS.get("alert_thresholds", {}))
    supplied_thresholds = merged.get("alert_thresholds")
    if isinstance(supplied_thresholds, dict):
        default_thresholds.update(supplied_thresholds)
    def _threshold(name: str, fallback: int, low: int, high: int) -> int:
        try:
            return max(low, min(high, int(default_thresholds.get(name, fallback))))
        except Exception:
            return fallback
    merged["alert_thresholds"] = {
        "cpu_percent": _threshold("cpu_percent", 90, 1, 100),
        "memory_percent": _threshold("memory_percent", 90, 1, 100),
        "disk_percent": _threshold("disk_percent", 90, 1, 100),
        "temperature_c": _threshold("temperature_c", 85, 1, 125),
        "battery_percent": _threshold("battery_percent", 15, 1, 100),
    }
    merged["desktop_notifications"] = bool(merged.get("desktop_notifications", False))
    return merged


def load_settings() -> Dict[str, Any]:
    settings = read_private_json(settings_path(), DEFAULT_SETTINGS)
    return sanitize_widget_settings(settings)


def save_settings(settings: Dict[str, Any]) -> None:
    write_private_json(settings_path(), sanitize_widget_settings(settings))


def load_aegis_policy() -> Dict[str, Any]:
    policy = read_private_json(aegis_policy_path(), DEFAULT_AEGIS_POLICY)
    # Preserve user policy edits while ensuring new read-only v0.7.0 commands are available after upgrades.
    allowed = list(dict.fromkeys(list(policy.get("allowed_commands", [])) + list(DEFAULT_AEGIS_POLICY.get("allowed_commands", []))))
    policy["allowed_commands"] = allowed
    return policy


def save_aegis_policy(policy: Dict[str, Any]) -> None:
    merged = dict(DEFAULT_AEGIS_POLICY)
    merged.update(policy)
    write_private_json(aegis_policy_path(), merged)


def ensure_runtime_config() -> None:
    ensure_private_dir(config_dir())
    if not settings_path().exists():
        save_settings(DEFAULT_SETTINGS)
    if not aegis_policy_path().exists():
        save_aegis_policy(DEFAULT_AEGIS_POLICY)


def set_widget_opacity(value: float) -> Dict[str, Any]:
    settings = load_settings()
    settings["widget_opacity"] = max(0.20, min(1.0, float(value)))
    save_settings(settings)
    return load_settings()


def set_widget_mode(mode: str) -> Dict[str, Any]:
    settings = load_settings()
    mode = str(mode).lower().strip()
    if mode not in WIDGET_MODES:
        raise ValueError(f"Unknown widget mode: {mode}. Valid modes: {', '.join(WIDGET_MODES)}")
    settings["widget_mode"] = mode
    save_settings(settings)
    return load_settings()


def set_widget_position(x: int, y: int) -> Dict[str, Any]:
    settings = load_settings()
    settings["widget_position"] = {"x": int(x), "y": int(y)}
    save_settings(settings)
    return load_settings()


def reset_widget_position() -> Dict[str, Any]:
    settings = load_settings()
    settings["widget_position"] = {"x": 40, "y": 40}
    save_settings(settings)
    return load_settings()


def widget_profile(settings: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    s = sanitize_widget_settings(settings or load_settings())
    mode = s.get("widget_mode", "normal")
    mode_info = WIDGET_MODES.get(mode, WIDGET_MODES["normal"])
    visible = s.get("widget_visible_metrics", {})
    active_metrics = [key for key in mode_info["metrics"] if visible.get(key, True)]
    return {
        "mode": mode,
        "geometry": mode_info["geometry"],
        "active_metrics": active_metrics,
        "available_modes": list(WIDGET_MODES.keys()),
        "opacity": s.get("widget_opacity", 0.50),
        "opacity_percent": round(float(s.get("widget_opacity", 0.50)) * 100),
        "layer": s.get("widget_layer", "desktop"),
        "layer_description": WIDGET_LAYERS.get(str(s.get("widget_layer", "desktop")), WIDGET_LAYERS["desktop"]),
        "always_on_top": bool(s.get("widget_always_on_top", False)),
        "layer_user_set": bool(s.get("widget_layer_user_set", False)),
        "default_behavior": "desktop layer; not topmost; coverable by open windows",
        "lock_position": bool(s.get("widget_lock_position", False)),
        "position": s.get("widget_position", {"x": 40, "y": 40}),
        "refresh_ms": s.get("widget_refresh_ms", 1500),
        "visual_bars": bool(s.get("widget_visual_bars", True)),
        "launch_policy": "main app and menu entry; no widget desktop shortcut",
    }


def alert_thresholds(settings: Optional[Dict[str, Any]] = None) -> Dict[str, int]:
    return dict(sanitize_widget_settings(settings or load_settings()).get("alert_thresholds", DEFAULT_SETTINGS["alert_thresholds"]))


def set_alert_threshold(metric: str, value: int) -> Dict[str, Any]:
    aliases = {
        "cpu": "cpu_percent",
        "memory": "memory_percent",
        "ram": "memory_percent",
        "disk": "disk_percent",
        "temperature": "temperature_c",
        "temp": "temperature_c",
        "battery": "battery_percent",
    }
    key = aliases.get(str(metric).lower().strip(), str(metric).lower().strip())
    if key not in DEFAULT_SETTINGS["alert_thresholds"]:
        raise ValueError("Unknown threshold metric. Valid: cpu, memory, disk, temperature, battery")
    settings = load_settings()
    thresholds = dict(settings.get("alert_thresholds", DEFAULT_SETTINGS["alert_thresholds"]))
    thresholds[key] = int(value)
    settings["alert_thresholds"] = thresholds
    save_settings(settings)
    return load_settings()


def alert_summary(status: Dict[str, Any], settings: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    thresholds = alert_thresholds(settings)
    alerts: List[Dict[str, Any]] = []

    def add(metric: str, current: Optional[float], threshold: float, unit: str, message: str, level: str = "warning") -> None:
        if current is None:
            return
        alerts.append({
            "level": level,
            "metric": metric,
            "current": round(float(current), 1),
            "threshold": threshold,
            "unit": unit,
            "message": message,
        })

    cpu = float(status.get("cpu", {}).get("percent", 0) or 0)
    if cpu >= thresholds["cpu_percent"]:
        add("cpu", cpu, thresholds["cpu_percent"], "%", "CPU usage is above the configured threshold")
    mem = float(status.get("memory", {}).get("percent", 0) or 0)
    if mem >= thresholds["memory_percent"]:
        add("memory", mem, thresholds["memory_percent"], "%", "Memory usage is above the configured threshold")
    root_pct = status.get("disk", {}).get("root", {}).get("percent")
    if root_pct is not None and float(root_pct) >= thresholds["disk_percent"]:
        add("disk", float(root_pct), thresholds["disk_percent"], "%", "Root disk usage is above the configured threshold")
    temp = status.get("temperature", {}).get("summary_c")
    if temp is not None and float(temp) >= thresholds["temperature_c"]:
        add("temperature", float(temp), thresholds["temperature_c"], "°C", "Temperature is above the configured threshold")
    batt = status.get("battery", {})
    batt_pct = batt.get("percent")
    if batt.get("available") and not batt.get("plugged") and batt_pct is not None and float(batt_pct) <= thresholds["battery_percent"]:
        add("battery", float(batt_pct), thresholds["battery_percent"], "%", "Battery level is below the configured threshold")
    return {
        "ok": not alerts,
        "alerts": alerts,
        "count": len(alerts),
        "thresholds": thresholds,
        "desktop_notifications": bool(sanitize_widget_settings(settings or load_settings()).get("desktop_notifications", False)),
        "policy": "local-only threshold checks; optional local desktop notification only",
    }


def state_dir() -> Path:
    return Path(os.environ.get("XDG_STATE_HOME", Path.home() / ".local" / "state")) / APP_ID


def error_log_path() -> Path:
    return state_dir() / "widget-error.log"


def log_widget_error(exc: BaseException) -> None:
    try:
        ensure_private_dir(state_dir())
        with error_log_path().open("a", encoding="utf-8") as fh:
            fh.write(f"[{datetime.now().isoformat(timespec='seconds')}] {type(exc).__name__}: {exc}\n")
            fh.write(traceback.format_exc())
            fh.write("\n")
        os.chmod(error_log_path(), 0o600)
    except Exception:
        pass

def apply_x11_below_hints(root: Any) -> None:
    """Optional EWMH hints for advanced desktop-layer experiments.

    v1.0.1 intentionally does *not* apply xprop/wmctrl hints by default.
    On some MATE/Marco setups those hints can make the Tk widget appear to
    hang, disappear behind Caja's desktop window, or close immediately. The
    stable default is now a normal managed, non-topmost, coverable widget.

    Set SENTINEL_SYSTEM_MONITOR_EXPERIMENTAL_DESKTOP_HINTS=1 to opt into the
    older BELOW/SKIP_TASKBAR/SKIP_PAGER hints for testing.
    """
    if os.environ.get("SENTINEL_SYSTEM_MONITOR_EXPERIMENTAL_DESKTOP_HINTS") != "1":
        return
    if os.environ.get("XDG_SESSION_TYPE", "x11").lower() == "wayland":
        return
    try:
        root.update_idletasks()
        wid = int(root.winfo_id())
    except Exception:
        return
    xprop = shutil.which("xprop")
    if xprop:
        try:
            subprocess.run([xprop, "-id", str(wid), "-f", "_NET_WM_STATE", "32a", "-set", "_NET_WM_STATE", "_NET_WM_STATE_BELOW, _NET_WM_STATE_SKIP_TASKBAR, _NET_WM_STATE_SKIP_PAGER"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False, timeout=0.35)
        except Exception:
            pass
    wmctrl = shutil.which("wmctrl")
    if wmctrl:
        try:
            subprocess.run([wmctrl, "-i", "-r", str(wid), "-b", "add,below,skip_taskbar,skip_pager"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False, timeout=0.35)
        except Exception:
            pass


def aegis_envelope(command: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "app": APP_NAME,
        "version": VERSION,
        "program": 108,
        "interface": "sentinel-system-monitor-aegis",
        "command": command,
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "read_only": True,
        "local_only": True,
        "network_policy": NETWORK_POLICY,
        "aegis_policy": load_aegis_policy(),
        "payload": payload,
    }

def get_temperatures() -> Dict[str, Any]:
    readings: Dict[str, Any] = {"available": False, "summary_c": None, "sensors": {}}
    try:
        temps = psutil.sensors_temperatures(fahrenheit=False)  # type: ignore[attr-defined]
    except Exception:
        temps = {}
    if not temps:
        return readings
    readings["available"] = True
    max_current: Optional[float] = None
    sensors: Dict[str, List[Dict[str, Any]]] = {}
    for name, entries in temps.items():
        sensors[name] = []
        for item in entries:
            current = getattr(item, "current", None)
            high = getattr(item, "high", None)
            critical = getattr(item, "critical", None)
            label = getattr(item, "label", "") or name
            sensors[name].append({"label": label, "current_c": current, "high_c": high, "critical_c": critical})
            if current is not None:
                max_current = current if max_current is None else max(max_current, current)
    readings["summary_c"] = max_current
    readings["sensors"] = sensors
    return readings


def get_battery() -> Dict[str, Any]:
    try:
        batt = psutil.sensors_battery()  # type: ignore[attr-defined]
    except Exception:
        batt = None
    if batt is None:
        return {"available": False}
    return {
        "available": True,
        "percent": batt.percent,
        "plugged": batt.power_plugged,
        "seconds_left": batt.secsleft,
        "time_left": human_seconds(batt.secsleft) if batt.secsleft and batt.secsleft > 0 else "unknown",
    }


def disk_usage_for(path: str) -> Dict[str, Any]:
    try:
        usage = shutil.disk_usage(path)
        percent = (usage.used / usage.total * 100.0) if usage.total else 0.0
        return {
            "path": path,
            "total": usage.total,
            "used": usage.used,
            "free": usage.free,
            "percent": round(percent, 1),
            "total_h": human_bytes(usage.total),
            "used_h": human_bytes(usage.used),
            "free_h": human_bytes(usage.free),
        }
    except Exception as exc:
        return {"path": path, "error": str(exc)}


def get_system_status() -> Dict[str, Any]:
    ensure_runtime_config()
    cpu_percent = psutil.cpu_percent(interval=0.15)
    cpu_per_core = psutil.cpu_percent(interval=None, percpu=True)
    freq = None
    try:
        f = psutil.cpu_freq()
        if f:
            freq = {"current_mhz": f.current, "min_mhz": f.min, "max_mhz": f.max}
    except Exception:
        pass
    vm = psutil.virtual_memory()
    sw = psutil.swap_memory()
    boot_ts = psutil.boot_time()
    net = psutil.net_io_counters()
    if net is None:
        class _NetFallback:
            bytes_sent = 0
            bytes_recv = 0
            packets_sent = 0
            packets_recv = 0
        net = _NetFallback()
    disk_io = psutil.disk_io_counters()
    status = {
        "app": APP_NAME,
        "version": VERSION,
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "network_policy": NETWORK_POLICY,
        "settings": load_settings(),
        "aegis": {"enabled": load_aegis_policy().get("enabled", True), "read_only": True, "local_only": True},
        "host": {
            "hostname": socket.gethostname(),
            "system": platform.system(),
            "release": platform.release(),
            "version": platform.version(),
            "machine": platform.machine(),
            "processor": platform.processor(),
            "python": platform.python_version(),
            "boot_time": datetime.fromtimestamp(boot_ts).isoformat(timespec="seconds"),
            "uptime": human_seconds(time.time() - boot_ts),
        },
        "cpu": {
            "percent": cpu_percent,
            "per_core": cpu_per_core,
            "logical_cpus": psutil.cpu_count(logical=True),
            "physical_cpus": psutil.cpu_count(logical=False),
            "frequency": freq,
            "load_avg": os.getloadavg() if hasattr(os, "getloadavg") else None,
        },
        "memory": {
            "total": vm.total,
            "available": vm.available,
            "used": vm.used,
            "percent": vm.percent,
            "total_h": human_bytes(vm.total),
            "available_h": human_bytes(vm.available),
            "used_h": human_bytes(vm.used),
        },
        "swap": {
            "total": sw.total,
            "used": sw.used,
            "free": sw.free,
            "percent": sw.percent,
            "total_h": human_bytes(sw.total),
            "used_h": human_bytes(sw.used),
            "free_h": human_bytes(sw.free),
        },
        "disk": {
            "root": disk_usage_for("/"),
            "home": disk_usage_for(str(Path.home())),
            "io": {
                "read_bytes_h": human_bytes(disk_io.read_bytes) if disk_io else "unknown",
                "write_bytes_h": human_bytes(disk_io.write_bytes) if disk_io else "unknown",
            },
        },
        "network": {
            "bytes_sent": net.bytes_sent,
            "bytes_recv": net.bytes_recv,
            "sent_h": human_bytes(net.bytes_sent),
            "recv_h": human_bytes(net.bytes_recv),
            "packets_sent": net.packets_sent,
            "packets_recv": net.packets_recv,
        },
        "temperature": get_temperatures(),
        "battery": get_battery(),
    }
    return status


def process_rows(limit: int = 20, query: str = "") -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    query_l = (query or "").strip().lower()
    for proc in psutil.process_iter(["pid", "name", "username", "cpu_percent", "memory_percent", "status"]):
        try:
            info = proc.info
            row = {
                "pid": info.get("pid"),
                "name": info.get("name") or "",
                "user": info.get("username") or "",
                "cpu": float(info.get("cpu_percent") or 0.0),
                "memory": float(info.get("memory_percent") or 0.0),
                "status": info.get("status") or "",
            }
            if query_l:
                hay = f"{row['pid']} {row['name']} {row['user']} {row['status']}".lower()
                if query_l not in hay:
                    continue
            rows.append(row)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    rows.sort(key=lambda x: (x["cpu"], x["memory"]), reverse=True)
    return rows[:max(1, int(limit))]


def process_details(pid: int) -> Dict[str, Any]:
    proc = psutil.Process(int(pid))
    with proc.oneshot():
        try:
            mem = proc.memory_info()
        except Exception:
            mem = None
        try:
            cpu_times = proc.cpu_times()
            cpu_times_payload = {"user": cpu_times.user, "system": cpu_times.system}
        except Exception:
            cpu_times_payload = None
        try:
            create_time = datetime.fromtimestamp(proc.create_time()).isoformat(timespec="seconds")
        except Exception:
            create_time = "unknown"
        try:
            cmdline = proc.cmdline()
        except Exception:
            cmdline = []
        try:
            exe = proc.exe()
        except Exception:
            exe = ""
        try:
            username = proc.username()
        except Exception:
            username = "unknown"
        try:
            name = proc.name()
        except Exception:
            name = "unknown"
        try:
            status = proc.status()
        except Exception:
            status = "unknown"
        try:
            cpu_percent = proc.cpu_percent(interval=0.05)
        except Exception:
            cpu_percent = 0.0
        try:
            memory_percent = proc.memory_percent()
        except Exception:
            memory_percent = 0.0
        return {
            "pid": proc.pid,
            "name": name,
            "status": status,
            "username": username,
            "cpu_percent": cpu_percent,
            "memory_percent": memory_percent,
            "memory_rss_h": human_bytes(mem.rss) if mem else "unknown",
            "create_time": create_time,
            "cpu_times": cpu_times_payload,
            "cmdline": cmdline,
            "exe": exe,
        }


def process_action(pid: int, action: str) -> Dict[str, Any]:
    proc = psutil.Process(int(pid))
    if int(pid) == os.getpid():
        raise ValueError("Refusing to terminate Sentinel System Monitor itself")
    name = proc.name()
    if action == "terminate":
        proc.terminate()
    elif action == "kill":
        proc.kill()
    else:
        raise ValueError(f"Unknown process action: {action}")
    return {"pid": int(pid), "name": name, "action": action, "requested": True, "policy": "confirmation-required; never exposed through AEGIS"}


def metric_percentages(status: Dict[str, Any], rx_rate: float = 0.0, tx_rate: float = 0.0) -> Dict[str, Optional[float]]:
    temp = status.get("temperature", {}).get("summary_c")
    batt = status.get("battery", {})
    net_rate = max(0.0, float(rx_rate) + float(tx_rate))
    # Normalise network activity against 10 MiB/s for compact widget bar display only.
    net_pct = min(100.0, net_rate / (10 * 1024 * 1024) * 100.0)
    return {
        "cpu": float(status.get("cpu", {}).get("percent") or 0.0),
        "ram": float(status.get("memory", {}).get("percent") or 0.0),
        "swap": float(status.get("swap", {}).get("percent") or 0.0),
        "disk": float(status.get("disk", {}).get("root", {}).get("percent") or 0.0),
        "temp": None if temp is None else max(0.0, min(100.0, float(temp))),
        "battery": None if not batt.get("available") else float(batt.get("percent") or 0.0),
        "net": net_pct,
        "uptime": None,
    }


@dataclass
class CleanupItem:
    key: str
    label: str
    path: Path
    enabled_by_default: bool = False
    description: str = ""
    user_owned_only: bool = False
    older_than_seconds: Optional[int] = None


def cleanup_items() -> List[CleanupItem]:
    home = Path.home()
    tmp = Path(tempfile.gettempdir())
    return [
        CleanupItem("thumbs", "Thumbnail cache", home / ".cache" / "thumbnails", True, "Freedesktop thumbnail cache only."),
        CleanupItem("trash", "Trash files", home / ".local" / "share" / "Trash" / "files", False, "User trash contents. Disabled by default."),
        CleanupItem("pip", "Python pip cache", home / ".cache" / "pip", False, "Python package download/build cache."),
        CleanupItem("fontconfig", "Fontconfig cache", home / ".cache" / "fontconfig", False, "Fontconfig cache; safe to regenerate."),
        CleanupItem("sentinel_tmp", "Sentinel temporary files", tmp / f"sentinel-{os.getuid()}", True, "Sentinel-owned temporary workspace."),
        CleanupItem("user_tmp", "User-owned /tmp files older than 24h", tmp, False, "Only user-owned temporary files older than 24 hours.", True, 24 * 3600),
    ]


def dir_size(path: Path, user_owned_only: bool = False, older_than_seconds: Optional[int] = None) -> int:
    total = 0
    now = time.time()
    if not path.exists():
        return 0
    if path.is_file():
        try:
            st = path.stat()
            if user_owned_only and st.st_uid != os.getuid():
                return 0
            if older_than_seconds is not None and now - st.st_mtime < older_than_seconds:
                return 0
            return st.st_size
        except OSError:
            return 0
    for root, dirs, files in os.walk(path, topdown=True):
        rootp = Path(root)
        try:
            st_root = rootp.stat()
            if user_owned_only and st_root.st_uid != os.getuid():
                dirs[:] = []
                continue
        except OSError:
            continue
        for filename in files:
            fp = rootp / filename
            try:
                st = fp.stat()
                if user_owned_only and st.st_uid != os.getuid():
                    continue
                if older_than_seconds is not None and now - st.st_mtime < older_than_seconds:
                    continue
                total += st.st_size
            except OSError:
                continue
    return total


def cleanup_preview() -> Dict[str, Any]:
    rows = []
    total = 0
    default_total = 0
    for item in cleanup_items():
        size = dir_size(item.path, user_owned_only=item.user_owned_only, older_than_seconds=item.older_than_seconds)
        row = {
            "key": item.key,
            "label": item.label,
            "path": str(item.path),
            "size": size,
            "size_h": human_bytes(size),
            "enabled_by_default": item.enabled_by_default,
            "description": item.description,
            "user_owned_only": item.user_owned_only,
            "older_than_seconds": item.older_than_seconds,
        }
        rows.append(row)
        total += size
        if item.enabled_by_default:
            default_total += size
    return {
        "total": total,
        "total_h": human_bytes(total),
        "default_selected_total": default_total,
        "default_selected_total_h": human_bytes(default_total),
        "items": rows,
        "safety_policy": "preview-first; user-level cleanup only; no documents/downloads/media deletion; no silent root actions",
    }


def remove_path_contents(path: Path, user_owned_only: bool = False, older_than_seconds: Optional[int] = None) -> Tuple[int, int]:
    removed = 0
    freed = 0
    now = time.time()
    if not path.exists():
        return removed, freed
    if path.is_file():
        try:
            st = path.stat()
            if user_owned_only and st.st_uid != os.getuid():
                return removed, freed
            if older_than_seconds is not None and now - st.st_mtime < older_than_seconds:
                return removed, freed
            size = st.st_size
            path.unlink()
            return 1, size
        except OSError:
            return removed, freed
    for root, dirs, files in os.walk(path, topdown=False):
        rootp = Path(root)
        for filename in files:
            fp = rootp / filename
            try:
                st = fp.stat()
                if user_owned_only and st.st_uid != os.getuid():
                    continue
                if older_than_seconds is not None and now - st.st_mtime < older_than_seconds:
                    continue
                size = st.st_size
                fp.unlink()
                removed += 1
                freed += size
            except OSError:
                continue
        # Only remove child dirs for narrow paths, not /tmp root.
        if rootp != path:
            try:
                if not any(rootp.iterdir()):
                    rootp.rmdir()
            except OSError:
                pass
    return removed, freed


def cleanup_run(keys: Iterable[str]) -> Dict[str, Any]:
    selected = set(keys)
    rows = []
    total_freed = 0
    total_removed = 0
    for item in cleanup_items():
        if item.key not in selected:
            continue
        removed, freed = remove_path_contents(item.path, user_owned_only=item.user_owned_only, older_than_seconds=item.older_than_seconds)
        rows.append({"key": item.key, "label": item.label, "removed": removed, "freed": freed, "freed_h": human_bytes(freed)})
        total_removed += removed
        total_freed += freed
    payload = {
        "removed": total_removed,
        "freed": total_freed,
        "freed_h": human_bytes(total_freed),
        "items": rows,
        "safety_policy": "user-level cleanup only; no root/system destructive actions",
    }
    append_cleanup_log(payload)
    return payload


def plain_status_text(status: Dict[str, Any]) -> str:
    temp = status["temperature"]
    temp_s = "unknown"
    if temp.get("summary_c") is not None:
        temp_s = f"{temp['summary_c']:.1f}°C"
    batt = status["battery"]
    batt_s = "n/a"
    if batt.get("available"):
        batt_s = f"{batt.get('percent', 0):.0f}%" + (" plugged" if batt.get("plugged") else "")
    lines = [
        f"{APP_NAME} v{VERSION}",
        f"Host: {status['host']['hostname']} | {status['host']['system']} {status['host']['release']}",
        f"Uptime: {status['host']['uptime']}",
        f"CPU: {percent_bar(status['cpu']['percent'])}",
        f"RAM: {percent_bar(status['memory']['percent'])} {status['memory']['used_h']} / {status['memory']['total_h']}",
        f"Swap: {percent_bar(status['swap']['percent'])} {status['swap']['used_h']} / {status['swap']['total_h']}",
        f"Disk /: {percent_bar(status['disk']['root'].get('percent'))} free {status['disk']['root'].get('free_h')}",
        f"Disk home: {percent_bar(status['disk']['home'].get('percent'))} free {status['disk']['home'].get('free_h')}",
        f"Temp: {temp_s} | Battery: {batt_s}",
        f"Network totals: rx {status['network']['recv_h']} / tx {status['network']['sent_h']} (local counters only)",
        "Policy: local-only, no telemetry, no cloud sync, no outbound network actions",
    ]
    return "\n".join(lines)


def load_tk() -> Any:
    import tkinter as tk
    from tkinter import messagebox, ttk
    return tk, ttk, messagebox


class SentinelMonitorGUI:
    def __init__(self, widget: bool = False) -> None:
        self.tk, self.ttk, self.messagebox = load_tk()
        self.widget = widget
        self.root = self.tk.Tk()
        self.root.title(APP_NAME + (" Widget" if widget else ""))
        self.root.configure(bg=THEME["bg"])
        self.root.protocol("WM_DELETE_WINDOW", self.close)
        self.root.bind("<Control-q>", lambda _e: self.close())
        self.root.bind("<Control-Q>", lambda _e: self.close())
        self.root.bind("<F5>", lambda _e: self.refresh_all())
        self.style = self.ttk.Style(self.root)
        try:
            self.style.theme_use("clam")
        except Exception:
            pass
        self.configure_style()
        ensure_runtime_config()
        self.settings = load_settings()
        self.status: Dict[str, Any] = {}
        self.last_net: Optional[Tuple[float, int, int]] = None
        if widget:
            self.build_widget()
        else:
            self.build_main()
        self.refresh_all()
        self.root.after(1500, self.loop_refresh)

    def configure_style(self) -> None:
        s = self.style
        s.configure("TFrame", background=THEME["bg"])
        s.configure("Panel.TFrame", background=THEME["panel"])
        s.configure("TLabel", background=THEME["bg"], foreground=THEME["text"])
        s.configure("Muted.TLabel", background=THEME["bg"], foreground=THEME["muted"])
        s.configure("Gold.TLabel", background=THEME["bg"], foreground=THEME["gold"], font=("Sans", 13, "bold"))
        s.configure("Cyan.TLabel", background=THEME["bg"], foreground=THEME["cyan"])
        s.configure("TButton", background=THEME["panel2"], foreground=THEME["text"], padding=6)
        s.map("TButton", background=[("active", THEME["gold"]), ("pressed", THEME["cyan"])] )
        s.configure("TNotebook", background=THEME["bg"], borderwidth=0)
        s.configure("TNotebook.Tab", background=THEME["panel2"], foreground=THEME["text"], padding=(10, 5))
        s.map("TNotebook.Tab", background=[("selected", THEME["panel"])], foreground=[("selected", THEME["gold"])])
        s.configure("Treeview", background=THEME["panel"], fieldbackground=THEME["panel"], foreground=THEME["text"], borderwidth=0)
        s.configure("Treeview.Heading", background=THEME["panel2"], foreground=THEME["gold"], font=("Sans", 9, "bold"))
        s.configure("Horizontal.TProgressbar", troughcolor=THEME["panel2"], background=THEME["gold"], bordercolor=THEME["panel"])

    def build_header(self, parent: Any) -> None:
        frame = self.ttk.Frame(parent, style="Panel.TFrame")
        frame.pack(fill="x", padx=10, pady=(10, 5))
        title = self.ttk.Label(frame, text="Sentinel System Monitor", style="Gold.TLabel")
        title.pack(side="left", padx=10, pady=8)
        for badge in ("LOCAL ONLY", "NO TELEMETRY", "AEGIS READY", "LIVE BARS"):
            self.tk.Label(frame, text=badge, bg=THEME["panel2"], fg=THEME["cyan"], padx=8, pady=3).pack(side="left", padx=4)
        self.ttk.Button(frame, text="Refresh", command=self.refresh_all).pack(side="right", padx=10)
        if not self.widget:
            self.ttk.Button(frame, text="Open Widget", command=self.launch_widget).pack(side="right", padx=4)

    def build_main(self) -> None:
        self.root.geometry("1040x720")
        self.build_header(self.root)
        menubar = self.tk.Menu(self.root)
        filem = self.tk.Menu(menubar, tearoff=0)
        filem.add_command(label="Open Widget", command=self.launch_widget)
        filem.add_separator()
        filem.add_command(label="Exit", accelerator="Ctrl+Q", command=self.close)
        menubar.add_cascade(label="File", menu=filem)
        viewm = self.tk.Menu(menubar, tearoff=0)
        viewm.add_command(label="Refresh", accelerator="F5", command=self.refresh_all)
        menubar.add_cascade(label="View", menu=viewm)
        settingsm = self.tk.Menu(menubar, tearoff=0)
        settingsm.add_command(label="Widget Settings", command=self.show_widget_settings)
        settingsm.add_command(label="Alert Thresholds", command=self.show_alert_settings)
        menubar.add_cascade(label="Settings", menu=settingsm)
        helpm = self.tk.Menu(menubar, tearoff=0)
        helpm.add_command(label="About", command=lambda: self.messagebox.showinfo(APP_NAME, f"{APP_NAME} v{VERSION}\nProgram 108 — local system visibility and desktop widget."))
        menubar.add_cascade(label="Help", menu=helpm)
        self.root.config(menu=menubar)

        self.notebook = self.ttk.Notebook(self.root)
        self.notebook.pack(fill="both", expand=True, padx=10, pady=8)
        self.overview_tab = self.ttk.Frame(self.notebook)
        self.process_tab = self.ttk.Frame(self.notebook)
        self.storage_tab = self.ttk.Frame(self.notebook)
        self.network_tab = self.ttk.Frame(self.notebook)
        self.hardware_tab = self.ttk.Frame(self.notebook)
        self.alerts_tab = self.ttk.Frame(self.notebook)
        self.notebook.add(self.overview_tab, text="Overview")
        self.notebook.add(self.process_tab, text="Processes")
        self.notebook.add(self.storage_tab, text="Storage + Cleanup")
        self.notebook.add(self.network_tab, text="Network Counters")
        self.notebook.add(self.hardware_tab, text="Hardware")
        self.notebook.add(self.alerts_tab, text="Alerts")
        self.build_overview_tab()
        self.build_process_tab()
        self.build_storage_tab()
        self.build_network_tab()
        self.build_hardware_tab()
        self.build_alerts_tab()
        self.status_bar = self.tk.Label(self.root, text="Ready", anchor="w", bg=THEME["panel"], fg=THEME["muted"], padx=10)
        self.status_bar.pack(fill="x", side="bottom")

    def metric_row(self, parent: Any, label: str) -> Tuple[Any, Any]:
        frame = self.ttk.Frame(parent)
        frame.pack(fill="x", padx=14, pady=6)
        lbl = self.tk.Label(frame, text=label, width=16, anchor="w", bg=THEME["bg"], fg=THEME["muted"])
        lbl.pack(side="left")
        bar = self.ttk.Progressbar(frame, mode="determinate", maximum=100, length=300)
        bar.pack(side="left", padx=8)
        val = self.tk.Label(frame, text="", anchor="w", bg=THEME["bg"], fg=THEME["text"], width=36)
        val.pack(side="left", padx=8)
        return bar, val

    def build_overview_tab(self) -> None:
        self.cpu_bar, self.cpu_val = self.metric_row(self.overview_tab, "CPU")
        self.ram_bar, self.ram_val = self.metric_row(self.overview_tab, "Memory")
        self.swap_bar, self.swap_val = self.metric_row(self.overview_tab, "Swap")
        self.rootdisk_bar, self.rootdisk_val = self.metric_row(self.overview_tab, "Disk /")
        self.homedisk_bar, self.homedisk_val = self.metric_row(self.overview_tab, "Disk home")
        self.info_text = self.tk.Text(self.overview_tab, height=14, bg=THEME["panel"], fg=THEME["text"], insertbackground=THEME["cyan"], relief="flat")
        self.info_text.pack(fill="both", expand=True, padx=14, pady=10)

    def build_process_tab(self) -> None:
        top = self.ttk.Frame(self.process_tab)
        top.pack(fill="x", padx=10, pady=(10, 4))
        self.tk.Label(top, text="Search", bg=THEME["bg"], fg=THEME["muted"]).pack(side="left")
        self.proc_filter_var = self.tk.StringVar(value="")
        entry = self.tk.Entry(top, textvariable=self.proc_filter_var, bg=THEME["panel"], fg=THEME["text"], insertbackground=THEME["cyan"], relief="flat", width=28)
        entry.pack(side="left", padx=6)
        entry.bind("<Return>", lambda _e: self.refresh_processes())
        self.ttk.Button(top, text="Refresh", command=self.refresh_processes).pack(side="left", padx=5)
        self.ttk.Button(top, text="Details", command=self.show_selected_process_details).pack(side="left", padx=5)
        self.ttk.Button(top, text="Terminate", command=lambda: self.confirm_process_action("terminate")).pack(side="left", padx=5)
        self.ttk.Button(top, text="Force Kill", command=lambda: self.confirm_process_action("kill")).pack(side="left", padx=5)
        self.tk.Label(top, text="Process controls are confirmation-first and never exposed through AEGIS.", bg=THEME["bg"], fg=THEME["cyan"]).pack(side="left", padx=10)

        cols = ("pid", "name", "user", "cpu", "memory", "status")
        self.proc_tree = self.ttk.Treeview(self.process_tab, columns=cols, show="headings", height=15)
        headings = {"pid":"PID", "name":"Name", "user":"User", "cpu":"CPU %", "memory":"RAM %", "status":"Status"}
        widths = {"pid":70, "name":260, "user":180, "cpu":80, "memory":80, "status":100}
        self.process_sort_reverse = {c: False for c in cols}
        for c in cols:
            self.proc_tree.heading(c, text=headings[c], command=lambda col=c: self.sort_process_tree(col))
            self.proc_tree.column(c, width=widths[c], anchor="w")
        self.proc_tree.pack(fill="both", expand=True, padx=10, pady=(4, 6))
        self.proc_tree.bind("<<TreeviewSelect>>", lambda _e: self.update_process_detail_panel())
        self.process_detail_text = self.tk.Text(self.process_tab, height=8, bg=THEME["panel"], fg=THEME["text"], insertbackground=THEME["cyan"], relief="flat")
        self.process_detail_text.pack(fill="x", padx=10, pady=(0, 10))

    def build_storage_tab(self) -> None:
        top = self.ttk.Frame(self.storage_tab)
        top.pack(fill="x", padx=10, pady=8)
        self.ttk.Button(top, text="Preview Reclaimable", command=self.refresh_cleanup).pack(side="left", padx=5)
        self.ttk.Button(top, text="Clean Selected", command=self.clean_selected).pack(side="left", padx=5)
        self.cleanup_vars: Dict[str, Any] = {}
        self.cleanup_labels: Dict[str, Any] = {}
        self.cleanup_frame = self.ttk.Frame(self.storage_tab)
        self.cleanup_frame.pack(fill="x", padx=10, pady=8)
        for item in cleanup_items():
            row = self.ttk.Frame(self.cleanup_frame)
            row.pack(fill="x", pady=3)
            var = self.tk.BooleanVar(value=item.enabled_by_default)
            self.cleanup_vars[item.key] = var
            cb = self.tk.Checkbutton(row, text=item.label, variable=var, bg=THEME["bg"], fg=THEME["text"], selectcolor=THEME["panel"], activebackground=THEME["bg"], activeforeground=THEME["gold"])
            cb.pack(side="left")
            lbl = self.tk.Label(row, text=f"{item.path} — {item.description}", bg=THEME["bg"], fg=THEME["muted"])
            lbl.pack(side="left", padx=8)
            size_lbl = self.tk.Label(row, text="", bg=THEME["bg"], fg=THEME["cyan"])
            size_lbl.pack(side="right", padx=8)
            self.cleanup_labels[item.key] = size_lbl
        self.cleanup_total = self.tk.Label(self.storage_tab, text="", bg=THEME["bg"], fg=THEME["gold"], anchor="w")
        self.cleanup_total.pack(fill="x", padx=14, pady=8)
        note = "Cleanup is intentionally conservative: it only targets user-level caches/temp areas. It does not drop kernel memory caches or require root."
        self.tk.Label(self.storage_tab, text=note, bg=THEME["bg"], fg=THEME["muted"], wraplength=900, justify="left").pack(fill="x", padx=14, pady=8)

    def build_network_tab(self) -> None:
        self.net_text = self.tk.Text(self.network_tab, height=18, bg=THEME["panel"], fg=THEME["text"], relief="flat")
        self.net_text.pack(fill="both", expand=True, padx=12, pady=12)

    def build_hardware_tab(self) -> None:
        self.hw_text = self.tk.Text(self.hardware_tab, height=18, bg=THEME["panel"], fg=THEME["text"], relief="flat")
        self.hw_text.pack(fill="both", expand=True, padx=12, pady=12)

    def build_alerts_tab(self) -> None:
        top = self.ttk.Frame(self.alerts_tab)
        top.pack(fill="x", padx=10, pady=8)
        self.ttk.Button(top, text="Refresh Alerts", command=self.refresh_alerts).pack(side="left", padx=5)
        self.ttk.Button(top, text="Alert Thresholds", command=self.show_alert_settings).pack(side="left", padx=5)
        self.alerts_text = self.tk.Text(self.alerts_tab, height=18, bg=THEME["panel"], fg=THEME["text"], relief="flat")
        self.alerts_text.pack(fill="both", expand=True, padx=12, pady=12)

    def build_widget(self) -> None:
        self.settings = load_settings()
        profile = widget_profile(self.settings)
        pos = profile.get("position", {"x": 40, "y": 40})
        self.root.geometry(f"{profile['geometry']}+{int(pos.get('x', 40))}+{int(pos.get('y', 40))}")
        # Only explicit topmost mode uses override-redirect. Default desktop mode
        # remains window-manager managed so Marco/MATE can keep it below normal windows.
        try:
            self.root.overrideredirect(str(self.settings.get("widget_layer", "desktop")).lower() == "topmost")
        except Exception:
            pass
        try:
            self.root.attributes("-alpha", float(self.settings.get("widget_opacity", 0.50)))
        except Exception:
            pass
        self.apply_widget_window_policy()
        self.widget_x = 0
        self.widget_y = 0
        self.widget_frame = self.tk.Frame(self.root, bg=THEME["panel"], highlightbackground=THEME["gold"], highlightthickness=1)
        self.widget_frame.pack(fill="both", expand=True)
        self.bind_widget_controls(self.widget_frame)
        self.widget_title = self.tk.Label(
            self.widget_frame,
            text=f"SENTINEL MONITOR • {profile['mode'].upper()}",
            bg=THEME["panel"],
            fg=THEME["gold"],
            font=("Sans", 10, "bold"),
        )
        self.widget_title.pack(fill="x", padx=8, pady=(7, 2))
        self.bind_widget_controls(self.widget_title)
        self.widget_labels: Dict[str, Any] = {}
        self.widget_bars: Dict[str, Any] = {}
        self.widget_values: Dict[str, Any] = {}
        visible = self.settings.get("widget_visible_metrics", {})
        show_bars = bool(self.settings.get("widget_visual_bars", True))
        for key in WIDGET_MODES[profile["mode"]]["metrics"]:
            if not visible.get(key, True):
                continue
            if show_bars:
                row = self.tk.Frame(self.widget_frame, bg=THEME["panel"])
                row.pack(fill="x", padx=8, pady=1)
                self.bind_widget_controls(row)
                name = self.tk.Label(row, text=key.upper(), bg=THEME["panel"], fg=THEME["muted"], anchor="w", font=("Monospace", 8), width=5)
                name.pack(side="left")
                self.bind_widget_controls(name)
                canvas = self.tk.Canvas(row, height=10, width=108, bg=THEME["panel2"], highlightthickness=0, bd=0)
                canvas.pack(side="left", fill="x", expand=True, padx=5)
                self.bind_widget_controls(canvas)
                value = self.tk.Label(row, text="", bg=THEME["panel"], fg=THEME["text"], anchor="e", font=("Monospace", 8), width=14)
                value.pack(side="right")
                self.bind_widget_controls(value)
                self.widget_bars[key] = canvas
                self.widget_values[key] = value
            else:
                lbl = self.tk.Label(self.widget_frame, text="", bg=THEME["panel"], fg=THEME["text"], anchor="w", font=("Monospace", 9))
                lbl.pack(fill="x", padx=10, pady=1)
                self.bind_widget_controls(lbl)
                self.widget_labels[key] = lbl
        self.widget_footer = self.tk.Label(
            self.widget_frame,
            text=f"Desktop layer • Ctrl+Q close • {profile['opacity_percent']}% opacity",
            bg=THEME["panel"],
            fg=THEME["muted"],
            font=("Sans", 8),
        )
        self.widget_footer.pack(fill="x", padx=8, pady=(4, 6))
        self.bind_widget_controls(self.widget_footer)
        self.build_widget_menu()
        self.root.bind("<Escape>", lambda _e: self.close())
        self.root.bind("<ButtonRelease-1>", self.end_drag)
        try:
            self.root.deiconify()
            self.root.update_idletasks()
        except Exception:
            pass

    def apply_widget_window_policy(self) -> None:
        """Apply widget stacking policy.

        v1.0.1 uses a conservative, reliable window policy by default:
        managed Tk window, not topmost, no override-redirect, no forced
        splash/desktop window type. This avoids the MATE/Marco hang/disappear
        behavior seen with aggressive desktop-layer hints while still allowing
        normal windows to cover the widget.
        """
        layer = str(load_settings().get("widget_layer", "desktop")).lower()

        # Always start from a safe managed window.
        try:
            self.root.overrideredirect(False)
        except Exception:
            pass
        try:
            self.root.attributes("-topmost", layer == "topmost")
        except Exception:
            pass

        if layer == "topmost":
            try:
                self.root.attributes("-type", "utility")
                self.root.lift()
            except Exception:
                pass
        else:
            # Desktop/normal modes are both intentionally non-topmost.
            # Do not force -type desktop/splash here; those were the unstable
            # paths on the user's MATE/Marco setup.
            try:
                self.root.attributes("-type", "normal")
            except Exception:
                pass
            if layer == "desktop":
                apply_x11_below_hints(self.root)

        try:
            self.root.update_idletasks()
        except Exception:
            pass

    def bind_widget_controls(self, widget: Any) -> None:
        widget.bind("<ButtonPress-1>", self.start_drag)
        widget.bind("<B1-Motion>", self.do_drag)
        widget.bind("<ButtonRelease-1>", self.end_drag)
        widget.bind("<Button-3>", self.show_widget_menu)

    def build_widget_menu(self) -> None:
        self.widget_menu = self.tk.Menu(self.root, tearoff=0, bg=THEME["panel2"], fg=THEME["text"], activebackground=THEME["gold"], activeforeground=THEME["bg"])
        self.widget_menu.add_command(label="Refresh now", command=self.refresh_all)
        self.widget_menu.add_command(label="Open full monitor", command=self.open_full_monitor)
        self.widget_menu.add_command(label="Widget settings", command=self.show_widget_settings)
        self.widget_menu.add_separator()
        self.widget_menu.add_command(label="Toggle position lock", command=self.toggle_widget_lock)
        self.widget_menu.add_command(label="Reset widget position", command=self.reset_widget_position_gui)
        self.widget_menu.add_separator()
        self.widget_menu.add_command(label="Close widget", accelerator="Ctrl+Q", command=self.close)

    def show_widget_menu(self, event: Any) -> None:
        try:
            self.widget_menu.tk_popup(event.x_root, event.y_root)
        finally:
            try:
                self.widget_menu.grab_release()
            except Exception:
                pass

    def open_full_monitor(self) -> None:
        try:
            subprocess.Popen(["sentinel-system-monitor"], start_new_session=True)
        except Exception:
            try:
                subprocess.Popen([sys.executable, __file__, "gui"], start_new_session=True)
            except Exception as exc:
                self.messagebox.showerror(APP_NAME, f"Could not open full monitor: {exc}")

    def toggle_widget_lock(self) -> None:
        settings = load_settings()
        settings["widget_lock_position"] = not bool(settings.get("widget_lock_position", False))
        save_settings(settings)
        self.settings = load_settings()
        if hasattr(self, "widget_footer"):
            lock_note = "locked" if self.settings.get("widget_lock_position") else "movable"
            self.widget_footer.config(text=f"Right-click menu • Ctrl+Q close • position {lock_note}")

    def reset_widget_position_gui(self) -> None:
        self.settings = reset_widget_position()
        self.root.geometry("+40+40")

    def start_drag(self, event: Any) -> None:
        if self.widget and load_settings().get("widget_lock_position", False):
            return
        self.widget_x = event.x
        self.widget_y = event.y

    def do_drag(self, event: Any) -> None:
        if self.widget and load_settings().get("widget_lock_position", False):
            return
        x = self.root.winfo_pointerx() - self.widget_x
        y = self.root.winfo_pointery() - self.widget_y
        self.root.geometry(f"+{x}+{y}")

    def end_drag(self, _event: Any = None) -> None:
        if not self.widget or load_settings().get("widget_lock_position", False):
            return
        try:
            settings = load_settings()
            settings["widget_position"] = {"x": int(self.root.winfo_x()), "y": int(self.root.winfo_y())}
            save_settings(settings)
            self.settings = settings
        except Exception:
            pass


    def show_widget_settings(self) -> None:
        settings = load_settings()
        win = self.tk.Toplevel(self.root)
        win.title("Widget Settings")
        win.configure(bg=THEME["bg"])
        win.resizable(False, False)
        self.tk.Label(win, text="Widget Settings", bg=THEME["bg"], fg=THEME["gold"], font=("Sans", 12, "bold")).pack(anchor="w", padx=14, pady=(14, 4))
        self.tk.Label(win, text="Default opacity is 50%. Default layer is Desktop, so the widget sits on the desktop and does not cover open windows.", bg=THEME["bg"], fg=THEME["muted"], wraplength=460, justify="left").pack(anchor="w", padx=14, pady=(0, 8))

        var = self.tk.DoubleVar(value=float(settings.get("widget_opacity", 0.50)) * 100.0)
        value_label = self.tk.Label(win, text=f"Opacity: {var.get():.0f}%", bg=THEME["bg"], fg=THEME["cyan"])
        value_label.pack(anchor="w", padx=14)
        def update_label(_value: str) -> None:
            value_label.config(text=f"Opacity: {var.get():.0f}%")
        scale = self.tk.Scale(win, from_=20, to=100, orient="horizontal", variable=var, command=update_label, bg=THEME["bg"], fg=THEME["text"], troughcolor=THEME["panel2"], highlightthickness=0, length=400)
        scale.pack(fill="x", padx=14, pady=8)

        mode_frame = self.ttk.Frame(win)
        mode_frame.pack(fill="x", padx=14, pady=4)
        self.tk.Label(mode_frame, text="Mode", width=14, anchor="w", bg=THEME["bg"], fg=THEME["muted"]).pack(side="left")
        mode_var = self.tk.StringVar(value=str(settings.get("widget_mode", "normal")))
        mode_box = self.ttk.Combobox(mode_frame, values=list(WIDGET_MODES.keys()), textvariable=mode_var, state="readonly", width=14)
        mode_box.pack(side="left", padx=5)

        refresh_frame = self.ttk.Frame(win)
        refresh_frame.pack(fill="x", padx=14, pady=4)
        self.tk.Label(refresh_frame, text="Refresh ms", width=14, anchor="w", bg=THEME["bg"], fg=THEME["muted"]).pack(side="left")
        refresh_var = self.tk.IntVar(value=int(settings.get("widget_refresh_ms", 1500)))
        self.tk.Spinbox(refresh_frame, from_=750, to=10000, increment=250, textvariable=refresh_var, width=8, bg=THEME["panel"], fg=THEME["text"], insertbackground=THEME["cyan"]).pack(side="left", padx=5)

        layer_frame = self.ttk.Frame(win)
        layer_frame.pack(fill="x", padx=14, pady=4)
        self.tk.Label(layer_frame, text="Layer", width=14, anchor="w", bg=THEME["bg"], fg=THEME["muted"]).pack(side="left")
        layer_var = self.tk.StringVar(value=str(settings.get("widget_layer", "desktop")))
        layer_box = self.ttk.Combobox(layer_frame, values=list(WIDGET_LAYERS.keys()), textvariable=layer_var, state="readonly", width=14)
        layer_box.pack(side="left", padx=5)
        self.tk.Label(layer_frame, text="desktop = behind open windows", bg=THEME["bg"], fg=THEME["cyan"]).pack(side="left", padx=8)

        lock_var = self.tk.BooleanVar(value=bool(settings.get("widget_lock_position", False)))
        self.tk.Checkbutton(win, text="Lock widget position", variable=lock_var, bg=THEME["bg"], fg=THEME["text"], selectcolor=THEME["panel"], activebackground=THEME["bg"], activeforeground=THEME["gold"]).pack(anchor="w", padx=14, pady=2)
        bars_var = self.tk.BooleanVar(value=bool(settings.get("widget_visual_bars", True)))
        self.tk.Checkbutton(win, text="Show live coloured metric bars", variable=bars_var, bg=THEME["bg"], fg=THEME["text"], selectcolor=THEME["panel"], activebackground=THEME["bg"], activeforeground=THEME["gold"]).pack(anchor="w", padx=14, pady=2)

        metrics_frame = self.ttk.Frame(win)
        metrics_frame.pack(fill="x", padx=14, pady=(8, 2))
        self.tk.Label(metrics_frame, text="Visible metrics", bg=THEME["bg"], fg=THEME["gold"]).pack(anchor="w")
        metric_vars: Dict[str, Any] = {}
        visible = settings.get("widget_visible_metrics", {})
        for key in WIDGET_METRIC_ORDER:
            metric_vars[key] = self.tk.BooleanVar(value=bool(visible.get(key, True)))
            self.tk.Checkbutton(metrics_frame, text=key.upper(), variable=metric_vars[key], bg=THEME["bg"], fg=THEME["text"], selectcolor=THEME["panel"], activebackground=THEME["bg"], activeforeground=THEME["gold"]).pack(side="left", padx=4)

        buttons = self.ttk.Frame(win)
        buttons.pack(fill="x", padx=14, pady=(10, 14))
        def save_and_close() -> None:
            new_settings = load_settings()
            new_settings["widget_opacity"] = max(0.20, min(1.0, float(var.get()) / 100.0))
            new_settings["widget_mode"] = mode_var.get() if mode_var.get() in WIDGET_MODES else "normal"
            new_settings["widget_refresh_ms"] = int(refresh_var.get())
            new_settings["widget_layer"] = layer_var.get() if layer_var.get() in WIDGET_LAYERS else "desktop"
            new_settings["widget_layer_user_set"] = True
            new_settings["widget_always_on_top"] = (new_settings["widget_layer"] == "topmost")
            new_settings["widget_lock_position"] = bool(lock_var.get())
            new_settings["widget_visual_bars"] = bool(bars_var.get())
            new_settings["widget_visible_metrics"] = {k: bool(v.get()) for k, v in metric_vars.items()}
            save_settings(new_settings)
            self.settings = load_settings()
            if self.widget:
                try:
                    self.root.attributes("-alpha", float(self.settings.get("widget_opacity", 0.50)))
                    self.apply_widget_window_policy()
                except Exception:
                    pass
            self.messagebox.showinfo("Widget Settings", "Widget settings saved. Opacity/layer/lock apply now. Restart the widget to rebuild mode, visible metric rows, or live bar layout.")
            win.destroy()
        self.ttk.Button(buttons, text="Save", command=save_and_close).pack(side="right", padx=5)
        self.ttk.Button(buttons, text="Cancel", command=win.destroy).pack(side="right", padx=5)

    def launch_widget(self) -> None:
        """Open the desktop widget from the main application without using a separate widget launcher."""
        if self.widget:
            return
        log_path = error_log_path()
        try:
            ensure_private_dir(log_path.parent)
            log_handle = log_path.open("a", encoding="utf-8")
            try:
                log_handle.write(f"[{datetime.now().isoformat(timespec='seconds')}] Widget launch requested from main app.\n")
                log_handle.flush()
                subprocess.Popen(["sentinel-system-monitor-widget"], stdout=log_handle, stderr=log_handle, start_new_session=True)
            except FileNotFoundError:
                subprocess.Popen([sys.executable, __file__, "widget"], stdout=log_handle, stderr=log_handle, start_new_session=True)
            except Exception:
                log_handle.close()
                raise
            else:
                log_handle.close()
            self.status_bar.config(text="Widget launch requested • safe non-topmost mode • menu entry also available")
        except Exception as exc:
            log_widget_error(exc)
            self.messagebox.showerror(APP_NAME, f"Could not launch widget: {exc}\n\nError log: {log_path}")

    def show_alert_settings(self) -> None:
        settings = load_settings()
        thresholds = alert_thresholds(settings)
        win = self.tk.Toplevel(self.root)
        win.title("Alert Thresholds")
        win.configure(bg=THEME["bg"])
        win.resizable(False, False)
        self.tk.Label(win, text="Alert Thresholds", bg=THEME["bg"], fg=THEME["gold"], font=("Sans", 12, "bold")).pack(anchor="w", padx=14, pady=(14, 4))
        self.tk.Label(win, text="Local-only warning thresholds. AEGIS can read alert status but cannot perform destructive actions.", bg=THEME["bg"], fg=THEME["muted"], wraplength=460, justify="left").pack(anchor="w", padx=14, pady=(0, 8))
        fields = [
            ("cpu_percent", "CPU % high", 1, 100),
            ("memory_percent", "Memory % high", 1, 100),
            ("disk_percent", "Disk % high", 1, 100),
            ("temperature_c", "Temperature °C high", 1, 125),
            ("battery_percent", "Battery % low", 1, 100),
        ]
        vars: Dict[str, Any] = {}
        for key, label, low, high in fields:
            row = self.ttk.Frame(win)
            row.pack(fill="x", padx=14, pady=4)
            self.tk.Label(row, text=label, width=20, anchor="w", bg=THEME["bg"], fg=THEME["muted"]).pack(side="left")
            vars[key] = self.tk.IntVar(value=int(thresholds.get(key, DEFAULT_SETTINGS["alert_thresholds"][key])))
            self.tk.Spinbox(row, from_=low, to=high, increment=1, textvariable=vars[key], width=8, bg=THEME["panel"], fg=THEME["text"], insertbackground=THEME["cyan"]).pack(side="left", padx=5)
        notify_var = self.tk.BooleanVar(value=bool(settings.get("desktop_notifications", False)))
        self.tk.Checkbutton(win, text="Enable local desktop notifications when supported", variable=notify_var, bg=THEME["bg"], fg=THEME["text"], selectcolor=THEME["panel"], activebackground=THEME["bg"], activeforeground=THEME["gold"]).pack(anchor="w", padx=14, pady=(8, 2))
        buttons = self.ttk.Frame(win)
        buttons.pack(fill="x", padx=14, pady=(10, 14))
        def save_and_close() -> None:
            new_settings = load_settings()
            new_settings["alert_thresholds"] = {k: int(v.get()) for k, v in vars.items()}
            new_settings["desktop_notifications"] = bool(notify_var.get())
            save_settings(new_settings)
            self.settings = load_settings()
            self.refresh_alerts()
            self.messagebox.showinfo("Alert Thresholds", "Alert thresholds saved.")
            win.destroy()
        self.ttk.Button(buttons, text="Save", command=save_and_close).pack(side="right", padx=5)
        self.ttk.Button(buttons, text="Cancel", command=win.destroy).pack(side="right", padx=5)

    def refresh_alerts(self) -> None:
        if not hasattr(self, "alerts_text"):
            return
        summary = alert_summary(self.status or get_system_status())
        self.alerts_text.delete("1.0", "end")
        self.alerts_text.insert("end", "Sentinel Local Alerts\n")
        self.alerts_text.insert("end", "=====================\n\n")
        self.alerts_text.insert("end", f"Status: {'OK' if summary['ok'] else 'WARNINGS ACTIVE'}\n")
        self.alerts_text.insert("end", f"Count: {summary['count']}\n\n")
        self.alerts_text.insert("end", "Thresholds:\n")
        for k, v in summary.get("thresholds", {}).items():
            self.alerts_text.insert("end", f"- {k}: {v}\n")
        self.alerts_text.insert("end", "\nAlerts:\n")
        if not summary.get("alerts"):
            self.alerts_text.insert("end", "- No threshold alerts active.\n")
        else:
            for item in summary.get("alerts", []):
                self.alerts_text.insert("end", f"- {item['level'].upper()} {item['metric']}: {item['current']}{item['unit']} / threshold {item['threshold']}{item['unit']} — {item['message']}\n")
        self.alerts_text.insert("end", "\nPolicy: local-only threshold checks; AEGIS read-only; no network transport.\n")

    def refresh_all(self) -> None:
        try:
            self.status = get_system_status()
            if self.widget:
                self.refresh_widget()
            else:
                self.refresh_overview()
                self.refresh_processes()
                self.refresh_storage()
                self.refresh_network()
                self.refresh_hardware()
                self.refresh_alerts()
                summary = alert_summary(self.status)
                alert_note = "OK" if summary.get("ok") else f"{summary.get('count')} alert(s)"
                self.status_bar.config(text=f"Updated {self.status['timestamp']} • alerts: {alert_note} • local-only counters • Ctrl+Q exits")
        except Exception as exc:
            if self.widget:
                for lbl in getattr(self, "widget_labels", {}).values():
                    lbl.config(text=f"Error: {exc}")
            else:
                self.messagebox.showerror(APP_NAME, str(exc))

    def refresh_overview(self) -> None:
        s = self.status
        def setbar(bar: Any, val: Any, pct: float, text: str) -> None:
            bar["value"] = pct
            val.config(text=text)
        setbar(self.cpu_bar, self.cpu_val, s["cpu"]["percent"], f"{s['cpu']['percent']:.1f}% • {s['cpu']['logical_cpus']} logical CPUs")
        setbar(self.ram_bar, self.ram_val, s["memory"]["percent"], f"{s['memory']['used_h']} / {s['memory']['total_h']} used")
        setbar(self.swap_bar, self.swap_val, s["swap"]["percent"], f"{s['swap']['used_h']} / {s['swap']['total_h']} used")
        setbar(self.rootdisk_bar, self.rootdisk_val, s["disk"]["root"].get("percent", 0), f"{s['disk']['root'].get('free_h')} free of {s['disk']['root'].get('total_h')}")
        setbar(self.homedisk_bar, self.homedisk_val, s["disk"]["home"].get("percent", 0), f"{s['disk']['home'].get('free_h')} free of {s['disk']['home'].get('total_h')}")
        self.info_text.delete("1.0", "end")
        self.info_text.insert("end", plain_status_text(s))

    def selected_process_pid(self) -> Optional[int]:
        try:
            selected = self.proc_tree.selection()
            if not selected:
                return None
            values = self.proc_tree.item(selected[0], "values")
            return int(values[0])
        except Exception:
            return None

    def sort_process_tree(self, column: str) -> None:
        rows = []
        for iid in self.proc_tree.get_children(""):
            values = list(self.proc_tree.item(iid, "values"))
            rows.append((iid, values))
        idx = {"pid":0, "name":1, "user":2, "cpu":3, "memory":4, "status":5}.get(column, 0)
        reverse = not self.process_sort_reverse.get(column, False)
        self.process_sort_reverse[column] = reverse
        def key(row: Any) -> Any:
            value = row[1][idx]
            if column in ("pid", "cpu", "memory"):
                try:
                    return float(value)
                except Exception:
                    return 0.0
            return str(value).lower()
        for pos, (iid, _values) in enumerate(sorted(rows, key=key, reverse=reverse)):
            self.proc_tree.move(iid, "", pos)

    def update_process_detail_panel(self) -> None:
        if not hasattr(self, "process_detail_text"):
            return
        pid = self.selected_process_pid()
        self.process_detail_text.delete("1.0", "end")
        if pid is None:
            self.process_detail_text.insert("end", "Select a process to view details.")
            return
        try:
            info = process_details(pid)
            lines = [
                f"PID: {info.get('pid')}    Name: {info.get('name')}    Status: {info.get('status')}",
                f"User: {info.get('username')}    CPU: {info.get('cpu_percent'):.1f}%    RAM: {info.get('memory_percent'):.1f}%    RSS: {info.get('memory_rss_h')}",
                f"Started: {info.get('create_time')}",
                f"Executable: {info.get('exe')}",
                "Command: " + " ".join(info.get("cmdline") or []),
            ]
            self.process_detail_text.insert("end", "\n".join(lines))
        except Exception as exc:
            self.process_detail_text.insert("end", f"Could not read process details: {exc}")

    def show_selected_process_details(self) -> None:
        self.update_process_detail_panel()

    def confirm_process_action(self, action: str) -> None:
        pid = self.selected_process_pid()
        if pid is None:
            self.messagebox.showinfo("Processes", "Select a process first.")
            return
        verb = "terminate" if action == "terminate" else "force kill"
        if not self.messagebox.askyesno("Confirm process action", f"{verb.title()} process PID {pid}?\n\nThis can close applications or stop background tasks. This action is local only and requires this confirmation."):
            return
        try:
            result = process_action(pid, action)
            self.messagebox.showinfo("Process action requested", f"Requested {result['action']} for PID {result['pid']} ({result['name']}).")
            self.refresh_processes()
        except Exception as exc:
            self.messagebox.showerror("Process action failed", str(exc))

    def refresh_processes(self) -> None:
        for item in self.proc_tree.get_children():
            self.proc_tree.delete(item)
        query = getattr(self, "proc_filter_var", None).get() if hasattr(self, "proc_filter_var") else ""
        for row in process_rows(50, query=query):
            self.proc_tree.insert("", "end", values=(row["pid"], row["name"], row["user"], f"{row['cpu']:.1f}", f"{row['memory']:.1f}", row["status"]))
        self.update_process_detail_panel()

    def refresh_storage(self) -> None:
        self.refresh_cleanup()

    def refresh_cleanup(self) -> None:
        preview = cleanup_preview()
        for row in preview["items"]:
            lbl = self.cleanup_labels.get(row["key"])
            if lbl:
                lbl.config(text=row["size_h"])
        self.cleanup_total.config(text=f"Estimated reclaimable: {preview['total_h']} • Default selected: {preview.get('default_selected_total_h', '0 B')} • Policy: preview-first user cleanup")

    def clean_selected(self) -> None:
        keys = [k for k, v in self.cleanup_vars.items() if v.get()]
        if not keys:
            self.messagebox.showinfo("Cleanup", "No cleanup categories selected.")
            return
        if not self.messagebox.askyesno("Clean selected", "Clean selected user-level cache/temp categories?\n\nThis does not touch diary data, documents, or system files."):
            return
        result = cleanup_run(keys)
        self.messagebox.showinfo("Cleanup complete", f"Removed {result['removed']} files.\nFreed {result['freed_h']}.")
        self.refresh_cleanup()

    def refresh_network(self) -> None:
        s = self.status
        now = time.time()
        sent = int(s["network"]["bytes_sent"])
        recv = int(s["network"]["bytes_recv"])
        rx_rate = tx_rate = 0.0
        if self.last_net:
            last_t, last_sent, last_recv = self.last_net
            delta = max(0.001, now - last_t)
            tx_rate = (sent - last_sent) / delta
            rx_rate = (recv - last_recv) / delta
        self.last_net = (now, sent, recv)
        text = [
            "Network Counters (local OS counters only)",
            "No cloud sync, telemetry, accounts, or outbound network actions are used by this app.",
            "",
            f"Received total: {s['network']['recv_h']}",
            f"Sent total:     {s['network']['sent_h']}",
            f"Packets rx/tx:   {s['network']['packets_recv']} / {s['network']['packets_sent']}",
            f"Approx rx rate:  {human_bytes(rx_rate)}/s",
            f"Approx tx rate:  {human_bytes(tx_rate)}/s",
        ]
        self.net_text.delete("1.0", "end")
        self.net_text.insert("end", "\n".join(text))

    def refresh_hardware(self) -> None:
        s = self.status
        lines = [
            f"Host: {s['host']['hostname']}",
            f"System: {s['host']['system']} {s['host']['release']}",
            f"Kernel/Version: {s['host']['version']}",
            f"Machine: {s['host']['machine']}",
            f"Processor: {s['host']['processor']}",
            f"Boot: {s['host']['boot_time']}",
            f"Uptime: {s['host']['uptime']}",
            "",
            f"CPU logical/physical: {s['cpu']['logical_cpus']} / {s['cpu']['physical_cpus']}",
        ]
        freq = s["cpu"].get("frequency")
        if freq:
            lines.append(f"CPU frequency: {freq.get('current_mhz'):.0f} MHz current / {freq.get('max_mhz'):.0f} MHz max")
        load = s["cpu"].get("load_avg")
        if load:
            lines.append(f"Load average: {load[0]:.2f}, {load[1]:.2f}, {load[2]:.2f}")
        lines.append("")
        temp = s["temperature"]
        if temp.get("available"):
            lines.append(f"Temperature summary: {temp.get('summary_c'):.1f}°C")
            for sensor, entries in temp.get("sensors", {}).items():
                for entry in entries[:6]:
                    cur = entry.get("current_c")
                    lines.append(f"  {sensor}/{entry.get('label')}: {cur:.1f}°C" if cur is not None else f"  {sensor}/{entry.get('label')}: unknown")
        else:
            lines.append("Temperature sensors: unavailable")
        batt = s["battery"]
        if batt.get("available"):
            lines.append(f"Battery: {batt.get('percent'):.0f}% {'plugged' if batt.get('plugged') else 'on battery'}")
        else:
            lines.append("Battery: unavailable")
        self.hw_text.delete("1.0", "end")
        self.hw_text.insert("end", "\n".join(lines))

    def widget_bar_color(self, percent: Optional[float], key: str) -> str:
        if percent is None:
            return THEME["muted"]
        if key in ("net",):
            return THEME["cyan"]
        if key == "battery":
            return THEME["green"] if percent >= 35 else THEME["red"]
        if percent >= 85:
            return THEME["red"]
        if percent >= 65:
            return THEME["gold"]
        return THEME["green"]

    def draw_widget_bar(self, key: str, percent: Optional[float], text: str) -> None:
        canvas = getattr(self, "widget_bars", {}).get(key)
        value = getattr(self, "widget_values", {}).get(key)
        if not canvas or not value:
            return
        try:
            width = max(80, int(canvas.winfo_width() or 108))
            height = max(10, int(canvas.winfo_height() or 10))
            pct = 0.0 if percent is None else max(0.0, min(100.0, float(percent)))
            canvas.delete("all")
            canvas.create_rectangle(0, 0, width, height, fill=THEME["panel2"], outline="")
            fill_w = int(width * pct / 100.0)
            if fill_w > 0:
                canvas.create_rectangle(0, 0, fill_w, height, fill=self.widget_bar_color(percent, key), outline="")
            value.config(text=text)
        except Exception:
            pass

    def refresh_widget(self) -> None:
        s = self.status
        temp = s["temperature"].get("summary_c")
        temp_s = f"{temp:.1f}C" if temp is not None else "n/a"
        batt = s.get("battery", {})
        batt_s = "n/a"
        if batt.get("available"):
            batt_s = f"{float(batt.get('percent') or 0):.0f}%" + (" AC" if batt.get("plugged") else "")
        now = time.time()
        sent = int(s["network"]["bytes_sent"])
        recv = int(s["network"]["bytes_recv"])
        rx_rate = tx_rate = 0.0
        if self.last_net:
            last_t, last_sent, last_recv = self.last_net
            delta = max(0.001, now - last_t)
            tx_rate = (sent - last_sent) / delta
            rx_rate = (recv - last_recv) / delta
        self.last_net = (now, sent, recv)
        values = {
            "cpu": f"{s['cpu']['percent']:5.1f}%",
            "ram": f"{s['memory']['percent']:5.1f}%",
            "swap": f"{s['swap']['percent']:5.1f}%",
            "disk": f"{s['disk']['root'].get('percent', 0):5.1f}%",
            "temp": f"{temp_s}",
            "battery": f"{batt_s}",
            "net": f"↓{human_bytes(rx_rate)}/s ↑{human_bytes(tx_rate)}/s",
            "uptime": f"{s['host']['uptime']}",
        }
        line_values = {
            "cpu": f"CPU   {values['cpu']}",
            "ram": f"RAM   {values['ram']}  {s['memory']['used_h']}/{s['memory']['total_h']}",
            "swap": f"SWAP  {values['swap']}  {s['swap']['used_h']}/{s['swap']['total_h']}",
            "disk": f"DISK  {values['disk']}  / free {s['disk']['root'].get('free_h')}",
            "temp": f"TEMP  {values['temp']}",
            "battery": f"BATT  {values['battery']}",
            "net": f"NET   {values['net']}",
            "uptime": f"UP    {values['uptime']}",
        }
        percents = metric_percentages(s, rx_rate=rx_rate, tx_rate=tx_rate)
        for key, lbl in getattr(self, "widget_labels", {}).items():
            lbl.config(text=line_values.get(key, ""))
        for key in getattr(self, "widget_bars", {}):
            self.draw_widget_bar(key, percents.get(key), values.get(key, ""))
        if hasattr(self, "widget_footer"):
            alerts = alert_summary(s)
            if alerts.get("ok"):
                self.widget_footer.config(text=f"Desktop layer • Ctrl+Q close • {load_settings().get('widget_opacity', 0.50) * 100:.0f}% opacity")
            else:
                self.widget_footer.config(text=f"{alerts.get('count')} alert(s) active • right-click menu")

    def loop_refresh(self) -> None:
        self.refresh_all()
        delay = int(load_settings().get("widget_refresh_ms", 1500)) if self.widget else 3000
        self.root.after(delay, self.loop_refresh)

    def close(self) -> None:
        self.root.destroy()

    def run(self) -> int:
        self.root.mainloop()
        return 0


def cmd_status(args: argparse.Namespace) -> int:
    status = get_system_status()
    if args.json:
        print(json.dumps(status, indent=2, sort_keys=True))
    else:
        print(plain_status_text(status))
    return 0


def cmd_processes(args: argparse.Namespace) -> int:
    rows = process_rows(args.limit)
    if args.json:
        print(json.dumps(rows, indent=2, sort_keys=True))
    else:
        print(f"{'PID':>7}  {'CPU%':>6}  {'RAM%':>6}  NAME")
        for r in rows:
            print(f"{r['pid']:>7}  {r['cpu']:>6.1f}  {r['memory']:>6.1f}  {r['name']}")
    return 0


def cmd_cleanup_preview(args: argparse.Namespace) -> int:
    payload = cleanup_preview()
    if args.json:
        print(json.dumps(payload, indent=2, sort_keys=True))
    else:
        for row in payload["items"]:
            print(f"{row['key']:<12} {row['size_h']:>10}  {row['label']}  {row['path']}")
        print(f"Total: {payload['total_h']}")
    return 0


def cmd_cleanup_run(args: argparse.Namespace) -> int:
    keys = args.keys or []
    valid = {item.key for item in cleanup_items()}
    bad = [k for k in keys if k not in valid]
    if bad:
        print(f"Unknown cleanup keys: {', '.join(bad)}", file=sys.stderr)
        return 2
    if not keys:
        print("No cleanup keys selected. Use cleanup-preview to see available keys.", file=sys.stderr)
        return 2
    if not args.yes:
        print("Refusing to clean without --yes. This is a safety guard.", file=sys.stderr)
        return 2
    payload = cleanup_run(keys)
    print(json.dumps(payload, indent=2, sort_keys=True) if args.json else f"Removed {payload['removed']} files, freed {payload['freed_h']}")
    return 0




def cmd_process_details(args: argparse.Namespace) -> int:
    try:
        payload = process_details(args.pid)
    except Exception as exc:
        print(str(exc), file=sys.stderr)
        return 1
    print(json.dumps(payload, indent=2, sort_keys=True) if args.json else plain_process_details(payload))
    return 0


def plain_process_details(payload: Dict[str, Any]) -> str:
    lines = [
        f"PID: {payload.get('pid')}  Name: {payload.get('name')}  Status: {payload.get('status')}",
        f"User: {payload.get('username')}  CPU: {payload.get('cpu_percent'):.1f}%  RAM: {payload.get('memory_percent'):.1f}%  RSS: {payload.get('memory_rss_h')}",
        f"Started: {payload.get('create_time')}",
        f"Executable: {payload.get('exe')}",
        "Command: " + " ".join(payload.get("cmdline") or []),
    ]
    return "\n".join(lines)


def cmd_process_action(args: argparse.Namespace) -> int:
    if not args.yes:
        print("Refusing process action without --yes. This is a safety guard.", file=sys.stderr)
        return 2
    try:
        payload = process_action(args.pid, args.action)
    except Exception as exc:
        print(str(exc), file=sys.stderr)
        return 1
    print(json.dumps(payload, indent=2, sort_keys=True) if args.json else f"Requested {payload['action']} for PID {payload['pid']} ({payload['name']})")
    return 0


def cmd_set_widget_bars(args: argparse.Namespace) -> int:
    value = str(args.enabled).lower().strip()
    if value not in ("on", "off", "true", "false", "1", "0", "yes", "no"):
        print("Use on/off, true/false, yes/no, or 1/0", file=sys.stderr)
        return 2
    enabled = value in ("on", "true", "1", "yes")
    settings = load_settings()
    settings["widget_visual_bars"] = enabled
    save_settings(settings)
    payload = load_settings()
    print(json.dumps(payload, indent=2, sort_keys=True) if args.json else f"Widget live visual bars {'enabled' if enabled else 'disabled'}")
    return 0


def cmd_settings(args: argparse.Namespace) -> int:
    ensure_runtime_config()
    payload = load_settings()
    print(json.dumps(payload, indent=2, sort_keys=True) if args.json else f"Widget opacity: {payload.get('widget_opacity', 0.50) * 100:.0f}% | mode: {payload.get('widget_mode')} | bars: {payload.get('widget_visual_bars')} | lock position: {payload.get('widget_lock_position')}")
    return 0


def cmd_set_widget_opacity(args: argparse.Namespace) -> int:
    payload = set_widget_opacity(args.opacity / 100.0 if args.opacity > 1 else args.opacity)
    print(json.dumps(payload, indent=2, sort_keys=True) if args.json else f"Widget opacity set to {payload.get('widget_opacity', 0.50) * 100:.0f}%")
    return 0


def cmd_set_widget_mode(args: argparse.Namespace) -> int:
    try:
        payload = set_widget_mode(args.mode)
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        return 2
    print(json.dumps(payload, indent=2, sort_keys=True) if args.json else f"Widget mode set to {payload.get('widget_mode')}")
    return 0


def cmd_set_widget_layer(args: argparse.Namespace) -> int:
    layer = str(args.layer).lower().strip()
    if layer not in WIDGET_LAYERS:
        print(f"Unknown widget layer: {layer}. Valid layers: {', '.join(WIDGET_LAYERS)}", file=sys.stderr)
        return 2
    settings = load_settings()
    settings["widget_layer"] = layer
    settings["widget_layer_user_set"] = True
    settings["widget_always_on_top"] = (layer == "topmost")
    save_settings(settings)
    payload = load_settings()
    print(json.dumps(payload, indent=2, sort_keys=True) if args.json else f"Widget layer set to {payload.get('widget_layer')}")
    return 0


def cmd_set_widget_position(args: argparse.Namespace) -> int:
    payload = set_widget_position(args.x, args.y)
    print(json.dumps(payload, indent=2, sort_keys=True) if args.json else f"Widget position set to x={payload['widget_position']['x']}, y={payload['widget_position']['y']}")
    return 0


def cmd_reset_widget_position(args: argparse.Namespace) -> int:
    payload = reset_widget_position()
    print(json.dumps(payload, indent=2, sort_keys=True) if args.json else "Widget position reset to x=40, y=40")
    return 0


def cmd_widget_profile(args: argparse.Namespace) -> int:
    payload = widget_profile(load_settings())
    print(json.dumps(payload, indent=2, sort_keys=True) if args.json else f"Widget mode: {payload['mode']} | metrics: {', '.join(payload['active_metrics'])} | opacity: {payload['opacity_percent']}%")
    return 0


def cmd_alerts(args: argparse.Namespace) -> int:
    payload = alert_summary(get_system_status())
    if args.json:
        print(json.dumps(payload, indent=2, sort_keys=True))
    else:
        print("Alerts:", "OK" if payload.get("ok") else f"{payload.get('count')} active")
        for item in payload.get("alerts", []):
            print(f"- {item['metric']}: {item['current']}{item['unit']} / {item['threshold']}{item['unit']} — {item['message']}")
    return 0


def cmd_alert_thresholds(args: argparse.Namespace) -> int:
    payload = alert_thresholds(load_settings())
    print(json.dumps(payload, indent=2, sort_keys=True) if args.json else "\n".join(f"{k}: {v}" for k, v in payload.items()))
    return 0


def cmd_set_alert_threshold(args: argparse.Namespace) -> int:
    try:
        payload = set_alert_threshold(args.metric, args.value)
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        return 2
    thresholds = alert_thresholds(payload)
    print(json.dumps(thresholds, indent=2, sort_keys=True) if args.json else f"{args.metric} threshold set to {args.value}")
    return 0


def validate_aegis_policy_payload() -> Dict[str, Any]:
    policy = load_aegis_policy()
    required = {
        "enabled": True,
        "read_only": True,
        "local_only": True,
        "network_allowed": False,
        "control_actions_require_user_confirmation": True,
    }
    checks: Dict[str, Any] = {}
    ok = True
    for key, expected in required.items():
        actual = policy.get(key)
        passed = actual == expected
        checks[key] = {"expected": expected, "actual": actual, "ok": passed}
        ok = ok and passed
    allowed = set(policy.get("allowed_commands", []))
    forbidden = {"cleanup-run", "process-action", "terminate", "kill", "network", "remote"}
    checks["forbidden_actions_absent"] = {"ok": not bool(allowed & forbidden), "forbidden_present": sorted(allowed & forbidden)}
    ok = ok and checks["forbidden_actions_absent"]["ok"]
    return {
        "ok": ok,
        "contract_version": AEGIS_CONTRACT_VERSION,
        "policy_path": str(aegis_policy_path()),
        "policy": policy,
        "checks": checks,
    }


def aegis_contract_payload() -> Dict[str, Any]:
    return {
        "app": APP_NAME,
        "app_id": APP_ID,
        "version": VERSION,
        "contract_version": AEGIS_CONTRACT_VERSION,
        "interface": "sentinel-system-monitor-aegis",
        "transport": "local CLI only",
        "output": "JSON envelope",
        "read_only": True,
        "local_only": True,
        "network_allowed": False,
        "destructive_actions_available": False,
        "allowed_commands": load_aegis_policy().get("allowed_commands", []),
        "guarantees": [
            "No cloud sync",
            "No telemetry",
            "No external API calls",
            "No process termination through AEGIS",
            "No cleanup execution through AEGIS",
            "Metrics are read from local OS counters only",
        ],
    }


def aegis_health_summary_payload(status: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    status = status or get_system_status()
    alerts = alert_summary(status)
    cleanup = cleanup_preview()
    return {
        "health": "attention" if alerts.get("count", 0) else "ok",
        "alert_count": alerts.get("count", 0),
        "alerts": alerts.get("items", []),
        "cpu_percent": status.get("cpu", {}).get("percent"),
        "memory_percent": status.get("memory", {}).get("percent"),
        "disk_percent": status.get("disk", {}).get("percent"),
        "temperature_c": status.get("temperature", {}).get("current_c"),
        "battery_percent": status.get("battery", {}).get("percent"),
        "cleanup_reclaimable_h": cleanup.get("selected_total_h"),
        "widget": widget_profile(load_settings()),
    }


def aegis_recommendations_payload(status: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    status = status or get_system_status()
    alerts = alert_summary(status).get("items", [])
    cleanup = cleanup_preview()
    recommendations: List[Dict[str, Any]] = []
    for alert in alerts:
        key = alert.get("key")
        if key == "cpu":
            recommendations.append({"severity": "medium", "action": "inspect_processes", "message": "CPU usage is high. Review top processes before terminating anything."})
        elif key == "memory":
            recommendations.append({"severity": "medium", "action": "inspect_processes", "message": "Memory usage is high. Check high-RAM processes and close unneeded apps manually."})
        elif key == "disk":
            recommendations.append({"severity": "medium", "action": "cleanup_preview", "message": "Disk usage is high. Review safe cleanup categories before running cleanup."})
        elif key == "temperature":
            recommendations.append({"severity": "high", "action": "thermal_check", "message": "Temperature is high. Check airflow, fan load, and demanding processes."})
        elif key == "battery":
            recommendations.append({"severity": "low", "action": "plug_in", "message": "Battery is low. Connect power if available."})
    try:
        if int(cleanup.get("selected_total", 0)) > 0:
            recommendations.append({"severity": "low", "action": "cleanup_preview", "message": f"Safe cleanup preview found {cleanup.get('selected_total_h')} reclaimable. Cleanup must be confirmed by the user."})
    except Exception:
        pass
    if not recommendations:
        recommendations.append({"severity": "info", "action": "none", "message": "System metrics are currently within configured thresholds."})
    return {"count": len(recommendations), "items": recommendations, "read_only": True, "requires_user_confirmation_for_actions": True}


def cmd_aegis(args: argparse.Namespace) -> int:
    ensure_runtime_config()
    command = args.aegis_command or "status"
    status = get_system_status()
    if command in ("status", "metrics"):
        payload = status
    elif command == "contract":
        payload = aegis_contract_payload()
    elif command == "validate-policy":
        payload = validate_aegis_policy_payload()
    elif command == "health-summary":
        payload = aegis_health_summary_payload(status)
    elif command == "recommendations":
        payload = aegis_recommendations_payload(status)
    elif command == "hardware":
        payload = {"host": status.get("host"), "cpu": status.get("cpu"), "memory": status.get("memory"), "swap": status.get("swap"), "disk": status.get("disk"), "temperature": status.get("temperature"), "battery": status.get("battery")}
    elif command == "cleanup-preview":
        payload = cleanup_preview()
    elif command == "alerts":
        payload = alert_summary(status)
    elif command == "widget-settings":
        payload = load_settings()
    elif command == "widget-profile":
        payload = widget_profile(load_settings())
    elif command == "alert-thresholds":
        payload = alert_thresholds(load_settings())
    elif command == "processes":
        payload = {"items": process_rows(15), "read_only": True, "control_actions": "not available through AEGIS"}
    elif command == "process-details":
        if args.pid is None:
            print(json.dumps(aegis_envelope("error", {"error": "process-details requires --pid"}), indent=2, sort_keys=True), file=sys.stderr)
            return 2
        payload = process_details(args.pid)
    elif command == "permissions":
        payload = {"read_only": True, "local_only": True, "network_allowed": False, "policy_path": str(aegis_policy_path()), "settings_path": str(settings_path()), "allowed_commands": load_aegis_policy().get("allowed_commands", [])}
    elif command == "stable-lock":
        payload = stable_lock_report()
    else:
        print(json.dumps(aegis_envelope("error", {"error": f"unknown AEGIS command: {command}"}), indent=2, sort_keys=True), file=sys.stderr)
        return 2
    print(json.dumps(aegis_envelope(command, payload), indent=2, sort_keys=True))
    return 0

def repair_widget_defaults() -> Dict[str, Any]:
    settings = load_settings()
    settings["widget_layer"] = "desktop"
    settings["widget_layer_user_set"] = False
    settings["widget_always_on_top"] = False
    settings["widget_opacity"] = max(0.20, min(1.0, float(settings.get("widget_opacity", 0.50))))
    save_settings(settings)
    return widget_profile(load_settings())


def repair_launchers() -> Dict[str, Any]:
    result = {"attempted": True, "ok": True, "messages": []}
    helper = shutil.which("sentinel-system-monitor-install-launchers")
    if helper:
        try:
            proc = subprocess.run([helper], text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False, timeout=10)
            result["returncode"] = proc.returncode
            result["stdout"] = proc.stdout.strip()
            result["stderr"] = proc.stderr.strip()
            result["ok"] = proc.returncode == 0
        except Exception as exc:
            result["ok"] = False
            result["messages"].append(str(exc))
    else:
        result["ok"] = False
        result["messages"].append("sentinel-system-monitor-install-launchers not found")
    desktop_dir = Path.home() / "Desktop"
    stale_widget = desktop_dir / "Sentinel System Monitor Widget.desktop"
    try:
        if stale_widget.exists():
            stale_widget.unlink()
            result["messages"].append("Removed stale widget desktop launcher")
    except Exception as exc:
        result["ok"] = False
        result["messages"].append(f"Could not remove stale widget desktop launcher: {exc}")
    return result


def cmd_repair(args: argparse.Namespace) -> int:
    ensure_runtime_config()
    payload: Dict[str, Any] = {"app": APP_NAME, "version": VERSION, "ok": True, "repairs": {}}
    if args.widget_defaults or args.all:
        payload["repairs"]["widget_defaults"] = repair_widget_defaults()
    if args.launchers or args.all:
        payload["repairs"]["launchers"] = repair_launchers()
        if not payload["repairs"]["launchers"].get("ok", False):
            payload["ok"] = False
    if args.reset_policy or args.all:
        write_private_json(aegis_policy_path(), DEFAULT_AEGIS_POLICY)
        payload["repairs"]["aegis_policy"] = validate_aegis_policy_payload()
    if not payload["repairs"]:
        payload["repairs"]["nothing_selected"] = "Use --all, --widget-defaults, --launchers, or --reset-policy."
    if args.json:
        print(json.dumps(payload, indent=2, sort_keys=True))
    else:
        print(f"{APP_NAME} repair v{VERSION}")
        for key, value in payload["repairs"].items():
            print(f"- {key}: {value}")
        print("Result:", "OK" if payload["ok"] else "WARN/FAIL")
    return 0 if payload["ok"] else 1


def cmd_doctor(args: argparse.Namespace) -> int:
    checks: Dict[str, Any] = {"app": APP_NAME, "version": VERSION, "ok": True, "checks": {}}
    checks["checks"]["psutil"] = True
    checks["checks"]["python"] = platform.python_version()
    ensure_runtime_config()
    checks["checks"]["network_policy"] = NETWORK_POLICY
    checks["checks"]["settings_path"] = str(settings_path())
    checks["checks"]["widget_opacity"] = load_settings().get("widget_opacity")
    checks["checks"]["widget_profile"] = widget_profile(load_settings())
    checks["checks"]["widget_visual_bars"] = bool(load_settings().get("widget_visual_bars", True))
    checks["checks"]["process_manager"] = {"search": True, "details": True, "terminate_confirmed": True, "kill_confirmed": True, "aegis_read_only": True}
    checks["checks"]["alert_thresholds"] = alert_thresholds(load_settings())
    checks["checks"]["widget_launch_policy"] = "main application button and widget menu entry; no widget desktop shortcut"
    checks["checks"]["widget_error_log"] = str(error_log_path())
    checks["checks"]["aegis_policy"] = load_aegis_policy()
    checks["checks"]["aegis_contract"] = aegis_contract_payload()
    checks["checks"]["aegis_policy_validation"] = validate_aegis_policy_payload()
    checks["checks"]["transparent_icon_assets"] = True
    checks["checks"]["widget_desktop_default"] = {"layer": load_settings().get("widget_layer"), "always_on_top": load_settings().get("widget_always_on_top"), "coverable_by_windows": load_settings().get("widget_layer") == "desktop" and not load_settings().get("widget_always_on_top")}
    checks["checks"]["repair_available"] = True
    checks["checks"]["commands"] = {
        "monitor": shutil.which("sentinel-system-monitor"),
        "widget": shutil.which("sentinel-system-monitor-widget"),
        "cli": shutil.which("sentinel-system-monitor-cli"),
        "aegis": shutil.which("sentinel-system-monitor-aegis"),
    }
    desktop = Path.home() / "Desktop" / "Sentinel System Monitor.desktop"
    checks["checks"]["desktop_launcher"] = str(desktop) if desktop.exists() else None
    checks["checks"]["home_desktop_mode"] = oct(safe_stat_mode(desktop) or 0) if desktop.exists() else None
    try:
        status = get_system_status()
        checks["checks"]["status_read"] = True
        checks["checks"]["hostname"] = status["host"]["hostname"]
    except Exception as exc:
        checks["ok"] = False
        checks["checks"]["status_read"] = str(exc)
    if args.json:
        print(json.dumps(checks, indent=2, sort_keys=True))
    else:
        print(f"{APP_NAME} doctor v{VERSION}")
        for key, value in checks["checks"].items():
            print(f"- {key}: {value}")
        print("Result:", "OK" if checks["ok"] else "FAIL")
    return 0 if checks["ok"] else 1


def release_candidate_report() -> Dict[str, Any]:
    settings = load_settings()
    widget = widget_profile(settings)
    aegis_validation = validate_aegis_policy_payload()
    try:
        status = get_system_status()
        status_ok = True
        status_error = None
    except Exception as exc:
        status = {}
        status_ok = False
        status_error = str(exc)
    try:
        cleanup = cleanup_preview()
        cleanup_ok = True
        cleanup_error = None
    except Exception as exc:
        cleanup = {}
        cleanup_ok = False
        cleanup_error = str(exc)
    desktop_entry = Path("/usr/share/applications/sentinel-system-monitor.desktop")
    widget_entry = Path("/usr/share/applications/sentinel-system-monitor-widget.desktop")
    icon_asset = Path("/usr/share/icons/hicolor/512x512/apps/sentinel-system-monitor.png")
    package_share = Path(__file__).resolve().parents[1] if len(Path(__file__).resolve().parents) > 1 else Path("/usr/share")
    package_icon_asset = package_share / "icons" / "hicolor" / "512x512" / "apps" / "sentinel-system-monitor.png"
    report: Dict[str, Any] = {
        "app": APP_NAME,
        "app_id": APP_ID,
        "version": VERSION,
        "phase": "v0.9.0 Release Candidate",
        "stable_target": "v1.0.0",
        "ok": True,
        "checks": {
            "status_read": {"ok": status_ok, "error": status_error},
            "widget_defaults": {
                "ok": widget.get("layer") == "desktop" and not bool(widget.get("always_on_top")) and int(widget.get("opacity_percent", 0)) == 50,
                "layer": widget.get("layer"),
                "always_on_top": widget.get("always_on_top"),
                "opacity_percent": widget.get("opacity_percent"),
                "coverable_by_windows": widget.get("coverable_by_windows"),
            },
            "widget_visual_bars": {"ok": bool(settings.get("widget_visual_bars", True)), "enabled": bool(settings.get("widget_visual_bars", True))},
            "launchers": {
                "main_menu_packaged": desktop_entry.exists(),
                "widget_menu_packaged": widget_entry.exists(),
                "main_desktop_created_by_helper": True,
                "widget_desktop_created_by_helper": False,
            },
            "icon_asset": {"ok": icon_asset.exists() or package_icon_asset.exists(), "path": str(icon_asset), "packaged_path": str(package_icon_asset)},
            "aegis_policy": {"ok": bool(aegis_validation.get("ok")), "contract_version": aegis_validation.get("contract_version")},
            "cleanup_preview": {"ok": cleanup_ok, "error": cleanup_error, "selected_total_h": cleanup.get("selected_total_h")},
            "alerts": alert_summary(status) if status_ok else {"ok": False, "error": "status unavailable"},
            "network_policy": NETWORK_POLICY,
            "doctor_available": True,
            "repair_available": True,
        },
        "notes": [
            "AEGIS integration is read-only and local-only.",
            "Widget is intended to be desktop-layer, coverable by normal windows, and 50% translucent by default.",
            "Cleanup and process-control actions remain user-confirmed only; AEGIS cannot execute them.",
        ],
    }
    for item in report["checks"].values():
        if isinstance(item, dict) and "ok" in item and not item["ok"]:
            report["ok"] = False
    return report


def cmd_release_candidate(args: argparse.Namespace) -> int:
    payload = release_candidate_report()
    if args.json:
        print(json.dumps(payload, indent=2, sort_keys=True))
    else:
        print(f"{APP_NAME} release candidate v{VERSION}")
        print(f"Phase: {payload['phase']}")
        for key, value in payload.get("checks", {}).items():
            ok = value.get("ok") if isinstance(value, dict) else None
            if ok is None:
                print(f"- {key}: {value}")
            else:
                print(f"- {key}: {'OK' if ok else 'CHECK'}")
        print("Result:", "OK" if payload.get("ok") else "CHECK")
    return 0 if payload.get("ok") else 1


def stable_lock_report() -> Dict[str, Any]:
    rc = release_candidate_report()
    stable_checks = dict(rc.get("checks", {}))
    stable_checks["stable_lock"] = {
        "ok": True,
        "version": VERSION,
        "phase": "v1.0.1 Stable Lock Hotfix",
        "package": "sentinel-system-monitor",
        "hotfix": "widget launch stability",
    }
    stable_checks["aegis_stable_contract"] = {
        "ok": True,
        "contract_version": AEGIS_CONTRACT_VERSION,
        "read_only": True,
        "local_only": True,
        "network_allowed": False,
    }
    stable_checks["widget_policy"] = {
        "ok": stable_checks.get("widget_defaults", {}).get("ok", False),
        "default_opacity_percent": 50,
        "default_layer": "desktop",
        "coverable_by_windows": stable_checks.get("widget_defaults", {}).get("coverable_by_windows"),
    }
    payload: Dict[str, Any] = {
        "app": APP_NAME,
        "app_id": APP_ID,
        "version": VERSION,
        "phase": "v1.0.1 Stable Lock Hotfix",
        "stable_lock": True,
        "ok": bool(rc.get("ok")) and all(
            bool(v.get("ok", True)) for v in stable_checks.values() if isinstance(v, dict)
        ),
        "checks": stable_checks,
        "locked_capabilities": [
            "main GUI system monitor",
            "desktop widget opened from menu or main app",
            "50 percent translucent widget default",
            "safe managed widget policy, not topmost by default",
            "live coloured widget metric bars",
            "CPU/RAM/swap/disk/temperature/battery/network/uptime metrics",
            "process viewer and confirmed user process actions",
            "preview-first cleanup with local cleanup log",
            "local alert thresholds",
            "AEGIS read-only local JSON integration",
            "doctor and repair tools",
            "transparent supplied launcher/menu icon",
            "local-only/no-cloud/no-telemetry/no-outbound-network policy",
        ],
        "notes": [
            "This v1 stable lock is local-first and does not add network, cloud, telemetry, or remote account features.",
            "AEGIS can inspect monitor data through the approved helper but cannot kill processes or run cleanup.",
            "Widget behavior can still vary by window manager; v1.0.1 defaults to a safe managed non-topmost widget so it opens reliably and remains coverable by normal windows.",
        ],
    }
    return payload


def cmd_stable_lock(args: argparse.Namespace) -> int:
    payload = stable_lock_report()
    if args.json:
        print(json.dumps(payload, indent=2, sort_keys=True))
    else:
        print(f"{APP_NAME} stable lock v{VERSION}")
        print(f"Phase: {payload['phase']}")
        print("Result:", "OK" if payload.get("ok") else "CHECK")
        for item in payload.get("locked_capabilities", []):
            print(f"- {item}")
    return 0 if payload.get("ok") else 1


def cmd_gui(args: argparse.Namespace) -> int:
    return SentinelMonitorGUI(widget=False).run()


def cmd_widget(args: argparse.Namespace) -> int:
    try:
        return SentinelMonitorGUI(widget=True).run()
    except Exception as exc:
        log_widget_error(exc)
        print(f"Sentinel System Monitor widget failed: {exc}", file=sys.stderr)
        print(f"Error log: {error_log_path()}", file=sys.stderr)
        return 1


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=f"{APP_NAME} v{VERSION}")
    sub = p.add_subparsers(dest="cmd")
    g = sub.add_parser("gui", help="Open full GUI")
    g.set_defaults(func=cmd_gui)
    w = sub.add_parser("widget", help="Open compact desktop widget")
    w.set_defaults(func=cmd_widget)
    s = sub.add_parser("status", help="Print system status")
    s.add_argument("--json", action="store_true")
    s.set_defaults(func=cmd_status)
    pr = sub.add_parser("processes", help="Show top processes")
    pr.add_argument("--limit", type=int, default=20)
    pr.add_argument("--query", default="", help="Filter by PID/name/user/status")
    pr.add_argument("--json", action="store_true")
    pr.set_defaults(func=cmd_processes)
    pd = sub.add_parser("process-details", help="Show details for one process")
    pd.add_argument("pid", type=int)
    pd.add_argument("--json", action="store_true")
    pd.set_defaults(func=cmd_process_details)
    pa = sub.add_parser("process-action", help="Request a local process action with --yes safety guard")
    pa.add_argument("action", choices=["terminate", "kill"])
    pa.add_argument("pid", type=int)
    pa.add_argument("--yes", action="store_true")
    pa.add_argument("--json", action="store_true")
    pa.set_defaults(func=cmd_process_action)
    cp = sub.add_parser("cleanup-preview", help="Preview user-level reclaimable cache/temp space")
    cp.add_argument("--json", action="store_true")
    cp.set_defaults(func=cmd_cleanup_preview)
    cr = sub.add_parser("cleanup-run", help="Clean selected safe user-level cache/temp categories")
    cr.add_argument("keys", nargs="*")
    cr.add_argument("--yes", action="store_true")
    cr.add_argument("--json", action="store_true")
    cr.set_defaults(func=cmd_cleanup_run)
    st = sub.add_parser("settings", help="Show Sentinel System Monitor settings")
    st.add_argument("--json", action="store_true")
    st.set_defaults(func=cmd_settings)
    swo = sub.add_parser("set-widget-opacity", help="Set widget opacity/transparency. Accepts 20-100 percent or 0.20-1.0.")
    swo.add_argument("opacity", type=float)
    swo.add_argument("--json", action="store_true")
    swo.set_defaults(func=cmd_set_widget_opacity)
    swm = sub.add_parser("set-widget-mode", help="Set widget mode: compact, normal, or expanded")
    swm.add_argument("mode", choices=list(WIDGET_MODES.keys()))
    swm.add_argument("--json", action="store_true")
    swm.set_defaults(func=cmd_set_widget_mode)
    swl = sub.add_parser("set-widget-layer", help="Set widget layer: desktop, normal, or topmost")
    swl.add_argument("layer", choices=list(WIDGET_LAYERS.keys()))
    swl.add_argument("--json", action="store_true")
    swl.set_defaults(func=cmd_set_widget_layer)
    swb = sub.add_parser("set-widget-bars", help="Enable or disable live coloured widget metric bars")
    swb.add_argument("enabled")
    swb.add_argument("--json", action="store_true")
    swb.set_defaults(func=cmd_set_widget_bars)
    swp = sub.add_parser("set-widget-position", help="Set widget screen position")
    swp.add_argument("x", type=int)
    swp.add_argument("y", type=int)
    swp.add_argument("--json", action="store_true")
    swp.set_defaults(func=cmd_set_widget_position)
    rwp = sub.add_parser("reset-widget-position", help="Reset widget screen position")
    rwp.add_argument("--json", action="store_true")
    rwp.set_defaults(func=cmd_reset_widget_position)
    wprof = sub.add_parser("widget-profile", help="Show effective widget profile")
    wprof.add_argument("--json", action="store_true")
    wprof.set_defaults(func=cmd_widget_profile)
    al = sub.add_parser("alerts", help="Show local threshold alerts")
    al.add_argument("--json", action="store_true")
    al.set_defaults(func=cmd_alerts)
    ath = sub.add_parser("alert-thresholds", help="Show configured alert thresholds")
    ath.add_argument("--json", action="store_true")
    ath.set_defaults(func=cmd_alert_thresholds)
    sath = sub.add_parser("set-alert-threshold", help="Set an alert threshold: cpu, memory, disk, temperature, or battery")
    sath.add_argument("metric")
    sath.add_argument("value", type=int)
    sath.add_argument("--json", action="store_true")
    sath.set_defaults(func=cmd_set_alert_threshold)
    ag = sub.add_parser("aegis", help="AEGIS local read-only JSON interface")
    ag.add_argument("aegis_command", nargs="?", default="status", choices=["status", "metrics", "hardware", "cleanup-preview", "alerts", "widget-settings", "widget-profile", "alert-thresholds", "processes", "process-details", "permissions", "validate-policy", "contract", "health-summary", "recommendations", "stable-lock"])
    ag.add_argument("--pid", type=int, help="PID for process-details; read-only")
    ag.set_defaults(func=cmd_aegis)
    d = sub.add_parser("doctor", help="Run diagnostics")
    d.add_argument("--json", action="store_true")
    d.set_defaults(func=cmd_doctor)
    rp = sub.add_parser("repair", help="Repair launchers, widget defaults, and local policies")
    rp.add_argument("--all", action="store_true")
    rp.add_argument("--launchers", action="store_true")
    rp.add_argument("--widget-defaults", action="store_true")
    rp.add_argument("--reset-policy", action="store_true")
    rp.add_argument("--json", action="store_true")
    rp.set_defaults(func=cmd_repair)
    rc = sub.add_parser("release-candidate", help="Run release-candidate readiness report")
    rc.add_argument("--json", action="store_true")
    rc.set_defaults(func=cmd_release_candidate)
    sl = sub.add_parser("stable-lock", help="Run v1.0.1 stable-lock report")
    sl.add_argument("--json", action="store_true")
    sl.set_defaults(func=cmd_stable_lock)
    return p


def main(argv: Optional[List[str]] = None) -> int:
    ensure_runtime_config()
    parser = build_parser()
    args = parser.parse_args(argv)
    if not args.cmd:
        args = parser.parse_args(["gui"])
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
