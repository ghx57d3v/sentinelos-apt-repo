# Sentinel Calendar v1.0.2

**Program 104 — Sentinel Calendar**  
Stable Lock

Locks Sentinel Calendar as a daily-use local calendar with the full v0.8.1-v0.9.0 backfill plus v0.8.0 suite hooks.

## Major capabilities

- Local-only JSON calendar storage with automatic backups
- DD/MM/YYYY default date input/output with selectable date formats
- Australia public holidays enabled by default
- Blank suffix for Australia-wide public holidays and [STATE] suffixes for regional holidays
- Month view, week view, 30-day agenda, Today, Upcoming, Jump Date
- Search across events, recurrence instances, notes, categories, locations, dates, and holidays
- Category/type filters plus user-event/holiday visibility toggles
- Themed SentinelOS/AEGIS dark-gold dropdown menus
- Ctrl+Q close hotkey
- Desktop/menu launcher and supplied Sentinel Calendar icon
- AEGIS/Sentinel Suite JSON status, Tasks feed, Diary feed, suite hook export
- Reminder notification daemon with notify-send fallback, dismiss, and snooze state
- Recurrence exception controls: skip, restore, and split one occurrence from a series
- Settings lock: first day of week, default category/reminder, startup view, confirm delete, backup retention, notification toggles
- ICS hardening: preview, duplicate detection, folded-line parsing, backup before import, source UID handling, date-range export
- Release-candidate self-test and expanded doctor checks

## Install

```bash
unzip sentinel_calendar_v1_0_2_redteam_security_cleanup_hotfix.zip
cd sentinel_calendar_v1_0_2_redteam_security_cleanup_hotfix
./install.sh
```

Or install the Debian package directly:

```bash
sudo apt install ./sentinel-calendar_1.0.2-1_all.deb
sentinel-calendar-user-setup
```

## Common commands

```bash
sentinel-calendar
sentinel-calendar --today
sentinel-calendar --week
sentinel-calendar --agenda 30
sentinel-calendar --search "service"
sentinel-calendar --check-reminders 120
sentinel-calendar --notify-reminders 10
sentinel-calendar-reminder-daemon
sentinel-calendar-autostart-reminders
sentinel-calendar --skip-occurrence EVENT_ID DD/MM/YYYY
sentinel-calendar --restore-occurrence EVENT_ID DD/MM/YYYY
sentinel-calendar --edit-occurrence EVENT_ID DD/MM/YYYY --new-title "Changed appointment"
sentinel-calendar --settings-json
sentinel-calendar --set-setting first_day_of_week=Sunday
sentinel-calendar --import-ics-preview calendar.ics
sentinel-calendar --import-ics calendar.ics
sentinel-calendar --export-ics calendar.ics
sentinel-calendar --export-ics-range 01/01/2026 31/12/2026 calendar_2026.ics
sentinel-calendar --suite-status
sentinel-calendar --export-suite-hooks
sentinel-calendar --self-test
sentinel-calendar-doctor
```

## Data policy

Sentinel Calendar is local-first and stores data under the user profile. It does not require network access.


## v1.0.1 Missing Update Closure

This patch explicitly closes the missing v0.7.0 update layer inside the final stable build. The application now exposes the version/update ledger and adds GUI-level ICS hardening that matches the CLI safety layer:

- GUI import preview before changes are made
- GUI duplicate detection and duplicate skipping
- GUI backup-before-import behavior
- GUI date-range ICS export
- `--version-ledger` JSON command
- Doctor/self-test checks for the update ledger and ICS duplicate preview

The final build should now be treated as including the v0.6.0, v0.7.0, v0.8.0, v0.9.0, v1.0.0, v1.0.1, and v1.0.2 layers.

## v1.0.2 Redteam Security Cleanup

This hotfix keeps the Sentinel Calendar v1 data format intact while hardening local storage, ICS import/export, launcher/autostart writes, reminder state, and Sentinel Suite hook outputs. It also blocks normal calendar profile access while running as root by default, preventing accidental root-owned calendar files under a user profile.
