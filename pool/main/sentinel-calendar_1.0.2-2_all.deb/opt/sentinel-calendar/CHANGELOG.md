# Sentinel Calendar Changelog

## v1.0.2 — Redteam Security Cleanup Hotfix

- Blocks root user-profile calendar access/writes by default unless explicitly overridden for controlled maintenance.
- Adds symlink-safe private data/config/backups/reminder-state/suite-hook writes.
- Hardens calendar store saves and backups with random temporary files, atomic replace, and private permissions.
- Refuses symlinked ICS import/export paths and caps ICS import size/event count/text fields.
- Replaces shell-based launcher metadata helpers with direct subprocess calls.
- Hardens reminder autostart launcher writes and removes packaged bytecode/cache clutter.

## v1.0.1 — Missing Update Closure Patch

- Explicitly backfills the missing v0.7.0 import/export hardening layer into the stable build.
- Adds GUI ICS import preview before data is changed.
- Adds GUI duplicate detection and duplicate skipping during import.
- Adds GUI backup-before-import behavior.
- Adds GUI date-range ICS export.
- Adds `--version-ledger` JSON output so Sentinel/AEGIS can verify included roadmap layers.
- Adds doctor/self-test validation for the update ledger and ICS duplicate preview.
- Improves use of first-day-of-week and startup-view settings in the GUI.
- Makes confirm-delete setting functional in the GUI.

## v0.8.1 — Reminder Daemon Patch

- Adds desktop reminder notification daemon, notify-send fallback, dismiss/snooze state, daemon one-shot mode, and reminder state path.

## v0.8.2 — Recurrence Control Patch

- Adds recurrence exception storage, skip/restore occurrence, and split one recurring occurrence into a standalone event.

## v0.8.3 — Settings Lock Patch

- Adds first-day-of-week, default category, default reminder, startup view, confirm delete, backup retention, notification settings, and CLI settings management.

## v0.8.4 — ICS Hardening Patch

- Adds ICS import preview, duplicate detection, backup-before-import, folded-line parsing, source UID handling, and date-range export.

## v0.9.0 — Release Candidate Patch

- Adds release-candidate self-test, stronger doctor checks, migration-safe older data loading, and package polish for lock testing.

## v1.0.0 — Stable Lock

- Locks Sentinel Calendar as a daily-use local calendar with the full v0.8.1-v0.9.0 backfill plus v0.8.0 suite hooks.
