# Sentinel Ledger Changelog

## v1.0.0 — User Ready Baseline

- Promoted Program 107 Sentinel Ledger from v0.9.5 release candidate to v1.0.0 stable baseline.
- Added `stable-status` for v1 readiness and stable-lock reporting.
- Preserved DD/MM/YYYY display dates with YYYY-MM-DD internal storage.
- Locked local-first / no-cloud / no-telemetry / explicit-write-approval doctrine.
- Preserved AEGIS/Sentinel Command read-only inspection and metadata contracts.
- Updated README, Manual, AEGIS manifest, and release metadata for v1.0.0.

## v0.9.5 — Phase 7 Release Candidate

- Added release-candidate readiness status command.
- Added DD/MM/YYYY user-facing date display and input support.
- Updated release candidate documentation and AEGIS manifest.
