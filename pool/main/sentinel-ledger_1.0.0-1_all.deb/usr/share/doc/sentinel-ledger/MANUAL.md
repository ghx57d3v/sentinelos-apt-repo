# Sentinel Ledger Manual — v1.0.0 User Ready Baseline

Sentinel Ledger is Program 107 in the Sentinel Desktop Suite. It is a local-first business ledger for small-business records, receipts, GST/BAS preparation, accountant handoff, customer/supplier memory, import/export, recovery, security, and AEGIS/Sentinel Command inspection.

## Core workflow

1. Open Sentinel Ledger from the menu or run `sentinel-ledger-gui`.
2. Complete the Setup Wizard with business details.
3. Use Quick Sale and Quick Expense for daily entries.
4. Use Customers and Suppliers tabs to review linked history.
5. Use Taxes for GST/BAS preparation and deductions checklist.
6. Use Reports to view read-only accounting reports and save accountant handoff packs.
7. Use Backup/Recovery/Security commands to protect the ledger.

## Dates

User-facing dates display as **DD/MM/YYYY**. The CLI accepts both `DD/MM/YYYY` and `YYYY-MM-DD`. The database stores dates internally as `YYYY-MM-DD`.

## AEGIS boundary

AEGIS may inspect, summarize, warn, and index metadata. AEGIS may not silently create, edit, delete, lodge, bank, sync, or mutate records without explicit user approval.

## v1 stability command

```bash
sentinel-ledger stable-status
```

This checks health, deep integrity, security, AEGIS readiness, launcher visibility, and known v1 limitations.
