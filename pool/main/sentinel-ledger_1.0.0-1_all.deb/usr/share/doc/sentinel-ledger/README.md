# Sentinel Ledger v1.0.0

Program 107 — Sentinel Ledger is the stable user-ready local-first business bookkeeping application for SentinelOS / AEGIS.

v1.0.0 is the **User Ready Baseline**. It is cumulative from the v0.9.5 release candidate and preserves the local SQLite double-entry ledger, Sentinel/AEGIS GUI, multi-ledger business profiles, setup wizard, receipts, receipt designer, customer/supplier registry, invoice and supplier bill workflows, GST/BAS preparation, accountant handoff reports, import/export packs, backup/recovery hardening, security hardening, AEGIS metadata, Sentinel Command contracts, inventory bridge contract, and workflow hotkeys.

## Date display

User-facing dates display as **DD/MM/YYYY**. Internal database storage remains **YYYY-MM-DD** for safe sorting and filtering.

## Safety boundary

Sentinel Ledger is not a tax lodgement tool. It prepares reports, records, receipt indexes, suggested deduction checklists, and accountant handoff packs for review. AEGIS/Sentinel Command may inspect, summarize, warn, and index metadata, but financial record changes require explicit user action.

## Useful commands

```bash
sentinel-ledger gui
sentinel-ledger stable-status
sentinel-ledger health
sentinel-ledger aegis-readiness
sentinel-ledger dashboard-summary
sentinel-ledger accountant-bas-report --start 01/07/2025 --end 30/06/2026 --include-suggested-deductions
sentinel-ledger full-archive-export
sentinel-ledger portable-restore-pack
```
