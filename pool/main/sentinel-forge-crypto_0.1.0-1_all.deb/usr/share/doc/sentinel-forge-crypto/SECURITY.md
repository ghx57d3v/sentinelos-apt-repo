# Security Notes

This package is a wrapper layer. It deliberately avoids implementing custom cryptographic algorithms.

## Included safeguards

- Destructive `luks-format` requires `--execute --confirm ERASE`.
- LUKS header restore requires `--execute --confirm RESTORE_HEADER`.
- Output files are not overwritten by default.
- Mapping names are restricted to safe characters.
- Subprocess calls use argv arrays rather than shell command strings.
- Folder decrypt uses safe tar extraction path checks.

## Not included in v0.1.0

- No automatic filesystem creation after LUKS format.
- No automatic drive wiping.
- No automated root filesystem encryption.
- No GUI destructive disk wizard.
- No custom key escrow.
- No remote unlock.
- No cloud sync.

## Operational warning

LUKS formatting a real device will destroy access to existing data on that target. Always verify the device path with `sentinel-forge-crypto list-devices` and keep recovery material offline.
