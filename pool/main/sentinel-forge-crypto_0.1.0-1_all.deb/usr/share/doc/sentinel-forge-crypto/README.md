# Sentinel F.O.R.G.E Crypto v0.1.0

**Component:** F.O.R.G.E Encryption & Secure Media backend  
**Program:** 120 — F.O.R.G.E / File Output & Release Generation Engine  
**Package:** `sentinel-forge-crypto`  
**Status:** v0.1.0 foundation build, not a v1 lock

This package adds a conservative encryption backend for Sentinel F.O.R.G.E. It does **not** implement custom cryptography. It wraps established Linux tools:

- `cryptsetup` / LUKS / dm-crypt for encrypted block devices and encrypted container files
- `age` for portable file and folder-archive encryption
- `fscrypt` as an optional helper for native filesystem directory encryption on supported filesystems

## Safety posture

- Local-only
- No network requirement
- No telemetry
- No custom encryption algorithms
- Destructive disk formatting is blocked unless both are supplied:
  - `--execute`
  - `--confirm ERASE`
- LUKS header restore is blocked unless both are supplied:
  - `--execute`
  - `--confirm RESTORE_HEADER`
- Commands are executed through Python argument lists, not shell strings.
- GUI v0.1.0 intentionally does not run destructive disk workflows.

## Install

```bash
sudo apt install ./sentinel-forge-crypto_0.1.0-1_all.deb
```

Suggested dependencies:

```bash
sudo apt install cryptsetup age fscrypt util-linux tar python3-tk
```

`fscrypt` and `python3-tk` are optional unless you use those features.

## Main commands

```bash
sentinel-forge-crypto deps
sentinel-forge-crypto aegis-status
sentinel-forge-crypto list-devices
sentinel-forge-crypto is-luks /dev/sdX1
sentinel-forge-crypto luks-status myvault
```

### File encryption

Passphrase mode:

```bash
sentinel-forge-crypto file-encrypt ./plain.txt ./plain.txt.age --passphrase
sentinel-forge-crypto file-decrypt ./plain.txt.age ./plain-restored.txt --passphrase
```

Recipient key mode:

```bash
sentinel-forge-crypto age-keygen ./sentinel-age-identity.txt
# Copy the public key printed by age-keygen, then:
sentinel-forge-crypto file-encrypt ./plain.txt ./plain.txt.age --recipient age1...
sentinel-forge-crypto file-decrypt ./plain.txt.age ./plain-restored.txt --identity ./sentinel-age-identity.txt
```

### Folder archive encryption

```bash
sentinel-forge-crypto folder-encrypt ./FamilyRecipes ./FamilyRecipes.tar.age --passphrase
sentinel-forge-crypto folder-decrypt ./FamilyRecipes.tar.age ./Recovered --passphrase
```

### LUKS encrypted container workflow

Create a sparse container file:

```bash
sentinel-forge-crypto container-create ~/secure-vault.img --size 2G --execute
```

Format it as LUKS2. This is destructive to the target file/device and requires explicit confirmation:

```bash
sentinel-forge-crypto luks-format ~/secure-vault.img --label SentinelVault --execute --confirm ERASE
```

Open and close:

```bash
sentinel-forge-crypto luks-open ~/secure-vault.img sentinel_secure
sentinel-forge-crypto luks-close sentinel_secure
```

Mount after formatting the opened mapping with a filesystem manually:

```bash
sudo mkfs.ext4 /dev/mapper/sentinel_secure
sentinel-forge-crypto mount sentinel_secure ~/SecureMount
sentinel-forge-crypto unmount ~/SecureMount
sentinel-forge-crypto luks-close sentinel_secure
```

## AEGIS status contract

```bash
sentinel-forge-crypto aegis-status
```

Schema:

```json
{
  "schema": "sentinel.forge.crypto.status.v1",
  "component": "F.O.R.G.E Encryption & Secure Media backend",
  "program": "120 F.O.R.G.E",
  "local_only": true,
  "custom_crypto": false
}
```

## F.O.R.G.E integration intent

This backend is meant to sit underneath the future F.O.R.G.E GUI module:

```text
F.O.R.G.E
└── Encryption & Secure Media
    ├── Encrypt USB Drive
    ├── Create Encrypted Volume
    ├── Open / Close Encrypted Volume
    ├── Encrypt File
    ├── Encrypt Folder Archive
    ├── Recovery Key Kit
    └── Safety / Integrity Report
```

B.A.S.T.I.O.N can later call this backend for encrypted backup containers. S.C.A.N can audit the status JSON and dependency readiness. V.A.U.L.T can use encrypted containers/archive outputs without taking over disk operations.
