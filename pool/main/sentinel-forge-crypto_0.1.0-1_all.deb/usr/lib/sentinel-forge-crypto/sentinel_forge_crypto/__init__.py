VERSION = "0.1.0"
APP_ID = "sentinel-forge-crypto"
