#!/usr/bin/env python3
"""
Sentinel F.O.R.G.E Crypto backend
Safe command construction and execution wrappers for proven Linux encryption tools.
No custom cryptography is implemented here.
"""
from __future__ import annotations

import dataclasses
import getpass
import hashlib
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
import tarfile
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Optional

from . import VERSION, APP_ID

SAFE_MAP_RE = re.compile(r"^[A-Za-z0-9_.-]{1,64}$")

DEPENDENCIES = {
    "cryptsetup": "LUKS/dm-crypt block-device and encrypted-container operations",
    "lsblk": "safe block-device listing",
    "findmnt": "mount/mapping inspection",
    "mount": "mount opened encrypted volumes",
    "umount": "unmount encrypted volumes",
    "age": "file/folder archive encryption and decryption",
    "age-keygen": "age key generation",
    "tar": "folder packing before age encryption",
    "fscrypt": "optional native filesystem directory encryption helper",
}

DANGEROUS_WORDS = ("format", "erase", "wipe", "luksFormat", "mkfs")

class ForgeCryptoError(RuntimeError):
    pass

@dataclasses.dataclass
class RunResult:
    argv: list[str]
    returncode: int
    stdout: str
    stderr: str
    dry_run: bool = False

    def to_dict(self) -> dict[str, Any]:
        return dataclasses.asdict(self)


def now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def which(name: str) -> Optional[str]:
    return shutil.which(name)


def dependency_status() -> dict[str, Any]:
    deps = []
    for name, purpose in DEPENDENCIES.items():
        path = which(name)
        deps.append({"name": name, "available": bool(path), "path": path, "purpose": purpose})
    required_core = ["cryptsetup", "lsblk", "findmnt", "age", "tar"]
    return {
        "app": APP_ID,
        "version": VERSION,
        "checked_at": now_iso(),
        "dependencies": deps,
        "core_ready": all(which(x) for x in required_core),
        "luks_ready": all(which(x) for x in ["cryptsetup", "lsblk", "findmnt"]),
        "file_crypto_ready": all(which(x) for x in ["age", "tar"]),
        "fscrypt_ready": bool(which("fscrypt")),
    }


def require_command(name: str) -> str:
    path = which(name)
    if not path:
        raise ForgeCryptoError(f"Missing required command: {name}")
    return path


def quote_cmd(argv: Iterable[str]) -> str:
    return " ".join(shlex.quote(str(x)) for x in argv)


def run(argv: list[str], *, dry_run: bool = False, check: bool = True, input_text: str | None = None) -> RunResult:
    if dry_run:
        return RunResult(argv=argv, returncode=0, stdout=quote_cmd(argv), stderr="", dry_run=True)
    try:
        proc = subprocess.run(
            argv,
            input=input_text,
            text=True,
            capture_output=True,
            check=False,
        )
    except FileNotFoundError as exc:
        raise ForgeCryptoError(str(exc)) from exc
    result = RunResult(argv=argv, returncode=proc.returncode, stdout=proc.stdout, stderr=proc.stderr, dry_run=False)
    if check and proc.returncode != 0:
        raise ForgeCryptoError(f"Command failed ({proc.returncode}): {quote_cmd(argv)}\n{proc.stderr.strip()}")
    return result


def ensure_safe_mapping_name(name: str) -> str:
    if not SAFE_MAP_RE.match(name):
        raise ForgeCryptoError("Mapping/container name must contain only letters, numbers, dot, dash, and underscore, max 64 chars.")
    return name


def ensure_path_exists(path: str | Path) -> Path:
    p = Path(path).expanduser().resolve()
    if not p.exists():
        raise ForgeCryptoError(f"Path does not exist: {p}")
    return p


def ensure_parent(path: str | Path) -> Path:
    p = Path(path).expanduser().resolve()
    p.parent.mkdir(parents=True, exist_ok=True)
    return p


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def list_devices_json() -> dict[str, Any]:
    require_command("lsblk")
    argv = ["lsblk", "-J", "-o", "NAME,PATH,SIZE,TYPE,FSTYPE,LABEL,MODEL,SERIAL,MOUNTPOINTS,UUID"]
    res = run(argv)
    try:
        data = json.loads(res.stdout)
    except json.JSONDecodeError as exc:
        raise ForgeCryptoError("Unable to parse lsblk JSON output") from exc
    return {"app": APP_ID, "version": VERSION, "checked_at": now_iso(), **data}


def luks_is_luks(device: str) -> RunResult:
    require_command("cryptsetup")
    return run(["cryptsetup", "isLuks", str(device)], check=False)


def luks_status(mapping: str) -> RunResult:
    require_command("cryptsetup")
    mapping = ensure_safe_mapping_name(mapping)
    return run(["cryptsetup", "status", mapping], check=False)


def luks_format(device: str, *, label: str | None = None, dry_run: bool = False, execute: bool = False, confirm: str | None = None) -> RunResult:
    if not dry_run:
        require_command("cryptsetup")
    if not dry_run and (not execute or confirm != "ERASE"):
        raise ForgeCryptoError("Refusing destructive LUKS format. Require --execute --confirm ERASE.")
    argv = ["sudo", "cryptsetup", "luksFormat", "--type", "luks2"]
    if label:
        argv.extend(["--label", label])
    argv.append(str(device))
    return run(argv, dry_run=dry_run)


def luks_header_backup(device: str, output: str, *, dry_run: bool = False) -> RunResult:
    if not dry_run:
        require_command("cryptsetup")
    out = ensure_parent(output)
    argv = ["sudo", "cryptsetup", "luksHeaderBackup", str(device), "--header-backup-file", str(out)]
    return run(argv, dry_run=dry_run)


def luks_header_restore(device: str, backup_file: str, *, dry_run: bool = False, execute: bool = False, confirm: str | None = None) -> RunResult:
    if not dry_run:
        require_command("cryptsetup")
    backup = ensure_path_exists(backup_file)
    if not dry_run and (not execute or confirm != "RESTORE_HEADER"):
        raise ForgeCryptoError("Refusing LUKS header restore. Require --execute --confirm RESTORE_HEADER.")
    argv = ["sudo", "cryptsetup", "luksHeaderRestore", str(device), "--header-backup-file", str(backup)]
    return run(argv, dry_run=dry_run)


def luks_open(device: str, mapping: str, *, dry_run: bool = False) -> RunResult:
    if not dry_run:
        require_command("cryptsetup")
    mapping = ensure_safe_mapping_name(mapping)
    argv = ["sudo", "cryptsetup", "open", str(device), mapping]
    return run(argv, dry_run=dry_run)


def luks_close(mapping: str, *, dry_run: bool = False) -> RunResult:
    if not dry_run:
        require_command("cryptsetup")
    mapping = ensure_safe_mapping_name(mapping)
    argv = ["sudo", "cryptsetup", "close", mapping]
    return run(argv, dry_run=dry_run)


def mount_mapping(mapping: str, mountpoint: str, *, dry_run: bool = False) -> RunResult:
    if not dry_run:
        require_command("mount")
    mapping = ensure_safe_mapping_name(mapping)
    mp = Path(mountpoint).expanduser().resolve()
    argv = ["sudo", "mkdir", "-p", str(mp), "&&", "sudo", "mount", f"/dev/mapper/{mapping}", str(mp)]
    # Avoid shell because of &&. Run mkdir first then mount.
    if dry_run:
        return RunResult(argv=argv, returncode=0, stdout="sudo mkdir -p " + shlex.quote(str(mp)) + " && sudo mount " + shlex.quote(f"/dev/mapper/{mapping}") + " " + shlex.quote(str(mp)), stderr="", dry_run=True)
    run(["sudo", "mkdir", "-p", str(mp)])
    return run(["sudo", "mount", f"/dev/mapper/{mapping}", str(mp)])


def unmount_path(mountpoint: str, *, dry_run: bool = False) -> RunResult:
    if not dry_run:
        require_command("umount")
    mp = Path(mountpoint).expanduser().resolve()
    argv = ["sudo", "umount", str(mp)]
    return run(argv, dry_run=dry_run)


def create_container_image(path: str, size: str, *, sparse: bool = True, dry_run: bool = False, execute: bool = False) -> RunResult:
    """Create an empty file intended to become a LUKS container. Size is passed to truncate/fallocate."""
    out = ensure_parent(path)
    if out.exists():
        raise ForgeCryptoError(f"Refusing to overwrite existing file: {out}")
    if not dry_run and not execute:
        raise ForgeCryptoError("Refusing to create container without --execute.")
    if sparse:
        if not dry_run:
            require_command("truncate")
        argv = ["truncate", "-s", size, str(out)]
    else:
        if not dry_run:
            require_command("fallocate")
        argv = ["fallocate", "-l", size, str(out)]
    return run(argv, dry_run=dry_run)


def age_generate_identity(output: str, *, dry_run: bool = False) -> RunResult:
    if not dry_run:
        require_command("age-keygen")
    out = ensure_parent(output)
    if out.exists() and not dry_run:
        raise ForgeCryptoError(f"Refusing to overwrite existing identity file: {out}")
    return run(["age-keygen", "-o", str(out)], dry_run=dry_run)


def age_encrypt_file(input_file: str, output_file: str, *, recipient: str | None = None, passphrase: bool = False, dry_run: bool = False) -> RunResult:
    if not dry_run:
        require_command("age")
    src = ensure_path_exists(input_file)
    if not src.is_file():
        raise ForgeCryptoError("Input must be a regular file for file encryption.")
    out = ensure_parent(output_file)
    if out.exists() and not dry_run:
        raise ForgeCryptoError(f"Refusing to overwrite existing output: {out}")
    argv = ["age", "-o", str(out)]
    if passphrase:
        argv.append("-p")
    elif recipient:
        argv.extend(["-r", recipient])
    else:
        raise ForgeCryptoError("Provide --recipient AGE_PUBLIC_KEY or use --passphrase.")
    argv.append(str(src))
    return run(argv, dry_run=dry_run)


def age_decrypt_file(input_file: str, output_file: str, *, identity: str | None = None, passphrase: bool = False, dry_run: bool = False) -> RunResult:
    if not dry_run:
        require_command("age")
    src = ensure_path_exists(input_file)
    out = ensure_parent(output_file)
    if out.exists() and not dry_run:
        raise ForgeCryptoError(f"Refusing to overwrite existing output: {out}")
    argv = ["age", "-d", "-o", str(out)]
    if identity:
        argv.extend(["-i", str(ensure_path_exists(identity))])
    elif not passphrase:
        raise ForgeCryptoError("Provide --identity KEYFILE or use --passphrase.")
    argv.append(str(src))
    return run(argv, dry_run=dry_run)


def pack_folder_to_tar(folder: str, tar_output: Path) -> None:
    src = ensure_path_exists(folder)
    if not src.is_dir():
        raise ForgeCryptoError("Input must be a folder for folder-pack encryption.")
    with tarfile.open(tar_output, "w") as tf:
        tf.add(src, arcname=src.name)


def age_encrypt_folder_archive(folder: str, output_file: str, *, recipient: str | None = None, passphrase: bool = False, dry_run: bool = False) -> RunResult:
    if not dry_run:
        require_command("age")
        require_command("tar")
    src = ensure_path_exists(folder)
    if not src.is_dir():
        raise ForgeCryptoError("Input must be a folder.")
    out = ensure_parent(output_file)
    if out.exists() and not dry_run:
        raise ForgeCryptoError(f"Refusing to overwrite existing output: {out}")
    if dry_run:
        mode = "-p" if passphrase else f"-r {recipient}"
        return RunResult(argv=["tar", "+", "age"], returncode=0, stdout=f"tar folder {shlex.quote(str(src))} to temporary archive, then age {mode} -o {shlex.quote(str(out))}", stderr="", dry_run=True)
    with tempfile.TemporaryDirectory(prefix="sentinel-forge-crypto-") as td:
        tmp_tar = Path(td) / f"{src.name}.tar"
        pack_folder_to_tar(str(src), tmp_tar)
        return age_encrypt_file(str(tmp_tar), str(out), recipient=recipient, passphrase=passphrase, dry_run=False)


def age_decrypt_folder_archive(input_file: str, output_dir: str, *, identity: str | None = None, passphrase: bool = False, dry_run: bool = False) -> RunResult:
    if not dry_run:
        require_command("age")
        require_command("tar")
    src = ensure_path_exists(input_file)
    out_dir = Path(output_dir).expanduser().resolve()
    if dry_run:
        return RunResult(argv=["age", "+", "tar"], returncode=0, stdout=f"age decrypt {shlex.quote(str(src))} to temporary tar, then extract under {shlex.quote(str(out_dir))}", stderr="", dry_run=True)
    out_dir.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="sentinel-forge-crypto-") as td:
        tmp_tar = Path(td) / "decrypted-folder.tar"
        age_decrypt_file(str(src), str(tmp_tar), identity=identity, passphrase=passphrase, dry_run=False)
        with tarfile.open(tmp_tar, "r") as tf:
            safe_extract_tar(tf, out_dir)
    return RunResult(argv=["age", "+", "tar"], returncode=0, stdout=f"Extracted encrypted archive to {out_dir}", stderr="", dry_run=False)


def safe_extract_tar(tf: tarfile.TarFile, destination: Path) -> None:
    dest = destination.resolve()
    for member in tf.getmembers():
        target = (dest / member.name).resolve()
        if not str(target).startswith(str(dest) + os.sep) and target != dest:
            raise ForgeCryptoError(f"Unsafe archive path blocked: {member.name}")
    tf.extractall(dest)


def fscrypt_status(path: str | None = None) -> RunResult:
    require_command("fscrypt")
    argv = ["fscrypt", "status"]
    if path:
        argv.append(str(Path(path).expanduser().resolve()))
    return run(argv, check=False)


def fscrypt_encrypt_empty_dir(path: str, *, dry_run: bool = False, execute: bool = False) -> RunResult:
    if not dry_run:
        require_command("fscrypt")
    p = Path(path).expanduser().resolve()
    if not p.exists():
        raise ForgeCryptoError(f"Directory does not exist: {p}")
    if not p.is_dir():
        raise ForgeCryptoError("fscrypt target must be a directory.")
    if any(p.iterdir()):
        raise ForgeCryptoError("fscrypt encryption requires an empty directory. Create a new empty folder, encrypt it, then move files in after unlocking.")
    if not dry_run and not execute:
        raise ForgeCryptoError("Refusing fscrypt encrypt without --execute.")
    argv = ["fscrypt", "encrypt", str(p)]
    return run(argv, dry_run=dry_run)


def aegis_status() -> dict[str, Any]:
    deps = dependency_status()
    return {
        "app": APP_ID,
        "component": "F.O.R.G.E Encryption & Secure Media backend",
        "program": "120 F.O.R.G.E",
        "version": VERSION,
        "schema": "sentinel.forge.crypto.status.v1",
        "generated_at": now_iso(),
        "local_only": True,
        "network_required": False,
        "custom_crypto": False,
        "proven_tools": ["cryptsetup/LUKS/dm-crypt", "age", "fscrypt optional"],
        "ready": deps["core_ready"],
        "capabilities": {
            "list_devices": bool(which("lsblk")),
            "luks_status_open_close": deps["luks_ready"],
            "luks_format_guarded": deps["luks_ready"],
            "luks_header_backup_restore_guarded": bool(which("cryptsetup")),
            "file_encrypt_decrypt": deps["file_crypto_ready"],
            "folder_archive_encrypt_decrypt": deps["file_crypto_ready"],
            "fscrypt_directory_encrypt_empty_dir": deps["fscrypt_ready"],
        },
        "safety": {
            "destructive_disk_format_requires": ["--execute", "--confirm ERASE"],
            "luks_header_restore_requires": ["--execute", "--confirm RESTORE_HEADER"],
            "shell_invocation": False,
            "dry_run_supported": True,
        },
        "dependencies": deps["dependencies"],
    }
