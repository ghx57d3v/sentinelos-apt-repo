#!/usr/bin/env python3
"""Small GUI launcher for Sentinel F.O.R.G.E Crypto v0.1.0.
This is intentionally a command builder/status panel, not a full destructive disk wizard.
"""
from __future__ import annotations

import json
import subprocess
import sys
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

from . import VERSION
from . import core


class ForgeCryptoGUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"Sentinel F.O.R.G.E Encryption v{VERSION}")
        self.geometry("900x620")
        self.configure(bg="#101418")
        self._build()
        self.refresh_status()

    def _build(self):
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("TFrame", background="#101418")
        style.configure("TLabel", background="#101418", foreground="#E8E8E8")
        style.configure("TButton", padding=6)
        style.configure("Header.TLabel", font=("Sans", 15, "bold"), foreground="#E19B00", background="#101418")

        root = ttk.Frame(self, padding=14)
        root.pack(fill="both", expand=True)

        ttk.Label(root, text="F.O.R.G.E Encryption & Secure Media", style="Header.TLabel").pack(anchor="w")
        ttk.Label(root, text="Safe frontend for cryptsetup/LUKS, age, and optional fscrypt. Destructive disk actions stay CLI-guarded in v0.1.0.").pack(anchor="w", pady=(2,10))

        btns = ttk.Frame(root)
        btns.pack(fill="x", pady=4)
        ttk.Button(btns, text="Refresh Status", command=self.refresh_status).pack(side="left", padx=(0,6))
        ttk.Button(btns, text="List Devices", command=self.list_devices).pack(side="left", padx=6)
        ttk.Button(btns, text="Build File Encrypt Command", command=self.file_encrypt_builder).pack(side="left", padx=6)
        ttk.Button(btns, text="Build Folder Encrypt Command", command=self.folder_encrypt_builder).pack(side="left", padx=6)

        self.text = tk.Text(root, bg="#171C21", fg="#E8E8E8", insertbackground="#E8E8E8", relief="flat", wrap="word")
        self.text.pack(fill="both", expand=True, pady=(12,0))

        footer = ttk.Frame(root)
        footer.pack(fill="x", pady=(8,0))
        ttk.Button(footer, text="Copy Output", command=self.copy_output).pack(side="right")

    def set_text(self, value: str):
        self.text.delete("1.0", "end")
        self.text.insert("1.0", value)

    def refresh_status(self):
        self.set_text(json.dumps(core.aegis_status(), indent=2, sort_keys=True))

    def list_devices(self):
        try:
            self.set_text(json.dumps(core.list_devices_json(), indent=2, sort_keys=True))
        except Exception as exc:
            messagebox.showerror("F.O.R.G.E Encryption", str(exc))

    def file_encrypt_builder(self):
        src = filedialog.askopenfilename(title="Choose file to encrypt")
        if not src:
            return
        out = filedialog.asksaveasfilename(title="Save encrypted file as", defaultextension=".age")
        if not out:
            return
        cmd = f"sentinel-forge-crypto file-encrypt {src!r} {out!r} --passphrase"
        self.set_text("Command built for terminal review:\n\n" + cmd + "\n\nThis uses age passphrase mode and will prompt in terminal.")

    def folder_encrypt_builder(self):
        src = filedialog.askdirectory(title="Choose folder to pack and encrypt")
        if not src:
            return
        out = filedialog.asksaveasfilename(title="Save encrypted archive as", defaultextension=".tar.age")
        if not out:
            return
        cmd = f"sentinel-forge-crypto folder-encrypt {src!r} {out!r} --passphrase"
        self.set_text("Command built for terminal review:\n\n" + cmd + "\n\nThis packs the folder to a temporary tar archive, then encrypts the archive with age passphrase mode.")

    def copy_output(self):
        self.clipboard_clear()
        self.clipboard_append(self.text.get("1.0", "end").strip())
        messagebox.showinfo("Copied", "Output copied to clipboard.")


def main():
    app = ForgeCryptoGUI()
    app.mainloop()

if __name__ == "__main__":
    main()
