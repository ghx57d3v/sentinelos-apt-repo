#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from . import VERSION, APP_ID
from . import core


def print_json(obj) -> None:
    print(json.dumps(obj, indent=2, sort_keys=True))


def print_result(res: core.RunResult, json_mode: bool = False) -> None:
    if json_mode:
        print_json(res.to_dict())
    else:
        prefix = "DRY-RUN: " if res.dry_run else ""
        if res.stdout.strip():
            print(prefix + res.stdout.strip())
        if res.stderr.strip():
            print(res.stderr.strip(), file=sys.stderr)
        if not res.stdout.strip() and not res.stderr.strip():
            print(prefix + f"Command completed with exit code {res.returncode}")


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="sentinel-forge-crypto",
        description="Sentinel F.O.R.G.E Encryption & Secure Media backend. Uses proven Linux tools; implements no custom cryptography.",
    )
    p.add_argument("--version", action="version", version=f"{APP_ID} {VERSION}")
    p.add_argument("--json", action="store_true", help="Emit JSON where practical.")
    sub = p.add_subparsers(dest="command", required=True)

    sub.add_parser("deps", help="Show dependency readiness.")
    sub.add_parser("aegis-status", help="Emit AEGIS-readable status JSON.")
    sub.add_parser("list-devices", help="List block devices using lsblk JSON.")

    is_luks = sub.add_parser("is-luks", help="Check whether a block device/file is a LUKS container.")
    is_luks.add_argument("device")

    status = sub.add_parser("luks-status", help="Show cryptsetup status for an open mapping.")
    status.add_argument("mapping")

    fmt = sub.add_parser("luks-format", help="Destructively initialize a LUKS2 device/container. Guarded.")
    fmt.add_argument("device")
    fmt.add_argument("--label")
    fmt.add_argument("--dry-run", action="store_true")
    fmt.add_argument("--execute", action="store_true", help="Required for destructive actions.")
    fmt.add_argument("--confirm", help="Must be ERASE for luks-format.")

    hbak = sub.add_parser("luks-header-backup", help="Back up a LUKS header.")
    hbak.add_argument("device")
    hbak.add_argument("output")
    hbak.add_argument("--dry-run", action="store_true")

    hres = sub.add_parser("luks-header-restore", help="Restore a LUKS header. Guarded.")
    hres.add_argument("device")
    hres.add_argument("backup_file")
    hres.add_argument("--dry-run", action="store_true")
    hres.add_argument("--execute", action="store_true")
    hres.add_argument("--confirm", help="Must be RESTORE_HEADER.")

    op = sub.add_parser("luks-open", help="Open a LUKS device/container mapping.")
    op.add_argument("device")
    op.add_argument("mapping")
    op.add_argument("--dry-run", action="store_true")

    cl = sub.add_parser("luks-close", help="Close a LUKS mapping.")
    cl.add_argument("mapping")
    cl.add_argument("--dry-run", action="store_true")

    mnt = sub.add_parser("mount", help="Mount an opened /dev/mapper mapping.")
    mnt.add_argument("mapping")
    mnt.add_argument("mountpoint")
    mnt.add_argument("--dry-run", action="store_true")

    umnt = sub.add_parser("unmount", help="Unmount a path.")
    umnt.add_argument("mountpoint")
    umnt.add_argument("--dry-run", action="store_true")

    cont = sub.add_parser("container-create", help="Create an empty file intended for LUKS container use.")
    cont.add_argument("path")
    cont.add_argument("--size", required=True, help="Size accepted by truncate/fallocate, e.g. 2G, 512M.")
    cont.add_argument("--allocated", action="store_true", help="Use fallocate instead of sparse truncate.")
    cont.add_argument("--dry-run", action="store_true")
    cont.add_argument("--execute", action="store_true")

    key = sub.add_parser("age-keygen", help="Generate an age identity file.")
    key.add_argument("output")
    key.add_argument("--dry-run", action="store_true")

    enc = sub.add_parser("file-encrypt", help="Encrypt a file with age.")
    enc.add_argument("input_file")
    enc.add_argument("output_file")
    enc.add_argument("--recipient", help="age public recipient key.")
    enc.add_argument("--passphrase", action="store_true")
    enc.add_argument("--dry-run", action="store_true")

    dec = sub.add_parser("file-decrypt", help="Decrypt an age-encrypted file.")
    dec.add_argument("input_file")
    dec.add_argument("output_file")
    dec.add_argument("--identity", help="age identity key file.")
    dec.add_argument("--passphrase", action="store_true")
    dec.add_argument("--dry-run", action="store_true")

    fenc = sub.add_parser("folder-encrypt", help="Pack a folder to tar and encrypt it with age.")
    fenc.add_argument("folder")
    fenc.add_argument("output_file")
    fenc.add_argument("--recipient")
    fenc.add_argument("--passphrase", action="store_true")
    fenc.add_argument("--dry-run", action="store_true")

    fdec = sub.add_parser("folder-decrypt", help="Decrypt an age folder archive and safely extract it.")
    fdec.add_argument("input_file")
    fdec.add_argument("output_dir")
    fdec.add_argument("--identity")
    fdec.add_argument("--passphrase", action="store_true")
    fdec.add_argument("--dry-run", action="store_true")

    fss = sub.add_parser("fscrypt-status", help="Show fscrypt status.")
    fss.add_argument("path", nargs="?")

    fse = sub.add_parser("fscrypt-encrypt-empty-dir", help="Encrypt an empty directory with fscrypt. Guarded.")
    fse.add_argument("path")
    fse.add_argument("--dry-run", action="store_true")
    fse.add_argument("--execute", action="store_true")

    return p


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        if args.command == "deps":
            print_json(core.dependency_status())
        elif args.command == "aegis-status":
            print_json(core.aegis_status())
        elif args.command == "list-devices":
            print_json(core.list_devices_json())
        elif args.command == "is-luks":
            res = core.luks_is_luks(args.device)
            if args.json:
                print_json({"device": args.device, "is_luks": res.returncode == 0, "returncode": res.returncode, "stderr": res.stderr})
            else:
                print("YES" if res.returncode == 0 else "NO")
        elif args.command == "luks-status":
            print_result(core.luks_status(args.mapping), args.json)
        elif args.command == "luks-format":
            print_result(core.luks_format(args.device, label=args.label, dry_run=args.dry_run, execute=args.execute, confirm=args.confirm), args.json)
        elif args.command == "luks-header-backup":
            print_result(core.luks_header_backup(args.device, args.output, dry_run=args.dry_run), args.json)
        elif args.command == "luks-header-restore":
            print_result(core.luks_header_restore(args.device, args.backup_file, dry_run=args.dry_run, execute=args.execute, confirm=args.confirm), args.json)
        elif args.command == "luks-open":
            print_result(core.luks_open(args.device, args.mapping, dry_run=args.dry_run), args.json)
        elif args.command == "luks-close":
            print_result(core.luks_close(args.mapping, dry_run=args.dry_run), args.json)
        elif args.command == "mount":
            print_result(core.mount_mapping(args.mapping, args.mountpoint, dry_run=args.dry_run), args.json)
        elif args.command == "unmount":
            print_result(core.unmount_path(args.mountpoint, dry_run=args.dry_run), args.json)
        elif args.command == "container-create":
            print_result(core.create_container_image(args.path, args.size, sparse=not args.allocated, dry_run=args.dry_run, execute=args.execute), args.json)
        elif args.command == "age-keygen":
            print_result(core.age_generate_identity(args.output, dry_run=args.dry_run), args.json)
        elif args.command == "file-encrypt":
            print_result(core.age_encrypt_file(args.input_file, args.output_file, recipient=args.recipient, passphrase=args.passphrase, dry_run=args.dry_run), args.json)
        elif args.command == "file-decrypt":
            print_result(core.age_decrypt_file(args.input_file, args.output_file, identity=args.identity, passphrase=args.passphrase, dry_run=args.dry_run), args.json)
        elif args.command == "folder-encrypt":
            print_result(core.age_encrypt_folder_archive(args.folder, args.output_file, recipient=args.recipient, passphrase=args.passphrase, dry_run=args.dry_run), args.json)
        elif args.command == "folder-decrypt":
            print_result(core.age_decrypt_folder_archive(args.input_file, args.output_dir, identity=args.identity, passphrase=args.passphrase, dry_run=args.dry_run), args.json)
        elif args.command == "fscrypt-status":
            print_result(core.fscrypt_status(args.path), args.json)
        elif args.command == "fscrypt-encrypt-empty-dir":
            print_result(core.fscrypt_encrypt_empty_dir(args.path, dry_run=args.dry_run, execute=args.execute), args.json)
        else:
            parser.error("Unknown command")
        return 0
    except core.ForgeCryptoError as exc:
        if getattr(args, "json", False):
            print_json({"ok": False, "error": str(exc), "app": APP_ID, "version": VERSION})
        else:
            print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        return 130

if __name__ == "__main__":
    raise SystemExit(main())
