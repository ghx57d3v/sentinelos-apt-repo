
## v1.0.8 — Homepage Weather Source / AEGIS Theme Hotfix

- Weather widget now treats saved user city as the primary source.
- Melbourne, VIC is fallback only when no user city is saved.
- Default no-user weather view uses Melbourne main weather with Sydney, Brisbane, Adelaide and Alice Springs current-weather cards.
- Saving a city rewrites the runtime homepage immediately so page reload does not reuse stale Melbourne bootstrap data.
- Search-engine selector is forced into AEGIS theme styling.
- Metallic/glass homepage styling removed in favour of flat AEGIS dark/gold/cyan surfaces.

# Sentinel Browser v1.0.2

Homepage Default / SentinelOS landing-page patch.

- Installs the supplied `homepage.html` under `/usr/share/sentinel-browser/homepage/homepage.html`.
- Routes `sentinel://home` and `about:sentinel-home` to the packaged SentinelOS Browser Home page.
- Makes first launch, Home button, and new tabs use the SentinelOS landing page by default.
- Adds `sentinel-browser --homepage-status` and `sentinel-browser --homepage-default-test`.
- Preserves Browser/Wallet security separation: Browser never receives seeds, private keys, wallet passphrases, or signing material.

# Sentinel Browser v1.0.0-rc18

Phase 5B browser-first download UX correction.

## Download model

Sentinel Browser now handles active downloads like Firefox/Chrome: the Browser owns the WebKit transfer, progress indicator, and active cancel action. Download Guard is not called during active transfer. After WebKit reports the download as finished, Browser starts a background handoff to Download Guard using `--import-completed-download`.

Completed files remain in guarded staging/quarantine and only move to the user's Downloads folder after explicit Download Guard release.

## Clean Debian rule

Sentinel Browser must run on clean Debian with its declared dependencies and the matching `sentinel-download-guard` package. AEGIS/Sentinel Command integration is advisory JSON/status only and is not required for normal operation.

## New checks

```bash
sentinel-browser --phase5b-browser-first-test
sentinel-browser --release-candidate-status
```


## RC18 Download UX Polish

- Downloads button uses green active/completed feedback.
- Active downloads remain Browser-owned to avoid WebKit UI freezes.
- Downloads page now exposes Review / Release for quarantined files and Go to File / Show Folder for released files.
- Go to File is intentionally unavailable before Download Guard release approval.


## v1.0.0-rc18 RC3-based v1 security gate

RC18 is built from the confirmed-good RC3 base, not from RC4/RC5. It preserves browser-first active downloads and Download Guard post-completion quarantine/review/release, while adding clean Debian independence and private-directory/security gate checks. No AEGIS/Sentinel Command runtime is required.


## RC18 Home / Vault / Network polish
- Default local home page: `about:sentinel-home`.
- Bookmarks toolbar row title text hidden; bookmark buttons remain.
- Vault login prompt includes `Save to Vault` without Browser storing credentials.
- Preferences include Network/Proxy/VPN settings; AEGIS remains optional.

## v1.0.0-rc18
- Removed remaining Bookmarks row title label from the favourites/bookmarks bar.
- Added editable Security checkbox controls for permissions, TLS, download warnings, dangerous downloads, no-auto-open, external protocols, and JavaScript profile.
- Preserved RC3/RC7/RC18 browser-first download behaviour; no live polling was reintroduced.

## v1.0.0-rc18 Downloads page status guidance
- Adds a clear note to the Downloads page header: live active-download progress belongs in the bottom status bar/toolbar indicator.
- Keeps the Downloads page stable/manual-refresh to avoid reintroducing the RC4 live-refresh glitch that could interfere with downloads.
- No download architecture changes: Browser owns active transfer; Download Guard reviews completed files after transfer.


## 1.0.0-rc18

Removes default bookmarks from the favourites bar and adds safe Sentinel Wallet integration status/open plumbing. No live download path changes.


## RC20 Wallet passphrase escrow awareness
Browser can report Sentinel Wallet optional encrypted passphrase escrow status, but Browser never receives or stores wallet passphrases. Escrow is handled only by Wallet as explicit user-approved AEGIS Vault / Password Vault handoff.


## v1.0.1 Wallet Transaction + DApp Login Bridge

Sentinel Browser now detects the Sentinel Wallet v1.0.1 transaction/dApp-login bridge and can create local request-response records for dApp login and transaction signing. Browser never stores wallet seeds, private keys, passphrases, or signing material. Browser does not sign or broadcast transactions itself; Wallet remains the signing authority and returns public signatures/signed payloads only after explicit user approval.


## v1.0.3 Homepage Scalable / Persistent City Patch

- Makes the packaged SentinelOS Browser Home page fluid across small windows, laptop screens, full-screen layouts, narrow widths, and short-height browser windows.
- Changes the homepage shell to allow scrolling instead of clipping when the browser window is small.
- Stores the selected weather city as a persistent local default with explicit locked/default keys.
- Keeps the default city until the user selects a different city or clears Browser local data.
- Preserves the local-first CSP/security marker and Browser Wallet/Download Guard boundaries.


## v1.0.4 Homepage Wider Window / Melbourne Default City Patch

- Widens the default Browser window from `1180x760` to `1280x760` for a roomier SentinelOS homepage deck.
- Keeps the selected homepage weather city as the local default across Browser restarts using the existing locked localStorage keys.
- Changes the fresh-install / no-city-selected fallback from Sydney to `Melbourne, VIC`.
- Repairs invalid/corrupted weather-city fallback so it also returns to Melbourne rather than Sydney.
- Preserves local-first homepage security boundaries: no direct Vault/app/database launchers and no Browser wallet-secret storage.


## v1.1.0 Blockchain / Tor compatibility patch

- Adds a TOR toolbar switch left of the address/search bar. Once local Tor is installed and listening on socks5://127.0.0.1:9050, the switch routes normal web pages through Tor without editing settings.
- Moves the HTTPS/security indicator into the address/search bar as an embedded entry icon.
- Adds a minimal injected blockchain provider bridge (`window.ethereum`, `window.sentinelEthereum`, `window.sentinelSolana`) that forwards dApp login/sign/transaction requests to Sentinel Wallet for explicit user approval.
- Browser remains unable to read/store seed phrases, private keys, wallet passphrases, signing material, or card data.


## v1.1.1 GUI installer option awareness

Browser and Download Guard are treated as an inseparable install pair. The v1.1.1 master installer can enable Basic Browser only, optional Tor support, optional blockchain provider injection, and optional Wallet install/integration. Browser-side Wallet toolbar packing now respects the local `wallet_integration_enabled` preference; blockchain provider injection and the TOR switch remain config-controlled.


## v1.1.2 - WalletConnect / Multi-chain / Tor Identity Patch
- Adds Tor top-menu controls and right-click TOR button menu with Change Tor Identity.
- Adds ControlPort/AuthCookie NEWNYM support where local Tor permits it.
- Adds WalletConnect URI capture foundation and forwards pairing requests to Sentinel Wallet.
- Expands provider shims to window.solana and BTC/PSBT foundation while preserving Browser no-secret/no-sign/no-broadcast doctrine.


## v1.1.3 Tor UX / Wallet Approval Hotfix
- Tor status and test panels are user-readable AEGIS-themed GUI dialogs, not JSON/console-style windows.
- TOR button shows active Tor exit country when available, with setup/off/on fallback labels.
- WalletConnect requests auto-open Sentinel Wallet and Wallet shows an Approve / Reject prompt.


## v1.1.12 ETH/SOL Provider Discovery Repair
Restores dApp wallet detection after the manual-approval patch. Fixes malformed Solana Wallet Standard feature key syntax and keeps provider discovery always visible while approval/signing remains manual-user-action gated.


### v1.1.13 — Uniswap ETH Popup Regression Repair

Keeps ETH/SOL provider discovery visible while preventing repeated ETH approval popups after an origin has already been approved. Repeated `eth_requestAccounts` and `wallet_requestPermissions` return the cached account/permission set for the current origin; unsupported methods reject cleanly without opening Wallet; and manual approval no longer uses long-lived `navigator.userActivation.hasBeenActive`.


## v1.1.16 Bookmark Folders Hotfix

- Adds user-created bookmark folders from the Bookmarks top menu.
- The bookmark editor now includes an optional Folder field.
- Bookmarks menu groups saved pages into folder submenus.
- The favourites/bookmarks toolbar shows folder buttons that open folder menus.
- Preserves legacy flat bookmarks, Tor button restore behavior, Download Guard hardening, and Wallet baseline safety.

## v1.1.17 — Bookmark Drag / Right-Click Toolbar Hotfix
- Adds drag-to-reorder for top-level bookmark buttons in the bookmarks toolbar.
- Adds drag-to-folder behavior so a bookmark button can be dropped onto a folder button.
- Adds right-click quick actions on the bookmarks toolbar and bookmark buttons for Add Bookmark, Add Bookmark Folder, Show/Hide Toolbar, status, edit, delete, copy, and move-to-folder.
- Preserves v1.1.22 bookmark folder storage, v1.1.21 TOR button restore, v1.1.20 security hardening, Download Guard 1.0.1, and Wallet 1.1.14.

## v1.1.18 — Banking Mode Hotfix

- Adds **Banking Mode** beside Private Mode in the toolbar and File menu.
- Adds `sentinel-browser --banking` and `sentinel-browser-banking` launch paths.
- Banking Mode uses separate WebKit banking data/cache directories and clears them on start/exit by default.
- Banking Mode disables Sentinel Wallet, blockchain provider injection, native provider requests, and WalletConnect surfaces for the banking session only.
- Preserves v1.1.23 bookmark drag toolbar, v1.1.22 bookmark folders, v1.1.21 Tor button restore, v1.1.20 security cleanup, Download Guard 1.0.1, and Wallet 1.1.14.

## v1.1.19 — Bookmark Toolbar Regression + Banking Icon Hotfix

- Restores/hardens bookmark toolbar drag-to-reorder.
- Restores/hardens drag bookmark onto folder button to move it into that folder.
- Restores/hardens right-click bookmark and bookmarks-toolbar quick menus.
- Adds text/UTF8 drag target fallback beside the Sentinel private drag MIME target.
- Replaces the BANK/BANKING toolbar text with a compact 🏦 Banking Mode icon-style button.
- Preserves Banking Mode, Tor restore, bookmark folders, Download Guard, and Wallet baseline behaviour.
