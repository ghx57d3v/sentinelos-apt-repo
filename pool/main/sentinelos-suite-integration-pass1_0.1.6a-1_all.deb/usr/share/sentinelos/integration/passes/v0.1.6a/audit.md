# SentinelOS v0.1.6a Batch 1 Script and Package Audit

## Scope

Reviewed uploaded Batch 1 artifacts before integration:

- `Sentinel Calendar.zip`
- `sentinel_calculator_v1_1_0(1).zip`
- `sentinel_diary_v1_0_1(1).zip`
- `sentinel_program_manager.zip` reviewed but held from this pass

## Integration decision

Integrated in this pass:

| Program | Package | Version | Decision |
|---:|---|---:|---|
| 103 | sentinel-calculator | 1.1.0-1 | integrate/adopt |
| 104 | sentinel-calendar | 1.0.1-1 | integrate/adopt |
| 105 | sentinel-diary | 1.0.1-1 | integrate/adopt |

Held from this pass:

| Program | Package | Version | Reason |
|---:|---|---:|---|
| 101 | sentinel-program-manager | 1.0.1-1 | core package-management surface; postinst mutates system MIME defaults; package uses `/usr/local/bin`; contains `__pycache__`; integrate separately |

Not provided in this upload:

| Program | Package |
|---:|---|
| 108 | sentinel-system-monitor |

## General checks performed

- `.deb` metadata read with `dpkg-deb -f`.
- Control/maintainer scripts extracted with `dpkg-deb -e`.
- Payload paths listed with `dpkg-deb -c`.
- Python source syntax checked with `python3 -m py_compile` where source was present.
- Source/install scripts inspected for high-risk patterns: broad destructive removal, `systemctl`, cron, `/etc/os-release`, `sources.list`, network fetch tools, filesystem formatting, cryptsetup, and unsafe recursive permission changes.

## Per-package findings

### Sentinel Calculator 1.1.0-1

Result: **accepted for Pass 1**.

Notes:

- Maintainer scripts refresh desktop/menu/icon caches only.
- User setup refuses to run as root.
- User cleanup removes only Sentinel Calculator user-local paths under `$HOME`.
- Python source compiles.
- Contains optional online currency/crypto/stock refresh via Python `urllib`; UI labels indicate manual refresh and local cache. This is not automatic background network use, but it should be documented as an optional online feature.

### Sentinel Calendar 1.0.1-1

Result: **accepted for Pass 1**.

Notes:

- Maintainer scripts refresh desktop/icon caches only.
- Command wrappers are under `/usr/bin` and execute the packaged app under `/opt/sentinel-calendar`.
- Reminder autostart is not enabled by package install; user must run `sentinel-calendar-autostart-reminders` explicitly.
- Python source compiles.
- `os.system` use is limited to user launcher trust/desktop-database updates inside launcher helper flow.

### Sentinel Diary 1.0.1-1

Result: **accepted for Pass 1**.

Notes:

- Maintainer scripts are small and limited to desktop/icon cache refresh.
- Python source compiles.
- Uses `python3-cryptography` dependency for encrypted local storage.
- Runtime intentionally patches socket creation to block network use.
- Contains packaged `__pycache__`; not ideal, but not a blocker for this pass. Prefer stripping bytecode in a future polish rebuild.

### Sentinel Program Manager 1.0.1-1

Result: **reviewed, held from Pass 1**.

Notes:

- The app itself includes appropriate safety language around package operations, protected packages, and explicit repository/internet enablement.
- The package `postinst` writes `/etc/xdg/mimeapps.list` to assign `.deb` and archive file types to Program Manager.
- The payload places the command in `/usr/local/bin` and includes Python `__pycache__`.
- Because Program Manager is itself a package-management/control surface, integrate it in a separate, explicit patch rather than blending it into the first normal-app pass.
