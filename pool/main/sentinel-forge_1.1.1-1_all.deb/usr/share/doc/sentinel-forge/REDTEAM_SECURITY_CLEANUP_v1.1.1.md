# F.O.R.G.E v1.1.1 Redteam Security Cleanup

Hardens archive extraction, package/release builders, output publishing, USB target validation, and postinst desktop handling.
