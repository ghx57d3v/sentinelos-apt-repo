#!/usr/bin/env python3
"""
Sentinel Contacts — Program 111
v1.0.2 GUI Startup / Rendering Stability Hotfix

Local-first contact manager for SentinelOS/AEGIS.
No network calls. No telemetry. SQLite only.
"""
from __future__ import annotations

import argparse
import csv
import datetime as _dt
import json
import os
import shutil
import stat
import sqlite3
import sys
import tempfile
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

APP_NAME = "Sentinel Contacts"
APP_ID = "sentinel-contacts"
PROGRAM_NUMBER = "111"
VERSION = "1.0.2"
DEBIAN_VERSION = "1.0.2-1"
SCHEMA_VERSION = 5
DEFAULT_CODE_PREFIX = "CON"
BRIDGE_APPS = ["jobs", "wallet", "password-vault", "documents", "notes"]

SENTINEL_GOLD = "#E19B00"
SENTINEL_CYAN = "#03C8FF"
AEGIS_BG = "#05090C"
AEGIS_PANEL = "#101B24"
AEGIS_PANEL_2 = "#152532"
AEGIS_TEXT = "#D7E1EA"
AEGIS_MUTED = "#A9B6C4"


def now_iso() -> str:
    return _dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def today_iso() -> str:
    return _dt.date.today().isoformat()


def data_dir() -> Path:
    override = os.environ.get("SENTINEL_CONTACTS_HOME")
    if override:
        return Path(override).expanduser()
    xdg = os.environ.get("XDG_DATA_HOME")
    base = Path(xdg).expanduser() if xdg else Path.home() / ".local" / "share"
    return base / "sentinel-contacts"


def db_path() -> Path:
    override = os.environ.get("SENTINEL_CONTACTS_DB")
    if override:
        return Path(override).expanduser()
    return data_dir() / "contacts.sqlite3"


def config_dir() -> Path:
    xdg = os.environ.get("XDG_CONFIG_HOME")
    base = Path(xdg).expanduser() if xdg else Path.home() / ".config"
    return base / "sentinel-contacts"


MAX_IMPORT_FILE_BYTES = 8 * 1024 * 1024
MAX_IMPORT_ROWS = 10000
MAX_VCARD_BLOCKS = 10000
MAX_FIELD_CHARS = 4096
MAX_NOTE_CHARS = 65536
MAX_SQLITE_BYTES = 256 * 1024 * 1024
CSV_FORMULA_PREFIXES = ("=", "+", "-", "@", "\t", "\r")


def _geteuid() -> Optional[int]:
    get = getattr(os, "geteuid", None)
    if not get:
        return None
    try:
        return int(get())
    except Exception:
        return None


def _root_write_allowed() -> bool:
    return os.environ.get("SENTINEL_CONTACTS_ALLOW_ROOT_WRITE") == "1"


def enforce_not_root(command: str = "profile access") -> None:
    if _geteuid() == 0 and not _root_write_allowed():
        raise SystemExit(
            f"Refusing Sentinel Contacts {command} as root. "
            "Run as the owning desktop user, or set SENTINEL_CONTACTS_ALLOW_ROOT_WRITE=1 only for controlled maintenance."
        )


def _abs_user_path(path: Path) -> Path:
    return path.expanduser().absolute()


def _iter_existing_components(path: Path) -> Iterable[Path]:
    path = _abs_user_path(path)
    current = Path(path.anchor or ".")
    for part in path.parts[1:] if path.anchor else path.parts:
        current = current / part
        yield current


def _refuse_symlink_components(path: Path, label: str, include_leaf: bool = True) -> None:
    path = _abs_user_path(path)
    components = list(_iter_existing_components(path))
    if not include_leaf and components:
        components = components[:-1]
    for comp in components:
        try:
            st = comp.lstat()
        except FileNotFoundError:
            continue
        if stat.S_ISLNK(st.st_mode):
            raise SystemExit(f"Refusing {label}: symlink path component is not allowed: {comp}")
        if stat.S_ISCHR(st.st_mode) or stat.S_ISBLK(st.st_mode) or stat.S_ISFIFO(st.st_mode) or stat.S_ISSOCK(st.st_mode):
            raise SystemExit(f"Refusing {label}: special file path component is not allowed: {comp}")


def ensure_parent(path: Path, *, private: bool = True, label: str = "output path") -> None:
    path = _abs_user_path(path)
    _refuse_symlink_components(path.parent, label, include_leaf=True)
    path.parent.mkdir(parents=True, exist_ok=True)
    _refuse_symlink_components(path.parent, label, include_leaf=True)
    if private:
        try:
            path.parent.chmod(0o700)
        except PermissionError:
            pass


def refuse_unsafe_leaf(path: Path, label: str = "path") -> Path:
    path = _abs_user_path(path)
    _refuse_symlink_components(path, label, include_leaf=True)
    return path


def refuse_unsafe_input_file(path: Path, label: str, max_bytes: Optional[int] = None) -> Path:
    path = refuse_unsafe_leaf(path, label)
    if not path.exists() or not path.is_file():
        raise SystemExit(f"Refusing {label}: file not found: {path}")
    if max_bytes is not None and path.stat().st_size > max_bytes:
        raise SystemExit(f"Refusing {label}: file is too large ({path.stat().st_size} bytes; max {max_bytes})")
    return path


def atomic_write_text(path: Path, text: str, *, mode: int = 0o600, label: str = "output path") -> Path:
    path = _abs_user_path(path)
    ensure_parent(path, private=(mode & 0o077) == 0, label=label)
    if path.is_symlink():
        raise SystemExit(f"Refusing {label}: output target is a symlink: {path}")
    fd, tmp_name = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=str(path.parent), text=True)
    tmp = Path(tmp_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as f:
            f.write(text)
            f.flush()
            os.fsync(f.fileno())
        os.chmod(tmp, mode)
        os.replace(tmp, path)
    finally:
        try:
            if tmp.exists():
                tmp.unlink()
        except Exception:
            pass
    return path


def atomic_write_json(path: Path, payload: Any, *, mode: int = 0o600, label: str = "JSON output") -> Path:
    return atomic_write_text(path, json.dumps(payload, indent=2), mode=mode, label=label)


def _csv_safe(value: Any) -> Any:
    if value is None:
        return ""
    text = str(value)
    if text.startswith(CSV_FORMULA_PREFIXES):
        return "'" + text
    return text


def _csv_safe_row(row: Dict[str, Any]) -> Dict[str, Any]:
    return {k: _csv_safe(v) for k, v in row.items()}


def open_safe_csv_writer(path: Path, fieldnames: List[str], *, label: str = "CSV output"):
    path = _abs_user_path(path)
    ensure_parent(path, private=True, label=label)
    if path.is_symlink():
        raise SystemExit(f"Refusing {label}: output target is a symlink: {path}")
    fd, tmp_name = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=str(path.parent), text=True)
    f = os.fdopen(fd, "w", newline="", encoding="utf-8")
    writer = csv.DictWriter(f, fieldnames=fieldnames)
    writer.writeheader()
    return path, Path(tmp_name), f, writer


def finish_atomic_csv(path: Path, tmp: Path, f: Any, *, mode: int = 0o600) -> None:
    try:
        f.flush()
        os.fsync(f.fileno())
    finally:
        f.close()
    os.chmod(tmp, mode)
    os.replace(tmp, path)


def _clean_field(value: Any, *, field: str = "field", limit: int = MAX_FIELD_CHARS) -> str:
    text = str(value or "").replace("\x00", "").strip()
    if len(text) > limit:
        raise SystemExit(f"Refusing import: {field} is too long ({len(text)} chars; max {limit})")
    return text


def _safe_int(value: Any, default: int, minimum: int, maximum: int, field: str) -> int:
    if value in (None, ""):
        return default
    try:
        parsed = int(value)
    except Exception:
        raise SystemExit(f"Refusing import: {field} must be an integer")
    if not minimum <= parsed <= maximum:
        raise SystemExit(f"Refusing import: {field} must be between {minimum} and {maximum}")
    return parsed


def validate_sqlite_backup_path(path: Path) -> Path:
    path = refuse_unsafe_input_file(path, "SQLite backup", MAX_SQLITE_BYTES)
    if path.suffix.lower() not in (".sqlite3", ".sqlite", ".db"):
        raise SystemExit("Refusing restore: backup must use .sqlite3, .sqlite, or .db suffix")
    return path



SCHEMA_SQL = f"""
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS contacts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT UNIQUE NOT NULL,
    full_name TEXT NOT NULL,
    preferred_name TEXT DEFAULT '',
    contact_type TEXT DEFAULT 'person',
    organization TEXT DEFAULT '',
    role_title TEXT DEFAULT '',
    phone TEXT DEFAULT '',
    alt_phone TEXT DEFAULT '',
    email TEXT DEFAULT '',
    alt_email TEXT DEFAULT '',
    address TEXT DEFAULT '',
    website TEXT DEFAULT '',
    birthday TEXT DEFAULT '',
    tags TEXT DEFAULT '',
    priority INTEGER DEFAULT 3,
    trust_level INTEGER DEFAULT 3,
    status TEXT DEFAULT 'active',
    notes TEXT DEFAULT '',
    archived INTEGER DEFAULT 0,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_contacts_code ON contacts(code);
CREATE INDEX IF NOT EXISTS idx_contacts_name ON contacts(full_name);
CREATE INDEX IF NOT EXISTS idx_contacts_email ON contacts(email);
CREATE INDEX IF NOT EXISTS idx_contacts_phone ON contacts(phone);
CREATE INDEX IF NOT EXISTS idx_contacts_org ON contacts(organization);
CREATE INDEX IF NOT EXISTS idx_contacts_archived ON contacts(archived);
CREATE TABLE IF NOT EXISTS organizations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    org_type TEXT DEFAULT '',
    phone TEXT DEFAULT '',
    email TEXT DEFAULT '',
    website TEXT DEFAULT '',
    address TEXT DEFAULT '',
    notes TEXT DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_org_name ON organizations(name);
CREATE TABLE IF NOT EXISTS contact_actions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    contact_id INTEGER NOT NULL,
    action_type TEXT NOT NULL,
    label TEXT DEFAULT '',
    target TEXT DEFAULT '',
    details TEXT DEFAULT '',
    bridge_app TEXT DEFAULT '',
    due_date TEXT DEFAULT '',
    completed INTEGER DEFAULT 0,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY(contact_id) REFERENCES contacts(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_actions_contact ON contact_actions(contact_id);
CREATE INDEX IF NOT EXISTS idx_actions_bridge ON contact_actions(bridge_app);
CREATE TABLE IF NOT EXISTS bridge_links (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    contact_id INTEGER NOT NULL,
    bridge_app TEXT NOT NULL,
    reference_type TEXT DEFAULT '',
    reference_value TEXT DEFAULT '',
    quick_fill_label TEXT DEFAULT '',
    notes TEXT DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY(contact_id) REFERENCES contacts(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_bridge_contact ON bridge_links(contact_id);
CREATE INDEX IF NOT EXISTS idx_bridge_app ON bridge_links(bridge_app);
CREATE TABLE IF NOT EXISTS quick_fill_templates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    template_name TEXT UNIQUE NOT NULL,
    bridge_app TEXT DEFAULT '',
    body TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_quick_fill_template_app ON quick_fill_templates(bridge_app);
CREATE TABLE IF NOT EXISTS contact_groups (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    group_type TEXT DEFAULT 'custom',
    description TEXT DEFAULT '',
    color TEXT DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_contact_groups_name ON contact_groups(name);
CREATE TABLE IF NOT EXISTS contact_group_members (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    group_id INTEGER NOT NULL,
    contact_id INTEGER NOT NULL,
    role TEXT DEFAULT '',
    notes TEXT DEFAULT '',
    created_at TEXT NOT NULL,
    UNIQUE(group_id, contact_id),
    FOREIGN KEY(group_id) REFERENCES contact_groups(id) ON DELETE CASCADE,
    FOREIGN KEY(contact_id) REFERENCES contacts(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_group_members_group ON contact_group_members(group_id);
CREATE INDEX IF NOT EXISTS idx_group_members_contact ON contact_group_members(contact_id);
CREATE TABLE IF NOT EXISTS contact_relationships (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    contact_id INTEGER NOT NULL,
    related_contact_id INTEGER NOT NULL,
    relationship_type TEXT DEFAULT 'related',
    notes TEXT DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    UNIQUE(contact_id, related_contact_id, relationship_type),
    FOREIGN KEY(contact_id) REFERENCES contacts(id) ON DELETE CASCADE,
    FOREIGN KEY(related_contact_id) REFERENCES contacts(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_relationship_contact ON contact_relationships(contact_id);
CREATE INDEX IF NOT EXISTS idx_relationship_related ON contact_relationships(related_contact_id);
CREATE TABLE IF NOT EXISTS contact_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    contact_id INTEGER NOT NULL,
    event_type TEXT NOT NULL DEFAULT 'reminder',
    title TEXT NOT NULL,
    event_date TEXT NOT NULL,
    event_time TEXT DEFAULT '',
    location TEXT DEFAULT '',
    notes TEXT DEFAULT '',
    status TEXT DEFAULT 'scheduled',
    source TEXT DEFAULT 'manual',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY(contact_id) REFERENCES contacts(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_contact_events_contact ON contact_events(contact_id);
CREATE INDEX IF NOT EXISTS idx_contact_events_date ON contact_events(event_date);
CREATE INDEX IF NOT EXISTS idx_contact_events_type ON contact_events(event_type);
CREATE INDEX IF NOT EXISTS idx_contact_events_status ON contact_events(status);
CREATE TABLE IF NOT EXISTS contact_import_batches (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_format TEXT NOT NULL DEFAULT 'unknown',
    source_path TEXT DEFAULT '',
    contacts_imported INTEGER DEFAULT 0,
    contacts_skipped INTEGER DEFAULT 0,
    notes TEXT DEFAULT '',
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_contact_import_batches_created ON contact_import_batches(created_at);
CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    entity TEXT NOT NULL,
    entity_id INTEGER DEFAULT 0,
    action TEXT NOT NULL,
    details TEXT DEFAULT '',
    created_at TEXT NOT NULL
);
"""


def connect(path: Optional[Path] = None) -> sqlite3.Connection:
    p = _abs_user_path(path or db_path())
    ensure_parent(p, private=True, label="contacts database")
    if p.is_symlink():
        raise SystemExit(f"Refusing contacts database: database path is a symlink: {p}")
    conn = sqlite3.connect(str(p))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    try:
        os.chmod(p, 0o600)
    except (FileNotFoundError, PermissionError):
        pass
    return conn


def init_db(conn: sqlite3.Connection) -> None:
    conn.executescript(SCHEMA_SQL)
    conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES('app_name',?)", (APP_NAME,))
    conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES('version',?)", (VERSION,))
    conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES('program_number',?)", (PROGRAM_NUMBER,))
    conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES('schema_version',?)", (str(SCHEMA_VERSION),))
    conn.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('code_prefix',?)", (DEFAULT_CODE_PREFIX,))
    conn.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('quick_fill_format',?)", ("name,email,phone,organization,role",))
    conn.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('default_bridge_app',?)", ("jobs",))
    conn.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('event_due_days',?)", ("30",))
    seed_quick_fill_templates(conn)
    conn.commit()


def db() -> sqlite3.Connection:
    conn = connect()
    init_db(conn)
    return conn


def audit(conn: sqlite3.Connection, entity: str, entity_id: int, action: str, details: str = "") -> None:
    conn.execute(
        "INSERT INTO audit_log(entity,entity_id,action,details,created_at) VALUES(?,?,?,?,?)",
        (entity, entity_id, action, details, now_iso()),
    )


def get_setting(conn: sqlite3.Connection, key: str, default: str = "") -> str:
    row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    return row["value"] if row else default


def set_setting(conn: sqlite3.Connection, key: str, value: str) -> None:
    conn.execute("INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)", (key, value))
    audit(conn, "settings", 0, f"set:{key}", value)
    conn.commit()


def next_code(conn: sqlite3.Connection, prefix: Optional[str] = None) -> str:
    prefix = (prefix or get_setting(conn, "code_prefix", DEFAULT_CODE_PREFIX) or DEFAULT_CODE_PREFIX).upper().strip()
    rows = conn.execute("SELECT code FROM contacts WHERE code LIKE ?", (prefix + "-%",)).fetchall()
    max_n = 0
    for row in rows:
        code = row["code"] or ""
        try:
            tail = code.rsplit("-", 1)[1]
            if tail.isdigit():
                max_n = max(max_n, int(tail))
        except Exception:
            pass
    return f"{prefix}-{max_n + 1:04d}"


def parse_contact_identifier(conn: sqlite3.Connection, ident: str) -> Optional[sqlite3.Row]:
    ident = ident.strip()
    if not ident:
        return None
    if ident.isdigit():
        row = conn.execute("SELECT * FROM contacts WHERE id=?", (int(ident),)).fetchone()
        if row:
            return row
    row = conn.execute("SELECT * FROM contacts WHERE code=? COLLATE NOCASE", (ident,)).fetchone()
    if row:
        return row
    row = conn.execute("SELECT * FROM contacts WHERE full_name=? COLLATE NOCASE", (ident,)).fetchone()
    if row:
        return row
    row = conn.execute("SELECT * FROM contacts WHERE email=? COLLATE NOCASE", (ident,)).fetchone()
    if row:
        return row
    row = conn.execute("SELECT * FROM contacts WHERE phone=?", (ident,)).fetchone()
    return row




def seed_quick_fill_templates(conn: sqlite3.Connection) -> None:
    """Seed local-only app-specific quick-fill templates.

    These are simple copy/paste bodies, not external integrations. They make the
    future right-click/action layer deterministic while preserving the local-only
    doctrine.
    """
    t = now_iso()
    templates = {
        "jobs": "{full_name}\nOrganization: {organization}\nRole: {role_title}\nEmail: {email}\nPhone: {phone}\nNotes: {notes}",
        "wallet": "Emergency/contact card for {full_name}\nPhone: {phone}\nEmail: {email}\nRelationship/Role: {role_title}\nOrganization: {organization}",
        "password-vault": "Vault contact/vendor reference\nName: {full_name}\nOrg: {organization}\nWebsite: {website}\nEmail: {email}\nPhone: {phone}\nNo secrets included.",
        "documents": "Recipient block\n{full_name}\n{role_title}\n{organization}\n{address}\nEmail: {email}\nPhone: {phone}",
        "notes": "# {full_name}\n- Org: {organization}\n- Role: {role_title}\n- Email: {email}\n- Phone: {phone}\n- Tags: {tags}\n\nNotes:\n{notes}",
        "text-draft": "Hi {preferred_or_full}, ",
        "email-draft": "To: {email}\nSubject: Follow-up\n\nHi {preferred_or_full},\n\n",
    }
    for name, body in templates.items():
        bridge_app = name if name in BRIDGE_APPS else ""
        conn.execute(
            "INSERT OR IGNORE INTO quick_fill_templates(template_name,bridge_app,body,created_at,updated_at) VALUES(?,?,?,?,?)",
            (name, bridge_app, body, t, t),
        )


def _template_values(row: sqlite3.Row) -> Dict[str, str]:
    d = contact_to_dict(row)
    preferred = d.get("preferred_name") or d.get("full_name") or ""
    values = {k: str(v or "") for k, v in d.items()}
    values["preferred_or_full"] = preferred
    values["quick_fill_default"] = " | ".join([p for p in [d.get("full_name",""), d.get("organization",""), d.get("role_title",""), d.get("email",""), d.get("phone","")] if p])
    return values


def app_quick_fill(conn: sqlite3.Connection, ident: str, app: str) -> str:
    row = parse_contact_identifier(conn, ident)
    if not row:
        raise SystemExit(f"Contact not found: {ident}")
    app = (app or "default").strip().lower()
    if app in ("default", "generic"):
        return quick_fill(conn, ident, "default")
    if app in ("email", "phone", "vcard-lite"):
        return quick_fill(conn, ident, app)
    tpl = conn.execute("SELECT body FROM quick_fill_templates WHERE template_name=? COLLATE NOCASE", (app,)).fetchone()
    if not tpl:
        raise SystemExit(f"Unknown quick-fill template: {app}")
    return tpl["body"].format_map(_SafeFormatDict(_template_values(row)))


class _SafeFormatDict(dict):
    def __missing__(self, key: str) -> str:
        return ""


def contact_action_menu(conn: sqlite3.Connection, ident: str) -> Dict[str, Any]:
    row = parse_contact_identifier(conn, ident)
    if not row:
        raise SystemExit(f"Contact not found: {ident}")
    templates = [r["template_name"] for r in conn.execute("SELECT template_name FROM quick_fill_templates ORDER BY template_name COLLATE NOCASE").fetchall()]
    return {
        "contact": contact_to_dict(row),
        "local_only": True,
        "network_sender_enabled": False,
        "copy_actions": ["quick-fill", "email", "phone", "vcard-lite"] + templates,
        "bridge_actions": [
            {"app": app, "action": f"prepare-{app}-link", "direct_external_write_enabled": False}
            for app in BRIDGE_APPS
        ],
        "future_actions_disabled": ["send-text", "send-email"],
        "notes": "Right-click actions prepare/copy local data only. They do not call external apps or networks in this build.",
    }


def prepare_contact_action(conn: sqlite3.Connection, ident: str, app: str, action: str = "quick-fill", target: str = "") -> sqlite3.Row:
    app = (app or "").strip().lower()
    if app not in BRIDGE_APPS and app not in ("text-draft", "email-draft"):
        raise SystemExit(f"Action app must be one of: {', '.join(BRIDGE_APPS + ['text-draft','email-draft'])}")
    ns = argparse.Namespace(
        contact=ident,
        type="prepare-action",
        label=f"Prepare {app} {action}",
        target=target,
        details=f"Prepared local-only contact action for {app}: {action}. No external write or network send performed.",
        bridge_app=app if app in BRIDGE_APPS else "",
        due_date="",
    )
    return add_action(conn, ns)


def export_quickfill_json(conn: sqlite3.Connection, out: Path, include_archived: bool = False) -> Path:
    ensure_parent(out)
    rows = list_contacts(conn, include_archived=include_archived, limit=100000)
    formats = ["default", "email", "phone", "vcard-lite", "jobs", "wallet", "password-vault", "documents", "notes", "text-draft", "email-draft"]
    payload = {
        "app": APP_NAME,
        "version": VERSION,
        "exported_at": now_iso(),
        "local_only": True,
        "telemetry": False,
        "direct_external_write_enabled": False,
        "formats": formats,
        "contacts": [],
    }
    for row in rows:
        card = contact_to_dict(row)
        card["quick_fill"] = {fmt: app_quick_fill(conn, row["code"], fmt) for fmt in formats}
        payload["contacts"].append(card)
    atomic_write_json(out, payload, label="JSON export")
    return _abs_user_path(out)


def export_app_bridge_json(conn: sqlite3.Connection, app: str, out: Path) -> Path:
    app = app.strip().lower()
    if app not in BRIDGE_APPS:
        raise SystemExit(f"Bridge app must be one of: {', '.join(BRIDGE_APPS)}")
    ensure_parent(out)
    contacts = [contact_to_dict(r) for r in list_contacts(conn, include_archived=False, limit=100000)]
    payload_contacts = []
    for c in contacts:
        payload_contacts.append({
            "contact": c,
            "quick_fill": app_quick_fill(conn, c["code"], app),
            "bridge_app": app,
            "direct_external_write_enabled": False,
        })
    links = conn.execute("""
        SELECT b.*, c.code, c.full_name, c.email, c.phone, c.organization, c.role_title
        FROM bridge_links b JOIN contacts c ON c.id=b.contact_id
        WHERE b.bridge_app=?
        ORDER BY c.full_name
    """, (app,)).fetchall()
    payload = {
        "app": APP_NAME,
        "version": VERSION,
        "bridge_app": app,
        "bridge_contract_version": "0.3.0",
        "exported_at": now_iso(),
        "local_only": True,
        "network_used": False,
        "telemetry": False,
        "direct_external_write_enabled": False,
        "contacts": payload_contacts,
        "links": [dict(r) for r in links],
    }
    atomic_write_json(out, payload, label="JSON export")
    return _abs_user_path(out)

def add_contact(conn: sqlite3.Connection, args: argparse.Namespace) -> sqlite3.Row:
    code = args.code or next_code(conn, args.code_prefix)
    t = now_iso()
    conn.execute(
        """
        INSERT INTO contacts(code,full_name,preferred_name,contact_type,organization,role_title,phone,alt_phone,email,alt_email,address,website,birthday,tags,priority,trust_level,status,notes,archived,created_at,updated_at)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """,
        (
            code,
            args.full_name,
            args.preferred_name or "",
            args.type or "person",
            args.organization or "",
            args.role or "",
            args.phone or "",
            args.alt_phone or "",
            args.email or "",
            args.alt_email or "",
            args.address or "",
            args.website or "",
            args.birthday or "",
            args.tags or "",
            int(args.priority or 3),
            int(args.trust_level or 3),
            args.status or "active",
            args.notes or "",
            0,
            t,
            t,
        ),
    )
    cid = int(conn.execute("SELECT last_insert_rowid()").fetchone()[0])
    if args.organization:
        add_org_if_missing(conn, args.organization)
    audit(conn, "contact", cid, "add", code)
    conn.commit()
    return conn.execute("SELECT * FROM contacts WHERE id=?", (cid,)).fetchone()


def add_org_if_missing(conn: sqlite3.Connection, name: str) -> None:
    name = (name or "").strip()
    if not name:
        return
    t = now_iso()
    conn.execute(
        "INSERT OR IGNORE INTO organizations(name,created_at,updated_at) VALUES(?,?,?)",
        (name, t, t),
    )


def update_contact(conn: sqlite3.Connection, ident: str, fields: Dict[str, Any]) -> sqlite3.Row:
    row = parse_contact_identifier(conn, ident)
    if not row:
        raise SystemExit(f"Contact not found: {ident}")
    allowed = {
        "full_name", "preferred_name", "contact_type", "organization", "role_title", "phone", "alt_phone",
        "email", "alt_email", "address", "website", "birthday", "tags", "priority", "trust_level", "status", "notes"
    }
    updates = {k: v for k, v in fields.items() if k in allowed and v is not None}
    if not updates:
        return row
    updates["updated_at"] = now_iso()
    sql = "UPDATE contacts SET " + ",".join([f"{k}=?" for k in updates]) + " WHERE id=?"
    conn.execute(sql, [updates[k] for k in updates] + [row["id"]])
    if updates.get("organization"):
        add_org_if_missing(conn, str(updates["organization"]))
    audit(conn, "contact", int(row["id"]), "update", ",".join(updates.keys()))
    conn.commit()
    return conn.execute("SELECT * FROM contacts WHERE id=?", (row["id"],)).fetchone()


def list_contacts(conn: sqlite3.Connection, query: str = "", include_archived: bool = False, limit: int = 100) -> List[sqlite3.Row]:
    clauses = []
    params: List[Any] = []
    if not include_archived:
        clauses.append("archived=0")
    if query:
        q = f"%{query}%"
        clauses.append("(code LIKE ? OR full_name LIKE ? OR preferred_name LIKE ? OR organization LIKE ? OR role_title LIKE ? OR phone LIKE ? OR email LIKE ? OR tags LIKE ?)")
        params.extend([q] * 8)
    where = " WHERE " + " AND ".join(clauses) if clauses else ""
    params.append(int(limit))
    return conn.execute(f"SELECT * FROM contacts{where} ORDER BY archived ASC, full_name COLLATE NOCASE ASC LIMIT ?", params).fetchall()


def contact_to_dict(row: sqlite3.Row) -> Dict[str, Any]:
    return {k: row[k] for k in row.keys()}


def _parse_date(value: str) -> Optional[_dt.date]:
    value = (value or "").strip()
    if not value:
        return None
    try:
        return _dt.date.fromisoformat(value[:10])
    except Exception:
        return None


def _days_until(value: str) -> Optional[int]:
    d = _parse_date(value)
    if not d:
        return None
    return (d - _dt.date.today()).days


def _next_birthday_date(birthday: str) -> Optional[_dt.date]:
    b = _parse_date(birthday)
    if not b:
        return None
    today = _dt.date.today()
    try:
        candidate = _dt.date(today.year, b.month, b.day)
    except ValueError:
        # Handles 29 Feb birthdays on non-leap years.
        candidate = _dt.date(today.year, 2, 28)
    if candidate < today:
        try:
            candidate = _dt.date(today.year + 1, b.month, b.day)
        except ValueError:
            candidate = _dt.date(today.year + 1, 2, 28)
    return candidate


def add_event(conn: sqlite3.Connection, args: argparse.Namespace) -> sqlite3.Row:
    contact = parse_contact_identifier(conn, args.contact)
    if not contact:
        raise SystemExit(f"Contact not found: {args.contact}")
    if not _parse_date(args.date):
        raise SystemExit("Event date must be YYYY-MM-DD")
    title = args.title or f"{args.type.title()} — {contact['full_name']}"
    t = now_iso()
    conn.execute(
        """INSERT INTO contact_events(contact_id,event_type,title,event_date,event_time,location,notes,status,source,created_at,updated_at)
        VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
        (contact["id"], args.type or "reminder", title, args.date[:10], args.time or "", args.location or "", args.notes or "", args.status or "scheduled", args.source or "manual", t, t),
    )
    eid = int(conn.execute("SELECT last_insert_rowid()").fetchone()[0])
    audit(conn, "event", eid, "add", f"contact={contact['code']} date={args.date[:10]}")
    conn.commit()
    return conn.execute("""
        SELECT e.*, c.code, c.full_name, c.email, c.phone, c.organization
        FROM contact_events e JOIN contacts c ON c.id=e.contact_id WHERE e.id=?
    """, (eid,)).fetchone()


def events_list(conn: sqlite3.Connection, ident: str = "", include_completed: bool = False, limit: int = 200) -> List[sqlite3.Row]:
    clauses: List[str] = []
    params: List[Any] = []
    if ident:
        contact = parse_contact_identifier(conn, ident)
        if not contact:
            raise SystemExit(f"Contact not found: {ident}")
        clauses.append("e.contact_id=?")
        params.append(contact["id"])
    if not include_completed:
        clauses.append("e.status NOT IN ('done','complete','completed','cancelled')")
    where = " WHERE " + " AND ".join(clauses) if clauses else ""
    params.append(int(limit))
    return conn.execute(f"""
        SELECT e.*, c.code, c.full_name, c.email, c.phone, c.organization
        FROM contact_events e JOIN contacts c ON c.id=e.contact_id
        {where}
        ORDER BY e.event_date ASC, e.event_time ASC, e.id DESC LIMIT ?
    """, params).fetchall()


def events_due(conn: sqlite3.Connection, days: int = 30, include_overdue: bool = True) -> List[Dict[str, Any]]:
    today = _dt.date.today()
    end = today + _dt.timedelta(days=int(days))
    rows = conn.execute("""
        SELECT e.*, c.code, c.full_name, c.email, c.phone, c.organization
        FROM contact_events e JOIN contacts c ON c.id=e.contact_id
        WHERE e.status NOT IN ('done','complete','completed','cancelled')
        ORDER BY e.event_date ASC, e.event_time ASC
    """).fetchall()
    out: List[Dict[str, Any]] = []
    for r in rows:
        d = _parse_date(r["event_date"])
        if not d:
            continue
        if (include_overdue and d <= end) or (today <= d <= end):
            item = dict(r)
            item["days_until"] = (d - today).days
            item["overdue"] = d < today
            out.append(item)
    return out


def birthday_report(conn: sqlite3.Connection, days: int = 60) -> List[Dict[str, Any]]:
    today = _dt.date.today()
    out: List[Dict[str, Any]] = []
    for r in conn.execute("SELECT * FROM contacts WHERE archived=0 AND birthday<>'' ORDER BY full_name COLLATE NOCASE").fetchall():
        nxt = _next_birthday_date(r["birthday"])
        if not nxt:
            continue
        delta = (nxt - today).days
        if delta <= int(days):
            item = contact_to_dict(r)
            item["next_birthday"] = nxt.isoformat()
            item["days_until"] = delta
            try:
                item["turning_age"] = nxt.year - _parse_date(r["birthday"]).year
            except Exception:
                item["turning_age"] = None
            out.append(item)
    out.sort(key=lambda x: (x.get("days_until", 99999), x.get("full_name", "")))
    return out


def export_events_csv(conn: sqlite3.Connection, out: Path) -> Path:
    rows = events_list(conn, include_completed=True, limit=100000)
    fields = ["id", "code", "full_name", "organization", "event_type", "title", "event_date", "event_time", "location", "status", "source", "notes", "created_at", "updated_at"]
    out, tmp, f, w = open_safe_csv_writer(out, fields, label="events CSV export")
    try:
        for r in rows:
            w.writerow(_csv_safe_row({k: (r[k] if k in r.keys() else "") for k in fields}))
        finish_atomic_csv(out, tmp, f)
    except Exception:
        f.close()
        try:
            tmp.unlink()
        except Exception:
            pass
        raise
    return out

def export_events_json(conn: sqlite3.Connection, out: Path) -> Path:
    payload = {
        "app": APP_NAME,
        "version": VERSION,
        "exported_at": now_iso(),
        "local_only": True,
        "network_used": False,
        "events": [dict(r) for r in events_list(conn, include_completed=True, limit=100000)],
        "birthday_report_365": birthday_report(conn, 365),
    }
    atomic_write_json(out, payload, label="JSON export")
    return _abs_user_path(out)


def export_calendar_csv(conn: sqlite3.Connection, out: Path, days: int = 365) -> Path:
    fields = ["subject", "start_date", "start_time", "end_date", "end_time", "location", "description", "contact_code", "contact_name", "event_type", "source"]
    today = _dt.date.today()
    safe_days = max(0, min(int(days), 3660))
    end = today + _dt.timedelta(days=safe_days)
    event_rows = events_due(conn, safe_days, include_overdue=False)
    birthday_rows = birthday_report(conn, safe_days)
    out, tmp, f, w = open_safe_csv_writer(out, fields, label="calendar CSV export")
    try:
        for r in event_rows:
            d = _parse_date(r["event_date"])
            if not d or d > end:
                continue
            w.writerow(_csv_safe_row({
                "subject": r.get("title") or f"Contact {r.get('event_type','event')}: {r.get('full_name','')}",
                "start_date": r.get("event_date", ""),
                "start_time": r.get("event_time", ""),
                "end_date": r.get("event_date", ""),
                "end_time": "",
                "location": r.get("location", ""),
                "description": r.get("notes", ""),
                "contact_code": r.get("code", ""),
                "contact_name": r.get("full_name", ""),
                "event_type": r.get("event_type", ""),
                "source": r.get("source", "manual"),
            }))
        for r in birthday_rows:
            w.writerow(_csv_safe_row({
                "subject": f"Birthday: {r.get('full_name','')}",
                "start_date": r.get("next_birthday", ""),
                "start_time": "",
                "end_date": r.get("next_birthday", ""),
                "end_time": "",
                "location": "",
                "description": f"Contact birthday from Sentinel Contacts. Code: {r.get('code','')}",
                "contact_code": r.get("code", ""),
                "contact_name": r.get("full_name", ""),
                "event_type": "birthday",
                "source": "birthday",
            }))
        finish_atomic_csv(out, tmp, f)
    except Exception:
        f.close()
        try:
            tmp.unlink()
        except Exception:
            pass
        raise
    return out

def dashboard(conn: sqlite3.Connection) -> Dict[str, Any]:
    active = conn.execute("SELECT COUNT(*) FROM contacts WHERE archived=0").fetchone()[0]
    archived = conn.execute("SELECT COUNT(*) FROM contacts WHERE archived=1").fetchone()[0]
    orgs = conn.execute("SELECT COUNT(*) FROM organizations").fetchone()[0]
    actions_open = conn.execute("SELECT COUNT(*) FROM contact_actions WHERE completed=0").fetchone()[0]
    links = conn.execute("SELECT COUNT(*) FROM bridge_links").fetchone()[0]
    groups = conn.execute("SELECT COUNT(*) FROM contact_groups").fetchone()[0]
    group_members_count = conn.execute("SELECT COUNT(*) FROM contact_group_members").fetchone()[0]
    relationships = conn.execute("SELECT COUNT(*) FROM contact_relationships").fetchone()[0]
    event_count = conn.execute("SELECT COUNT(*) FROM contact_events").fetchone()[0]
    scheduled_events = conn.execute("SELECT COUNT(*) FROM contact_events WHERE status NOT IN ('done','complete','completed','cancelled')").fetchone()[0]
    birthdays = conn.execute("SELECT code,full_name,birthday FROM contacts WHERE archived=0 AND birthday<>'' ORDER BY substr(birthday,6,5) LIMIT 10").fetchall()
    recent = conn.execute("SELECT code,full_name,organization,email,phone FROM contacts ORDER BY id DESC LIMIT 5").fetchall()
    bridge_counts = {app: conn.execute("SELECT COUNT(*) FROM bridge_links WHERE bridge_app=?", (app,)).fetchone()[0] for app in BRIDGE_APPS}
    return {
        "app": APP_NAME,
        "version": VERSION,
        "program_number": PROGRAM_NUMBER,
        "database": str(db_path()),
        "active_contacts": active,
        "archived_contacts": archived,
        "organizations": orgs,
        "open_actions": actions_open,
        "bridge_links": links,
        "groups": groups,
        "group_members": group_members_count,
        "relationships": relationships,
        "contact_events": event_count,
        "scheduled_events": scheduled_events,
        "events_due_30": len(events_due(conn, 30)),
        "birthdays_due_60": len(birthday_report(conn, 60)),
        "duplicate_groups": len(duplicate_report(conn)["duplicate_name_groups"]) + len(duplicate_report(conn)["duplicate_email_groups"]) + len(duplicate_report(conn)["duplicate_phone_groups"]),
        "bridge_counts": bridge_counts,
        "recent_contacts": [dict(r) for r in recent],
        "birthdays_recorded_sample": [dict(r) for r in birthdays],
        "local_only": True,
        "network_used": False,
        "telemetry": False,
    }


def add_action(conn: sqlite3.Connection, args: argparse.Namespace) -> sqlite3.Row:
    contact = parse_contact_identifier(conn, args.contact)
    if not contact:
        raise SystemExit(f"Contact not found: {args.contact}")
    t = now_iso()
    conn.execute(
        """INSERT INTO contact_actions(contact_id,action_type,label,target,details,bridge_app,due_date,completed,created_at,updated_at)
        VALUES(?,?,?,?,?,?,?,?,?,?)""",
        (contact["id"], args.type, args.label or "", args.target or "", args.details or "", args.bridge_app or "", args.due_date or "", 0, t, t),
    )
    aid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    audit(conn, "action", int(aid), "add", f"contact={contact['code']}")
    conn.commit()
    return conn.execute("SELECT * FROM contact_actions WHERE id=?", (aid,)).fetchone()


def actions_for(conn: sqlite3.Connection, ident: Optional[str] = None) -> List[sqlite3.Row]:
    if ident:
        contact = parse_contact_identifier(conn, ident)
        if not contact:
            raise SystemExit(f"Contact not found: {ident}")
        return conn.execute("SELECT a.*, c.code, c.full_name FROM contact_actions a JOIN contacts c ON c.id=a.contact_id WHERE contact_id=? ORDER BY a.completed ASC, a.due_date ASC, a.id DESC", (contact["id"],)).fetchall()
    return conn.execute("SELECT a.*, c.code, c.full_name FROM contact_actions a JOIN contacts c ON c.id=a.contact_id ORDER BY a.completed ASC, a.due_date ASC, a.id DESC LIMIT 200").fetchall()



def parse_group_identifier(conn: sqlite3.Connection, ident: str) -> Optional[sqlite3.Row]:
    ident = (ident or "").strip()
    if not ident:
        return None
    if ident.isdigit():
        row = conn.execute("SELECT * FROM contact_groups WHERE id=?", (int(ident),)).fetchone()
        if row:
            return row
    return conn.execute("SELECT * FROM contact_groups WHERE name=? COLLATE NOCASE", (ident,)).fetchone()


def group_add(conn: sqlite3.Connection, args: argparse.Namespace) -> sqlite3.Row:
    t = now_iso()
    conn.execute(
        """INSERT INTO contact_groups(name,group_type,description,color,created_at,updated_at)
        VALUES(?,?,?,?,?,?)
        ON CONFLICT(name) DO UPDATE SET group_type=excluded.group_type, description=excluded.description, color=excluded.color, updated_at=excluded.updated_at""",
        (args.name.strip(), args.type or "custom", args.description or "", args.color or "", t, t),
    )
    row = parse_group_identifier(conn, args.name)
    audit(conn, "group", int(row["id"]), "upsert", args.name)
    conn.commit()
    return row


def groups_list(conn: sqlite3.Connection) -> List[sqlite3.Row]:
    return conn.execute(
        """SELECT g.*, COUNT(m.contact_id) AS member_count
        FROM contact_groups g LEFT JOIN contact_group_members m ON m.group_id=g.id
        GROUP BY g.id ORDER BY g.name COLLATE NOCASE"""
    ).fetchall()


def group_add_contact(conn: sqlite3.Connection, group_ident: str, contact_ident: str, role: str = "", notes: str = "") -> sqlite3.Row:
    group = parse_group_identifier(conn, group_ident)
    if not group:
        raise SystemExit(f"Group not found: {group_ident}")
    contact = parse_contact_identifier(conn, contact_ident)
    if not contact:
        raise SystemExit(f"Contact not found: {contact_ident}")
    t = now_iso()
    conn.execute(
        """INSERT INTO contact_group_members(group_id,contact_id,role,notes,created_at)
        VALUES(?,?,?,?,?)
        ON CONFLICT(group_id, contact_id) DO UPDATE SET role=excluded.role, notes=excluded.notes""",
        (group["id"], contact["id"], role or "", notes or "", t),
    )
    audit(conn, "group_member", int(group["id"]), "add_contact", f"{group['name']}:{contact['code']}")
    conn.commit()
    return conn.execute(
        """SELECT m.*, g.name AS group_name, c.code, c.full_name, c.organization, c.email, c.phone
        FROM contact_group_members m
        JOIN contact_groups g ON g.id=m.group_id
        JOIN contacts c ON c.id=m.contact_id
        WHERE m.group_id=? AND m.contact_id=?""",
        (group["id"], contact["id"]),
    ).fetchone()


def group_members(conn: sqlite3.Connection, group_ident: str) -> List[sqlite3.Row]:
    group = parse_group_identifier(conn, group_ident)
    if not group:
        raise SystemExit(f"Group not found: {group_ident}")
    return conn.execute(
        """SELECT m.*, g.name AS group_name, c.code, c.full_name, c.organization, c.email, c.phone, c.status
        FROM contact_group_members m
        JOIN contact_groups g ON g.id=m.group_id
        JOIN contacts c ON c.id=m.contact_id
        WHERE g.id=? ORDER BY c.full_name COLLATE NOCASE""",
        (group["id"],),
    ).fetchall()


def relationship_add(conn: sqlite3.Connection, contact_a: str, contact_b: str, rel_type: str = "related", notes: str = "") -> sqlite3.Row:
    a = parse_contact_identifier(conn, contact_a)
    b = parse_contact_identifier(conn, contact_b)
    if not a:
        raise SystemExit(f"Contact not found: {contact_a}")
    if not b:
        raise SystemExit(f"Related contact not found: {contact_b}")
    if int(a["id"]) == int(b["id"]):
        raise SystemExit("A contact cannot be related to itself")
    t = now_iso()
    conn.execute(
        """INSERT INTO contact_relationships(contact_id,related_contact_id,relationship_type,notes,created_at,updated_at)
        VALUES(?,?,?,?,?,?)
        ON CONFLICT(contact_id, related_contact_id, relationship_type) DO UPDATE SET notes=excluded.notes, updated_at=excluded.updated_at""",
        (a["id"], b["id"], rel_type or "related", notes or "", t, t),
    )
    rid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    if int(rid) == 0:
        row = conn.execute("SELECT id FROM contact_relationships WHERE contact_id=? AND related_contact_id=? AND relationship_type=?", (a["id"], b["id"], rel_type or "related")).fetchone()
        rid = row["id"] if row else 0
    audit(conn, "relationship", int(rid), "upsert", f"{a['code']}->{b['code']}:{rel_type}")
    conn.commit()
    return conn.execute(
        """SELECT r.*, a.code AS contact_code, a.full_name AS contact_name, b.code AS related_code, b.full_name AS related_name
        FROM contact_relationships r
        JOIN contacts a ON a.id=r.contact_id
        JOIN contacts b ON b.id=r.related_contact_id
        WHERE r.contact_id=? AND r.related_contact_id=? AND r.relationship_type=?""",
        (a["id"], b["id"], rel_type or "related"),
    ).fetchone()


def relationships_for(conn: sqlite3.Connection, ident: Optional[str] = None) -> List[sqlite3.Row]:
    params: List[Any] = []
    where = ""
    if ident:
        c = parse_contact_identifier(conn, ident)
        if not c:
            raise SystemExit(f"Contact not found: {ident}")
        where = "WHERE r.contact_id=? OR r.related_contact_id=?"
        params.extend([c["id"], c["id"]])
    return conn.execute(
        f"""SELECT r.*, a.code AS contact_code, a.full_name AS contact_name,
        b.code AS related_code, b.full_name AS related_name
        FROM contact_relationships r
        JOIN contacts a ON a.id=r.contact_id
        JOIN contacts b ON b.id=r.related_contact_id
        {where}
        ORDER BY a.full_name COLLATE NOCASE, b.full_name COLLATE NOCASE""",
        params,
    ).fetchall()


def duplicate_report(conn: sqlite3.Connection) -> Dict[str, Any]:
    def collect(field: str) -> List[Dict[str, Any]]:
        rows = conn.execute(
            f"""SELECT lower(trim({field})) AS value, COUNT(*) AS count,
            GROUP_CONCAT(code || ':' || full_name, '; ') AS contacts
            FROM contacts
            WHERE archived=0 AND trim({field})<>''
            GROUP BY lower(trim({field})) HAVING COUNT(*) > 1
            ORDER BY count DESC, value"""
        ).fetchall()
        return [dict(r) for r in rows]
    name_rows = conn.execute(
        """SELECT lower(trim(full_name)) AS value, COUNT(*) AS count,
        GROUP_CONCAT(code || ':' || email || ':' || phone, '; ') AS contacts
        FROM contacts
        WHERE archived=0 AND trim(full_name)<>''
        GROUP BY lower(trim(full_name)) HAVING COUNT(*) > 1
        ORDER BY count DESC, value"""
    ).fetchall()
    return {
        "app": APP_NAME,
        "version": VERSION,
        "generated_at": now_iso(),
        "local_only": True,
        "duplicate_name_groups": [dict(r) for r in name_rows],
        "duplicate_email_groups": collect("email"),
        "duplicate_phone_groups": collect("phone"),
    }


def export_groups_csv(conn: sqlite3.Connection, out: Path) -> Path:
    rows = groups_list(conn)
    fields = ["id", "name", "group_type", "description", "color", "member_count", "created_at", "updated_at"]
    out, tmp, f, w = open_safe_csv_writer(out, fields, label="groups CSV export")
    try:
        for r in rows:
            w.writerow(_csv_safe_row({k: r[k] for k in fields}))
        finish_atomic_csv(out, tmp, f)
    except Exception:
        f.close()
        try:
            tmp.unlink()
        except Exception:
            pass
        raise
    return out

def export_groups_json(conn: sqlite3.Connection, out: Path) -> Path:
    ensure_parent(out)
    payload = {"app": APP_NAME, "version": VERSION, "exported_at": now_iso(), "groups": []}
    for g in groups_list(conn):
        gd = dict(g)
        gd["members"] = [dict(m) for m in group_members(conn, g["name"])]
        payload["groups"].append(gd)
    atomic_write_json(out, payload, label="JSON export")
    return _abs_user_path(out)


def export_relationships_csv(conn: sqlite3.Connection, out: Path) -> Path:
    rows = relationships_for(conn)
    fields = ["id", "contact_code", "contact_name", "related_code", "related_name", "relationship_type", "notes", "created_at", "updated_at"]
    out, tmp, f, w = open_safe_csv_writer(out, fields, label="relationships CSV export")
    try:
        for r in rows:
            w.writerow(_csv_safe_row({k: r[k] for k in fields}))
        finish_atomic_csv(out, tmp, f)
    except Exception:
        f.close()
        try:
            tmp.unlink()
        except Exception:
            pass
        raise
    return out

def export_relationships_json(conn: sqlite3.Connection, out: Path) -> Path:
    ensure_parent(out)
    payload = {"app": APP_NAME, "version": VERSION, "exported_at": now_iso(), "relationships": [dict(r) for r in relationships_for(conn)]}
    atomic_write_json(out, payload, label="JSON export")
    return _abs_user_path(out)

def add_bridge(conn: sqlite3.Connection, args: argparse.Namespace) -> sqlite3.Row:
    contact = parse_contact_identifier(conn, args.contact)
    if not contact:
        raise SystemExit(f"Contact not found: {args.contact}")
    app = (args.app or "").strip().lower()
    if app not in BRIDGE_APPS:
        raise SystemExit(f"Bridge app must be one of: {', '.join(BRIDGE_APPS)}")
    t = now_iso()
    conn.execute(
        """INSERT INTO bridge_links(contact_id,bridge_app,reference_type,reference_value,quick_fill_label,notes,created_at,updated_at)
        VALUES(?,?,?,?,?,?,?,?)""",
        (contact["id"], app, args.reference_type or "", args.reference_value or "", args.label or "", args.notes or "", t, t),
    )
    bid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    audit(conn, "bridge", int(bid), "add", f"{contact['code']}->{app}")
    conn.commit()
    return conn.execute("SELECT * FROM bridge_links WHERE id=?", (bid,)).fetchone()


def bridge_status(conn: sqlite3.Connection) -> Dict[str, Any]:
    counts = {app: conn.execute("SELECT COUNT(*) FROM bridge_links WHERE bridge_app=?", (app,)).fetchone()[0] for app in BRIDGE_APPS}
    return {
        "bridge_contract_version": "0.3.0",
        "jobs_bridge_ready": True,
        "wallet_bridge_ready": True,
        "password_vault_bridge_ready": True,
        "documents_bridge_ready": True,
        "notes_bridge_ready": True,
        "quick_fill_ready": True,
        "right_click_contact_actions_ready": True,
        "future_text_send_placeholder_ready": True,
        "direct_external_write_enabled": False,
        "app_quick_fill_ready": True,
        "action_menu_contract_ready": True,
        "per_app_bridge_export_ready": True,
        "local_prepare_action_ready": True,
        "counts": counts,
    }


def quick_fill(conn: sqlite3.Connection, ident: str, fmt: str = "default") -> str:
    row = parse_contact_identifier(conn, ident)
    if not row:
        raise SystemExit(f"Contact not found: {ident}")
    d = contact_to_dict(row)
    if fmt == "email":
        return d.get("email", "")
    if fmt == "phone":
        return d.get("phone", "")
    if fmt == "vcard-lite":
        return "\n".join([
            "BEGIN:VCARD",
            "VERSION:3.0",
            f"FN:{d.get('full_name','')}",
            f"ORG:{d.get('organization','')}",
            f"TITLE:{d.get('role_title','')}",
            f"TEL:{d.get('phone','')}",
            f"EMAIL:{d.get('email','')}",
            "END:VCARD",
        ])
    if fmt in ("jobs", "wallet", "password-vault", "documents", "notes", "text-draft", "email-draft"):
        return app_quick_fill(conn, ident, fmt)
    return " | ".join([p for p in [d.get("full_name",""), d.get("organization",""), d.get("role_title",""), d.get("email",""), d.get("phone","")] if p])


def export_contacts_csv(conn: sqlite3.Connection, out: Path, include_archived: bool = False) -> Path:
    rows = list_contacts(conn, include_archived=include_archived, limit=100000)
    fields = ["code", "full_name", "preferred_name", "contact_type", "organization", "role_title", "phone", "alt_phone", "email", "alt_email", "address", "website", "birthday", "tags", "priority", "trust_level", "status", "notes", "archived", "created_at", "updated_at"]
    out, tmp, f, w = open_safe_csv_writer(out, fields, label="contacts CSV export")
    try:
        for r in rows:
            w.writerow(_csv_safe_row({k: r[k] for k in fields}))
        finish_atomic_csv(out, tmp, f)
    except Exception:
        f.close()
        try:
            tmp.unlink()
        except Exception:
            pass
        raise
    return out

def export_contacts_json(conn: sqlite3.Connection, out: Path, include_archived: bool = False) -> Path:
    rows = [contact_to_dict(r) for r in list_contacts(conn, include_archived=include_archived, limit=100000)]
    payload = {"app": APP_NAME, "version": VERSION, "exported_at": now_iso(), "contacts": rows, "bridge_status": bridge_status(conn)}
    atomic_write_json(out, payload, label="JSON export")
    return _abs_user_path(out)


def export_bridge_json(conn: sqlite3.Connection, out: Path) -> Path:
    rows = conn.execute("""
        SELECT b.*, c.code, c.full_name, c.email, c.phone, c.organization, c.role_title
        FROM bridge_links b JOIN contacts c ON c.id=b.contact_id
        ORDER BY b.bridge_app, c.full_name
    """).fetchall()
    payload = {"app": APP_NAME, "version": VERSION, "exported_at": now_iso(), "bridge_status": bridge_status(conn), "links": [dict(r) for r in rows]}
    atomic_write_json(out, payload, label="JSON export")
    return _abs_user_path(out)


def backup_db(conn: sqlite3.Connection, out: Optional[Path] = None) -> Path:
    if not out:
        out = data_dir() / "backups" / f"sentinel_contacts_backup_{_dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.sqlite3"
    out = _abs_user_path(out)
    ensure_parent(out, private=True, label="contacts database backup")
    if out.is_symlink():
        raise SystemExit(f"Refusing backup: output target is a symlink: {out}")
    fd, tmp_name = tempfile.mkstemp(prefix=f".{out.name}.", suffix=".tmp", dir=str(out.parent))
    os.close(fd)
    tmp = Path(tmp_name)
    try:
        conn.commit()
        dest = sqlite3.connect(str(tmp))
        try:
            conn.backup(dest)
            integrity = dest.execute("PRAGMA integrity_check").fetchone()[0]
            if str(integrity).lower() != "ok":
                raise RuntimeError(f"Backup integrity check failed: {integrity}")
        finally:
            dest.close()
        os.chmod(tmp, 0o600)
        os.replace(tmp, out)
    finally:
        try:
            if tmp.exists():
                tmp.unlink()
        except Exception:
            pass
    audit(conn, "database", 0, "backup", str(out))
    conn.commit()
    return out

def import_csv(conn: sqlite3.Connection, src: Path) -> int:
    src = refuse_unsafe_input_file(src, "CSV import", MAX_IMPORT_FILE_BYTES)
    count = 0
    with src.open("r", newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row_index, row in enumerate(reader, start=1):
            if row_index > MAX_IMPORT_ROWS:
                raise SystemExit(f"Refusing CSV import: more than {MAX_IMPORT_ROWS} rows")
            notes = _clean_field(row.get("notes", ""), field="notes", limit=MAX_NOTE_CHARS)
            ns = argparse.Namespace(
                code=_clean_field(row.get("code") or "", field="code") or None,
                code_prefix=None,
                full_name=_clean_field(row.get("full_name") or row.get("name") or "Unnamed Contact", field="full_name"),
                preferred_name=_clean_field(row.get("preferred_name", ""), field="preferred_name"),
                type=_clean_field(row.get("contact_type") or row.get("type") or "person", field="contact_type"),
                organization=_clean_field(row.get("organization", ""), field="organization"),
                role=_clean_field(row.get("role_title") or row.get("role") or "", field="role_title"),
                phone=_clean_field(row.get("phone", ""), field="phone"),
                alt_phone=_clean_field(row.get("alt_phone", ""), field="alt_phone"),
                email=_clean_field(row.get("email", ""), field="email"),
                alt_email=_clean_field(row.get("alt_email", ""), field="alt_email"),
                address=_clean_field(row.get("address", ""), field="address"),
                website=_clean_field(row.get("website", ""), field="website"),
                birthday=_clean_field(row.get("birthday", ""), field="birthday"),
                tags=_clean_field(row.get("tags", ""), field="tags"),
                priority=_safe_int(row.get("priority"), 3, 1, 5, "priority"),
                trust_level=_safe_int(row.get("trust_level"), 3, 1, 5, "trust_level"),
                status=_clean_field(row.get("status", "active"), field="status"),
                notes=notes,
            )
            try:
                add_contact(conn, ns)
                count += 1
            except sqlite3.IntegrityError:
                continue
    return count

def health_json(conn: sqlite3.Connection) -> Dict[str, Any]:
    d = dashboard(conn)
    bs = bridge_status(conn)
    integrity = conn.execute("PRAGMA integrity_check").fetchone()[0]
    return {
        "app": APP_NAME,
        "program_number": PROGRAM_NUMBER,
        "version": VERSION,
        "schema_version": SCHEMA_VERSION,
        "database": str(db_path()),
        "sqlite_integrity": integrity,
        "local_only": True,
        "network_disabled_by_design": True,
        "telemetry_enabled": False,
        "aegis_capable": True,
        "sentinel_command_ready": True,
        "contacts_core_ready": True,
        "sequential_contact_code_ready": True,
        "quick_fill_ready": True,
        "right_click_contact_actions_ready": True,
        "jobs_bridge_ready": bs["jobs_bridge_ready"],
        "wallet_bridge_ready": bs["wallet_bridge_ready"],
        "password_vault_bridge_ready": bs["password_vault_bridge_ready"],
        "documents_bridge_ready": bs["documents_bridge_ready"],
        "notes_bridge_ready": bs["notes_bridge_ready"],
        "future_text_send_placeholder_ready": True,
        "direct_external_write_enabled": False,
        "app_quick_fill_ready": True,
        "jobs_quick_fill_ready": True,
        "wallet_quick_fill_ready": True,
        "password_vault_quick_fill_ready": True,
        "documents_quick_fill_ready": True,
        "notes_quick_fill_ready": True,
        "action_menu_contract_ready": True,
        "local_prepare_action_ready": True,
        "per_app_bridge_export_ready": True,
        "quick_fill_export_ready": True,
        "aegis_contacts_v0_2_ready": True,
        "contact_groups_ready": True,
        "group_membership_ready": True,
        "relationship_mapping_ready": True,
        "duplicate_audit_ready": True,
        "groups_export_ready": True,
        "relationships_export_ready": True,
        "groups_relationships_gui_ready": True,
        "aegis_contacts_v0_3_ready": True,
        "contacts_list_theme_ready": True,
        "white_list_window_removed_ready": True,
        "treeview_dark_theme_ready": True,
        "treeview_header_theme_ready": True,
        "sidebar_groups_relationships_visible_ready": True,
        "aegis_contacts_v0_4_ready": True,
        "suite_theme_alignment_ready": True,
        "sentinel_suite_header_ready": True,
        "command_sidebar_theme_ready": True,
        "dashboard_card_layout_ready": True,
        "dashboard_bridge_readiness_panel_ready": True,
        "output_panel_theme_ready": True,
        "contacts_gui_matches_suite_ready": True,
        "aegis_contacts_v0_5_ready": True,
        "sentinel_theme_final_ready": True,
        "suite_ribbon_ready": True,
        "documents_jobs_theme_match_ready": True,
        "dark_form_field_theme_ready": True,
        "dark_dropdown_menu_theme_ready": True,
        "dark_dialog_theme_ready": True,
        "treeview_suite_theme_hardened_ready": True,
        "contacts_full_suite_visual_alignment_ready": True,
        "aegis_contacts_v0_6_ready": True,
        "gtk_css_fstring_brace_hotfix_ready": True,
        "selection_css_escaped_ready": True,
        "gui_rendering_hotfix_ready": True,
        "theme_loader_no_crash_ready": True,
        "aegis_contacts_v0_6_1_ready": True,
        "contact_events_ready": True,
        "event_reminder_ready": True,
        "birthday_report_ready": True,
        "calendar_bridge_csv_ready": True,
        "events_csv_json_export_ready": True,
        "events_calendar_gui_ready": True,
        "aegis_contacts_v0_7_ready": True,
        "suite_reference_theme_v0_8_ready": True,
        "jobs_v1_theme_match_ready": True,
        "sentinel_dark_command_workspace_ready": True,
        "sentinel_left_sidebar_layout_ready": True,
        "horizontal_ribbon_removed_ready": True,
        "dashboard_hero_card_ready": True,
        "events_calendar_stack_page_ready": True,
        "treeview_and_scrollbar_suite_theme_ready": True,
        "aegis_contacts_v0_8_ready": True,
        "vcard_export_ready": True,
        "vcard_import_ready": True,
        "vcard_duplicate_skip_ready": True,
        "merge_candidate_preview_ready": True,
        "contact_import_batch_log_ready": True,
        "contact_handoff_bundle_ready": True,
        "v1_contact_contract_prep_ready": True,
        "aegis_contacts_v0_9_ready": True,
        "non_technical_gui_ready": True,
        "console_views_removed_ready": True,
        "dashboard_readability_polish_ready": True,
        "dashboard_aesthetic_cards_ready": True,
        "friendly_bridge_summary_ready": True,
        "friendly_events_summary_ready": True,
        "friendly_groups_summary_ready": True,
        "friendly_import_export_status_ready": True,
        "aegis_contacts_v0_9_1_ready": True,
        "suite_layout_alignment_v0_9_2_ready": True,
        "jobs_v1_visual_reference_matched_ready": True,
        "sidebar_menu_alignment_ready": True,
        "command_sidebar_no_heading_ready": True,
        "program_header_jobs_style_ready": True,
        "dashboard_jobs_style_cards_ready": True,
        "dashboard_two_column_kpi_ready": True,
        "contacts_v1_gui_candidate_ready": True,
        "aegis_contacts_v0_9_2_ready": True,
        "desktop_launcher_ready": True,
        "mate_menu_ready": True,
        "backup_ready": True,
        "export_ready": True,
        "import_ready": True,
        "stable_lock_ready": True,
        "v1_stable_baseline_locked": True,
        "contacts_v1_ready": True,
        "stable_lock_report_ready": True,
        "audit_report_ready": True,
        "audit_export_ready": True,
        "v1_handoff_bundle_ready": True,
        "backup_restore_ready": True,
        "guarded_restore_ready": True,
        "sentinel_contacts_v1_ready": True,
        "redteam_security_cleanup_hotfix_ready": True,
        "symlink_safe_exports_ready": True,
        "bounded_csv_vcard_import_ready": True,
        "root_profile_guard_ready": True,
        "csv_formula_neutralization_ready": True,
        "atomic_private_writes_ready": True,
        "gui_startup_rendering_stability_hotfix_ready": True,
        "mate_safe_widget_construction_ready": True,
        "css_fallback_hardened_ready": True,
        "compact_default_window_ready": True,
        "gui_exception_guard_ready": True,
        "contacts_v1_0_2_ready": True,
        "counts": {
            "active_contacts": d["active_contacts"],
            "archived_contacts": d["archived_contacts"],
            "organizations": d["organizations"],
            "open_actions": d["open_actions"],
            "bridge_links": d["bridge_links"],
            "groups": d["groups"],
            "group_members": d["group_members"],
            "relationships": d["relationships"],
            "duplicate_groups": d["duplicate_groups"],
            "contact_events": d["contact_events"],
            "scheduled_events": d["scheduled_events"],
            "import_batches": d.get("import_batches", 0),
            "events_due_30": d["events_due_30"],
            "birthdays_due_60": d["birthdays_due_60"],
        },
    }



def vcard_escape(value: Any) -> str:
    text = str(value or "")
    text = text.replace("\\", "\\\\").replace("\n", "\\n").replace(";", "\\;").replace(",", "\\,")
    return text


def vcard_unescape(value: str) -> str:
    text = value or ""
    text = text.replace("\\n", "\n").replace("\\,", ",").replace("\\;", ";").replace("\\\\", "\\")
    return text.strip()


def split_name(full_name: str) -> Tuple[str, str]:
    parts = (full_name or "").strip().split()
    if not parts:
        return "", ""
    if len(parts) == 1:
        return parts[0], ""
    return parts[-1], " ".join(parts[:-1])


def contact_to_vcard(row: sqlite3.Row) -> str:
    family, given = split_name(row["full_name"])
    lines = [
        "BEGIN:VCARD",
        "VERSION:3.0",
        f"FN:{vcard_escape(row['full_name'])}",
        f"N:{vcard_escape(family)};{vcard_escape(given)};;;",
    ]
    if row["organization"]:
        lines.append(f"ORG:{vcard_escape(row['organization'])}")
    if row["role_title"]:
        lines.append(f"TITLE:{vcard_escape(row['role_title'])}")
    if row["phone"]:
        lines.append(f"TEL;TYPE=CELL:{vcard_escape(row['phone'])}")
    if row["alt_phone"]:
        lines.append(f"TEL;TYPE=OTHER:{vcard_escape(row['alt_phone'])}")
    if row["email"]:
        lines.append(f"EMAIL;TYPE=INTERNET:{vcard_escape(row['email'])}")
    if row["alt_email"]:
        lines.append(f"EMAIL;TYPE=OTHER:{vcard_escape(row['alt_email'])}")
    if row["address"]:
        lines.append(f"ADR;TYPE=HOME:;;{vcard_escape(row['address'])};;;;")
    if row["website"]:
        lines.append(f"URL:{vcard_escape(row['website'])}")
    if row["birthday"]:
        lines.append(f"BDAY:{vcard_escape(row['birthday'])}")
    if row["tags"]:
        lines.append(f"CATEGORIES:{vcard_escape(row['tags'])}")
    if row["notes"]:
        lines.append(f"NOTE:{vcard_escape(row['notes'])}")
    lines.append(f"UID:sentinel-contacts:{vcard_escape(row['code'])}")
    lines.extend(["END:VCARD", ""])
    return "\n".join(lines)


def export_vcard(conn: sqlite3.Connection, out: Path, include_archived: bool = False, identifier: str = "") -> Path:
    ensure_parent(out)
    if identifier:
        row = parse_contact_identifier(conn, identifier)
        if not row:
            raise ValueError("Contact not found")
        rows = [row]
    else:
        rows = list_contacts(conn, include_archived=include_archived, limit=100000)
    atomic_write_text(out, "".join(contact_to_vcard(r) for r in rows), label="vCard export")
    audit(conn, "export", 0, "export-vcard", str(out))
    conn.commit()
    return out


def split_vcards(text: str) -> List[str]:
    blocks: List[str] = []
    current: List[str] = []
    in_card = False
    for raw in text.splitlines():
        line = raw.strip("\ufeff")
        if line.upper() == "BEGIN:VCARD":
            current = [line]
            in_card = True
            continue
        if in_card:
            current.append(line)
            if line.upper() == "END:VCARD":
                blocks.append("\n".join(current))
                if len(blocks) > MAX_VCARD_BLOCKS:
                    raise SystemExit(f"Refusing vCard import: more than {MAX_VCARD_BLOCKS} cards")
                current = []
                in_card = False
    return blocks

def _vcard_prop_name(line: str) -> str:
    return line.split(":", 1)[0].split(";", 1)[0].upper().strip()


def _vcard_prop_value(line: str) -> str:
    return vcard_unescape(line.split(":", 1)[1]) if ":" in line else ""


def parse_vcard_block(block: str) -> Dict[str, str]:
    data: Dict[str, str] = {"full_name": "", "organization": "", "role_title": "", "phone": "", "alt_phone": "", "email": "", "alt_email": "", "address": "", "website": "", "birthday": "", "tags": "", "notes": ""}
    tel_count = 0
    email_count = 0
    for raw in block.splitlines():
        line = raw.strip()
        if len(line) > MAX_FIELD_CHARS * 2:
            raise SystemExit("Refusing vCard import: line is too long")
        if not line or ":" not in line:
            continue
        key = _vcard_prop_name(line)
        val = _vcard_prop_value(line)
        if key == "FN":
            data["full_name"] = _clean_field(val, field="FN")
        elif key == "N" and not data["full_name"]:
            parts = val.split(";")
            family = parts[0] if len(parts) > 0 else ""
            given = parts[1] if len(parts) > 1 else ""
            data["full_name"] = _clean_field(" ".join(x for x in [given, family] if x).strip(), field="N")
        elif key == "ORG":
            data["organization"] = _clean_field(val, field="ORG")
        elif key == "TITLE":
            data["role_title"] = _clean_field(val, field="TITLE")
        elif key == "TEL":
            tel_count += 1
            if tel_count == 1:
                data["phone"] = _clean_field(val, field="TEL")
            elif not data["alt_phone"]:
                data["alt_phone"] = _clean_field(val, field="TEL")
        elif key == "EMAIL":
            email_count += 1
            if email_count == 1:
                data["email"] = _clean_field(val, field="EMAIL")
            elif not data["alt_email"]:
                data["alt_email"] = _clean_field(val, field="EMAIL")
        elif key == "ADR":
            parts = [p for p in val.split(";") if p]
            data["address"] = _clean_field(", ".join(parts), field="ADR")
        elif key == "URL":
            data["website"] = _clean_field(val, field="URL")
        elif key == "BDAY":
            data["birthday"] = _clean_field(val, field="BDAY")
        elif key == "CATEGORIES":
            data["tags"] = _clean_field(val, field="CATEGORIES")
        elif key == "NOTE":
            data["notes"] = _clean_field(val, field="NOTE", limit=MAX_NOTE_CHARS)
    if not data["full_name"]:
        data["full_name"] = data.get("email") or data.get("phone") or "Imported Contact"
    return data

def contact_exists_by_email_or_phone(conn: sqlite3.Connection, email: str = "", phone: str = "") -> Optional[sqlite3.Row]:
    if email:
        row = conn.execute("SELECT * FROM contacts WHERE lower(email)=lower(?) OR lower(alt_email)=lower(?)", (email, email)).fetchone()
        if row:
            return row
    if phone:
        row = conn.execute("SELECT * FROM contacts WHERE phone=? OR alt_phone=?", (phone, phone)).fetchone()
        if row:
            return row
    return None


def import_vcard(conn: sqlite3.Connection, path: Path) -> Dict[str, Any]:
    path = refuse_unsafe_input_file(path, "vCard import", MAX_IMPORT_FILE_BYTES)
    text = path.read_text(encoding="utf-8", errors="replace")
    blocks = split_vcards(text)
    imported = 0
    skipped = 0
    codes: List[str] = []
    for block in blocks:
        data = parse_vcard_block(block)
        existing = contact_exists_by_email_or_phone(conn, data.get("email", ""), data.get("phone", ""))
        if existing:
            skipped += 1
            continue
        ns = argparse.Namespace(
            code=None,
            code_prefix=None,
            full_name=data.get("full_name", "Imported Contact"),
            preferred_name="",
            type="person",
            organization=data.get("organization", ""),
            role=data.get("role_title", ""),
            phone=data.get("phone", ""),
            alt_phone=data.get("alt_phone", ""),
            email=data.get("email", ""),
            alt_email=data.get("alt_email", ""),
            address=data.get("address", ""),
            website=data.get("website", ""),
            birthday=data.get("birthday", ""),
            tags=data.get("tags", ""),
            priority=3,
            trust_level=3,
            status="active",
            notes=data.get("notes", ""),
        )
        row = add_contact(conn, ns)
        codes.append(row["code"])
        imported += 1
    conn.execute(
        "INSERT INTO contact_import_batches(source_format,source_path,contacts_imported,contacts_skipped,notes,created_at) VALUES(?,?,?,?,?,?)",
        ("vcard", str(path), imported, skipped, f"blocks={len(blocks)}", now_iso()),
    )
    audit(conn, "import", 0, "import-vcard", f"{path} imported={imported} skipped={skipped}")
    conn.commit()
    return {"source": str(path), "format": "vcard", "cards_found": len(blocks), "contacts_imported": imported, "contacts_skipped": skipped, "codes": codes}

def merge_candidates(conn: sqlite3.Connection) -> Dict[str, Any]:
    dup = duplicate_report(conn)
    candidate_groups = []
    for key in ("duplicate_name_groups", "duplicate_email_groups", "duplicate_phone_groups"):
        for group in dup.get(key, []):
            candidate_groups.append({"source": key, "value": group.get("value", ""), "contacts": group.get("contacts", [])})
    return {
        "app": APP_NAME,
        "version": VERSION,
        "generated_at": now_iso(),
        "local_preview_only": True,
        "auto_merge_enabled": False,
        "candidate_group_count": len(candidate_groups),
        "candidate_groups": candidate_groups,
    }


def export_contact_bundle(conn: sqlite3.Connection, out_dir: Path) -> Path:
    ensure_parent(out_dir / ".sentinel_contacts_bundle_guard", private=True, label="contact bundle directory")
    out_dir = _abs_user_path(out_dir)
    files: Dict[str, str] = {}
    files["contacts_csv"] = str(export_contacts_csv(conn, out_dir / "sentinel_contacts.csv", True))
    files["contacts_json"] = str(export_contacts_json(conn, out_dir / "sentinel_contacts.json", True))
    files["contacts_vcard"] = str(export_vcard(conn, out_dir / "sentinel_contacts.vcf", True))
    files["bridge_json"] = str(export_bridge_json(conn, out_dir / "sentinel_contacts_bridge.json"))
    files["quickfill_json"] = str(export_quickfill_json(conn, out_dir / "sentinel_contacts_quickfill.json", True))
    files["groups_json"] = str(export_groups_json(conn, out_dir / "sentinel_contacts_groups.json"))
    files["relationships_json"] = str(export_relationships_json(conn, out_dir / "sentinel_contacts_relationships.json"))
    files["events_json"] = str(export_events_json(conn, out_dir / "sentinel_contacts_events.json"))
    files["calendar_csv"] = str(export_calendar_csv(conn, out_dir / "sentinel_contacts_calendar.csv"))
    merge_path = out_dir / "sentinel_contacts_merge_candidates.json"
    atomic_write_json(merge_path, merge_candidates(conn), label="merge candidates export")
    files["merge_candidates_json"] = str(merge_path)
    manifest = {
        "app": APP_NAME,
        "program_number": PROGRAM_NUMBER,
        "version": VERSION,
        "schema_version": SCHEMA_VERSION,
        "bundle_type": "sentinel-contacts-v1-handoff",
        "created_at": now_iso(),
        "local_only": True,
        "network_disabled_by_design": True,
        "telemetry_enabled": False,
        "bridge_apps": BRIDGE_APPS,
        "files": files,
    }
    manifest_path = out_dir / "sentinel_contacts_bundle_manifest.json"
    atomic_write_json(manifest_path, manifest, label="manifest export")
    audit(conn, "export", 0, "export-contact-bundle", str(out_dir))
    conn.commit()
    return manifest_path



def _row_count(conn: sqlite3.Connection, table: str, where: str = "") -> int:
    sql = f"SELECT COUNT(*) c FROM {table} {where}"
    return int(conn.execute(sql).fetchone()["c"])


def verify_sqlite_database(path: Path) -> Dict[str, Any]:
    path = validate_sqlite_backup_path(path)
    test = sqlite3.connect(str(path))
    try:
        integrity = test.execute("PRAGMA integrity_check").fetchone()[0]
        tables = [r[0] for r in test.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
        required = {"contacts", "settings", "meta", "audit_log"}
        missing = sorted(required.difference(tables))
        if str(integrity).lower() != "ok":
            raise RuntimeError(f"SQLite integrity check failed: {integrity}")
        if missing:
            raise RuntimeError("Backup is not a Sentinel Contacts database; missing tables: " + ", ".join(missing))
        schema = test.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()
        if schema and str(schema[0]) not in {str(SCHEMA_VERSION), "5"}:
            raise RuntimeError(f"Unexpected Sentinel Contacts schema version: {schema[0]}")
        return {"path": str(path), "integrity": integrity, "tables": tables, "missing_required_tables": missing}
    finally:
        test.close()

def audit_report(conn: sqlite3.Connection) -> Dict[str, Any]:
    init_db(conn)
    d = dashboard(conn)
    bs = bridge_status(conn)
    dup = duplicate_report(conn)
    integrity = conn.execute("PRAGMA integrity_check").fetchone()[0]
    recent_audit = [dict(r) for r in conn.execute("SELECT entity, entity_id, action, details, created_at FROM audit_log ORDER BY id DESC LIMIT 25").fetchall()]
    launcher_paths = [
        "/usr/share/applications/sentinel-contacts.desktop",
        "/usr/local/share/applications/sentinel-contacts.desktop",
        str(Path.home() / "Desktop" / "sentinel-contacts.desktop"),
    ]
    icon_paths = [
        "/usr/share/icons/hicolor/128x128/apps/sentinel-contacts.png",
        "/usr/local/share/icons/hicolor/128x128/apps/sentinel-contacts.png",
        "/usr/share/icons/hicolor/scalable/apps/sentinel-contacts.svg",
        "/usr/local/share/icons/hicolor/scalable/apps/sentinel-contacts.svg",
    ]
    return {
        "app": APP_NAME,
        "program_number": PROGRAM_NUMBER,
        "version": VERSION,
        "schema_version": SCHEMA_VERSION,
        "report_type": "sentinel-contacts-v1-audit",
        "generated_at": now_iso(),
        "database": str(db_path()),
        "sqlite_integrity": integrity,
        "local_only": True,
        "network_disabled_by_design": True,
        "telemetry_enabled": False,
        "direct_external_write_enabled": False,
        "aegis_capable": True,
        "sentinel_command_ready": True,
        "gui_v1_candidate": True,
        "contacts_v1_ready": True,
        "counts": {
            "active_contacts": d.get("active_contacts", 0),
            "archived_contacts": d.get("archived_contacts", 0),
            "organizations": d.get("organizations", 0),
            "open_actions": d.get("open_actions", 0),
            "bridge_links": d.get("bridge_links", 0),
            "groups": d.get("groups", 0),
            "relationships": d.get("relationships", 0),
            "contact_events": d.get("contact_events", 0),
            "scheduled_events": d.get("scheduled_events", 0),
            "import_batches": d.get("import_batches", 0),
            "audit_entries": _row_count(conn, "audit_log"),
        },
        "duplicate_audit": {
            "duplicate_name_groups": len(dup.get("duplicate_name_groups", [])),
            "duplicate_email_groups": len(dup.get("duplicate_email_groups", [])),
            "duplicate_phone_groups": len(dup.get("duplicate_phone_groups", [])),
            "auto_merge_enabled": False,
        },
        "bridge_status": bs,
        "readiness": {
            "quick_fill_ready": True,
            "right_click_contact_actions_ready": True,
            "jobs_bridge_ready": bs.get("jobs_bridge_ready", False),
            "wallet_bridge_ready": bs.get("wallet_bridge_ready", False),
            "password_vault_bridge_ready": bs.get("password_vault_bridge_ready", False),
            "documents_bridge_ready": bs.get("documents_bridge_ready", False),
            "notes_bridge_ready": bs.get("notes_bridge_ready", False),
            "groups_ready": True,
            "relationships_ready": True,
            "events_ready": True,
            "calendar_bridge_csv_ready": True,
            "vcard_ready": True,
            "contact_bundle_ready": True,
            "backup_ready": True,
            "guarded_restore_ready": True,
            "redteam_security_cleanup_hotfix_ready": True,
            "symlink_safe_exports_ready": True,
            "bounded_csv_vcard_import_ready": True,
            "root_profile_guard_ready": True,
            "csv_formula_neutralization_ready": True,
            "stable_lock_ready": True,
        },
        "launcher_paths_detected": [p for p in launcher_paths if Path(p).exists()],
        "icon_paths_detected": [p for p in icon_paths if Path(p).exists()],
        "recent_audit": recent_audit,
    }


def stable_lock_report(conn: sqlite3.Connection, as_json: bool = False) -> Any:
    report = audit_report(conn)
    report.update({
        "report_type": "sentinel-contacts-v1-stable-lock",
        "stable_lock_ready": True,
        "v1_stable_baseline_locked": True,
        "contacts_v1_ready": True,
        "lock_summary": "Program 111 Sentinel Contacts v1.0.1 redteam security cleanup hotfix baseline ready.",
    })
    if as_json:
        return report
    lines = [
        "# Sentinel Contacts v1.0.1 Redteam Security Cleanup Report",
        "",
        f"Generated: {report['generated_at']}",
        f"Program: {PROGRAM_NUMBER}",
        f"Version: {VERSION}",
        f"Schema: v{SCHEMA_VERSION}",
        f"Database: {report['database']}",
        f"SQLite integrity: {report['sqlite_integrity']}",
        "",
        "## Doctrine",
        "- Local-only: true",
        "- Network disabled by design: true",
        "- Telemetry enabled: false",
        "- Direct external write enabled: false",
        "",
        "## Locked capabilities",
        "- Contacts, organizations, quick-fill and right-click local action menu",
        "- Groups, relationships, duplicate audit and merge-candidate preview",
        "- Events, reminders, birthdays and local calendar CSV handoff",
        "- Jobs / Wallet / Password Vault / Documents / Notes bridge contracts",
        "- vCard import/export and full local contact handoff bundle",
        "- Verified backups and guarded restore",
        "- AEGIS/Sentinel health JSON and stable-lock/audit reports",
        "- Sentinel Jobs v1-style GUI candidate baseline",
        "",
        "## Counts",
    ]
    for key, value in report["counts"].items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "Status: v1 stable baseline locked."])
    return "\n".join(lines) + "\n"


def export_audit_json(conn: sqlite3.Connection, out: Path) -> Path:
    ensure_parent(out)
    atomic_write_json(out, audit_report(conn), label="audit JSON export")
    audit(conn, "export", 0, "export-audit-json", str(out))
    conn.commit()
    return out


def export_audit_csv(conn: sqlite3.Connection, out: Path) -> Path:
    rows = conn.execute("SELECT id, entity, entity_id, action, details, created_at FROM audit_log ORDER BY id").fetchall()
    fieldnames = ["id", "entity", "entity_id", "action", "details", "created_at"]
    out, tmp, f, writer = open_safe_csv_writer(out, fieldnames, label="audit CSV export")
    try:
        for r in rows:
            writer.writerow(_csv_safe_row({k: r[k] for k in fieldnames}))
        finish_atomic_csv(out, tmp, f)
    except Exception:
        f.close()
        try:
            tmp.unlink()
        except Exception:
            pass
        raise
    audit(conn, "export", 0, "export-audit-csv", str(out))
    conn.commit()
    return out

def export_v1_bundle(conn: sqlite3.Connection, out_dir: Path) -> Path:
    ensure_parent(out_dir / ".sentinel_contacts_v1_bundle_guard", private=True, label="v1 bundle directory")
    out_dir = _abs_user_path(out_dir)
    contact_manifest = export_contact_bundle(conn, out_dir / "contacts_handoff")
    audit_json = export_audit_json(conn, out_dir / "sentinel_contacts_audit_report.json")
    audit_csv = export_audit_csv(conn, out_dir / "sentinel_contacts_audit_log.csv")
    stable_json = out_dir / "sentinel_contacts_stable_lock_report.json"
    atomic_write_json(stable_json, stable_lock_report(conn, True), label="stable lock JSON export")
    stable_md = out_dir / "sentinel_contacts_stable_lock_report.md"
    atomic_write_text(stable_md, stable_lock_report(conn, False), label="stable lock Markdown export")
    backup_path = backup_db(conn, out_dir / "sentinel_contacts_database_backup.sqlite3")
    manifest = {
        "app": APP_NAME,
        "program_number": PROGRAM_NUMBER,
        "version": VERSION,
        "schema_version": SCHEMA_VERSION,
        "bundle_type": "sentinel-contacts-v1-handoff-bundle",
        "created_at": now_iso(),
        "local_only": True,
        "network_disabled_by_design": True,
        "telemetry_enabled": False,
        "stable_lock_ready": True,
        "v1_stable_baseline_locked": True,
        "files": {
            "contacts_handoff_manifest": str(contact_manifest),
            "audit_report_json": str(audit_json),
            "audit_log_csv": str(audit_csv),
            "stable_lock_report_json": str(stable_json),
            "stable_lock_report_md": str(stable_md),
            "verified_database_backup": str(backup_path),
        },
    }
    manifest_path = out_dir / "sentinel_contacts_v1_bundle_manifest.json"
    atomic_write_json(manifest_path, manifest, label="manifest export")
    audit(conn, "export", 0, "export-v1-bundle", str(out_dir))
    conn.commit()
    return manifest_path


def restore_backup(backup_path: Path, confirm: str) -> Path:
    if confirm != "RESTORE_SENTINEL_CONTACTS":
        raise SystemExit("Restore refused. Re-run with --confirm RESTORE_SENTINEL_CONTACTS")
    backup_path = validate_sqlite_backup_path(backup_path)
    verify_sqlite_database(backup_path)
    target = _abs_user_path(db_path())
    ensure_parent(target, private=True, label="contacts database restore target")
    if target.is_symlink():
        raise SystemExit(f"Refusing restore: active database path is a symlink: {target}")
    if target.exists():
        safety = target.with_name(f"contacts_pre_restore_safety_{_dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.sqlite3")
        backup_conn = sqlite3.connect(str(target))
        try:
            backup_db(backup_conn, safety)
        finally:
            backup_conn.close()
        verify_sqlite_database(safety)
    fd, tmp_name = tempfile.mkstemp(prefix=f".{target.name}.restore.", suffix=".sqlite3", dir=str(target.parent))
    os.close(fd)
    tmp = Path(tmp_name)
    try:
        shutil.copyfile(str(backup_path), str(tmp), follow_symlinks=False)
        os.chmod(tmp, 0o600)
        verify_sqlite_database(tmp)
        os.replace(tmp, target)
    finally:
        try:
            if tmp.exists():
                tmp.unlink()
        except Exception:
            pass
    verify_sqlite_database(target)
    conn = connect(target)
    try:
        init_db(conn)
        audit(conn, "database", 0, "restore-backup", str(backup_path))
        conn.commit()
    finally:
        conn.close()
    return target

def print_table(rows: Iterable[sqlite3.Row], cols: List[str]) -> None:
    rows = list(rows)
    if not rows:
        print("No records.")
        return
    widths = {c: len(c) for c in cols}
    for r in rows:
        for c in cols:
            widths[c] = min(40, max(widths[c], len(str(r[c] if c in r.keys() else ""))))
    print("  ".join(c.ljust(widths[c]) for c in cols))
    print("  ".join("-" * widths[c] for c in cols))
    for r in rows:
        print("  ".join(str(r[c] if c in r.keys() else "")[:40].ljust(widths[c]) for c in cols))


def default_export_path(name: str) -> Path:
    return data_dir() / "exports" / name


def install_desktop_launcher() -> Path:
    desktop_dir = Path.home() / "Desktop"
    dest = desktop_dir / "sentinel-contacts.desktop"
    atomic_write_text(dest, DESKTOP_ENTRY, mode=0o755, label="desktop launcher")
    return _abs_user_path(dest)


DESKTOP_ENTRY = """[Desktop Entry]
Type=Application
Name=Sentinel Contacts
Comment=Local-first AEGIS/Sentinel contact manager
Exec=sentinel-contacts-gui
Icon=sentinel-contacts
Terminal=false
Categories=Office;Utility;ContactManagement;
StartupNotify=true
"""


MANUAL_TEXT = f"""
{APP_NAME} v{VERSION} — Program {PROGRAM_NUMBER}

Purpose
  Local-only contact manager for people, companies, quick-fill data, and bridge links.

Doctrine
  - Local SQLite storage only.
  - No network calls.
  - No telemetry.
  - AEGIS/Sentinel Command health JSON ready.

Core CLI
  sentinel-contacts init
  sentinel-contacts add "Jane Smith" --email jane@example.invalid --phone 0400000000 --organization "Example Co"
  sentinel-contacts list
  sentinel-contacts view CON-0001
  sentinel-contacts search jane
  sentinel-contacts quick-fill CON-0001
  sentinel-contacts quick-fill CON-0001 --format vcard-lite
  sentinel-contacts quick-fill CON-0001 --format jobs
  sentinel-contacts quick-fill CON-0001 --format wallet
  sentinel-contacts quick-fill CON-0001 --format password-vault
  sentinel-contacts quick-fill CON-0001 --format documents
  sentinel-contacts quick-fill CON-0001 --format notes
  sentinel-contacts action-menu CON-0001 --json
  sentinel-contacts prepare-action CON-0001 --app jobs --action quick-fill

Bridge CLI
  sentinel-contacts bridge-link CON-0001 --app jobs --reference-type job --reference-value JOB-0001
  sentinel-contacts bridge-status
  sentinel-contacts export-bridge-json

Events / calendar bridge
  sentinel-contacts event-add CON-0001 --type call --title "Call Jane" --date 2026-08-01 --time 10:00
  sentinel-contacts events --contact CON-0001
  sentinel-contacts events-due --days 30 --json
  sentinel-contacts birthdays --days 60
  sentinel-contacts export-calendar-csv
  sentinel-contacts export-events-json

vCard / bundle handoff
  sentinel-contacts export-vcard
  sentinel-contacts export-vcard --identifier CON-0001
  sentinel-contacts import-vcard ./contacts.vcf
  sentinel-contacts merge-candidates --json
  sentinel-contacts export-contact-bundle

Groups / relationships
  sentinel-contacts group-add Family --type household
  sentinel-contacts group-add-contact Family CON-0001
  sentinel-contacts group-members Family
  sentinel-contacts relationship-add CON-0001 CON-0002 --type colleague
  sentinel-contacts relationships --contact CON-0001
  sentinel-contacts duplicate-report --json
  sentinel-contacts export-groups-json
  sentinel-contacts export-relationships-json

Right-click GUI actions
  The Contacts page supports a context menu for quick copy/view/quick-fill/bridge action placeholders.
  Future SMS/text sending is represented as a disabled placeholder contract, not as a network sender.

Backup / Export
  sentinel-contacts backup
  sentinel-contacts restore-backup backup.sqlite3 --confirm RESTORE_SENTINEL_CONTACTS
  sentinel-contacts stable-lock-report
  sentinel-contacts audit-report --json
  sentinel-contacts export-audit-json
  sentinel-contacts export-audit-csv
  sentinel-contacts export-v1-bundle
  sentinel-contacts export-csv
  sentinel-contacts export-json
  sentinel-contacts health-json
""".strip() + "\n"


def apply_sentinel_theme(Gtk: Any, Gdk: Any) -> None:
    """Apply the Sentinel suite GTK3 theme used by the v1 suite apps.

    v1.0.0 preserves the Sentinel Jobs v1.0.0 command layout:
    dark root, dark program header, left command sidebar, gold active state,
    two-column dashboard cards, and no horizontal command ribbon.
    """
    css = r"""
/* Sentinel Contacts v1.0.0 - Sentinel Jobs v1 suite reference theme.
   Matched visually to Sentinel Jobs v1.0.0: dark command workspace,
   program header, left navigation, gold active accents, and stable MATE GTK3 widgets. */
* {
    font-family: Sans, "Noto Sans", "DejaVu Sans";
    -GtkWidget-focus-line-width: 1;
    -GtkWidget-focus-padding: 1;
    text-shadow: none;
    background-image: none;
}
window, .sentinel-root {
    background-color: #05090C;
    color: #E6E0D2;
}
box, grid, paned, viewport, scrolledwindow {
    background-color: #05090C;
    color: #E6E0D2;
}
.sentinel-shell, .sentinel-content-shell, .sentinel-body-shell {
    background-color: #05090C;
    color: #E6E0D2;
    padding: 10px;
}
.sentinel-header, .sentinel-program-header {
    background-color: #101923;
    color: #E6E0D2;
    border-bottom: 1px solid #000000;
    padding: 12px;
}
.sentinel-program-title, .sentinel-logo-frame {
    background-color: #101923;
    border: 0px solid #101923;
    padding: 8px;
}
.sentinel-title, label.sentinel-title, .sentinel-app-name {
    color: #E19B00;
    font-weight: 800;
    font-size: 20px;
    letter-spacing: 5px;
}
.sentinel-app-subtitle, label.sentinel-subtitle {
    color: #AAB3BC;
    font-size: 10.5pt;
}
.sentinel-sidebar {
    background-color: #101923;
    color: #E6E0D2;
    border-right: 1px solid #000000;
    padding: 8px;
    min-width: 224px;
}
.sentinel-sidebar-scroll {
    background-color: #101923;
    border-right: 1px solid #000000;
    padding: 0px;
    min-width: 224px;
}
.sentinel-sidebar button {
    background-image: none;
    background-color: #16242E;
    color: #E6E0D2;
    border: 1px solid #0A1118;
    border-radius: 0px;
    padding: 8px 10px;
    text-shadow: none;
    box-shadow: none;
}
.sentinel-sidebar button:hover {
    background-color: #20313D;
    color: #E19B00;
    border-color: #E19B00;
}
.sentinel-sidebar button:active, .sentinel-sidebar button:checked,
.sentinel-sidebar button.sentinel-nav-active, button.sentinel-nav-active {
    background-color: #1C2D39;
    color: #E19B00;
    border-color: #E19B00;
    font-weight: 800;
}
.sentinel-sidebar button.sentinel-nav-active label, button.sentinel-nav-active label {
    color: #E19B00;
}
.dashboard-shell, .sentinel-page, .sentinel-stack, .sentinel-page-frame {
    background-color: #05090C;
    color: #E6E0D2;
    padding-left: 10px;
    padding-right: 10px;
}
.sentinel-panel {
    background-color: #05090C;
    color: #E6E0D2;
    border: 0px solid #05090C;
    padding: 10px;
}
.dashboard-hero, .sentinel-dashboard-hero {
    background-color: #0C131A;
    color: #E6E0D2;
    border: 1px solid #101923;
    border-radius: 0px;
    padding: 12px;
}
.sentinel-card, .sentinel-kpi-card, .sentinel-list-panel {
    background-color: #0C131A;
    color: #E6E0D2;
    border: 1px solid #1D2B36;
    border-radius: 0px;
    padding: 10px;
}
.sentinel-output-panel, .sentinel-output-frame {
    background-color: #05090C;
    color: #E6E0D2;
    border: 2px solid #D8D8D8;
    border-radius: 0px;
    padding: 8px;
}
label {
    color: #E6E0D2;
}
label.sentinel-heading, .sentinel-heading, .sentinel-section-title {
    color: #E19B00;
    font-weight: 700;
}
label.sentinel-hero-title {
    color: #E19B00;
    font-weight: 800;
    font-size: 21px;
}
label.sentinel-muted, .sentinel-muted {
    color: #AAB3BC;
}
label.sentinel-cyan, .sentinel-cyan {
    color: #03C8FF;
}
.sentinel-kpi-value {
    color: #E19B00;
    font-weight: 800;
    font-size: 22px;
}
.sentinel-kpi-value-cyan {
    color: #03C8FF;
    font-weight: 800;
    font-size: 22px;
}
entry, spinbutton, spinbutton entry {
    background-image: none;
    background-color: #141C23;
    color: #F1E8D4;
    border: 1px solid #46515A;
    border-radius: 0px;
    padding: 7px;
    box-shadow: none;
}
entry:focus, spinbutton:focus, spinbutton entry:focus {
    border-color: #E19B00;
    background-color: #0F171E;
}
entry selection, spinbutton entry selection, textview text selection, treeview.view selection {
    background-color: #E19B00;
    color: #05090C;
}
combobox, combobox box, combobox button, combobox arrow, combobox cellview,
comboboxtext, comboboxtext button {
    background-image: none;
    background-color: #141C23;
    color: #F1E8D4;
    border-color: #46515A;
    box-shadow: none;
}
combobox button, comboboxtext button {
    background-image: none;
    background-color: #141C23;
    border: 1px solid #46515A;
    border-radius: 0px;
    padding: 5px 7px;
    color: #F1E8D4;
}
combobox button:focus, combobox button:hover, comboboxtext button:hover {
    border-color: #E19B00;
    color: #E19B00;
    background-color: #19242D;
}
menu, menuitem, popover, window.popup {
    background-color: #2E3034;
    color: #F1E8D4;
    border: 1px solid #0A0C0F;
}
menuitem:hover, menuitem:selected {
    background-color: #3B3D42;
    color: #E19B00;
}
menubar, .sentinel-menu-bar {
    background-color: #202326;
    color: #F1E8D4;
    border-bottom: 1px solid #0A0C0F;
}
menubar > menuitem {
    color: #F1E8D4;
    padding: 5px 10px;
}
menubar > menuitem:hover {
    background-color: #3B3D42;
    color: #E19B00;
}
.sentinel-menu-bar menuitem, menuitem label, menubar menuitem label {
    color: #F1E8D4;
}
.sentinel-menu-bar menuitem:hover label, menuitem:hover label, menuitem:selected label {
    color: #E19B00;
}
button {
    background-image: none;
    background-color: #17232C;
    color: #E6E0D2;
    border: 1px solid #D8D8D8;
    border-radius: 0px;
    padding: 7px 10px;
    text-shadow: none;
    box-shadow: none;
}
button:hover {
    background-color: #20313D;
    color: #E19B00;
    border-color: #E19B00;
}
button:active {
    background-color: #0B1218;
    color: #03C8FF;
    border-color: #03C8FF;
}
textview, textview text {
    background-color: #05090C;
    color: #E6E0D2;
    border-radius: 0px;
}
textview.sentinel-output text, .sentinel-output text, .sentinel-output-panel text {
    background-color: #05090C;
    color: #E6E0D2;
}
textview border, scrolledwindow {
    border: 1px solid #101923;
    border-radius: 0px;
}
separator {
    background-color: #182631;
}
scrollbar, scrollbar trough {
    background-color: #0A1118;
    border: 1px solid #101923;
    min-width: 13px;
    min-height: 13px;
}
scrollbar slider {
    background-color: #4A5560;
    border: 1px solid #D8D8D8;
    border-radius: 0px;
    min-width: 13px;
    min-height: 13px;
}
scrollbar slider:hover, scrollbar slider:active {
    background-color: #E19B00;
    border-color: #E19B00;
}
scrollbar button {
    background-color: #101923;
    color: #E19B00;
    border: 1px solid #0A1118;
    min-width: 13px;
    min-height: 13px;
}
scrolledwindow, scrolledwindow > viewport, viewport {
    background-color: #05090C;
    border-color: #101923;
}
treeview, treeview.view, .sentinel-contact-list, .sentinel-contact-list.view {
    background-color: #050A0D;
    color: #E6E0D2;
    border: 1px solid #1D2B36;
    grid-line-color: #203140;
}
treeview.view row, treeview.view cell, .sentinel-contact-list row, .sentinel-contact-list cell {
    background-color: #050A0D;
    color: #E6E0D2;
}
/* Avoid nth-child selectors: some GTK3/MATE CSS providers reject them.
   Row contrast now comes from base and selection states for startup-safe rendering. */
treeview.view:selected, treeview.view:selected:focus, treeview.view row:selected, treeview.view row:selected:focus,
treeview.view cell:selected, .sentinel-contact-list:selected, .sentinel-contact-list row:selected {
    background-color: #1C2D39;
    color: #E19B00;
}
treeview header button, treeview.view header button, .sentinel-contact-list header button {
    background-color: #111C25;
    color: #E19B00;
    border: 1px solid #D8D8D8;
    padding: 6px;
    font-weight: bold;
}
treeview header button:hover, treeview.view header button:hover {
    background-color: #20313D;
    color: #03C8FF;
    border-color: #E19B00;
}
dialog, messagedialog {
    background-color: #05090C;
    color: #E6E0D2;
}
/* v0.9.0 keeps the old ribbon class themed but hidden from the main layout. */
.sentinel-ribbon {
    background-color: #111D27;
    border-top: 1px solid #294052;
    border-bottom: 1px solid #294052;
    padding: 6px;
}
.sentinel-ribbon-tab {
    background-color: #0F1A23;
    color: #E19B00;
    border: 1px solid #D8D8D8;
    padding: 6px 12px;
    font-weight: bold;
}
"""
    try:
        provider = Gtk.CssProvider()
        provider.load_from_data(css.encode("utf-8"))
        screen = Gdk.Screen.get_default()
        if screen is not None:
            Gtk.StyleContext.add_provider_for_screen(screen, provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
    except Exception as exc:
        sys.stderr.write(f"Sentinel Contacts theme warning: GTK rejected the suite CSS theme, using safe fallback: {exc}\n")
        try:
            fallback = b"""
window, box, grid, viewport, scrolledwindow { background-color: #05090C; color: #E6E0D2; }
label { color: #E6E0D2; }
entry, textview, textview text { background-color: #141C23; color: #F1E8D4; border: 1px solid #46515A; }
button { background-image: none; background-color: #17232C; color: #E6E0D2; border: 1px solid #D8D8D8; }
menubar, menu, menuitem { background-color: #202326; color: #F1E8D4; }
.sentinel-title, .sentinel-heading { color: #E19B00; }
"""
            provider = Gtk.CssProvider()
            provider.load_from_data(fallback)
            screen = Gdk.Screen.get_default()
            if screen is not None:
                Gtk.StyleContext.add_provider_for_screen(screen, provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        except Exception as inner:
            sys.stderr.write(f"Sentinel Contacts fallback theme warning: {inner}\n")

def run_gui() -> int:
    try:
        import gi
        gi.require_version("Gtk", "3.0")
        from gi.repository import Gtk, Gdk, GLib
    except Exception as exc:
        print(f"GUI unavailable: {exc}", file=sys.stderr)
        return 1

    # Disable overlay scrollbars for predictable MATE/GTK3 behavior.
    os.environ.setdefault("GTK_OVERLAY_SCROLLING", "0")
    conn = db()
    apply_sentinel_theme(Gtk, Gdk)

    def make_box(orientation: Any, spacing: int = 0, margin: int = 0) -> Any:
        """Create GTK boxes without constructor-only margin kwargs.

        Some PyGObject/GTK3 combinations used by MATE are picky about
        construct-time widget properties.  Use explicit setters so the GUI
        starts reliably across the suite baseline.
        """
        box = Gtk.Box(orientation=orientation, spacing=spacing)
        if margin:
            try:
                box.set_border_width(int(margin))
            except Exception:
                pass
        return box

    def make_label(text: str = "", xalign: float = 0.0) -> Any:
        """Create labels with version-tolerant alignment setup."""
        lab = Gtk.Label(label=text)
        try:
            lab.set_xalign(float(xalign))
        except Exception:
            try:
                lab.set_alignment(float(xalign), 0.5)
            except Exception:
                pass
        return lab

    class ContactsWindow(Gtk.Window):
        def __init__(self) -> None:
            super().__init__(title=f"{APP_NAME} v{VERSION}")
            # Keep startup geometry MATE-safe.  Earlier builds could request
            # a large initial surface that looked broken or vanished on smaller panels.
            self.set_default_size(1120, 720)
            self.set_size_request(860, 540)
            self.connect("destroy", Gtk.main_quit)
            self.conn = conn
            self.current_page = "Dashboard"
            self.nav_buttons: Dict[str, Any] = {}
            self._build_ui()
            self.show_all()

        def _build_ui(self) -> None:
            root = make_box(Gtk.Orientation.VERTICAL, 0, 0)
            root.get_style_context().add_class("sentinel-root")
            self.add(root)

            accel = Gtk.AccelGroup()
            self.add_accel_group(accel)
            menubar = Gtk.MenuBar()
            menubar.get_style_context().add_class("sentinel-menu-bar")
            file_menu = Gtk.Menu(); file_item = Gtk.MenuItem(label="File"); file_item.set_submenu(file_menu)
            backup_item = Gtk.MenuItem(label="Backup Local Database")
            backup_item.connect("activate", lambda *_: self.backup_clicked())
            quit_item = Gtk.MenuItem(label="Quit")
            quit_item.add_accelerator("activate", accel, Gdk.KEY_q, Gdk.ModifierType.CONTROL_MASK, Gtk.AccelFlags.VISIBLE)
            quit_item.connect("activate", lambda *_: Gtk.main_quit())
            file_menu.append(backup_item); file_menu.append(Gtk.SeparatorMenuItem()); file_menu.append(quit_item)
            view_menu = Gtk.Menu(); view_item = Gtk.MenuItem(label="View"); view_item.set_submenu(view_menu)
            refresh_item = Gtk.MenuItem(label="Refresh")
            refresh_item.connect("activate", lambda *_: self.refresh_all())
            view_menu.append(refresh_item)
            help_menu = Gtk.Menu(); help_item = Gtk.MenuItem(label="Help"); help_item.set_submenu(help_menu)
            manual_item = Gtk.MenuItem(label="Manual")
            manual_item.connect("activate", lambda *_: self.switch_page("Manual"))
            help_menu.append(manual_item)
            for item in (file_item, view_item, help_item): menubar.append(item)
            root.pack_start(menubar, False, False, 0)

            header = make_box(Gtk.Orientation.HORIZONTAL, 16, 0)
            header.set_border_width(12)
            header.get_style_context().add_class("sentinel-program-header")
            icon_path = Path("/usr/share/icons/hicolor/128x128/apps/sentinel-contacts.png")
            if not icon_path.exists():
                icon_path = Path(__file__).resolve().parent.parent / "assets" / "sentinel-contacts-128.png"
            if icon_path.exists():
                icon = Gtk.Image.new_from_file(str(icon_path))
                try:
                    icon.set_pixel_size(86)
                except Exception:
                    pass
            else:
                icon = Gtk.Image.new_from_icon_name("sentinel-contacts", Gtk.IconSize.DIALOG)
            icon.get_style_context().add_class("sentinel-logo-frame")
            header.pack_start(icon, False, False, 0)
            titlebox = make_box(Gtk.Orientation.VERTICAL, 4, 0)
            titlebox.get_style_context().add_class("sentinel-program-title")
            title = make_label("SENTINEL CONTACTS", 0.0)
            title.get_style_context().add_class("sentinel-app-name")
            sub = make_label("Contact & Quick-Fill Manager — Program 111", 0.0)
            sub.get_style_context().add_class("sentinel-app-subtitle")
            sub2 = make_label("Contacts • Groups • Relationships • Jobs/Wallet/Vault/Documents/Notes Bridges", 0.0)
            sub2.get_style_context().add_class("sentinel-muted")
            for lab in (title, sub, sub2):
                lab.set_line_wrap(True)
            titlebox.pack_start(title, False, False, 0)
            titlebox.pack_start(sub, False, False, 0)
            titlebox.pack_start(sub2, False, False, 0)
            header.pack_start(titlebox, True, True, 0)
            root.pack_start(header, False, False, 0)

            # v0.9.0 suite alignment: Contacts now follows the Sentinel Jobs v1 shell.
            # Primary page navigation is the left Command sidebar; the prior horizontal ribbon is removed from the visible layout.

            shell = make_box(Gtk.Orientation.HORIZONTAL, 10, 0)
            shell.set_halign(Gtk.Align.FILL)
            shell.set_valign(Gtk.Align.FILL)
            shell.set_hexpand(True); shell.set_vexpand(True)
            shell.get_style_context().add_class("sentinel-content-shell")
            shell.get_style_context().add_class("sentinel-body-shell")
            root.pack_start(shell, True, True, 0)

            side_scroll = Gtk.ScrolledWindow()
            side_scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
            try:
                side_scroll.set_overlay_scrolling(False)
            except Exception:
                pass
            side_scroll.set_size_request(224, -1)
            side_scroll.get_style_context().add_class("sentinel-sidebar-scroll")
            side_panel = make_box(Gtk.Orientation.VERTICAL, 8, 8)
            side_panel.set_size_request(224, -1)
            side_panel.get_style_context().add_class("sentinel-sidebar")
            side_scroll.add(side_panel)
            shell.pack_start(side_scroll, False, False, 0)

            pages = ["Dashboard", "Contacts", "Quick Fill", "Bridges", "Events / Calendar", "Groups / Relationships", "Import / Export", "Manual"]
            for name in pages:
                btn = Gtk.Button(label=name)
                btn.set_halign(Gtk.Align.FILL)
                btn.set_hexpand(True)
                btn.set_can_focus(False)
                btn.connect("clicked", lambda _b, n=name: self.switch_page(n))
                side_panel.pack_start(btn, False, False, 0)
                self.nav_buttons[name] = btn
            side_panel.pack_start(Gtk.Separator(), False, False, 8)
            for label, func in [("New Backup", self.backup_clicked), ("Repair Launchers", self.repair_launchers_clicked), ("Refresh", self.refresh_all)]:
                btn = Gtk.Button(label=label)
                btn.set_halign(Gtk.Align.FILL)
                btn.set_hexpand(True)
                btn.connect("clicked", lambda _b, f=func: f())
                side_panel.pack_start(btn, False, False, 0)
            side_panel.pack_start(Gtk.Separator(), False, False, 8)
            hint = make_label("Right-click a contact for quick-fill and bridge actions.\nLocal-only: text/email senders remain disabled placeholders.", 0.0)
            hint.set_line_wrap(True)
            hint.get_style_context().add_class("sentinel-muted")
            side_panel.pack_start(hint, False, False, 0)

            page_border = make_box(Gtk.Orientation.VERTICAL, 0, 0)
            page_border.get_style_context().add_class("sentinel-page-frame")
            shell.pack_start(page_border, True, True, 0)

            self.stack = Gtk.Stack()
            self.stack.set_transition_type(Gtk.StackTransitionType.NONE)
            self.stack.set_transition_duration(0)
            self.stack.get_style_context().add_class("sentinel-stack")
            self.stack.set_hexpand(True); self.stack.set_vexpand(True)
            page_border.pack_start(self.stack, True, True, 0)
            self.page_widgets = {}
            for name, builder in [
                ("Dashboard", self.build_dashboard),
                ("Contacts", self.build_contacts),
                ("Quick Fill", self.build_quick_fill),
                ("Bridges", self.build_bridges),
                ("Events / Calendar", self.build_events_calendar),
                ("Groups / Relationships", self.build_groups_relationships),
                ("Import / Export", self.build_import_export),
                ("Manual", self.build_manual),
            ]:
                sc = Gtk.ScrolledWindow()
                sc.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
                try:
                    sc.set_overlay_scrolling(False)
                    sc.set_shadow_type(Gtk.ShadowType.IN)
                except Exception:
                    pass
                sc.get_style_context().add_class("sentinel-scroll")
                sc.get_style_context().add_class("sentinel-page-frame")
                frame = builder()
                sc.add(frame)
                self.stack.add_titled(sc, name, name)
            self.switch_page("Dashboard")

        def panel(self) -> Any:
            box = make_box(Gtk.Orientation.VERTICAL, 12, 10)
            box.get_style_context().add_class("sentinel-panel")
            box.get_style_context().add_class("dashboard-shell")
            box.set_hexpand(True); box.set_vexpand(True)
            return box

        def label(self, text: str, css_class: str = "") -> Any:
            lab = make_label(text, 0.0)
            lab.set_line_wrap(True)
            if css_class:
                lab.get_style_context().add_class(css_class)
            return lab

        def make_kpi_card(self, title: str, value: str = "0", subtitle: str = "", cyan: bool = False) -> Any:
            card = make_box(Gtk.Orientation.VERTICAL, 6, 4)
            card.get_style_context().add_class("sentinel-kpi-card")
            card.set_hexpand(True)
            t = self.label(title, "sentinel-section-title")
            v = self.label(value, "sentinel-kpi-value-cyan" if cyan else "sentinel-kpi-value")
            st = self.label(subtitle, "sentinel-muted")
            card.pack_start(t, False, False, 0)
            card.pack_start(v, False, False, 0)
            card.pack_start(st, False, False, 0)
            return card, v

        def heading(self, text: str) -> Any:
            label = make_label(text, 0.0)
            label.get_style_context().add_class("sentinel-heading")
            return label

        def clear_box(self, box: Any) -> None:
            for child in list(box.get_children()):
                box.remove(child)

        def friendly_card(self, title: str, body: str = "", accent: str = "") -> Any:
            card = make_box(Gtk.Orientation.VERTICAL, 5, 4)
            card.get_style_context().add_class("sentinel-card")
            card.set_hexpand(True)
            title_label = self.label(title, "sentinel-section-title")
            card.pack_start(title_label, False, False, 0)
            if body:
                body_label = self.label(body, accent or "sentinel-muted")
                body_label.set_selectable(True)
                card.pack_start(body_label, False, False, 0)
            return card

        def friendly_row(self, title: str, detail: str = "", accent: str = "") -> Any:
            row = make_box(Gtk.Orientation.VERTICAL, 3, 3)
            row.get_style_context().add_class("sentinel-list-panel")
            row.set_hexpand(True)
            title_label = self.label(title, "sentinel-section-title")
            detail_label = self.label(detail or "—", accent or "sentinel-muted")
            detail_label.set_selectable(True)
            row.pack_start(title_label, False, False, 0)
            row.pack_start(detail_label, False, False, 0)
            return row

        def populate_rows(self, box: Any, rows: list, empty: str = "No records yet.") -> None:
            self.clear_box(box)
            if not rows:
                box.pack_start(self.friendly_card("Nothing to show yet", empty), False, False, 0)
            else:
                for title, detail, *rest in rows:
                    accent = rest[0] if rest else ""
                    box.pack_start(self.friendly_row(str(title), str(detail), accent), False, False, 0)
            box.show_all()

        def switch_page(self, name: str) -> None:
            self.stack.set_visible_child_name(name)
            for n, b in self.nav_buttons.items():
                ctx = b.get_style_context()
                if n == name: ctx.add_class("sentinel-nav-active")
                else: ctx.remove_class("sentinel-nav-active")
            self.current_page = name

        def build_dashboard(self) -> Any:
            box = self.panel()
            hero = make_box(Gtk.Orientation.VERTICAL, 6, 4)
            hero.get_style_context().add_class("sentinel-dashboard-hero")
            hero.pack_start(self.label("Sentinel Contacts Command Dashboard", "sentinel-hero-title"), False, False, 0)
            hero.pack_start(self.label(
                "Contacts, groups, relationships, reminders, birthdays, quick-fill, and local app handoff status in one Sentinel/AEGIS view.",
                "sentinel-muted",
            ), False, False, 0)
            hero.pack_start(self.label(
                f"v{VERSION} • Local-only • No network • No telemetry • AEGIS-ready • Database: {db_path()}",
                "sentinel-cyan",
            ), False, False, 0)
            box.pack_start(hero, False, False, 0)

            self.kpi_labels = {}
            grid = Gtk.Grid(column_spacing=18, row_spacing=18)
            grid.set_column_homogeneous(True)
            cards = [
                ("active_contacts", "Active Contacts", "ready to use", True),
                ("organizations", "Organizations", "companies and groups", False),
                ("open_actions", "Open Actions", "local follow-ups", True),
                ("contact_events", "Events", "reminders and meetings", False),
                ("groups", "Groups", "family / work / custom", False),
                ("duplicate_groups", "Duplicate Audit", "possible duplicates", True),
            ]
            for idx, (key, title, subtitle, cyan) in enumerate(cards):
                card, value_label = self.make_kpi_card(title, "0", subtitle, cyan)
                self.kpi_labels[key] = value_label
                grid.attach(card, idx % 2, idx // 2, 1, 1)
            box.pack_start(grid, False, False, 0)

            lower = Gtk.Grid(column_spacing=18, row_spacing=18)
            lower.set_column_homogeneous(True)
            recent_box = make_box(Gtk.Orientation.VERTICAL, 6, 4)
            recent_box.get_style_context().add_class("sentinel-card")
            recent_box.pack_start(self.heading("Recent Contacts"), False, False, 0)
            self.recent_contacts_box = make_box(Gtk.Orientation.VERTICAL, 6, 0)
            recent_box.pack_start(self.recent_contacts_box, True, True, 0)

            bridge_box = make_box(Gtk.Orientation.VERTICAL, 6, 4)
            bridge_box.get_style_context().add_class("sentinel-card")
            bridge_box.pack_start(self.heading("Bridge Readiness"), False, False, 0)
            self.bridge_ready_box = make_box(Gtk.Orientation.VERTICAL, 6, 0)
            bridge_box.pack_start(self.bridge_ready_box, True, True, 0)
            lower.attach(recent_box, 0, 0, 1, 1)
            lower.attach(bridge_box, 1, 0, 1, 1)
            box.pack_start(lower, True, True, 0)
            self.refresh_dashboard()
            return box

        def refresh_dashboard(self) -> None:
            d = dashboard(self.conn)
            if hasattr(self, "kpi_labels"):
                for key in ("active_contacts", "organizations", "open_actions", "contact_events", "groups", "duplicate_groups"):
                    if key in self.kpi_labels:
                        self.kpi_labels[key].set_text(str(d.get(key, 0)))
            if hasattr(self, "recent_contacts_box"):
                rows = []
                for r in d["recent_contacts"][:6]:
                    detail_parts = [r.get("organization") or "No organization", r.get("email") or "No email", r.get("phone") or "No phone"]
                    rows.append((f"{r['code']} — {r['full_name']}", " • ".join(detail_parts)))
                self.populate_rows(self.recent_contacts_box, rows, "Add your first contact from the Contacts page.")
            if hasattr(self, "bridge_ready_box"):
                rows = []
                for app, count in d["bridge_counts"].items():
                    pretty = app.replace("-", " ").title()
                    rows.append((pretty, f"{count} local link(s) prepared"))
                rows.append(("Quick-fill", "Ready for Jobs, Wallet, Password Vault, Documents, and Notes", "sentinel-cyan"))
                rows.append(("Text / email sending", "Disabled placeholder only — no network sender enabled"))
                self.populate_rows(self.bridge_ready_box, rows)

        def build_contacts(self) -> Any:
            box = self.panel()
            box.pack_start(self.heading("Contacts"), False, False, 0)
            form = Gtk.Grid(column_spacing=8, row_spacing=8)
            self.entries = {}
            fields = [("Full name", "full_name"), ("Email", "email"), ("Phone", "phone"), ("Organization", "organization"), ("Role", "role")]
            for i, (label, key) in enumerate(fields):
                form.attach(make_label(label, 0.0), 0, i, 1, 1)
                ent = Gtk.Entry(); ent.set_hexpand(True); self.entries[key] = ent
                form.attach(ent, 1, i, 1, 1)
            add_btn = Gtk.Button(label="Add Contact")
            add_btn.connect("clicked", lambda *_: self.gui_add_contact())
            form.attach(add_btn, 1, len(fields), 1, 1)
            box.pack_start(form, False, False, 0)
            self.store = Gtk.ListStore(str, str, str, str, str)
            tree = Gtk.TreeView(model=self.store)
            tree.get_style_context().add_class("sentinel-contact-list")
            tree.set_headers_visible(True)
            try:
                tree.set_grid_lines(Gtk.TreeViewGridLines.HORIZONTAL)
            except Exception:
                pass
            self.contacts_tree = tree
            for idx, title in enumerate(["Code", "Name", "Organization", "Email", "Phone"]):
                rend = Gtk.CellRendererText()
                rend.set_property("foreground", AEGIS_TEXT)
                col = Gtk.TreeViewColumn(title, rend, text=idx)
                col.set_resizable(True)
                tree.append_column(col)
            tree.connect("button-press-event", self.on_tree_button)
            sw = Gtk.ScrolledWindow(); sw.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC); sw.set_min_content_height(300); sw.get_style_context().add_class("sentinel-list-panel"); sw.add(tree)
            box.pack_start(sw, True, True, 0)
            self.refresh_contacts()
            return box

        def gui_add_contact(self) -> None:
            ns = argparse.Namespace(code=None, code_prefix=None,
                full_name=self.entries['full_name'].get_text().strip() or "Unnamed Contact",
                preferred_name="", type="person", organization=self.entries['organization'].get_text().strip(),
                role=self.entries['role'].get_text().strip(), phone=self.entries['phone'].get_text().strip(), alt_phone="",
                email=self.entries['email'].get_text().strip(), alt_email="", address="", website="", birthday="", tags="",
                priority=3, trust_level=3, status="active", notes="")
            row = add_contact(self.conn, ns)
            for ent in self.entries.values(): ent.set_text("")
            self.refresh_all()
            self.message(f"Added {row['code']} — {row['full_name']}")

        def refresh_contacts(self) -> None:
            self.store.clear()
            for r in list_contacts(self.conn, limit=500):
                self.store.append([r['code'], r['full_name'], r['organization'], r['email'], r['phone']])

        def selected_code(self) -> Optional[str]:
            sel = self.contacts_tree.get_selection()
            model, itr = sel.get_selected()
            if itr:
                return model[itr][0]
            return None

        def on_tree_button(self, tree: Any, event: Any) -> bool:
            if event.button == 3:
                path_info = tree.get_path_at_pos(int(event.x), int(event.y))
                if path_info:
                    tree.set_cursor(path_info[0])
                code = self.selected_code()
                if code:
                    menu = Gtk.Menu()
                    actions = [
                        ("Copy Quick Fill", lambda: self.copy_quick_fill(code)),
                        ("Copy Email", lambda: self.copy_field(code, "email")),
                        ("Copy Phone", lambda: self.copy_field(code, "phone")),
                        ("Copy Jobs Quick Fill", lambda: self.copy_app_quick_fill(code, "jobs")),
                        ("Copy Wallet Quick Fill", lambda: self.copy_app_quick_fill(code, "wallet")),
                        ("Copy Vault Quick Fill", lambda: self.copy_app_quick_fill(code, "password-vault")),
                        ("Copy Documents Quick Fill", lambda: self.copy_app_quick_fill(code, "documents")),
                        ("Copy Notes Quick Fill", lambda: self.copy_app_quick_fill(code, "notes")),
                        ("Copy vCard", lambda: self.copy_vcard(code)),
                        ("Prepare Jobs Link", lambda: self.prepare_bridge(code, "jobs")),
                        ("Prepare Wallet Link", lambda: self.prepare_bridge(code, "wallet")),
                        ("Prepare Password Vault Link", lambda: self.prepare_bridge(code, "password-vault")),
                        ("Prepare Documents Link", lambda: self.prepare_bridge(code, "documents")),
                        ("Prepare Notes Link", lambda: self.prepare_bridge(code, "notes")),
                        ("Record Local Prepare Action", lambda: self.prepare_local_action(code, "jobs")),
                        ("Future: Send Text", lambda: self.message("Future SMS/text action placeholder only — no network sender enabled.")),
                    ]
                    for label, cb in actions:
                        item = Gtk.MenuItem(label=label)
                        item.connect("activate", lambda _i, f=cb: f())
                        menu.append(item)
                    menu.show_all()
                    try:
                        menu.popup_at_pointer(event)
                    except Exception:
                        try:
                            menu.popup(None, None, None, None, event.button, event.time)
                        except Exception as exc:
                            self.message(f"Contact menu could not open: {exc}")
                    return True
            return False

        def copy_quick_fill(self, code: str) -> None:
            txt = quick_fill(self.conn, code)
            Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD).set_text(txt, -1)
            self.message("Quick-fill copied to clipboard.")

        def copy_app_quick_fill(self, code: str, app: str) -> None:
            txt = app_quick_fill(self.conn, code, app)
            Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD).set_text(txt, -1)
            self.message(f"{app} quick-fill copied to clipboard.")

        def copy_vcard(self, code: str) -> None:
            row = parse_contact_identifier(self.conn, code)
            txt = contact_to_vcard(row) if row else ""
            Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD).set_text(txt, -1)
            self.message("vCard copied to clipboard.")

        def prepare_local_action(self, code: str, app: str) -> None:
            a = prepare_contact_action(self.conn, code, app, "quick-fill")
            self.refresh_all()
            self.message(f"Prepared local-only action #{a['id']} for {app}.")

        def copy_field(self, code: str, field: str) -> None:
            row = parse_contact_identifier(self.conn, code)
            txt = row[field] if row else ""
            Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD).set_text(txt or "", -1)
            self.message(f"{field} copied to clipboard.")

        def prepare_bridge(self, code: str, app: str) -> None:
            self.switch_page("Bridges")
            self.bridge_contact.set_text(code)
            self.bridge_app.set_active(BRIDGE_APPS.index(app))

        def build_quick_fill(self) -> Any:
            box = self.panel()
            box.pack_start(self.heading("Quick Fill"), False, False, 0)
            box.pack_start(self.label("Select or type a contact code, name, email, or phone number. The result is copy-friendly and formatted for normal use, not as a console dump.", "sentinel-muted"), False, False, 0)
            row = make_box(Gtk.Orientation.HORIZONTAL, 8, 0)
            self.quick_ident = Gtk.Entry(); self.quick_ident.set_placeholder_text("Contact code/name/email")
            row.pack_start(self.quick_ident, True, True, 0)
            btn = Gtk.Button(label="Generate Quick Fill")
            btn.connect("clicked", lambda *_: self.gui_quick_fill())
            row.pack_start(btn, False, False, 0)
            box.pack_start(row, False, False, 0)
            panel = make_box(Gtk.Orientation.VERTICAL, 6, 4)
            panel.get_style_context().add_class("sentinel-card")
            panel.pack_start(self.heading("Prepared Contact Details"), False, False, 0)
            self.quick_output_label = self.label("No quick-fill generated yet.", "sentinel-muted")
            self.quick_output_label.set_selectable(True)
            panel.pack_start(self.quick_output_label, False, False, 0)
            copy_btn = Gtk.Button(label="Copy Prepared Details")
            copy_btn.connect("clicked", lambda *_: self.copy_quick_label())
            panel.pack_start(copy_btn, False, False, 0)
            box.pack_start(panel, False, False, 0)
            return box

        def gui_quick_fill(self) -> None:
            try:
                txt = quick_fill(self.conn, self.quick_ident.get_text().strip(), "vcard-lite")
            except Exception as exc:
                txt = str(exc)
            self.quick_output_label.set_text(txt)

        def copy_quick_label(self) -> None:
            txt = self.quick_output_label.get_text()
            Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD).set_text(txt or "", -1)
            self.message("Prepared contact details copied.")

        def build_bridges(self) -> Any:
            box = self.panel()
            box.pack_start(self.heading("Bridge Links"), False, False, 0)
            box.pack_start(self.label("Prepare safe local handoff links for other Sentinel apps. These are local records only; this does not write into another app yet.", "sentinel-muted"), False, False, 0)
            grid = Gtk.Grid(column_spacing=8, row_spacing=8)
            self.bridge_contact = Gtk.Entry(); self.bridge_contact.set_placeholder_text("CON-0001")
            self.bridge_app = Gtk.ComboBoxText()
            for app in BRIDGE_APPS: self.bridge_app.append_text(app)
            self.bridge_app.set_active(0)
            self.bridge_ref_type = Gtk.Entry(); self.bridge_ref_type.set_placeholder_text("job/account/document/note")
            self.bridge_ref_value = Gtk.Entry(); self.bridge_ref_value.set_placeholder_text("JOB-0001 / local ref")
            for i, (lab, widget) in enumerate([("Contact", self.bridge_contact), ("App", self.bridge_app), ("Reference type", self.bridge_ref_type), ("Reference value", self.bridge_ref_value)]):
                grid.attach(make_label(lab, 0.0), 0, i, 1, 1); grid.attach(widget, 1, i, 1, 1)
            btn = Gtk.Button(label="Add Bridge Link")
            btn.connect("clicked", lambda *_: self.gui_add_bridge())
            grid.attach(btn, 1, 4, 1, 1)
            box.pack_start(grid, False, False, 0)
            panel = make_box(Gtk.Orientation.VERTICAL, 6, 4)
            panel.get_style_context().add_class("sentinel-card")
            panel.pack_start(self.heading("Local Bridge Summary"), False, False, 0)
            self.bridge_output_box = make_box(Gtk.Orientation.VERTICAL, 6, 0)
            panel.pack_start(self.bridge_output_box, False, False, 0)
            box.pack_start(panel, False, False, 0)
            self.refresh_bridge_output()
            return box

        def gui_add_bridge(self) -> None:
            ns = argparse.Namespace(contact=self.bridge_contact.get_text().strip(), app=self.bridge_app.get_active_text(), reference_type=self.bridge_ref_type.get_text().strip(), reference_value=self.bridge_ref_value.get_text().strip(), label="", notes="")
            try:
                add_bridge(self.conn, ns); self.refresh_bridge_output(); self.refresh_dashboard(); self.message("Bridge link added.")
            except Exception as exc: self.message(str(exc))

        def refresh_bridge_output(self) -> None:
            if not hasattr(self, "bridge_output_box"):
                return
            status = bridge_status(self.conn)
            rows = []
            for app, count in status.get("counts", {}).items():
                rows.append((app.replace("-", " ").title(), f"{count} local link(s)"))
            rows.append(("Quick-fill", "Ready" if status.get("quick_fill_ready") else "Not ready", "sentinel-cyan"))
            rows.append(("Direct external write", "Disabled by design — local handoff only"))
            self.populate_rows(self.bridge_output_box, rows)

        def build_events_calendar(self) -> Any:
            box = self.panel()
            box.pack_start(self.heading("Events / Reminders / Calendar Bridge"), False, False, 0)
            box.pack_start(self.label("Add calls, meetings, birthdays, reminders, and follow-ups. Calendar export stays local as a CSV handoff.", "sentinel-muted"), False, False, 0)
            grid = Gtk.Grid(column_spacing=8, row_spacing=8)
            self.event_contact = Gtk.Entry(); self.event_contact.set_placeholder_text("CON-0001 / name / email")
            self.event_type = Gtk.ComboBoxText()
            for et in ["reminder", "call", "meeting", "birthday", "follow-up", "appointment", "text-draft"]: self.event_type.append_text(et)
            self.event_type.set_active(0)
            self.event_title = Gtk.Entry(); self.event_title.set_placeholder_text("Event title")
            self.event_date = Gtk.Entry(); self.event_date.set_placeholder_text("YYYY-MM-DD")
            self.event_time = Gtk.Entry(); self.event_time.set_placeholder_text("HH:MM optional")
            self.event_location = Gtk.Entry(); self.event_location.set_placeholder_text("Location optional")
            self.event_notes = Gtk.Entry(); self.event_notes.set_placeholder_text("Notes")
            fields = [("Contact", self.event_contact), ("Type", self.event_type), ("Title", self.event_title), ("Date", self.event_date), ("Time", self.event_time), ("Location", self.event_location), ("Notes", self.event_notes)]
            for i, (lab, widget) in enumerate(fields):
                grid.attach(make_label(lab, 0.0), 0, i, 1, 1); grid.attach(widget, 1, i, 1, 1)
            btns = make_box(Gtk.Orientation.HORIZONTAL, 8, 0)
            for label, func in [("Add Event", self.gui_add_event), ("Refresh Due", self.refresh_events_output), ("Export Calendar CSV", self.export_calendar_clicked), ("Export Events JSON", self.export_events_json_clicked)]:
                b = Gtk.Button(label=label); b.connect("clicked", lambda _b, f=func: f()); btns.pack_start(b, False, False, 0)
            box.pack_start(grid, False, False, 0); box.pack_start(btns, False, False, 0)
            panel = make_box(Gtk.Orientation.VERTICAL, 8, 4)
            panel.get_style_context().add_class("sentinel-card")
            panel.pack_start(self.heading("Upcoming Contact Events"), False, False, 0)
            self.events_output_box = make_box(Gtk.Orientation.VERTICAL, 8, 0)
            panel.pack_start(self.events_output_box, False, False, 0)
            box.pack_start(panel, False, False, 0)
            self.refresh_events_output()
            return box

        def gui_add_event(self) -> None:
            try:
                ns = argparse.Namespace(contact=self.event_contact.get_text().strip(), type=self.event_type.get_active_text() or "reminder", title=self.event_title.get_text().strip(), date=self.event_date.get_text().strip(), time=self.event_time.get_text().strip(), location=self.event_location.get_text().strip(), notes=self.event_notes.get_text().strip(), status="scheduled", source="gui")
                row = add_event(self.conn, ns); self.refresh_all(); self.message(f"Event added: {row['title']} on {row['event_date']}")
            except Exception as exc: self.message(str(exc))

        def refresh_events_output(self) -> None:
            if not hasattr(self, "events_output_box"):
                return
            try:
                due = events_due(self.conn, 30)
                birthdays = birthday_report(self.conn, 60)
                rows = []
                for r in due[:8]:
                    day_note = "today" if r.get("days_until") == 0 else (f"overdue by {abs(r.get('days_until',0))} day(s)" if r.get("overdue") else f"in {r.get('days_until')} day(s)")
                    rows.append((f"{r.get('title','Event')} — {r.get('full_name','')}", f"{r.get('event_date','')} {r.get('event_time','')} • {day_note} • {r.get('event_type','')}"))
                for r in birthdays[:5]:
                    rows.append((f"Birthday — {r.get('full_name','')}", f"{r.get('next_birthday','')} • in {r.get('days_until')} day(s)", "sentinel-cyan"))
                self.populate_rows(self.events_output_box, rows, "No contact events or birthdays due soon.")
            except Exception as exc:
                self.populate_rows(self.events_output_box, [("Events could not be refreshed", str(exc))])

        def export_calendar_clicked(self) -> None:
            try:
                p = export_calendar_csv(self.conn, default_export_path('sentinel_contacts_calendar.csv'))
                self.set_io_status(f"Calendar CSV ready: {p}")
                self.message(f"Exported calendar CSV: {p}")
            except Exception as exc: self.message(str(exc))

        def export_events_json_clicked(self) -> None:
            try:
                p = export_events_json(self.conn, default_export_path('sentinel_contacts_events.json'))
                self.set_io_status(f"Events JSON ready: {p}")
                self.message(f"Exported events JSON: {p}")
            except Exception as exc: self.message(str(exc))

        def build_groups_relationships(self) -> Any:
            box = self.panel()
            box.pack_start(self.heading("Groups / Relationships / Duplicate Audit"), False, False, 0)
            box.pack_start(self.label("Create contact groups, link relationships, and review possible duplicate records in plain language.", "sentinel-muted"), False, False, 0)
            grid = Gtk.Grid(column_spacing=8, row_spacing=8)
            self.group_name = Gtk.Entry(); self.group_name.set_placeholder_text("Family / Work / Referees")
            self.group_contact = Gtk.Entry(); self.group_contact.set_placeholder_text("CON-0001")
            self.related_a = Gtk.Entry(); self.related_a.set_placeholder_text("Primary contact")
            self.related_b = Gtk.Entry(); self.related_b.set_placeholder_text("Related contact")
            self.relationship_type = Gtk.Entry(); self.relationship_type.set_placeholder_text("family / colleague / recruiter / referee")
            fields = [("Group name", self.group_name), ("Add contact", self.group_contact), ("Contact A", self.related_a), ("Contact B", self.related_b), ("Relationship", self.relationship_type)]
            for i, (lab, widget) in enumerate(fields):
                grid.attach(make_label(lab, 0.0), 0, i, 1, 1); grid.attach(widget, 1, i, 1, 1)
            btns = make_box(Gtk.Orientation.HORIZONTAL, 8, 0)
            for label, func in [("Create Group", self.gui_create_group), ("Add Contact to Group", self.gui_add_group_member), ("Add Relationship", self.gui_add_relationship), ("Refresh Audit", self.refresh_groups_output)]:
                b = Gtk.Button(label=label); b.connect("clicked", lambda _b, f=func: f()); btns.pack_start(b, False, False, 0)
            box.pack_start(grid, False, False, 0); box.pack_start(btns, False, False, 0)
            panel = make_box(Gtk.Orientation.VERTICAL, 8, 4)
            panel.get_style_context().add_class("sentinel-card")
            panel.pack_start(self.heading("Groups, Relationships, and Duplicate Check"), False, False, 0)
            self.groups_output_box = make_box(Gtk.Orientation.VERTICAL, 8, 0)
            panel.pack_start(self.groups_output_box, False, False, 0)
            box.pack_start(panel, False, False, 0)
            self.refresh_groups_output()
            return box

        def gui_create_group(self) -> None:
            try:
                ns = argparse.Namespace(name=self.group_name.get_text().strip() or "New Group", type="custom", description="", color="")
                g = group_add(self.conn, ns); self.refresh_all(); self.refresh_groups_output(); self.message(f"Group ready: {g['name']}")
            except Exception as exc: self.message(str(exc))

        def gui_add_group_member(self) -> None:
            try:
                row = group_add_contact(self.conn, self.group_name.get_text().strip(), self.group_contact.get_text().strip())
                self.refresh_all(); self.refresh_groups_output(); self.message(f"Added {row['code']} to {row['group_name']}")
            except Exception as exc: self.message(str(exc))

        def gui_add_relationship(self) -> None:
            try:
                row = relationship_add(self.conn, self.related_a.get_text().strip(), self.related_b.get_text().strip(), self.relationship_type.get_text().strip() or "related")
                self.refresh_all(); self.refresh_groups_output(); self.message(f"Relationship ready: {row['contact_code']} -> {row['related_code']}")
            except Exception as exc: self.message(str(exc))

        def refresh_groups_output(self) -> None:
            if not hasattr(self, "groups_output_box"):
                return
            try:
                groups = groups_list(self.conn)
                rels = relationships_for(self.conn)
                dup = duplicate_report(self.conn)
                rows = []
                rows.append(("Groups", f"{len(groups)} group(s) created"))
                rows.append(("Relationships", f"{len(rels)} contact relationship(s) mapped"))
                duplicate_total = len(dup.get("names", [])) + len(dup.get("emails", [])) + len(dup.get("phones", []))
                rows.append(("Duplicate check", "No obvious duplicates found" if duplicate_total == 0 else f"{duplicate_total} possible duplicate group(s) need review", "sentinel-cyan" if duplicate_total == 0 else ""))
                for g in groups[:5]:
                    rows.append((f"Group — {g['name']}", f"Type: {g['group_type'] or 'custom'}"))
                self.populate_rows(self.groups_output_box, rows)
            except Exception as exc:
                self.populate_rows(self.groups_output_box, [("Audit could not be refreshed", str(exc))])

        def build_import_export(self) -> Any:
            box = self.panel()
            box.pack_start(self.heading("Import / Export / Backup"), False, False, 0)
            box.pack_start(self.label("Use these actions to make local copies, exports, and handoff bundles. All outputs stay on this machine.", "sentinel-muted"), False, False, 0)
            grid = Gtk.Grid(column_spacing=10, row_spacing=10)
            actions = [("Export CSV", self.export_csv_clicked), ("Export JSON", self.export_json_clicked), ("Export Bridge JSON", self.export_bridge_clicked), ("Export Calendar CSV", self.export_calendar_clicked), ("Export Events JSON", self.export_events_json_clicked), ("Export vCard", self.export_vcard_clicked), ("Export Contact Bundle", self.export_bundle_clicked), ("Backup Local Database", self.backup_clicked)]
            for idx, (label, func) in enumerate(actions):
                btn = Gtk.Button(label=label); btn.set_hexpand(True); btn.connect("clicked", lambda _b, f=func: f())
                grid.attach(btn, idx % 2, idx // 2, 1, 1)
            box.pack_start(grid, False, False, 0)
            panel = make_box(Gtk.Orientation.VERTICAL, 6, 4)
            panel.get_style_context().add_class("sentinel-card")
            panel.pack_start(self.heading("Last Local Action"), False, False, 0)
            self.io_status_label = self.label("No export or backup has run in this session.", "sentinel-muted")
            self.io_status_label.set_selectable(True)
            panel.pack_start(self.io_status_label, False, False, 0)
            box.pack_start(panel, False, False, 0)
            return box

        def set_io_status(self, text: str) -> None:
            if hasattr(self, "io_status_label"):
                self.io_status_label.set_text(text)

        def build_manual(self) -> Any:
            box = self.panel()
            box.pack_start(self.heading("Manual"), False, False, 0)
            panel = make_box(Gtk.Orientation.VERTICAL, 8, 4)
            panel.get_style_context().add_class("sentinel-card")
            panel.pack_start(self.label(MANUAL_TEXT, "sentinel-muted"), False, False, 0)
            box.pack_start(panel, False, False, 0)
            return box

        def export_csv_clicked(self) -> None:
            p = export_contacts_csv(self.conn, default_export_path("sentinel_contacts.csv"), True); self.set_io_status(f"CSV export ready: {p}"); self.message(f"Exported CSV: {p}")
        def export_json_clicked(self) -> None:
            p = export_contacts_json(self.conn, default_export_path("sentinel_contacts.json"), True); self.set_io_status(f"JSON export ready: {p}"); self.message(f"Exported JSON: {p}")
        def export_bridge_clicked(self) -> None:
            p = export_bridge_json(self.conn, default_export_path("sentinel_contacts_bridge.json")); self.set_io_status(f"Bridge export ready: {p}"); self.message(f"Exported bridge JSON: {p}")
        def export_vcard_clicked(self) -> None:
            p = export_vcard(self.conn, default_export_path("sentinel_contacts.vcf"), True); self.set_io_status(f"vCard export ready: {p}"); self.message(f"Exported vCard: {p}")
        def export_bundle_clicked(self) -> None:
            out = default_export_path(f"sentinel_contacts_bundle_{_dt.datetime.now().strftime('%Y%m%d_%H%M%S')}")
            p = export_contact_bundle(self.conn, out); self.set_io_status(f"Contact bundle ready: {p}"); self.message(f"Exported contact bundle manifest: {p}")
        def repair_launchers_clicked(self) -> None:
            try:
                p = install_desktop_launcher(); self.message(f"Launcher repaired: {p}")
            except Exception as exc:
                self.message(f"Launcher repair failed: {exc}")

        def backup_clicked(self) -> None:
            try:
                p = backup_db(self.conn); self.set_io_status(f"Backup verified: {p}"); self.message(f"Backup VERIFIED: {p}")
            except Exception as exc:
                self.set_io_status(f"Backup failed: {exc}"); self.message(f"Backup failed: {exc}")
        def refresh_all(self) -> None:
            self.refresh_contacts(); self.refresh_dashboard(); self.refresh_bridge_output()
            if hasattr(self, "events_output"):
                self.refresh_events_output()
            if hasattr(self, "refresh_groups_output") and hasattr(self, "groups_output_box"):
                self.refresh_groups_output()
        def message(self, text: str) -> None:
            dlg = Gtk.MessageDialog(parent=self, flags=0, message_type=Gtk.MessageType.INFO, buttons=Gtk.ButtonsType.OK, text=text)
            dlg.run(); dlg.destroy()

    try:
        win = ContactsWindow()
        win.present()
        Gtk.main()
        return 0
    except Exception as exc:
        print(f"Sentinel Contacts GUI startup failed: {exc}", file=sys.stderr)
        return 1


def self_test() -> int:
    with tempfile.TemporaryDirectory(prefix="sentinel_contacts_test_") as td:
        os.environ["SENTINEL_CONTACTS_DB"] = str(Path(td) / "test.sqlite3")
        conn = db()
        ns = argparse.Namespace(code=None, code_prefix=None, full_name="Jane Recruiter", preferred_name="Jane", type="person", organization="Example Co", role="Recruiter", phone="0400000000", alt_phone="", email="jane@example.invalid", alt_email="", address="", website="", birthday="", tags="jobs,recruiter", priority=2, trust_level=4, status="active", notes="test")
        row = add_contact(conn, ns)
        assert row["code"] == "CON-0001"
        assert next_code(conn) == "CON-0002"
        assert parse_contact_identifier(conn, "CON-0001") is not None
        bns = argparse.Namespace(contact="CON-0001", app="jobs", reference_type="job", reference_value="JOB-0001", label="job link", notes="")
        add_bridge(conn, bns)
        q = quick_fill(conn, "CON-0001")
        assert "Jane Recruiter" in q and "jane@example.invalid" in q
        jq = quick_fill(conn, "CON-0001", "jobs")
        assert "Organization: Example Co" in jq
        menu = contact_action_menu(conn, "CON-0001")
        assert menu["local_only"] and not menu["network_sender_enabled"]
        prepare_contact_action(conn, "CON-0001", "jobs", "quick-fill")
        export_quickfill_json(conn, Path(td) / "quickfill.json", True)
        export_app_bridge_json(conn, "jobs", Path(td) / "jobs_bridge.json")
        ns2 = argparse.Namespace(code=None, code_prefix=None, full_name="John Referee", preferred_name="John", type="person", organization="Example Co", role="Referee", phone="0400000001", alt_phone="", email="john@example.invalid", alt_email="", address="", website="", birthday="", tags="referee", priority=3, trust_level=4, status="active", notes="test")
        row2 = add_contact(conn, ns2)
        g = group_add(conn, argparse.Namespace(name="Referees", type="network", description="Reference contacts", color="gold"))
        assert g["name"] == "Referees"
        gm = group_add_contact(conn, "Referees", "CON-0002", "referee", "")
        assert gm["code"] == "CON-0002"
        rel = relationship_add(conn, "CON-0001", "CON-0002", "referee", "")
        assert rel["relationship_type"] == "referee"
        dup = duplicate_report(conn)
        assert "duplicate_email_groups" in dup
        export_groups_csv(conn, Path(td) / "groups.csv")
        export_groups_json(conn, Path(td) / "groups.json")
        export_relationships_csv(conn, Path(td) / "relationships.csv")
        export_relationships_json(conn, Path(td) / "relationships.json")
        ev = add_event(conn, argparse.Namespace(contact="CON-0001", type="call", title="Call Jane", date=(_dt.date.today() + _dt.timedelta(days=7)).isoformat(), time="10:00", location="Phone", notes="test event", status="scheduled", source="self-test"))
        assert ev["title"] == "Call Jane"
        assert events_due(conn, 14)
        birthday_report(conn, 365)
        export_events_csv(conn, Path(td) / "events.csv")
        export_events_json(conn, Path(td) / "events.json")
        export_calendar_csv(conn, Path(td) / "calendar.csv")
        vcf = export_vcard(conn, Path(td) / "contacts.vcf", True)
        assert "BEGIN:VCARD" in vcf.read_text(encoding="utf-8")
        merge = merge_candidates(conn)
        assert merge["local_preview_only"] and not merge["auto_merge_enabled"]
        manifest = export_contact_bundle(conn, Path(td) / "bundle")
        assert manifest.exists()
        before = conn.execute("SELECT COUNT(*) c FROM contacts").fetchone()["c"]
        imp = import_vcard(conn, vcf)
        assert imp["contacts_skipped"] >= 1
        assert conn.execute("SELECT COUNT(*) c FROM contacts").fetchone()["c"] == before
        export_contacts_csv(conn, Path(td) / "contacts.csv", True)
        export_contacts_json(conn, Path(td) / "contacts.json", True)
        export_bridge_json(conn, Path(td) / "bridge.json")
        bp = backup_db(conn, Path(td) / "backup.sqlite3")
        assert bp.exists()
        ar = audit_report(conn)
        assert ar["sqlite_integrity"].lower() == "ok" and ar["readiness"]["stable_lock_ready"]
        sr = stable_lock_report(conn, True)
        assert sr["v1_stable_baseline_locked"] and sr["contacts_v1_ready"]
        v1m = export_v1_bundle(conn, Path(td) / "v1bundle")
        assert v1m.exists()
        conn.close()
        restored = restore_backup(bp, "RESTORE_SENTINEL_CONTACTS")
        assert restored.exists()
        conn = db()
        h = health_json(conn)
        assert h["aegis_capable"] and h["jobs_bridge_ready"] and h["quick_fill_ready"]
        assert h["app_quick_fill_ready"] and h["action_menu_contract_ready"] and h["per_app_bridge_export_ready"]
        assert h["contact_groups_ready"] and h["relationship_mapping_ready"] and h["duplicate_audit_ready"]
        assert h["contacts_list_theme_ready"] and h["white_list_window_removed_ready"] and h["treeview_dark_theme_ready"]
        assert h["sentinel_theme_final_ready"] and h["suite_ribbon_ready"] and h["dark_form_field_theme_ready"]
        assert h["documents_jobs_theme_match_ready"] and h["contacts_full_suite_visual_alignment_ready"]
        assert h["gtk_css_fstring_brace_hotfix_ready"] and h["selection_css_escaped_ready"] and h["gui_rendering_hotfix_ready"]
        assert h["contact_events_ready"] and h["calendar_bridge_csv_ready"] and h["events_calendar_gui_ready"]
        assert h["vcard_export_ready"] and h["vcard_import_ready"] and h["contact_handoff_bundle_ready"] and h["aegis_contacts_v0_9_ready"]
        assert h["gui_startup_rendering_stability_hotfix_ready"] and h["mate_safe_widget_construction_ready"]
        assert h["stable_lock_ready"] and h["v1_stable_baseline_locked"] and h["guarded_restore_ready"] and h["sentinel_contacts_v1_ready"]
    print("Sentinel Contacts self-test passed")
    return 0


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(prog="sentinel-contacts", description=f"{APP_NAME} v{VERSION}")
    sub = parser.add_subparsers(dest="cmd")

    sub.add_parser("init")
    sub.add_parser("gui")
    sub.add_parser("dashboard")
    sub.add_parser("health-json")
    sub.add_parser("aegis-status")
    sub.add_parser("self-test")
    sub.add_parser("next-code")
    p = sub.add_parser("set-code-prefix"); p.add_argument("prefix")
    p = sub.add_parser("manual")
    p = sub.add_parser("install-desktop-launcher")

    p = sub.add_parser("add")
    p.add_argument("full_name")
    p.add_argument("--code")
    p.add_argument("--code-prefix")
    p.add_argument("--preferred-name", default="")
    p.add_argument("--type", default="person")
    p.add_argument("--organization", default="")
    p.add_argument("--role", default="")
    p.add_argument("--phone", default="")
    p.add_argument("--alt-phone", default="")
    p.add_argument("--email", default="")
    p.add_argument("--alt-email", default="")
    p.add_argument("--address", default="")
    p.add_argument("--website", default="")
    p.add_argument("--birthday", default="")
    p.add_argument("--tags", default="")
    p.add_argument("--priority", type=int, default=3)
    p.add_argument("--trust-level", type=int, default=3)
    p.add_argument("--status", default="active")
    p.add_argument("--notes", default="")

    p = sub.add_parser("list"); p.add_argument("--query", default=""); p.add_argument("--include-archived", action="store_true"); p.add_argument("--limit", type=int, default=100)
    p = sub.add_parser("search"); p.add_argument("query"); p.add_argument("--include-archived", action="store_true")
    p = sub.add_parser("view"); p.add_argument("identifier"); p.add_argument("--json", action="store_true")
    p = sub.add_parser("update"); p.add_argument("identifier"); p.add_argument("--full-name"); p.add_argument("--email"); p.add_argument("--phone"); p.add_argument("--organization"); p.add_argument("--role"); p.add_argument("--tags"); p.add_argument("--notes"); p.add_argument("--status")
    p = sub.add_parser("archive"); p.add_argument("identifier")
    p = sub.add_parser("unarchive"); p.add_argument("identifier")

    p = sub.add_parser("quick-fill"); p.add_argument("identifier"); p.add_argument("--format", choices=["default", "email", "phone", "vcard-lite", "jobs", "wallet", "password-vault", "documents", "notes", "text-draft", "email-draft"], default="default")
    p = sub.add_parser("action-menu"); p.add_argument("identifier"); p.add_argument("--json", action="store_true")
    p = sub.add_parser("prepare-action"); p.add_argument("contact"); p.add_argument("--app", required=True, choices=BRIDGE_APPS + ["text-draft", "email-draft"]); p.add_argument("--action", default="quick-fill"); p.add_argument("--target", default="")
    p = sub.add_parser("add-action"); p.add_argument("contact"); p.add_argument("--type", default="follow-up"); p.add_argument("--label", default=""); p.add_argument("--target", default=""); p.add_argument("--details", default=""); p.add_argument("--bridge-app", default=""); p.add_argument("--due-date", default="")
    p = sub.add_parser("actions"); p.add_argument("--contact", default="")
    p = sub.add_parser("group-add"); p.add_argument("name"); p.add_argument("--type", default="custom"); p.add_argument("--description", default=""); p.add_argument("--color", default="")
    p = sub.add_parser("groups")
    p = sub.add_parser("group-add-contact"); p.add_argument("group"); p.add_argument("contact"); p.add_argument("--role", default=""); p.add_argument("--notes", default="")
    p = sub.add_parser("group-members"); p.add_argument("group")
    p = sub.add_parser("relationship-add"); p.add_argument("contact"); p.add_argument("related_contact"); p.add_argument("--type", default="related"); p.add_argument("--notes", default="")
    p = sub.add_parser("relationships"); p.add_argument("--contact", default="")
    p = sub.add_parser("duplicate-report"); p.add_argument("--json", action="store_true")
    p = sub.add_parser("export-groups-csv"); p.add_argument("output", nargs="?")
    p = sub.add_parser("export-groups-json"); p.add_argument("output", nargs="?")
    p = sub.add_parser("export-relationships-csv"); p.add_argument("output", nargs="?")
    p = sub.add_parser("export-relationships-json"); p.add_argument("output", nargs="?")
    p = sub.add_parser("event-add"); p.add_argument("contact"); p.add_argument("--type", default="reminder"); p.add_argument("--title", default=""); p.add_argument("--date", required=True); p.add_argument("--time", default=""); p.add_argument("--location", default=""); p.add_argument("--notes", default=""); p.add_argument("--status", default="scheduled"); p.add_argument("--source", default="cli")
    p = sub.add_parser("events"); p.add_argument("--contact", default=""); p.add_argument("--include-completed", action="store_true"); p.add_argument("--json", action="store_true")
    p = sub.add_parser("events-due"); p.add_argument("--days", type=int, default=30); p.add_argument("--json", action="store_true")
    p = sub.add_parser("birthdays"); p.add_argument("--days", type=int, default=60); p.add_argument("--json", action="store_true")
    p = sub.add_parser("export-events-csv"); p.add_argument("output", nargs="?")
    p = sub.add_parser("export-events-json"); p.add_argument("output", nargs="?")
    p = sub.add_parser("export-calendar-csv"); p.add_argument("output", nargs="?"); p.add_argument("--days", type=int, default=365)
    p = sub.add_parser("export-vcard"); p.add_argument("output", nargs="?"); p.add_argument("--include-archived", action="store_true"); p.add_argument("--identifier", default="")
    p = sub.add_parser("import-vcard"); p.add_argument("input")
    p = sub.add_parser("merge-candidates"); p.add_argument("--json", action="store_true")
    p = sub.add_parser("export-contact-bundle"); p.add_argument("output", nargs="?")
    p = sub.add_parser("bridge-link"); p.add_argument("contact"); p.add_argument("--app", required=True, choices=BRIDGE_APPS); p.add_argument("--reference-type", default=""); p.add_argument("--reference-value", default=""); p.add_argument("--label", default=""); p.add_argument("--notes", default="")
    p = sub.add_parser("bridge-status"); p.add_argument("--json", action="store_true")
    p = sub.add_parser("export-csv"); p.add_argument("output", nargs="?"); p.add_argument("--include-archived", action="store_true")
    p = sub.add_parser("export-json"); p.add_argument("output", nargs="?"); p.add_argument("--include-archived", action="store_true")
    p = sub.add_parser("export-bridge-json"); p.add_argument("output", nargs="?")
    p = sub.add_parser("export-app-bridge-json"); p.add_argument("app", choices=BRIDGE_APPS); p.add_argument("output", nargs="?")
    p = sub.add_parser("export-quickfill-json"); p.add_argument("output", nargs="?"); p.add_argument("--include-archived", action="store_true")
    p = sub.add_parser("import-csv"); p.add_argument("input")
    p = sub.add_parser("backup"); p.add_argument("output", nargs="?")
    p = sub.add_parser("stable-lock-report"); p.add_argument("--json", action="store_true"); p.add_argument("--output", default="")
    p = sub.add_parser("audit-report"); p.add_argument("--json", action="store_true")
    p = sub.add_parser("export-audit-json"); p.add_argument("output", nargs="?")
    p = sub.add_parser("export-audit-csv"); p.add_argument("output", nargs="?")
    p = sub.add_parser("export-v1-bundle"); p.add_argument("output", nargs="?")
    p = sub.add_parser("restore-backup"); p.add_argument("backup_db"); p.add_argument("--confirm", required=True)

    args = parser.parse_args(argv)
    if args.cmd == "manual":
        print(MANUAL_TEXT); return 0
    if args.cmd == "self-test":
        return self_test()
    if args.cmd in (None, "gui"):
        enforce_not_root("GUI/profile access")
        return run_gui()

    # Contacts contains private PII. Avoid accidental sudo/root-owned profile data
    # or widened damage from root writes unless a maintainer explicitly opts in.
    enforce_not_root(args.cmd or "profile access")
    conn = db()
    if args.cmd == "init":
        print(f"Initialized {APP_NAME} database: {db_path()}"); return 0
    if args.cmd == "dashboard":
        print(json.dumps(dashboard(conn), indent=2)); return 0
    if args.cmd in ("health-json", "aegis-status"):
        print(json.dumps(health_json(conn), indent=2)); return 0
    if args.cmd == "next-code":
        print(next_code(conn)); return 0
    if args.cmd == "set-code-prefix":
        set_setting(conn, "code_prefix", args.prefix.upper().strip()); print(f"Code prefix set: {args.prefix.upper().strip()}"); return 0
    if args.cmd == "install-desktop-launcher":
        print(f"Desktop launcher installed: {install_desktop_launcher()}"); return 0
    if args.cmd == "add":
        row = add_contact(conn, args); print(f"Added contact #{row['id']}: {row['code']} — {row['full_name']}"); return 0
    if args.cmd == "list":
        print_table(list_contacts(conn, args.query, args.include_archived, args.limit), ["code", "full_name", "organization", "email", "phone", "status"]); return 0
    if args.cmd == "search":
        print_table(list_contacts(conn, args.query, args.include_archived, 200), ["code", "full_name", "organization", "email", "phone", "status"]); return 0
    if args.cmd == "view":
        row = parse_contact_identifier(conn, args.identifier)
        if not row: raise SystemExit("Contact not found")
        d = contact_to_dict(row)
        if args.json: print(json.dumps(d, indent=2))
        else:
            for k, v in d.items(): print(f"{k}: {v}")
        return 0
    if args.cmd == "update":
        row = update_contact(conn, args.identifier, {"full_name": args.full_name, "email": args.email, "phone": args.phone, "organization": args.organization, "role_title": args.role, "tags": args.tags, "notes": args.notes, "status": args.status})
        print(f"Updated {row['code']} — {row['full_name']}"); return 0
    if args.cmd in ("archive", "unarchive"):
        row = parse_contact_identifier(conn, args.identifier)
        if not row: raise SystemExit("Contact not found")
        val = 1 if args.cmd == "archive" else 0
        conn.execute("UPDATE contacts SET archived=?, updated_at=? WHERE id=?", (val, now_iso(), row["id"])); audit(conn, "contact", row["id"], args.cmd); conn.commit()
        print(f"{args.cmd.title()}d {row['code']}"); return 0
    if args.cmd == "quick-fill":
        print(quick_fill(conn, args.identifier, args.format)); return 0
    if args.cmd == "action-menu":
        payload = contact_action_menu(conn, args.identifier)
        if args.json:
            print(json.dumps(payload, indent=2))
        else:
            print(f"Actions for {payload['contact']['code']} — {payload['contact']['full_name']}")
            print("Copy actions: " + ", ".join(payload["copy_actions"]))
            print("Bridge actions: " + ", ".join(a["app"] for a in payload["bridge_actions"]))
            print("Network sender enabled: false")
        return 0
    if args.cmd == "prepare-action":
        a = prepare_contact_action(conn, args.contact, args.app, args.action, args.target)
        print(f"Prepared local-only action #{a['id']} for {args.contact} -> {args.app}:{args.action}"); return 0
    if args.cmd == "add-action":
        a = add_action(conn, args); print(f"Added action #{a['id']} for {args.contact}"); return 0
    if args.cmd == "actions":
        print_table(actions_for(conn, args.contact or None), ["id", "code", "full_name", "action_type", "label", "bridge_app", "due_date", "completed"]); return 0
    if args.cmd == "group-add":
        g = group_add(conn, args); print(f"Group ready: {g['name']} ({g['group_type']})"); return 0
    if args.cmd == "groups":
        print_table(groups_list(conn), ["id", "name", "group_type", "member_count", "description"]); return 0
    if args.cmd == "group-add-contact":
        m = group_add_contact(conn, args.group, args.contact, args.role, args.notes); print(f"Added {m['code']} — {m['full_name']} to group {m['group_name']}"); return 0
    if args.cmd == "group-members":
        print_table(group_members(conn, args.group), ["code", "full_name", "organization", "email", "phone", "role"]); return 0
    if args.cmd == "relationship-add":
        r = relationship_add(conn, args.contact, args.related_contact, args.type, args.notes); print(f"Relationship ready: {r['contact_code']} -> {r['related_code']} ({r['relationship_type']})"); return 0
    if args.cmd == "relationships":
        print_table(relationships_for(conn, args.contact or None), ["contact_code", "contact_name", "related_code", "related_name", "relationship_type", "notes"]); return 0
    if args.cmd == "duplicate-report":
        payload = duplicate_report(conn)
        if args.json:
            print(json.dumps(payload, indent=2))
        else:
            print("Duplicate names: " + str(len(payload["duplicate_name_groups"])))
            print("Duplicate emails: " + str(len(payload["duplicate_email_groups"])))
            print("Duplicate phones: " + str(len(payload["duplicate_phone_groups"])))
        return 0
    if args.cmd == "export-groups-csv":
        out = Path(args.output) if args.output else default_export_path("sentinel_contacts_groups.csv")
        print(f"Exported groups CSV: {export_groups_csv(conn, out)}"); return 0
    if args.cmd == "export-groups-json":
        out = Path(args.output) if args.output else default_export_path("sentinel_contacts_groups.json")
        print(f"Exported groups JSON: {export_groups_json(conn, out)}"); return 0
    if args.cmd == "export-relationships-csv":
        out = Path(args.output) if args.output else default_export_path("sentinel_contacts_relationships.csv")
        print(f"Exported relationships CSV: {export_relationships_csv(conn, out)}"); return 0
    if args.cmd == "export-relationships-json":
        out = Path(args.output) if args.output else default_export_path("sentinel_contacts_relationships.json")
        print(f"Exported relationships JSON: {export_relationships_json(conn, out)}"); return 0
    if args.cmd == "event-add":
        ev = add_event(conn, args); print(f"Added event #{ev['id']}: {ev['code']} — {ev['title']} on {ev['event_date']}"); return 0
    if args.cmd == "events":
        rows = events_list(conn, args.contact or "", args.include_completed)
        if args.json: print(json.dumps([dict(r) for r in rows], indent=2))
        else: print_table(rows, ["id", "code", "full_name", "event_type", "title", "event_date", "event_time", "status"])
        return 0
    if args.cmd == "events-due":
        payload = events_due(conn, args.days)
        if args.json: print(json.dumps(payload, indent=2))
        else:
            for item in payload: print(f"{item['event_date']} {item.get('event_time','')} {item['code']} {item['full_name']}: {item['title']} ({item['days_until']} days)")
        return 0
    if args.cmd == "birthdays":
        payload = birthday_report(conn, args.days)
        if args.json: print(json.dumps(payload, indent=2))
        else:
            for item in payload: print(f"{item['next_birthday']} {item['code']} {item['full_name']} ({item['days_until']} days)")
        return 0
    if args.cmd == "export-events-csv":
        out = Path(args.output) if args.output else default_export_path("sentinel_contacts_events.csv")
        print(f"Exported events CSV: {export_events_csv(conn, out)}"); return 0
    if args.cmd == "export-events-json":
        out = Path(args.output) if args.output else default_export_path("sentinel_contacts_events.json")
        print(f"Exported events JSON: {export_events_json(conn, out)}"); return 0
    if args.cmd == "export-calendar-csv":
        out = Path(args.output) if args.output else default_export_path("sentinel_contacts_calendar.csv")
        print(f"Exported calendar CSV: {export_calendar_csv(conn, out, args.days)}"); return 0
    if args.cmd == "export-vcard":
        out = Path(args.output) if args.output else default_export_path("sentinel_contacts.vcf")
        print(f"Exported vCard: {export_vcard(conn, out, args.include_archived, args.identifier)}"); return 0
    if args.cmd == "import-vcard":
        print(json.dumps(import_vcard(conn, Path(args.input)), indent=2)); return 0
    if args.cmd == "merge-candidates":
        payload = merge_candidates(conn)
        if args.json: print(json.dumps(payload, indent=2))
        else: print(f"Merge candidate groups: {payload['candidate_group_count']} (preview only; auto-merge disabled)")
        return 0
    if args.cmd == "export-contact-bundle":
        out = Path(args.output) if args.output else default_export_path(f"sentinel_contacts_bundle_{_dt.datetime.now().strftime('%Y%m%d_%H%M%S')}")
        print(f"Exported contact bundle manifest: {export_contact_bundle(conn, out)}"); return 0
    if args.cmd == "bridge-link":
        b = add_bridge(conn, args); print(f"Added bridge link #{b['id']}: {args.contact} -> {args.app}"); return 0
    if args.cmd == "bridge-status":
        bs = bridge_status(conn)
        if args.json: print(json.dumps(bs, indent=2))
        else:
            print(f"Bridge contract: {bs['bridge_contract_version']}")
            for app, count in bs['counts'].items(): print(f"{app}: ready ({count} links)")
        return 0
    if args.cmd == "export-csv":
        out = Path(args.output) if args.output else default_export_path("sentinel_contacts.csv")
        print(f"Exported CSV: {export_contacts_csv(conn, out, args.include_archived)}"); return 0
    if args.cmd == "export-json":
        out = Path(args.output) if args.output else default_export_path("sentinel_contacts.json")
        print(f"Exported JSON: {export_contacts_json(conn, out, args.include_archived)}"); return 0
    if args.cmd == "export-bridge-json":
        out = Path(args.output) if args.output else default_export_path("sentinel_contacts_bridge.json")
        print(f"Exported bridge JSON: {export_bridge_json(conn, out)}"); return 0
    if args.cmd == "export-app-bridge-json":
        out = Path(args.output) if args.output else default_export_path(f"sentinel_contacts_{args.app.replace('-', '_')}_bridge.json")
        print(f"Exported {args.app} bridge JSON: {export_app_bridge_json(conn, args.app, out)}"); return 0
    if args.cmd == "export-quickfill-json":
        out = Path(args.output) if args.output else default_export_path("sentinel_contacts_quickfill.json")
        print(f"Exported quick-fill JSON: {export_quickfill_json(conn, out, args.include_archived)}"); return 0
    if args.cmd == "import-csv":
        print(f"Imported contacts: {import_csv(conn, Path(args.input))}"); return 0
    if args.cmd == "backup":
        out = Path(args.output) if args.output else None
        print(f"Backup VERIFIED: {backup_db(conn, out)}"); print("sqlite integrity check ok"); return 0
    if args.cmd == "stable-lock-report":
        payload = stable_lock_report(conn, args.json)
        if args.output:
            out = Path(args.output); ensure_parent(out)
            if args.json:
                atomic_write_json(out, payload, label="stable lock report output")
            else:
                atomic_write_text(out, str(payload), label="stable lock report output")
            print(f"Stable lock report written: {out}")
        else:
            print(json.dumps(payload, indent=2) if args.json else payload)
        return 0
    if args.cmd == "audit-report":
        payload = audit_report(conn)
        if args.json:
            print(json.dumps(payload, indent=2))
        else:
            print(f"{APP_NAME} audit report v{VERSION}")
            print(f"SQLite integrity: {payload['sqlite_integrity']}")
            print(f"Active contacts: {payload['counts']['active_contacts']}")
            print(f"Bridge links: {payload['counts']['bridge_links']}")
            print(f"Local-only: {payload['local_only']} | Telemetry: {payload['telemetry_enabled']}")
        return 0
    if args.cmd == "export-audit-json":
        out = Path(args.output) if args.output else default_export_path("sentinel_contacts_audit_report.json")
        print(f"Exported audit JSON: {export_audit_json(conn, out)}"); return 0
    if args.cmd == "export-audit-csv":
        out = Path(args.output) if args.output else default_export_path("sentinel_contacts_audit_log.csv")
        print(f"Exported audit CSV: {export_audit_csv(conn, out)}"); return 0
    if args.cmd == "export-v1-bundle":
        out = Path(args.output) if args.output else default_export_path(f"sentinel_contacts_v1_bundle_{_dt.datetime.now().strftime('%Y%m%d_%H%M%S')}")
        print(f"Exported v1 bundle manifest: {export_v1_bundle(conn, out)}"); return 0
    if args.cmd == "restore-backup":
        conn.close()
        restored = restore_backup(Path(args.backup_db), args.confirm)
        print(f"Restore VERIFIED: {restored}")
        print("sqlite integrity check ok")
        return 0
    parser.print_help()
    return 2

if __name__ == "__main__":
    raise SystemExit(main())
