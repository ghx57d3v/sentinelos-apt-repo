# SentinelOS Official Icon Baseline v0.2.5a

This marker records ICONS(1).zip as the official baseline iconset for the v0.2.5a theme-base polish stage.
