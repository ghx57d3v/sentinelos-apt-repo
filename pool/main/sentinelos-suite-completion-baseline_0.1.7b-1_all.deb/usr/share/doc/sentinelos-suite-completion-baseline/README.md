SentinelOS v0.1.7b suite completion baseline meta-package.
