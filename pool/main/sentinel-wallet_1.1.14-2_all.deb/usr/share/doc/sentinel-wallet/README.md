# Sentinel Wallet 1.0.0 Local Foundation

Crypto-only Sentinel Wallet companion for Sentinel Browser and Download Guard.

## v1.0.0 stable lock scope

- Local-first encrypted wallet records.
- Professional Sentinel crypto-wallet dashboard GUI.
- Dashboard-first layout with hidden-by-default totals and eye reveal.
- Add Wallet / recovery-import foundation for 12-word and 24-word recovery phrases.
- Generate Wallet support for BTC, ETH, BNB, XRP, and SOL.
- USDT and USDC display/readiness foundation across ETH, BNB, and SOL.
- ETH, BNB, and SOL NFT local catalogue foundation.
- Explicit local login/proof-of-ownership message signing foundation.
- Browser bridge support for safe open/status/request-response only.

## Security posture

- Crypto-only wallet.
- No debit/credit cards.
- No card autofill, CVV storage, or card payments.
- No browser-side wallet secrets.
- No transaction signing, network broadcast, WalletConnect/dapp approval, or live chain balance lookup in v1.0.0.
- Recovery phrases are displayed at generation time and stored only inside the encrypted wallet record.
- Optional passphrase escrow remains external, encrypted, and explicit opt-in only.

## Deferred to v1.1+ / v1.2+

- WalletConnect / production dapp compatibility.
- Transaction signing.
- Network broadcast.
- Live chain balance lookup.
- Production hot-wallet security review.

## Commands

```bash
sentinel-wallet --gui
sentinel-wallet --v1-readiness-gate
sentinel-wallet --stable-lock-report
sentinel-wallet --phase7-recovery-nft-signing-gui-test
sentinel-wallet --generate-wallet --chain ETH --wallet-name "Main ETH" --recovery-words 24
```


## v1.0.2 Transaction + DApp Login Foundation

Sentinel Wallet v1.0.2 enables explicit user-approved local signing for blockchain app login and selected transaction payloads. Browser-side code must never receive seed phrases, private keys, wallet passphrases, or signing material. Wallet-owned network broadcast remains disabled; signed payloads may be handed back to an external dApp/RPC for broadcast after user approval.

Supported v1.0.2 signing paths:

- ETH / BNB: EIP-191 app-login signatures and EVM legacy raw transaction signing.
- SOL: Ed25519 app-login/raw-payload signing.
- BTC / XRP: receive/watch/login foundation remains available; full transaction builders are deferred to audited patches.

Commands:

```bash
sentinel-wallet --transaction-dapp-status
sentinel-wallet --transaction-dapp-test
sentinel-wallet --sign-dapp-login --wallet-uid WALLET_UID --message "Login challenge"
sentinel-wallet --sign-transaction --wallet-uid WALLET_UID --transaction-json '{"chainId":1,"nonce":0,"gasPrice":"0x3b9aca00","gas":21000,"to":"0x0000000000000000000000000000000000000000","value":0,"data":"0x"}'
```

Mainnet warning: treat mainnet use as user-risk until hardware-backed key storage and independent external security audit are complete.
