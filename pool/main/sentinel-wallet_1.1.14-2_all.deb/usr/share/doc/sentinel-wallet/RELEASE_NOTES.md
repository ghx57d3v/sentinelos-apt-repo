# Sentinel Wallet v1.1.12

Sentinel Banking foundation added: local-only encrypted crypto Bank/Savings/Vault account containers, reward eligibility metadata without active interest/yield, and crypto receipt records. ETH/SOL native provider baseline remains unchanged; BTC/XRP dApp provider support remains deferred.

# Sentinel Wallet 1.0.0

## v1 stable local-foundation lock

- Promoted Sentinel Wallet from v0.7.3 to v1.0.0 as a local-first crypto-only wallet foundation.
- Readiness gate now reports `v1_ready: true` when all local-foundation gates pass.
- Added stable lock report command: `sentinel-wallet --stable-lock-report`.
- Preserves 12/24 word recovery generation and recovery/import foundation.
- Preserves BTC, ETH, BNB, XRP, SOL, USDT, USDC, and ETH/BNB/SOL NFT catalogue foundations.
- Preserves local login/proof message signing foundation.
- Preserves strict no-card, no-browser-secret, no-payment, no-transaction-signing, no-broadcast, no-network posture.
- Explicitly defers WalletConnect, production dapp compatibility, transaction signing, network broadcast, live balance lookup, and hot-wallet security review to later audited phases.


## 1.0.2 — Transaction + DApp Login Foundation

- Enables explicit user-approved local dApp/login message signing.
- Enables ETH/BNB EVM legacy signed raw transaction payload generation.
- Enables SOL raw-payload Ed25519 signing.
- Updates browser bridge contract to allow transaction/login requests while preserving no browser secret storage.
- Keeps wallet-owned network broadcast, live balances, card features, and browser-held secrets disabled.


## v1.0.2 - Wallet Delete GUI Patch

- Adds a Wallets-tab **Delete Wallet** button beside **Add Wallet**.
- Requires typed `DELETE` confirmation and a second confirmation dialog before removing a local encrypted wallet record.
- Adds `sentinel-wallet --delete-wallet --wallet-uid UID --confirm-delete-wallet DELETE`.
- Deletion removes the local wallet record only; it does not delete blockchain assets or independent backups.
