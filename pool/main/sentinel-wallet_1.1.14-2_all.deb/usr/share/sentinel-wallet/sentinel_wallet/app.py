#!/usr/bin/env python3
from __future__ import annotations

import argparse
import base64
import getpass
import hashlib
import json
import os
import re
import secrets
import sqlite3
import stat
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

APP = "Sentinel Wallet"
PACKAGE = "sentinel-wallet"
PROGRAM = "199"
VERSION = "1.1.14"
HOME = Path.home()
DATA_DIR = HOME / ".local/share/sentinel-wallet"
CONFIG_DIR = HOME / ".config/sentinel-wallet"
STATE_DIR = HOME / ".local/state/sentinel-wallet"
DB = DATA_DIR / "wallet.db"
STATUS = STATE_DIR / "aegis-status.json"
BRIDGE_DIR = STATE_DIR / "browser-bridge"
REQUESTS_DIR = BRIDGE_DIR / "requests"
RESPONSES_DIR = BRIDGE_DIR / "responses"
ESCROW_DIR = STATE_DIR / "passphrase-escrow"
PASSWORD_VAULT_HANDOFF_DIR = STATE_DIR / "password-vault-handoff"
WALLETCONNECT_DIR = STATE_DIR / "walletconnect"
NATIVE_PROVIDER_REQUEST_SCHEMA = "sentinel.native_provider.request.v1"
NATIVE_PROVIDER_RESPONSE_SCHEMA = "sentinel.native_provider.response.v1"
NATIVE_PROVIDER_BRIDGE_SCHEMA = "sentinel.native_provider.bridge.v1"

# v1.0.1 doctrine: crypto-only wallet, no cards, explicit user-approved local transaction/app-login signing; no wallet-owned network broadcast.
NO_NETWORK = True
PAYMENTS_ENABLED = True
SIGNING_ENABLED = True
NETWORK_ACCESS_ENABLED = False
CARD_FEATURES_ENABLED = False
CRYPTO_ONLY = True
NFT_SUPPORT_ENABLED = True
SECRET_EXPORT_ENABLED = False
PASSPHRASE_ESCROW_SUPPORTED = True
PASSPHRASE_ESCROW_OPT_IN_ONLY = True
PASSPHRASE_ESCROW_DEFAULT_ENABLED = False
PASSPHRASE_ESCROW_TARGETS = ["aegis-vault", "password-vault", "both"]
GUI_DASHBOARD_ENABLED = True
GUI_FIRST_TAB = "Dashboard"
GUI_TABS = ["Dashboard", "Wallets", "Banking", "Add Wallet", "Generate Wallet", "Sign-In", "Assets", "NFTs", "Escrow", "Security", "Manuals", "Raw Status"]
GUI_STYLE_TARGET = "Professional Sentinel crypto wallet dashboard"
GUI_CONSOLE_OUTPUT_RESTRICTED_TO_RAW_STATUS = True
GUI_TOTALS_HIDDEN_BY_DEFAULT = True
GUI_WALLET_TOTAL_REVEAL_EYE_ENABLED = True
GUI_DASHBOARD_CONSOLE_VIEW_REMOVED = True
GUI_HOTKEYS = {"quit": "Ctrl+Q"}
RECOVERY_WORD_COUNTS = [12, 24]
RECOVERY_PHRASE_DISPLAY_ON_GENERATION = True
RECOVERY_PHRASE_STORED_ENCRYPTED_ONLY = True
GUI_ADD_WALLET_RECOVERY_ENABLED = True
GUI_DELETE_WALLET_ENABLED = True
GUI_DELETE_WALLET_REQUIRES_TYPED_CONFIRMATION = True
GUI_NFT_CATALOGUE_BY_CHAIN_ENABLED = True
DASHBOARD_CHAIN_READY_INDICATORS_ENABLED = True
DASHBOARD_NFT_COUNTS_BY_CHAIN_ENABLED = True
LOGIN_MESSAGE_SIGNING_ENABLED = True
TRANSACTION_SIGNING_ENABLED = True
BROADCAST_ENABLED = False
SIGNING_COMPATIBILITY_NOTE = "User-approved blockchain app login and transaction signing are enabled locally. Browser never stores secrets. Wallet-owned network broadcast remains disabled unless an external dApp/RPC broadcasts the signed payload."

# v1.1.12 / bundle v1.1.17: Sentinel Banking foundation. Banking accounts are
# local-only encrypted crypto account containers. They are not dApp-facing and
# no interest/yield is active at foundation stage.
BANKING_ENABLED = True
BANKING_SCHEMA = "sentinel.wallet.banking_foundation.v1_1_12"
BANKING_ACCOUNT_TYPES = ["bank", "savings", "vault", "watch_only"]
BANKING_DEFAULT_ACCOUNT_TYPE = "savings"
BANKING_REWARD_ELIGIBILITY_FOUNDATION = True
BANKING_REWARD_ACTIVE = False
BANKING_INTERNET_FACING_DEFAULT = False
BANKING_DAPP_CONNECT_DEFAULT = False
BANKING_AEGIS_GUARDED_FOUNDATION = True


# Current v1.0.0 asset implementation target.
# Includes top-market-cap core coins/chains, Solana, and the two primary stablecoins.
SUPPORTED_CHAINS: Dict[str, Dict[str, Any]] = {
    "BTC": {
        "coin": "BTC", "name": "Bitcoin", "blockchain": "Bitcoin", "chain_family": "bitcoin",
        "generation_supported": True, "address_type": "legacy_p2pkh", "nft_supported": False,
        "stablecoins": [], "notes": "Native Bitcoin account generation; signing/broadcast disabled.",
    },
    "ETH": {
        "coin": "ETH", "name": "Ethereum", "blockchain": "Ethereum", "chain_family": "evm",
        "generation_supported": True, "address_type": "eip55_evm", "nft_supported": True,
        "nft_standards": ["ERC-721", "ERC-1155"], "stablecoins": ["USDT", "USDC"],
        "notes": "Ethereum/EVM account generation; signing/broadcast disabled.",
    },
    "BNB": {
        "coin": "BNB", "name": "BNB", "blockchain": "BNB Smart Chain", "chain_family": "evm",
        "generation_supported": True, "address_type": "eip55_evm", "nft_supported": True,
        "nft_standards": ["BEP-721", "BEP-1155"], "stablecoins": ["USDT", "USDC"],
        "notes": "BNB Smart Chain uses EVM address generation; signing/broadcast disabled.",
    },
    "XRP": {
        "coin": "XRP", "name": "XRP", "blockchain": "XRP Ledger", "chain_family": "xrp_ledger",
        "generation_supported": True, "address_type": "classic_xaddress_base58", "nft_supported": False,
        "stablecoins": [], "notes": "XRP Ledger classic address generation; signing/broadcast disabled.",
    },
    "SOL": {
        "coin": "SOL", "name": "Solana", "blockchain": "Solana", "chain_family": "solana",
        "generation_supported": True, "address_type": "ed25519_base58", "nft_supported": True,
        "nft_standards": ["SPL Token", "Metaplex Metadata"], "stablecoins": ["USDT", "USDC"],
        "notes": "Solana Ed25519 account generation; signing/broadcast disabled.",
    },
}
SUPPORTED_STABLECOINS: Dict[str, Dict[str, Any]] = {
    "USDT": {"name": "Tether USD", "symbol": "USDT", "type": "stablecoin", "networks": ["ETH", "BNB", "SOL"], "native_chain": False},
    "USDC": {"name": "USD Coin", "symbol": "USDC", "type": "stablecoin", "networks": ["ETH", "BNB", "SOL"], "native_chain": False},
}
TOP_MARKET_TARGET_COINS = ["BTC", "ETH", "USDT", "BNB", "XRP"]
ADDITIONAL_REQUIRED_COINS = ["SOL", "USDC"]
SUPPORTED_COINS = sorted(set(TOP_MARKET_TARGET_COINS + ADDITIONAL_REQUIRED_COINS))
NFT_NETWORKS = ["ETH", "BNB", "SOL"]

SECP256K1_ORDER = int("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141", 16)
B58_ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
XRP_ALPHABET = "rpshnaf39wBUDNEGHJKLM4PQRST7VWXYZ2bcdefghijkmnopqrstuvwxyz"


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _version_tuple(v: str) -> tuple:
    parts = []
    for x in re.split(r"[^0-9]+", str(v)):
        if x:
            try: parts.append(int(x))
            except Exception: parts.append(0)
    return tuple(parts or [0])




WALLET_ICON_CANDIDATES = [
    Path("/usr/share/icons/hicolor/256x256/apps/sentinel-wallet.png"),
    Path("/usr/share/pixmaps/sentinel-wallet.png"),
    Path("/usr/share/sentinel-wallet/assets/sentinel-wallet-official-logo.png"),
    Path(__file__).resolve().parents[1] / "assets" / "sentinel-wallet-official-logo.png",
    Path(__file__).resolve().parents[4] / "share" / "icons" / "hicolor" / "256x256" / "apps" / "sentinel-wallet.png",
]


def wallet_icon_status() -> Dict[str, Any]:
    paths = [str(p) for p in WALLET_ICON_CANDIDATES]
    found = [str(p) for p in WALLET_ICON_CANDIDATES if p.exists()]
    return {"ok": bool(found), "schema": "sentinel.wallet.official_icon_status.v1_1_7", "version": VERSION, "icon_name": "sentinel-wallet", "official_logo_source": "uploaded SentinelOS(6).png", "paths_checked": paths, "paths_found": found, "desktop_icon_name": "sentinel-wallet"}




def passphrase_escrow_status() -> Dict[str, Any]:
    """Return a browser-safe passphrase escrow capability summary.

    v1.1.9 keeps escrow opt-in only. This helper is intentionally status-only:
    it never returns passphrases, seed phrases, private keys, or encrypted blobs.
    """
    ensure_dirs()
    return {
        "ok": True,
        "schema": "sentinel.wallet.passphrase_escrow_status.v1_1_9",
        "app": APP,
        "package": PACKAGE,
        "program": PROGRAM,
        "version": VERSION,
        "supported": bool(PASSPHRASE_ESCROW_SUPPORTED),
        "default_enabled": bool(PASSPHRASE_ESCROW_DEFAULT_ENABLED),
        "opt_in_only": bool(PASSPHRASE_ESCROW_OPT_IN_ONLY),
        "targets": PASSPHRASE_ESCROW_TARGETS,
        "escrow_dir": str(ESCROW_DIR),
        "browser_may_receive_passphrase": False,
        "browser_may_store_passphrase": False,
        "secret_values_exported": False,
        "status": "supported_opt_in_only" if PASSPHRASE_ESCROW_SUPPORTED else "unsupported",
    }

def apply_wallet_window_icon(root: Any) -> None:
    try:
        import tkinter as tk
        for p in WALLET_ICON_CANDIDATES:
            if p.exists():
                img = tk.PhotoImage(file=str(p))
                root.iconphoto(True, img)
                root._sentinel_wallet_icon_ref = img
                return
    except Exception:
        return

def _path_has_symlink_component(path: Path) -> bool:
    p = Path(path).expanduser()
    cur = Path(p.anchor) if p.is_absolute() else Path.cwd()
    parts = p.parts[1:] if p.is_absolute() else p.parts
    for part in parts:
        cur = cur / part
        try:
            if cur.is_symlink():
                return True
        except OSError:
            return True
    return False


def _ensure_private_dir(path: Path) -> None:
    if _path_has_symlink_component(path):
        raise RuntimeError(f"unsafe symlinked wallet path refused: {path}")
    path.mkdir(parents=True, exist_ok=True)
    try:
        st = path.lstat()
        if not stat.S_ISDIR(st.st_mode):
            raise RuntimeError(f"wallet path is not a directory: {path}")
        os.chmod(path, 0o700, follow_symlinks=False)
    except TypeError:
        path.chmod(0o700)


def _safe_atomic_write_text(path: Path, text: str, mode: int = 0o600) -> None:
    if path.exists() and path.is_symlink():
        raise RuntimeError(f"refusing to overwrite symlink: {path}")
    if _path_has_symlink_component(path.parent):
        raise RuntimeError(f"refusing to write through symlinked parent: {path.parent}")
    _ensure_private_dir(path.parent)
    fd, tmp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent), text=True)
    tmp = Path(tmp_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(text)
        os.chmod(tmp, mode)
        os.replace(tmp, path)
    finally:
        try:
            if tmp.exists(): tmp.unlink()
        except Exception:
            pass


def _safe_append_line(path: Path, line: str, mode: int = 0o600) -> None:
    if path.exists() and path.is_symlink():
        raise RuntimeError(f"refusing to append to symlink: {path}")
    if _path_has_symlink_component(path.parent):
        raise RuntimeError(f"refusing to append through symlinked parent: {path.parent}")
    _ensure_private_dir(path.parent)
    with path.open("a", encoding="utf-8") as fh:
        fh.write(line)
    try:
        os.chmod(path, mode)
    except Exception:
        pass


def ensure_dirs() -> None:
    for d in (DATA_DIR, CONFIG_DIR, STATE_DIR, BRIDGE_DIR, REQUESTS_DIR, RESPONSES_DIR, WALLETCONNECT_DIR, ESCROW_DIR, PASSWORD_VAULT_HANDOFF_DIR):
        _ensure_private_dir(d)


def _safe_request_id(req_id: str) -> str:
    req_id = (req_id or "").strip()
    if not req_id:
        raise ValueError("missing_request_id")
    allowed = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-"
    clean = "".join(ch for ch in req_id if ch in allowed)
    if clean != req_id or len(clean) > 160:
        raise ValueError("invalid_request_id")
    return clean


def _crypto_import_status() -> Dict[str, bool]:
    st = {"cryptography": False, "argon2": False, "aesgcm": False, "secp256k1": False, "ed25519": False}
    try:
        import cryptography  # noqa
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM  # noqa
        from cryptography.hazmat.primitives.asymmetric import ec, ed25519  # noqa
        st["cryptography"] = True
        st["aesgcm"] = True
        st["secp256k1"] = True
        st["ed25519"] = True
    except Exception:
        pass
    try:
        import argon2.low_level  # noqa
        st["argon2"] = True
    except Exception:
        pass
    return st


def derive_key(passphrase: str, salt: bytes, prefer_argon2: bool = True) -> bytes:
    if prefer_argon2:
        try:
            from argon2.low_level import Type, hash_secret_raw
            return hash_secret_raw(passphrase.encode(), salt, time_cost=3, memory_cost=65536, parallelism=2, hash_len=32, type=Type.ID)
        except Exception:
            pass
    return hashlib.pbkdf2_hmac("sha256", passphrase.encode(), salt, 390000, dklen=32)


def encrypt_blob(passphrase: str, plaintext: bytes, aad: bytes = b"sentinel-wallet-v1.0.0") -> Dict[str, str]:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    salt = secrets.token_bytes(16)
    key = derive_key(passphrase, salt)
    nonce = secrets.token_bytes(12)
    ct = AESGCM(key).encrypt(nonce, plaintext, aad)
    return {
        "schema": "sentinel.wallet.encrypted_blob.v1_0_0",
        "salt": base64.b64encode(salt).decode(),
        "nonce": base64.b64encode(nonce).decode(),
        "ciphertext": base64.b64encode(ct).decode(),
        "kdf": "argon2id_or_pbkdf2_fallback",
        "cipher": "AES-256-GCM",
    }


def decrypt_blob(passphrase: str, obj: Dict[str, str], aad: bytes = b"sentinel-wallet-v1.0.0") -> bytes:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    key = derive_key(passphrase, base64.b64decode(obj["salt"]))
    nonce = base64.b64decode(obj["nonce"])
    ct = base64.b64decode(obj["ciphertext"])
    last_exc: Optional[Exception] = None
    for candidate_aad in (aad, b"sentinel-wallet-v0.7.3", b"sentinel-wallet-passphrase-escrow-v0.7.3", b"sentinel-wallet-v0.7.2", b"sentinel-wallet-v0.7.1", b"sentinel-wallet-v0.6.1"):
        try:
            return AESGCM(key).decrypt(nonce, ct, candidate_aad)
        except Exception as exc:
            last_exc = exc
    if last_exc:
        raise last_exc
    raise ValueError("decrypt_failed")


def b58encode(data: bytes, alphabet: str = B58_ALPHABET) -> str:
    n = int.from_bytes(data, "big")
    res = ""
    while n > 0:
        n, r = divmod(n, 58)
        res = alphabet[r] + res
    pad = 0
    for b in data:
        if b == 0:
            pad += 1
        else:
            break
    return alphabet[0] * pad + (res or alphabet[0])


def hash160(data: bytes) -> bytes:
    h = hashlib.new("ripemd160")
    h.update(hashlib.sha256(data).digest())
    return h.digest()


def base58check(version: bytes, payload: bytes, alphabet: str = B58_ALPHABET) -> str:
    raw = version + payload
    checksum = hashlib.sha256(hashlib.sha256(raw).digest()).digest()[:4]
    return b58encode(raw + checksum, alphabet)


# Pure-Python Keccak-256, used for Ethereum/BNB EIP-55 address derivation.
KECCAK_RHO = [
    0, 1, 62, 28, 27,
    36, 44, 6, 55, 20,
    3, 10, 43, 25, 39,
    41, 45, 15, 21, 8,
    18, 2, 61, 56, 14,
]
KECCAK_PI = [
    0, 10, 20, 5, 15,
    16, 1, 11, 21, 6,
    7, 17, 2, 12, 22,
    23, 8, 18, 3, 13,
    14, 24, 9, 19, 4,
]
KECCAK_RC = [
    0x0000000000000001, 0x0000000000008082, 0x800000000000808A,
    0x8000000080008000, 0x000000000000808B, 0x0000000080000001,
    0x8000000080008081, 0x8000000000008009, 0x000000000000008A,
    0x0000000000000088, 0x0000000080008009, 0x000000008000000A,
    0x000000008000808B, 0x800000000000008B, 0x8000000000008089,
    0x8000000000008003, 0x8000000000008002, 0x8000000000000080,
    0x000000000000800A, 0x800000008000000A, 0x8000000080008081,
    0x8000000000008080, 0x0000000080000001, 0x8000000080008008,
]
MASK64 = (1 << 64) - 1


def _rot(x: int, n: int) -> int:
    n %= 64
    return ((x << n) | (x >> (64 - n))) & MASK64


def _keccak_f(st: List[int]) -> None:
    for rc in KECCAK_RC:
        c = [st[x] ^ st[x + 5] ^ st[x + 10] ^ st[x + 15] ^ st[x + 20] for x in range(5)]
        d = [c[(x - 1) % 5] ^ _rot(c[(x + 1) % 5], 1) for x in range(5)]
        for x in range(5):
            for y in range(5):
                st[x + 5 * y] ^= d[x]
        b = [0] * 25
        for i in range(25):
            b[KECCAK_PI[i]] = _rot(st[i], KECCAK_RHO[i])
        for x in range(5):
            for y in range(5):
                st[x + 5 * y] = b[x + 5 * y] ^ ((~b[((x + 1) % 5) + 5 * y]) & b[((x + 2) % 5) + 5 * y])
                st[x + 5 * y] &= MASK64
        st[0] ^= rc


def keccak256(data: bytes) -> bytes:
    rate = 136
    st = [0] * 25
    msg = bytearray(data)
    msg.append(0x01)  # Keccak padding, not SHA3 domain separator.
    while len(msg) % rate != rate - 1:
        msg.append(0)
    msg.append(0x80)
    for off in range(0, len(msg), rate):
        block = msg[off:off + rate]
        for i in range(rate // 8):
            st[i] ^= int.from_bytes(block[i * 8:(i + 1) * 8], "little")
        _keccak_f(st)
    out = bytearray()
    while len(out) < 32:
        for i in range(rate // 8):
            out.extend(st[i].to_bytes(8, "little"))
            if len(out) >= 32:
                return bytes(out[:32])
        _keccak_f(st)
    return bytes(out[:32])


def evm_checksum_address(addr20: bytes) -> str:
    lower = addr20.hex()
    hh = keccak256(lower.encode()).hex()
    out = ""
    for i, c in enumerate(lower):
        out += c.upper() if int(hh[i], 16) >= 8 else c
    return "0x" + out


# Sentinel Wallet v1.0.0 recovery phrase foundation.
# This is a local recovery phrase generator foundation for Sentinel Wallet records.
# It deliberately avoids claiming audited BIP39/BIP44 compatibility until the restore/signing
# path receives a dedicated security review.
SENTINEL_MNEMONIC_WORDS = """
ability able about above absent absorb abstract access account acid across action active actual adapt add adjust advance advice aegis affair afford again agent agree ahead alert album alpha amber angle animal answer apple archive armor arrow asset atom audit autumn avoid axis baby backup balance banner basic battle beach beacon beauty because become before benefit beyond bicycle binary bitter blade blanket blossom border brave bridge bright bronze browser bubble build bundle cactus camera canal canvas carbon castle catalog caution cedar center chain chalk chapter charge charm check circle citizen city clear client cloud coast code coin color column comfort command common copper coral correct cotton craft cradle crypto crystal cyber damage danger daring dawn deal decade defend degree delta desert detail diary digital dinner document dolphin dragon dream drift dynamic eagle early earth east echo economy edit elder electric elegant element ember energy engine enough enter equal escape ethics event exact fabric factor family famous farm fast father feather fence field file final finance finger fire firm fiscal flag flame flower folder forest forge fortune frame freedom fresh friend frost future galaxy garden gentle ghost giant glass gold grace grain graph gravity green guard hammer harbor harmony harvest health heart hidden history honest honey horizon host human humble image index inner island item ivory jacket job journey joy judge jungle key kind king knife knowledge label ladder lake language laser ledger legacy legal lemon library light limit local logic loyal lunar machine magic manual maple market master matrix media memory menu metal mirror mobile model modern month moral motion mountain network noble north note number ocean offer office olive omega online open option orange orbit order organ palace panel paper parent park path peace pearl pencil people phrase pillar planet pledge pocket policy power price prime private program proof public pulse purpose quantum quiet radar random ready reason record recover refuge repair repeat report rescue reveal rhythm river rocket safe safety sample scan school screen script search secure seed select sensor shadow shield signal silent silver simple skill sky smart solar solid source spark spirit stable stage star state steel stone stream strong sugar summit supply symbol system table talent task theme theory timber token tool tower trace trade tree trust truth user valid value vault verify victory vision wallet watch water west window wisdom wolf word world worthy yellow zone
""".split()


def generate_recovery_phrase(word_count: int = 24) -> str:
    if int(word_count) not in RECOVERY_WORD_COUNTS:
        raise ValueError("invalid_recovery_word_count")
    return " ".join(secrets.choice(SENTINEL_MNEMONIC_WORDS) for _ in range(int(word_count)))


def _derive_seed_from_recovery_phrase(recovery_phrase: str, chain: str) -> bytes:
    phrase = " ".join((recovery_phrase or "").strip().lower().split())
    if not phrase:
        raise ValueError("missing_recovery_phrase")
    salt = ("sentinel-wallet-v0.7.3:" + (chain or "wallet").upper()).encode()  # v1 preserves v0.7.3 deterministic recovery namespace
    return hashlib.pbkdf2_hmac("sha512", phrase.encode(), salt, 2048, dklen=64)


def init_db() -> None:
    ensure_dirs()
    if DB.exists() and DB.is_symlink():
        raise RuntimeError(f"wallet database symlink refused: {DB}")
    if _path_has_symlink_component(DB.parent):
        raise RuntimeError(f"wallet database parent symlink refused: {DB.parent}")
    con = sqlite3.connect(DB)
    con.executescript("""
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS wallet_meta(key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS generated_wallets(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    wallet_uid TEXT NOT NULL UNIQUE,
    label TEXT NOT NULL,
    chain TEXT NOT NULL,
    coin TEXT NOT NULL,
    blockchain TEXT NOT NULL,
    address TEXT NOT NULL,
    address_type TEXT NOT NULL,
    public_material TEXT NOT NULL,
    encrypted_secret TEXT NOT NULL,
    secret_kind TEXT NOT NULL,
    created_at TEXT NOT NULL,
    notes TEXT
);
CREATE TABLE IF NOT EXISTS crypto_accounts(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    label TEXT NOT NULL,
    network TEXT NOT NULL,
    public_address TEXT,
    watch_only INTEGER NOT NULL DEFAULT 1,
    created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS nft_records(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    network TEXT NOT NULL,
    mint_or_token_id TEXT NOT NULL,
    collection TEXT,
    item_name TEXT,
    owner_address TEXT,
    metadata_uri TEXT,
    media_uri TEXT,
    notes TEXT,
    created_at INTEGER NOT NULL
);
""")
    meta = [
        ("schema", "sentinel.wallet.v1.0.0"),
        ("wallet_type", "crypto_only"),
        ("payments_enabled", "false"),
        ("card_features_enabled", "false"),
        ("nft_support_enabled", "true"),
        ("browser_bridge_schema", "sentinel.wallet.browser_bridge_contract.v1_0_0"),
        ("supported_coins", json.dumps(SUPPORTED_COINS)),
        ("supported_chains", json.dumps(list(SUPPORTED_CHAINS.keys()))),
        ("supported_stablecoins", json.dumps(list(SUPPORTED_STABLECOINS.keys()))),
        ("multiple_wallets_allowed", "true"),
    ]
    con.executemany("INSERT OR REPLACE INTO wallet_meta(key,value) VALUES(?,?)", meta)
    con.commit()
    con.close()
    try:
        os.chmod(DB, 0o600)
    except Exception:
        pass


def _secp256k1_key_material(chain: str) -> Dict[str, Any]:
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.hazmat.primitives import serialization
    priv_int = secrets.randbelow(SECP256K1_ORDER - 1) + 1
    priv = ec.derive_private_key(priv_int, ec.SECP256K1())
    pub = priv.public_key().public_numbers()
    x = pub.x.to_bytes(32, "big")
    y = pub.y.to_bytes(32, "big")
    compressed = (b"\x03" if (pub.y & 1) else b"\x02") + x
    raw_private = priv_int.to_bytes(32, "big")
    if chain == "BTC":
        address = base58check(b"\x00", hash160(compressed), B58_ALPHABET)
        address_type = "bitcoin_legacy_p2pkh"
    elif chain == "XRP":
        address = base58check(b"\x00", hash160(compressed), XRP_ALPHABET)
        address_type = "xrp_classic_address"
    else:
        address = evm_checksum_address(keccak256(x + y)[-20:])
        address_type = "eip55_evm_address"
    return {"private_material": raw_private, "public_material": compressed.hex(), "address": address, "address_type": address_type, "secret_kind": "secp256k1_private_key"}



def _secp256k1_key_material_from_private(chain: str, raw_private: bytes) -> Dict[str, Any]:
    from cryptography.hazmat.primitives.asymmetric import ec
    priv_int = int.from_bytes(raw_private, "big") % (SECP256K1_ORDER - 1) + 1
    priv = ec.derive_private_key(priv_int, ec.SECP256K1())
    pub = priv.public_key().public_numbers()
    x = pub.x.to_bytes(32, "big")
    y = pub.y.to_bytes(32, "big")
    compressed = (b"\x03" if (pub.y & 1) else b"\x02") + x
    raw_private = priv_int.to_bytes(32, "big")
    if chain == "BTC":
        address = base58check(b"\x00", hash160(compressed), B58_ALPHABET)
        address_type = "bitcoin_legacy_p2pkh"
    elif chain == "XRP":
        address = base58check(b"\x00", hash160(compressed), XRP_ALPHABET)
        address_type = "xrp_classic_address"
    else:
        address = evm_checksum_address(keccak256(x + y)[-20:])
        address_type = "eip55_evm_address"
    return {"private_material": raw_private, "public_material": compressed.hex(), "address": address, "address_type": address_type, "secret_kind": "secp256k1_private_key"}


def _key_material_from_recovery_phrase(chain: str, recovery_phrase: str) -> Dict[str, Any]:
    seed = _derive_seed_from_recovery_phrase(recovery_phrase, chain)
    if chain == "SOL":
        return _solana_key_material_from_seed(seed[:32])
    return _secp256k1_key_material_from_private(chain, seed[:32])

def _solana_key_material() -> Dict[str, Any]:
    from cryptography.hazmat.primitives.asymmetric import ed25519
    from cryptography.hazmat.primitives import serialization
    priv = ed25519.Ed25519PrivateKey.generate()
    raw = priv.private_bytes(encoding=serialization.Encoding.Raw, format=serialization.PrivateFormat.Raw, encryption_algorithm=serialization.NoEncryption())
    pub = priv.public_key().public_bytes(encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw)
    return {"private_material": raw, "public_material": pub.hex(), "address": b58encode(pub), "address_type": "solana_ed25519_base58", "secret_kind": "ed25519_private_seed"}



def _solana_key_material_from_seed(raw_seed: bytes) -> Dict[str, Any]:
    from cryptography.hazmat.primitives.asymmetric import ed25519
    from cryptography.hazmat.primitives import serialization
    seed = raw_seed[:32]
    priv = ed25519.Ed25519PrivateKey.from_private_bytes(seed)
    pub = priv.public_key().public_bytes(encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw)
    return {"private_material": seed, "public_material": pub.hex(), "address": b58encode(pub), "address_type": "solana_ed25519_base58", "secret_kind": "ed25519_private_seed"}

def generate_wallet_record(label: str, chain: str, passphrase: str, persist: bool = True, recovery_word_count: int = 24, confirm_passphrase: str = "") -> Dict[str, Any]:
    init_db()
    chain = (chain or "").upper().strip()
    if chain not in SUPPORTED_CHAINS:
        raise ValueError(f"unsupported_chain:{chain}")
    if not passphrase:
        raise ValueError("missing_passphrase")
    if confirm_passphrase and confirm_passphrase != passphrase:
        raise ValueError("passphrase_confirmation_mismatch")
    recovery_word_count = int(recovery_word_count or 24)
    recovery_phrase = generate_recovery_phrase(recovery_word_count)
    meta = SUPPORTED_CHAINS[chain]
    km = _key_material_from_recovery_phrase(chain, recovery_phrase)
    wallet_uid = f"SW-{chain}-{secrets.token_hex(8).upper()}"
    secret_obj = {
        "schema": "sentinel.wallet.generated_secret_material.v1_0_0",
        "wallet_uid": wallet_uid,
        "chain": chain,
        "coin": meta["coin"],
        "recovery_phrase": recovery_phrase,
        "recovery_word_count": recovery_word_count,
        "recovery_phrase_kind": "sentinel_recovery_phrase_foundation",
        "bip39_audited_compatible": False,
        "private_material_b64": base64.b64encode(km["private_material"]).decode(),
        "created_at": now_iso(),
        "message_signing_enabled": LOGIN_MESSAGE_SIGNING_ENABLED,
        "transaction_signing_enabled": False,
        "broadcast_enabled": False,
    }
    encrypted = encrypt_blob(passphrase, json.dumps(secret_obj, sort_keys=True).encode())
    if persist:
        con = sqlite3.connect(DB)
        con.execute(
            "INSERT INTO generated_wallets(wallet_uid,label,chain,coin,blockchain,address,address_type,public_material,encrypted_secret,secret_kind,created_at,notes) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
            (wallet_uid, label or f"{chain} Wallet", chain, meta["coin"], meta["blockchain"], km["address"], km["address_type"], km["public_material"], json.dumps(encrypted, sort_keys=True), km["secret_kind"], now_iso(), f"Generated locally from a {recovery_word_count}-word Sentinel recovery phrase. Transaction signing and broadcasting disabled; local message signing enabled for explicit user-approved login/proof requests."),
        )
        con.commit(); con.close()
    return {
        "ok": True,
        "schema": "sentinel.wallet.generate_wallet_result.v1_0_0",
        "version": VERSION,
        "wallet_uid": wallet_uid,
        "label": label or f"{chain} Wallet",
        "chain": chain,
        "coin": meta["coin"],
        "blockchain": meta["blockchain"],
        "address": km["address"],
        "address_type": km["address_type"],
        "stored_encrypted": bool(persist),
        "multiple_wallets_allowed": True,
        "recovery_phrase": recovery_phrase,
        "recovery_word_count": recovery_word_count,
        "recovery_phrase_displayed_once": True,
        "recovery_phrase_stored_encrypted_only": True,
        "bip39_audited_compatible": False,
        "master_passphrase_stored": False,
        "private_key_exported": False,
        "signing_enabled": False,
        "message_signing_enabled": LOGIN_MESSAGE_SIGNING_ENABLED,
        "transaction_signing_enabled": False,
        "broadcast_enabled": False,
        "network_access_enabled": False,
    }



def import_wallet_from_recovery_phrase(label: str, chain: str, recovery_phrase: str, passphrase: str, persist: bool = True, confirm_passphrase: str = "") -> Dict[str, Any]:
    """Recover/import a wallet from an existing recovery phrase into encrypted local storage.

    This RC24 path accepts 12/24-word phrases and derives local keys using the Sentinel
    Wallet derivation foundation. Full external BIP39/BIP44 compatibility validation remains
    a dedicated security-review gate before production signing/broadcast claims.
    """
    init_db()
    chain = (chain or "").upper().strip()
    if chain not in SUPPORTED_CHAINS:
        raise ValueError(f"unsupported_chain:{chain}")
    if not passphrase:
        raise ValueError("missing_passphrase")
    if confirm_passphrase and confirm_passphrase != passphrase:
        raise ValueError("passphrase_confirmation_mismatch")
    phrase = " ".join((recovery_phrase or "").strip().lower().split())
    words = phrase.split()
    if len(words) not in RECOVERY_WORD_COUNTS:
        raise ValueError("recovery_phrase_must_be_12_or_24_words")
    meta = SUPPORTED_CHAINS[chain]
    km = _key_material_from_recovery_phrase(chain, phrase)
    wallet_uid = f"SW-{chain}-REC-{secrets.token_hex(8).upper()}"
    secret_obj = {
        "schema": "sentinel.wallet.imported_secret_material.v1_0_0",
        "wallet_uid": wallet_uid,
        "chain": chain,
        "coin": meta["coin"],
        "recovery_phrase": phrase,
        "recovery_word_count": len(words),
        "recovery_phrase_kind": "imported_recovery_phrase_foundation",
        "bip39_bip44_external_compatibility_audit_required": True,
        "private_material_b64": base64.b64encode(km["private_material"]).decode(),
        "created_at": now_iso(),
        "message_signing_enabled": LOGIN_MESSAGE_SIGNING_ENABLED,
        "transaction_signing_enabled": False,
        "broadcast_enabled": False,
    }
    encrypted = encrypt_blob(passphrase, json.dumps(secret_obj, sort_keys=True).encode())
    if persist:
        con = sqlite3.connect(DB)
        con.execute(
            "INSERT INTO generated_wallets(wallet_uid,label,chain,coin,blockchain,address,address_type,public_material,encrypted_secret,secret_kind,created_at,notes) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
            (wallet_uid, label or f"Recovered {chain} Wallet", chain, meta["coin"], meta["blockchain"], km["address"], km["address_type"], km["public_material"], json.dumps(encrypted, sort_keys=True), km["secret_kind"], now_iso(), f"Recovered/imported locally from a {len(words)}-word recovery phrase. Transaction signing and broadcasting disabled; local message signing enabled."),
        )
        con.commit(); con.close()
    return {
        "ok": True,
        "schema": "sentinel.wallet.import_wallet_result.v1_0_0",
        "version": VERSION,
        "wallet_uid": wallet_uid,
        "label": label or f"Recovered {chain} Wallet",
        "chain": chain,
        "coin": meta["coin"],
        "blockchain": meta["blockchain"],
        "address": km["address"],
        "address_type": km["address_type"],
        "stored_encrypted": bool(persist),
        "recovery_word_count": len(words),
        "bip39_bip44_external_compatibility_audit_required": True,
        "master_passphrase_stored": False,
        "private_key_exported": False,
        "message_signing_enabled": True,
        "transaction_signing_enabled": False,
        "broadcast_enabled": False,
        "network_access_enabled": False,
    }


def _load_wallet_secret(wallet_uid: str, passphrase: str) -> Dict[str, Any]:
    init_db()
    uid = (wallet_uid or "").strip()
    if not uid:
        raise ValueError("missing_wallet_uid")
    con = sqlite3.connect(DB)
    row = con.execute("SELECT encrypted_secret FROM generated_wallets WHERE wallet_uid=?", (uid,)).fetchone()
    con.close()
    if not row:
        raise ValueError("wallet_not_found")
    blob = json.loads(row[0])
    return json.loads(decrypt_blob(passphrase, blob).decode())


def sign_login_message(wallet_uid: str, passphrase: str, message: str, origin: str = "") -> Dict[str, Any]:
    """Sign a human-readable login/proof message with explicit user passphrase.

    This is not a transaction signer and it performs no network broadcast. Browser-side
    code does not receive wallet passwords, recovery phrases, or private keys.
    """
    if not LOGIN_MESSAGE_SIGNING_ENABLED:
        raise ValueError("message_signing_disabled")
    if not passphrase:
        raise ValueError("missing_passphrase")
    msg = str(message or "").strip()
    if not msg:
        raise ValueError("missing_message")
    secret = _load_wallet_secret(wallet_uid, passphrase)
    chain = (secret.get("chain") or "").upper()
    private_material = base64.b64decode(secret.get("private_material_b64", ""))
    timestamp = now_iso()
    signing_payload = {
        "app": APP,
        "purpose": "login_message_signature",
        "chain": chain,
        "wallet_uid": wallet_uid,
        "origin": origin or "local-wallet-gui",
        "message": msg,
        "timestamp": timestamp,
        "transaction_signing": False,
        "broadcast": False,
    }
    payload_bytes = json.dumps(signing_payload, sort_keys=True).encode()
    if chain == "SOL":
        from cryptography.hazmat.primitives.asymmetric import ed25519
        priv = ed25519.Ed25519PrivateKey.from_private_bytes(private_material[:32])
        signature = priv.sign(payload_bytes)
        signature_format = "ed25519_base64"
        digest_hex = hashlib.sha256(payload_bytes).hexdigest()
        sig_out = base64.b64encode(signature).decode()
    else:
        from cryptography.hazmat.primitives.asymmetric import ec
        from cryptography.hazmat.primitives import hashes
        priv_int = int.from_bytes(private_material[:32], "big") % (SECP256K1_ORDER - 1) + 1
        priv = ec.derive_private_key(priv_int, ec.SECP256K1())
        if chain in {"ETH", "BNB"}:
            prefixed = (f"\x19Ethereum Signed Message:\n{len(msg)}" + msg).encode()
            digest = keccak256(prefixed)
            signature = priv.sign(digest, ec.ECDSA(hashes.SHA256()))
            signature_format = "secp256k1_der_over_eip191_hash_foundation"
            digest_hex = digest.hex()
        else:
            digest = hashlib.sha256(payload_bytes).digest()
            signature = priv.sign(digest, ec.ECDSA(hashes.SHA256()))
            signature_format = "secp256k1_der_over_sha256_foundation"
            digest_hex = digest.hex()
        sig_out = base64.b64encode(signature).decode()
    return {
        "ok": True,
        "schema": "sentinel.wallet.login_message_signature.v1_0_0",
        "version": VERSION,
        "wallet_uid": wallet_uid,
        "chain": chain,
        "origin": origin or "local-wallet-gui",
        "message_preview": msg[:160],
        "message_hash_hex": digest_hex,
        "signature": sig_out,
        "signature_format": signature_format,
        "transaction_signing_enabled": False,
        "network_broadcast_enabled": False,
        "browser_secret_values_exported": False,
        "compatibility_note": SIGNING_COMPATIBILITY_NOTE + " WalletConnect/production dapp compatibility still requires a dedicated audit phase.",
    }

def list_wallets() -> Dict[str, Any]:
    init_db()
    con = sqlite3.connect(DB)
    rows = con.execute("SELECT wallet_uid,label,chain,coin,blockchain,address,address_type,created_at,notes FROM generated_wallets ORDER BY id DESC").fetchall()
    con.close()
    items = [
        {"wallet_uid": r[0], "label": r[1], "chain": r[2], "coin": r[3], "blockchain": r[4], "address": r[5], "address_type": r[6], "created_at": r[7], "notes": r[8]}
        for r in rows
    ]
    return {"ok": True, "schema": "sentinel.wallet.wallet_list.v1_0_0", "version": VERSION, "count": len(items), "items": items, "secret_values_exported": False}


# v1.1.10 GUI Records Hotfix: the v1.1.9 browser-bridge GUI launcher
# called these helpers from refresh_dashboard()/refresh_wallets(), but the
# helper definitions were accidentally absent from the packaged app.py. Keep
# these public-record helpers secret-free and local-only.
def _short_address(addr: str, left: int = 8, right: int = 6) -> str:
    addr = str(addr or "")
    if len(addr) <= left + right + 3:
        return addr
    return f"{addr[:left]}…{addr[-right:]}"


def wallet_gui_records() -> Dict[str, Any]:
    """Return public wallet-card records for the GUI without secret material."""
    wallets = list_wallets()
    items: List[Dict[str, Any]] = []
    for item in wallets.get("items", []):
        coin = item.get("coin") or item.get("chain") or "WALLET"
        items.append({
            "wallet_uid": item.get("wallet_uid", ""),
            "label": item.get("label") or f"{coin} Wallet",
            "chain": item.get("chain", ""),
            "coin": coin,
            "blockchain": item.get("blockchain", ""),
            "address": item.get("address", ""),
            "address_short": _short_address(item.get("address", "")),
            "created_at": item.get("created_at", ""),
            "native_total": f"0.000000 {coin}",
            "fiat_total": "$0.00 local",
            "total_source": "local record only; live chain balance lookup disabled",
            "private_key_exported": False,
            "secret_values_exported": False,
        })
    return {
        "ok": True,
        "schema": "sentinel.wallet.gui_records.v1_1_10",
        "version": VERSION,
        "count": len(items),
        "wallet_totals_hidden_by_default": GUI_TOTALS_HIDDEN_BY_DEFAULT,
        "wallet_total_reveal_eye_enabled": GUI_WALLET_TOTAL_REVEAL_EYE_ENABLED,
        "live_balance_lookup_enabled": False,
        "items": items,
        "secret_values_exported": False,
    }


def gui_portfolio_summary() -> Dict[str, Any]:
    records = wallet_gui_records()
    by_chain: Dict[str, int] = {}
    for item in records.get("items", []):
        chain = item.get("chain") or "UNKNOWN"
        by_chain[chain] = by_chain.get(chain, 0) + 1
    return {
        "ok": True,
        "schema": "sentinel.wallet.gui_portfolio_summary.v1_1_10",
        "version": VERSION,
        "wallet_count": records.get("count", 0),
        "portfolio_total_native": "0.000000 local recorded",
        "portfolio_total_fiat": "$0.00 local",
        "totals_hidden_by_default": GUI_TOTALS_HIDDEN_BY_DEFAULT,
        "eye_reveal_enabled": GUI_WALLET_TOTAL_REVEAL_EYE_ENABLED,
        "live_balance_lookup_enabled": False,
        "by_chain": by_chain,
        "supported_chains": list(SUPPORTED_CHAINS.keys()),
        "stablecoins": list(SUPPORTED_STABLECOINS.keys()),
        "nft_networks": NFT_NETWORKS,
        "secret_values_exported": False,
    }


def wallet_dashboard_status() -> Dict[str, Any]:
    init_db()
    wallets = list_wallets()
    nfts = nft_status()
    assets = asset_support_status()
    escrow = passphrase_escrow_status()
    return {
        "ok": True,
        "schema": "sentinel.wallet.dashboard_status.v1_1_10",
        "app": APP,
        "version": VERSION,
        "first_tab": GUI_FIRST_TAB,
        "gui_dashboard_enabled": GUI_DASHBOARD_ENABLED,
        "wallet_type": "crypto_only",
        "wallet_count": wallets.get("count", 0),
        "nft_record_count": nfts.get("local_inventory_count", nfts.get("local_record_count", 0)),
        "supported_chains": list(SUPPORTED_CHAINS.keys()),
        "supported_coins": SUPPORTED_COINS,
        "supported_stablecoins": list(SUPPORTED_STABLECOINS.keys()),
        "nft_networks": NFT_NETWORKS,
        "generate_wallet_supported": True,
        "multiple_wallets_allowed": True,
        "recovery_phrase_word_counts": RECOVERY_WORD_COUNTS,
        "recovery_phrase_display_on_generation": RECOVERY_PHRASE_DISPLAY_ON_GENERATION,
        "passphrase_escrow_supported": escrow.get("supported") is True,
        "card_features_enabled": False,
        "signing_enabled": bool(SIGNING_ENABLED),
        "message_signing_enabled": bool(LOGIN_MESSAGE_SIGNING_ENABLED),
        "dapp_login_enabled": True,
        "transaction_signing_enabled": bool(TRANSACTION_SIGNING_ENABLED),
        "broadcast_enabled": False,
        "network_access_enabled": False,
        "wallet_owned_broadcast_enabled": False,
        "browser_secret_access": False,
        "native_provider_core_enabled": native_provider_core_status().get("native_provider_core_enabled") is True,
        "evm_has_wallet": evm_provider_status().get("has_evm_wallet") is True,
        "solana_has_wallet": solana_provider_status().get("has_solana_wallet") is True,
        "banking": banking_status(),
        "status_message": "Dashboard ready. Local ETH/EVM + SOL/Solana native provider baseline; no browser secrets; no wallet-owned broadcast.",
        "secret_values_exported": False,
    }



def ensure_banking_schema() -> None:
    """Create the local-only Sentinel Banking tables without exposing secrets."""
    init_db()
    con = sqlite3.connect(DB)
    con.executescript("""
CREATE TABLE IF NOT EXISTS sentinel_banking_accounts(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    banking_uid TEXT NOT NULL UNIQUE,
    label TEXT NOT NULL,
    account_type TEXT NOT NULL,
    chain TEXT NOT NULL,
    coin TEXT NOT NULL,
    blockchain TEXT NOT NULL,
    address TEXT NOT NULL,
    address_type TEXT NOT NULL,
    public_material TEXT NOT NULL,
    encrypted_secret TEXT,
    secret_kind TEXT,
    watch_only INTEGER NOT NULL DEFAULT 0,
    interest_eligible INTEGER NOT NULL DEFAULT 1,
    interest_active INTEGER NOT NULL DEFAULT 0,
    reward_program TEXT,
    internet_facing INTEGER NOT NULL DEFAULT 0,
    dapp_connect_allowed INTEGER NOT NULL DEFAULT 0,
    aegis_guarded INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL,
    notes TEXT
);
CREATE TABLE IF NOT EXISTS sentinel_banking_receipts(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    receipt_uid TEXT NOT NULL UNIQUE,
    banking_uid TEXT,
    receipt_type TEXT NOT NULL,
    event_time TEXT NOT NULL,
    amount_text TEXT,
    asset TEXT,
    description TEXT,
    metadata_json TEXT,
    created_at TEXT NOT NULL
);
""")
    con.execute("INSERT OR REPLACE INTO wallet_meta(key,value) VALUES(?,?)", ("sentinel_banking_schema", BANKING_SCHEMA))
    con.execute("INSERT OR REPLACE INTO wallet_meta(key,value) VALUES(?,?)", ("sentinel_banking_enabled", "true"))
    con.commit(); con.close()
    try:
        os.chmod(DB, 0o600)
    except Exception:
        pass


def _banking_account_type(account_type: str) -> str:
    t = (account_type or BANKING_DEFAULT_ACCOUNT_TYPE).strip().lower().replace(" ", "_")
    aliases = {"bank_account": "bank", "crypto_bank": "bank", "crypto_savings": "savings", "savings_account": "savings", "treasury": "vault", "aegis_guarded": "vault", "watch": "watch_only"}
    t = aliases.get(t, t)
    if t not in BANKING_ACCOUNT_TYPES:
        raise ValueError("unsupported_banking_account_type:" + t)
    return t


def write_banking_receipt(banking_uid: str, receipt_type: str, description: str, amount_text: str = "", asset: str = "", metadata: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    ensure_banking_schema()
    rid = "SBR-" + secrets.token_hex(8).upper()
    item = {
        "receipt_uid": rid,
        "banking_uid": (banking_uid or "").strip(),
        "receipt_type": (receipt_type or "event").strip() or "event",
        "event_time": now_iso(),
        "amount_text": str(amount_text or ""),
        "asset": str(asset or ""),
        "description": str(description or ""),
        "metadata": metadata or {},
        "secret_values_exported": False,
    }
    con = sqlite3.connect(DB)
    con.execute("INSERT INTO sentinel_banking_receipts(receipt_uid,banking_uid,receipt_type,event_time,amount_text,asset,description,metadata_json,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
                (item["receipt_uid"], item["banking_uid"], item["receipt_type"], item["event_time"], item["amount_text"], item["asset"], item["description"], json.dumps(item["metadata"], sort_keys=True), now_iso()))
    con.commit(); con.close()
    return {"ok": True, "schema": "sentinel.wallet.banking_receipt.v1_1_12", "version": VERSION, **item}


def create_banking_account(label: str, chain: str, passphrase: str, account_type: str = BANKING_DEFAULT_ACCOUNT_TYPE, recovery_word_count: int = 24, confirm_passphrase: str = "", notes: str = "") -> Dict[str, Any]:
    """Create an encrypted offline Sentinel Banking crypto account container.

    Foundation doctrine: local-only, not internet-facing, not dApp-connectable, no active interest/yield.
    """
    ensure_banking_schema()
    chain = (chain or "").upper().strip()
    if chain not in SUPPORTED_CHAINS:
        raise ValueError(f"unsupported_chain:{chain}")
    acct_type = _banking_account_type(account_type)
    if not passphrase:
        raise ValueError("missing_passphrase")
    if confirm_passphrase and confirm_passphrase != passphrase:
        raise ValueError("passphrase_confirmation_mismatch")
    recovery_word_count = int(recovery_word_count or 24)
    recovery_phrase = generate_recovery_phrase(recovery_word_count)
    meta = SUPPORTED_CHAINS[chain]
    km = _key_material_from_recovery_phrase(chain, recovery_phrase)
    banking_uid = f"SB-{chain}-{acct_type.upper()}-{secrets.token_hex(6).upper()}"
    secret_obj = {
        "schema": "sentinel.wallet.banking_secret_material.v1_1_12",
        "banking_uid": banking_uid,
        "chain": chain,
        "coin": meta["coin"],
        "account_type": acct_type,
        "recovery_phrase": recovery_phrase,
        "recovery_word_count": recovery_word_count,
        "recovery_phrase_kind": "sentinel_recovery_phrase_foundation",
        "private_material_b64": base64.b64encode(km["private_material"]).decode(),
        "created_at": now_iso(),
        "internet_facing": False,
        "dapp_connect_allowed": False,
        "interest_eligible": True,
        "interest_active": False,
        "reward_program": None,
        "wallet_owned_broadcast_enabled": False,
    }
    encrypted = encrypt_blob(passphrase, json.dumps(secret_obj, sort_keys=True).encode(), aad=b"sentinel-wallet-banking-v1.1.12")
    con = sqlite3.connect(DB)
    con.execute("INSERT INTO sentinel_banking_accounts(banking_uid,label,account_type,chain,coin,blockchain,address,address_type,public_material,encrypted_secret,secret_kind,watch_only,interest_eligible,interest_active,reward_program,internet_facing,dapp_connect_allowed,aegis_guarded,created_at,notes) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (banking_uid, label or f"{chain} Sentinel Savings", acct_type, chain, meta["coin"], meta["blockchain"], km["address"], km["address_type"], km["public_material"], json.dumps(encrypted, sort_keys=True), km["secret_kind"], 0, 1, 0, None, 0, 0, 1, now_iso(), notes or "Sentinel Banking foundation account: encrypted, local-only, non-dApp-facing, reward-eligible foundation only."))
    con.commit(); con.close()
    receipt = write_banking_receipt(banking_uid, "account_created", f"Created local Sentinel Banking {acct_type} account", "0", chain, {"account_type": acct_type, "internet_facing": False, "dapp_connect_allowed": False, "interest_eligible": True, "interest_active": False})
    return {
        "ok": True,
        "schema": "sentinel.wallet.create_banking_account_result.v1_1_12",
        "version": VERSION,
        "banking_uid": banking_uid,
        "label": label or f"{chain} Sentinel Savings",
        "account_type": acct_type,
        "chain": chain,
        "coin": meta["coin"],
        "blockchain": meta["blockchain"],
        "address": km["address"],
        "address_type": km["address_type"],
        "stored_encrypted": True,
        "contained_section": "Sentinel Banking",
        "internet_facing": False,
        "dapp_connect_allowed": False,
        "interest_eligible": True,
        "interest_active": False,
        "future_rewards_only": True,
        "aegis_guarded_foundation": True,
        "recovery_phrase": recovery_phrase,
        "recovery_word_count": recovery_word_count,
        "recovery_phrase_displayed_once": True,
        "recovery_phrase_stored_encrypted_only": True,
        "private_key_exported": False,
        "secret_values_exported": False,
        "network_access_enabled": False,
        "wallet_owned_broadcast_enabled": False,
        "receipt": {"receipt_uid": receipt.get("receipt_uid"), "receipt_type": receipt.get("receipt_type")},
    }


def list_banking_accounts() -> Dict[str, Any]:
    ensure_banking_schema()
    con = sqlite3.connect(DB)
    rows = con.execute("SELECT banking_uid,label,account_type,chain,coin,blockchain,address,address_type,watch_only,interest_eligible,interest_active,reward_program,internet_facing,dapp_connect_allowed,aegis_guarded,created_at,notes FROM sentinel_banking_accounts ORDER BY id DESC").fetchall()
    con.close()
    items = []
    for r in rows:
        items.append({
            "banking_uid": r[0], "label": r[1], "account_type": r[2], "chain": r[3], "coin": r[4], "blockchain": r[5],
            "address": r[6], "address_short": _short_address(r[6]), "address_type": r[7], "watch_only": bool(r[8]),
            "interest_eligible": bool(r[9]), "interest_active": bool(r[10]), "reward_program": r[11],
            "internet_facing": bool(r[12]), "dapp_connect_allowed": bool(r[13]), "aegis_guarded": bool(r[14]),
            "created_at": r[15], "notes": r[16], "native_total": f"0.000000 {r[4]}", "total_source": "local record only; live balance lookup disabled",
            "secret_values_exported": False,
        })
    return {"ok": True, "schema": "sentinel.wallet.banking_accounts.v1_1_12", "version": VERSION, "count": len(items), "items": items, "secret_values_exported": False}


def list_banking_receipts(limit: int = 25) -> Dict[str, Any]:
    ensure_banking_schema()
    con = sqlite3.connect(DB)
    rows = con.execute("SELECT receipt_uid,banking_uid,receipt_type,event_time,amount_text,asset,description,metadata_json,created_at FROM sentinel_banking_receipts ORDER BY id DESC LIMIT ?", (int(limit or 25),)).fetchall()
    con.close()
    items = []
    for r in rows:
        try:
            meta = json.loads(r[7] or "{}")
        except Exception:
            meta = {}
        items.append({"receipt_uid": r[0], "banking_uid": r[1], "receipt_type": r[2], "event_time": r[3], "amount_text": r[4], "asset": r[5], "description": r[6], "metadata": meta, "created_at": r[8], "secret_values_exported": False})
    return {"ok": True, "schema": "sentinel.wallet.banking_receipts.v1_1_12", "version": VERSION, "count": len(items), "items": items, "secret_values_exported": False}


def banking_status() -> Dict[str, Any]:
    ensure_banking_schema()
    accounts = list_banking_accounts()
    receipts = list_banking_receipts(limit=10)
    by_type: Dict[str, int] = {}
    by_chain: Dict[str, int] = {}
    eligible = 0
    for item in accounts.get("items", []):
        by_type[item.get("account_type", "unknown")] = by_type.get(item.get("account_type", "unknown"), 0) + 1
        by_chain[item.get("chain", "UNKNOWN")] = by_chain.get(item.get("chain", "UNKNOWN"), 0) + 1
        if item.get("interest_eligible"):
            eligible += 1
    return {
        "ok": True,
        "schema": BANKING_SCHEMA,
        "version": VERSION,
        "app": APP,
        "section": "Sentinel Banking",
        "enabled": True,
        "contained_encrypted_wallet_section": True,
        "account_count": accounts.get("count", 0),
        "receipt_count_preview": receipts.get("count", 0),
        "by_type": by_type,
        "by_chain": by_chain,
        "reward_eligible_account_count": eligible,
        "interest_eligibility_foundation": True,
        "interest_active": False,
        "yield_or_interest_guaranteed": False,
        "future_rewards_only": True,
        "internet_facing_default": False,
        "dapp_connect_allowed_default": False,
        "aegis_guarded_foundation": True,
        "supported_account_types": BANKING_ACCOUNT_TYPES,
        "supported_chains": list(SUPPORTED_CHAINS.keys()),
        "security_doctrine": "Banking accounts are encrypted local-only crypto account containers. They are not dApp-facing and do not claim active interest/yield at foundation stage.",
        "secret_values_exported": False,
    }


def banking_foundation_test() -> Dict[str, Any]:
    ensure_banking_schema()
    phrase = "sentinel-banking-test-" + secrets.token_hex(4)
    blob = {"schema": "sentinel.wallet.banking_test_secret.v1_1_12", "secret": secrets.token_hex(16)}
    encrypted = encrypt_blob(phrase, json.dumps(blob, sort_keys=True).encode(), aad=b"sentinel-wallet-banking-v1.1.12")
    decrypted = json.loads(decrypt_blob(phrase, encrypted, aad=b"sentinel-wallet-banking-v1.1.12").decode())
    st = banking_status()
    checks = {
        "banking_enabled": st.get("enabled") is True,
        "encrypted_container_roundtrip": decrypted == blob,
        "local_only_default": st.get("internet_facing_default") is False,
        "dapp_connect_disabled_default": st.get("dapp_connect_allowed_default") is False,
        "interest_not_active": st.get("interest_active") is False,
        "no_yield_guarantee": st.get("yield_or_interest_guaranteed") is False,
        "secret_values_not_exported": st.get("secret_values_exported") is False,
    }
    return {"ok": all(checks.values()), "schema": "sentinel.wallet.banking_foundation_test.v1_1_12", "version": VERSION, "checks": checks, "status": st}

def delete_wallet_record(wallet_uid: str, confirmation: str = "") -> Dict[str, Any]:
    """Delete one local encrypted wallet record from the Wallet database.

    This removes the local SQLite wallet row only. It does not delete blockchain
    assets, close an address, revoke prior signatures, or wipe independent backups.
    Recovery is only possible if the user kept the recovery phrase / backup.
    """
    init_db()
    uid = (wallet_uid or "").strip()
    if not uid:
        raise ValueError("missing_wallet_uid")
    if GUI_DELETE_WALLET_REQUIRES_TYPED_CONFIRMATION and str(confirmation or "").strip().upper() != "DELETE":
        raise ValueError("delete_confirmation_required_type_DELETE")
    con = sqlite3.connect(DB)
    row = con.execute("SELECT wallet_uid,label,chain,coin,blockchain,address,address_type,created_at,notes FROM generated_wallets WHERE wallet_uid=?", (uid,)).fetchone()
    if not row:
        con.close()
        raise ValueError("wallet_not_found")
    item = {"wallet_uid": row[0], "label": row[1], "chain": row[2], "coin": row[3], "blockchain": row[4], "address": row[5], "address_type": row[6], "created_at": row[7], "notes": row[8]}
    con.execute("DELETE FROM generated_wallets WHERE wallet_uid=?", (uid,))
    con.commit()
    try:
        con.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        con.execute("VACUUM")
    except Exception:
        pass
    con.close()
    ensure_dirs()
    log_path = STATE_DIR / "wallet-delete-audit.jsonl"
    log_item = {"time": now_iso(), "action": "delete_wallet_record", "wallet_uid": uid, "label": item.get("label"), "chain": item.get("chain"), "address_short": _short_address(item.get("address", "")) if '_short_address' in globals() else str(item.get("address", ""))[:16], "secret_values_exported": False, "blockchain_assets_deleted": False}
    try:
        _safe_append_line(log_path, json.dumps(log_item, sort_keys=True) + "\n")
    except Exception:
        pass
    return {"ok": True, "schema": "sentinel.wallet.delete_wallet_result.v1_0_2", "version": VERSION, "deleted_wallet": {k: item.get(k) for k in ["wallet_uid", "label", "chain", "coin", "blockchain", "address", "address_type"]}, "local_record_deleted": True, "encrypted_secret_removed_from_wallet_db": True, "blockchain_assets_deleted": False, "recovery_requires_saved_recovery_phrase_or_backup": True, "secret_values_exported": False}


def wallet_delete_feature_test() -> Dict[str, Any]:
    checks = {
        "runtime_version_1_1_4_or_newer": _version_tuple(VERSION) >= _version_tuple("1.1.4"),
        "gui_delete_wallet_enabled": GUI_DELETE_WALLET_ENABLED is True,
        "typed_confirmation_required": GUI_DELETE_WALLET_REQUIRES_TYPED_CONFIRMATION is True,
    }
    before = list_wallets().get("count", 0)
    created = generate_wallet_record("Delete Feature Test ETH", "ETH", "sentinel-wallet-delete-test", persist=True, recovery_word_count=12)
    checks["test_wallet_created"] = created.get("ok") is True and bool(created.get("wallet_uid"))
    deleted = delete_wallet_record(created.get("wallet_uid", ""), "DELETE")
    checks["test_wallet_deleted"] = deleted.get("ok") is True and deleted.get("local_record_deleted") is True
    after = list_wallets().get("count", 0)
    checks["wallet_count_restored"] = after == before
    return {"ok": all(bool(v) for v in checks.values()), "schema": "sentinel.wallet.delete_wallet_feature_test.v1_0_2", "version": VERSION, "checks": checks, "created_preview": {"chain": created.get("chain"), "address_prefix": str(created.get("address", ""))[:10]}, "deleted_preview": {"wallet_uid": deleted.get("deleted_wallet", {}).get("wallet_uid"), "chain": deleted.get("deleted_wallet", {}).get("chain")}, "policy": "Wallets tab exposes Delete Wallet beside Add Wallet; destructive deletion requires typed DELETE confirmation and removes only the local encrypted wallet record."}


def _read_private_secret_file(path: str) -> str:
    p = Path(path).expanduser()
    if p.is_symlink() or _path_has_symlink_component(p):
        raise ValueError("secret_file_symlink_refused")
    st = p.stat()
    if not stat.S_ISREG(st.st_mode):
        raise ValueError("secret_file_not_regular")
    if (st.st_mode & 0o077) != 0:
        raise ValueError("secret_file_must_be_private_0600")
    return p.read_text(encoding="utf-8").strip()


def _secret_from_source(source: str, prompt: str) -> str:
    src = str(source or "")
    if src == "@-":
        return sys.stdin.readline().rstrip("\n")
    if src.startswith("@") and len(src) > 1:
        return _read_private_secret_file(src[1:])
    val = os.environ.get(src, "") if src else ""
    if val:
        return val
    if os.environ.get("SENTINEL_WALLET_ALLOW_INLINE_SECRET", "") == "1" and src and not src.startswith("SENTINEL_"):
        return src
    if os.isatty(0):
        return getpass.getpass(prompt)
    raise ValueError(f"missing_secret_source:{src or 'SENTINEL_WALLET_PASSPHRASE'}")


def _passphrase_from_cli(env_name: str, prompt_allowed: bool = True) -> str:
    env_name = env_name or "SENTINEL_WALLET_PASSPHRASE"
    if not prompt_allowed and env_name == "@-":
        raise ValueError("stdin_secret_not_allowed_here")
    return _secret_from_source(env_name, "Sentinel Wallet passphrase: ")





def _native_provider_chain_family(method: str, kind: str = "") -> str:
    method = str(method or "")
    kind = str(kind or "")
    if method.startswith("eth_") or method in {"personal_sign", "wallet_switchEthereumChain", "wallet_addEthereumChain"}:
        return "evm"
    if method.startswith("solana_"):
        return "solana"
    if method.startswith("btc_") or "psbt" in method.lower():
        return "bitcoin"
    if method.startswith("xrpl_") or method.startswith("xrp_"):
        return "xrp_ledger"
    if kind.startswith("walletconnect") or method.startswith("walletconnect"):
        return "walletconnect"
    return "unknown"


def _parse_native_provider_note(note: str, kind: str, browser_origin: str) -> Dict[str, Any]:
    parsed: Dict[str, Any] = {}
    note = str(note or "")
    if len(note.encode("utf-8", "ignore")) > 65536:
        raise ValueError("native_provider_note_too_large")
    try:
        obj = json.loads(note or "{}") if note else {}
        if isinstance(obj, dict):
            parsed = obj
    except Exception:
        parsed = {"raw_note_present": bool(note)}
    method = str(parsed.get("method") or kind or "dapp_request")
    params = parsed.get("params", [])
    if not isinstance(params, list):
        params = [params]
    if len(params) > 16:
        raise ValueError("native_provider_too_many_params")
    safe_params: List[Any] = []
    for item in params:
        if isinstance(item, str) and len(item) > 8192:
            safe_params.append(item[:8192] + "...[truncated]")
        else:
            safe_params.append(item)
    params = safe_params
    chain_family = str(parsed.get("chain_family") or _native_provider_chain_family(method, kind))
    chain_id = str(parsed.get("chain_id") or ("0x1" if chain_family == "evm" else ("solana:mainnet" if chain_family == "solana" else "")))
    return {
        "schema": NATIVE_PROVIDER_REQUEST_SCHEMA,
        "bridge_schema": NATIVE_PROVIDER_BRIDGE_SCHEMA,
        "phase": str(parsed.get("phase") or "phase1_native_provider_core"),
        "provider": str(parsed.get("provider") or "sentinel-browser"),
        "method": method,
        "params": params,
        "params_present": bool(params),
        "param_count": len(params),
        "chain_family": chain_family,
        "chain_id": chain_id,
        "origin": browser_origin or str(parsed.get("origin") or ""),
        "requires_user_approval": True,
        "approval_owner": "Sentinel Wallet",
        "browser_signs_transactions": False,
        "browser_broadcasts_transactions": False,
        "browser_stores_wallet_secrets": False,
        "browser_may_receive_secrets": False,
        "secret_values_present": False,
        "wallet_owned_network_broadcast_enabled": False,
        "raw_note_truncated": len(note or "") >= 6000,
    }



EVM_CHAIN_ID_TO_CHAIN = {
    "0x1": "ETH",
    "0x38": "BNB",
    "0x89": "ETH",
    "0xa": "ETH",
    "0xa4b1": "ETH",
    "0x2105": "ETH",
    "0xa86a": "ETH",
}

EVM_PHASE2_METHODS = [
    "eth_requestAccounts", "eth_accounts", "eth_chainId", "net_version", "personal_sign", "eth_sign",
    "eth_signTypedData", "eth_signTypedData_v3", "eth_signTypedData_v4", "wallet_switchEthereumChain",
    "wallet_addEthereumChain", "wallet_watchAsset", "eth_sendTransaction"
]


def _normalise_evm_chain_id(chain_id: str) -> str:
    raw = str(chain_id or "0x1").strip().lower()
    if not raw:
        return "0x1"
    if raw.startswith("0x"):
        return raw
    try:
        return hex(int(raw, 10))
    except Exception:
        return raw


def _wallet_candidates_for_native_request(req_native: Dict[str, Any]) -> List[Dict[str, Any]]:
    init_db()
    chain_family = str(req_native.get("chain_family") or "").lower()
    chain_id = _normalise_evm_chain_id(str(req_native.get("chain_id") or "0x1"))
    preferred_chain = EVM_CHAIN_ID_TO_CHAIN.get(chain_id, "ETH") if chain_family == "evm" else ""
    con = sqlite3.connect(DB)
    rows = con.execute("SELECT wallet_uid,label,chain,coin,blockchain,address,address_type,created_at FROM generated_wallets ORDER BY id DESC").fetchall()
    con.close()
    out: List[Dict[str, Any]] = []
    for r in rows:
        chain = str(r[2] or "").upper()
        if chain_family == "evm" and chain not in {"ETH", "BNB"}:
            continue
        if chain_family == "solana" and chain != "SOL":
            continue
        if chain_family == "bitcoin" and chain != "BTC":
            continue
        if chain_family == "xrp_ledger" and chain != "XRP":
            continue
        rank = 0
        if preferred_chain and chain == preferred_chain:
            rank = 2
        elif chain_family == "evm" and chain in {"ETH", "BNB"}:
            rank = 1
        out.append({"wallet_uid": r[0], "label": r[1], "chain": chain, "coin": r[3], "blockchain": r[4], "address": r[5], "address_type": r[6], "created_at": r[7], "rank": rank})
    out.sort(key=lambda x: (int(x.get("rank", 0)), str(x.get("created_at") or "")), reverse=True)
    return out


def _select_wallet_for_native_request(req_native: Dict[str, Any], preferred_uid: str = "") -> Dict[str, Any]:
    candidates = _wallet_candidates_for_native_request(req_native)
    preferred_uid = str(preferred_uid or "").strip()
    if preferred_uid:
        for item in candidates:
            if item.get("wallet_uid") == preferred_uid:
                return item
    return candidates[0] if candidates else {}


def _extract_evm_message(method: str, params: Any, selected_address: str = "") -> str:
    method = str(method or "")
    if not isinstance(params, list):
        params = [params]
    if method == "personal_sign":
        # MetaMask commonly uses [message, address], but older dApps may use [address, message].
        if len(params) >= 2:
            a, b = str(params[0]), str(params[1])
            if a.lower() == str(selected_address or "").lower() or (a.startswith("0x") and len(a) == 42 and not (b.startswith("0x") and len(b) == 42)):
                return b
            return a
        return str(params[0]) if params else ""
    if method in {"eth_sign", "eth_signTypedData", "eth_signTypedData_v3", "eth_signTypedData_v4"}:
        if len(params) >= 2:
            return params[1] if isinstance(params[1], str) else json.dumps(params[1], sort_keys=True)
        return params[0] if params else ""
    return ""



SOLANA_PHASE3_METHODS = [
    "solana_connect",
    "solana_disconnect",
    "solana_signMessage",
    "solana_signTransaction",
    "solana_signAllTransactions",
    "solana_signAndSendTransaction",
]


def _decode_solana_message_payload(value: Any) -> bytes:
    if isinstance(value, dict):
        enc = str(value.get("encoding") or "").lower()
        data = value.get("data")
        if enc == "base64" and isinstance(data, str):
            return base64.b64decode(data)
        if isinstance(data, list):
            return bytes(int(x) & 0xff for x in data)
        if isinstance(data, str):
            return data.encode()
    if isinstance(value, list):
        return bytes(int(x) & 0xff for x in value)
    if isinstance(value, str):
        # Accept base64-ish payloads, but fall back to UTF-8 text for simple dApp login messages.
        try:
            if re.fullmatch(r"[A-Za-z0-9+/=\-_]+", value) and len(value) % 4 == 0:
                return base64.b64decode(value)
        except Exception:
            pass
        return value.encode()
    return json.dumps(value, sort_keys=True).encode()


def _solana_sign_message(wallet_uid: str, passphrase: str, message_payload: Any, origin: str = "") -> Dict[str, Any]:
    secret = _load_wallet_secret(wallet_uid, passphrase)
    chain = (secret.get("chain") or "").upper()
    if chain != "SOL":
        raise ValueError(f"solana_sign_message_not_supported_for_chain:{chain}")
    payload = _decode_solana_message_payload(message_payload)
    private_material = base64.b64decode(secret.get("private_material_b64", ""))
    from cryptography.hazmat.primitives.asymmetric import ed25519
    priv = ed25519.Ed25519PrivateKey.from_private_bytes(private_material[:32])
    sig = priv.sign(payload)
    return {"ok": True, "schema": "sentinel.wallet.solana_sign_message.v1_1_7", "version": VERSION, "wallet_uid": wallet_uid, "chain": "SOL", "origin": origin or "local-wallet-gui", "payload_sha256": hashlib.sha256(payload).hexdigest(), "signature": base64.b64encode(sig).decode(), "signature_format": "ed25519_base64", "signed_payload_only": True, "broadcast_by_wallet": False, "browser_secret_values_exported": False, "audit_note": TRANSACTION_SIGNING_AUDIT_NOTE}


def solana_provider_status() -> Dict[str, Any]:
    ensure_dirs(); init_db()
    req_native = {"chain_family": "solana", "chain_id": "solana:mainnet"}
    candidates = _wallet_candidates_for_native_request(req_native)
    icon = wallet_icon_status()
    return {
        "ok": True,
        "schema": "sentinel.wallet.solana_provider_status.v1_1_7",
        "app": APP,
        "package": PACKAGE,
        "program": PROGRAM,
        "version": VERSION,
        "phase": "phase3_manual_approval_return_patch",
        "enabled": True,
        "supported_methods_phase3": SOLANA_PHASE3_METHODS,
        "supported_chain_ids_phase3": ["solana:mainnet", "solana:devnet"],
        "solana_wallet_count": len(candidates),
        "has_solana_wallet": bool(candidates),
        "latest_solana_wallet_preview": {k: candidates[0].get(k) for k in ["wallet_uid", "label", "chain", "address", "address_type"]} if candidates else {},
        "returns_public_key_after_approval": True,
        "sign_message_after_approval": True,
        "phantom_compat_surface": True,
        "wallet_standard_foundation": True,
        "official_wallet_icon": icon,
        "wallet_owned_broadcast_enabled": False,
        "network_access_enabled": False,
        "browser_may_receive_secrets": False,
        "secret_values_exported": False,
    }


def solana_provider_test() -> Dict[str, Any]:
    ensure_dirs(); init_db()
    pp = "sentinel-phase3-solana-provider-test-passphrase"
    created_uid = ""
    try:
        created = generate_wallet_record("Phase3 Solana Provider Test SOL", "SOL", pp, persist=True, recovery_word_count=12, confirm_passphrase=pp)
        created_uid = str(created.get("wallet_uid") or "")
        addr = str(created.get("address") or "")
        rid = "wallet-solana-provider-phase3-test-" + secrets.token_hex(4)
        origin = "https://sentinel.local/solana-provider-phase3-wallet-test"
        note = json.dumps({"provider":"sentinel-browser", "native_provider_schema":NATIVE_PROVIDER_REQUEST_SCHEMA, "phase":"phase3_manual_approval_return_patch", "method":"solana_connect", "params":[], "chain_family":"solana", "chain_id":"solana:mainnet", "requires_user_approval":True}, sort_keys=True)
        req = write_bridge_request(rid, "dapp_login_request", origin, note)
        payload = _native_provider_approval_payload(req, pp, created_uid)
        rsp = write_bridge_response(rid, "approved", "phase3 solana provider connect approval self-test", origin, payload)
        read_rsp = read_bridge_response(rid)
        native = read_rsp.get("native_provider") if isinstance(read_rsp.get("native_provider"), dict) else {}
        rid2 = rid + "-sign"
        msg_obj = {"__sentinelType":"string", "data":"Sentinel Phase 3 Solana provider test"}
        note2 = json.dumps({"provider":"sentinel-browser", "native_provider_schema":NATIVE_PROVIDER_REQUEST_SCHEMA, "phase":"phase3_manual_approval_return_patch", "method":"solana_signMessage", "params":[msg_obj, "utf8"], "chain_family":"solana", "chain_id":"solana:mainnet", "requires_user_approval":True}, sort_keys=True)
        req2 = write_bridge_request(rid2, "personal_sign_request", origin, note2)
        payload2 = _native_provider_approval_payload(req2, pp, created_uid)
        rsp2 = write_bridge_response(rid2, "approved", "phase3 solana provider signMessage self-test", origin, payload2)
        checks = {
            "status_enabled": solana_provider_status().get("enabled") is True,
            "official_icon_available": wallet_icon_status().get("ok") is True,
            "generated_temp_solana_wallet": bool(created_uid and addr and not addr.startswith("0x")),
            "write_request_ok": req.get("ok") is True,
            "approval_response_ok": rsp.get("ok") is True and rsp.get("decision") == "approved",
            "response_contains_public_key": native.get("publicKey") == addr or native.get("public_key") == addr or native.get("address") == addr,
            "secret_values_not_exported": rsp.get("secret_values_exported") is False and native.get("secret_values_exported") is False,
            "sign_message_response_ok": rsp2.get("ok") is True and bool(rsp2.get("signature")),
            "signature_base64_present": bool(str(rsp2.get("signature", "")).strip()),
            "wallet_no_broadcast": rsp.get("wallet_owned_broadcast_enabled") is False,
        }
        return {"ok": all(bool(v) for v in checks.values()), "schema": "sentinel.wallet.solana_provider_test.v1_1_7", "app": APP, "version": VERSION, "checks": checks, "account_preview": {"publicKey": addr, "wallet_uid": created_uid}, "sample_response": read_rsp, "message_sign_response_preview": {"signature_prefix": str(rsp2.get("signature", ""))[:18], "signature_format": rsp2.get("signature_format")}}
    finally:
        if created_uid:
            try:
                delete_wallet_record(created_uid, "DELETE")
            except Exception:
                pass

def evm_provider_status() -> Dict[str, Any]:
    ensure_dirs(); init_db()
    req_native = {"chain_family": "evm", "chain_id": "0x1"}
    candidates = _wallet_candidates_for_native_request(req_native)
    return {
        "ok": True,
        "schema": "sentinel.wallet.evm_provider_status.v1_1_7",
        "app": APP,
        "package": PACKAGE,
        "program": PROGRAM,
        "version": VERSION,
        "phase": "phase3_manual_approval_return_patch",
        "enabled": True,
        "supported_methods_phase2": EVM_PHASE2_METHODS,
        "supported_chain_ids_phase2": sorted(EVM_CHAIN_ID_TO_CHAIN.keys()),
        "evm_wallet_count": len(candidates),
        "has_evm_wallet": bool(candidates),
        "latest_evm_wallet_preview": {k: candidates[0].get(k) for k in ["wallet_uid", "label", "chain", "address", "address_type"]} if candidates else {},
        "returns_accounts_after_approval": True,
        "personal_sign_after_approval": True,
        "typed_data_signing_foundation": True,
        "wallet_owned_broadcast_enabled": False,
        "network_access_enabled": False,
        "browser_may_receive_secrets": False,
        "secret_values_exported": False,
    }


def _native_provider_approval_payload(req: Dict[str, Any], passphrase: str = "", wallet_uid: str = "") -> Dict[str, Any]:
    req_native = req.get("native_provider") if isinstance(req.get("native_provider"), dict) else {}
    method = str(req_native.get("method") or "")
    params = req_native.get("params") if isinstance(req_native.get("params"), list) else []
    chain_family = str(req_native.get("chain_family") or _native_provider_chain_family(method, req.get("request_kind", "")))
    origin = str(req.get("browser_origin") or req_native.get("origin") or "")
    if chain_family == "evm" or method in EVM_PHASE2_METHODS:
        selected = _select_wallet_for_native_request({**req_native, "chain_family": "evm"}, wallet_uid)
        if not selected:
            raise ValueError("no_evm_wallet_available_generate_or_import_eth_or_bnb_wallet_first")
        address = str(selected.get("address") or "")
        out: Dict[str, Any] = {
            "chain_family": "evm",
            "chain_id": _normalise_evm_chain_id(str(req_native.get("chain_id") or "0x1")),
            "wallet_uid": selected.get("wallet_uid"),
            "wallet_label": selected.get("label"),
            "wallet_chain": selected.get("chain"),
            "address": address,
            "public_address": address,
            "account": address,
            "accounts": [address],
            "addresses": [address],
            "secret_values_exported": False,
            "browser_may_receive_secrets": False,
            "wallet_owned_network_broadcast_enabled": False,
        }
        if method in {"personal_sign", "eth_sign", "eth_signTypedData", "eth_signTypedData_v3", "eth_signTypedData_v4"}:
            if not passphrase:
                raise ValueError("missing_wallet_password_for_signature")
            msg = _extract_evm_message(method, params, address)
            if not str(msg or "").strip():
                raise ValueError("missing_message_for_evm_signature")
            sig = sign_dapp_login_message(str(selected.get("wallet_uid")), passphrase, str(msg), origin)
            out.update({"signature": sig.get("signature"), "signature_format": sig.get("signature_format"), "message_hash_hex": sig.get("message_hash_hex"), "signed_payload_only": True})
        if method in {"eth_sendTransaction", "eth_signTransaction"}:
            # Phase 2 forwards/labels transaction payloads but does not broadcast. Actual signing UX remains explicit and guarded.
            out.update({"transaction_payload_forwarded": True, "signed_payload_only": False, "broadcast_by_wallet": False, "transaction_signing_requires_explicit_wallet_phase": True})
        return out
    if chain_family == "solana" or method in SOLANA_PHASE3_METHODS:
        selected = _select_wallet_for_native_request({**req_native, "chain_family": "solana", "chain_id": "solana:mainnet"}, wallet_uid)
        if not selected:
            raise ValueError("no_solana_wallet_available_generate_or_import_sol_wallet_first")
        public_key = str(selected.get("address") or "")
        out: Dict[str, Any] = {
            "chain_family": "solana",
            "chain_id": str(req_native.get("chain_id") or "solana:mainnet"),
            "wallet_uid": selected.get("wallet_uid"),
            "wallet_label": selected.get("label"),
            "wallet_chain": selected.get("chain"),
            "address": public_key,
            "publicKey": public_key,
            "public_key": public_key,
            "account": public_key,
            "accounts": [public_key],
            "addresses": [public_key],
            "secret_values_exported": False,
            "browser_may_receive_secrets": False,
            "wallet_owned_network_broadcast_enabled": False,
        }
        if method == "solana_signMessage":
            if not passphrase:
                raise ValueError("missing_wallet_password_for_solana_signature")
            message_payload = params[0] if params else ""
            sig = _solana_sign_message(str(selected.get("wallet_uid")), passphrase, message_payload, origin)
            out.update({"signature": sig.get("signature"), "signature_format": sig.get("signature_format"), "message_hash_hex": sig.get("payload_sha256"), "signed_payload_only": True})
        if method in {"solana_signTransaction", "solana_signAllTransactions", "solana_signAndSendTransaction"}:
            out.update({"transaction_payload_forwarded": True, "signed_payload_only": False, "broadcast_by_wallet": False, "transaction_signing_requires_explicit_wallet_phase": True})
        return out
    return {"secret_values_exported": False, "browser_may_receive_secrets": False}


def evm_provider_test() -> Dict[str, Any]:
    ensure_dirs(); init_db()
    pp = "sentinel-phase2-evm-provider-test-passphrase"
    created_uid = ""
    cleanup = None
    try:
        created = generate_wallet_record("Phase2 EVM Provider Test ETH", "ETH", pp, persist=True, recovery_word_count=12, confirm_passphrase=pp)
        created_uid = str(created.get("wallet_uid") or "")
        rid = "wallet-evm-provider-phase2-test-" + secrets.token_hex(4)
        origin = "https://sentinel.local/evm-provider-phase2-wallet-test"
        note = json.dumps({"provider":"sentinel-browser", "native_provider_schema":NATIVE_PROVIDER_REQUEST_SCHEMA, "phase":"phase2_evm_provider_methods", "method":"eth_requestAccounts", "params":[], "chain_family":"evm", "chain_id":"0x1", "requires_user_approval":True}, sort_keys=True)
        req = write_bridge_request(rid, "dapp_login_request", origin, note)
        payload = _native_provider_approval_payload(req, pp, created_uid)
        rsp = write_bridge_response(rid, "approved", "phase2 evm provider account approval self-test", origin, payload)
        read_rsp = read_bridge_response(rid)
        addr = str(created.get("address") or "")
        native = read_rsp.get("native_provider") if isinstance(read_rsp.get("native_provider"), dict) else {}
        # Message signing path.
        rid2 = rid + "-sign"
        note2 = json.dumps({"provider":"sentinel-browser", "native_provider_schema":NATIVE_PROVIDER_REQUEST_SCHEMA, "phase":"phase2_evm_provider_methods", "method":"personal_sign", "params":["Sentinel Phase 2 EVM provider test", addr], "chain_family":"evm", "chain_id":"0x1", "requires_user_approval":True}, sort_keys=True)
        req2 = write_bridge_request(rid2, "personal_sign_request", origin, note2)
        payload2 = _native_provider_approval_payload(req2, pp, created_uid)
        rsp2 = write_bridge_response(rid2, "approved", "phase2 evm provider personal_sign self-test", origin, payload2)
        checks = {
            "status_enabled": evm_provider_status().get("enabled") is True,
            "generated_temp_evm_wallet": bool(created_uid and addr.startswith("0x") and len(addr) == 42),
            "write_request_ok": req.get("ok") is True,
            "approval_response_ok": rsp.get("ok") is True and rsp.get("decision") == "approved",
            "response_contains_account": native.get("address") == addr and addr in native.get("accounts", []),
            "secret_values_not_exported": rsp.get("secret_values_exported") is False and native.get("secret_values_exported") is False,
            "message_sign_response_ok": rsp2.get("ok") is True and bool(rsp2.get("signature")),
            "message_signature_hex": str(rsp2.get("signature", "")).startswith("0x"),
            "wallet_no_broadcast": rsp.get("wallet_owned_broadcast_enabled") is False,
        }
        return {"ok": all(bool(v) for v in checks.values()), "schema": "sentinel.wallet.evm_provider_test.v1_1_7", "app": APP, "version": VERSION, "checks": checks, "account_preview": {"address": addr, "wallet_uid": created_uid}, "sample_response": read_rsp, "message_sign_response_preview": {"signature_prefix": str(rsp2.get("signature", ""))[:18], "signature_format": rsp2.get("signature_format")}}
    finally:
        if created_uid:
            try:
                delete_wallet_record(created_uid, "DELETE")
            except Exception:
                pass

def native_provider_core_status() -> Dict[str, Any]:
    ensure_dirs()
    return {
        "ok": True,
        "schema": "sentinel.wallet.native_provider_core_status.v3",
        "bridge_schema": NATIVE_PROVIDER_BRIDGE_SCHEMA,
        "request_schema": NATIVE_PROVIDER_REQUEST_SCHEMA,
        "response_schema": NATIVE_PROVIDER_RESPONSE_SCHEMA,
        "app": APP,
        "package": PACKAGE,
        "program": PROGRAM,
        "version": VERSION,
        "phase": "phase3_manual_approval_return_patch",
        "native_provider_core_enabled": True,
        "shared_request_response_bridge_enabled": True,
        "request_envelope_enabled": True,
        "response_envelope_enabled": True,
        "pending_approval_queue_enabled": True,
        "exact_request_id_supported": True,
        "request_read_supported": True,
        "response_read_supported": True,
        "approval_owner": "Sentinel Wallet",
        "supported_chain_families_phase1": ["evm", "solana", "bitcoin", "xrp_ledger", "walletconnect"],
        "evm_phase2_enabled": True,
        "evm_provider": evm_provider_status(),
        "solana_provider": solana_provider_status(),
        "phase1_methods_routed_not_signed": ["eth_requestAccounts", "personal_sign", "eth_sendTransaction", "solana_connect", "solana_signMessage", "btc_requestAccounts", "btc_signPsbt"],
        "phase3_solana_methods": SOLANA_PHASE3_METHODS,
        "requests_dir": str(REQUESTS_DIR),
        "responses_dir": str(RESPONSES_DIR),
        "private_dirs_chmod_700_target": True,
        "request_files_chmod_600_target": True,
        "browser_may_receive_secrets": False,
        "browser_signs_transactions": False,
        "browser_broadcasts_transactions": False,
        "wallet_owned_network_broadcast_enabled": False,
        "status": "ready_phase3_solana_native_provider_no_qr_local_bridge",
    }


def read_bridge_request(request_id: str) -> Dict[str, Any]:
    ensure_dirs(); rid = _safe_request_id(request_id); path = REQUESTS_DIR / f"{rid}.json"
    if not path.exists():
        return {"ok": False, "schema": "sentinel.wallet.browser_bridge_request_read.v1", "request_id": rid, "status": "not_found"}
    try:
        obj = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(obj, dict):
            obj.setdefault("ok", True)
            return obj
    except Exception as exc:
        return {"ok": False, "schema": "sentinel.wallet.browser_bridge_request_read.v1", "request_id": rid, "error": str(exc)}
    return {"ok": False, "schema": "sentinel.wallet.browser_bridge_request_read.v1", "request_id": rid, "status": "invalid"}



def read_bridge_response(request_id: str) -> Dict[str, Any]:
    ensure_dirs(); rid = _safe_request_id(request_id); path = RESPONSES_DIR / f"{rid}.json"
    if not path.exists():
        return {"ok": True, "schema": "sentinel.wallet.browser_bridge_response_read.v1", "request_id": rid, "decision": "pending", "status": "pending", "secret_values_exported": False}
    try:
        obj = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(obj, dict):
            obj.setdefault("ok", True)
            return obj
    except Exception as exc:
        return {"ok": False, "schema": "sentinel.wallet.browser_bridge_response_read.v1", "request_id": rid, "error": str(exc)}
    return {"ok": False, "schema": "sentinel.wallet.browser_bridge_response_read.v1", "request_id": rid, "status": "invalid"}


def pending_bridge_requests(limit: int = 20) -> List[Dict[str, Any]]:
    """Return unresolved browser-bridge requests only. Completed responses are skipped to prevent popup loops."""
    ensure_dirs()
    items: List[Dict[str, Any]] = []
    try:
        paths = sorted(REQUESTS_DIR.glob("*.json"), key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)
    except Exception:
        paths = []
    for path in paths:
        if len(items) >= int(limit or 20):
            break
        try:
            req = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(req, dict):
                continue
            rid = str(req.get("request_id") or path.stem)
            rsp_path = RESPONSES_DIR / f"{rid}.json"
            if rsp_path.exists():
                try:
                    rsp = json.loads(rsp_path.read_text(encoding="utf-8"))
                    if str(rsp.get("decision") or rsp.get("status") or "").lower() not in {"", "pending"}:
                        continue
                except Exception:
                    continue
            if not str(req.get("status", "pending")).startswith("pending"):
                continue
            items.append(req)
        except Exception:
            continue
    return items


def native_provider_core_test() -> Dict[str, Any]:
    rid = "wallet-native-provider-phase1-test-" + secrets.token_hex(4)
    origin = "https://sentinel.local/native-provider-phase1-wallet-test"
    note = json.dumps({
        "provider": "sentinel-browser",
        "native_provider_schema": NATIVE_PROVIDER_REQUEST_SCHEMA,
        "phase": "phase3_manual_approval_return_patch",
        "method": "eth_requestAccounts",
        "params": [],
        "chain_family": "evm",
        "chain_id": "0x1",
        "requires_user_approval": True,
        "browser_signs_transactions": False,
        "browser_stores_wallet_secrets": False,
    }, sort_keys=True)
    req = write_bridge_request(rid, "dapp_login_request", origin, note)
    read_req = read_bridge_request(rid)
    rsp = write_bridge_response(rid, "pending", "phase1 native provider pending response self-test", origin)
    read_rsp = read_bridge_response(rid)
    native = read_req.get("native_provider") if isinstance(read_req.get("native_provider"), dict) else {}
    response_native = read_rsp.get("native_provider") if isinstance(read_rsp.get("native_provider"), dict) else {}
    checks = {
        "status_enabled": native_provider_core_status().get("native_provider_core_enabled") is True,
        "write_request_ok": req.get("ok") is True,
        "read_request_ok": read_req.get("ok") is True,
        "request_schema_v1": native.get("schema") == NATIVE_PROVIDER_REQUEST_SCHEMA,
        "request_method_preserved": native.get("method") == "eth_requestAccounts",
        "request_chain_family_evm": native.get("chain_family") == "evm",
        "approval_required": native.get("requires_user_approval") is True,
        "write_response_ok": rsp.get("ok") is True and rsp.get("decision") == "pending",
        "read_response_ok": read_rsp.get("ok") is True and read_rsp.get("decision") == "pending",
        "response_schema_v1": response_native.get("schema") == NATIVE_PROVIDER_RESPONSE_SCHEMA,
        "browser_no_secrets": native.get("browser_may_receive_secrets") is False,
        "wallet_no_broadcast": native.get("wallet_owned_network_broadcast_enabled") is False,
    }
    return {"ok": all(bool(v) for v in checks.values()), "schema": "sentinel.wallet.native_provider_core_test.v1", "app": APP, "version": VERSION, "checks": checks, "sample_request": read_req, "sample_response": read_rsp, "status": native_provider_core_status()}

def walletconnect_status() -> Dict[str, Any]:
    ensure_dirs()
    return {
        "ok": True,
        "schema": "sentinel.wallet.walletconnect_status.v1_1_5",
        "app": APP,
        "package": PACKAGE,
        "program": PROGRAM,
        "version": VERSION,
        "walletconnect_v2_foundation_enabled": True,
        "pairing_uri_request_kind": "walletconnect_pairing",
        "session_proposal_approval_owner": "Sentinel Wallet",
        "supported_namespaces": ["eip155", "solana", "bip122"],
        "evm_methods_foundation": ["eth_requestAccounts", "personal_sign", "eth_signTypedData_v4", "eth_sendTransaction", "eth_signTransaction"],
        "solana_methods_foundation": ["solana_connect", "solana_signMessage", "solana_signTransaction", "solana_signAndSendTransaction"],
        "bitcoin_methods_foundation": ["btc_requestAccounts", "btc_signMessage", "btc_signPsbt", "btc_signPsbts"],
        "browser_may_forward_pairing_uri": True,
        "browser_may_receive_secrets": False,
        "browser_signs_transactions": False,
        "wallet_owned_network_broadcast_enabled": False,
        "network_relay_client_bundled": False,
        "phantom_style_connect_prompt_enabled": True,
        "exact_request_popup_focus_enabled": True,
        "browser_response_polling_supported": True,
        "field_test_required": ["Tensor WalletConnect QR/pairing", "EVM WalletConnect dApp connect", "Solana message signing", "BTC PSBT compatibility test"],
        "native_provider_core_available": True, "status": "walletconnect_fallback_native_provider_phase1_core_no_browser_secrets",
    }


def walletconnect_test() -> Dict[str, Any]:
    st = walletconnect_status()
    checks = {
        "walletconnect_enabled": st.get("walletconnect_v2_foundation_enabled") is True,
        "eip155_supported": "eip155" in st.get("supported_namespaces", []),
        "solana_supported": "solana" in st.get("supported_namespaces", []),
        "btc_supported": "bip122" in st.get("supported_namespaces", []),
        "pairing_kind_supported": st.get("pairing_uri_request_kind") == "walletconnect_pairing",
        "browser_no_secrets": st.get("browser_may_receive_secrets") is False,
        "wallet_broadcast_disabled": st.get("wallet_owned_network_broadcast_enabled") is False,
    }
    return {"ok": all(checks.values()), "schema": "sentinel.wallet.walletconnect_test.v1_1_0", "app": APP, "version": VERSION, "checks": checks, "status": st}

def asset_support_status() -> Dict[str, Any]:
    return {
        "ok": True,
        "schema": "sentinel.wallet.asset_support_status.v1_0_0",
        "version": VERSION,
        "top_market_target_coins": TOP_MARKET_TARGET_COINS,
        "additional_required_coins": ADDITIONAL_REQUIRED_COINS,
        "supported_coins": SUPPORTED_COINS,
        "supported_chains": SUPPORTED_CHAINS,
        "supported_stablecoins": SUPPORTED_STABLECOINS,
        "nft_networks": NFT_NETWORKS,
        "generate_wallet_supported": True,
        "multiple_wallets_allowed": True,
        "recovery_phrase_word_counts": RECOVERY_WORD_COUNTS,
        "recovery_phrase_display_on_generation": RECOVERY_PHRASE_DISPLAY_ON_GENERATION,
        "card_features_enabled": False,
        "signing_enabled": False,
        "message_signing_enabled": LOGIN_MESSAGE_SIGNING_ENABLED,
        "transaction_signing_enabled": False,
        "broadcast_enabled": False,
        "network_access_enabled": False,
    }


def chain_support_status() -> Dict[str, Any]:
    return {"ok": True, "schema": "sentinel.wallet.chain_support_status.v1_0_0", "version": VERSION, "chains": SUPPORTED_CHAINS, "generation_supported_chains": [k for k, v in SUPPORTED_CHAINS.items() if v.get("generation_supported")], "network_access_enabled": False}


def stablecoin_status() -> Dict[str, Any]:
    return {"ok": True, "schema": "sentinel.wallet.stablecoin_status.v1_0_0", "version": VERSION, "stablecoins": SUPPORTED_STABLECOINS, "display_and_record_foundation": True, "live_balance_lookup_enabled": False, "transfer_enabled": False}


def card_feature_status() -> Dict[str, Any]:
    return {"ok": True, "schema": "sentinel.wallet.card_feature_status.v1_0_0", "version": VERSION, "wallet_type": "crypto_only", "card_features_enabled": False, "credit_card_support": False, "debit_card_support": False, "bank_card_storage_enabled": False, "card_autofill_enabled": False, "cvv_storage_enabled": False, "fiat_card_payment_approval_enabled": False, "doctrine": "Sentinel Wallet is crypto-only. Card features are forbidden."}


def crypto_wallet_status() -> Dict[str, Any]:
    init_db()
    return {"ok": True, "schema": "sentinel.wallet.crypto_status.v1_0_0", "version": VERSION, "wallet_type": "crypto_only", "supported_coins": SUPPORTED_COINS, "supported_networks": list(SUPPORTED_CHAINS.keys()), "supported_chains": SUPPORTED_CHAINS, "supported_stablecoins": SUPPORTED_STABLECOINS, "generate_wallet_supported": True, "import_wallet_supported": True, "multiple_wallets_allowed": True, "recovery_phrase_word_counts": RECOVERY_WORD_COUNTS, "recovery_phrase_display_on_generation": True, "network_enabled": False, "signing_enabled": False, "message_signing_enabled": LOGIN_MESSAGE_SIGNING_ENABLED, "transaction_signing_enabled": False, "broadcast_enabled": False, "receive_address_foundation": True, "watch_only_foundation": True, "master_passphrase_stored": False, "secret_export_enabled": False, "card_features": card_feature_status()}


def nft_status() -> Dict[str, Any]:
    init_db(); con = sqlite3.connect(DB); count = con.execute("SELECT COUNT(*) FROM nft_records").fetchone()[0]; con.close()
    return {"ok": True, "schema": "sentinel.wallet.nft_status.v1_0_0", "version": VERSION, "nft_support_enabled": True, "nft_inventory_supported": True, "nft_networks_declared": NFT_NETWORKS, "nft_standards_declared": {"ETH": ["ERC-721", "ERC-1155"], "BNB": ["BEP-721", "BEP-1155"], "SOL": ["SPL Token", "Metaplex Metadata"]}, "local_inventory_count": int(count), "live_chain_lookup_enabled": False, "metadata_cache_foundation": True, "media_preview_foundation": True}




def nft_counts_by_chain() -> Dict[str, Any]:
    init_db()
    con = sqlite3.connect(DB)
    rows = con.execute("SELECT network, COUNT(*) FROM nft_records GROUP BY network").fetchall()
    con.close()
    counts = {net: 0 for net in NFT_NETWORKS}
    for network, count in rows:
        counts[str(network).upper()] = int(count)
    return {"ok": True, "schema": "sentinel.wallet.nft_counts_by_chain.v1_0_0", "version": VERSION, "counts": counts, "total": sum(counts.values())}




def nft_catalog_by_chain() -> Dict[str, Any]:
    init_db()
    con = sqlite3.connect(DB)
    rows = con.execute("SELECT network,mint_or_token_id,collection,item_name,owner_address,metadata_uri,media_uri,notes,created_at FROM nft_records ORDER BY network, collection, item_name, id DESC").fetchall()
    con.close()
    catalogue = {net: [] for net in NFT_NETWORKS}
    for r in rows:
        net = str(r[0] or "").upper()
        catalogue.setdefault(net, []).append({
            "network": net,
            "token_id": r[1] or "",
            "collection": r[2] or "Unsorted Collection",
            "name": r[3] or "Unnamed NFT",
            "owner_address": r[4] or "",
            "metadata_uri": r[5] or "",
            "media_uri": r[6] or "",
            "notes": r[7] or "",
            "created_at": r[8],
        })
    counts = {k: len(v) for k, v in catalogue.items()}
    return {"ok": True, "schema": "sentinel.wallet.nft_catalogue_by_chain.v1_0_0", "version": VERSION, "catalogue_by_chain": catalogue, "counts": counts, "total": sum(counts.values()), "live_lookup_enabled": False}

def chain_readiness_status() -> Dict[str, Any]:
    chains = {}
    for chain, meta in SUPPORTED_CHAINS.items():
        chains[chain] = {
            "enabled": True,
            "generation_ready": bool(meta.get("generation_supported")),
            "message_signing_ready": LOGIN_MESSAGE_SIGNING_ENABLED,
            "transaction_signing_ready": False,
            "broadcast_ready": False,
            "live_balance_ready": False,
            "nft_ready": bool(meta.get("nft_supported")),
            "stablecoins": meta.get("stablecoins", []),
            "status": "enabled_ready_local" if meta.get("generation_supported") else "declared_not_ready",
        }
    stables = {}
    for sym, meta in SUPPORTED_STABLECOINS.items():
        stables[sym] = {"enabled": True, "networks": meta.get("networks", []), "display_ready": True, "transfer_ready": False, "live_balance_ready": False}
    return {"ok": True, "schema": "sentinel.wallet.chain_readiness_status.v1_0_0", "version": VERSION, "chains": chains, "stablecoins": stables}
def browser_bridge_contract() -> Dict[str, Any]:
    return {"ok": True, "schema": "sentinel.wallet.browser_bridge_contract.v1_0_0", "app": APP, "package": PACKAGE, "program": PROGRAM, "version": VERSION, "browser_bridge_supported": True, "browser_open_supported": True, "browser_origin_context_supported": True, "request_response_supported": True, "browser_generated_request_id_supported": True, "write_request_supported": True, "write_response_supported": True, "read_response_supported": True, "wallet_type": "crypto_only", "crypto_only_wallet": True, "card_features_enabled": False, "credit_card_support": False, "debit_card_support": False, "bank_card_storage_enabled": False, "card_autofill_enabled": False, "credential_storage": "none_in_browser", "browser_must_never_store": ["seed phrase", "private keys", "wallet passphrase", "signing material", "payment secrets", "card numbers", "CVV"], "payments_enabled": False, "signing_enabled": False, "message_signing_enabled": LOGIN_MESSAGE_SIGNING_ENABLED, "transaction_signing_enabled": False, "network_access_enabled": False, "generate_wallet_supported": True, "import_wallet_supported": True, "multiple_wallets_allowed": True, "supported_coins": SUPPORTED_COINS, "supported_chains": list(SUPPORTED_CHAINS.keys()), "stablecoins_supported": list(SUPPORTED_STABLECOINS.keys()), "networks_declared": list(SUPPORTED_CHAINS.keys()), "nft_support_enabled": True, "nft_inventory_supported": True, "nft_networks_declared": NFT_NETWORKS, "requires_user_unlock": True, "requires_explicit_user_approval_for_any_future_crypto_action": True, "ai_may_initiate_payment": False, "aegis_may_export_secrets": False, "passphrase_escrow_supported": True, "passphrase_escrow_default_enabled": False, "wallet_internal_master_passphrase_stored": False, "status": "crypto_only_multi_wallet_top_assets_nft_recovery_import_message_signing_ready_no_cards_no_broadcast"}


def browser_bridge_status() -> Dict[str, Any]:
    ensure_dirs()
    return {"ok": True, "schema": "sentinel.wallet.browser_bridge_status.v1_0_0", "app": APP, "package": PACKAGE, "program": PROGRAM, "version": VERSION, "browser_bridge_supported": True, "request_response_supported": True, "read_response_supported": True, "requests_dir": str(REQUESTS_DIR), "responses_dir": str(RESPONSES_DIR), "private_dirs_chmod_700_target": True, "wallet_type": "crypto_only", "crypto_only_wallet": True, "card_features_enabled": False, "payments_enabled": False, "signing_enabled": False, "message_signing_enabled": LOGIN_MESSAGE_SIGNING_ENABLED, "transaction_signing_enabled": False, "network_access_enabled": False, "generate_wallet_supported": True, "import_wallet_supported": True, "multiple_wallets_allowed": True, "supported_coins": SUPPORTED_COINS, "supported_chains": list(SUPPORTED_CHAINS.keys()), "stablecoins_supported": list(SUPPORTED_STABLECOINS.keys()), "nft_support_enabled": True, "nft_inventory_supported": True, "browser_may_open_wallet_gui": True, "browser_may_request_status": True, "browser_may_request_payment": False, "browser_may_request_signing": True, "browser_may_request_transaction_signing": False, "secret_values_exported": False, "aegis_required": False, "sentinel_os_required": False, "contract": browser_bridge_contract(), "crypto_status": crypto_wallet_status(), "nft_status": nft_status(), "asset_support": asset_support_status(), "passphrase_escrow_supported": True, "passphrase_escrow_default_enabled": False, "passphrase_escrow_status": passphrase_escrow_status(), "status": "ready_crypto_only_multi_wallet_top_assets_nft_import_message_signing_ready_no_cards"}


def write_bridge_request(request_id: str, kind: str = "status", browser_origin: str = "", note: str = "") -> Dict[str, Any]:
    ensure_dirs(); rid = _safe_request_id(request_id)
    allowed = ("status", "open", "connect_preview", "receive_address_preview", "nft_inventory_preview", "asset_support_preview", "generate_wallet_preview", "dapp_login_request", "personal_sign_request", "transaction_sign_request", "payment_request", "walletconnect_pairing", "walletconnect_session_proposal")
    if kind not in allowed:
        kind = "status"
    native = _parse_native_provider_note(note or "", kind, browser_origin or "")
    native["request_id"] = rid
    native["request_kind"] = kind
    native["created_at"] = now_iso()
    obj = {"ok": True, "schema": "sentinel.wallet.browser_bridge_request.v1_0_2", "request_id": rid, "request_kind": kind, "browser_origin": browser_origin or "", "note": note or "", "native_provider": native, "created_at": native["created_at"], "browser_generated_request_id": rid.startswith("browser-"), "wallet_type": "crypto_only", "card_features_enabled": False, "payments_enabled": True, "crypto_transactions_enabled": True, "signing_enabled": True, "message_signing_enabled": LOGIN_MESSAGE_SIGNING_ENABLED, "dapp_login_enabled": True, "transaction_signing_enabled": True, "network_access_enabled": False, "wallet_owned_broadcast_enabled": False, "secret_values_present": False, "status": "pending_user_wallet_approval"}
    path = REQUESTS_DIR / f"{rid}.json"; _safe_atomic_write_text(path, json.dumps(obj, indent=2, sort_keys=True) + "\n"); return obj


def write_bridge_response(request_id: str, decision: str = "rejected", message: str = "", browser_origin: str = "", approval_payload: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    ensure_dirs(); rid = _safe_request_id(request_id); decision = (decision or "rejected").lower()
    if decision not in ("approved", "rejected", "cancelled", "pending"):
        decision = "rejected"
    req = read_bridge_request(rid)
    req_native = req.get("native_provider") if isinstance(req.get("native_provider"), dict) else {}
    approval_payload = dict(approval_payload or {})
    native = {"schema": NATIVE_PROVIDER_RESPONSE_SCHEMA, "bridge_schema": NATIVE_PROVIDER_BRIDGE_SCHEMA, "phase": "phase3_manual_approval_return_patch", "request_id": rid, "decision": decision, "method": req_native.get("method"), "chain_family": req_native.get("chain_family"), "chain_id": req_native.get("chain_id"), "origin": browser_origin or req.get("browser_origin") or req_native.get("origin") or "", "approved": decision == "approved", "user_approval_required": True, "approval_owner": "Sentinel Wallet", "browser_may_receive_secrets": False, "secret_values_exported": False, "wallet_owned_network_broadcast_enabled": False, "signed_payload_only": bool(decision == "approved" and approval_payload.get("signature"))}
    if approval_payload:
        for k, v in approval_payload.items():
            if k not in {"private_key", "seed", "seed_phrase", "recovery_phrase", "passphrase", "password"}:
                native[k] = v
    obj = {"ok": True, "schema": "sentinel.wallet.browser_bridge_response.v1_1_7", "request_id": rid, "decision": decision, "message": message or "", "browser_origin": native["origin"], "native_provider": native, "created_at": now_iso(), "wallet_type": "crypto_only", "card_features_enabled": False, "payments_enabled": True, "crypto_transactions_enabled": True, "signing_enabled": True, "message_signing_enabled": LOGIN_MESSAGE_SIGNING_ENABLED, "dapp_login_enabled": True, "transaction_signing_enabled": True, "network_access_enabled": False, "wallet_owned_broadcast_enabled": False, "secret_values_exported": False, "signed_payload_only": bool(native.get("signed_payload_only"))}
    if approval_payload:
        for k, v in approval_payload.items():
            if k in {"address", "public_address", "publicKey", "public_key", "account", "accounts", "addresses", "wallet_uid", "wallet_label", "wallet_chain", "chain_id", "chain_family", "signature", "signature_format", "message_hash_hex", "signed_transaction_hex", "transaction_payload_forwarded", "broadcast_by_wallet"}:
                obj[k] = v
    path = RESPONSES_DIR / f"{rid}.json"; _safe_atomic_write_text(path, json.dumps(obj, indent=2, sort_keys=True) + "\n"); return obj


def walletconnect_approval_prompt_test() -> Dict[str, Any]:
    rid = "browser-walletconnect-approval-test-" + secrets.token_hex(4)
    rid2 = rid + "-approved"
    req = write_bridge_request(rid, "walletconnect_pairing", "sentinel-browser://walletconnect-test", json.dumps({"provider":"walletconnect","uri":"wc:test@2?relay-protocol=irn"}))
    pending = pending_bridge_requests()
    write_bridge_response(req["request_id"], "rejected", "test cleanup", req.get("browser_origin", ""))
    exact_path_exists = (REQUESTS_DIR / f"{req.get('request_id')}.json").exists()
    checks = {
        "runtime_version_1_1_4_or_newer": _version_tuple(VERSION) >= _version_tuple("1.1.4"),
        "pending_request_detected": any(x.get("request_id") == req.get("request_id") for x in pending),
        "exact_request_file_available_for_gui": exact_path_exists,
        "exact_request_popup_focus_enabled": True,
        "browser_response_polling_supported": True,
        "walletconnect_kind_supported": req.get("request_kind") == "walletconnect_pairing",
        "approve_reject_response_supported": write_bridge_response(rid2, "approved", "approval prompt test", "sentinel-browser://walletconnect-test").get("decision") == "approved",
        "phantom_style_password_then_connect_prompt_declared": True,
        "secret_values_exported_false": read_bridge_response(rid2).get("secret_values_exported") is False,
    }
    return {"ok": all(checks.values()), "schema": "sentinel.wallet.walletconnect_approval_prompt_test.v1_1_4", "app": APP, "version": VERSION, "checks": checks, "sample_request": req}

def _dapp_display_name(origin: str) -> str:
    try:
        host = origin or ""
        if "://" in host:
            from urllib.parse import urlparse
            host = urlparse(host).netloc or host
        host = host.split("/")[0].split(":")[0].strip().lower()
        if host.startswith("www."):
            host = host[4:]
        if not host:
            return "this dApp"
        parts = [p for p in host.split(".") if p]
        core = parts[-2] if len(parts) >= 2 else parts[0]
        return core[:1].upper() + core[1:]
    except Exception:
        return "this dApp"

def gui(browser_origin: str = "", approval_request_id: str = "") -> None:
    import tkinter as tk
    from tkinter import ttk, messagebox

    init_db()
    root = tk.Tk()
    apply_wallet_window_icon(root)
    root.title(f"{APP} {VERSION}")
    root.geometry("1240x780")
    root.minsize(1020, 660)
    root.configure(bg="#070A0D")
    root.bind_all("<Control-q>", lambda event: root.destroy())
    root.bind_all("<Control-Q>", lambda event: root.destroy())

    GOLD = "#E19B00"
    CYAN = "#03C8FF"
    BG = "#070A0D"
    PANEL = "#0F1720"
    PANEL2 = "#141F2A"
    HEADER = "#05090C"
    TEXT = "#E8E6DF"
    MUTED = "#B9C4D0"
    BORDER = "#21313E"
    SAFE = "#78D17B"
    DANGER = "#FF7474"

    style = ttk.Style()
    try:
        style.theme_use("clam")
    except Exception:
        pass
    style.configure("Sentinel.TCombobox", fieldbackground="#111722", background="#111722", foreground=TEXT)

    totals_visible = tk.BooleanVar(value=False)


    approval_prompt_shown = {"value": False}

    def _load_exact_pending_request(rid: str) -> Optional[Dict[str, Any]]:
        rid = _safe_request_id(rid or "")
        if not rid:
            return None
        if (RESPONSES_DIR / f"{rid}.json").exists():
            return None
        path = REQUESTS_DIR / f"{rid}.json"
        if not path.exists():
            return None
        try:
            obj = json.loads(path.read_text())
            if isinstance(obj, dict) and str(obj.get("status", "")).startswith("pending"):
                return obj
        except Exception:
            return None
        return None

    def show_pending_browser_approval_if_any():
        if approval_prompt_shown.get("value"):
            return
        req = _load_exact_pending_request(approval_request_id) if approval_request_id else None
        # v1.1.11: only show an approval popup for the exact request id passed by the Browser.
        # Opening Wallet normally must not auto-popup stale or page-load requests.
        if req is None:
            return
        approval_prompt_shown["value"] = True
        rid = str(req.get("request_id", ""))
        kind = str(req.get("request_kind", "request"))
        origin = str(req.get("browser_origin", "unknown"))
        note = str(req.get("note", ""))
        try:
            parsed = json.loads(note) if note.strip().startswith("{") else {}
        except Exception:
            parsed = {}
        provider = parsed.get("provider", "Sentinel Browser") if isinstance(parsed, dict) else "Sentinel Browser"
        native_req = req.get("native_provider") if isinstance(req.get("native_provider"), dict) else _parse_native_provider_note(note, kind, origin)
        method = str(native_req.get("method") or kind)
        chain_family = str(native_req.get("chain_family") or _native_provider_chain_family(method, kind))
        chain_id = str(native_req.get("chain_id") or "")
        wallet_candidates = _wallet_candidates_for_native_request(native_req) if chain_family in {"evm", "solana", "bitcoin", "xrp_ledger"} else []
        selected_wallet_uid = tk.StringVar(value=(wallet_candidates[0].get("wallet_uid") if wallet_candidates else ""))
        uri_hint = ""
        if isinstance(parsed, dict):
            uri_hint = str(parsed.get("uri", ""))[:180]
        dapp_name = _dapp_display_name(origin)
        action_label = "Connect"
        if kind in {"personal_sign_request", "transaction_sign_request"}:
            action_label = "Sign"
        elif kind.startswith("walletconnect"):
            action_label = "Connect"
        win = tk.Toplevel(root)
        win.title("Sentinel Wallet Approval")
        win.configure(bg=BG)
        win.geometry("720x540")
        win.transient(root)
        win.grab_set()
        frame = tk.Frame(win, bg=BG, padx=18, pady=18)
        frame.pack(fill="both", expand=True)
        tk.Label(frame, text=f"{action_label} to {dapp_name}?", bg=BG, fg=GOLD, font=("Sans", 18, "bold")).pack(anchor="w")
        tk.Label(frame, text="Sentinel Wallet is asking for your wallet password before approval. Approve only if you trust this dApp request. The Browser will be told only approved/rejected status unless a later signed-payload flow is added.", bg=BG, fg=MUTED, font=("Sans", 10), wraplength=660, justify="left").pack(anchor="w", pady=(4,14))
        card = tk.Frame(frame, bg=PANEL, highlightbackground=BORDER, highlightthickness=1, padx=12, pady=12)
        card.pack(fill="both", expand=True)
        for label, value, colour in [("Request", kind, CYAN), ("Method", method, CYAN), ("Chain", (chain_family + (" / " + chain_id if chain_id else "")), TEXT), ("From", origin, TEXT), ("Provider", str(provider), TEXT), ("WalletConnect URI", uri_hint or "not shown", MUTED)]:
            row = tk.Frame(card, bg=PANEL); row.pack(fill="x", pady=4)
            tk.Label(row, text=label + ":", bg=PANEL, fg=GOLD, font=("Sans", 10, "bold"), width=18, anchor="w").pack(side="left")
            tk.Label(row, text=value, bg=PANEL, fg=colour, font=("Sans", 10), wraplength=390, justify="left", anchor="w").pack(side="left", fill="x", expand=True)
        if wallet_candidates:
            wallet_row = tk.Frame(card, bg=PANEL); wallet_row.pack(fill="x", pady=(10,4))
            tk.Label(wallet_row, text="Wallet:", bg=PANEL, fg=GOLD, font=("Sans", 10, "bold"), width=18, anchor="w").pack(side="left")
            labels = []
            label_to_uid = {}
            for item in wallet_candidates:
                label = f"{item.get('label')} — {item.get('chain')} — {str(item.get('address'))[:10]}…{str(item.get('address'))[-6:]}"
                labels.append(label); label_to_uid[label] = item.get("wallet_uid")
            selected_label = tk.StringVar(value=labels[0] if labels else "")
            def _sync_wallet_label(*_): selected_wallet_uid.set(label_to_uid.get(selected_label.get(), ""))
            selected_label.trace_add("write", _sync_wallet_label)
            try:
                tk.OptionMenu(wallet_row, selected_label, *labels).pack(side="left", fill="x", expand=True)
            except Exception:
                tk.Label(wallet_row, text=labels[0], bg=PANEL, fg=TEXT, font=("Sans", 10), wraplength=390, justify="left", anchor="w").pack(side="left", fill="x", expand=True)
        elif chain_family == "evm" and method in EVM_PHASE2_METHODS:
            tk.Label(card, text="No ETH/BNB EVM wallet was found. Generate or import an ETH or BNB wallet before approving this dApp request.", bg=PANEL, fg=DANGER, font=("Sans", 9), wraplength=560, justify="left").pack(anchor="w", pady=(10,0))
        elif chain_family == "solana" and method in SOLANA_PHASE3_METHODS:
            tk.Label(card, text="No SOL wallet was found. Generate or import a Solana wallet before approving this dApp request.", bg=PANEL, fg=DANGER, font=("Sans", 9), wraplength=560, justify="left").pack(anchor="w", pady=(10,0))

        unlock_row = tk.Frame(card, bg=PANEL); unlock_row.pack(fill="x", pady=(12, 4))
        tk.Label(unlock_row, text="Wallet password:", bg=PANEL, fg=GOLD, font=("Sans", 10, "bold"), width=18, anchor="w").pack(side="left")
        password_var = tk.StringVar()
        password_entry = tk.Entry(unlock_row, textvariable=password_var, show="•", bg="#091018", fg=TEXT, insertbackground=GOLD, relief="flat", highlightbackground=BORDER, highlightcolor=GOLD, highlightthickness=1)
        password_entry.pack(side="left", fill="x", expand=True)
        tk.Label(card, text="Browser never receives seed phrases, private keys, wallet passwords, passphrases, or signing material. Approval only writes a local response for the dApp bridge.", bg=PANEL, fg=SAFE, font=("Sans", 9), wraplength=560, justify="left").pack(anchor="w", pady=(10,0))
        buttons = tk.Frame(frame, bg=BG); buttons.pack(fill="x", pady=(14,0))
        def reject():
            write_bridge_response(rid, "rejected", "Rejected by user in Sentinel Wallet", origin)
            try: win.destroy()
            except Exception: pass
            try: root.after(120, root.destroy)
            except Exception: pass
        def approve():
            # Phantom-style UX gate: the visible Wallet must be unlocked before a dApp connection/sign approval is written.
            # This passphrase is not stored, not sent to Browser, and not exported in the bridge response.
            if not password_var.get().strip():
                messagebox.showwarning("Sentinel Wallet", "Enter your wallet password before approving this request.")
                try: password_entry.focus_set()
                except Exception: pass
                return
            try:
                approval_payload = _native_provider_approval_payload(req, password_var.get(), selected_wallet_uid.get()) if (chain_family in {"evm", "solana", "bitcoin", "xrp_ledger"} or method in EVM_PHASE2_METHODS or method in SOLANA_PHASE3_METHODS) else {}
            except Exception as exc:
                messagebox.showerror("Sentinel Wallet", "Could not approve this dApp request: " + str(exc))
                return
            write_bridge_response(rid, "approved", f"{action_label} approved by user in Sentinel Wallet approval prompt", origin, approval_payload)
            password_var.set("")
            try: win.destroy()
            except Exception: pass
            # Close Wallet after approval so focus naturally returns to Sentinel Browser/dApp.
            try: root.after(150, root.destroy)
            except Exception: pass
        tk.Button(buttons, text="Decline", command=reject, bg="#2A1111", fg=DANGER, activebackground=DANGER, activeforeground="#050505", relief="flat", padx=18, pady=8).pack(side="right", padx=(8,0))
        tk.Button(buttons, text=action_label, command=approve, bg="#182635", fg=GOLD, activebackground=GOLD, activeforeground="#050505", relief="flat", padx=18, pady=8).pack(side="right")
        try:
            password_entry.focus_set()
            win.lift()
            win.attributes('-topmost', True)
            win.after(800, lambda: win.attributes('-topmost', False))
        except Exception:
            pass


    menubar = tk.Menu(root, bg="#202226", fg=TEXT, activebackground=GOLD, activeforeground="#050505", tearoff=False)
    file_menu = tk.Menu(menubar, tearoff=False, bg="#202226", fg=TEXT, activebackground=GOLD, activeforeground="#050505")
    file_menu.add_command(label="Refresh", command=lambda: refresh_all())
    file_menu.add_separator()
    file_menu.add_command(label="Quit\tCtrl+Q", command=root.destroy)
    view_menu = tk.Menu(menubar, tearoff=False, bg="#202226", fg=TEXT, activebackground=GOLD, activeforeground="#050505")
    help_menu = tk.Menu(menubar, tearoff=False, bg="#202226", fg=TEXT, activebackground=GOLD, activeforeground="#050505")
    menubar.add_cascade(label="File", menu=file_menu)
    root.config(menu=menubar)

    # Header banner: Sentinel Jobs-inspired, but Wallet-specific.
    header = tk.Frame(root, bg="#0C1722", highlightbackground=BORDER, highlightthickness=1)
    header.pack(fill="x", padx=10, pady=(10, 8))
    icon_box = tk.Frame(header, width=96, height=76, bg="#0C1722")
    icon_box.pack(side="left", padx=(16, 12), pady=10)
    icon_box.pack_propagate(False)
    tk.Label(icon_box, text="◈", bg="#0C1722", fg=GOLD, font=("Sans", 42, "bold")).pack(expand=True)
    title_box = tk.Frame(header, bg=HEADER)
    title_box.pack(side="left", fill="x", expand=True, padx=(0, 12), pady=10)
    tk.Label(title_box, text="S E N T I N E L   W A L L E T", bg=HEADER, fg=GOLD, font=("Sans", 18, "bold")).pack(anchor="w", padx=12, pady=(10, 2))
    tk.Label(title_box, text="Crypto Wallet — Program 199", bg=HEADER, fg=MUTED, font=("Sans", 10)).pack(anchor="w", padx=12)
    tk.Label(title_box, text="Portfolio dashboard • Multi-wallet generation • BTC/ETH/BNB/XRP/SOL • USDT/USDC • NFTs • Local encrypted storage", bg=HEADER, fg=MUTED, font=("Sans", 10)).pack(anchor="w", padx=12, pady=(2, 10))

    body = tk.Frame(root, bg=BG)
    body.pack(fill="both", expand=True, padx=10, pady=(0, 10))
    side = tk.Frame(body, bg="#0A1118", width=230, highlightbackground=BORDER, highlightthickness=1)
    side.pack(side="left", fill="y", padx=(0, 8))
    side.pack_propagate(False)
    content = tk.Frame(body, bg=BG, highlightbackground=BORDER, highlightthickness=1)
    content.pack(side="left", fill="both", expand=True)

    pages: Dict[str, tk.Frame] = {}
    nav_buttons: Dict[str, tk.Button] = {}
    current = tk.StringVar(value="Dashboard")

    def clear(frame):
        for child in frame.winfo_children():
            child.destroy()

    def make_page(name: str) -> tk.Frame:
        outer = tk.Frame(content, bg=BG)
        canvas = tk.Canvas(outer, bg=BG, highlightthickness=0, bd=0)
        scrollbar = tk.Scrollbar(outer, orient="vertical", command=canvas.yview)
        inner = tk.Frame(canvas, bg=BG)
        inner_id = canvas.create_window((0, 0), window=inner, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        def _sync_scrollregion(_event=None):
            canvas.configure(scrollregion=canvas.bbox("all"))

        def _sync_inner_width(event):
            canvas.itemconfigure(inner_id, width=event.width)

        def _wheel(event):
            if getattr(event, "num", None) == 4:
                canvas.yview_scroll(-3, "units")
            elif getattr(event, "num", None) == 5:
                canvas.yview_scroll(3, "units")
            else:
                delta = getattr(event, "delta", 0)
                if delta:
                    canvas.yview_scroll(int(-1 * (delta / 120)), "units")

        def _bind_wheel(_event=None):
            canvas.bind_all("<MouseWheel>", _wheel)
            canvas.bind_all("<Button-4>", _wheel)
            canvas.bind_all("<Button-5>", _wheel)

        def _unbind_wheel(_event=None):
            canvas.unbind_all("<MouseWheel>")
            canvas.unbind_all("<Button-4>")
            canvas.unbind_all("<Button-5>")

        inner.bind("<Configure>", _sync_scrollregion)
        canvas.bind("<Configure>", _sync_inner_width)
        outer.bind("<Enter>", _bind_wheel)
        outer.bind("<Leave>", _unbind_wheel)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        inner._sentinel_scroll_canvas = canvas
        outer._sentinel_scroll_canvas = canvas
        pages[name] = outer
        return inner

    def page_title(parent, title, subtitle):
        box = tk.Frame(parent, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
        box.pack(fill="x", padx=28, pady=(24, 14))
        tk.Label(box, text=title, bg=PANEL, fg=GOLD, font=("Sans", 16, "bold")).pack(anchor="w", padx=14, pady=(12, 2))
        tk.Label(box, text=subtitle, bg=PANEL, fg=MUTED, font=("Sans", 10)).pack(anchor="w", padx=14, pady=(0, 12))
        return box

    def small_card(parent, title, value, subtitle="", value_color=CYAN, side="left"):
        f = tk.Frame(parent, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
        f.pack(side=side, fill="both", expand=True, padx=6, pady=6)
        tk.Label(f, text=title, bg=PANEL, fg=GOLD, font=("Sans", 10, "bold")).pack(anchor="w", padx=12, pady=(10, 2))
        tk.Label(f, text=value, bg=PANEL, fg=value_color, font=("Sans", 16, "bold")).pack(anchor="w", padx=12, pady=(0, 2))
        if subtitle:
            tk.Label(f, text=subtitle, bg=PANEL, fg=MUTED, font=("Sans", 9), wraplength=220, justify="left").pack(anchor="w", padx=12, pady=(0, 10))
        return f

    def make_scrolled_text(parent, **kw):
        frame_bg = kw.get("bg", "#0A1118")
        box = tk.Frame(parent, bg=frame_bg, highlightthickness=1, highlightbackground=BORDER)
        box.rowconfigure(0, weight=1)
        box.columnconfigure(0, weight=1)
        text = tk.Text(box, **kw)
        yscroll = tk.Scrollbar(box, orient="vertical", command=text.yview)
        text.configure(yscrollcommand=yscroll.set, highlightthickness=0)
        text.grid(row=0, column=0, sticky="nsew")
        yscroll.grid(row=0, column=1, sticky="ns")
        text._sentinel_scroll_frame = box
        return text

    def wallet_card(parent, item):
        f = tk.Frame(parent, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
        f.pack(fill="x", padx=6, pady=6)
        top = tk.Frame(f, bg=PANEL); top.pack(fill="x", padx=12, pady=(10, 2))
        tk.Label(top, text=item.get("label", "Wallet"), bg=PANEL, fg=TEXT, font=("Sans", 12, "bold")).pack(side="left")
        tk.Label(top, text=item.get("chain", ""), bg="#1C2A36", fg=GOLD, font=("Sans", 9, "bold"), padx=8, pady=2).pack(side="right")
        addr = item.get("address_short", "")
        tk.Label(f, text=f"{item.get('blockchain','')} • {addr}", bg=PANEL, fg=MUTED, font=("Sans", 9)).pack(anchor="w", padx=12, pady=(0, 4))
        total_text = item.get("native_total", "0.000000") if totals_visible.get() else "••••••"
        fiat_text = item.get("fiat_total", "$0.00 local") if totals_visible.get() else "••••"
        tk.Label(f, text=total_text, bg=PANEL, fg=CYAN, font=("Sans", 16, "bold")).pack(anchor="w", padx=12)
        tk.Label(f, text=fiat_text + "  •  " + item.get("total_source", "local only"), bg=PANEL, fg=MUTED, font=("Sans", 9)).pack(anchor="w", padx=12, pady=(0, 10))
        return f

    def show_page(name: str):
        for p in pages.values():
            p.pack_forget()
        pages[name].pack(fill="both", expand=True)
        current.set(name)
        for n, b in nav_buttons.items():
            b.configure(bg=("#182635" if n != name else "#111A24"), fg=(TEXT if n != name else GOLD), highlightbackground=(BORDER if n != name else GOLD))
        if name == "Dashboard": refresh_dashboard()
        elif name == "Wallets": refresh_wallets()
        elif name == "Banking": refresh_banking()
        elif name == "Add Wallet": refresh_add_wallet()
        elif name == "Sign-In": refresh_signing_wallet_choices()
        elif name == "Assets": refresh_assets()
        elif name == "NFTs": refresh_nfts()
        elif name == "Escrow": refresh_escrow()
        elif name == "Security": refresh_security()
        elif name == "Raw Status": refresh_raw()

    def nav_button(name: str):
        b = tk.Button(side, text=name, anchor="center", command=lambda n=name: show_page(n), bg="#182635", fg=TEXT, activebackground="#111A24", activeforeground=GOLD, relief="flat", highlightthickness=1, highlightbackground=BORDER, font=("Sans", 10, "bold" if name == "Dashboard" else "normal"))
        b.pack(fill="x", padx=14, pady=4, ipady=7)
        nav_buttons[name] = b

    tk.Label(side, text="Navigation", bg="#0A1118", fg=GOLD, font=("Sans", 11, "bold")).pack(anchor="w", padx=14, pady=(14, 8))
    for nav in GUI_TABS:
        nav_button(nav)
    tk.Frame(side, bg=BORDER, height=1).pack(fill="x", padx=14, pady=12)
    tk.Label(side, text="Ctrl+Q quits", bg="#0A1118", fg=MUTED, font=("Sans", 9)).pack(anchor="w", padx=14)
    tk.Label(side, text="Totals hidden by default", bg="#0A1118", fg=GOLD, font=("Sans", 9, "bold")).pack(anchor="w", padx=14, pady=(4, 0))
    tk.Label(side, text="Crypto-only. No cards.", bg="#0A1118", fg=GOLD, font=("Sans", 9, "bold")).pack(anchor="w", padx=14, pady=(4, 0))

    dash = make_page("Dashboard")
    page_title(dash, "Sentinel Wallet Dashboard", "Professional crypto-wallet overview. Totals are hidden by default. Live balance lookup remains disabled until audited.")
    portfolio_row = tk.Frame(dash, bg=BG); portfolio_row.pack(fill="x", padx=24, pady=2)
    total_var = tk.StringVar(value="••••••")
    fiat_var = tk.StringVar(value="••••")
    wallet_count_var = tk.StringVar(value="0")
    summary_var = tk.StringVar(value="Local-only • no live chain lookup")
    total_card = tk.Frame(portfolio_row, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
    total_card.pack(side="left", fill="both", expand=True, padx=6, pady=6)
    tk.Label(total_card, text="Portfolio Total", bg=PANEL, fg=GOLD, font=("Sans", 10, "bold")).pack(anchor="w", padx=12, pady=(10, 2))
    tk.Label(total_card, textvariable=total_var, bg=PANEL, fg=CYAN, font=("Sans", 22, "bold")).pack(anchor="w", padx=12)
    tk.Label(total_card, textvariable=fiat_var, bg=PANEL, fg=MUTED, font=("Sans", 10)).pack(anchor="w", padx=12)
    def toggle_totals():
        totals_visible.set(not totals_visible.get())
        eye_btn.configure(text="🙈 Hide totals" if totals_visible.get() else "👁 Show totals")
        refresh_dashboard(); refresh_wallets()
    eye_btn = tk.Button(total_card, text="👁 Show totals", command=toggle_totals, bg="#182635", fg=TEXT, activebackground=GOLD, activeforeground="#050505", relief="flat")
    eye_btn.pack(anchor="w", padx=12, pady=(8, 12))
    # replace value label in second card via direct refresh by rebuilding below is avoided; use another small frame manually
    wallet_summary = tk.Frame(portfolio_row, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
    wallet_summary.pack(side="left", fill="both", expand=True, padx=6, pady=6)
    tk.Label(wallet_summary, text="Wallets", bg=PANEL, fg=GOLD, font=("Sans", 10, "bold")).pack(anchor="w", padx=12, pady=(10, 2))
    tk.Label(wallet_summary, textvariable=wallet_count_var, bg=PANEL, fg=GOLD, font=("Sans", 18, "bold")).pack(anchor="w", padx=12)
    tk.Label(wallet_summary, textvariable=summary_var, bg=PANEL, fg=MUTED, font=("Sans", 9), wraplength=220, justify="left").pack(anchor="w", padx=12, pady=(0, 10))

    status_row = tk.Frame(dash, bg=BG); status_row.pack(fill="x", padx=24, pady=(0, 4))
    dash_chain_var = tk.StringVar(value="✅ BTC ✅ ETH ✅ BNB ✅ XRP ✅ SOL")
    dash_token_var = tk.StringVar(value="✅ USDT ready • ✅ USDC ready")
    dash_nft_var = tk.StringVar(value="ETH: 0 • BNB: 0 • SOL: 0")
    dash_security_var = tk.StringVar(value="No cards • login message signing only • no broadcast")
    for title, var, colour in [("Chains", dash_chain_var, CYAN), ("Stablecoins", dash_token_var, CYAN), ("NFTs", dash_nft_var, TEXT), ("Security", dash_security_var, SAFE)]:
        box = tk.Frame(status_row, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
        box.pack(side="left", fill="both", expand=True, padx=6, pady=6)
        tk.Label(box, text=title, bg=PANEL, fg=GOLD, font=("Sans", 10, "bold")).pack(anchor="w", padx=12, pady=(10, 2))
        tk.Label(box, textvariable=var, bg=PANEL, fg=colour, font=("Sans", 11, "bold"), wraplength=210, justify="left").pack(anchor="w", padx=12, pady=(0, 10))

    preview_box = tk.Frame(dash, bg=BG); preview_box.pack(fill="both", expand=True, padx=24, pady=(4, 12))
    tk.Label(preview_box, text="Wallets", bg=BG, fg=GOLD, font=("Sans", 13, "bold")).pack(anchor="w", padx=6, pady=(4, 0))
    dash_wallet_list = tk.Frame(preview_box, bg=BG); dash_wallet_list.pack(fill="both", expand=True)
    def refresh_dashboard():
        rec = wallet_gui_records()
        summary = gui_portfolio_summary()
        if totals_visible.get():
            total_var.set(summary.get("portfolio_total_native", "0.000000 local recorded"))
            fiat_var.set(summary.get("portfolio_total_fiat", "$0.00 local"))
        else:
            total_var.set("••••••")
            fiat_var.set("••••")
        wallet_count_var.set(str(summary.get("wallet_count", 0)))
        summary_var.set("Local recorded totals only • live balances disabled")
        ready = chain_readiness_status()
        nft_counts = nft_counts_by_chain().get("counts", {})
        dash_chain_var.set("  ".join([f"✅ {k}" if ready.get("chains", {}).get(k, {}).get("enabled") else f"⚠ {k}" for k in ["BTC", "ETH", "BNB", "XRP", "SOL"]]))
        dash_token_var.set("  ".join([f"✅ {k}" for k in ["USDT", "USDC"]]))
        dash_nft_var.set(" • ".join([f"{k}: {nft_counts.get(k, 0)}" for k in ["ETH", "BNB", "SOL"]]))
        dash_security_var.set("No cards • login message signing only • no transaction broadcast")
        clear(dash_wallet_list)
        items = rec.get("items", [])[:4]
        if not items:
            empty = tk.Frame(dash_wallet_list, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
            empty.pack(fill="x", padx=6, pady=8)
            tk.Label(empty, text="No wallets yet", bg=PANEL, fg=TEXT, font=("Sans", 12, "bold")).pack(anchor="w", padx=12, pady=(12, 2))
            tk.Label(empty, text="Use Generate Wallet to create your first encrypted local wallet record.", bg=PANEL, fg=MUTED).pack(anchor="w", padx=12, pady=(0, 12))
        else:
            for item in items:
                wallet_card(dash_wallet_list, item)

    wallets = make_page("Wallets")
    page_title(wallets, "Your Wallets", "User-friendly list of local encrypted wallet records. Totals are hidden by default.")

    def open_delete_wallet_dialog():
        rec = wallet_gui_records()
        items = rec.get("items", [])
        if not items:
            messagebox.showinfo("No wallets to delete", "There are no local wallet records to delete yet.")
            return
        lookup = {f"{i.get('label')} • {i.get('chain')} • {i.get('address_short')}": i for i in items}
        dlg = tk.Toplevel(root)
        dlg.title("Delete Wallet")
        dlg.configure(bg=BG)
        dlg.transient(root)
        dlg.grab_set()
        dlg.resizable(False, False)
        tk.Label(dlg, text="Delete Wallet", bg=BG, fg=GOLD, font=("Sans", 14, "bold")).pack(anchor="w", padx=16, pady=(14, 4))
        tk.Label(dlg, text="This removes only the local encrypted wallet record. It does not delete blockchain assets. Recovery requires your saved recovery phrase or backup.", bg=BG, fg=MUTED, wraplength=520, justify="left").pack(anchor="w", padx=16, pady=(0, 10))
        selected = tk.StringVar(value=next(iter(lookup.keys())))
        combo = ttk.Combobox(dlg, textvariable=selected, values=list(lookup.keys()), width=72, state="readonly")
        combo.pack(anchor="w", padx=16, pady=(0, 10))
        confirm_var = tk.StringVar()
        tk.Label(dlg, text="Type DELETE to confirm", bg=BG, fg=TEXT, font=("Sans", 10, "bold")).pack(anchor="w", padx=16, pady=(2, 2))
        confirm_entry = tk.Entry(dlg, textvariable=confirm_var, width=24, bg="#111722", fg=TEXT, insertbackground=GOLD)
        confirm_entry.pack(anchor="w", padx=16, pady=(0, 12))
        buttons = tk.Frame(dlg, bg=BG); buttons.pack(fill="x", padx=16, pady=(0, 16))
        def do_delete_selected():
            item = lookup.get(selected.get())
            if not item:
                messagebox.showwarning("Wallet required", "Choose a wallet record to delete.")
                return
            if confirm_var.get().strip().upper() != "DELETE":
                messagebox.showwarning("Confirmation required", "Type DELETE exactly to confirm local wallet deletion.")
                return
            if not messagebox.askyesno("Confirm wallet deletion", f"Delete local wallet record?\n\n{item.get('label')} • {item.get('chain')}\n{item.get('address')}\n\nThis cannot remove blockchain assets and cannot restore the wallet unless you kept the recovery phrase."):
                return
            try:
                delete_wallet_record(item.get("wallet_uid", ""), confirm_var.get())
                dlg.destroy()
                messagebox.showinfo("Wallet deleted", "The local encrypted wallet record was deleted.")
                refresh_dashboard(); refresh_wallets(); refresh_signing_wallet_choices()
            except Exception as exc:
                messagebox.showerror("Delete Wallet failed", f"{type(exc).__name__}: {exc}")
        tk.Button(buttons, text="Delete Wallet", command=do_delete_selected, bg="#6A1F24", fg=TEXT, activebackground=GOLD, activeforeground="#050505", relief="flat", font=("Sans", 10, "bold")).pack(side="left", padx=(0, 8))
        tk.Button(buttons, text="Cancel", command=dlg.destroy, bg="#182635", fg=TEXT, activebackground=GOLD, activeforeground="#050505", relief="flat").pack(side="left")
        confirm_entry.focus_set()

    wallets_actions = tk.Frame(wallets, bg=BG); wallets_actions.pack(fill="x", padx=28, pady=(0, 8))
    tk.Button(wallets_actions, text="Refresh Wallets", command=lambda: refresh_wallets(), bg="#182635", fg=TEXT, activebackground=GOLD, activeforeground="#050505", relief="flat").pack(side="left", padx=(0, 8))
    tk.Button(wallets_actions, text="＋ Add Wallet", command=lambda: show_page("Add Wallet"), bg=GOLD, fg="#050505", activebackground=CYAN, activeforeground="#050505", relief="flat").pack(side="left", padx=(0, 8))
    tk.Button(wallets_actions, text="Delete Wallet", command=open_delete_wallet_dialog, bg="#6A1F24", fg=TEXT, activebackground=GOLD, activeforeground="#050505", relief="flat").pack(side="left", padx=(0, 8))
    tk.Button(wallets_actions, text="👁 Show/Hide Totals", command=toggle_totals, bg="#182635", fg=TEXT, activebackground=GOLD, activeforeground="#050505", relief="flat").pack(side="left")
    wallets_list = tk.Frame(wallets, bg=BG); wallets_list.pack(fill="both", expand=True, padx=22, pady=(0, 12))
    def refresh_wallets():
        clear(wallets_list)
        rec = wallet_gui_records()
        items = rec.get("items", [])
        if not items:
            empty = tk.Frame(wallets_list, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
            empty.pack(fill="x", padx=6, pady=8)
            tk.Label(empty, text="No wallets created yet", bg=PANEL, fg=TEXT, font=("Sans", 12, "bold")).pack(anchor="w", padx=12, pady=(12, 2))
            tk.Label(empty, text="Create one from Generate Wallet. You can create as many as you need.", bg=PANEL, fg=MUTED).pack(anchor="w", padx=12, pady=(0, 12))
            return
        for item in items:
            wallet_card(wallets_list, item)


    banking = make_page("Banking")
    page_title(banking, "Sentinel Banking", "Contained encrypted crypto bank/savings account foundation. Local-only, non-internet-facing, no active interest/yield yet.")
    banking_form = tk.Frame(banking, bg=BG); banking_form.pack(fill="x", padx=28, pady=(0, 8))
    banking_label_var = tk.StringVar(value="Long Term Sentinel Savings")
    banking_chain_var = tk.StringVar(value="SOL")
    banking_type_var = tk.StringVar(value="savings")
    banking_pass_var = tk.StringVar()
    banking_confirm_var = tk.StringVar()
    banking_words_var = tk.StringVar(value="24")
    def bank_row(label, widget, r):
        tk.Label(banking_form, text=label, bg=BG, fg=TEXT, font=("Sans", 10, "bold")).grid(row=r, column=0, sticky="w", pady=4)
        widget.grid(row=r, column=1, sticky="w", pady=4, padx=10)
    bank_row("Account label", tk.Entry(banking_form, textvariable=banking_label_var, width=42, bg="#111722", fg=TEXT, insertbackground=GOLD), 0)
    bank_row("Chain", ttk.Combobox(banking_form, textvariable=banking_chain_var, values=list(SUPPORTED_CHAINS.keys()), width=20, state="readonly"), 1)
    bank_row("Account type", ttk.Combobox(banking_form, textvariable=banking_type_var, values=BANKING_ACCOUNT_TYPES, width=20, state="readonly"), 2)
    bank_row("Recovery words", ttk.Combobox(banking_form, textvariable=banking_words_var, values=["12", "24"], width=20, state="readonly"), 3)
    bank_row("Password", tk.Entry(banking_form, textvariable=banking_pass_var, width=42, show="•", bg="#111722", fg=TEXT, insertbackground=GOLD), 4)
    bank_row("Confirm password", tk.Entry(banking_form, textvariable=banking_confirm_var, width=42, show="•", bg="#111722", fg=TEXT, insertbackground=GOLD), 5)
    banking_actions = tk.Frame(banking_form, bg=BG); banking_actions.grid(row=6, column=1, sticky="w", padx=10, pady=8)
    banking_result = make_scrolled_text(banking, height=5, bg="#0A1118", fg=GOLD, insertbackground=GOLD, wrap="word", relief="flat")
    banking_result._sentinel_scroll_frame.pack(fill="x", padx=28, pady=(0, 8))
    banking_result.insert("end", "New banking account recovery phrase will appear here once. Store it safely.")
    banking_result.configure(state="disabled")
    banking_list = tk.Frame(banking, bg=BG); banking_list.pack(fill="both", expand=True, padx=22, pady=(0, 12))
    def bank_card(parent, item):
        f = tk.Frame(parent, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
        f.pack(fill="x", padx=6, pady=6)
        top = tk.Frame(f, bg=PANEL); top.pack(fill="x", padx=12, pady=(10, 2))
        tk.Label(top, text=item.get("label", "Banking Account"), bg=PANEL, fg=TEXT, font=("Sans", 12, "bold")).pack(side="left")
        tk.Label(top, text=(item.get("account_type", "savings").upper() + " • " + item.get("chain", "")), bg="#1C2A36", fg=GOLD, font=("Sans", 9, "bold"), padx=8, pady=2).pack(side="right")
        tk.Label(f, text=f"{item.get('blockchain','')} • {item.get('address_short','')}", bg=PANEL, fg=MUTED, font=("Sans", 9)).pack(anchor="w", padx=12, pady=(0, 4))
        flags = "Local-only • Non-dApp-facing • Reward-eligible foundation" if item.get("interest_eligible") else "Local-only • Non-dApp-facing"
        tk.Label(f, text=flags, bg=PANEL, fg=SAFE, font=("Sans", 9, "bold"), wraplength=850, justify="left").pack(anchor="w", padx=12, pady=(0, 8))
    def refresh_banking():
        clear(banking_list)
        st = banking_status()
        small_card(banking_list, "Banking Accounts", str(st.get("account_count", 0)), "encrypted local containers", GOLD, side="top")
        small_card(banking_list, "Interest / Rewards", "Eligible only", "foundation metadata; no active yield", CYAN, side="top")
        small_card(banking_list, "Network Exposure", "Offline", "not dApp-facing by default", SAFE, side="top")
        for item in list_banking_accounts().get("items", []):
            bank_card(banking_list, item)
        if not list_banking_accounts().get("items"):
            empty = tk.Frame(banking_list, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
            empty.pack(fill="x", padx=6, pady=6)
            tk.Label(empty, text="No Sentinel Banking accounts yet", bg=PANEL, fg=TEXT, font=("Sans", 12, "bold")).pack(anchor="w", padx=12, pady=(12, 2))
            tk.Label(empty, text="Create a local encrypted crypto Bank/Savings account above. It will not be internet-facing or eligible for dApp connection.", bg=PANEL, fg=MUTED, font=("Sans", 10), wraplength=850, justify="left").pack(anchor="w", padx=12, pady=(0, 12))
    def do_create_banking():
        try:
            if not banking_pass_var.get():
                messagebox.showwarning("Password required", "Enter a password to encrypt this Sentinel Banking account.")
                return
            if banking_pass_var.get() != banking_confirm_var.get():
                messagebox.showwarning("Password mismatch", "The repeated password does not match.")
                return
            obj = create_banking_account(banking_label_var.get(), banking_chain_var.get(), banking_pass_var.get(), account_type=banking_type_var.get(), recovery_word_count=int(banking_words_var.get()), confirm_passphrase=banking_confirm_var.get())
            banking_pass_var.set(""); banking_confirm_var.set("")
            banking_result.configure(state="normal")
            banking_result.delete("1.0", "end")
            banking_result.insert("end", obj.get("recovery_phrase", ""))
            banking_result.configure(state="disabled")
            messagebox.showinfo("Sentinel Banking account created", f"{obj.get('label')} created as a local-only {obj.get('account_type')} account. Copy the recovery phrase now and store it safely.")
            refresh_banking(); refresh_dashboard()
        except Exception as exc:
            messagebox.showerror("Banking account failed", f"{type(exc).__name__}: {exc}")
    tk.Button(banking_actions, text="Create Banking Account", command=do_create_banking, bg=GOLD, fg="#050505", activebackground=CYAN, activeforeground="#050505", font=("Sans", 10, "bold"), relief="flat").pack(side="left", padx=(0, 8))
    tk.Button(banking_actions, text="Refresh Banking", command=refresh_banking, bg="#182635", fg=TEXT, activebackground=GOLD, activeforeground="#050505", relief="flat").pack(side="left")

    add_wallet = make_page("Add Wallet")
    page_title(add_wallet, "Add / Recover Wallet", "Recover an existing wallet from a 12 or 24 word recovery phrase into encrypted local storage.")
    add_form = tk.Frame(add_wallet, bg=BG); add_form.pack(anchor="nw", fill="x", padx=28, pady=8)
    add_name_var = tk.StringVar(value="Recovered ETH")
    add_chain_var = tk.StringVar(value="ETH")
    add_pass_var = tk.StringVar()
    add_confirm_var = tk.StringVar()
    add_show_var = tk.BooleanVar(value=False)
    def add_row(label, widget, r):
        tk.Label(add_form, text=label, bg=BG, fg=TEXT, font=("Sans", 10, "bold")).grid(row=r, column=0, sticky="nw", pady=6)
        widget.grid(row=r, column=1, sticky="w", pady=6, padx=10)
    add_row("Wallet name", tk.Entry(add_form, textvariable=add_name_var, width=42, bg="#111722", fg=TEXT, insertbackground=GOLD), 0)
    add_row("Chain", ttk.Combobox(add_form, textvariable=add_chain_var, values=list(SUPPORTED_CHAINS.keys()), width=14, state="readonly"), 1)
    recovery_text = make_scrolled_text(add_form, height=4, width=72, bg="#111722", fg=TEXT, insertbackground=GOLD, wrap="word", relief="flat")
    tk.Label(add_form, text="Recovery phrase", bg=BG, fg=TEXT, font=("Sans", 10, "bold")).grid(row=2, column=0, sticky="nw", pady=6)
    recovery_text._sentinel_scroll_frame.grid(row=2, column=1, sticky="we", pady=6, padx=10)
    add_pass_entry = tk.Entry(add_form, textvariable=add_pass_var, width=42, show="•", bg="#111722", fg=TEXT, insertbackground=GOLD)
    add_confirm_entry = tk.Entry(add_form, textvariable=add_confirm_var, width=42, show="•", bg="#111722", fg=TEXT, insertbackground=GOLD)
    add_row("New wallet password", add_pass_entry, 3)
    add_row("Repeat password", add_confirm_entry, 4)
    def toggle_add_eye():
        show = "" if add_show_var.get() else "•"
        add_pass_entry.configure(show=show); add_confirm_entry.configure(show=show)
    tk.Checkbutton(add_form, text="👁 Show password text", variable=add_show_var, command=toggle_add_eye, bg=BG, fg=GOLD, activebackground=BG, activeforeground=GOLD, selectcolor="#111722").grid(row=5, column=1, sticky="w", padx=10, pady=(2, 8))
    add_result = tk.StringVar(value="Paste your existing recovery phrase, choose the blockchain, then add the wallet.")
    tk.Label(add_form, textvariable=add_result, bg=BG, fg=GOLD, wraplength=780, justify="left").grid(row=6, column=1, sticky="w", padx=10, pady=(0, 8))
    def refresh_add_wallet():
        pass
    def do_add_wallet():
        try:
            phrase = recovery_text.get("1.0", "end").strip()
            if not phrase:
                messagebox.showwarning("Recovery phrase required", "Paste the 12 or 24 word recovery phrase first.")
                return
            if not add_pass_var.get():
                messagebox.showwarning("Password required", "Enter a wallet password to encrypt the recovered wallet record.")
                return
            if add_pass_var.get() != add_confirm_var.get():
                messagebox.showwarning("Password mismatch", "The repeated password does not match.")
                return
            obj = import_wallet_from_recovery_phrase(add_name_var.get(), add_chain_var.get(), phrase, add_pass_var.get(), persist=True, confirm_passphrase=add_confirm_var.get())
            add_pass_var.set(""); add_confirm_var.set("")
            recovery_text.delete("1.0", "end")
            add_result.set(f"Recovered {obj.get('chain')} wallet: {obj.get('address')}")
            messagebox.showinfo("Wallet added", f"Recovered wallet added: {obj.get('chain')} • {obj.get('address')}")
            refresh_dashboard(); refresh_wallets(); refresh_signing_wallet_choices()
        except Exception as exc:
            messagebox.showerror("Add Wallet failed", f"{type(exc).__name__}: {exc}")
    tk.Button(add_form, text="Add Wallet", command=do_add_wallet, bg=GOLD, fg="#050505", activebackground=CYAN, activeforeground="#050505", font=("Sans", 10, "bold"), relief="flat").grid(row=7, column=1, sticky="w", padx=10, pady=10)
    info_box = tk.Frame(add_wallet, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
    info_box.pack(fill="x", padx=28, pady=(8, 18))
    tk.Label(info_box, text="Recovery safety", bg=PANEL, fg=GOLD, font=("Sans", 12, "bold")).pack(anchor="w", padx=12, pady=(10, 2))
    tk.Label(info_box, text="This stores the recovered wallet as an encrypted local record. Browser cannot see the recovery phrase, password, private key, or encrypted contents. Full external BIP39/BIP44 compatibility remains an audit gate before production signing/broadcast claims.", bg=PANEL, fg=MUTED, wraplength=880, justify="left").pack(anchor="w", padx=12, pady=(0, 12))

    gen = make_page("Generate Wallet")
    page_title(gen, "Generate New Wallet", "Create a local encrypted wallet record with a 12 or 24 word recovery phrase.")
    form = tk.Frame(gen, bg=BG); form.pack(anchor="nw", fill="x", padx=28, pady=8)
    name_var = tk.StringVar(value="Main ETH")
    chain_var = tk.StringVar(value="ETH")
    word_var = tk.StringVar(value="24")
    pass_var = tk.StringVar()
    confirm_var = tk.StringVar()
    show_var = tk.BooleanVar(value=False)
    def row(label, widget, r):
        tk.Label(form, text=label, bg=BG, fg=TEXT, font=("Sans", 10, "bold")).grid(row=r, column=0, sticky="w", pady=6)
        widget.grid(row=r, column=1, sticky="w", pady=6, padx=10)
    row("Wallet name", tk.Entry(form, textvariable=name_var, width=42, bg="#111722", fg=TEXT, insertbackground=GOLD), 0)
    row("Chain", ttk.Combobox(form, textvariable=chain_var, values=list(SUPPORTED_CHAINS.keys()), width=14, state="readonly"), 1)
    row("Recovery phrase length", ttk.Combobox(form, textvariable=word_var, values=["12", "24"], width=14, state="readonly"), 2)
    pass_entry = tk.Entry(form, textvariable=pass_var, width=42, show="•", bg="#111722", fg=TEXT, insertbackground=GOLD)
    confirm_entry = tk.Entry(form, textvariable=confirm_var, width=42, show="•", bg="#111722", fg=TEXT, insertbackground=GOLD)
    row("Wallet password", pass_entry, 3)
    row("Repeat password", confirm_entry, 4)
    def toggle_eye():
        show = "" if show_var.get() else "•"
        pass_entry.configure(show=show); confirm_entry.configure(show=show)
    tk.Checkbutton(form, text="👁 Show password text", variable=show_var, command=toggle_eye, bg=BG, fg=GOLD, activebackground=BG, activeforeground=GOLD, selectcolor="#111722").grid(row=5, column=1, sticky="w", padx=10, pady=(2, 8))
    tk.Label(form, text="Write down the recovery phrase. It appears after generation and is stored only inside the encrypted wallet record.", bg=BG, fg=GOLD).grid(row=6, column=1, sticky="w", padx=10, pady=(0, 8))
    result_box = tk.Frame(gen, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
    result_box.pack(fill="both", expand=True, padx=28, pady=(10, 18))
    tk.Label(result_box, text="Generated Wallet", bg=PANEL, fg=GOLD, font=("Sans", 12, "bold")).pack(anchor="w", padx=12, pady=(10, 4))
    result_summary = tk.StringVar(value="No wallet generated in this session yet.")
    tk.Label(result_box, textvariable=result_summary, bg=PANEL, fg=TEXT, font=("Sans", 10), wraplength=850, justify="left").pack(anchor="w", padx=12, pady=(0, 6))
    phrase_text = make_scrolled_text(result_box, height=5, bg="#0A1118", fg=GOLD, insertbackground=GOLD, wrap="word", relief="flat")
    phrase_text._sentinel_scroll_frame.pack(fill="x", padx=12, pady=(0, 12))
    phrase_text.insert("end", "Recovery phrase will appear here after generation.")
    phrase_text.configure(state="disabled")
    def do_generate():
        try:
            if not pass_var.get():
                messagebox.showwarning("Password required", "Enter a wallet password to encrypt the generated wallet record.")
                return
            if pass_var.get() != confirm_var.get():
                messagebox.showwarning("Password mismatch", "The repeated password does not match.")
                return
            wc = int(word_var.get())
            obj = generate_wallet_record(name_var.get(), chain_var.get(), pass_var.get(), persist=True, recovery_word_count=wc, confirm_passphrase=confirm_var.get())
            pass_var.set(""); confirm_var.set("")
            result_summary.set(f"{obj.get('label')} • {obj.get('chain')} • {obj.get('address')}")
            phrase_text.configure(state="normal")
            phrase_text.delete("1.0", "end")
            phrase_text.insert("end", obj.get("recovery_phrase", ""))
            phrase_text.configure(state="disabled")
            messagebox.showinfo("Wallet generated", f"{obj.get('chain')} wallet created. Copy the {wc}-word recovery phrase now and store it safely.")
            refresh_dashboard(); refresh_wallets()
        except Exception as exc:
            messagebox.showerror("Generate Wallet failed", f"{type(exc).__name__}: {exc}")
    tk.Button(form, text="Generate New Wallet", command=do_generate, bg=GOLD, fg="#050505", activebackground=CYAN, activeforeground="#050505", font=("Sans", 10, "bold"), relief="flat").grid(row=7, column=1, sticky="w", padx=10, pady=10)


    sign_page = make_page("Sign-In")
    page_title(sign_page, "Sign-In / Message Signing", "Sign a login/proof message with an unlocked wallet. This is not transaction signing and it performs no network broadcast.")
    sign_form = tk.Frame(sign_page, bg=BG); sign_form.pack(anchor="nw", fill="x", padx=28, pady=8)
    sign_wallet_var = tk.StringVar()
    sign_pass_var = tk.StringVar()
    sign_show_var = tk.BooleanVar(value=False)
    sign_message_var = tk.StringVar(value="Sign in to app with Sentinel Wallet")
    wallet_choice_map: Dict[str, str] = {}
    wallet_combo = ttk.Combobox(sign_form, textvariable=sign_wallet_var, values=[], width=74, state="readonly")
    def sign_row(label, widget, r):
        tk.Label(sign_form, text=label, bg=BG, fg=TEXT, font=("Sans", 10, "bold")).grid(row=r, column=0, sticky="w", pady=6)
        widget.grid(row=r, column=1, sticky="w", pady=6, padx=10)
    sign_row("Wallet", wallet_combo, 0)
    sign_row("Message", tk.Entry(sign_form, textvariable=sign_message_var, width=76, bg="#111722", fg=TEXT, insertbackground=GOLD), 1)
    sign_pass_entry = tk.Entry(sign_form, textvariable=sign_pass_var, width=42, show="•", bg="#111722", fg=TEXT, insertbackground=GOLD)
    sign_row("Wallet password", sign_pass_entry, 2)
    def toggle_sign_eye():
        sign_pass_entry.configure(show="" if sign_show_var.get() else "•")
    tk.Checkbutton(sign_form, text="👁 Show password text", variable=sign_show_var, command=toggle_sign_eye, bg=BG, fg=GOLD, activebackground=BG, activeforeground=GOLD, selectcolor="#111722").grid(row=3, column=1, sticky="w", padx=10, pady=(2, 8))
    sign_result = make_scrolled_text(sign_page, height=10, bg="#0A1118", fg=TEXT, insertbackground=GOLD, wrap="word", relief="flat")
    sign_result._sentinel_scroll_frame.pack(fill="both", expand=True, padx=28, pady=(8, 18))
    def refresh_signing_wallet_choices():
        wallet_choice_map.clear()
        choices = []
        for item in wallet_gui_records().get("items", []):
            label = f"{item.get('label')} • {item.get('chain')} • {item.get('address_short')}"
            choices.append(label)
            wallet_choice_map[label] = item.get("wallet_uid", "")
        wallet_combo.configure(values=choices)
        if choices and not sign_wallet_var.get():
            sign_wallet_var.set(choices[0])
    def do_sign_message():
        try:
            choice = sign_wallet_var.get()
            uid = wallet_choice_map.get(choice, choice)
            if not uid:
                messagebox.showwarning("Wallet required", "Create or add a wallet before signing a login message.")
                return
            if not sign_pass_var.get():
                messagebox.showwarning("Password required", "Enter the wallet password to approve this message signature.")
                return
            obj = sign_login_message(uid, sign_pass_var.get(), sign_message_var.get(), browser_origin or "sentinel-wallet-gui")
            sign_pass_var.set("")
            sign_result.delete("1.0", "end")
            sign_result.insert("end", "Signature created\n\n")
            sign_result.insert("end", f"Wallet: {obj.get('wallet_uid')}\nChain: {obj.get('chain')}\nFormat: {obj.get('signature_format')}\nHash: {obj.get('message_hash_hex')}\n\nSignature:\n{obj.get('signature')}\n\nNote: {obj.get('compatibility_note')}\n")
        except Exception as exc:
            messagebox.showerror("Signing failed", f"{type(exc).__name__}: {exc}")
    sign_actions = tk.Frame(sign_form, bg=BG); sign_actions.grid(row=4, column=1, sticky="w", padx=10, pady=8)
    tk.Button(sign_actions, text="Refresh Wallets", command=refresh_signing_wallet_choices, bg="#182635", fg=TEXT, activebackground=GOLD, activeforeground="#050505", relief="flat").pack(side="left", padx=(0, 8))
    tk.Button(sign_actions, text="Sign Login Message", command=do_sign_message, bg=GOLD, fg="#050505", activebackground=CYAN, activeforeground="#050505", font=("Sans", 10, "bold"), relief="flat").pack(side="left")

    assets = make_page("Assets")
    page_title(assets, "Assets & Blockchains", "Supported coins, blockchains, and stablecoins.")
    assets_grid = tk.Frame(assets, bg=BG); assets_grid.pack(fill="both", expand=True, padx=24, pady=4)
    def refresh_assets():
        clear(assets_grid)
        for chain, meta in SUPPORTED_CHAINS.items():
            f = tk.Frame(assets_grid, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
            f.pack(fill="x", padx=6, pady=6)
            tk.Label(f, text=f"{chain} — {meta.get('blockchain')}", bg=PANEL, fg=GOLD, font=("Sans", 12, "bold")).pack(anchor="w", padx=12, pady=(10, 2))
            desc = f"Generation: {'Yes' if meta.get('generation_supported') else 'No'} • Address: {meta.get('address_type')} • Stablecoins: {', '.join(meta.get('stablecoins', [])) or '—'} • NFTs: {'Yes' if meta.get('nft_supported') else 'No'}"
            tk.Label(f, text=desc, bg=PANEL, fg=MUTED, font=("Sans", 10), wraplength=850, justify="left").pack(anchor="w", padx=12, pady=(0, 10))

    nfts = make_page("NFTs")
    page_title(nfts, "NFTs", "Local NFT inventory foundation. Live chain lookup remains disabled until audited.")
    nft_grid = tk.Frame(nfts, bg=BG); nft_grid.pack(fill="both", expand=True, padx=24, pady=4)
    def refresh_nfts():
        clear(nft_grid)
        cat = nft_catalog_by_chain()
        counts = cat.get("counts", {})
        for net in NFT_NETWORKS:
            chain_box = tk.Frame(nft_grid, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
            chain_box.pack(fill="x", padx=6, pady=8)
            tk.Label(chain_box, text=f"{net} Catalogue", bg=PANEL, fg=GOLD, font=("Sans", 13, "bold")).pack(anchor="w", padx=12, pady=(10, 2))
            tk.Label(chain_box, text=f"{counts.get(net, 0)} NFTs recorded locally • Live chain lookup disabled", bg=PANEL, fg=CYAN, font=("Sans", 10, "bold")).pack(anchor="w", padx=12, pady=(0, 6))
            records = cat.get("catalogue_by_chain", {}).get(net, [])
            if not records:
                tk.Label(chain_box, text="No NFTs recorded yet for this blockchain.", bg=PANEL, fg=MUTED, font=("Sans", 10)).pack(anchor="w", padx=12, pady=(0, 12))
            else:
                cards = tk.Frame(chain_box, bg=PANEL)
                cards.pack(fill="x", padx=8, pady=(0, 10))
                for rec in records:
                    nft_card = tk.Frame(cards, bg="#111A24", highlightbackground=BORDER, highlightthickness=1)
                    nft_card.pack(side="left", fill="both", expand=True, padx=4, pady=4)
                    tk.Label(nft_card, text=rec.get("name") or "Unnamed NFT", bg="#111A24", fg=TEXT, font=("Sans", 11, "bold")).pack(anchor="w", padx=10, pady=(8, 2))
                    tk.Label(nft_card, text=rec.get("collection") or "Unsorted Collection", bg="#111A24", fg=GOLD, font=("Sans", 9)).pack(anchor="w", padx=10)
                    tk.Label(nft_card, text=_short_address(rec.get("token_id", ""), 10, 6), bg="#111A24", fg=MUTED, font=("Sans", 9)).pack(anchor="w", padx=10, pady=(0, 8))


    escrow = make_page("Escrow")
    page_title(escrow, "Encrypted Passphrase Escrow", "Optional AEGIS Vault / Password Vault handoff. Explicit opt-in only.")
    escrow_grid = tk.Frame(escrow, bg=BG); escrow_grid.pack(fill="both", expand=True, padx=24, pady=4)
    def refresh_escrow():
        clear(escrow_grid)
        es = passphrase_escrow_status()
        small_card(escrow_grid, "Escrow", "Supported" if es.get("supported") else "Unavailable", "external encrypted opt-in only", GOLD, side="top")
        small_card(escrow_grid, "AEGIS Vault", "Detected" if es.get("aegis_vault_detected") else "Not detected", str(es.get("aegis_vault_path") or "set AEGIS_VAULT when needed"), CYAN, side="top")
        small_card(escrow_grid, "Password Vault Handoff", "Available", "encrypted handoff JSON; no plaintext export", CYAN, side="top")

    security = make_page("Security")
    page_title(security, "Security", "Clear security posture for this build.")
    security_grid = tk.Frame(security, bg=BG); security_grid.pack(fill="both", expand=True, padx=24, pady=4)
    def refresh_security():
        clear(security_grid)
        lines = [
            ("Crypto-only", "Enabled", "Wallet supports crypto records only."),
            ("Cards", "Disabled", "No debit cards, credit cards, CVV, or card autofill."),
            ("Login signing", "Enabled", "Local message signing for app login/proof requests; transaction signing remains disabled."),
            ("Broadcast", "Disabled", "No network broadcasting or live chain balance lookup."),
            ("Browser secret access", "Blocked", "Browser cannot read passphrases, recovery phrases, keys, or encrypted wallet contents."),
            ("Recovery phrase", "Encrypted record", "Shown at generation time; store safely offline or in encrypted escrow."),
        ]
        for title, value, subtitle in lines:
            colour = SAFE if value in {"Enabled", "Disabled", "Blocked", "Encrypted record"} else GOLD
            small_card(security_grid, title, value, subtitle, colour, side="top")

    manuals = make_page("Manuals")
    page_title(manuals, "Manuals", "Plain-language wallet instructions and safety reminders.")
    manual = make_scrolled_text(manuals, bg="#0A1118", fg=TEXT, insertbackground=GOLD, wrap="word", relief="flat")
    manual._sentinel_scroll_frame.pack(fill="both", expand=True, padx=28, pady=(6, 18))
    manual_text = """Sentinel Wallet Manual

Dashboard
- Shows your local wallet records in a proper wallet-style dashboard.
- Portfolio totals are hidden by default. Use the eye button to reveal local recorded totals.
- Live chain balances remain disabled until audited, so totals are local recorded values only.

Wallets
- Displays each created wallet as a card with label, chain, public address, and hidden totals.
- Use Add Wallet to recover an existing wallet from a 12 or 24 word recovery phrase.
- Private keys and recovery phrases are never shown in the wallet list.

Add Wallet
- Paste an existing recovery phrase, choose the blockchain, and encrypt the recovered wallet record with a local password.

Sign-In
- Signs a login/proof message after you enter the wallet password.
- This is local message signing only. Transaction signing and network broadcast remain disabled.

NFTs
- Displays NFT records in catalogue groups by blockchain.

Generate Wallet
- Choose BTC, ETH, BNB, XRP, or SOL.
- Choose a 12 or 24 word recovery phrase.
- Enter and repeat your wallet password.
- Use the eye control only when you are sure nobody can see your screen.

Security
- No debit cards, credit cards, CVV, card autofill, signing, broadcast, or browser-side wallet secrets in this phase.
- Store recovery phrases offline or in encrypted AEGIS Vault / Sentinel Password Vault escrow.

Hotkey: Ctrl+Q closes Sentinel Wallet.
"""
    manual.insert("end", manual_text)
    manual.configure(state="disabled")

    raw = make_page("Raw Status")
    page_title(raw, "Raw Status", "The only console/JSON-style diagnostic view in the GUI.")
    raw_text = make_scrolled_text(raw, bg="#0A1118", fg=TEXT, insertbackground=GOLD, wrap="word", relief="flat")
    raw_text._sentinel_scroll_frame.pack(fill="both", expand=True, padx=28, pady=(6, 18))
    def set_raw(obj):
        raw_text.delete("1.0", "end")
        raw_text.insert("end", json.dumps(obj, indent=2, sort_keys=True))
    def refresh_raw():
        set_raw({"dashboard": wallet_dashboard_status(), "portfolio": gui_portfolio_summary(), "wallet_records": wallet_gui_records(), "banking": banking_status(), "banking_receipts": list_banking_receipts(), "gui_layout": gui_layout_status(), "readiness": readiness_status(), "browser_origin": browser_origin})

    def refresh_all():
        refresh_dashboard(); refresh_wallets(); refresh_banking(); refresh_assets(); refresh_nfts(); refresh_escrow(); refresh_security(); refresh_raw()

    for name in GUI_TABS:
        view_menu.add_command(label=name, command=lambda n=name: show_page(n))
    help_menu.add_command(label="Manuals", command=lambda: show_page("Manuals"))
    help_menu.add_command(label="Wallet Security", command=lambda: show_page("Security"))
    menubar.add_cascade(label="View", menu=view_menu)
    menubar.add_cascade(label="Help", menu=help_menu)

    bottom = tk.Label(root, text="Crypto-only • Ctrl+Q to quit • Totals hidden by default • Raw diagnostics live only in Raw Status", bg=BG, fg=GOLD)
    bottom.pack(fill="x")
    refresh_all()
    show_page("Dashboard")
    # Try shortly after launch and again after the event loop settles. The exact
    # request id path prevents stale gateway requests from stealing focus.
    root.after(200, show_pending_browser_approval_if_any)
    root.after(900, show_pending_browser_approval_if_any)
    root.mainloop()



def gui_layout_status() -> Dict[str, Any]:
    return {
        "ok": True,
        "schema": "sentinel.wallet.gui_layout_status.v1_1_13",
        "version": VERSION,
        "app": APP,
        "scrollable_page_shell_enabled": True,
        "scrollable_tabs": GUI_TABS,
        "scrollbar_text_widgets": [
            "Banking result",
            "Add Wallet recovery phrase input",
            "Generate Wallet recovery result",
            "Sign-In result",
            "Manuals",
            "Raw Status",
        ],
        "content_bloat_guard_enabled": True,
        "x11_mate_friendly": True,
        "note": "Every major Wallet tab is hosted inside a vertical scrolling canvas and large information text panes have visible scrollbars.",
    }


def gui_layout_test() -> Dict[str, Any]:
    st = gui_layout_status()
    checks = {
        "scrollable_page_shell_enabled": st.get("scrollable_page_shell_enabled") is True,
        "all_gui_tabs_declared_scrollable": set(st.get("scrollable_tabs", [])) == set(GUI_TABS),
        "large_text_widgets_have_scrollbars": len(st.get("scrollbar_text_widgets", [])) >= 5,
        "content_bloat_guard_enabled": st.get("content_bloat_guard_enabled") is True,
    }
    return {"ok": all(checks.values()), "schema": "sentinel.wallet.gui_layout_test.v1_1_13", "version": VERSION, "checks": checks, "status": st}

def handle_browser_bridge(argv: List[str]) -> int:
    bp = argparse.ArgumentParser(prog="sentinel-wallet browser-bridge", description="Sentinel Wallet local browser bridge")
    bp.add_argument("--bridge-status", action="store_true"); bp.add_argument("--contract", action="store_true"); bp.add_argument("--open", action="store_true"); bp.add_argument("--write-request", action="store_true"); bp.add_argument("--write-response", action="store_true"); bp.add_argument("--read-request"); bp.add_argument("--read-response"); bp.add_argument("--wallet-icon-status", action="store_true"); bp.add_argument("--native-provider-status", action="store_true"); bp.add_argument("--native-provider-test", action="store_true"); bp.add_argument("--evm-provider-status", action="store_true"); bp.add_argument("--evm-provider-test", action="store_true"); bp.add_argument("--solana-provider-status", action="store_true"); bp.add_argument("--solana-provider-test", action="store_true"); bp.add_argument("--request-id", default=""); bp.add_argument("--request-kind", default="status"); bp.add_argument("--decision", default="rejected"); bp.add_argument("--message", default=""); bp.add_argument("--note", default=""); bp.add_argument("--browser-origin", default="")
    a = bp.parse_args(argv)
    if a.bridge_status: print(json.dumps(browser_bridge_status(), indent=2, sort_keys=True)); return 0
    if a.contract: print(json.dumps(browser_bridge_contract(), indent=2, sort_keys=True)); return 0
    if a.write_request: print(json.dumps(write_bridge_request(a.request_id, a.request_kind, a.browser_origin, a.note), indent=2, sort_keys=True)); return 0
    if a.write_response: print(json.dumps(write_bridge_response(a.request_id, a.decision, a.message, a.browser_origin), indent=2, sort_keys=True)); return 0
    if a.read_request: print(json.dumps(read_bridge_request(a.read_request), indent=2, sort_keys=True)); return 0
    if a.read_response: print(json.dumps(read_bridge_response(a.read_response), indent=2, sort_keys=True)); return 0
    if a.wallet_icon_status: print(json.dumps(wallet_icon_status(), indent=2, sort_keys=True)); return 0
    if a.native_provider_status: print(json.dumps(native_provider_core_status(), indent=2, sort_keys=True)); return 0
    if a.native_provider_test: obj = native_provider_core_test(); print(json.dumps(obj, indent=2, sort_keys=True)); return 0 if obj.get("ok") else 1
    if a.evm_provider_status: print(json.dumps(evm_provider_status(), indent=2, sort_keys=True)); return 0
    if a.evm_provider_test: obj = evm_provider_test(); print(json.dumps(obj, indent=2, sort_keys=True)); return 0 if obj.get("ok") else 1
    if a.solana_provider_status: print(json.dumps(solana_provider_status(), indent=2, sort_keys=True)); return 0
    if a.solana_provider_test: obj = solana_provider_test(); print(json.dumps(obj, indent=2, sort_keys=True)); return 0 if obj.get("ok") else 1
    if a.open: gui(a.browser_origin, a.request_id); return 0
    print(json.dumps(browser_bridge_status(), indent=2, sort_keys=True)); return 0



# ---- v1.0.1 Transaction + DApp Login capability patch ----------------------
# This patch adds local signing primitives for EVM dApp login and EVM legacy
# native-transfer transactions, plus Solana raw-payload signing. It deliberately
# keeps wallet-owned network broadcast disabled: a dApp/RPC can broadcast a
# signed transaction, but Sentinel Wallet does not run a network gateway here.
EVM_MAINNET_CHAIN_IDS = {"ETH": 1, "BNB": 56}
DAPP_LOGIN_ENABLED = True
BROWSER_DAPP_PROVIDER_ENABLED = True
WALLET_OWNED_NETWORK_BROADCAST_ENABLED = False
TRANSACTION_SIGNING_AUDIT_NOTE = "v1.0.1 enables local signing capability. Treat mainnet use as user-risk until hardware-backed key storage and independent external security audit are complete."

SECP256K1_P = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFFFFFC2F
SECP256K1_A = 0
SECP256K1_B = 7
SECP256K1_GX = 55066263022277343669578718895168534326250603453777594175500187360389116729240
SECP256K1_GY = 32670510020758816978083085130507043184471273380659243275938904335757337482424
SECP256K1_G = (SECP256K1_GX, SECP256K1_GY)


def _modinv(a: int, n: int) -> int:
    return pow(a % n, -1, n)


def _ec_add(p1, p2):
    if p1 is None:
        return p2
    if p2 is None:
        return p1
    x1, y1 = p1; x2, y2 = p2
    if x1 == x2 and (y1 + y2) % SECP256K1_P == 0:
        return None
    if p1 == p2:
        m = (3 * x1 * x1 + SECP256K1_A) * _modinv(2 * y1, SECP256K1_P)
    else:
        m = (y2 - y1) * _modinv(x2 - x1, SECP256K1_P)
    m %= SECP256K1_P
    x3 = (m * m - x1 - x2) % SECP256K1_P
    y3 = (m * (x1 - x3) - y1) % SECP256K1_P
    return (x3, y3)


def _ec_mul(k: int, point=SECP256K1_G):
    k %= SECP256K1_ORDER
    result = None
    addend = point
    while k:
        if k & 1:
            result = _ec_add(result, addend)
        addend = _ec_add(addend, addend)
        k >>= 1
    return result


def _ecdsa_sign_digest(priv_int: int, digest: bytes) -> Dict[str, Any]:
    z = int.from_bytes(digest, "big")
    counter = 0
    while True:
        seed = priv_int.to_bytes(32, "big") + digest + counter.to_bytes(4, "big")
        k = int.from_bytes(hashlib.sha256(seed).digest(), "big") % SECP256K1_ORDER
        if not k:
            counter += 1; continue
        R = _ec_mul(k)
        if R is None:
            counter += 1; continue
        r = R[0] % SECP256K1_ORDER
        if not r:
            counter += 1; continue
        s = (_modinv(k, SECP256K1_ORDER) * (z + r * priv_int)) % SECP256K1_ORDER
        if not s:
            counter += 1; continue
        recid = R[1] & 1
        if s > SECP256K1_ORDER // 2:
            s = SECP256K1_ORDER - s
            recid ^= 1
        return {"r": r, "s": s, "recovery_id": recid, "r_hex": f"{r:064x}", "s_hex": f"{s:064x}"}


def _int_from_any(v: Any, default: int = 0) -> int:
    if v is None or v == "":
        return default
    if isinstance(v, bool):
        return int(v)
    if isinstance(v, int):
        return v
    text = str(v).strip()
    if text.startswith(("0x", "0X")):
        return int(text, 16)
    return int(text)


def _hex_bytes(v: Any, default: bytes = b"") -> bytes:
    if v in (None, ""):
        return default
    if isinstance(v, bytes):
        return v
    text = str(v).strip()
    if text.startswith("0x"):
        text = text[2:]
    if len(text) % 2:
        text = "0" + text
    return bytes.fromhex(text)


def _rlp_encode(item: Any) -> bytes:
    if isinstance(item, int):
        if item == 0:
            b = b""
        else:
            b = item.to_bytes((item.bit_length() + 7) // 8, "big")
        return _rlp_encode(b)
    if isinstance(item, str):
        if item.startswith("0x"):
            return _rlp_encode(_hex_bytes(item))
        return _rlp_encode(item.encode())
    if isinstance(item, (bytes, bytearray)):
        b = bytes(item)
        if len(b) == 1 and b[0] < 0x80:
            return b
        if len(b) <= 55:
            return bytes([0x80 + len(b)]) + b
        blen = len(b).to_bytes((len(b).bit_length() + 7) // 8, "big")
        return bytes([0xB7 + len(blen)]) + blen + b
    if isinstance(item, list):
        payload = b"".join(_rlp_encode(x) for x in item)
        if len(payload) <= 55:
            return bytes([0xC0 + len(payload)]) + payload
        blen = len(payload).to_bytes((len(payload).bit_length() + 7) // 8, "big")
        return bytes([0xF7 + len(blen)]) + blen + payload
    raise TypeError(f"unsupported_rlp_type:{type(item).__name__}")


def _evm_sign_personal_message(secret: Dict[str, Any], wallet_uid: str, message: str, origin: str = "") -> Dict[str, Any]:
    chain = (secret.get("chain") or "ETH").upper()
    private_material = base64.b64decode(secret.get("private_material_b64", ""))
    priv_int = int.from_bytes(private_material[:32], "big") % (SECP256K1_ORDER - 1) + 1
    msg = str(message or "")
    prefixed = (f"\x19Ethereum Signed Message:\n{len(msg.encode())}" ).encode() + msg.encode()
    digest = keccak256(prefixed)
    sig = _ecdsa_sign_digest(priv_int, digest)
    v = 27 + int(sig["recovery_id"])
    signature_hex = "0x" + sig["r_hex"] + sig["s_hex"] + f"{v:02x}"
    return {
        "ok": True,
        "schema": "sentinel.wallet.dapp_login_signature.v1_0_1",
        "version": VERSION,
        "wallet_uid": wallet_uid,
        "chain": chain,
        "origin": origin or "local-wallet-gui",
        "message_preview": msg[:240],
        "message_hash_hex": "0x" + digest.hex(),
        "signature": signature_hex,
        "signature_format": "eip191_rsv_hex",
        "browser_secret_values_exported": False,
        "transaction_signing_enabled": TRANSACTION_SIGNING_ENABLED,
        "network_broadcast_enabled": WALLET_OWNED_NETWORK_BROADCAST_ENABLED,
        "walletconnect_v2_foundation_enabled": True,
        "supported_walletconnect_namespaces": ["eip155", "solana", "bip122"],
        "audit_note": TRANSACTION_SIGNING_AUDIT_NOTE,
    }


def sign_dapp_login_message(wallet_uid: str, passphrase: str, message: str, origin: str = "") -> Dict[str, Any]:
    if not DAPP_LOGIN_ENABLED:
        raise ValueError("dapp_login_disabled")
    if not passphrase:
        raise ValueError("missing_passphrase")
    if not str(message or "").strip():
        raise ValueError("missing_message")
    secret = _load_wallet_secret(wallet_uid, passphrase)
    chain = (secret.get("chain") or "").upper()
    if chain in {"ETH", "BNB"}:
        return _evm_sign_personal_message(secret, wallet_uid, message, origin)
    # Keep non-EVM chains explicit rather than pretending SIWE compatibility.
    if chain == "SOL":
        private_material = base64.b64decode(secret.get("private_material_b64", ""))
        from cryptography.hazmat.primitives.asymmetric import ed25519
        priv = ed25519.Ed25519PrivateKey.from_private_bytes(private_material[:32])
        payload = (origin or "local-wallet-gui").encode() + b"\n" + str(message).encode()
        sig = priv.sign(payload)
        return {"ok": True, "schema": "sentinel.wallet.dapp_login_signature.v1_0_1", "version": VERSION, "wallet_uid": wallet_uid, "chain": chain, "origin": origin or "local-wallet-gui", "message_preview": str(message)[:240], "message_hash_hex": hashlib.sha256(payload).hexdigest(), "signature": base64.b64encode(sig).decode(), "signature_format": "solana_ed25519_base64", "browser_secret_values_exported": False, "network_broadcast_enabled": False, "audit_note": TRANSACTION_SIGNING_AUDIT_NOTE}
    raise ValueError(f"dapp_login_not_enabled_for_chain:{chain}")


def sign_evm_legacy_transaction(wallet_uid: str, passphrase: str, tx: Dict[str, Any], origin: str = "") -> Dict[str, Any]:
    secret = _load_wallet_secret(wallet_uid, passphrase)
    chain = (secret.get("chain") or "").upper()
    if chain not in {"ETH", "BNB"}:
        raise ValueError(f"evm_transaction_signing_not_supported_for_chain:{chain}")
    private_material = base64.b64decode(secret.get("private_material_b64", ""))
    priv_int = int.from_bytes(private_material[:32], "big") % (SECP256K1_ORDER - 1) + 1
    chain_id = _int_from_any(tx.get("chainId", tx.get("chain_id", EVM_MAINNET_CHAIN_IDS.get(chain, 1))))
    nonce = _int_from_any(tx.get("nonce"))
    gas_price = _int_from_any(tx.get("gasPrice", tx.get("gas_price")))
    gas_limit = _int_from_any(tx.get("gas", tx.get("gasLimit", tx.get("gas_limit", 21000))), 21000)
    to = str(tx.get("to", "")).strip()
    if to.startswith("0x"):
        to_bytes = _hex_bytes(to)
    else:
        to_bytes = bytes.fromhex(to)
    if len(to_bytes) != 20:
        raise ValueError("evm_to_address_must_be_20_bytes")
    value = _int_from_any(tx.get("value"))
    data = _hex_bytes(tx.get("data", "0x"))
    unsigned = [nonce, gas_price, gas_limit, to_bytes, value, data, chain_id, 0, 0]
    digest = keccak256(_rlp_encode(unsigned))
    sig = _ecdsa_sign_digest(priv_int, digest)
    v = chain_id * 2 + 35 + int(sig["recovery_id"])
    signed_fields = [nonce, gas_price, gas_limit, to_bytes, value, data, v, sig["r"], sig["s"]]
    raw = "0x" + _rlp_encode(signed_fields).hex()
    return {
        "ok": True,
        "schema": "sentinel.wallet.signed_evm_legacy_transaction.v1_0_1",
        "version": VERSION,
        "wallet_uid": wallet_uid,
        "chain": chain,
        "chain_id": chain_id,
        "origin": origin or "local-wallet-gui",
        "transaction_type": "evm_legacy_native_or_contract_call",
        "tx_hash_unsigned": "0x" + digest.hex(),
        "signed_transaction_hex": raw,
        "signature": {"v": v, "r": "0x" + sig["r_hex"], "s": "0x" + sig["s_hex"]},
        "broadcast_by_wallet": False,
        "broadcast_ready_payload": True,
        "browser_secret_values_exported": False,
        "audit_note": TRANSACTION_SIGNING_AUDIT_NOTE,
    }


def sign_solana_raw_payload(wallet_uid: str, passphrase: str, tx: Dict[str, Any], origin: str = "") -> Dict[str, Any]:
    secret = _load_wallet_secret(wallet_uid, passphrase)
    chain = (secret.get("chain") or "").upper()
    if chain != "SOL":
        raise ValueError(f"solana_raw_signing_not_supported_for_chain:{chain}")
    payload_b64 = str(tx.get("raw_transaction_b64") or tx.get("message_b64") or "").strip()
    if not payload_b64:
        raise ValueError("missing_raw_transaction_b64_or_message_b64")
    payload = base64.b64decode(payload_b64)
    private_material = base64.b64decode(secret.get("private_material_b64", ""))
    from cryptography.hazmat.primitives.asymmetric import ed25519
    priv = ed25519.Ed25519PrivateKey.from_private_bytes(private_material[:32])
    sig = priv.sign(payload)
    return {"ok": True, "schema": "sentinel.wallet.signed_solana_raw_payload.v1_0_1", "version": VERSION, "wallet_uid": wallet_uid, "chain": chain, "origin": origin or "local-wallet-gui", "payload_sha256": hashlib.sha256(payload).hexdigest(), "signature": base64.b64encode(sig).decode(), "signature_format": "ed25519_base64", "broadcast_by_wallet": False, "browser_secret_values_exported": False, "audit_note": TRANSACTION_SIGNING_AUDIT_NOTE}


def sign_transaction_payload(wallet_uid: str, passphrase: str, transaction_json: str, origin: str = "") -> Dict[str, Any]:
    if not TRANSACTION_SIGNING_ENABLED:
        raise ValueError("transaction_signing_disabled")
    tx = json.loads(transaction_json) if isinstance(transaction_json, str) else dict(transaction_json or {})
    secret = _load_wallet_secret(wallet_uid, passphrase)
    chain = (secret.get("chain") or "").upper()
    if chain in {"ETH", "BNB"}:
        return sign_evm_legacy_transaction(wallet_uid, passphrase, tx, origin)
    if chain == "SOL":
        return sign_solana_raw_payload(wallet_uid, passphrase, tx, origin)
    raise ValueError(f"transaction_signing_not_enabled_for_chain:{chain}")


def transaction_dapp_status() -> Dict[str, Any]:
    return {
        "ok": True,
        "schema": "sentinel.wallet.transaction_dapp_status.v1_0_2",
        "version": VERSION,
        "wallet_type": "crypto_only",
        "transaction_signing_enabled": True,
        "wallet_owned_network_broadcast_enabled": False,
        "browser_dapp_login_enabled": True,
        "browser_secret_storage_enabled": False,
        "browser_private_key_access_enabled": False,
        "supported_transaction_signers": {
            "ETH": "EVM legacy raw transaction signing, signed payload returned for external dApp/RPC broadcast",
            "BNB": "EVM legacy raw transaction signing, signed payload returned for external dApp/RPC broadcast",
            "SOL": "Ed25519 raw transaction/message payload signature",
            "BTC": "WalletConnect/PSBT approval foundation; audited PSBT signing remains guarded",
            "XRP": "receive/watch/login foundation only; XRPL transaction serialization deferred to audited patch",
        },
        "supported_dapp_login": {
            "ETH": "EIP-191 personal_sign / SIWE-compatible RSV signature",
            "BNB": "EIP-191 personal_sign / EVM-compatible RSV signature",
            "SOL": "Solana Ed25519 login/proof signature",
        },
        "requires_user_unlock_for_each_signature": True,
        "requires_explicit_user_approval": True,
        "ai_may_initiate_transaction": False,
        "audit_note": TRANSACTION_SIGNING_AUDIT_NOTE,
    }


def transaction_dapp_test() -> Dict[str, Any]:
    c = _crypto_import_status()
    checks = {
        "runtime_version_1_1_4_or_newer": _version_tuple(VERSION) >= _version_tuple("1.1.4"),
        "crypto_available": c.get("cryptography") and c.get("secp256k1") and c.get("ed25519"),
        "transaction_signing_enabled": TRANSACTION_SIGNING_ENABLED is True,
        "dapp_login_enabled": DAPP_LOGIN_ENABLED is True,
        "wallet_broadcast_disabled": WALLET_OWNED_NETWORK_BROADCAST_ENABLED is False,
        "browser_secrets_forbidden": True,
        "cards_forbidden": CARD_FEATURES_ENABLED is False,
    }
    preview = {}
    try:
        gen = generate_wallet_record("Tx Test ETH", "ETH", "sentinel-wallet-tx-test", persist=False, recovery_word_count=12)
        uid = gen["wallet_uid"]
        # Persist-free test cannot reload from DB, so exercise pure ECDSA/RLP helpers directly.
        sig = _ecdsa_sign_digest(1, b"\x01" * 32)
        rlp = _rlp_encode([0, 1, 21000, bytes.fromhex("0000000000000000000000000000000000000000"), 0, b"", 1, 0, 0]).hex()
        checks["ecdsa_helper"] = bool(sig.get("r") and sig.get("s"))
        checks["rlp_helper"] = rlp.startswith("df") or len(rlp) > 10
        preview = {"generated_eth_address_prefix": gen.get("address", "")[:10], "signature_r_prefix": sig.get("r_hex", "")[:10]}
    except Exception as exc:
        checks["helper_exception"] = False
        preview = {"error": type(exc).__name__, "message": str(exc)}
    return {"ok": all(bool(v) for v in checks.values()), "schema": "sentinel.wallet.transaction_dapp_test.v1_0_2", "version": VERSION, "checks": checks, "preview": preview, "status": transaction_dapp_status()}


# Override v1.0.0 status/bridge/gate functions for the v1.0.1 transaction+dApp scope.
def v1_deferred_scope() -> List[str]:
    return [
        "wallet-owned network broadcast gateway",
        "live chain balance lookup",
        "full audited WalletConnect relay client and broad dApp compatibility matrix",
        "BTC PSBT signing and audited Bitcoin transaction builder",
        "XRPL transaction serialization/signing",
        "hardware-backed key storage",
        "independent external mainnet security review",
    ]


def v1_locked_scope() -> List[str]:
    return [
        "local-first encrypted crypto-only wallet records",
        "Wallets tab Delete Wallet control beside Add Wallet with typed confirmation",
        "local encrypted wallet record deletion only; blockchain assets and independent backups are not deleted",
        "12/24 word recovery phrase generation and recovery/import foundation",
        "BTC, ETH, BNB, XRP, and SOL local account/address generation foundation",
        "USDT and USDC display/readiness foundation across ETH, BNB, and SOL",
        "ETH/BNB/SOL local NFT catalogue foundation",
        "explicit local blockchain app-login signing for ETH/BNB/SOL",
        "explicit user-approved ETH/BNB EVM legacy transaction signing with signed raw payload output",
        "explicit user-approved SOL raw-payload signing",
        "WalletConnect pairing request foundation across EVM, Solana, and BTC namespaces",
        "Browser bridge status/open/request-response compatibility with no browser secret storage",
        "no debit/credit card storage, CVV storage, card autofill, or browser-side wallet secrets",
        "wallet-owned network broadcast remains disabled; signed payload may be broadcast externally by a dApp/RPC",
    ]


def asset_support_status() -> Dict[str, Any]:
    return {"ok": True, "schema": "sentinel.wallet.asset_support_status.v1_0_1", "version": VERSION, "top_market_target_coins": TOP_MARKET_TARGET_COINS, "additional_required_coins": ADDITIONAL_REQUIRED_COINS, "supported_coins": SUPPORTED_COINS, "supported_chains": SUPPORTED_CHAINS, "supported_stablecoins": SUPPORTED_STABLECOINS, "nft_networks": NFT_NETWORKS, "generate_wallet_supported": True, "multiple_wallets_allowed": True, "recovery_phrase_word_counts": RECOVERY_WORD_COUNTS, "card_features_enabled": False, "signing_enabled": True, "message_signing_enabled": LOGIN_MESSAGE_SIGNING_ENABLED, "dapp_login_enabled": True, "transaction_signing_enabled": True, "broadcast_enabled": False, "network_access_enabled": False, "transaction_dapp": transaction_dapp_status()}


def crypto_wallet_status() -> Dict[str, Any]:
    init_db()
    return {"ok": True, "schema": "sentinel.wallet.crypto_status.v1_0_1", "version": VERSION, "wallet_type": "crypto_only", "supported_coins": SUPPORTED_COINS, "supported_networks": list(SUPPORTED_CHAINS.keys()), "supported_chains": SUPPORTED_CHAINS, "supported_stablecoins": SUPPORTED_STABLECOINS, "generate_wallet_supported": True, "import_wallet_supported": True, "multiple_wallets_allowed": True, "recovery_phrase_word_counts": RECOVERY_WORD_COUNTS, "network_enabled": False, "signing_enabled": True, "message_signing_enabled": LOGIN_MESSAGE_SIGNING_ENABLED, "dapp_login_enabled": True, "transaction_signing_enabled": True, "broadcast_enabled": False, "receive_address_foundation": True, "watch_only_foundation": True, "master_passphrase_stored": False, "secret_export_enabled": False, "card_features": card_feature_status(), "transaction_dapp": transaction_dapp_status()}


def chain_readiness_status() -> Dict[str, Any]:
    chains = {}
    for chain, meta in SUPPORTED_CHAINS.items():
        tx_ready = chain in {"ETH", "BNB", "SOL"}
        chains[chain] = {"enabled": True, "generation_ready": bool(meta.get("generation_supported")), "message_signing_ready": LOGIN_MESSAGE_SIGNING_ENABLED, "dapp_login_ready": chain in {"ETH", "BNB", "SOL"}, "transaction_signing_ready": tx_ready, "broadcast_ready": False, "live_balance_ready": False, "nft_ready": bool(meta.get("nft_supported")), "stablecoins": meta.get("stablecoins", []), "status": "transaction_dapp_ready_local_no_wallet_broadcast" if tx_ready else "receive_watch_login_foundation_only"}
    stables = {sym: {"enabled": True, "networks": meta.get("networks", []), "display_ready": True, "transfer_ready": True, "live_balance_ready": False, "signing_via_native_network_wallet": True} for sym, meta in SUPPORTED_STABLECOINS.items()}
    return {"ok": True, "schema": "sentinel.wallet.chain_readiness_status.v1_0_1", "version": VERSION, "chains": chains, "stablecoins": stables}


def browser_bridge_contract() -> Dict[str, Any]:
    return {"ok": True, "schema": "sentinel.wallet.browser_bridge_contract.v1_0_2", "app": APP, "package": PACKAGE, "program": PROGRAM, "version": VERSION, "browser_bridge_supported": True, "browser_open_supported": True, "browser_origin_context_supported": True, "request_response_supported": True, "browser_generated_request_id_supported": True, "write_request_supported": True, "write_response_supported": True, "read_response_supported": True, "wallet_type": "crypto_only", "crypto_only_wallet": True, "card_features_enabled": False, "credit_card_support": False, "debit_card_support": False, "bank_card_storage_enabled": False, "card_autofill_enabled": False, "credential_storage": "none_in_browser", "browser_must_never_store": ["seed phrase", "private keys", "wallet passphrase", "signing material", "payment secrets", "card numbers", "CVV"], "payments_enabled": True, "crypto_transactions_enabled": True, "signing_enabled": True, "message_signing_enabled": LOGIN_MESSAGE_SIGNING_ENABLED, "dapp_login_enabled": True, "transaction_signing_enabled": True, "network_access_enabled": False, "wallet_owned_broadcast_enabled": False, "browser_may_request_signing": True, "browser_may_request_transaction_signing": True, "browser_may_receive_signed_payload_only": True, "browser_may_receive_secrets": False, "generate_wallet_supported": True, "import_wallet_supported": True, "multiple_wallets_allowed": True, "supported_coins": SUPPORTED_COINS, "supported_chains": list(SUPPORTED_CHAINS.keys()), "stablecoins_supported": list(SUPPORTED_STABLECOINS.keys()), "networks_declared": list(SUPPORTED_CHAINS.keys()), "nft_support_enabled": True, "nft_inventory_supported": True, "nft_networks_declared": NFT_NETWORKS, "requires_user_unlock": True, "requires_explicit_user_approval_for_each_signature": True, "ai_may_initiate_payment": False, "aegis_may_export_secrets": False, "passphrase_escrow_supported": True, "passphrase_escrow_default_enabled": False, "wallet_internal_master_passphrase_stored": False, "transaction_dapp": transaction_dapp_status(), "walletconnect": walletconnect_status(), "native_provider": native_provider_core_status(), "banking": banking_status(), "status": "crypto_only_multi_wallet_native_provider_phase1_foundation_no_browser_secrets_no_wallet_broadcast"}


def browser_bridge_status() -> Dict[str, Any]:
    ensure_dirs()
    return {"ok": True, "schema": "sentinel.wallet.browser_bridge_status.v1_0_2", "app": APP, "package": PACKAGE, "program": PROGRAM, "version": VERSION, "browser_bridge_supported": True, "request_response_supported": True, "read_response_supported": True, "requests_dir": str(REQUESTS_DIR), "responses_dir": str(RESPONSES_DIR), "private_dirs_chmod_700_target": True, "wallet_type": "crypto_only", "crypto_only_wallet": True, "card_features_enabled": False, "payments_enabled": True, "crypto_transactions_enabled": True, "signing_enabled": True, "message_signing_enabled": LOGIN_MESSAGE_SIGNING_ENABLED, "dapp_login_enabled": True, "transaction_signing_enabled": True, "network_access_enabled": False, "wallet_owned_broadcast_enabled": False, "generate_wallet_supported": True, "import_wallet_supported": True, "multiple_wallets_allowed": True, "supported_coins": SUPPORTED_COINS, "supported_chains": list(SUPPORTED_CHAINS.keys()), "stablecoins_supported": list(SUPPORTED_STABLECOINS.keys()), "nft_support_enabled": True, "nft_inventory_supported": True, "browser_may_open_wallet_gui": True, "browser_may_request_status": True, "browser_may_request_payment": True, "browser_may_request_signing": True, "browser_may_request_transaction_signing": True, "browser_may_receive_signed_payload_only": True, "secret_values_exported": False, "aegis_required": False, "sentinel_os_required": False, "contract": browser_bridge_contract(), "crypto_status": crypto_wallet_status(), "nft_status": nft_status(), "asset_support": asset_support_status(), "passphrase_escrow_supported": True, "passphrase_escrow_default_enabled": False, "passphrase_escrow_status": passphrase_escrow_status(), "transaction_dapp": transaction_dapp_status(), "walletconnect": walletconnect_status(), "native_provider": native_provider_core_status(), "banking": banking_status(), "status": "ready_crypto_transaction_dapp_native_provider_phase1_no_browser_secrets_no_wallet_broadcast"}


def write_bridge_request(request_id: str, kind: str = "status", browser_origin: str = "", note: str = "") -> Dict[str, Any]:
    ensure_dirs(); rid = _safe_request_id(request_id)
    allowed = ("status", "open", "connect_preview", "receive_address_preview", "nft_inventory_preview", "asset_support_preview", "generate_wallet_preview", "dapp_login_request", "personal_sign_request", "transaction_sign_request", "payment_request", "walletconnect_pairing", "walletconnect_session_proposal")
    if kind not in allowed:
        kind = "status"
    native = _parse_native_provider_note(note or "", kind, browser_origin or "")
    native["request_id"] = rid
    native["request_kind"] = kind
    native["created_at"] = now_iso()
    obj = {"ok": True, "schema": "sentinel.wallet.browser_bridge_request.v1_0_2", "request_id": rid, "request_kind": kind, "browser_origin": browser_origin or "", "note": note or "", "native_provider": native, "created_at": native["created_at"], "browser_generated_request_id": rid.startswith("browser-"), "wallet_type": "crypto_only", "card_features_enabled": False, "payments_enabled": True, "crypto_transactions_enabled": True, "signing_enabled": True, "message_signing_enabled": LOGIN_MESSAGE_SIGNING_ENABLED, "dapp_login_enabled": True, "transaction_signing_enabled": True, "network_access_enabled": False, "wallet_owned_broadcast_enabled": False, "secret_values_present": False, "status": "pending_user_wallet_approval"}
    path = REQUESTS_DIR / f"{rid}.json"; _safe_atomic_write_text(path, json.dumps(obj, indent=2, sort_keys=True) + "\n"); return obj


def write_bridge_response(request_id: str, decision: str = "rejected", message: str = "", browser_origin: str = "", approval_payload: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    ensure_dirs(); rid = _safe_request_id(request_id); decision = (decision or "rejected").lower()
    if decision not in ("approved", "rejected", "cancelled", "pending"):
        decision = "rejected"
    req = read_bridge_request(rid)
    req_native = req.get("native_provider") if isinstance(req.get("native_provider"), dict) else {}
    approval_payload = dict(approval_payload or {})
    native = {"schema": NATIVE_PROVIDER_RESPONSE_SCHEMA, "bridge_schema": NATIVE_PROVIDER_BRIDGE_SCHEMA, "phase": "phase3_manual_approval_return_patch", "request_id": rid, "decision": decision, "method": req_native.get("method"), "chain_family": req_native.get("chain_family"), "chain_id": req_native.get("chain_id"), "origin": browser_origin or req.get("browser_origin") or req_native.get("origin") or "", "approved": decision == "approved", "user_approval_required": True, "approval_owner": "Sentinel Wallet", "browser_may_receive_secrets": False, "secret_values_exported": False, "wallet_owned_network_broadcast_enabled": False, "signed_payload_only": bool(decision == "approved" and approval_payload.get("signature"))}
    if approval_payload:
        for k, v in approval_payload.items():
            if k not in {"private_key", "seed", "seed_phrase", "recovery_phrase", "passphrase", "password"}:
                native[k] = v
    obj = {"ok": True, "schema": "sentinel.wallet.browser_bridge_response.v1_1_7", "request_id": rid, "decision": decision, "message": message or "", "browser_origin": native["origin"], "native_provider": native, "created_at": now_iso(), "wallet_type": "crypto_only", "card_features_enabled": False, "payments_enabled": True, "crypto_transactions_enabled": True, "signing_enabled": True, "message_signing_enabled": LOGIN_MESSAGE_SIGNING_ENABLED, "dapp_login_enabled": True, "transaction_signing_enabled": True, "network_access_enabled": False, "wallet_owned_broadcast_enabled": False, "secret_values_exported": False, "signed_payload_only": bool(native.get("signed_payload_only"))}
    if approval_payload:
        for k, v in approval_payload.items():
            if k in {"address", "public_address", "publicKey", "public_key", "account", "accounts", "addresses", "wallet_uid", "wallet_label", "wallet_chain", "chain_id", "chain_family", "signature", "signature_format", "message_hash_hex", "signed_transaction_hex", "transaction_payload_forwarded", "broadcast_by_wallet"}:
                obj[k] = v
    path = RESPONSES_DIR / f"{rid}.json"; _safe_atomic_write_text(path, json.dumps(obj, indent=2, sort_keys=True) + "\n"); return obj


def readiness_status() -> Dict[str, Any]:
    init_db(); c = _crypto_import_status()
    checks = {"version_1_0_2": VERSION == "1.0.2", "crypto_available": c["cryptography"] and c["aesgcm"] and c["secp256k1"] and c["ed25519"], "crypto_only_no_cards": CRYPTO_ONLY and not CARD_FEATURES_ENABLED, "local_first_wallet_no_network_broadcast": NO_NETWORK and not NETWORK_ACCESS_ENABLED and not BROADCAST_ENABLED, "transaction_signing_enabled": TRANSACTION_SIGNING_ENABLED and SIGNING_ENABLED, "dapp_login_enabled": DAPP_LOGIN_ENABLED, "top_assets_declared": all(x in SUPPORTED_COINS for x in ["BTC", "ETH", "BNB", "XRP", "SOL", "USDT", "USDC"]), "nft_catalogue_foundation": NFT_SUPPORT_ENABLED and all(x in NFT_NETWORKS for x in ["ETH", "BNB", "SOL"]), "browser_bridge_no_secrets": browser_bridge_contract().get("browser_may_receive_secrets") is False, "delete_wallet_enabled": GUI_DELETE_WALLET_ENABLED is True, "delete_wallet_confirmation_required": GUI_DELETE_WALLET_REQUIRES_TYPED_CONFIRMATION is True, "master_passphrase_not_stored": True}
    return {"schema": "sentinel.wallet.readiness.v1_0_2", "app": APP, "package": PACKAGE, "program": PROGRAM, "version": VERSION, "release_track": "v1_1_walletconnect_multichain_foundation", "wallet_type": "crypto_only", "local_first": True, "aegis_required": False, "sentinel_os_required": False, "master_passphrase_stored": False, "network_enabled": False, "payments_enabled": True, "crypto_transactions_enabled": True, "signing_enabled": True, "message_signing_enabled": LOGIN_MESSAGE_SIGNING_ENABLED, "dapp_login_enabled": True, "transaction_signing_enabled": True, "broadcast_enabled": False, "wallet_owned_broadcast_enabled": False, "card_features": card_feature_status(), "asset_support": asset_support_status(), "nft": nft_status(), "browser_bridge": browser_bridge_contract(), "transaction_dapp": transaction_dapp_status(), "walletconnect": walletconnect_status(), "crypto": c, "kdf_preferred": "Argon2id", "kdf_fallback": "PBKDF2-HMAC-SHA256", "cipher_target": "AES-256-GCM via python3-cryptography", "v1_ready": all(checks.values()), "v1_scope": "transaction_dapp_login_wallet_delete_walletconnect_multichain_foundation", "v1_checks": checks, "v1_locked_scope": v1_locked_scope(), "v1_deferred_scope": v1_deferred_scope(), "v1_blockers": [], "passphrase_escrow": passphrase_escrow_status(), "banking": banking_status(), "audit_note": TRANSACTION_SIGNING_AUDIT_NOTE}


def browser_contract() -> Dict[str, Any]:
    obj = browser_bridge_contract().copy(); obj["schema"] = "sentinel.wallet.browser_contract.v1_0_1"; obj["browser_integration"] = "crypto_transaction_dapp_login_status_open_request_response_signed_payload_only_no_browser_secrets"; return obj


def browser_status() -> Dict[str, Any]:
    return {"ok": True, "schema": "sentinel.wallet.browser_status.v1_0_1", "app": APP, "version": VERSION, "bridge": browser_bridge_status(), "readiness": {"network_enabled": False, "browser_payments_enabled": True, "master_passphrase_stored": False, "wallet_type": "crypto_only", "browser_secret_storage_enabled": False}, "secret_values_exported": False}


def v1_gate() -> Dict[str, Any]:
    st = readiness_status(); assets = asset_support_status(); bridge = browser_bridge_status(); tx = transaction_dapp_test()
    checks = {"runtime_version_1_1_4_or_newer": _version_tuple(VERSION) >= _version_tuple("1.1.4"), "clean_debian_supported": True, "aegis_optional": not st["aegis_required"], "master_passphrase_not_stored": not st["master_passphrase_stored"], "crypto_available": st["crypto"]["cryptography"] and st["crypto"]["aesgcm"] and st["crypto"]["secp256k1"] and st["crypto"]["ed25519"], "crypto_only_no_cards": st["wallet_type"] == "crypto_only" and not st["card_features"]["card_features_enabled"], "top_assets_declared": all(x in assets["supported_coins"] for x in ["BTC", "ETH", "BNB", "XRP", "SOL", "USDT", "USDC"]), "multiple_wallets_generation": assets["generate_wallet_supported"] and assets["multiple_wallets_allowed"], "recovery_import_declared": GUI_ADD_WALLET_RECOVERY_ENABLED and set(RECOVERY_WORD_COUNTS) == {12, 24}, "dapp_login_enabled": DAPP_LOGIN_ENABLED is True, "transaction_signing_enabled": TRANSACTION_SIGNING_ENABLED is True, "wallet_broadcast_disabled": not BROADCAST_ENABLED and not NETWORK_ACCESS_ENABLED, "transaction_dapp_test_pass": tx.get("ok") is True, "delete_wallet_gui_enabled": GUI_DELETE_WALLET_ENABLED is True, "delete_wallet_confirmation_required": GUI_DELETE_WALLET_REQUIRES_TYPED_CONFIRMATION is True, "nft_foundation_present": st["nft"]["nft_support_enabled"] and st["nft"]["nft_inventory_supported"], "browser_bridge_no_secret_storage": bridge["contract"]["browser_may_receive_secrets"] is False, "request_response_supported": bridge["request_response_supported"], "readiness_status_v1_ready": st.get("v1_ready") is True}
    return {"schema": "sentinel.wallet.v1_readiness_gate.v1_0_2", "app": APP, "version": VERSION, "ok": all(checks.values()), "v1_ready": all(checks.values()), "v1_scope": "transaction_dapp_login_wallet_delete_walletconnect_multichain_foundation", "checks": checks, "locked_scope": v1_locked_scope(), "deferred_scope": v1_deferred_scope(), "transaction_dapp_test": tx, "next_required_phases": ["mainnet field test with tiny test amount", "full audited WalletConnect relay client and broad dApp compatibility matrix", "hardware-backed key storage", "external security audit before serious funds"]}


def stable_lock_report() -> Dict[str, Any]:
    gate = v1_gate()
    return {"schema": "sentinel.wallet.stable_lock_report.v1_0_2", "app": APP, "package": PACKAGE, "program": PROGRAM, "version": VERSION, "stable_locked": gate.get("ok") is True, "stable_lock_name": "Sentinel Wallet v1.1.4 dApp Approval Popup Compatibility Hotfix", "doctrine": "local-first crypto-only wallet; no cards; no browser-stored secrets; user-approved app-login and transaction signing; wallet-owned network broadcast disabled", "gate": gate, "locked_scope": v1_locked_scope(), "deferred_scope": v1_deferred_scope(), "field_test_required": ["open GUI on SentinelOS/MATE", "generate/import test wallets", "sign an ETH/BNB SIWE/login message", "sign an ETH/BNB tiny test transaction payload", "sign a SOL raw test payload", "confirm Browser never receives wallet password/seed/private key", "confirm dApp/browser only receives public address/signature/signed transaction payload", "confirm Wallets tab Delete Wallet removes only the selected local encrypted wallet record after typed DELETE confirmation"], "audit_note": TRANSACTION_SIGNING_AUDIT_NOTE}


# v1.0.2 override: include Wallets-tab Delete Wallet gate while preserving v1.0.1 transaction/dApp scope.
def self_test() -> Dict[str, Any]:
    ensure_dirs(); init_db(); c = _crypto_import_status(); tx = transaction_dapp_test(); delete_gate = wallet_delete_feature_test()
    checks = {
        "dirs_exist": all(d.exists() for d in (DATA_DIR, CONFIG_DIR, STATE_DIR, BRIDGE_DIR, REQUESTS_DIR, RESPONSES_DIR, WALLETCONNECT_DIR)),
        "db_exists": DB.exists(),
        "runtime_version_1_1_4_or_newer": _version_tuple(VERSION) >= _version_tuple("1.1.4"),
        "master_passphrase_not_stored": True,
        "crypto_only_no_cards": CRYPTO_ONLY and not CARD_FEATURES_ENABLED,
        "transaction_dapp_gate": tx.get("ok") is True,
        "delete_wallet_feature_gate": delete_gate.get("ok") is True,
        "walletconnect_gate": walletconnect_test().get("ok") is True,
        "walletconnect_approval_prompt_gate": walletconnect_approval_prompt_test().get("ok") is True,
        "crypto_imports": c["cryptography"] and c["aesgcm"] and c["secp256k1"] and c["ed25519"],
        "browser_bridge_no_secrets": browser_bridge_contract().get("browser_may_receive_secrets") is False,
        "wallet_owned_broadcast_disabled": not WALLET_OWNED_NETWORK_BROADCAST_ENABLED and not NETWORK_ACCESS_ENABLED,
    }
    if checks["crypto_imports"]:
        phrase = "sentinel-wallet-self-test-" + secrets.token_hex(8); blob = b"wallet-self-test-secret"; checks["encrypt_decrypt_roundtrip"] = decrypt_blob(phrase, encrypt_blob(phrase, blob)) == blob
    else:
        checks["encrypt_decrypt_roundtrip"] = False
    return {"ok": all(bool(v) for v in checks.values()), "schema": "sentinel.wallet.self_test.v1_1_2", "app": APP, "version": VERSION, "checks": checks, "crypto": c, "transaction_dapp_test": tx, "delete_wallet_feature_test": delete_gate, "walletconnect_test": walletconnect_test()}


def main(argv: Optional[List[str]] = None) -> int:
    argv = list(argv or os.sys.argv[1:])
    if "--transaction-dapp-status" in argv:
        print(json.dumps(transaction_dapp_status(), indent=2, sort_keys=True)); return 0
    if "--transaction-dapp-test" in argv:
        obj = transaction_dapp_test(); print(json.dumps(obj, indent=2, sort_keys=True)); return 0 if obj.get("ok") else 1
    if "--sign-dapp-login" in argv:
        mini = argparse.ArgumentParser(prog="sentinel-wallet --sign-dapp-login")
        mini.add_argument("--sign-dapp-login", action="store_true"); mini.add_argument("--wallet-uid", required=True); mini.add_argument("--message", required=True); mini.add_argument("--browser-origin", default=""); mini.add_argument("--passphrase-env", default="SENTINEL_WALLET_PASSPHRASE")
        m = mini.parse_args(argv)
        try:
            pp = _passphrase_from_cli(m.passphrase_env)
            print(json.dumps(sign_dapp_login_message(m.wallet_uid, pp, m.message, m.browser_origin), indent=2, sort_keys=True)); return 0
        except Exception as exc:
            print(json.dumps({"ok": False, "schema": "sentinel.wallet.dapp_login_signature_error.v1_0_1", "error": type(exc).__name__, "message": str(exc)}, indent=2, sort_keys=True)); return 1
    if "--sign-transaction" in argv:
        mini = argparse.ArgumentParser(prog="sentinel-wallet --sign-transaction")
        mini.add_argument("--sign-transaction", action="store_true"); mini.add_argument("--wallet-uid", required=True); mini.add_argument("--transaction-json", default=""); mini.add_argument("--transaction-json-env", default="SENTINEL_WALLET_TRANSACTION_JSON"); mini.add_argument("--browser-origin", default=""); mini.add_argument("--passphrase-env", default="SENTINEL_WALLET_PASSPHRASE")
        m = mini.parse_args(argv)
        try:
            pp = _passphrase_from_cli(m.passphrase_env)
            txj = m.transaction_json or os.environ.get(m.transaction_json_env, "")
            print(json.dumps(sign_transaction_payload(m.wallet_uid, pp, txj, m.browser_origin), indent=2, sort_keys=True)); return 0
        except Exception as exc:
            print(json.dumps({"ok": False, "schema": "sentinel.wallet.transaction_signature_error.v1_0_1", "error": type(exc).__name__, "message": str(exc)}, indent=2, sort_keys=True)); return 1
    if "--delete-wallet" in argv:
        mini = argparse.ArgumentParser(prog="sentinel-wallet --delete-wallet")
        mini.add_argument("--delete-wallet", action="store_true"); mini.add_argument("--wallet-uid", required=True); mini.add_argument("--confirm-delete-wallet", default="")
        m = mini.parse_args(argv)
        try:
            print(json.dumps(delete_wallet_record(m.wallet_uid, m.confirm_delete_wallet), indent=2, sort_keys=True)); return 0
        except Exception as exc:
            print(json.dumps({"ok": False, "schema": "sentinel.wallet.delete_wallet_error.v1_0_2", "error": type(exc).__name__, "message": str(exc)}, indent=2, sort_keys=True)); return 1
    if "--wallet-delete-feature-test" in argv:
        obj = wallet_delete_feature_test(); print(json.dumps(obj, indent=2, sort_keys=True)); return 0 if obj.get("ok") else 1
    if "--wallet-icon-status" in argv:
        print(json.dumps(wallet_icon_status(), indent=2, sort_keys=True)); return 0
    if "--native-provider-status" in argv:
        print(json.dumps(native_provider_core_status(), indent=2, sort_keys=True)); return 0
    if "--native-provider-core-test" in argv or "--native-provider-test" in argv:
        obj = native_provider_core_test(); print(json.dumps(obj, indent=2, sort_keys=True)); return 0 if obj.get("ok") else 1
    if "--solana-provider-status" in argv:
        print(json.dumps(solana_provider_status(), indent=2, sort_keys=True)); return 0
    if "--solana-provider-test" in argv:
        obj = solana_provider_test(); print(json.dumps(obj, indent=2, sort_keys=True)); return 0 if obj.get("ok") else 1
    if "--walletconnect-status" in argv:
        print(json.dumps(walletconnect_status(), indent=2, sort_keys=True)); return 0
    if "--walletconnect-test" in argv:
        obj = walletconnect_test(); print(json.dumps(obj, indent=2, sort_keys=True)); return 0 if obj.get("ok") else 1
    if "--walletconnect-approval-prompt-test" in argv:
        obj = walletconnect_approval_prompt_test(); print(json.dumps(obj, indent=2, sort_keys=True)); return 0 if obj.get("ok") else 1
    if argv and argv[0] == "browser-bridge":
        return handle_browser_bridge(argv[1:])
    p = argparse.ArgumentParser(description=f"{APP} crypto-only wallet")
    p.add_argument("--version", action="store_true"); p.add_argument("--approval-request-id", default=""); p.add_argument("--gui-layout-status", action="store_true"); p.add_argument("--gui-layout-test", action="store_true"); p.add_argument("--wallet-icon-status", action="store_true"); p.add_argument("--native-provider-status", action="store_true"); p.add_argument("--native-provider-core-test", action="store_true"); p.add_argument("--native-provider-test", action="store_true"); p.add_argument("--evm-provider-status", action="store_true"); p.add_argument("--evm-provider-test", action="store_true"); p.add_argument("--solana-provider-status", action="store_true"); p.add_argument("--solana-provider-test", action="store_true"); p.add_argument("--walletconnect-status", action="store_true"); p.add_argument("--walletconnect-test", action="store_true"); p.add_argument("--walletconnect-approval-prompt-test", action="store_true"); p.add_argument("--self-test", action="store_true"); p.add_argument("--wallet-delete-feature-test", action="store_true"); p.add_argument("--delete-wallet", action="store_true"); p.add_argument("--confirm-delete-wallet", default=""); p.add_argument("--stable-lock-report", action="store_true"); p.add_argument("--readiness-status", action="store_true"); p.add_argument("--browser-contract", action="store_true"); p.add_argument("--browser-status", action="store_true"); p.add_argument("--browser-open", action="store_true"); p.add_argument("--browser-origin", default=""); p.add_argument("--v1-readiness-gate", action="store_true"); p.add_argument("--write-aegis-status", action="store_true"); p.add_argument("--init-store", action="store_true"); p.add_argument("--gui", action="store_true"); p.add_argument("--dashboard-status", action="store_true"); p.add_argument("--phase4-wallet-gui-dashboard-test", action="store_true"); p.add_argument("--phase5-wallet-gui-style-recovery-test", action="store_true"); p.add_argument("--phase6-professional-wallet-gui-test", action="store_true"); p.add_argument("--phase7-recovery-nft-signing-gui-test", action="store_true"); p.add_argument("--crypto-status", action="store_true"); p.add_argument("--nft-status", action="store_true"); p.add_argument("--card-feature-status", action="store_true"); p.add_argument("--asset-support-status", action="store_true"); p.add_argument("--chain-support-status", action="store_true"); p.add_argument("--stablecoin-status", action="store_true"); p.add_argument("--list-wallets", action="store_true"); p.add_argument("--generate-wallet", action="store_true"); p.add_argument("--add-wallet-from-phrase", action="store_true"); p.add_argument("--sign-login-message", action="store_true"); p.add_argument("--wallet-uid", default=""); p.add_argument("--message", default=""); p.add_argument("--wallet-name", default=""); p.add_argument("--chain", default="BTC"); p.add_argument("--recovery-words", type=int, default=24, choices=[12, 24]); p.add_argument("--passphrase-env", default="SENTINEL_WALLET_PASSPHRASE"); p.add_argument("--confirm-passphrase-env", default=""); p.add_argument("--recovery-phrase-env", default="SENTINEL_WALLET_RECOVERY_PHRASE"); p.add_argument("--phase1-crypto-only-nft-test", action="store_true"); p.add_argument("--phase2-top-assets-wallet-generation-test", action="store_true"); p.add_argument("--passphrase-escrow-status", action="store_true"); p.add_argument("--export-passphrase-escrow", action="store_true"); p.add_argument("--escrow-target", default="aegis-vault"); p.add_argument("--escrow-label", default=""); p.add_argument("--escrow-passphrase-env", default="SENTINEL_WALLET_ESCROW_PASSPHRASE"); p.add_argument("--escrow-note", default=""); p.add_argument("--phase3-passphrase-escrow-test", action="store_true"); p.add_argument("--banking-status", action="store_true"); p.add_argument("--banking-test", action="store_true"); p.add_argument("--list-banking-accounts", action="store_true"); p.add_argument("--list-banking-receipts", action="store_true"); p.add_argument("--create-banking-account", action="store_true"); p.add_argument("--banking-account-type", default=BANKING_DEFAULT_ACCOUNT_TYPE); p.add_argument("--banking-note", default="")
    a = p.parse_args(argv)
    if a.version: print(f"{APP} {VERSION}"); return 0
    if a.native_provider_status: print(json.dumps(native_provider_core_status(), indent=2, sort_keys=True)); return 0
    if a.native_provider_core_test or a.native_provider_test: obj = native_provider_core_test(); print(json.dumps(obj, indent=2, sort_keys=True)); return 0 if obj.get("ok") else 1
    if a.evm_provider_status: print(json.dumps(evm_provider_status(), indent=2, sort_keys=True)); return 0
    if a.evm_provider_test: obj = evm_provider_test(); print(json.dumps(obj, indent=2, sort_keys=True)); return 0 if obj.get("ok") else 1
    if a.walletconnect_status: print(json.dumps(walletconnect_status(), indent=2, sort_keys=True)); return 0
    if a.walletconnect_test: obj = walletconnect_test(); print(json.dumps(obj, indent=2, sort_keys=True)); return 0 if obj.get("ok") else 1
    if a.walletconnect_approval_prompt_test: obj = walletconnect_approval_prompt_test(); print(json.dumps(obj, indent=2, sort_keys=True)); return 0 if obj.get("ok") else 1
    if a.self_test: obj = self_test(); print(json.dumps(obj, indent=2, sort_keys=True)); return 0 if obj["ok"] else 1
    if a.stable_lock_report: obj = stable_lock_report(); print(json.dumps(obj, indent=2, sort_keys=True)); return 0 if obj.get("stable_locked") else 1
    if a.readiness_status: print(json.dumps(readiness_status(), indent=2, sort_keys=True)); return 0
    if a.dashboard_status: print(json.dumps(wallet_dashboard_status(), indent=2, sort_keys=True)); return 0
    if a.gui_layout_status: print(json.dumps(gui_layout_status(), indent=2, sort_keys=True)); return 0
    if a.gui_layout_test:
        obj = gui_layout_test(); print(json.dumps(obj, indent=2, sort_keys=True)); return 0 if obj.get("ok") else 1
    if a.banking_status: print(json.dumps(banking_status(), indent=2, sort_keys=True)); return 0
    if a.banking_test:
        obj = banking_foundation_test(); print(json.dumps(obj, indent=2, sort_keys=True)); return 0 if obj.get("ok") else 1
    if a.list_banking_accounts: print(json.dumps(list_banking_accounts(), indent=2, sort_keys=True)); return 0
    if a.list_banking_receipts: print(json.dumps(list_banking_receipts(), indent=2, sort_keys=True)); return 0
    if a.create_banking_account:
        try:
            pp = _passphrase_from_cli(a.passphrase_env)
            confirm = os.environ.get(a.confirm_passphrase_env, "") if a.confirm_passphrase_env else pp
            print(json.dumps(create_banking_account(a.wallet_name or f"{a.chain.upper()} Sentinel Savings", a.chain, pp, account_type=a.banking_account_type, recovery_word_count=a.recovery_words, confirm_passphrase=confirm, notes=a.banking_note), indent=2, sort_keys=True)); return 0
        except Exception as exc:
            print(json.dumps({"ok": False, "schema": "sentinel.wallet.banking_error.v1_1_12", "error": type(exc).__name__, "message": str(exc)}, indent=2, sort_keys=True)); return 1
    if a.phase4_wallet_gui_dashboard_test:
        obj = phase4_wallet_gui_dashboard_test(); print(json.dumps(obj, indent=2, sort_keys=True)); return 0 if obj.get("ok") else 1
    if a.phase5_wallet_gui_style_recovery_test:
        obj = phase5_wallet_gui_style_recovery_test(); print(json.dumps(obj, indent=2, sort_keys=True)); return 0 if obj.get("ok") else 1
    if a.phase6_professional_wallet_gui_test:
        obj = phase6_professional_wallet_gui_test(); print(json.dumps(obj, indent=2, sort_keys=True)); return 0 if obj.get("ok") else 1
    if a.phase7_recovery_nft_signing_gui_test:
        obj = phase7_wallet_recovery_nft_signing_gui_test(); print(json.dumps(obj, indent=2, sort_keys=True)); return 0 if obj.get("ok") else 1
    if a.crypto_status: print(json.dumps(crypto_wallet_status(), indent=2, sort_keys=True)); return 0
    if a.nft_status: print(json.dumps(nft_status(), indent=2, sort_keys=True)); return 0
    if a.card_feature_status: print(json.dumps(card_feature_status(), indent=2, sort_keys=True)); return 0
    if a.asset_support_status: print(json.dumps(asset_support_status(), indent=2, sort_keys=True)); return 0
    if a.chain_support_status: print(json.dumps(chain_support_status(), indent=2, sort_keys=True)); return 0
    if a.stablecoin_status: print(json.dumps(stablecoin_status(), indent=2, sort_keys=True)); return 0
    if a.list_wallets: print(json.dumps(list_wallets(), indent=2, sort_keys=True)); return 0
    if a.wallet_delete_feature_test:
        obj = wallet_delete_feature_test(); print(json.dumps(obj, indent=2, sort_keys=True)); return 0 if obj.get("ok") else 1
    if a.delete_wallet:
        try:
            print(json.dumps(delete_wallet_record(a.wallet_uid, a.confirm_delete_wallet), indent=2, sort_keys=True)); return 0
        except Exception as exc:
            print(json.dumps({"ok": False, "schema": "sentinel.wallet.delete_wallet_error.v1_0_2", "error": type(exc).__name__, "message": str(exc)}, indent=2, sort_keys=True)); return 1

    if a.passphrase_escrow_status: print(json.dumps(passphrase_escrow_status(), indent=2, sort_keys=True)); return 0
    if a.export_passphrase_escrow:
        try:
            phrase = _passphrase_from_cli(a.passphrase_env)
            escrow_phrase = os.environ.get(a.escrow_passphrase_env, "") or _escrow_key_phrase(a.escrow_passphrase_env)
            obj = export_passphrase_escrow(a.escrow_label or a.wallet_name or "Sentinel Wallet", a.chain, phrase, target=a.escrow_target, escrow_phrase=escrow_phrase, note=a.escrow_note)
            print(json.dumps(obj, indent=2, sort_keys=True)); return 0 if obj.get("ok") else 1
        except Exception as exc:
            print(json.dumps({"ok": False, "schema": "sentinel.wallet.passphrase_escrow_error.v1_0_0", "error": type(exc).__name__, "message": str(exc)}, indent=2, sort_keys=True)); return 1
    if a.phase3_passphrase_escrow_test:
        obj = phase3_passphrase_escrow_test(); print(json.dumps(obj, indent=2, sort_keys=True)); return 0 if obj["ok"] else 1
    if a.generate_wallet:
        try:
            phrase = _passphrase_from_cli(a.passphrase_env)
            confirm = os.environ.get(a.confirm_passphrase_env, "") if a.confirm_passphrase_env else ""
            print(json.dumps(generate_wallet_record(a.wallet_name or f"{a.chain.upper()} Wallet", a.chain, phrase, persist=True, recovery_word_count=a.recovery_words, confirm_passphrase=confirm), indent=2, sort_keys=True)); return 0
        except Exception as exc:
            print(json.dumps({"ok": False, "schema": "sentinel.wallet.generate_wallet_error.v1_0_0", "error": type(exc).__name__, "message": str(exc)}, indent=2, sort_keys=True)); return 1
    if a.add_wallet_from_phrase:
        try:
            phrase = os.environ.get(a.recovery_phrase_env, "")
            if not phrase and os.isatty(0):
                phrase = getpass.getpass("Recovery phrase: ")
            pp = _passphrase_from_cli(a.passphrase_env)
            confirm = os.environ.get(a.confirm_passphrase_env, "") if a.confirm_passphrase_env else pp
            print(json.dumps(import_wallet_from_recovery_phrase(a.wallet_name or f"Recovered {a.chain.upper()} Wallet", a.chain, phrase, pp, persist=True, confirm_passphrase=confirm), indent=2, sort_keys=True)); return 0
        except Exception as exc:
            print(json.dumps({"ok": False, "schema": "sentinel.wallet.import_wallet_error.v1_0_0", "error": type(exc).__name__, "message": str(exc)}, indent=2, sort_keys=True)); return 1
    if a.sign_login_message:
        try:
            pp = _passphrase_from_cli(a.passphrase_env)
            print(json.dumps(sign_login_message(a.wallet_uid, pp, a.message, a.browser_origin), indent=2, sort_keys=True)); return 0
        except Exception as exc:
            print(json.dumps({"ok": False, "schema": "sentinel.wallet.login_message_signature_error.v1_0_0", "error": type(exc).__name__, "message": str(exc)}, indent=2, sort_keys=True)); return 1
    if a.phase1_crypto_only_nft_test or a.phase2_top_assets_wallet_generation_test:
        obj = phase2_top_assets_wallet_generation_test(); print(json.dumps(obj, indent=2, sort_keys=True)); return 0 if obj["ok"] else 1
    if a.browser_contract: print(json.dumps(browser_contract(), indent=2, sort_keys=True)); return 0
    if a.browser_status: print(json.dumps(browser_status(), indent=2, sort_keys=True)); return 0
    if a.browser_open: gui(a.browser_origin, a.approval_request_id); return 0
    if a.v1_readiness_gate: obj = v1_gate(); print(json.dumps(obj, indent=2, sort_keys=True)); return 0 if obj["ok"] else 1
    if a.write_aegis_status: print(json.dumps(write_aegis_status(), indent=2, sort_keys=True)); return 0
    if a.init_store: init_db(); print(json.dumps({"ok": True, "store": str(DB)}, indent=2)); return 0
    if a.gui: gui(a.browser_origin, a.approval_request_id); return 0
    print(json.dumps(readiness_status(), indent=2, sort_keys=True)); return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except SystemExit:
        raise
    except Exception as exc:
        print(json.dumps({"ok": False, "schema": "sentinel.wallet.cli_error.v1_1_14", "error": type(exc).__name__, "message": str(exc)}, indent=2, sort_keys=True))
        raise SystemExit(1)
