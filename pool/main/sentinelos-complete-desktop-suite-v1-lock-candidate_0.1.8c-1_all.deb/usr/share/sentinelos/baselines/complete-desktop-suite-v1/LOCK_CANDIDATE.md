# SentinelOS Complete Desktop Suite v1 Lock Candidate

This package records the v0.1.8c complete Desktop Suite v1 lock candidate. Future v1 updates remain explicit-integration-pass-only.
