SentinelOS v0.1.7b suite integration classifier.
