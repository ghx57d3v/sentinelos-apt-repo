#!/usr/bin/env python3
"""
Sentinel Calendar v1.0.1
Program 104 in the SentinelOS Desktop Suite.

Local-only desktop calendar for appointments, family schedules, AEGIS-readable
agenda data, reminders, recurring events, completed v0.7.0 ICS safety, and Sentinel Suite integration hooks.
"""
from __future__ import annotations

import argparse
import calendar as pycalendar
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import textwrap
import time as time_module
import uuid
from dataclasses import dataclass, asdict, field
from datetime import date, datetime, time, timedelta, timezone
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

try:
    import tkinter as tk
    from tkinter import filedialog, messagebox, simpledialog, ttk
except Exception:  # pragma: no cover
    tk = None
    filedialog = messagebox = simpledialog = ttk = None

APP_NAME = "Sentinel Calendar"
APP_ID = "sentinel-calendar"
PROGRAM_NUMBER = "104"
VERSION = "1.0.1"
ORG_NAME = "SentinelOS / AEGIS"

THEME = {
    "bg": "#101214",
    "panel": "#171A1D",
    "panel2": "#1F2327",
    "text": "#F3E7C9",
    "muted": "#B8A77D",
    "gold": "#E19B00",
    "gold2": "#B87500",
    "cyan": "#03C8FF",
    "danger": "#C85A54",
    "ok": "#6DBB75",
    "border": "#3D3422",
}

CATEGORY_CHOICES = [
    "General",
    "Family",
    "Work",
    "Repair",
    "Project",
    "AEGIS",
    "SentinelOS",
    "Birthday",
    "Appointment",
    "Bill",
    "Reminder",
    "School",
    "Health",
    "Vehicle",
]

RECURRENCE_CHOICES = ["None", "Daily", "Weekly", "Monthly", "Yearly"]
REMINDER_CHOICES = ["0", "5", "10", "15", "30", "60", "120", "1440"]
FIRST_DAY_CHOICES = ["Monday", "Sunday"]
STARTUP_VIEW_CHOICES = ["Month", "Week", "Agenda", "Today"]
BACKUP_KEEP_MIN = 5
BACKUP_KEEP_MAX = 500

TIME_RE = re.compile(r"^([01]?\d|2[0-3]):([0-5]\d)$")
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")

DATE_FORMAT_CHOICES = ["DD/MM/YYYY", "YYYY-MM-DD", "MM/DD/YYYY"]
DATE_FORMAT_PATTERNS = {
    "DD/MM/YYYY": "%d/%m/%Y",
    "YYYY-MM-DD": "%Y-%m-%d",
    "MM/DD/YYYY": "%m/%d/%Y",
}
HOLIDAY_COUNTRY_CHOICES = ["Australia", "United States", "United Kingdom", "Canada", "New Zealand", "Disabled"]
AU_REGION_CHOICES = ["National", "ACT", "NSW", "NT", "QLD", "SA", "TAS", "VIC", "WA"]
DEFAULT_SETTINGS = {
    "date_format": "DD/MM/YYYY",
    "show_public_holidays": True,
    "holiday_country": "Australia",
    "holiday_region": "National",
    "first_day_of_week": "Monday",
    "default_category": "General",
    "default_reminder_minutes": 0,
    "startup_view": "Month",
    "confirm_delete": True,
    "backup_keep": 50,
    "notifications_enabled": True,
    "notification_sound": False,
    "default_snooze_minutes": 10,
}

FILTER_CATEGORY_ALL = "All Categories"
FILTER_CATEGORY_PUBLIC_HOLIDAY = "Public Holiday"
FILTER_CATEGORY_CHOICES = [FILTER_CATEGORY_ALL] + CATEGORY_CHOICES + [FILTER_CATEGORY_PUBLIC_HOLIDAY]
ITEM_TYPE_CHOICES = ["all", "user", "holidays", "recurring"]
DEFAULT_AGENDA_DAYS = 30
DEFAULT_SEARCH_SCAN_DAYS = 730

VERSION_LEDGER = [
    {"version": "0.6.0", "layer": "navigation_search_filters", "included": True},
    {"version": "0.6.1", "layer": "themed_dropdowns", "included": True},
    {"version": "0.7.0", "layer": "ics_import_export_hardening", "included": True, "backfill_note": "Completed in v1.0.1 as the explicit missing-update backfill."},
    {"version": "0.8.0", "layer": "sentinel_suite_integration", "included": True},
    {"version": "0.8.1", "layer": "reminder_daemon_notifications", "included": True},
    {"version": "0.8.2", "layer": "recurrence_controls", "included": True},
    {"version": "0.8.3", "layer": "settings_preferences_lock", "included": True},
    {"version": "0.8.4", "layer": "ics_safety_backfill", "included": True},
    {"version": "0.9.0", "layer": "release_candidate_checks", "included": True},
    {"version": "1.0.0", "layer": "stable_lock", "included": True},
    {"version": "1.0.1", "layer": "missing_update_closure", "included": True},
]

RRULE_FREQ_TO_RECURRENCE = {
    "DAILY": "Daily",
    "WEEKLY": "Weekly",
    "MONTHLY": "Monthly",
    "YEARLY": "Yearly",
}
RECURRENCE_TO_RRULE_FREQ = {value: key for key, value in RRULE_FREQ_TO_RECURRENCE.items()}


def app_data_dir() -> Path:
    override = os.environ.get("SENTINEL_CALENDAR_HOME")
    if override:
        return Path(override).expanduser()
    xdg = os.environ.get("XDG_DATA_HOME")
    base = Path(xdg).expanduser() if xdg else Path.home() / ".local" / "share"
    return base / "sentinel_calendar"


def config_dir() -> Path:
    xdg = os.environ.get("XDG_CONFIG_HOME")
    base = Path(xdg).expanduser() if xdg else Path.home() / ".config"
    return base / "sentinel_calendar"


def settings_path() -> Path:
    return config_dir() / "settings.json"


def events_path() -> Path:
    return app_data_dir() / "events.json"


def reminder_state_path() -> Path:
    return app_data_dir() / "reminder_state.json"


def load_settings() -> Dict[str, object]:
    ensure_dirs()
    settings = dict(DEFAULT_SETTINGS)
    path = settings_path()
    if path.exists():
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(raw, dict):
                settings.update({k: raw[k] for k in DEFAULT_SETTINGS if k in raw})
        except Exception:
            pass
    if settings.get("date_format") not in DATE_FORMAT_CHOICES:
        settings["date_format"] = DEFAULT_SETTINGS["date_format"]
    if settings.get("holiday_country") not in HOLIDAY_COUNTRY_CHOICES:
        settings["holiday_country"] = DEFAULT_SETTINGS["holiday_country"]
    if settings.get("holiday_region") not in AU_REGION_CHOICES:
        settings["holiday_region"] = DEFAULT_SETTINGS["holiday_region"]
    settings["show_public_holidays"] = bool(settings.get("show_public_holidays", True))
    if settings.get("first_day_of_week") not in FIRST_DAY_CHOICES:
        settings["first_day_of_week"] = DEFAULT_SETTINGS["first_day_of_week"]
    if settings.get("default_category") not in CATEGORY_CHOICES:
        settings["default_category"] = DEFAULT_SETTINGS["default_category"]
    try:
        settings["default_reminder_minutes"] = max(0, int(settings.get("default_reminder_minutes", 0)))
    except Exception:
        settings["default_reminder_minutes"] = DEFAULT_SETTINGS["default_reminder_minutes"]
    if settings.get("startup_view") not in STARTUP_VIEW_CHOICES:
        settings["startup_view"] = DEFAULT_SETTINGS["startup_view"]
    settings["confirm_delete"] = bool(settings.get("confirm_delete", True))
    settings["notifications_enabled"] = bool(settings.get("notifications_enabled", True))
    settings["notification_sound"] = bool(settings.get("notification_sound", False))
    try:
        settings["backup_keep"] = min(BACKUP_KEEP_MAX, max(BACKUP_KEEP_MIN, int(settings.get("backup_keep", 50))))
    except Exception:
        settings["backup_keep"] = DEFAULT_SETTINGS["backup_keep"]
    try:
        settings["default_snooze_minutes"] = max(1, int(settings.get("default_snooze_minutes", 10)))
    except Exception:
        settings["default_snooze_minutes"] = DEFAULT_SETTINGS["default_snooze_minutes"]
    return settings


def save_settings(settings: Dict[str, object]) -> None:
    ensure_dirs()
    clean = dict(DEFAULT_SETTINGS)
    clean.update(settings or {})
    if clean.get("date_format") not in DATE_FORMAT_CHOICES:
        clean["date_format"] = DEFAULT_SETTINGS["date_format"]
    if clean.get("holiday_country") not in HOLIDAY_COUNTRY_CHOICES:
        clean["holiday_country"] = DEFAULT_SETTINGS["holiday_country"]
    if clean.get("holiday_region") not in AU_REGION_CHOICES:
        clean["holiday_region"] = DEFAULT_SETTINGS["holiday_region"]
    clean["show_public_holidays"] = bool(clean.get("show_public_holidays", True))
    if clean.get("first_day_of_week") not in FIRST_DAY_CHOICES:
        clean["first_day_of_week"] = DEFAULT_SETTINGS["first_day_of_week"]
    if clean.get("default_category") not in CATEGORY_CHOICES:
        clean["default_category"] = DEFAULT_SETTINGS["default_category"]
    if clean.get("startup_view") not in STARTUP_VIEW_CHOICES:
        clean["startup_view"] = DEFAULT_SETTINGS["startup_view"]
    clean["confirm_delete"] = bool(clean.get("confirm_delete", True))
    clean["notifications_enabled"] = bool(clean.get("notifications_enabled", True))
    clean["notification_sound"] = bool(clean.get("notification_sound", False))
    for key, default, low, high in [("default_reminder_minutes", 0, 0, 10080), ("backup_keep", 50, BACKUP_KEEP_MIN, BACKUP_KEEP_MAX), ("default_snooze_minutes", 10, 1, 1440)]:
        try:
            clean[key] = min(high, max(low, int(clean.get(key, default))))
        except Exception:
            clean[key] = default
    settings_path().write_text(json.dumps(clean, indent=2, ensure_ascii=False), encoding="utf-8")


def ensure_dirs() -> None:
    app_data_dir().mkdir(parents=True, exist_ok=True)
    (app_data_dir() / "backups").mkdir(parents=True, exist_ok=True)
    config_dir().mkdir(parents=True, exist_ok=True)


def date_format_pattern(settings: Optional[Dict[str, object]] = None) -> str:
    fmt = str((settings or load_settings()).get("date_format", DEFAULT_SETTINGS["date_format"]))
    return DATE_FORMAT_PATTERNS.get(fmt, DATE_FORMAT_PATTERNS[DEFAULT_SETTINGS["date_format"]])


def date_format_label(settings: Optional[Dict[str, object]] = None) -> str:
    fmt = str((settings or load_settings()).get("date_format", DEFAULT_SETTINGS["date_format"]))
    return fmt if fmt in DATE_FORMAT_CHOICES else DEFAULT_SETTINGS["date_format"]


def parse_date(value: str) -> date:
    """Parse a user-facing date into a date object.

    Internal storage stays ISO YYYY-MM-DD, but users may type dates using the
    selected app format. Slash dates default to Australian DD/MM/YYYY order.
    """
    value = (value or "").strip()
    if not value:
        raise ValueError(f"Invalid date '{value}'. Use {DEFAULT_SETTINGS['date_format']}.")
    patterns = [
        "%Y-%m-%d",
        "%d/%m/%Y",
        "%d-%m-%Y",
        "%m/%d/%Y",
    ]
    # If the user has selected US-style output, prefer MM/DD/YYYY for slash dates.
    try:
        selected = date_format_pattern(load_settings())
        if selected in patterns:
            patterns.remove(selected)
            patterns.insert(0, selected)
    except Exception:
        pass
    last_exc: Optional[Exception] = None
    for pattern in patterns:
        try:
            return datetime.strptime(value, pattern).date()
        except ValueError as exc:
            last_exc = exc
    hint = date_format_label()
    raise ValueError(f"Invalid date '{value}'. Use {hint}; ISO YYYY-MM-DD is also accepted.") from last_exc


def to_iso_date(value: str) -> str:
    return parse_date(value).isoformat()


def format_date(value: str | date, settings: Optional[Dict[str, object]] = None) -> str:
    day = parse_date(value) if isinstance(value, str) else value
    return day.strftime(date_format_pattern(settings))


def clean_time(value: str) -> str:
    value = (value or "").strip()
    if not value:
        return ""
    match = TIME_RE.match(value)
    if not match:
        raise ValueError(f"Invalid time '{value}'. Use 24-hour HH:MM.")
    return f"{int(match.group(1)):02d}:{match.group(2)}"


def clean_recurrence(value: str) -> str:
    value = (value or "None").strip().capitalize()
    if value.lower() in {"", "no", "none", "off"}:
        return "None"
    mapping = {item.lower(): item for item in RECURRENCE_CHOICES}
    if value.lower() not in mapping:
        raise ValueError(f"Invalid recurrence '{value}'. Use one of: {', '.join(RECURRENCE_CHOICES)}.")
    return mapping[value.lower()]


def clean_reminder(value: str | int) -> int:
    if value is None or value == "":
        return 0
    try:
        minutes = int(value)
    except Exception as exc:
        raise ValueError("Reminder must be a whole number of minutes before the event.") from exc
    if minutes < 0:
        raise ValueError("Reminder minutes cannot be negative.")
    return minutes


def now_iso() -> str:
    return datetime.now().replace(microsecond=0).isoformat()


def combine_event_datetime(day: date, clock: str) -> datetime:
    if clock:
        hh, mm = [int(part) for part in clock.split(":", 1)]
        return datetime.combine(day, time(hour=hh, minute=mm))
    # All-day reminders default to 09:00 local time.
    return datetime.combine(day, time(hour=9, minute=0))


@dataclass
class Event:
    id: str
    title: str
    start_date: str
    start_time: str = ""
    end_date: str = ""
    end_time: str = ""
    location: str = ""
    category: str = "General"
    notes: str = ""
    reminder_minutes: int = 0
    recurrence: str = "None"
    recurrence_until: str = ""
    recurrence_exdates: List[str] = field(default_factory=list)
    source_uid: str = ""
    created_at: str = ""
    updated_at: str = ""

    @staticmethod
    def create(
        title: str,
        start_date: str,
        start_time: str = "",
        end_date: str = "",
        end_time: str = "",
        location: str = "",
        category: str = "General",
        notes: str = "",
        reminder_minutes: str | int = 0,
        recurrence: str = "None",
        recurrence_until: str = "",
        recurrence_exdates: Optional[Sequence[str]] = None,
        source_uid: str = "",
    ) -> "Event":
        title = (title or "").strip()
        if not title:
            raise ValueError("Event title is required.")
        start_obj = parse_date(start_date)
        start_date = start_obj.isoformat()
        start_time = clean_time(start_time)
        end_date = (end_date or "").strip()
        if end_date:
            end_date = parse_date(end_date).isoformat()
        end_time = clean_time(end_time)
        recurrence = clean_recurrence(recurrence)
        recurrence_until = (recurrence_until or "").strip()
        if recurrence_until:
            until = parse_date(recurrence_until)
            if until < start_obj:
                raise ValueError("Recurrence-until date cannot be before the start date.")
            recurrence_until = until.isoformat()
        clean_exdates: List[str] = []
        for item in recurrence_exdates or []:
            try:
                clean_exdates.append(parse_date(str(item)).isoformat())
            except Exception:
                pass
        clean_exdates = sorted(set(clean_exdates))
        reminder_minutes = clean_reminder(reminder_minutes)
        stamp = now_iso()
        return Event(
            id=str(uuid.uuid4()),
            title=title,
            start_date=start_date,
            start_time=start_time,
            end_date=end_date,
            end_time=end_time,
            location=(location or "").strip(),
            category=(category or "General").strip() or "General",
            notes=(notes or "").strip(),
            reminder_minutes=reminder_minutes,
            recurrence=recurrence,
            recurrence_until=recurrence_until,
            recurrence_exdates=clean_exdates,
            source_uid=(source_uid or "").strip(),
            created_at=stamp,
            updated_at=stamp,
        )

    @staticmethod
    def from_dict(raw: Dict[str, object]) -> "Event":
        def s(key: str, default: str = "") -> str:
            return str(raw.get(key, default) or default)

        try:
            reminder = clean_reminder(raw.get("reminder_minutes", 0))
        except Exception:
            reminder = 0
        try:
            recurrence = clean_recurrence(s("recurrence", "None"))
        except Exception:
            recurrence = "None"
        start_raw = s("start_date", date.today().isoformat())
        end_raw = s("end_date")
        until_raw = s("recurrence_until")
        try:
            start_clean = parse_date(start_raw).isoformat()
        except Exception:
            start_clean = date.today().isoformat()
        try:
            end_clean = parse_date(end_raw).isoformat() if end_raw else ""
        except Exception:
            end_clean = ""
        try:
            until_clean = parse_date(until_raw).isoformat() if until_raw else ""
        except Exception:
            until_clean = ""
        exdates_raw = raw.get("recurrence_exdates", [])
        if not isinstance(exdates_raw, list):
            exdates_raw = []
        exdates: List[str] = []
        for item in exdates_raw:
            try:
                exdates.append(parse_date(str(item)).isoformat())
            except Exception:
                pass
        exdates = sorted(set(exdates))
        return Event(
            id=s("id") or str(uuid.uuid4()),
            title=s("title", "Untitled"),
            start_date=start_clean,
            start_time=s("start_time"),
            end_date=end_clean,
            end_time=s("end_time"),
            location=s("location"),
            category=s("category", "General"),
            notes=s("notes"),
            reminder_minutes=reminder,
            recurrence=recurrence,
            recurrence_until=until_clean,
            recurrence_exdates=exdates,
            source_uid=s("source_uid"),
            created_at=s("created_at", now_iso()),
            updated_at=s("updated_at", now_iso()),
        )

    def sort_key(self) -> Tuple[str, str, str]:
        return (self.start_date, self.start_time or "99:99", self.title.lower())

    def display_time(self) -> str:
        if self.start_time and self.end_time:
            return f"{self.start_time}–{self.end_time}"
        if self.start_time:
            return self.start_time
        return "All day"

    def short_line(self, occurrence_date: Optional[str] = None, settings: Optional[Dict[str, object]] = None) -> str:
        prefix = f"{format_date(occurrence_date, settings)}  " if occurrence_date and occurrence_date != self.start_date else ""
        loc = f" @ {self.location}" if self.location else ""
        recur = " ↻" if self.recurrence != "None" else ""
        bell = " ⏰" if self.reminder_minutes else ""
        return f"{prefix}{self.display_time()}  [{self.category}] {self.title}{loc}{recur}{bell}"

    def occurs_on(self, day: date | str) -> bool:
        target = parse_date(day) if isinstance(day, str) else day
        start = parse_date(self.start_date)
        if target < start:
            return False
        if target.isoformat() in set(self.recurrence_exdates or []):
            return False
        if self.recurrence_until and target > parse_date(self.recurrence_until):
            return False
        if self.recurrence == "None":
            return target == start
        if self.recurrence == "Daily":
            return True
        if self.recurrence == "Weekly":
            return (target - start).days % 7 == 0
        if self.recurrence == "Monthly":
            return target.day == start.day
        if self.recurrence == "Yearly":
            return target.month == start.month and target.day == start.day
        return target == start


@dataclass
class Occurrence:
    event: Event
    date: str

    def sort_key(self) -> Tuple[str, str, str]:
        return (self.date, self.event.start_time or "99:99", self.event.title.lower())

    def line(self, include_date: bool = False, settings: Optional[Dict[str, object]] = None) -> str:
        return self.event.short_line(self.date if include_date else None, settings=settings)


@dataclass
class HolidayOccurrence:
    title: str
    date: str
    country: str = "Australia"
    region: str = ""

    def sort_key(self) -> Tuple[str, str, str]:
        return (self.date, "00:00", self.title.lower())

    def line(self, include_date: bool = False, settings: Optional[Dict[str, object]] = None) -> str:
        prefix = f"{format_date(self.date, settings)}  " if include_date else ""
        return f"{prefix}All day  [Public Holiday] {self.title} ★"


CalendarItem = Occurrence | HolidayOccurrence


class CalendarStore:
    def __init__(self, path: Optional[Path] = None) -> None:
        self.path = path or events_path()
        ensure_dirs()
        self.events: List[Event] = []
        self.load()

    def load(self) -> None:
        if not self.path.exists():
            self.events = []
            self.save(backup=False)
            return
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            if isinstance(raw, dict):
                raw_events = raw.get("events", [])
            elif isinstance(raw, list):
                raw_events = raw
            else:
                raw_events = []
            self.events = [Event.from_dict(item) for item in raw_events if isinstance(item, dict)]
            self.events.sort(key=lambda e: e.sort_key())
        except Exception as exc:
            backup = self.path.with_suffix(f".corrupt.{datetime.now().strftime('%Y%m%d_%H%M%S')}.json")
            shutil.copy2(self.path, backup)
            self.events = []
            self.save(backup=False)
            raise RuntimeError(f"Could not read calendar store. Corrupt file backed up to {backup}") from exc

    def cleanup_backups(self, keep: int = 50) -> None:
        backups = sorted((app_data_dir() / "backups").glob("events_*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
        for old in backups[keep:]:
            try:
                old.unlink()
            except Exception:
                pass

    def backup_now(self) -> Path:
        ensure_dirs()
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = app_data_dir() / "backups" / f"events_manual_{stamp}.json"
        if self.path.exists():
            shutil.copy2(self.path, backup_path)
        else:
            backup_path.write_text(json.dumps({"events": []}, indent=2), encoding="utf-8")
        return backup_path

    def save(self, backup: bool = True) -> None:
        ensure_dirs()
        if backup and self.path.exists():
            stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_path = app_data_dir() / "backups" / f"events_{stamp}.json"
            try:
                shutil.copy2(self.path, backup_path)
            except Exception:
                pass
        payload = {
            "app": APP_NAME,
            "program": PROGRAM_NUMBER,
            "version": VERSION,
            "local_only": True,
            "updated_at": now_iso(),
            "events": [asdict(e) for e in sorted(self.events, key=lambda e: e.sort_key())],
        }
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
        tmp.replace(self.path)
        try:
            keep = int(load_settings().get("backup_keep", 50))
        except Exception:
            keep = 50
        self.cleanup_backups(keep=keep)

    def add(self, event: Event) -> None:
        self.events.append(event)
        self.events.sort(key=lambda e: e.sort_key())
        self.save()

    def update(self, event_id: str, **fields: object) -> Event:
        event = self.get(event_id)
        for key, value in fields.items():
            if hasattr(event, key) and value is not None:
                setattr(event, key, value)
        event.title = event.title.strip() or "Untitled"
        event.start_date = parse_date(event.start_date).isoformat()
        event.start_time = clean_time(event.start_time)
        if event.end_date:
            event.end_date = parse_date(event.end_date).isoformat()
        event.end_time = clean_time(event.end_time)
        event.reminder_minutes = clean_reminder(event.reminder_minutes)
        event.recurrence = clean_recurrence(event.recurrence)
        if event.recurrence_until:
            event.recurrence_until = parse_date(event.recurrence_until).isoformat()
        event.updated_at = now_iso()
        self.events.sort(key=lambda e: e.sort_key())
        self.save()
        return event

    def skip_occurrence(self, event_id: str, occurrence_date: str) -> Event:
        event = self.get(event_id)
        day_s = parse_date(occurrence_date).isoformat()
        if event.recurrence == "None":
            raise ValueError("Only recurring events can skip a single occurrence.")
        if day_s not in event.recurrence_exdates:
            event.recurrence_exdates.append(day_s)
            event.recurrence_exdates = sorted(set(event.recurrence_exdates))
        event.updated_at = now_iso()
        self.save()
        return event

    def restore_occurrence(self, event_id: str, occurrence_date: str) -> Event:
        event = self.get(event_id)
        day_s = parse_date(occurrence_date).isoformat()
        event.recurrence_exdates = [item for item in event.recurrence_exdates if item != day_s]
        event.updated_at = now_iso()
        self.save()
        return event

    def split_occurrence(self, event_id: str, occurrence_date: str, **fields: object) -> Event:
        original = self.get(event_id)
        day_s = parse_date(occurrence_date).isoformat()
        if original.recurrence == "None":
            raise ValueError("Only recurring events can split one occurrence.")
        if not original.occurs_on(day_s):
            raise ValueError("That recurring event does not occur on the requested date.")
        self.skip_occurrence(event_id, day_s)
        new_event = Event.create(
            title=str(fields.get("title") or original.title),
            start_date=str(fields.get("start_date") or day_s),
            start_time=str(fields.get("start_time") if fields.get("start_time") is not None else original.start_time),
            end_date=str(fields.get("end_date") if fields.get("end_date") is not None else ""),
            end_time=str(fields.get("end_time") if fields.get("end_time") is not None else original.end_time),
            location=str(fields.get("location") if fields.get("location") is not None else original.location),
            category=str(fields.get("category") if fields.get("category") is not None else original.category),
            notes=str(fields.get("notes") if fields.get("notes") is not None else original.notes),
            reminder_minutes=fields.get("reminder_minutes") if fields.get("reminder_minutes") is not None else original.reminder_minutes,
            recurrence="None",
            source_uid=f"split:{original.id}:{day_s}",
        )
        self.add(new_event)
        return new_event

    def event_identity(self, event: Event) -> str:
        parts = [event.title.lower().strip(), event.start_date, event.start_time, event.end_date, event.end_time, event.location.lower().strip(), event.category.lower().strip()]
        return hashlib.sha256("|".join(parts).encode("utf-8", errors="ignore")).hexdigest()

    def has_duplicate(self, event: Event) -> bool:
        ident = self.event_identity(event)
        for existing in self.events:
            if event.source_uid and existing.source_uid and event.source_uid == existing.source_uid:
                return True
            if self.event_identity(existing) == ident:
                return True
        return False

    def add_imported(self, event: Event, dedupe: bool = True) -> bool:
        if dedupe and self.has_duplicate(event):
            return False
        self.events.append(event)
        self.events.sort(key=lambda e: e.sort_key())
        self.save()
        return True

    def delete(self, event_id: str) -> None:
        before = len(self.events)
        self.events = [event for event in self.events if event.id != event_id]
        if len(self.events) == before:
            raise KeyError(f"Event not found: {event_id}")
        self.save()

    def get(self, event_id: str) -> Event:
        for event in self.events:
            if event.id == event_id:
                return event
        raise KeyError(f"Event not found: {event_id}")

    def occurrences_on(self, day: date | str) -> List[Occurrence]:
        day_obj = parse_date(day) if isinstance(day, str) else day
        day_s = day_obj.isoformat()
        matches = [Occurrence(event, day_s) for event in self.events if event.occurs_on(day_obj)]
        return sorted(matches, key=lambda occ: occ.sort_key())

    def by_date(self, day: date | str) -> List[Event]:
        return [occ.event for occ in self.occurrences_on(day)]

    def month_dates(self, year: int, month: int) -> Dict[str, int]:
        _, last_day = pycalendar.monthrange(year, month)
        result: Dict[str, int] = {}
        for day_num in range(1, last_day + 1):
            d = date(year, month, day_num)
            count = len(self.occurrences_on(d))
            if count:
                result[d.isoformat()] = count
        return result

    def search(self, term: str) -> List[Occurrence]:
        needle = term.lower().strip()
        matches: List[Occurrence] = []
        for event in self.events:
            hay = "\n".join([
                event.title,
                event.start_date,
                event.start_time,
                event.location,
                event.category,
                event.notes,
                event.recurrence,
                str(event.reminder_minutes),
            ]).lower()
            if not needle or needle in hay:
                matches.append(Occurrence(event, event.start_date))
        return sorted(matches, key=lambda occ: occ.sort_key())

    def upcoming(self, days: int = 14, start: Optional[date] = None) -> List[Occurrence]:
        start_day = start or date.today()
        matches: List[Occurrence] = []
        for offset in range(max(1, days)):
            d = start_day + timedelta(days=offset)
            matches.extend(self.occurrences_on(d))
        return sorted(matches, key=lambda occ: occ.sort_key())

    def reminders_due(self, window_minutes: int = 60, now: Optional[datetime] = None) -> List[Tuple[Occurrence, datetime, datetime]]:
        current = now or datetime.now()
        end = current + timedelta(minutes=window_minutes)
        scan_days = max(2, (window_minutes // 1440) + 3)
        result: List[Tuple[Occurrence, datetime, datetime]] = []
        for occ in self.upcoming(scan_days, start=current.date()):
            event = occ.event
            if not event.reminder_minutes:
                continue
            event_dt = combine_event_datetime(parse_date(occ.date), event.start_time)
            reminder_dt = event_dt - timedelta(minutes=event.reminder_minutes)
            if current <= reminder_dt <= end:
                result.append((occ, event_dt, reminder_dt))
        return sorted(result, key=lambda item: item[2])



# ------------------------- Public holiday support -------------------------

def nth_weekday(year: int, month: int, weekday: int, n: int) -> date:
    """Return the nth weekday in a month. Monday=0."""
    d = date(year, month, 1)
    delta = (weekday - d.weekday()) % 7
    return d + timedelta(days=delta + 7 * (n - 1))


def last_weekday(year: int, month: int, weekday: int) -> date:
    _, last_day = pycalendar.monthrange(year, month)
    d = date(year, month, last_day)
    delta = (d.weekday() - weekday) % 7
    return d - timedelta(days=delta)


def observed_fixed(name: str, actual: date) -> Dict[str, List[str]]:
    """Return actual fixed-date holiday plus a common Mondayised observance."""
    items: Dict[str, List[str]] = {actual.isoformat(): [name]}
    if actual.weekday() == 5:  # Saturday -> Monday
        items.setdefault((actual + timedelta(days=2)).isoformat(), []).append(f"{name} observed")
    elif actual.weekday() == 6:  # Sunday -> Monday
        items.setdefault((actual + timedelta(days=1)).isoformat(), []).append(f"{name} observed")
    return items


def add_holiday(target: Dict[str, List[str]], day: date, title: str) -> None:
    target.setdefault(day.isoformat(), [])
    if title not in target[day.isoformat()]:
        target[day.isoformat()].append(title)


def holiday_state_suffix(region: str) -> str:
    region = (region or "").upper().strip()
    return region if region in {"ACT", "NSW", "NT", "QLD", "SA", "TAS", "VIC", "WA"} else ""


def holiday_display_title(title: str, region: str = "") -> str:
    suffix = holiday_state_suffix(region)
    title = (title or "").strip()
    return f"{title} [{suffix}]" if suffix else title


def add_state_holiday(target: Dict[str, List[str]], day: date, title: str, region: str) -> None:
    """Add a state/territory-specific Australian holiday with an explicit suffix.

    Australia-wide public holidays intentionally have no suffix. State and
    territory-specific holidays carry [ACT], [NSW], [NT], [QLD], [SA], [TAS],
    [VIC], or [WA] in every agenda/list output so a blank suffix clearly means
    Australia-wide.
    """
    add_holiday(target, day, holiday_display_title(title, region))


def holiday_region_from_title(title: str) -> str:
    match = re.search(r"\[(ACT|NSW|NT|QLD|SA|TAS|VIC|WA)\]$", (title or "").strip())
    return match.group(1) if match else ""


def merge_holidays(target: Dict[str, List[str]], source: Dict[str, List[str]]) -> None:
    for day_s, names in source.items():
        for name in names:
            add_holiday(target, parse_date(day_s), name)


def easter_sunday(year: int) -> date:
    """Gregorian Easter Sunday using the Meeus/Jones/Butcher algorithm."""
    a = year % 19
    b = year // 100
    c = year % 100
    d = b // 4
    e = b % 4
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i = c // 4
    k = c % 4
    l = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l) // 451
    month = (h + l - 7 * m + 114) // 31
    day = ((h + l - 7 * m + 114) % 31) + 1
    return date(year, month, day)


def australia_public_holidays(year: int, region: str = "National") -> Dict[str, List[str]]:
    region = (region or "National").upper()
    holidays: Dict[str, List[str]] = {}
    easter = easter_sunday(year)
    for fixed_name, fixed_day in [
        ("New Year's Day", date(year, 1, 1)),
        ("Australia Day", date(year, 1, 26)),
        ("Anzac Day", date(year, 4, 25)),
        ("Christmas Day", date(year, 12, 25)),
        ("Boxing Day", date(year, 12, 26)),
    ]:
        merge_holidays(holidays, observed_fixed(fixed_name, fixed_day))
    add_holiday(holidays, easter - timedelta(days=2), "Good Friday")
    add_holiday(holidays, easter - timedelta(days=1), "Easter Saturday")
    add_holiday(holidays, easter, "Easter Sunday")
    add_holiday(holidays, easter + timedelta(days=1), "Easter Monday")

    # State/territory additions. These are local-rule approximations and avoid
    # network access; users can disable public holidays or switch country in Settings.
    if region in {"ACT"}:
        add_state_holiday(holidays, nth_weekday(year, 3, 0, 2), "Canberra Day", region)
        add_state_holiday(holidays, nth_weekday(year, 6, 0, 1), "Reconciliation Day", region)
        add_state_holiday(holidays, nth_weekday(year, 6, 0, 2), "King's Birthday", region)
        add_state_holiday(holidays, nth_weekday(year, 10, 0, 1), "Labour Day", region)
    elif region in {"NSW"}:
        add_state_holiday(holidays, nth_weekday(year, 6, 0, 2), "King's Birthday", region)
        add_state_holiday(holidays, nth_weekday(year, 8, 0, 1), "Bank Holiday", region)
        add_state_holiday(holidays, nth_weekday(year, 10, 0, 1), "Labour Day", region)
    elif region in {"NT"}:
        add_state_holiday(holidays, nth_weekday(year, 5, 0, 1), "May Day", region)
        add_state_holiday(holidays, nth_weekday(year, 6, 0, 2), "King's Birthday", region)
        add_state_holiday(holidays, nth_weekday(year, 8, 0, 1), "Picnic Day", region)
    elif region in {"QLD"}:
        add_state_holiday(holidays, nth_weekday(year, 5, 0, 1), "Labour Day", region)
        add_state_holiday(holidays, nth_weekday(year, 10, 0, 1), "King's Birthday", region)
    elif region in {"SA"}:
        add_state_holiday(holidays, nth_weekday(year, 3, 0, 2), "Adelaide Cup Day", region)
        add_state_holiday(holidays, nth_weekday(year, 6, 0, 2), "King's Birthday", region)
        add_state_holiday(holidays, nth_weekday(year, 10, 0, 1), "Labour Day", region)
        add_state_holiday(holidays, date(year, 12, 24), "Christmas Eve public holiday from evening", region)
    elif region in {"TAS"}:
        add_state_holiday(holidays, nth_weekday(year, 2, 0, 2), "Royal Hobart Regatta", region)
        add_state_holiday(holidays, nth_weekday(year, 3, 0, 2), "Eight Hours Day", region)
        add_state_holiday(holidays, nth_weekday(year, 6, 0, 2), "King's Birthday", region)
        add_state_holiday(holidays, nth_weekday(year, 11, 0, 1), "Recreation Day", region)
    elif region in {"VIC"}:
        add_state_holiday(holidays, nth_weekday(year, 3, 0, 2), "Labour Day", region)
        add_state_holiday(holidays, nth_weekday(year, 6, 0, 2), "King's Birthday", region)
        add_state_holiday(holidays, nth_weekday(year, 11, 1, 1), "Melbourne Cup", region)
    elif region in {"WA"}:
        add_state_holiday(holidays, nth_weekday(year, 3, 0, 1), "Labour Day", region)
        add_state_holiday(holidays, nth_weekday(year, 6, 0, 1), "Western Australia Day", region)
        add_state_holiday(holidays, last_weekday(year, 9, 0), "King's Birthday", region)
    return holidays


def us_public_holidays(year: int) -> Dict[str, List[str]]:
    holidays: Dict[str, List[str]] = {}
    for name, d in [
        ("New Year's Day", date(year, 1, 1)),
        ("Juneteenth", date(year, 6, 19)),
        ("Independence Day", date(year, 7, 4)),
        ("Veterans Day", date(year, 11, 11)),
        ("Christmas Day", date(year, 12, 25)),
    ]:
        merge_holidays(holidays, observed_fixed(name, d))
    add_holiday(holidays, nth_weekday(year, 1, 0, 3), "Martin Luther King Jr. Day")
    add_holiday(holidays, nth_weekday(year, 2, 0, 3), "Presidents' Day")
    add_holiday(holidays, last_weekday(year, 5, 0), "Memorial Day")
    add_holiday(holidays, nth_weekday(year, 9, 0, 1), "Labor Day")
    add_holiday(holidays, nth_weekday(year, 10, 0, 2), "Columbus Day / Indigenous Peoples' Day")
    add_holiday(holidays, nth_weekday(year, 11, 3, 4), "Thanksgiving Day")
    return holidays


def uk_public_holidays(year: int) -> Dict[str, List[str]]:
    holidays: Dict[str, List[str]] = {}
    easter = easter_sunday(year)
    merge_holidays(holidays, observed_fixed("New Year's Day", date(year, 1, 1)))
    add_holiday(holidays, easter - timedelta(days=2), "Good Friday")
    add_holiday(holidays, easter + timedelta(days=1), "Easter Monday")
    add_holiday(holidays, nth_weekday(year, 5, 0, 1), "Early May bank holiday")
    add_holiday(holidays, last_weekday(year, 5, 0), "Spring bank holiday")
    add_holiday(holidays, last_weekday(year, 8, 0), "Summer bank holiday")
    merge_holidays(holidays, observed_fixed("Christmas Day", date(year, 12, 25)))
    merge_holidays(holidays, observed_fixed("Boxing Day", date(year, 12, 26)))
    return holidays


def canada_public_holidays(year: int) -> Dict[str, List[str]]:
    holidays: Dict[str, List[str]] = {}
    easter = easter_sunday(year)
    for name, d in [
        ("New Year's Day", date(year, 1, 1)),
        ("Canada Day", date(year, 7, 1)),
        ("National Day for Truth and Reconciliation", date(year, 9, 30)),
        ("Remembrance Day", date(year, 11, 11)),
        ("Christmas Day", date(year, 12, 25)),
        ("Boxing Day", date(year, 12, 26)),
    ]:
        merge_holidays(holidays, observed_fixed(name, d))
    add_holiday(holidays, easter - timedelta(days=2), "Good Friday")
    add_holiday(holidays, nth_weekday(year, 9, 0, 1), "Labour Day")
    add_holiday(holidays, nth_weekday(year, 10, 0, 2), "Thanksgiving Day")
    return holidays


def nz_public_holidays(year: int) -> Dict[str, List[str]]:
    holidays: Dict[str, List[str]] = {}
    easter = easter_sunday(year)
    for name, d in [
        ("New Year's Day", date(year, 1, 1)),
        ("Day after New Year's Day", date(year, 1, 2)),
        ("Waitangi Day", date(year, 2, 6)),
        ("Anzac Day", date(year, 4, 25)),
        ("Christmas Day", date(year, 12, 25)),
        ("Boxing Day", date(year, 12, 26)),
    ]:
        merge_holidays(holidays, observed_fixed(name, d))
    add_holiday(holidays, easter - timedelta(days=2), "Good Friday")
    add_holiday(holidays, easter + timedelta(days=1), "Easter Monday")
    add_holiday(holidays, nth_weekday(year, 6, 0, 1), "King's Birthday")
    add_holiday(holidays, nth_weekday(year, 10, 0, 4), "Labour Day")
    return holidays


def public_holidays_for_year(year: int, settings: Optional[Dict[str, object]] = None) -> Dict[str, List[str]]:
    settings = settings or load_settings()
    if not bool(settings.get("show_public_holidays", True)):
        return {}
    country = str(settings.get("holiday_country", "Australia"))
    if country == "Disabled":
        return {}
    if country == "Australia":
        return australia_public_holidays(year, str(settings.get("holiday_region", "National")))
    if country == "United States":
        return us_public_holidays(year)
    if country == "United Kingdom":
        return uk_public_holidays(year)
    if country == "Canada":
        return canada_public_holidays(year)
    if country == "New Zealand":
        return nz_public_holidays(year)
    return {}


def public_holidays_for_month(year: int, month: int, settings: Optional[Dict[str, object]] = None) -> Dict[str, List[str]]:
    return {day_s: names for day_s, names in public_holidays_for_year(year, settings).items() if parse_date(day_s).month == month}


def holiday_occurrences_on(day: date | str, settings: Optional[Dict[str, object]] = None) -> List[HolidayOccurrence]:
    settings = settings or load_settings()
    day_obj = parse_date(day) if isinstance(day, str) else day
    items = public_holidays_for_year(day_obj.year, settings).get(day_obj.isoformat(), [])
    country = str(settings.get("holiday_country", "Australia"))
    return [
        HolidayOccurrence(
            title=name,
            date=day_obj.isoformat(),
            country=country,
            region=holiday_region_from_title(name) if country == "Australia" else "",
        )
        for name in items
    ]


def week_start(day: date | str, settings: Optional[Dict[str, object]] = None) -> date:
    day_obj = parse_date(day) if isinstance(day, str) else day
    settings = settings or load_settings()
    first = str(settings.get("first_day_of_week", "Monday"))
    if first == "Sunday":
        days_since_sunday = (day_obj.weekday() + 1) % 7
        return day_obj - timedelta(days=days_since_sunday)
    return day_obj - timedelta(days=day_obj.weekday())


def date_range(start_day: date | str, days: int) -> List[date]:
    start_obj = parse_date(start_day) if isinstance(start_day, str) else start_day
    return [start_obj + timedelta(days=offset) for offset in range(max(1, int(days)))]


def event_text_haystack(event: Event, occurrence_date: Optional[str] = None, settings: Optional[Dict[str, object]] = None) -> str:
    pieces = [
        event.title,
        event.start_date,
        format_date(event.start_date, settings),
        occurrence_date or "",
        format_date(occurrence_date, settings) if occurrence_date else "",
        event.start_time,
        event.end_date,
        format_date(event.end_date, settings) if event.end_date else "",
        event.end_time,
        event.location,
        event.category,
        event.notes,
        event.recurrence,
        " ".join(event.recurrence_exdates or []),
        event.source_uid,
        str(event.reminder_minutes),
    ]
    return "\n".join(str(piece or "") for piece in pieces).lower()


def holiday_text_haystack(holiday: HolidayOccurrence, settings: Optional[Dict[str, object]] = None) -> str:
    pieces = [
        holiday.title,
        holiday.date,
        format_date(holiday.date, settings),
        holiday.country,
        holiday.region,
        "Public Holiday",
    ]
    return "\n".join(str(piece or "") for piece in pieces).lower()


def item_matches_filters(
    item: CalendarItem,
    category: str = FILTER_CATEGORY_ALL,
    item_type: str = "all",
    show_user_events: bool = True,
    show_public_holidays: bool = True,
) -> bool:
    category = (category or FILTER_CATEGORY_ALL).strip()
    item_type = (item_type or "all").strip().lower()
    if item_type not in ITEM_TYPE_CHOICES:
        item_type = "all"
    if isinstance(item, HolidayOccurrence):
        if not show_public_holidays:
            return False
        if item_type not in {"all", "holidays"}:
            return False
        return category in {"", FILTER_CATEGORY_ALL, FILTER_CATEGORY_PUBLIC_HOLIDAY}
    if not show_user_events:
        return False
    event = item.event
    if item_type == "holidays":
        return False
    if item_type == "recurring" and event.recurrence == "None":
        return False
    if category and category not in {FILTER_CATEGORY_ALL, FILTER_CATEGORY_PUBLIC_HOLIDAY}:
        return event.category == category
    if category == FILTER_CATEGORY_PUBLIC_HOLIDAY:
        return False
    return True


def combined_calendar_items(
    store: CalendarStore,
    start_day: date | str,
    days: int = 1,
    settings: Optional[Dict[str, object]] = None,
    category: str = FILTER_CATEGORY_ALL,
    item_type: str = "all",
    show_user_events: bool = True,
    show_public_holidays: bool = True,
) -> List[CalendarItem]:
    settings = settings or load_settings()
    items: List[CalendarItem] = []
    for day in date_range(start_day, days):
        if show_user_events:
            items.extend(store.occurrences_on(day))
        if show_public_holidays:
            items.extend(holiday_occurrences_on(day, settings))
    filtered = [
        item for item in items
        if item_matches_filters(item, category=category, item_type=item_type, show_user_events=show_user_events, show_public_holidays=show_public_holidays)
    ]
    return sorted(filtered, key=lambda item: item.sort_key())


def search_calendar_items(
    store: CalendarStore,
    term: str,
    settings: Optional[Dict[str, object]] = None,
    start_day: Optional[date] = None,
    days: int = DEFAULT_SEARCH_SCAN_DAYS,
    category: str = FILTER_CATEGORY_ALL,
    item_type: str = "all",
    show_user_events: bool = True,
    show_public_holidays: bool = True,
) -> List[CalendarItem]:
    settings = settings or load_settings()
    needle = (term or "").strip().lower()
    start = start_day or (date.today() - timedelta(days=365))
    items = combined_calendar_items(
        store, start, days, settings=settings, category=category, item_type=item_type,
        show_user_events=show_user_events, show_public_holidays=show_public_holidays,
    )
    if not needle:
        return items
    matches: List[CalendarItem] = []
    for item in items:
        hay = holiday_text_haystack(item, settings) if isinstance(item, HolidayOccurrence) else event_text_haystack(item.event, item.date, settings)
        if needle in hay:
            matches.append(item)
    return sorted(matches, key=lambda item: item.sort_key())

# ------------------------- iCalendar support -------------------------

def escape_ics(value: str) -> str:
    return (value or "").replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\n", "\\n")


def unescape_ics(value: str) -> str:
    return value.replace("\\n", "\n").replace("\\,", ",").replace("\\;", ";").replace("\\\\", "\\")


def event_to_ics(event: Event) -> str:
    start = event.start_date.replace("-", "")
    if event.start_time:
        dtstart = f"DTSTART:{start}T{event.start_time.replace(':', '')}00"
    else:
        dtstart = f"DTSTART;VALUE=DATE:{start}"
    lines = [
        "BEGIN:VEVENT",
        f"UID:{event.id}@sentinel-calendar.local",
        f"DTSTAMP:{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}",
        dtstart,
    ]
    if event.end_date or event.end_time:
        end_date = (event.end_date or event.start_date).replace("-", "")
        if event.end_time:
            lines.append(f"DTEND:{end_date}T{event.end_time.replace(':', '')}00")
        else:
            lines.append(f"DTEND;VALUE=DATE:{end_date}")
    if event.recurrence != "None":
        rule = f"FREQ={RECURRENCE_TO_RRULE_FREQ[event.recurrence]}"
        if event.recurrence_until:
            rule += f";UNTIL={event.recurrence_until.replace('-', '')}"
        lines.append(f"RRULE:{rule}")
    lines.extend([
        f"SUMMARY:{escape_ics(event.title)}",
        f"CATEGORIES:{escape_ics(event.category)}",
    ])
    if event.location:
        lines.append(f"LOCATION:{escape_ics(event.location)}")
    if event.notes:
        lines.append(f"DESCRIPTION:{escape_ics(event.notes)}")
    if event.reminder_minutes:
        lines.extend([
            "BEGIN:VALARM",
            f"TRIGGER:-PT{event.reminder_minutes}M",
            "ACTION:DISPLAY",
            f"DESCRIPTION:{escape_ics(event.title)}",
            "END:VALARM",
        ])
    lines.append("END:VEVENT")
    return "\r\n".join(lines)


def export_ics(events: Iterable[Event], target: Path) -> int:
    items = list(events)
    body = [
        "BEGIN:VCALENDAR",
        "VERSION:2.0",
        "PRODID:-//SentinelOS//Sentinel Calendar//EN",
        "CALSCALE:GREGORIAN",
    ]
    body.extend(event_to_ics(event) for event in items)
    body.append("END:VCALENDAR")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text("\r\n".join(body) + "\r\n", encoding="utf-8")
    return len(items)


def parse_ics_datetime(value: str) -> Tuple[str, str]:
    value = value.strip()
    if ":" in value:
        value = value.split(":", 1)[1].strip()
    if "T" in value:
        day, clock = value.split("T", 1)
        clock = clock.rstrip("Z")
        return f"{day[0:4]}-{day[4:6]}-{day[6:8]}", f"{clock[0:2]}:{clock[2:4]}"
    return f"{value[0:4]}-{value[4:6]}-{value[6:8]}", ""


def unfold_ics_lines(text: str) -> List[str]:
    lines: List[str] = []
    for raw in text.splitlines():
        if raw.startswith((" ", "\t")) and lines:
            lines[-1] += raw[1:]
        else:
            lines.append(raw.rstrip("\r\n"))
    return lines

def parse_rrule(value: str) -> Tuple[str, str]:
    parts = {}
    for item in value.split(";"):
        if "=" in item:
            key, val = item.split("=", 1)
            parts[key.upper()] = val
    recurrence = RRULE_FREQ_TO_RECURRENCE.get(parts.get("FREQ", "").upper(), "None")
    until = parts.get("UNTIL", "")
    until_date = ""
    if until:
        until = until.split("T", 1)[0]
        until_date = f"{until[0:4]}-{until[4:6]}-{until[6:8]}"
    return recurrence, until_date


def parse_alarm_trigger(value: str) -> int:
    # Supports common negative minute/hour/day triggers: -PT15M, -PT1H, -P1D
    value = value.strip().upper()
    match = re.match(r"^-P(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?)?$", value)
    if not match:
        return 0
    days = int(match.group(1) or 0)
    hours = int(match.group(2) or 0)
    minutes = int(match.group(3) or 0)
    return days * 1440 + hours * 60 + minutes


def import_ics(path: Path) -> List[Event]:
    text = path.read_text(encoding="utf-8", errors="replace")
    events: List[Event] = []
    current: Dict[str, str] = {}
    in_event = False
    in_alarm = False
    for raw_line in unfold_ics_lines(text):
        line = raw_line.strip()
        if line == "BEGIN:VEVENT":
            current = {}
            in_event = True
            in_alarm = False
            continue
        if line == "BEGIN:VALARM" and in_event:
            in_alarm = True
            continue
        if line == "END:VALARM" and in_event:
            in_alarm = False
            continue
        if line == "END:VEVENT" and in_event:
            title = unescape_ics(current.get("SUMMARY", "Untitled"))
            dtstart = current.get("DTSTART", date.today().strftime("%Y%m%d"))
            start_date, start_time = parse_ics_datetime(dtstart)
            end_date = end_time = ""
            if current.get("DTEND"):
                end_date, end_time = parse_ics_datetime(current["DTEND"])
            recurrence, recurrence_until = parse_rrule(current.get("RRULE", "")) if current.get("RRULE") else ("None", "")
            reminder = parse_alarm_trigger(current.get("VALARM_TRIGGER", "")) if current.get("VALARM_TRIGGER") else 0
            events.append(Event.create(
                title=title,
                start_date=start_date,
                start_time=start_time,
                end_date=end_date,
                end_time=end_time,
                location=unescape_ics(current.get("LOCATION", "")),
                category=unescape_ics(current.get("CATEGORIES", "General")) or "General",
                notes=unescape_ics(current.get("DESCRIPTION", "")),
                reminder_minutes=reminder,
                recurrence=recurrence,
                recurrence_until=recurrence_until,
                source_uid=unescape_ics(current.get("UID", "")),
            ))
            current = {}
            in_event = False
            in_alarm = False
            continue
        if in_event and ":" in line:
            key, value = line.split(":", 1)
            key = key.split(";", 1)[0].upper()
            if in_alarm and key == "TRIGGER":
                current["VALARM_TRIGGER"] = value
            elif not in_alarm:
                current[key] = value
    return events


def import_ics_preview_payload(path: Path, store: Optional[CalendarStore] = None) -> Dict[str, object]:
    events = import_ics(path)
    store = store or CalendarStore()
    duplicates = [event for event in events if store.has_duplicate(event)]
    return {
        "app": APP_NAME,
        "program": PROGRAM_NUMBER,
        "version": VERSION,
        "type": "ics_import_preview",
        "path": str(path),
        "total_events": len(events),
        "duplicate_count": len(duplicates),
        "importable_count": len(events) - len(duplicates),
        "items": [asdict(event) for event in events],
    }


def export_ics_range(store: CalendarStore, start_day: str, end_day: str, target: Path) -> int:
    start = parse_date(start_day)
    end = parse_date(end_day)
    if end < start:
        raise ValueError("Export end date cannot be before start date.")
    selected = [event for event in store.events if start <= parse_date(event.start_date) <= end]
    return export_ics(selected, target)


# ------------------------- Reminder daemon / notification support -------------------------

def load_reminder_state() -> Dict[str, object]:
    ensure_dirs()
    path = reminder_state_path()
    if not path.exists():
        return {"dismissed": {}, "snoozed": {}}
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
        return raw if isinstance(raw, dict) else {"dismissed": {}, "snoozed": {}}
    except Exception:
        return {"dismissed": {}, "snoozed": {}}


def save_reminder_state(state: Dict[str, object]) -> None:
    ensure_dirs()
    write_json_file(reminder_state_path(), state)


def reminder_key(occ: Occurrence, event_dt: datetime) -> str:
    return f"{occ.event.id}:{occ.date}:{event_dt.strftime('%H:%M')}"


def reminder_state_is_blocked(key: str, state: Dict[str, object], now: Optional[datetime] = None) -> bool:
    now = now or datetime.now()
    dismissed = state.get("dismissed", {}) if isinstance(state.get("dismissed", {}), dict) else {}
    if key in dismissed:
        return True
    snoozed = state.get("snoozed", {}) if isinstance(state.get("snoozed", {}), dict) else {}
    until = snoozed.get(key)
    if until:
        try:
            return datetime.fromisoformat(str(until)) > now
        except Exception:
            return False
    return False


def dismiss_reminder(key: str) -> None:
    state = load_reminder_state()
    dismissed = state.setdefault("dismissed", {})
    if isinstance(dismissed, dict):
        dismissed[key] = now_iso()
    save_reminder_state(state)


def snooze_reminder(key: str, minutes: int) -> None:
    state = load_reminder_state()
    snoozed = state.setdefault("snoozed", {})
    if isinstance(snoozed, dict):
        snoozed[key] = (datetime.now() + timedelta(minutes=max(1, minutes))).replace(microsecond=0).isoformat()
    save_reminder_state(state)


def notify_desktop(title: str, body: str, sound: bool = False) -> bool:
    if not shutil.which("notify-send"):
        return False
    cmd = ["notify-send", "--app-name=Sentinel Calendar", title, body]
    try:
        subprocess.run(cmd, check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if sound and shutil.which("paplay"):
            subprocess.Popen(["paplay", "/usr/share/sounds/freedesktop/stereo/complete.oga"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except Exception:
        return False


def notify_due_reminders(store: CalendarStore, window_minutes: int = 5, mark_dismissed: bool = True) -> Dict[str, object]:
    settings = load_settings()
    state = load_reminder_state()
    due = store.reminders_due(max(1, window_minutes))
    sent = []
    for occ, event_dt, reminder_dt in due:
        key = reminder_key(occ, event_dt)
        if reminder_state_is_blocked(key, state):
            continue
        body = f"{format_date(event_dt.date(), settings)} {event_dt.strftime('%H:%M')} — {occ.event.title}"
        delivered = False
        if bool(settings.get("notifications_enabled", True)):
            delivered = notify_desktop("Sentinel Calendar Reminder", body, bool(settings.get("notification_sound", False)))
        if not delivered:
            print(f"REMINDER {key}: {body}")
        sent.append({"key": key, "event": calendar_item_to_dict(occ, settings), "event_datetime": event_dt.isoformat(), "reminder_datetime": reminder_dt.isoformat(), "desktop_notification": delivered})
        if mark_dismissed:
            dismiss_reminder(key)
    return {"app": APP_NAME, "version": VERSION, "type": "reminder_notify_result", "count": len(sent), "items": sent}


def run_reminder_daemon(store: CalendarStore, interval_seconds: int = 60, window_minutes: int = 5, once: bool = False) -> int:
    interval_seconds = max(30, int(interval_seconds))
    print(f"{APP_NAME} reminder daemon v{VERSION} running. Interval: {interval_seconds}s. Window: {window_minutes}m.")
    while True:
        notify_due_reminders(store, window_minutes=window_minutes, mark_dismissed=True)
        if once:
            return 0
        time_module.sleep(interval_seconds)


# ------------------------- Tk interface -------------------------

_ToplevelBase = tk.Toplevel if tk else object
_TkBase = tk.Tk if tk else object


def install_combobox_theme(root: tk.Misc) -> None:
    """Apply the Sentinel/AEGIS dark theme to ttk comboboxes and popdown lists.

    ttk comboboxes use native-ish popdown listboxes, so styling the widget alone
    is not enough.  The option database covers newly-created dropdown listboxes;
    style_combobox_popup() also refreshes the live popdown after it is posted.
    """
    if not tk or not ttk:
        return
    try:
        root.option_add("*TCombobox*Listbox.background", THEME["panel2"])
        root.option_add("*TCombobox*Listbox.foreground", THEME["text"])
        root.option_add("*TCombobox*Listbox.selectBackground", THEME["gold2"])
        root.option_add("*TCombobox*Listbox.selectForeground", "#111111")
        root.option_add("*TCombobox*Listbox.borderWidth", 0)
        root.option_add("*TCombobox*Listbox.highlightThickness", 1)
        root.option_add("*TCombobox*Listbox.highlightBackground", THEME["border"])
        root.option_add("*TCombobox*Listbox.highlightColor", THEME["gold"])
    except Exception:
        pass

    try:
        style = ttk.Style(root)
        style.configure(
            "Sentinel.TCombobox",
            fieldbackground=THEME["panel2"],
            background=THEME["panel2"],
            foreground=THEME["text"],
            selectbackground=THEME["gold2"],
            selectforeground="#111111",
            arrowcolor=THEME["gold"],
            bordercolor=THEME["border"],
            lightcolor=THEME["panel2"],
            darkcolor=THEME["border"],
            relief="flat",
            padding=4,
        )
        style.map(
            "Sentinel.TCombobox",
            fieldbackground=[("readonly", THEME["panel2"]), ("focus", THEME["panel2"]), ("!disabled", THEME["panel2"])],
            foreground=[("readonly", THEME["text"]), ("disabled", THEME["muted"]), ("!disabled", THEME["text"])],
            background=[("active", THEME["panel2"]), ("pressed", THEME["panel2"]), ("readonly", THEME["panel2"])],
            arrowcolor=[("active", THEME["cyan"]), ("pressed", THEME["gold"]), ("!disabled", THEME["gold"])],
            bordercolor=[("focus", THEME["gold"]), ("!focus", THEME["border"])],
        )
        # Keep plain TCombobox users themed as a fallback.
        style.configure("TCombobox", fieldbackground=THEME["panel2"], background=THEME["panel2"], foreground=THEME["text"], arrowcolor=THEME["gold"])
        style.map("TCombobox", fieldbackground=[("readonly", THEME["panel2"]), ("!disabled", THEME["panel2"])], foreground=[("readonly", THEME["text"]), ("!disabled", THEME["text"])])
    except Exception:
        pass


def style_combobox_popup(combo: ttk.Combobox) -> None:
    """Theme the actual dropdown listbox used by one ttk.Combobox."""
    if not tk:
        return
    try:
        popdown = combo.tk.eval(f"ttk::combobox::PopdownWindow {combo}")
        listbox = f"{popdown}.f.l"
        combo.tk.call(listbox, "configure", "-background", THEME["panel2"])
        combo.tk.call(listbox, "configure", "-foreground", THEME["text"])
        combo.tk.call(listbox, "configure", "-selectbackground", THEME["gold2"])
        combo.tk.call(listbox, "configure", "-selectforeground", "#111111")
        combo.tk.call(listbox, "configure", "-highlightbackground", THEME["border"])
        combo.tk.call(listbox, "configure", "-highlightcolor", THEME["gold"])
        combo.tk.call(listbox, "configure", "-borderwidth", 0)
    except Exception:
        pass


def themed_combobox(parent: tk.Widget, **kwargs) -> ttk.Combobox:
    """Create a ttk combobox using the Sentinel/AEGIS dropdown theme."""
    combo = ttk.Combobox(parent, style="Sentinel.TCombobox", **kwargs)
    try:
        combo.configure(style="Sentinel.TCombobox")
    except Exception:
        pass
    for event_name in ("<Button-1>", "<Alt-Down>", "<Key-F4>"):
        combo.bind(event_name, lambda _e, c=combo: c.after(1, lambda: style_combobox_popup(c)), add="+")
    combo.bind("<<ComboboxSelected>>", lambda _e, c=combo: style_combobox_popup(c), add="+")
    return combo


class EventDialog(_ToplevelBase):
    def __init__(self, parent: tk.Tk, title: str, initial: Optional[Event] = None, selected_date: Optional[date] = None, settings: Optional[Dict[str, object]] = None) -> None:
        super().__init__(parent)
        self.result: Optional[Dict[str, object]] = None
        self.settings = settings or load_settings()
        self.title(title)
        self.configure(bg=THEME["bg"])
        install_combobox_theme(self)
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()

        default_date = format_date(selected_date or date.today(), self.settings)
        self.vars = {
            "title": tk.StringVar(value=initial.title if initial else ""),
            "start_date": tk.StringVar(value=format_date(initial.start_date, self.settings) if initial else default_date),
            "start_time": tk.StringVar(value=initial.start_time if initial else ""),
            "end_date": tk.StringVar(value=format_date(initial.end_date, self.settings) if initial and initial.end_date else ""),
            "end_time": tk.StringVar(value=initial.end_time if initial else ""),
            "location": tk.StringVar(value=initial.location if initial else ""),
            "category": tk.StringVar(value=initial.category if initial else str(self.settings.get("default_category", "General"))),
            "reminder_minutes": tk.StringVar(value=str(initial.reminder_minutes) if initial else str(self.settings.get("default_reminder_minutes", 0))),
            "recurrence": tk.StringVar(value=initial.recurrence if initial else "None"),
            "recurrence_until": tk.StringVar(value=format_date(initial.recurrence_until, self.settings) if initial and initial.recurrence_until else ""),
        }
        self.notes = tk.Text(self, width=58, height=7, bg=THEME["panel2"], fg=THEME["text"], insertbackground=THEME["gold"], relief="flat", wrap="word")
        if initial and initial.notes:
            self.notes.insert("1.0", initial.notes)
        self._build()
        self.bind("<Escape>", lambda _e: self.destroy())
        self.bind("<Control-Return>", lambda _e: self.on_save())
        self.wait_visibility()
        self.focus_force()

    def _build(self) -> None:
        frame = tk.Frame(self, bg=THEME["bg"], padx=16, pady=16)
        frame.grid(row=0, column=0, sticky="nsew")

        def label(text: str, row: int, col: int = 0) -> None:
            tk.Label(frame, text=text, bg=THEME["bg"], fg=THEME["muted"], anchor="w").grid(row=row, column=col, sticky="w", pady=(4, 2))

        def entry(var: tk.StringVar, row: int, col: int = 0, width: int = 26) -> tk.Entry:
            item = tk.Entry(frame, textvariable=var, width=width, bg=THEME["panel2"], fg=THEME["text"], insertbackground=THEME["gold"], relief="flat")
            item.grid(row=row, column=col, sticky="we", padx=(0, 8), ipady=5)
            return item

        label("Title", 0)
        title_entry = entry(self.vars["title"], 1, width=58)
        title_entry.grid(columnspan=2, sticky="we")

        label(f"Start date {date_format_label(self.settings)}", 2)
        label("Start time HH:MM", 2, 1)
        entry(self.vars["start_date"], 3, 0)
        entry(self.vars["start_time"], 3, 1)

        label("End date optional", 4)
        label("End time optional", 4, 1)
        entry(self.vars["end_date"], 5, 0)
        entry(self.vars["end_time"], 5, 1)

        label("Location", 6)
        label("Category", 6, 1)
        entry(self.vars["location"], 7, 0)
        combo = themed_combobox(frame, textvariable=self.vars["category"], values=CATEGORY_CHOICES, width=24)
        combo.grid(row=7, column=1, sticky="we", padx=(0, 8), ipady=2)

        label("Reminder minutes before", 8)
        label("Repeats", 8, 1)
        reminder = themed_combobox(frame, textvariable=self.vars["reminder_minutes"], values=REMINDER_CHOICES, width=24)
        reminder.grid(row=9, column=0, sticky="we", padx=(0, 8), ipady=2)
        recurrence = themed_combobox(frame, textvariable=self.vars["recurrence"], values=RECURRENCE_CHOICES, width=24)
        recurrence.grid(row=9, column=1, sticky="we", padx=(0, 8), ipady=2)

        label(f"Repeat until optional {date_format_label(self.settings)}", 10)
        entry(self.vars["recurrence_until"], 11, 0)
        tk.Label(frame, text="Leave blank for no end date.", bg=THEME["bg"], fg=THEME["muted"], anchor="w").grid(row=11, column=1, sticky="w")

        label("Notes", 12)
        self.notes.grid(row=13, column=0, columnspan=2, sticky="we", pady=(0, 8))

        button_row = tk.Frame(frame, bg=THEME["bg"])
        button_row.grid(row=14, column=0, columnspan=2, sticky="e")
        self._button(button_row, "Cancel", self.destroy).pack(side="right", padx=(8, 0))
        self._button(button_row, "Save", self.on_save, primary=True).pack(side="right")
        title_entry.focus_set()

    def _button(self, parent: tk.Widget, text: str, command, primary: bool = False) -> tk.Button:
        return tk.Button(
            parent,
            text=text,
            command=command,
            bg=THEME["gold"] if primary else THEME["panel2"],
            fg="#111111" if primary else THEME["text"],
            activebackground=THEME["gold2"],
            activeforeground="#111111",
            relief="flat",
            padx=14,
            pady=6,
        )

    def on_save(self) -> None:
        try:
            start_date_iso = to_iso_date(self.vars["start_date"].get())
            clean_time(self.vars["start_time"].get())
            end_date_iso = ""
            if self.vars["end_date"].get().strip():
                end_date_iso = to_iso_date(self.vars["end_date"].get())
            clean_time(self.vars["end_time"].get())
            title = self.vars["title"].get().strip()
            if not title:
                raise ValueError("Event title is required.")
            recurrence = clean_recurrence(self.vars["recurrence"].get())
            recurrence_until = self.vars["recurrence_until"].get().strip()
            recurrence_until_iso = to_iso_date(recurrence_until) if recurrence_until else ""
            self.result = {
                "title": title,
                "start_date": start_date_iso,
                "start_time": clean_time(self.vars["start_time"].get()),
                "end_date": end_date_iso,
                "end_time": clean_time(self.vars["end_time"].get()),
                "location": self.vars["location"].get().strip(),
                "category": self.vars["category"].get().strip() or "General",
                "notes": self.notes.get("1.0", "end").strip(),
                "reminder_minutes": clean_reminder(self.vars["reminder_minutes"].get()),
                "recurrence": recurrence,
                "recurrence_until": recurrence_until_iso,
            }
            self.destroy()
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc), parent=self)


class SettingsDialog(_ToplevelBase):
    def __init__(self, parent: tk.Tk, settings: Dict[str, object]) -> None:
        super().__init__(parent)
        self.result: Optional[Dict[str, object]] = None
        self.title("Calendar Settings")
        self.configure(bg=THEME["bg"])
        install_combobox_theme(self)
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()
        self.vars = {
            "date_format": tk.StringVar(value=str(settings.get("date_format", DEFAULT_SETTINGS["date_format"]))),
            "show_public_holidays": tk.BooleanVar(value=bool(settings.get("show_public_holidays", True))),
            "holiday_country": tk.StringVar(value=str(settings.get("holiday_country", DEFAULT_SETTINGS["holiday_country"]))),
            "holiday_region": tk.StringVar(value=str(settings.get("holiday_region", DEFAULT_SETTINGS["holiday_region"]))),
            "first_day_of_week": tk.StringVar(value=str(settings.get("first_day_of_week", DEFAULT_SETTINGS["first_day_of_week"]))),
            "default_category": tk.StringVar(value=str(settings.get("default_category", DEFAULT_SETTINGS["default_category"]))),
            "default_reminder_minutes": tk.StringVar(value=str(settings.get("default_reminder_minutes", DEFAULT_SETTINGS["default_reminder_minutes"]))),
            "startup_view": tk.StringVar(value=str(settings.get("startup_view", DEFAULT_SETTINGS["startup_view"]))),
            "backup_keep": tk.StringVar(value=str(settings.get("backup_keep", DEFAULT_SETTINGS["backup_keep"]))),
            "confirm_delete": tk.BooleanVar(value=bool(settings.get("confirm_delete", True))),
            "notifications_enabled": tk.BooleanVar(value=bool(settings.get("notifications_enabled", True))),
            "notification_sound": tk.BooleanVar(value=bool(settings.get("notification_sound", False))),
            "default_snooze_minutes": tk.StringVar(value=str(settings.get("default_snooze_minutes", DEFAULT_SETTINGS["default_snooze_minutes"]))),
        }
        self._build()
        self.bind("<Escape>", lambda _e: self.destroy())
        self.bind("<Control-Return>", lambda _e: self.on_save())
        self.wait_visibility()
        self.focus_force()

    def _build(self) -> None:
        frame = tk.Frame(self, bg=THEME["bg"], padx=16, pady=16)
        frame.grid(row=0, column=0, sticky="nsew")
        tk.Label(frame, text="Sentinel Calendar Settings", bg=THEME["bg"], fg=THEME["gold"], font=("DejaVu Sans", 16, "bold"), anchor="w").grid(row=0, column=0, columnspan=2, sticky="we", pady=(0, 12))

        def label(text: str, row: int) -> None:
            tk.Label(frame, text=text, bg=THEME["bg"], fg=THEME["muted"], anchor="w").grid(row=row, column=0, sticky="w", pady=(6, 2))

        label("Date input/output format", 1)
        date_combo = themed_combobox(frame, textvariable=self.vars["date_format"], values=DATE_FORMAT_CHOICES, width=26, state="readonly")
        date_combo.grid(row=2, column=0, columnspan=2, sticky="we", ipady=3)

        holiday_check = tk.Checkbutton(
            frame,
            text="Show public holidays on calendar days",
            variable=self.vars["show_public_holidays"],
            bg=THEME["bg"],
            fg=THEME["text"],
            selectcolor=THEME["panel2"],
            activebackground=THEME["bg"],
            activeforeground=THEME["gold"],
        )
        holiday_check.grid(row=3, column=0, columnspan=2, sticky="w", pady=(12, 2))

        label("Public holiday country", 4)
        country_combo = themed_combobox(frame, textvariable=self.vars["holiday_country"], values=HOLIDAY_COUNTRY_CHOICES, width=26, state="readonly")
        country_combo.grid(row=5, column=0, columnspan=2, sticky="we", ipady=3)

        label("Australia region / state", 6)
        region_combo = themed_combobox(frame, textvariable=self.vars["holiday_region"], values=AU_REGION_CHOICES, width=26, state="readonly")
        region_combo.grid(row=7, column=0, columnspan=2, sticky="we", ipady=3)

        label("First day of week", 8)
        first_combo = themed_combobox(frame, textvariable=self.vars["first_day_of_week"], values=FIRST_DAY_CHOICES, width=26, state="readonly")
        first_combo.grid(row=9, column=0, columnspan=2, sticky="we", ipady=3)

        label("Default category", 10)
        defcat_combo = themed_combobox(frame, textvariable=self.vars["default_category"], values=CATEGORY_CHOICES, width=26, state="readonly")
        defcat_combo.grid(row=11, column=0, sticky="we", ipady=3)
        tk.Entry(frame, textvariable=self.vars["default_reminder_minutes"], width=10, bg=THEME["panel2"], fg=THEME["text"], insertbackground=THEME["gold"], relief="flat").grid(row=11, column=1, sticky="we", padx=(8, 0), ipady=5)
        tk.Label(frame, text="Default reminder minutes", bg=THEME["bg"], fg=THEME["muted"], anchor="w").grid(row=10, column=1, sticky="w", pady=(6, 2))

        label("Startup view", 12)
        startup_combo = themed_combobox(frame, textvariable=self.vars["startup_view"], values=STARTUP_VIEW_CHOICES, width=26, state="readonly")
        startup_combo.grid(row=13, column=0, sticky="we", ipady=3)
        tk.Entry(frame, textvariable=self.vars["backup_keep"], width=10, bg=THEME["panel2"], fg=THEME["text"], insertbackground=THEME["gold"], relief="flat").grid(row=13, column=1, sticky="we", padx=(8, 0), ipady=5)
        tk.Label(frame, text="Backups to retain", bg=THEME["bg"], fg=THEME["muted"], anchor="w").grid(row=12, column=1, sticky="w", pady=(6, 2))

        for row, text, var in [(14, "Confirm before deleting events", self.vars["confirm_delete"]), (15, "Enable desktop notifications", self.vars["notifications_enabled"]), (16, "Play notification sound when possible", self.vars["notification_sound"] )]:
            tk.Checkbutton(frame, text=text, variable=var, bg=THEME["bg"], fg=THEME["text"], selectcolor=THEME["panel2"], activebackground=THEME["bg"], activeforeground=THEME["gold"]).grid(row=row, column=0, columnspan=2, sticky="w", pady=(4, 0))

        tk.Label(
            frame,
            text="Internal event storage remains ISO for safety; the GUI and CLI accept and display your selected format.",
            bg=THEME["bg"], fg=THEME["muted"], wraplength=460, justify="left"
        ).grid(row=17, column=0, columnspan=2, sticky="w", pady=(12, 8))

        buttons = tk.Frame(frame, bg=THEME["bg"])
        buttons.grid(row=18, column=0, columnspan=2, sticky="e")
        self._button(buttons, "Cancel", self.destroy).pack(side="right", padx=(8, 0))
        self._button(buttons, "Save", self.on_save, primary=True).pack(side="right")

    def _button(self, parent: tk.Widget, text: str, command, primary: bool = False) -> tk.Button:
        return tk.Button(
            parent,
            text=text,
            command=command,
            bg=THEME["gold"] if primary else THEME["panel2"],
            fg="#111111" if primary else THEME["text"],
            activebackground=THEME["gold2"],
            activeforeground="#111111",
            relief="flat",
            padx=14,
            pady=6,
        )

    def on_save(self) -> None:
        self.result = {
            "date_format": self.vars["date_format"].get(),
            "show_public_holidays": bool(self.vars["show_public_holidays"].get()),
            "holiday_country": self.vars["holiday_country"].get(),
            "holiday_region": self.vars["holiday_region"].get(),
            "first_day_of_week": self.vars["first_day_of_week"].get(),
            "default_category": self.vars["default_category"].get(),
            "default_reminder_minutes": self.vars["default_reminder_minutes"].get(),
            "startup_view": self.vars["startup_view"].get(),
            "backup_keep": self.vars["backup_keep"].get(),
            "confirm_delete": bool(self.vars["confirm_delete"].get()),
            "notifications_enabled": bool(self.vars["notifications_enabled"].get()),
            "notification_sound": bool(self.vars["notification_sound"].get()),
            "default_snooze_minutes": self.vars["default_snooze_minutes"].get(),
        }
        self.destroy()


class SentinelCalendarApp(_TkBase):
    def __init__(self, store: CalendarStore) -> None:
        super().__init__()
        self.store = store
        self.settings = load_settings()
        today = date.today()
        self.visible_year = today.year
        self.visible_month = today.month
        self.selected_date = today
        self.day_buttons: Dict[Tuple[int, int], tk.Button] = {}
        self.day_header_labels: List[tk.Label] = []
        self.cell_dates: Dict[Tuple[int, int], Optional[date]] = {}
        self.current_occurrences: List[CalendarItem] = []
        self.category_filter_var = tk.StringVar(value=FILTER_CATEGORY_ALL)
        self.show_user_events_var = tk.BooleanVar(value=True)
        self.show_public_holidays_var = tk.BooleanVar(value=bool(self.settings.get("show_public_holidays", True)))
        self.recurring_only_var = tk.BooleanVar(value=False)
        self.title(f"{APP_NAME} v{VERSION}")
        self.geometry("1240x820")
        self.minsize(1080, 720)
        self.configure(bg=THEME["bg"])
        self._setup_style()
        self._build()
        self.bind_all("<Control-q>", lambda _e: self.quit_app())
        self.bind_all("<Control-Q>", lambda _e: self.quit_app())
        self.refresh_all()
        self.apply_startup_view()

    def _setup_style(self) -> None:
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except Exception:
            pass
        install_combobox_theme(self)
        style.configure("Treeview", background=THEME["panel2"], foreground=THEME["text"], fieldbackground=THEME["panel2"], bordercolor=THEME["border"], rowheight=28)
        style.configure("Treeview.Heading", background=THEME["panel"], foreground=THEME["gold"], relief="flat")
        style.map("Treeview", background=[("selected", THEME["gold2"])], foreground=[("selected", "#111111")])

    def _build(self) -> None:
        header = tk.Frame(self, bg=THEME["bg"], padx=14, pady=12)
        header.pack(fill="x")
        tk.Label(header, text="SENTINEL CALENDAR", bg=THEME["bg"], fg=THEME["gold"], font=("DejaVu Sans", 20, "bold")).pack(side="left")
        tk.Label(header, text="Program 104 • stable lock • v0.7.0 ICS backfill complete", bg=THEME["bg"], fg=THEME["muted"], font=("DejaVu Sans", 10)).pack(side="left", padx=(12, 0), pady=(8, 0))
        self._button(header, "Quit Ctrl+Q", self.quit_app).pack(side="right", padx=4)
        self._button(header, "Settings", self.open_settings).pack(side="right", padx=4)
        self._button(header, "Jump Date", self.jump_to_date).pack(side="right", padx=4)
        self._button(header, "Today", self.go_today).pack(side="right", padx=4)
        self._button(header, "Export ICS", self.export_dialog).pack(side="right", padx=4)
        self._button(header, "Export Range", self.export_range_dialog).pack(side="right", padx=4)
        self._button(header, "Import ICS", self.import_dialog).pack(side="right", padx=4)

        main = tk.Frame(self, bg=THEME["bg"])
        main.pack(fill="both", expand=True, padx=14, pady=(0, 14))

        left = tk.Frame(main, bg=THEME["panel"], padx=12, pady=12, highlightthickness=1, highlightbackground=THEME["border"])
        left.pack(side="left", fill="both", expand=True, padx=(0, 10))
        right = tk.Frame(main, bg=THEME["panel"], padx=12, pady=12, highlightthickness=1, highlightbackground=THEME["border"])
        right.pack(side="right", fill="both", expand=True)

        nav = tk.Frame(left, bg=THEME["panel"])
        nav.pack(fill="x")
        self._button(nav, "◀", self.prev_month).pack(side="left")
        self.month_label = tk.Label(nav, text="", bg=THEME["panel"], fg=THEME["text"], font=("DejaVu Sans", 16, "bold"))
        self.month_label.pack(side="left", fill="x", expand=True)
        self._button(nav, "▶", self.next_month).pack(side="right")

        days = tk.Frame(left, bg=THEME["panel"], pady=10)
        days.pack(fill="both", expand=True)
        day_names = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"] if str(self.settings.get("first_day_of_week", "Monday")) == "Sunday" else ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
        for col, day_name in enumerate(day_names):
            label = tk.Label(days, text=day_name, bg=THEME["panel"], fg=THEME["muted"], font=("DejaVu Sans", 10, "bold"))
            label.grid(row=0, column=col, sticky="nsew", padx=3, pady=3)
            self.day_header_labels.append(label)
            days.grid_columnconfigure(col, weight=1)
        self.days_frame = days
        for row in range(1, 7):
            days.grid_rowconfigure(row, weight=1)
            for col in range(7):
                btn = tk.Button(days, text="", bg=THEME["panel2"], fg=THEME["text"], relief="flat", anchor="nw", padx=7, pady=7, command=lambda r=row, c=col: self.select_cell(r, c))
                btn.grid(row=row, column=col, sticky="nsew", padx=3, pady=3)
                self.day_buttons[(row, col)] = btn

        legend = tk.Label(left, text="● user events   ↻ recurring   ★ public holidays", bg=THEME["panel"], fg=THEME["muted"], anchor="w")
        legend.pack(fill="x", pady=(4, 0))

        selected_header = tk.Frame(right, bg=THEME["panel"])
        selected_header.pack(fill="x")
        self.selected_label = tk.Label(selected_header, text="", bg=THEME["panel"], fg=THEME["gold"], font=("DejaVu Sans", 15, "bold"), anchor="w")
        self.selected_label.pack(side="left", fill="x", expand=True)
        self._button(selected_header, "+ Add", self.add_event, primary=True).pack(side="right")

        self.event_list = tk.Listbox(right, bg=THEME["panel2"], fg=THEME["text"], selectbackground=THEME["gold2"], selectforeground="#111111", relief="flat", activestyle="none", height=11)
        self.event_list.pack(fill="both", expand=True, pady=(10, 8))
        self.event_list.bind("<<ListboxSelect>>", lambda _e: self.show_selected_event())
        self.event_list.bind("<Double-Button-1>", lambda _e: self.edit_event())

        actions = tk.Frame(right, bg=THEME["panel"])
        actions.pack(fill="x")
        self._button(actions, "Edit", self.edit_event).pack(side="left", padx=(0, 6))
        self._button(actions, "Delete", self.delete_event).pack(side="left", padx=(0, 6))
        self._button(actions, "Today", self.show_today).pack(side="left", padx=(0, 6))
        self._button(actions, "Week", self.show_week).pack(side="left", padx=(0, 6))
        self._button(actions, "Agenda 30", self.show_agenda).pack(side="left", padx=(0, 6))
        self._button(actions, "Upcoming", self.show_upcoming).pack(side="left", padx=(0, 6))
        self._button(actions, "Suite", self.show_suite_summary).pack(side="left", padx=(0, 6))
        self._button(actions, "All", self.show_all_events).pack(side="left", padx=(0, 6))

        filter_row = tk.Frame(right, bg=THEME["panel"], pady=8)
        filter_row.pack(fill="x")
        tk.Label(filter_row, text="Filter:", bg=THEME["panel"], fg=THEME["muted"]).pack(side="left", padx=(0, 6))
        category_combo = themed_combobox(filter_row, textvariable=self.category_filter_var, values=FILTER_CATEGORY_CHOICES, width=18, state="readonly")
        category_combo.pack(side="left", padx=(0, 8))
        category_combo.bind("<<ComboboxSelected>>", lambda _e: self.apply_filters())
        self._check(filter_row, "User", self.show_user_events_var, self.apply_filters).pack(side="left", padx=(0, 6))
        self._check(filter_row, "Holidays", self.show_public_holidays_var, self.apply_filters).pack(side="left", padx=(0, 6))
        self._check(filter_row, "Recurring only", self.recurring_only_var, self.apply_filters).pack(side="left", padx=(0, 6))

        search_row = tk.Frame(right, bg=THEME["panel"], pady=10)
        search_row.pack(fill="x")
        self.search_var = tk.StringVar()
        search_entry = tk.Entry(search_row, textvariable=self.search_var, bg=THEME["panel2"], fg=THEME["text"], insertbackground=THEME["gold"], relief="flat")
        search_entry.pack(side="left", fill="x", expand=True, ipady=6)
        self._button(search_row, "Search", self.search_events).pack(side="left", padx=(8, 0))
        self._button(search_row, "Clear", self.clear_search).pack(side="left", padx=(6, 0))
        search_entry.bind("<Return>", lambda _e: self.search_events())

        self.details = tk.Text(right, bg=THEME["panel2"], fg=THEME["text"], insertbackground=THEME["gold"], relief="flat", height=11, wrap="word")
        self.details.pack(fill="x")
        self.details.configure(state="disabled")

    def _button(self, parent: tk.Widget, text: str, command, primary: bool = False) -> tk.Button:
        return tk.Button(
            parent,
            text=text,
            command=command,
            bg=THEME["gold"] if primary else THEME["panel2"],
            fg="#111111" if primary else THEME["text"],
            activebackground=THEME["gold2"],
            activeforeground="#111111",
            relief="flat",
            padx=12,
            pady=6,
        )

    def _check(self, parent: tk.Widget, text: str, variable: tk.BooleanVar, command) -> tk.Checkbutton:
        return tk.Checkbutton(
            parent, text=text, variable=variable, command=command,
            bg=THEME["panel"], fg=THEME["text"], selectcolor=THEME["panel2"],
            activebackground=THEME["panel"], activeforeground=THEME["gold"],
            relief="flat", padx=4, pady=2,
        )

    def active_item_type(self) -> str:
        return "recurring" if bool(self.recurring_only_var.get()) else "all"

    def active_category(self) -> str:
        return self.category_filter_var.get() or FILTER_CATEGORY_ALL

    def refresh_day_headers(self) -> None:
        names = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"] if str(self.settings.get("first_day_of_week", "Monday")) == "Sunday" else ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
        for label, name in zip(self.day_header_labels, names):
            label.configure(text=name)

    def apply_startup_view(self) -> None:
        view = str(self.settings.get("startup_view", "Month"))
        if view == "Today":
            self.show_today()
        elif view == "Week":
            self.show_week()
        elif view == "Agenda":
            self.show_agenda()

    def visible_items(self, start_day: date | str, days: int = 1) -> List[CalendarItem]:
        return combined_calendar_items(
            self.store, start_day, days, settings=self.settings, category=self.active_category(),
            item_type=self.active_item_type(), show_user_events=bool(self.show_user_events_var.get()),
            show_public_holidays=bool(self.show_public_holidays_var.get()),
        )

    def apply_filters(self) -> None:
        self.refresh_day_events()

    def refresh_all(self) -> None:
        self.refresh_day_headers()
        self.refresh_month()
        self.refresh_day_events()

    def refresh_month(self) -> None:
        month_name = pycalendar.month_name[self.visible_month]
        self.month_label.configure(text=f"{month_name} {self.visible_year}")
        event_days = self.store.month_dates(self.visible_year, self.visible_month)
        holiday_days = public_holidays_for_month(self.visible_year, self.visible_month, self.settings)
        today_s = date.today().isoformat()
        selected_s = self.selected_date.isoformat()
        cal = pycalendar.Calendar(firstweekday=6 if str(self.settings.get("first_day_of_week", "Monday")) == "Sunday" else 0)
        weeks = cal.monthdayscalendar(self.visible_year, self.visible_month)
        while len(weeks) < 6:
            weeks.append([0] * 7)
        self.cell_dates = {}
        for row_idx, week in enumerate(weeks[:6], start=1):
            for col_idx, day_num in enumerate(week):
                btn = self.day_buttons[(row_idx, col_idx)]
                if day_num == 0:
                    self.cell_dates[(row_idx, col_idx)] = None
                    btn.configure(text="", state="disabled", bg=THEME["panel"], fg=THEME["muted"])
                    continue
                d = date(self.visible_year, self.visible_month, day_num)
                self.cell_dates[(row_idx, col_idx)] = d
                day_key = d.isoformat()
                occurrences = self.store.occurrences_on(d)
                count = event_days.get(day_key, 0)
                recurring_count = len([occ for occ in occurrences if occ.event.recurrence != "None"])
                holiday_count = len(holiday_days.get(day_key, []))
                markers = []
                if count:
                    markers.append(f"●{count}")
                if recurring_count:
                    markers.append(f"↻{recurring_count}")
                if holiday_count:
                    markers.append(f"★{holiday_count}")
                marker_text = "\n" + " ".join(markers) if markers else ""
                text = f"{day_num}{marker_text}"
                bg = THEME["panel2"]
                fg = THEME["text"]
                if d.isoformat() == today_s:
                    fg = THEME["cyan"]
                if d.isoformat() == selected_s:
                    bg = THEME["gold"]
                    fg = "#111111"
                btn.configure(text=text, state="normal", bg=bg, fg=fg)

    def select_cell(self, row: int, col: int) -> None:
        d = self.cell_dates.get((row, col))
        if d:
            self.selected_date = d
            self.refresh_all()

    def refresh_day_events(self, occurrences: Optional[List[CalendarItem]] = None, title: Optional[str] = None, include_date: bool = False) -> None:
        if occurrences is None:
            occurrences = self.visible_items(self.selected_date, 1)
            title = f"{self.selected_date.strftime('%A')}, {format_date(self.selected_date, self.settings)}"
        self.selected_label.configure(text=title or "Events")
        self.event_list.delete(0, "end")
        self.current_occurrences = occurrences
        for occ in occurrences:
            self.event_list.insert("end", occ.line(include_date=include_date, settings=self.settings))
        self.set_details("Select an event to see details." if occurrences else "No events for this view.")

    def set_details(self, text: str) -> None:
        self.details.configure(state="normal")
        self.details.delete("1.0", "end")
        self.details.insert("1.0", text)
        self.details.configure(state="disabled")

    def selected_occurrence(self) -> Optional[CalendarItem]:
        sel = self.event_list.curselection()
        if not sel:
            return None
        idx = sel[0]
        if idx >= len(self.current_occurrences):
            return None
        return self.current_occurrences[idx]

    def show_selected_event(self) -> None:
        occ = self.selected_occurrence()
        if not occ:
            return
        if isinstance(occ, HolidayOccurrence):
            region_line = f"\nState/Territory: {occ.region}" if occ.region else ""
            text = textwrap.dedent(f"""
            {occ.title}
            Date: {format_date(occ.date, self.settings)}
            Type: Public holiday
            Country: {occ.country}{region_line}

            Public holidays are read-only calendar markers. Blank state/territory means Australia-wide. Change or disable them in Settings.
            """).strip()
            self.set_details(text)
            return
        event = occ.event
        end = ""
        if event.end_date or event.end_time:
            end = f"\nEnd: {format_date(event.end_date or event.start_date, self.settings)} {event.end_time}".rstrip()
        repeat = event.recurrence
        if event.recurrence_until:
            repeat += f" until {format_date(event.recurrence_until, self.settings)}"
        reminder = f"{event.reminder_minutes} minutes before" if event.reminder_minutes else "Off"
        occurrence_note = ""
        if occ.date != event.start_date:
            occurrence_note = f"\nOccurrence: {format_date(occ.date, self.settings)}"
        text = textwrap.dedent(f"""
        {event.title}
        Date: {format_date(event.start_date, self.settings)} {event.start_time or '(all day)'}{end}{occurrence_note}
        Category: {event.category}
        Reminder: {reminder}
        Repeats: {repeat}
        Location: {event.location or '-'}

        Notes:
        {event.notes or '-'}

        ID: {event.id}
        Updated: {event.updated_at}
        """).strip()
        self.set_details(text)

    def add_event(self) -> None:
        dialog = EventDialog(self, "Add Event", selected_date=self.selected_date, settings=self.settings)
        self.wait_window(dialog)
        if dialog.result:
            event = Event.create(**dialog.result)
            self.store.add(event)
            self.selected_date = parse_date(event.start_date)
            self.visible_year = self.selected_date.year
            self.visible_month = self.selected_date.month
            self.refresh_all()

    def edit_event(self) -> None:
        occ = self.selected_occurrence()
        if not occ:
            messagebox.showinfo(APP_NAME, "Select an event first.", parent=self)
            return
        if isinstance(occ, HolidayOccurrence):
            messagebox.showinfo(APP_NAME, "Public holidays are read-only. Change them in Settings.", parent=self)
            return
        event = occ.event
        dialog = EventDialog(self, "Edit Event", initial=event, settings=self.settings)
        self.wait_window(dialog)
        if dialog.result:
            self.store.update(event.id, **dialog.result)
            self.selected_date = parse_date(str(dialog.result["start_date"]))
            self.visible_year = self.selected_date.year
            self.visible_month = self.selected_date.month
            self.refresh_all()

    def delete_event(self) -> None:
        occ = self.selected_occurrence()
        if not occ:
            messagebox.showinfo(APP_NAME, "Select an event first.", parent=self)
            return
        if isinstance(occ, HolidayOccurrence):
            messagebox.showinfo(APP_NAME, "Public holidays are read-only. Disable them in Settings if needed.", parent=self)
            return
        event = occ.event
        should_delete = True
        if bool(self.settings.get("confirm_delete", True)):
            should_delete = messagebox.askyesno(APP_NAME, f"Delete '{event.title}'?\n\nRecurring events delete the series.", parent=self)
        if should_delete:
            self.store.delete(event.id)
            self.refresh_all()

    def prev_month(self) -> None:
        if self.visible_month == 1:
            self.visible_month = 12
            self.visible_year -= 1
        else:
            self.visible_month -= 1
        self.selected_date = date(self.visible_year, self.visible_month, min(self.selected_date.day, pycalendar.monthrange(self.visible_year, self.visible_month)[1]))
        self.refresh_all()

    def next_month(self) -> None:
        if self.visible_month == 12:
            self.visible_month = 1
            self.visible_year += 1
        else:
            self.visible_month += 1
        self.selected_date = date(self.visible_year, self.visible_month, min(self.selected_date.day, pycalendar.monthrange(self.visible_year, self.visible_month)[1]))
        self.refresh_all()

    def go_today(self) -> None:
        self.selected_date = date.today()
        self.visible_year = self.selected_date.year
        self.visible_month = self.selected_date.month
        self.refresh_all()

    def quit_app(self) -> None:
        self.destroy()

    def open_settings(self) -> None:
        dialog = SettingsDialog(self, self.settings)
        self.wait_window(dialog)
        if dialog.result:
            save_settings(dialog.result)
            self.settings = load_settings()
            self.show_public_holidays_var.set(bool(self.settings.get("show_public_holidays", True)))
            self.refresh_all()

    def combined_upcoming(self, days: int = 14) -> List[CalendarItem]:
        return combined_calendar_items(
            self.store, date.today(), days, settings=self.settings, category=self.active_category(),
            item_type=self.active_item_type(), show_user_events=bool(self.show_user_events_var.get()),
            show_public_holidays=bool(self.show_public_holidays_var.get()),
        )

    def show_today(self) -> None:
        self.selected_date = date.today()
        self.visible_year = self.selected_date.year
        self.visible_month = self.selected_date.month
        self.refresh_month()
        self.refresh_day_events(title="Today", include_date=False)

    def show_week(self) -> None:
        start = week_start(self.selected_date, self.settings)
        end = start + timedelta(days=6)
        items = self.visible_items(start, 7)
        title = f"Week View: {format_date(start, self.settings)} – {format_date(end, self.settings)}"
        self.refresh_day_events(items, title, include_date=True)

    def show_agenda(self) -> None:
        items = self.visible_items(self.selected_date, DEFAULT_AGENDA_DAYS)
        end = self.selected_date + timedelta(days=DEFAULT_AGENDA_DAYS - 1)
        title = f"Agenda: {format_date(self.selected_date, self.settings)} – {format_date(end, self.settings)}"
        self.refresh_day_events(items, title, include_date=True)

    def show_upcoming(self) -> None:
        self.refresh_day_events(self.combined_upcoming(14), "Upcoming 14 Days", include_date=True)

    def show_all_events(self) -> None:
        items = search_calendar_items(
            self.store, "", settings=self.settings, category=self.active_category(),
            item_type=self.active_item_type(), show_user_events=bool(self.show_user_events_var.get()),
            show_public_holidays=bool(self.show_public_holidays_var.get()),
        )
        self.refresh_day_events(items, "All Searchable Calendar Items", include_date=True)


    def show_suite_summary(self) -> None:
        lines = human_suite_summary(self.store, settings=self.settings).splitlines()
        self.event_list.delete(0, "end")
        for line in lines:
            self.event_list.insert("end", line)
        self.event_index = []
        self.selected_label.config(text="Sentinel Suite Summary")
        self.set_details("Sentinel Suite integration summary. Use CLI --export-suite-hooks to write machine-readable hook files for Sentinel Tasks, Sentinel Diary, AEGIS, and Sentinel Command.")

    def search_events(self) -> None:
        term = self.search_var.get().strip()
        occurrences = search_calendar_items(
            self.store, term, settings=self.settings, category=self.active_category(),
            item_type=self.active_item_type(), show_user_events=bool(self.show_user_events_var.get()),
            show_public_holidays=bool(self.show_public_holidays_var.get()),
        )
        self.refresh_day_events(occurrences, f"Search: {term or 'all calendar items'}", include_date=True)

    def jump_to_date(self) -> None:
        value = simpledialog.askstring(
            APP_NAME,
            f"Enter date ({date_format_label(self.settings)} or YYYY-MM-DD):",
            initialvalue=format_date(self.selected_date, self.settings),
            parent=self,
        )
        if value is None:
            return
        try:
            target = parse_date(value)
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc), parent=self)
            return
        self.selected_date = target
        self.visible_year = target.year
        self.visible_month = target.month
        self.refresh_all()

    def clear_search(self) -> None:
        self.search_var.set("")
        self.refresh_day_events()

    def export_dialog(self) -> None:
        path = filedialog.asksaveasfilename(title="Export Sentinel Calendar", defaultextension=".ics", filetypes=[("iCalendar", "*.ics"), ("All files", "*.*")])
        if not path:
            return
        try:
            count = export_ics(self.store.events, Path(path))
            messagebox.showinfo(APP_NAME, f"Exported {count} events.", parent=self)
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc), parent=self)

    def export_range_dialog(self) -> None:
        start_value = simpledialog.askstring(APP_NAME, f"Export start date ({date_format_label(self.settings)} or YYYY-MM-DD):", initialvalue=format_date(self.selected_date, self.settings), parent=self)
        if start_value is None:
            return
        end_value = simpledialog.askstring(APP_NAME, f"Export end date ({date_format_label(self.settings)} or YYYY-MM-DD):", initialvalue=format_date(self.selected_date + timedelta(days=30), self.settings), parent=self)
        if end_value is None:
            return
        path = filedialog.asksaveasfilename(title="Export Sentinel Calendar Date Range", defaultextension=".ics", filetypes=[("iCalendar", "*.ics"), ("All files", "*.*")])
        if not path:
            return
        try:
            count = export_ics_range(self.store, start_value, end_value, Path(path))
            messagebox.showinfo(APP_NAME, f"Exported {count} events from {start_value} to {end_value}.", parent=self)
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc), parent=self)

    def import_dialog(self) -> None:
        path = filedialog.askopenfilename(title="Import iCalendar file", filetypes=[("iCalendar", "*.ics"), ("All files", "*.*")])
        if not path:
            return
        try:
            preview = import_ics_preview_payload(Path(path), self.store)
            total = int(preview.get("total_events", 0))
            duplicates = int(preview.get("duplicate_count", 0))
            importable = int(preview.get("importable_count", 0))
            if total <= 0:
                messagebox.showinfo(APP_NAME, "No importable VEVENT entries were found in that ICS file.", parent=self)
                return
            confirm = messagebox.askyesno(
                APP_NAME,
                "ICS import preview:\n\n"
                f"Total events found: {total}\n"
                f"Duplicates to skip: {duplicates}\n"
                f"Events to import: {importable}\n\n"
                "A local backup will be created before import. Continue?",
                parent=self,
            )
            if not confirm:
                return
            backup = self.store.backup_now()
            added = 0
            skipped = 0
            for event in import_ics(Path(path)):
                if self.store.add_imported(event, dedupe=True):
                    added += 1
                else:
                    skipped += 1
            self.refresh_all()
            messagebox.showinfo(APP_NAME, f"Imported {added} events. Skipped {skipped} duplicate(s).\nBackup: {backup}", parent=self)
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc), parent=self)


# ------------------------- Sentinel Suite integration hooks -------------------------

def sentinel_suite_dir() -> Path:
    override = os.environ.get("SENTINEL_SUITE_HOME")
    if override:
        return Path(override).expanduser()
    xdg = os.environ.get("XDG_DATA_HOME")
    base = Path(xdg).expanduser() if xdg else Path.home() / ".local" / "share"
    return base / "sentinel_suite"


def sentinel_suite_status_dir() -> Path:
    return sentinel_suite_dir() / "status"


def sentinel_calendar_hook_dir() -> Path:
    return sentinel_suite_dir() / "hooks" / APP_ID


def ensure_suite_dirs() -> None:
    sentinel_suite_status_dir().mkdir(parents=True, exist_ok=True)
    sentinel_calendar_hook_dir().mkdir(parents=True, exist_ok=True)


def suite_status_path() -> Path:
    return sentinel_suite_status_dir() / f"{APP_ID}.status.json"


def suite_hook_path(name: str) -> Path:
    return sentinel_calendar_hook_dir() / name


def calendar_item_to_dict(item: CalendarItem, settings: Optional[Dict[str, object]] = None) -> Dict[str, object]:
    settings = settings or load_settings()
    if isinstance(item, HolidayOccurrence):
        return {
            "type": "public_holiday",
            "source_program": PROGRAM_NUMBER,
            "source_app": APP_NAME,
            "title": item.title,
            "date": item.date,
            "display_date": format_date(item.date, settings),
            "time": "All day",
            "category": "Public Holiday",
            "country": item.country,
            "region": item.region,
            "region_label": item.region or "",
            "read_only": True,
            "marker": "★",
        }
    event = item.event
    return {
        "type": "calendar_event",
        "source_program": PROGRAM_NUMBER,
        "source_app": APP_NAME,
        "event_id": event.id,
        "title": event.title,
        "date": item.date,
        "display_date": format_date(item.date, settings),
        "start_date": event.start_date,
        "start_time": event.start_time,
        "end_date": event.end_date,
        "end_time": event.end_time,
        "time": event.display_time(),
        "location": event.location,
        "category": event.category,
        "notes": event.notes,
        "reminder_minutes": event.reminder_minutes,
        "recurrence": event.recurrence,
        "recurrence_until": event.recurrence_until,
        "recurrence_exdates": event.recurrence_exdates,
        "source_uid": event.source_uid,
        "is_recurring_occurrence": event.recurrence != "None",
        "read_only": False,
        "marker": "↻" if event.recurrence != "None" else "●",
    }


def agenda_payload(title: str, items: Sequence[CalendarItem], settings: Optional[Dict[str, object]] = None) -> Dict[str, object]:
    settings = settings or load_settings()
    return {
        "app": APP_NAME,
        "program": PROGRAM_NUMBER,
        "version": VERSION,
        "local_only": True,
        "network_required": False,
        "title": title,
        "generated_at": now_iso(),
        "date_format": settings.get("date_format"),
        "count": len(items),
        "items": [calendar_item_to_dict(item, settings) for item in items],
    }


def reminders_payload(store: CalendarStore, minutes: int = 1440, settings: Optional[Dict[str, object]] = None) -> Dict[str, object]:
    settings = settings or load_settings()
    due = store.reminders_due(minutes)
    return {
        "app": APP_NAME,
        "program": PROGRAM_NUMBER,
        "version": VERSION,
        "type": "calendar_reminders",
        "window_minutes": minutes,
        "generated_at": now_iso(),
        "count": len(due),
        "items": [
            {
                "event": calendar_item_to_dict(occ, settings),
                "event_datetime": event_dt.replace(microsecond=0).isoformat(),
                "reminder_datetime": reminder_dt.replace(microsecond=0).isoformat(),
                "display_reminder_date": format_date(reminder_dt.date(), settings),
                "display_event_date": format_date(event_dt.date(), settings),
            }
            for occ, event_dt, reminder_dt in due
        ],
    }


def tasks_feed_payload(store: CalendarStore, days: int = 30, settings: Optional[Dict[str, object]] = None) -> Dict[str, object]:
    """Return read-only task candidates for Sentinel Tasks without modifying Tasks data."""
    settings = settings or load_settings()
    items = combined_calendar_items(store, date.today(), max(1, days), settings=settings, item_type="user")
    task_items = []
    for item in items:
        if isinstance(item, HolidayOccurrence):
            continue
        event = item.event
        task_items.append({
            "type": "calendar_task_candidate",
            "source_program": PROGRAM_NUMBER,
            "source_app": APP_NAME,
            "source_event_id": event.id,
            "title": event.title,
            "due_date": item.date,
            "display_due_date": format_date(item.date, settings),
            "due_time": event.start_time,
            "category": event.category,
            "location": event.location,
            "notes": event.notes,
            "reminder_minutes": event.reminder_minutes,
            "recurrence": event.recurrence,
            "read_only": True,
            "integration_note": "Sentinel Tasks may import or reference this item; Sentinel Calendar does not alter Tasks data directly.",
        })
    return {
        "app": APP_NAME,
        "program": PROGRAM_NUMBER,
        "version": VERSION,
        "type": "sentinel_tasks_feed",
        "target_app": "Sentinel Tasks",
        "target_program": "105",
        "generated_at": now_iso(),
        "window_days": days,
        "count": len(task_items),
        "items": task_items,
    }


def diary_feed_payload(store: CalendarStore, target_day: date | str, settings: Optional[Dict[str, object]] = None) -> Dict[str, object]:
    """Return a read-only day context package for Sentinel Diary."""
    settings = settings or load_settings()
    day = parse_date(target_day) if isinstance(target_day, str) else target_day
    items = combined_calendar_items(store, day, 1, settings=settings)
    user_events = [item for item in items if not isinstance(item, HolidayOccurrence)]
    holidays = [item for item in items if isinstance(item, HolidayOccurrence)]
    return {
        "app": APP_NAME,
        "program": PROGRAM_NUMBER,
        "version": VERSION,
        "type": "sentinel_diary_day_context",
        "target_app": "Sentinel Diary",
        "target_program": "106",
        "generated_at": now_iso(),
        "date": day.isoformat(),
        "display_date": format_date(day, settings),
        "event_count": len(user_events),
        "public_holiday_count": len(holidays),
        "items": [calendar_item_to_dict(item, settings) for item in items],
        "journal_context": {
            "summary": f"{len(user_events)} calendar event(s), {len(holidays)} public holiday item(s).",
            "suggested_tags": sorted({calendar_item_to_dict(item, settings).get("category", "Calendar") for item in items}),
            "read_only": True,
        },
    }


def today_summary_payload(store: CalendarStore, settings: Optional[Dict[str, object]] = None) -> Dict[str, object]:
    settings = settings or load_settings()
    today = date.today()
    today_items = combined_calendar_items(store, today, 1, settings=settings)
    upcoming_items = combined_calendar_items(store, today, 7, settings=settings)
    payload = {
        "app": APP_NAME,
        "program": PROGRAM_NUMBER,
        "version": VERSION,
        "type": "sentinel_suite_today_summary",
        "generated_at": now_iso(),
        "today": today.isoformat(),
        "display_today": format_date(today, settings),
        "today_count": len(today_items),
        "upcoming_7_days_count": len(upcoming_items),
        "reminders_next_24h_count": len(store.reminders_due(1440)),
        "today_items": [calendar_item_to_dict(item, settings) for item in today_items],
        "upcoming_7_days": [calendar_item_to_dict(item, settings) for item in upcoming_items],
        "hook_paths": {
            "suite_status": str(suite_status_path()),
            "calendar_hooks": str(sentinel_calendar_hook_dir()),
        },
        "integration_targets": ["AEGIS", "Sentinel Command", "Sentinel Tasks", "Sentinel Diary"],
    }
    return payload


def human_suite_summary(store: CalendarStore, settings: Optional[Dict[str, object]] = None) -> str:
    settings = settings or load_settings()
    payload = today_summary_payload(store, settings)
    lines = [
        f"{APP_NAME} v{VERSION} — Sentinel Suite Summary",
        f"Today: {payload['display_today']}",
        f"Today items: {payload['today_count']}",
        f"Upcoming 7 days: {payload['upcoming_7_days_count']}",
        f"Reminders next 24h: {payload['reminders_next_24h_count']}",
        "",
        "Today",
    ]
    if not payload["today_items"]:
        lines.append("  No events.")
    else:
        for item in payload["today_items"]:
            lines.append(f"  - {item.get('time', '')} [{item.get('category', '')}] {item.get('title', '')}")
    lines.extend(["", "Integration hooks", f"  Status: {suite_status_path()}", f"  Hooks:  {sentinel_calendar_hook_dir()}"])
    return "\n".join(lines)


def suite_status_payload(store: CalendarStore, settings: Optional[Dict[str, object]] = None) -> Dict[str, object]:
    settings = settings or load_settings()
    return {
        "app": APP_NAME,
        "program": PROGRAM_NUMBER,
        "version": VERSION,
        "local_only": True,
        "network_required": False,
        "generated_at": now_iso(),
        "status": "ready",
        "capabilities": {
            "gui": True,
            "today_summary": True,
            "today_json": True,
            "upcoming_json": True,
            "holidays_json": True,
            "reminders_json": True,
            "tasks_feed": True,
            "diary_feed": True,
            "suite_hook_export": True,
            "ics_import_export": True,
            "public_holidays": True,
            "recurring_events": True,
            "themed_dropdowns": True,
            "desktop_reminder_daemon": True,
            "reminder_dismiss_snooze": True,
            "recurrence_exceptions": True,
            "single_occurrence_split": True,
            "settings_lock": True,
            "ics_import_preview": True,
            "ics_duplicate_detection": True,
            "range_export": True,
            "v0_7_0_import_export_hardening": True,
            "gui_ics_import_preview": True,
            "gui_ics_backup_before_import": True,
            "gui_ics_range_export": True,
            "version_ledger": True,
            "release_candidate_checks": True,
        },
        "paths": {
            "data_dir": str(app_data_dir()),
            "config_dir": str(config_dir()),
            "settings": str(settings_path()),
            "events": str(events_path()),
            "suite_dir": str(sentinel_suite_dir()),
            "suite_status": str(suite_status_path()),
            "suite_hooks": str(sentinel_calendar_hook_dir()),
        },
        "counts": {
            "events": len(store.events),
            "recurring_events": len([event for event in store.events if event.recurrence != "None"]),
            "reminder_events": len([event for event in store.events if event.reminder_minutes]),
            "today_items": len(combined_calendar_items(store, date.today(), 1, settings=settings)),
            "upcoming_7_days": len(combined_calendar_items(store, date.today(), 7, settings=settings)),
        },
        "settings": {
            "date_format": settings.get("date_format"),
            "public_holidays_enabled": settings.get("show_public_holidays"),
            "public_holiday_country": settings.get("holiday_country"),
            "public_holiday_region": settings.get("holiday_region"),
            "first_day_of_week": settings.get("first_day_of_week"),
            "default_category": settings.get("default_category"),
            "default_reminder_minutes": settings.get("default_reminder_minutes"),
            "startup_view": settings.get("startup_view"),
            "confirm_delete": settings.get("confirm_delete"),
            "backup_keep": settings.get("backup_keep"),
            "notifications_enabled": settings.get("notifications_enabled"),
            "notification_sound": settings.get("notification_sound"),
        },
    }


def write_json_file(path: Path, payload: Dict[str, object]) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    tmp.replace(path)
    return path


def export_suite_hooks(store: CalendarStore, days: int = 30, diary_day: Optional[date] = None) -> Dict[str, str]:
    settings = load_settings()
    ensure_suite_dirs()
    diary_day = diary_day or date.today()
    paths = {
        "suite_status": write_json_file(suite_status_path(), suite_status_payload(store, settings)),
        "today_summary": write_json_file(suite_hook_path("today_summary.json"), today_summary_payload(store, settings)),
        "upcoming": write_json_file(suite_hook_path("upcoming_30_days.json"), agenda_payload("Upcoming 30 Days", combined_calendar_items(store, date.today(), days, settings=settings), settings)),
        "tasks_feed": write_json_file(suite_hook_path("sentinel_tasks_feed.json"), tasks_feed_payload(store, days, settings)),
        "diary_context": write_json_file(suite_hook_path("sentinel_diary_context.json"), diary_feed_payload(store, diary_day, settings)),
        "reminders": write_json_file(suite_hook_path("reminders_next_24h.json"), reminders_payload(store, 1440, settings)),
    }
    return {name: str(path) for name, path in paths.items()}


# ------------------------- CLI/status helpers -------------------------

def user_menu_launcher_path() -> Path:
    return Path.home() / ".local" / "share" / "applications" / "sentinel-calendar.desktop"


def user_desktop_path() -> Path:
    try:
        xdg_desktop = os.popen("xdg-user-dir DESKTOP 2>/dev/null").read().strip()
    except Exception:
        xdg_desktop = ""
    return Path(xdg_desktop).expanduser() / "Sentinel Calendar.desktop" if xdg_desktop else Path.home() / "Desktop" / "Sentinel Calendar.desktop"


def doctor() -> int:
    checks = []
    checks.append(("Python", sys.version.split()[0], True))
    checks.append(("Tkinter", "available" if tk else "missing", bool(tk)))
    data = app_data_dir()
    ensure_dirs()
    checks.append(("Data directory", str(data), data.exists() and os.access(data, os.W_OK)))
    store_path = events_path()
    if not store_path.exists():
        CalendarStore().save(backup=False)
    checks.append(("Event store", str(store_path), store_path.exists() and os.access(store_path, os.W_OK)))
    checks.append(("System menu launcher", "/usr/share/applications/sentinel-calendar.desktop", Path("/usr/share/applications/sentinel-calendar.desktop").exists()))
    checks.append(("User menu launcher", str(user_menu_launcher_path()), user_menu_launcher_path().exists()))
    checks.append(("Desktop launcher", str(user_desktop_path()), user_desktop_path().exists()))
    ensure_suite_dirs()
    checks.append(("Sentinel Suite status directory", str(sentinel_suite_status_dir()), sentinel_suite_status_dir().exists() and os.access(sentinel_suite_status_dir(), os.W_OK)))
    checks.append(("Sentinel Calendar hook directory", str(sentinel_calendar_hook_dir()), sentinel_calendar_hook_dir().exists() and os.access(sentinel_calendar_hook_dir(), os.W_OK)))
    checks.append(("Settings file", str(settings_path()), settings_path().exists() or config_dir().exists()))
    checks.append(("Reminder state path", str(reminder_state_path()), reminder_state_path().parent.exists() and os.access(reminder_state_path().parent, os.W_OK)))
    checks.append(("Version ledger", "v0.7.0/v0.8.0/v0.9.0/v1.0.0/v1.0.1", any(item.get("version") == "0.7.0" for item in VERSION_LEDGER)))
    checks.append(("notify-send", shutil.which("notify-send") or "not installed; terminal fallback available", True))

    print(f"{APP_NAME} doctor v{VERSION}")
    ok_all = True
    for name, detail, ok in checks:
        ok_all = ok_all and ok
        status = "OK" if ok else "WARN"
        print(f"[{status}] {name}: {detail}")
    return 0 if ok_all else 1


def print_json(store: CalendarStore) -> None:
    print(json.dumps({"app": APP_NAME, "program": PROGRAM_NUMBER, "version": VERSION, "events": [asdict(e) for e in store.events]}, indent=2, ensure_ascii=False))


def print_agenda(title: str, occurrences: Sequence[CalendarItem]) -> None:
    settings = load_settings()
    print(title)
    if not occurrences:
        print("No events.")
        return
    current_day = ""
    for occ in occurrences:
        if occ.date != current_day:
            current_day = occ.date
            print(f"\n{format_date(current_day, settings)}")
        print(f"  - {occ.line(settings=settings)}")


def aegis_status(store: CalendarStore) -> None:
    settings = load_settings()
    status = {
        "app": APP_NAME,
        "program": PROGRAM_NUMBER,
        "version": VERSION,
        "local_only": True,
        "network_required": False,
        "store_path": str(events_path()),
        "event_count": len(store.events),
        "today_count": len(store.occurrences_on(date.today())),
        "upcoming_7_days_count": len(store.upcoming(7)),
        "recurring_event_count": len([event for event in store.events if event.recurrence != "None"]),
        "reminder_event_count": len([event for event in store.events if event.reminder_minutes]),
        "date_format": settings.get("date_format"),
        "public_holidays_enabled": settings.get("show_public_holidays"),
        "public_holiday_country": settings.get("holiday_country"),
        "public_holiday_region": settings.get("holiday_region"),
        "today_public_holiday_count": len(holiday_occurrences_on(date.today(), settings)),
        "week_view_available": True,
        "agenda_view_available": True,
        "jump_to_date_available": True,
        "filter_categories": FILTER_CATEGORY_CHOICES,
        "search_scan_days": DEFAULT_SEARCH_SCAN_DAYS,
        "sentinel_suite_integration": True,
        "tasks_feed_available": True,
        "diary_feed_available": True,
        "today_summary_available": True,
        "suite_hook_export_available": True,
        "desktop_reminder_daemon_available": True,
        "recurrence_exceptions_available": True,
        "single_occurrence_edit_available": True,
        "settings_lock_available": True,
        "ics_import_preview_available": True,
        "ics_duplicate_detection_available": True,
        "range_export_available": True,
        "suite_status_path": str(suite_status_path()),
        "suite_hook_dir": str(sentinel_calendar_hook_dir()),
        "system_menu_entry": Path("/usr/share/applications/sentinel-calendar.desktop").exists(),
        "user_menu_entry": user_menu_launcher_path().exists(),
        "desktop_launcher": user_desktop_path().exists(),
        "data_dir": str(app_data_dir()),
        "updated_at": now_iso(),
    }
    print(json.dumps(status, indent=2, ensure_ascii=False))


def install_launchers() -> int:
    """Best-effort user launcher creation; must run as the normal desktop user."""
    if os.geteuid() == 0:
        print("Refusing to create user launchers as root. Run this as the normal desktop user.", file=sys.stderr)
        return 2
    home = Path.home()
    icon = Path("/usr/share/pixmaps/sentinel-calendar.png")
    if not icon.exists():
        app_dir = Path(__file__).resolve().parents[2]
        icon = app_dir / "assets" / "sentinel-calendar.png"
    command = shutil.which("sentinel-calendar") or "/usr/bin/sentinel-calendar"
    applications = home / ".local" / "share" / "applications"
    applications.mkdir(parents=True, exist_ok=True)
    desktop_dir = user_desktop_path().parent
    desktop_dir.mkdir(parents=True, exist_ok=True)
    entry = textwrap.dedent(f"""
    [Desktop Entry]
    Version=1.0
    Type=Application
    Name=Sentinel Calendar
    GenericName=Calendar
    Comment=SentinelOS local calendar and schedule layer
    Exec={command}
    Icon={icon}
    Terminal=false
    Categories=Office;Calendar;Utility;
    Keywords=calendar;schedule;events;reminders;sentinel;aegis;
    StartupNotify=true
    """).strip() + "\n"
    menu_file = applications / "sentinel-calendar.desktop"
    desktop_file = desktop_dir / "Sentinel Calendar.desktop"
    menu_file.write_text(entry, encoding="utf-8")
    desktop_file.write_text(entry, encoding="utf-8")
    menu_file.chmod(0o755)
    desktop_file.chmod(0o755)
    try:
        os.system(f"gio set {str(desktop_file)!r} metadata::trusted true >/dev/null 2>&1")
    except Exception:
        pass
    os.system("update-desktop-database ~/.local/share/applications >/dev/null 2>&1 || true")
    print(f"Installed launchers:\n- {menu_file}\n- {desktop_file}")
    return 0


def version_ledger_payload() -> Dict[str, object]:
    return {
        "app": APP_NAME,
        "program": PROGRAM_NUMBER,
        "version": VERSION,
        "type": "version_ledger",
        "note": "v1.0.1 explicitly closes the missing v0.7.0 import/export hardening layer while preserving the v1 stable lock.",
        "ledger": VERSION_LEDGER,
    }


def settings_payload() -> Dict[str, object]:
    settings = load_settings()
    return {"app": APP_NAME, "program": PROGRAM_NUMBER, "version": VERSION, "settings_path": str(settings_path()), "settings": settings}


def set_setting_pair(pair: str) -> None:
    if "=" not in pair:
        raise ValueError("Settings must be KEY=VALUE.")
    key, value = pair.split("=", 1)
    key = key.strip()
    if key not in DEFAULT_SETTINGS:
        raise ValueError(f"Unknown setting: {key}")
    settings = load_settings()
    if isinstance(DEFAULT_SETTINGS[key], bool):
        settings[key] = value.strip().lower() in {"1", "true", "yes", "on"}
    elif isinstance(DEFAULT_SETTINGS[key], int):
        settings[key] = int(value.strip())
    else:
        settings[key] = value.strip()
    save_settings(settings)


def run_self_test() -> int:
    tmp_root = app_data_dir() / "self_test" / datetime.now().strftime("%Y%m%d_%H%M%S")
    tmp_root.mkdir(parents=True, exist_ok=True)
    test_store = CalendarStore(tmp_root / "events.json")
    event = Event.create("Self Test Weekly", date.today().isoformat(), "09:00", recurrence="Weekly", reminder_minutes=5)
    test_store.add(event)
    test_store.skip_occurrence(event.id, (date.today() + timedelta(days=7)).isoformat())
    if test_store.occurrences_on(date.today() + timedelta(days=7)):
        print("Self-test failed: recurrence exception still appears.", file=sys.stderr)
        return 1
    ics_path = tmp_root / "export.ics"
    export_ics(test_store.events, ics_path)
    imported = import_ics(ics_path)
    if not imported:
        print("Self-test failed: ICS import returned no events.", file=sys.stderr)
        return 1
    preview = import_ics_preview_payload(ics_path, test_store)
    if int(preview.get("duplicate_count", 0)) < 1:
        print("Self-test failed: ICS duplicate preview did not detect existing event.", file=sys.stderr)
        return 1
    ledger_versions = {item.get("version") for item in VERSION_LEDGER}
    if not {"0.7.0", "0.8.0", "0.9.0", "1.0.0", "1.0.1"}.issubset(ledger_versions):
        print("Self-test failed: version ledger missing expected update layers.", file=sys.stderr)
        return 1
    print(f"{APP_NAME} self-test v{VERSION}: OK")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=f"{APP_NAME} v{VERSION}")
    parser.add_argument("--version", action="store_true", help="print version and exit")
    parser.add_argument("--doctor", action="store_true", help="run install/data diagnostics")
    parser.add_argument("--install-launchers", action="store_true", help="install user desktop/menu launchers")
    parser.add_argument("--user-setup", action="store_true", help="alias for --install-launchers")
    parser.add_argument("--print-json", action="store_true", help="print stored events as JSON")
    parser.add_argument("--aegis-status", action="store_true", help="print AEGIS-readable local status JSON")
    parser.add_argument("--suite-status", action="store_true", help="print expanded Sentinel Suite status JSON")
    parser.add_argument("--write-suite-status", action="store_true", help="write Sentinel Suite status JSON to shared status path")
    parser.add_argument("--export-suite-hooks", action="store_true", help="write Sentinel Tasks/Diary/AEGIS hook JSON files")
    parser.add_argument("--today-summary", action="store_true", help="print human-readable Sentinel Suite today summary")
    parser.add_argument("--today-json", action="store_true", help="print machine-readable today summary JSON")
    parser.add_argument("--upcoming-json", metavar="DAYS", type=int, nargs="?", const=30, help="print machine-readable upcoming agenda JSON; default 30")
    parser.add_argument("--holidays-json", metavar="YEAR", type=int, help="print machine-readable public holiday JSON for YEAR")
    parser.add_argument("--reminders-json", metavar="MINUTES", type=int, nargs="?", const=1440, help="print machine-readable reminder JSON; default 1440")
    parser.add_argument("--tasks-feed", metavar="DAYS", type=int, nargs="?", const=30, help="print Sentinel Tasks-compatible read-only feed JSON; default 30")
    parser.add_argument("--diary-feed", metavar="DATE", nargs="?", const="", help="print Sentinel Diary-compatible day context JSON; default today")
    parser.add_argument("--today", action="store_true", help="print today's agenda")
    parser.add_argument("--week", action="store_true", help="print the Monday-Sunday week containing today")
    parser.add_argument("--agenda", metavar="DAYS", type=int, nargs="?", const=DEFAULT_AGENDA_DAYS, help="print agenda for DAYS days from today; default 30")
    parser.add_argument("--upcoming", metavar="DAYS", type=int, help="print upcoming agenda for DAYS days")
    parser.add_argument("--search", metavar="TERM", help="search events, recurring occurrences, holidays, notes, categories, dates, and locations")
    parser.add_argument("--filter-category", default=FILTER_CATEGORY_ALL, help="filter agenda/search by category or Public Holiday")
    parser.add_argument("--type", choices=ITEM_TYPE_CHOICES, default="all", help="filter item type for agenda/search/week: all, user, holidays, recurring")
    parser.add_argument("--holidays", metavar="YEAR", type=int, help="print public holidays for YEAR using current settings")
    parser.add_argument("--check-reminders", metavar="MINUTES", type=int, nargs="?", const=60, help="print reminders due within MINUTES minutes; default 60")
    parser.add_argument("--notify-reminders", metavar="MINUTES", type=int, nargs="?", const=5, help="send desktop notifications for reminders due in MINUTES; fallback prints to terminal")
    parser.add_argument("--daemon", action="store_true", help="run local reminder daemon loop")
    parser.add_argument("--daemon-once", action="store_true", help="run one daemon reminder check and exit")
    parser.add_argument("--daemon-interval", type=int, default=60, help="daemon check interval in seconds; default 60")
    parser.add_argument("--dismiss-reminder", metavar="KEY", help="mark a reminder key as dismissed")
    parser.add_argument("--snooze-reminder", nargs=2, metavar=("KEY", "MINUTES"), help="snooze a reminder key")
    parser.add_argument("--skip-occurrence", nargs=2, metavar=("EVENT_ID", "DATE"), help="skip one occurrence of a recurring event")
    parser.add_argument("--restore-occurrence", nargs=2, metavar=("EVENT_ID", "DATE"), help="restore a skipped recurring occurrence")
    parser.add_argument("--edit-occurrence", nargs=2, metavar=("EVENT_ID", "DATE"), help="split one recurring occurrence into a standalone event using supplied --new-* fields")
    parser.add_argument("--new-title", default="", help="replacement title for --edit-occurrence")
    parser.add_argument("--new-date", default="", help="replacement date for --edit-occurrence")
    parser.add_argument("--new-time", default=None, help="replacement start time for --edit-occurrence")
    parser.add_argument("--new-end-date", default=None, help="replacement end date for --edit-occurrence")
    parser.add_argument("--new-end-time", default=None, help="replacement end time for --edit-occurrence")
    parser.add_argument("--settings-json", action="store_true", help="print Calendar Settings JSON")
    parser.add_argument("--set-setting", action="append", default=[], metavar="KEY=VALUE", help="update a Calendar Settings value")
    parser.add_argument("--self-test", action="store_true", help="run local release-candidate self-test")
    parser.add_argument("--version-ledger", action="store_true", help="print included version/update ledger JSON")
    parser.add_argument("--backup-now", action="store_true", help="create a manual local backup now")
    parser.add_argument("--export-ics", metavar="PATH", help="export all events to .ics")
    parser.add_argument("--export-ics-range", nargs=3, metavar=("START", "END", "PATH"), help="export events whose start dates fall within START..END")
    parser.add_argument("--import-ics-preview", metavar="PATH", help="preview .ics import with duplicate count and no data changes")
    parser.add_argument("--import-ics", metavar="PATH", help="import events from .ics with backup and duplicate detection")
    parser.add_argument("--add", metavar="TITLE", help="add an event from CLI")
    parser.add_argument("--date", dest="event_date", help="event date for --add; default DD/MM/YYYY, ISO YYYY-MM-DD accepted")
    parser.add_argument("--time", dest="event_time", default="", help="event time HH:MM for --add")
    parser.add_argument("--end-date", default="", help="optional event end date; selected date format or ISO accepted")
    parser.add_argument("--end-time", default="", help="optional event end time HH:MM for --add")
    parser.add_argument("--location", default="", help="event location for --add")
    parser.add_argument("--category", default="General", help="event category for --add")
    parser.add_argument("--notes", default="", help="event notes for --add")
    parser.add_argument("--reminder", default="0", help="minutes before event for reminder")
    parser.add_argument("--recurrence", default="None", help="None, Daily, Weekly, Monthly, or Yearly")
    parser.add_argument("--until", default="", help="recurrence end date; selected date format or ISO accepted")
    return parser


def main(argv: Optional[List[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.version:
        print(f"{APP_NAME} {VERSION}")
        return 0
    if args.doctor:
        return doctor()
    if args.install_launchers or args.user_setup:
        return install_launchers()

    store = CalendarStore()
    if args.self_test:
        return run_self_test()
    if args.version_ledger:
        print(json.dumps(version_ledger_payload(), indent=2, ensure_ascii=False))
        return 0
    if args.settings_json:
        print(json.dumps(settings_payload(), indent=2, ensure_ascii=False))
        return 0
    if args.set_setting:
        for pair in args.set_setting:
            set_setting_pair(pair)
        print(json.dumps(settings_payload(), indent=2, ensure_ascii=False))
        return 0
    if args.dismiss_reminder:
        dismiss_reminder(args.dismiss_reminder)
        print(f"Dismissed reminder: {args.dismiss_reminder}")
        return 0
    if args.snooze_reminder:
        key, minutes = args.snooze_reminder
        snooze_reminder(key, int(minutes))
        print(f"Snoozed reminder: {key} for {minutes} minutes")
        return 0
    if args.notify_reminders is not None:
        print(json.dumps(notify_due_reminders(store, args.notify_reminders), indent=2, ensure_ascii=False))
        return 0
    if args.daemon or args.daemon_once:
        return run_reminder_daemon(store, interval_seconds=args.daemon_interval, window_minutes=5, once=args.daemon_once)
    if args.skip_occurrence:
        event_id, occurrence_date = args.skip_occurrence
        event = store.skip_occurrence(event_id, occurrence_date)
        print(f"Skipped occurrence for {event.title}: {format_date(occurrence_date, load_settings())}")
        return 0
    if args.restore_occurrence:
        event_id, occurrence_date = args.restore_occurrence
        event = store.restore_occurrence(event_id, occurrence_date)
        print(f"Restored occurrence for {event.title}: {format_date(occurrence_date, load_settings())}")
        return 0
    if args.edit_occurrence:
        event_id, occurrence_date = args.edit_occurrence
        fields = {
            "title": args.new_title or None,
            "start_date": args.new_date or occurrence_date,
            "start_time": args.new_time,
            "end_date": args.new_end_date,
            "end_time": args.new_end_time,
            "location": args.location or None,
            "category": args.category or None,
            "notes": args.notes or None,
            "reminder_minutes": args.reminder if args.reminder != "0" else None,
        }
        event = store.split_occurrence(event_id, occurrence_date, **fields)
        print(f"Created standalone occurrence: {format_date(event.start_date, load_settings())} {event.display_time()} {event.title}")
        return 0
    if args.add:
        event_date = args.event_date or date.today().isoformat()
        event = Event.create(
            title=args.add,
            start_date=event_date,
            start_time=args.event_time,
            end_date=args.end_date,
            end_time=args.end_time,
            location=args.location,
            category=args.category,
            notes=args.notes,
            reminder_minutes=args.reminder,
            recurrence=args.recurrence,
            recurrence_until=args.until,
        )
        store.add(event)
        print(f"Added event: {format_date(event.start_date, load_settings())} {event.display_time()} {event.title}")
        return 0
    if args.print_json:
        print_json(store)
        return 0
    if args.aegis_status:
        aegis_status(store)
        return 0
    if args.suite_status:
        print(json.dumps(suite_status_payload(store), indent=2, ensure_ascii=False))
        return 0
    if args.write_suite_status:
        path = write_json_file(suite_status_path(), suite_status_payload(store))
        print(f"Wrote Sentinel Suite status: {path}")
        return 0
    if args.export_suite_hooks:
        paths = export_suite_hooks(store)
        print("Exported Sentinel Suite hooks:")
        for name, path in paths.items():
            print(f"- {name}: {path}")
        return 0
    if args.today_summary:
        print(human_suite_summary(store))
        return 0
    if args.today_json:
        print(json.dumps(today_summary_payload(store), indent=2, ensure_ascii=False))
        return 0
    if args.upcoming_json is not None:
        settings = load_settings()
        days = max(1, args.upcoming_json)
        items = combined_calendar_items(store, date.today(), days, settings=settings, category=args.filter_category, item_type=args.type)
        print(json.dumps(agenda_payload(f"Upcoming {days} Days", items, settings), indent=2, ensure_ascii=False))
        return 0
    if args.holidays_json is not None:
        settings = load_settings()
        items: List[CalendarItem] = []
        for day_s, names in sorted(public_holidays_for_year(args.holidays_json, settings).items()):
            for name in names:
                items.append(HolidayOccurrence(name, day_s, str(settings.get("holiday_country", "Australia")), holiday_region_from_title(name)))
        print(json.dumps(agenda_payload(f"Public Holidays {args.holidays_json}", sorted(items, key=lambda item: item.sort_key()), settings), indent=2, ensure_ascii=False))
        return 0
    if args.reminders_json is not None:
        print(json.dumps(reminders_payload(store, max(1, args.reminders_json)), indent=2, ensure_ascii=False))
        return 0
    if args.tasks_feed is not None:
        print(json.dumps(tasks_feed_payload(store, max(1, args.tasks_feed)), indent=2, ensure_ascii=False))
        return 0
    if args.diary_feed is not None:
        target = args.diary_feed or date.today().isoformat()
        print(json.dumps(diary_feed_payload(store, target), indent=2, ensure_ascii=False))
        return 0
    if args.today:
        settings = load_settings()
        today_items = combined_calendar_items(store, date.today(), 1, settings=settings, category=args.filter_category, item_type=args.type)
        print_agenda("Today", today_items)
        return 0
    if args.week:
        settings = load_settings()
        start = week_start(date.today(), settings)
        end = start + timedelta(days=6)
        items = combined_calendar_items(store, start, 7, settings=settings, category=args.filter_category, item_type=args.type)
        print_agenda(f"Week {format_date(start, settings)} – {format_date(end, settings)}", items)
        return 0
    if args.agenda is not None:
        settings = load_settings()
        days = max(1, args.agenda)
        items = combined_calendar_items(store, date.today(), days, settings=settings, category=args.filter_category, item_type=args.type)
        print_agenda(f"Agenda {days} Days", items)
        return 0
    if args.search is not None:
        settings = load_settings()
        items = search_calendar_items(store, args.search, settings=settings, category=args.filter_category, item_type=args.type)
        print_agenda(f"Search: {args.search or 'all calendar items'}", items)
        return 0
    if args.holidays is not None:
        settings = load_settings()
        items: List[CalendarItem] = []
        for day_s, names in sorted(public_holidays_for_year(args.holidays, settings).items()):
            for name in names:
                items.append(HolidayOccurrence(name, day_s, str(settings.get("holiday_country", "Australia")), holiday_region_from_title(name)))
        print_agenda(f"Public Holidays {args.holidays}", sorted(items, key=lambda item: item.sort_key()))
        return 0
    if args.upcoming is not None:
        settings = load_settings()
        upcoming_items = combined_calendar_items(store, date.today(), args.upcoming, settings=settings, category=args.filter_category, item_type=args.type)
        print_agenda(f"Upcoming {args.upcoming} Days", upcoming_items)
        return 0
    if args.check_reminders is not None:
        due = store.reminders_due(args.check_reminders)
        if not due:
            print(f"No reminders due in the next {args.check_reminders} minutes.")
        else:
            print(f"Reminders due in the next {args.check_reminders} minutes:")
            for occ, event_dt, reminder_dt in due:
                settings = load_settings()
                print(f"- {format_date(reminder_dt.date(), settings)} {reminder_dt.strftime('%H:%M')} reminder for {format_date(event_dt.date(), settings)} {event_dt.strftime('%H:%M')} — {occ.event.title}")
        return 0
    if args.backup_now:
        backup = store.backup_now()
        print(f"Created backup: {backup}")
        return 0
    if args.export_ics_range:
        start_s, end_s, path_s = args.export_ics_range
        count = export_ics_range(store, start_s, end_s, Path(path_s).expanduser())
        print(f"Exported {count} events to {path_s}")
        return 0
    if args.export_ics:
        count = export_ics(store.events, Path(args.export_ics).expanduser())
        print(f"Exported {count} events to {args.export_ics}")
        return 0
    if args.import_ics_preview:
        print(json.dumps(import_ics_preview_payload(Path(args.import_ics_preview).expanduser(), store), indent=2, ensure_ascii=False))
        return 0
    if args.import_ics:
        backup = store.backup_now()
        imported = import_ics(Path(args.import_ics).expanduser())
        added = 0
        skipped = 0
        for event in imported:
            if store.add_imported(event, dedupe=True):
                added += 1
            else:
                skipped += 1
        print(f"Imported {added} events from {args.import_ics}; skipped {skipped} duplicate(s). Backup: {backup}")
        return 0

    if not tk:
        print("Tkinter is not available. Install python3-tk or run with --help for CLI options.", file=sys.stderr)
        return 2
    app = SentinelCalendarApp(store)
    app.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
