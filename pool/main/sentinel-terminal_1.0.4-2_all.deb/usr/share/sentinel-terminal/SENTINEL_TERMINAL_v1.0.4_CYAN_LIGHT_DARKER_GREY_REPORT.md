# Sentinel Terminal v1.0.4 Darker Cyan Light Grey Report

## Purpose

This hotfix responds to the suite theming correction that `Sentinel Cyan Light` should go darker grey. The theme remains the selectable lighter cyan option, but its base is now medium/darker grey rather than pale grey or white.

## Updated Cyan Light palette

| Token | Value | Purpose |
|---|---:|---|
| window_bg | `#879399` | main window/dialog base |
| panel | `#77848B` | menu/status/basic panel base |
| panel_2 | `#687780` | selected tab/menu hover/panel contrast |
| panel_3 | `#596B75` | strongest grey surface contrast |
| entry_bg | `#93A0A5` | text entries/combo/spin fields |
| terminal_bg | `#74838B` | VTE terminal body |
| text | `#071117` | primary readable text |
| muted | `#1E3B45` | secondary readable text |
| border | `#2F5965` | cyan-grey borders |
| accent | `#00BFEF` | primary cyan accent |
| accent_2 | `#007F9F` | secondary cyan accent |

## Guardrails

- No Cyan Light surface token may be `#FFFFFF`.
- Cyan Light surface luminance is now capped so the preset cannot regress to a pale/white theme.
- White is retained only for selected/highlight text.

## Preserved behaviour

- Top-menu `Theme` switcher remains available.
- Dialog/popup/theme carryover remains active for Find, Preferences, File Chooser, paste warning, close confirmation, About, and terminal context menu.
- VTE background, foreground, cursor, and selection colours still update when switching themes.
