#!/usr/bin/env python3
"""Sentinel Terminal v1.0.4.

Official lightweight SentinelOS terminal emulator.
GTK/VTE imports are intentionally lazy so non-GUI diagnostics can run on
minimal systems and packaging builders.
"""
from __future__ import annotations

import argparse
import json
import re
import os
import shlex
import subprocess
import shutil
import sys
import traceback
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import unquote, urlparse
from typing import Any, Dict, Iterable, List, Optional, Tuple

VERSION = "1.0.4"
APP_ID = "sentinel-terminal"
APP_NAME = "Sentinel Terminal"
PACKAGE_NAME = "sentinel-terminal"
PACKAGE_SHARE_DIR = Path(os.environ.get("SENTINEL_TERMINAL_SHARE_DIR", Path(__file__).resolve().parents[1]))
ICON_PNG = PACKAGE_SHARE_DIR / "assets" / "sentinel-terminal.png"
DESKTOP_FILE = Path(os.environ.get("SENTINEL_TERMINAL_DESKTOP_FILE", str(PACKAGE_SHARE_DIR.parent / "applications" / "sentinel-terminal.desktop")))

AEGIS_BG = "#101216"
AEGIS_PANEL = "#171A20"
AEGIS_PANEL_2 = "#20242C"
AEGIS_GOLD = "#E19B00"
AEGIS_CYAN = "#03C8FF"
AEGIS_TEXT = "#E8E6DF"
AEGIS_MUTED = "#A9A39A"
AEGIS_ERROR = "#FF6B6B"
AEGIS_SUCCESS = "#7EE787"

THEME_ALIASES: Dict[str, str] = {
    "aegis_dark": "sentinel_suite_dark",
    "sentinel_gold_dark": "sentinel_suite_dark",
    "sentinel_cyan": "sentinel_cyan_dark",
    "cyan_light": "sentinel_cyan_light",
}

THEME_PRESETS: Dict[str, Dict[str, str]] = {
    "sentinel_suite_dark": {
        "label": "Sentinel Suite Dark / Gold",
        "window_bg": "#0B0D10",
        "panel": "#101216",
        "panel_2": "#171A20",
        "panel_3": "#20242C",
        "entry_bg": "#080A0D",
        "terminal_bg": "#05070A",
        "text": "#E8E6DF",
        "muted": "#A9A39A",
        "border": "#30343D",
        "accent": "#E19B00",
        "accent_2": "#03C8FF",
        "selected_bg": "#E19B00",
        "selected_text": "#05070A",
        "error": "#FF6B6B",
        "success": "#7EE787",
    },
    "sentinel_cyan_dark": {
        "label": "Sentinel Cyan Dark",
        "window_bg": "#071116",
        "panel": "#0B1820",
        "panel_2": "#102532",
        "panel_3": "#18384A",
        "entry_bg": "#061015",
        "terminal_bg": "#030B0F",
        "text": "#E6FBFF",
        "muted": "#8DB7C4",
        "border": "#23586C",
        "accent": "#03C8FF",
        "accent_2": "#E19B00",
        "selected_bg": "#03C8FF",
        "selected_text": "#031017",
        "error": "#FF6B6B",
        "success": "#7EE787",
    },
    "sentinel_cyan_light": {
        "label": "Sentinel Cyan Light",
        "window_bg": "#879399",
        "panel": "#77848B",
        "panel_2": "#687780",
        "panel_3": "#596B75",
        "entry_bg": "#93A0A5",
        "terminal_bg": "#74838B",
        "text": "#071117",
        "muted": "#1E3B45",
        "border": "#2F5965",
        "accent": "#00BFEF",
        "accent_2": "#007F9F",
        "selected_bg": "#03C8FF",
        "selected_text": "#FFFFFF",
        "error": "#6F1F1F",
        "success": "#0E4D2B",
    },
    "system": {
        "label": "System Default",
        "window_bg": "#101216",
        "panel": "#171A20",
        "panel_2": "#20242C",
        "panel_3": "#2C3038",
        "entry_bg": "#0B0D10",
        "terminal_bg": "#0B0D10",
        "text": "#E8E6DF",
        "muted": "#A9A39A",
        "border": "#30343D",
        "accent": "#E19B00",
        "accent_2": "#03C8FF",
        "selected_bg": "#E19B00",
        "selected_text": "#05070A",
        "error": "#FF6B6B",
        "success": "#7EE787",
    },
}
THEME_MENU_ORDER: Tuple[str, ...] = ("sentinel_suite_dark", "sentinel_cyan_light", "sentinel_cyan_dark", "system")


def normalize_theme_id(theme_id: Any) -> str:
    raw = str(theme_id or "sentinel_suite_dark").strip()
    raw = THEME_ALIASES.get(raw, raw)
    if raw not in THEME_PRESETS:
        return "sentinel_suite_dark"
    return raw


def theme_palette(theme_id: Any = None) -> Dict[str, str]:
    return dict(THEME_PRESETS[normalize_theme_id(theme_id)])


CONFIG_DIR = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")) / APP_ID
DATA_DIR = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share")) / APP_ID
STATE_DIR = Path(os.environ.get("XDG_STATE_HOME", Path.home() / ".local" / "state")) / APP_ID
CONFIG_PATH = CONFIG_DIR / "config.json"
CRASH_LOG = STATE_DIR / "crash.log"
STATUS_PATH = DATA_DIR / "SENTINEL_TERMINAL_STATUS.json"
SESSION_PATH = DATA_DIR / "session_state.json"

DEFAULT_CONFIG: Dict[str, Any] = {
    "schema_version": 8,
    "theme": "sentinel_suite_dark",
    "font_family": "Monospace",
    "font_size": 11,
    "font_description": "Monospace 11",
    "scrollback_lines": 10000,
    "cursor_blink": True,
    "cursor_shape": "block",  # block | ibeam | underline
    "audible_bell": False,
    "confirm_close": True,
    "warn_multiline_paste": True,
    "show_header": False,
    "show_menubar": True,
    "default_shell": "",
    "startup_cwd": "",
    "new_tab_cwd_mode": "current",  # current | home | configured
    "restore_window_size": True,
    "restore_tabs": False,
    "remember_active_tab": True,
    "dangerous_paste_warning": True,
    "safety_warn_only": True,
}


def now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def ensure_dirs() -> None:
    for path in (CONFIG_DIR, DATA_DIR, STATE_DIR):
        path.mkdir(parents=True, exist_ok=True)


def log_crash(exc: BaseException) -> None:
    try:
        ensure_dirs()
        with CRASH_LOG.open("a", encoding="utf-8") as fh:
            fh.write(f"\n--- {now_iso()} {APP_NAME} v{VERSION} crash ---\n")
            traceback.print_exception(type(exc), exc, exc.__traceback__, file=fh)
    except Exception:
        pass


def merged_config(raw: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    cfg = dict(DEFAULT_CONFIG)
    if isinstance(raw, dict):
        for key in DEFAULT_CONFIG:
            if key in raw:
                cfg[key] = raw[key]
    return normalize_config(cfg)


def normalize_config(cfg: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(DEFAULT_CONFIG)
    out.update(cfg or {})
    try:
        out["font_size"] = int(out.get("font_size", 11))
    except Exception:
        out["font_size"] = 11
    out["font_size"] = max(6, min(40, out["font_size"]))
    try:
        out["scrollback_lines"] = int(out.get("scrollback_lines", 10000))
    except Exception:
        out["scrollback_lines"] = 10000
    out["scrollback_lines"] = max(100, min(500000, out["scrollback_lines"]))
    for key in (
        "cursor_blink", "audible_bell", "confirm_close", "warn_multiline_paste",
        "show_header", "show_menubar", "restore_window_size", "restore_tabs", "remember_active_tab",
        "dangerous_paste_warning", "safety_warn_only",
    ):
        out[key] = bool(out.get(key, DEFAULT_CONFIG[key]))
    if out.get("new_tab_cwd_mode") not in {"current", "home", "configured"}:
        out["new_tab_cwd_mode"] = "current"
    if out.get("cursor_shape") not in {"block", "ibeam", "underline"}:
        out["cursor_shape"] = "block"
    out["theme"] = normalize_theme_id(out.get("theme", "sentinel_suite_dark"))
    family = str(out.get("font_family", "Monospace") or "Monospace").strip() or "Monospace"
    out["font_family"] = family
    out["font_description"] = f"{family} {out['font_size']}"
    out["show_header"] = False
    out["schema_version"] = 8
    return out

def load_config(safe_mode: bool = False) -> Dict[str, Any]:
    if safe_mode:
        return dict(DEFAULT_CONFIG)
    try:
        if CONFIG_PATH.exists():
            with CONFIG_PATH.open("r", encoding="utf-8") as fh:
                return merged_config(json.load(fh))
    except Exception as exc:
        log_crash(exc)
    return dict(DEFAULT_CONFIG)


def save_config(cfg: Dict[str, Any]) -> None:
    ensure_dirs()
    normalized = normalize_config(cfg)
    tmp = CONFIG_PATH.with_suffix(".json.tmp")
    with tmp.open("w", encoding="utf-8") as fh:
        json.dump(normalized, fh, indent=2, sort_keys=True)
        fh.write("\n")
    tmp.replace(CONFIG_PATH)


def reset_config() -> None:
    ensure_dirs()
    if CONFIG_PATH.exists():
        backup = CONFIG_PATH.with_name(f"config.backup.{datetime.now().strftime('%Y%m%d_%H%M%S')}.json")
        CONFIG_PATH.replace(backup)
    save_config(DEFAULT_CONFIG)


def load_session_state(safe_mode: bool = False) -> Dict[str, Any]:
    if safe_mode:
        return {}
    try:
        if SESSION_PATH.exists():
            with SESSION_PATH.open("r", encoding="utf-8") as fh:
                data = json.load(fh)
            return data if isinstance(data, dict) else {}
    except Exception as exc:
        log_crash(exc)
    return {}


def save_session_state(state: Dict[str, Any]) -> None:
    try:
        ensure_dirs()
        clean: Dict[str, Any] = {
            "schema_version": 1,
            "updated_utc": now_iso(),
        }
        if isinstance(state.get("window_size"), list) and len(state["window_size"]) == 2:
            try:
                width = max(400, min(5000, int(state["window_size"][0])))
                height = max(300, min(4000, int(state["window_size"][1])))
                clean["window_size"] = [width, height]
            except Exception:
                pass
        if isinstance(state.get("active_tab"), int):
            clean["active_tab"] = max(0, int(state["active_tab"]))
        tabs = []
        if isinstance(state.get("tabs"), list):
            for item in state["tabs"][:24]:
                if not isinstance(item, dict):
                    continue
                cwd = str(item.get("cwd", "") or "")
                title = str(item.get("title", "") or "")
                if cwd.startswith("~"):
                    cwd = os.path.expanduser(cwd)
                if cwd and Path(cwd).is_dir():
                    tabs.append({"cwd": str(Path(cwd).resolve()), "title": title[:80]})
        if tabs:
            clean["tabs"] = tabs
        tmp = SESSION_PATH.with_suffix(".json.tmp")
        with tmp.open("w", encoding="utf-8") as fh:
            json.dump(clean, fh, indent=2, sort_keys=True)
            fh.write("\n")
        tmp.replace(SESSION_PATH)
    except Exception as exc:
        log_crash(exc)


def cwd_from_uri(uri: str) -> str:
    try:
        parsed = urlparse(uri or "")
        if parsed.scheme != "file":
            return ""
        path = unquote(parsed.path or "")
        if path and Path(path).is_dir():
            return str(Path(path).resolve())
    except Exception:
        pass
    return ""

def is_root_session() -> bool:
    try:
        return hasattr(os, "geteuid") and os.geteuid() == 0
    except Exception:
        return False


DANGEROUS_PASTE_PATTERNS: Tuple[Tuple[str, str, str], ...] = (
    (r"\brm\s+(-[A-Za-z]*[rf][A-Za-z]*|-[A-Za-z]*[fr][A-Za-z]*)\b.*\s/(\s|$)", "high", "recursive/forced removal against root path"),
    (r"\brm\s+(-[A-Za-z]*[rf][A-Za-z]*|-[A-Za-z]*[fr][A-Za-z]*)\b", "medium", "recursive/forced removal"),
    (r"\bdd\s+.*\bof=/dev/", "high", "raw disk write with dd"),
    (r"\bmkfs(\.[A-Za-z0-9_+-]+)?\b", "high", "filesystem creation/format command"),
    (r"\bwipefs\b|\bshred\b", "high", "data destruction command"),
    (r"\bparted\b|\bfdisk\b|\bsgdisk\b|\bcfdisk\b", "high", "partition table command"),
    (r"\bchmod\s+-R\s+777\b", "medium", "recursive world-writable permissions"),
    (r"\bchown\s+-R\b", "medium", "recursive ownership change"),
    (r"\bmkfs\b|\bmount\b|\bumount\b", "medium", "system storage command"),
    (r"\bsudo\b|\bsu\s+-", "low", "privilege escalation command"),
)


def analyze_paste_risk(text: str) -> Dict[str, Any]:
    content = text or ""
    lines = [line for line in content.splitlines() if line.strip()]
    reasons: List[str] = []
    severity_rank = {"none": 0, "low": 1, "medium": 2, "high": 3}
    severity = "none"
    if len(lines) > 1:
        reasons.append(f"multiline paste: {len(lines)} non-empty lines")
        severity = "low"
    for pattern, level, reason in DANGEROUS_PASTE_PATTERNS:
        try:
            if re.search(pattern, content, flags=re.IGNORECASE | re.MULTILINE):
                if reason not in reasons:
                    reasons.append(reason)
                if severity_rank[level] > severity_rank[severity]:
                    severity = level
        except re.error:
            continue
    return {
        "severity": severity,
        "line_count": len(lines),
        "reasons": reasons,
        "warn": severity != "none",
    }


def format_paste_risk_warning(risk: Dict[str, Any]) -> str:
    reasons = risk.get("reasons") or []
    if not reasons:
        return "This paste may affect a live shell."
    listed = "\n".join(f"• {reason}" for reason in reasons[:8])
    return (
        "Sentinel Terminal detected possible paste risk.\n\n"
        f"{listed}\n\n"
        "This is a warning only. You remain in control."
    )


def resolve_shell(config_shell: str = "") -> str:
    candidates = [config_shell, os.environ.get("SHELL", ""), "/bin/bash", "/bin/sh"]
    for candidate in candidates:
        if candidate and Path(candidate).exists() and os.access(candidate, os.X_OK):
            return candidate
    return "/bin/sh"


def resolve_cwd(configured: str = "") -> str:
    candidate = (configured or "").strip()
    if candidate.startswith("~"):
        candidate = os.path.expanduser(candidate)
    if candidate and Path(candidate).is_dir():
        return str(Path(candidate).resolve())
    return str(Path.home())


def parse_env_for_vte() -> List[str]:
    env = dict(os.environ)
    env.setdefault("TERM", "xterm-256color")
    env.setdefault("COLORTERM", "truecolor")
    env.setdefault("SENTINEL_TERMINAL", VERSION)
    return [f"{k}={v}" for k, v in env.items()]


def format_json_status(include_paths: bool = True) -> Dict[str, Any]:
    deps = dependency_status()
    status = {
        "app": APP_NAME,
        "package": PACKAGE_NAME,
        "version": VERSION,
        "status": "ready" if deps["gtk_vte_available"] else "missing_gui_dependency",
        "timestamp_utc": now_iso(),
        "gui_stack": "GTK3 + VTE 2.91",
        "display_available": deps.get("display_available", False),
        "theme": "SentinelOS suite theming with runtime theme switcher and darker grey/cyan Sentinel Cyan Light",
        "theme_presets": [THEME_PRESETS[item]["label"] for item in THEME_MENU_ORDER],
        "dependency_status": deps,
        "capabilities": [
            "tabs",
            "copy_paste",
            "multiline_paste_warning",
            "zoom_controls",
            "find",
            "preferences",
            "font_chooser",
            "cursor_controls",
            "shell_startup_controls",
            "auto_terminal_focus",
            "exit_closes_last_tab",
            "ctrl_c_interrupt_forwarding",
            "tab_rename",
            "tab_duplicate",
            "session_state",
            "window_size_restore",
            "tab_switching_shortcuts",
            "menu_find_dialog",
            "find_next_previous",
            "clear_scrollback",
            "save_terminal_output",
            "open_current_folder",
            "dangerous_paste_warning",
            "warn_only_safety_model",
            "no_command_logging_default",
            "desktop_actions",
            "launcher_repair_helper",
            "mate_caja_open_here",
            "icon_cache_refresh",
            "user_setup_uninstall_safe",
            "stable_lock_checks",
            "mate_like_desktop_native",
            "manual_page",
            "no_root_top_banner",
            "safe_mode",
            "crash_logging",
            "desktop_launcher",
            "desktop_icon_setup",
            "compact_tabs",
            "headerless_ui",
            "aegis_status_json",
            "runtime_check",
            "spawn_error_guard",
            "suite_theme_integration",
            "top_menu_theme_switcher",
            "sentinel_cyan_light_theme",
            "dialog_popup_theme_carryover",
            "vte_terminal_theme_switching",
            "sentinel_cyan_light_darker_grey",
        ],
    }
    if include_paths:
        status["paths"] = {
            "config": str(CONFIG_PATH),
            "data": str(DATA_DIR),
            "state": str(STATE_DIR),
            "crash_log": str(CRASH_LOG),
            "status_json": str(STATUS_PATH),
        }
    return status


def write_status() -> Dict[str, Any]:
    ensure_dirs()
    status = format_json_status()
    tmp = STATUS_PATH.with_suffix(".json.tmp")
    with tmp.open("w", encoding="utf-8") as fh:
        json.dump(status, fh, indent=2, sort_keys=True)
        fh.write("\n")
    tmp.replace(STATUS_PATH)
    return status


def dependency_status() -> Dict[str, Any]:
    py_gi = False
    gtk = False
    vte = False
    error = ""
    display_available = bool(os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY"))
    try:
        import gi  # type: ignore

        py_gi = True
        try:
            gi.require_version("Gtk", "3.0")
            gi.require_version("Vte", "2.91")
            from gi.repository import Gtk, Vte  # noqa: F401  # type: ignore

            gtk = True
            vte = True
        except Exception as exc:  # pragma: no cover - depends on host packages
            error = str(exc)
    except Exception as exc:  # pragma: no cover - depends on host packages
        error = str(exc)
    return {
        "python3_gi_available": py_gi,
        "gtk3_available": gtk,
        "vte_2_91_available": vte,
        "gtk_vte_available": bool(py_gi and gtk and vte),
        "display_available": display_available,
        "display_backend": "wayland" if os.environ.get("WAYLAND_DISPLAY") else ("x11" if os.environ.get("DISPLAY") else "none"),
        "icon_png_exists": ICON_PNG.exists(),
        "desktop_file_exists": DESKTOP_FILE.exists(),
        "package_share_dir": str(PACKAGE_SHARE_DIR),
        "error": error,
    }


def path_writable(path: Path) -> bool:
    try:
        path.mkdir(parents=True, exist_ok=True)
        probe = path / ".sentinel-terminal-write-test"
        probe.write_text("ok\n", encoding="utf-8")
        probe.unlink(missing_ok=True)
        return True
    except Exception:
        return False


def runtime_check() -> Dict[str, Any]:
    deps = dependency_status()
    self_ok, self_messages = run_self_test()
    checks = {
        "version": VERSION,
        "timestamp_utc": now_iso(),
        "python": sys.version.split()[0],
        "executable": sys.executable,
        "shell": resolve_shell(""),
        "config_dir_writable": path_writable(CONFIG_DIR),
        "data_dir_writable": path_writable(DATA_DIR),
        "state_dir_writable": path_writable(STATE_DIR),
        "config_loads": isinstance(load_config(False), dict),
        "self_test_passed": self_ok,
        "self_test_messages": self_messages,
        "dependency_status": deps,
        "paths": {
            "package_share_dir": str(PACKAGE_SHARE_DIR),
            "icon_png": str(ICON_PNG),
            "desktop_file": str(DESKTOP_FILE),
            "config": str(CONFIG_PATH),
            "crash_log": str(CRASH_LOG),
            "status_json": str(STATUS_PATH),
        },
    }
    checks["ready_for_gui"] = bool(self_ok and deps.get("gtk_vte_available") and deps.get("display_available"))
    return checks

def run_self_test() -> Tuple[bool, List[str]]:
    messages: List[str] = []
    ok = True

    cfg = merged_config({"font_size": "999", "scrollback_lines": "bad", "new_tab_cwd_mode": "weird"})
    if cfg["font_size"] != 40:
        ok = False
        messages.append("FAIL: font_size clamp")
    else:
        messages.append("PASS: font_size clamp")
    if cfg["scrollback_lines"] != 10000:
        ok = False
        messages.append("FAIL: scrollback fallback")
    else:
        messages.append("PASS: scrollback fallback")
    if cfg["new_tab_cwd_mode"] != "current":
        ok = False
        messages.append("FAIL: new_tab_cwd_mode fallback")
    else:
        messages.append("PASS: new_tab_cwd_mode fallback")

    shell = resolve_shell("/definitely/not/a/shell")
    if not shell or not Path(shell).exists():
        ok = False
        messages.append("FAIL: shell fallback")
    else:
        messages.append(f"PASS: shell fallback -> {shell}")

    cwd = resolve_cwd("/definitely/not/a/directory")
    if not Path(cwd).is_dir():
        ok = False
        messages.append("FAIL: cwd fallback")
    else:
        messages.append("PASS: cwd fallback")

    tricky_cwd = Path.home()
    if resolve_cwd(str(tricky_cwd)) != str(tricky_cwd.resolve()):
        ok = False
        messages.append("FAIL: explicit working-directory resolver")
    else:
        messages.append("PASS: explicit working-directory resolver")

    envv = parse_env_for_vte()
    if not any(item.startswith("SENTINEL_TERMINAL=") for item in envv):
        ok = False
        messages.append("FAIL: VTE environment marker")
    else:
        messages.append("PASS: VTE environment marker")

    status = format_json_status(include_paths=False)
    if status.get("version") != VERSION or "tabs" not in status.get("capabilities", []):
        ok = False
        messages.append("FAIL: AEGIS status schema")
    else:
        messages.append("PASS: AEGIS status schema")

    if ICON_PNG.exists():
        messages.append("PASS: packaged icon present")
    else:
        messages.append("WARN: packaged icon not found in this execution context")

    if DESKTOP_FILE.exists():
        messages.append("PASS: desktop launcher present")
    else:
        messages.append("WARN: desktop launcher not found in this execution context")

    pref_cfg = merged_config({"cursor_shape": "bad", "theme": "bad", "font_family": "", "font_size": "12"})
    if pref_cfg.get("cursor_shape") != "block" or pref_cfg.get("theme") != "sentinel_suite_dark" or pref_cfg.get("schema_version") != 8:
        ok = False
        messages.append("FAIL: preferences/session schema normalization")
    else:
        messages.append("PASS: preferences/session schema normalization")

    if "auto_terminal_focus" not in status.get("capabilities", []) or "ctrl_c_interrupt_forwarding" not in status.get("capabilities", []):
        ok = False
        messages.append("FAIL: focus/interrupt capability schema")
    else:
        messages.append("PASS: focus/interrupt capability schema")

    if "tab_rename" not in status.get("capabilities", []) or "session_state" not in status.get("capabilities", []):
        ok = False
        messages.append("FAIL: session handling capability schema")
    else:
        messages.append("PASS: session handling capability schema")

    if cwd_from_uri("file:///tmp") != "/tmp":
        ok = False
        messages.append("FAIL: file URI cwd parser")
    else:
        messages.append("PASS: file URI cwd parser")

    required_window_methods = (
        "_on_configure_event",
        "_focus_current_terminal",
        "_on_switch_page",
        "_tab_current_cwd",
        "_session_snapshot",
        "_save_session_state",
        "_restore_session_tabs",
        "show_find_dialog",
        "set_theme",
        "_apply_dialog_theme",
        "_apply_terminal_theme",
    )
    missing_methods = [name for name in required_window_methods if not hasattr(SentinelTerminalWindow, name)]
    if missing_methods:
        ok = False
        messages.append("FAIL: GUI runtime method presence -> " + ", ".join(missing_methods))
    else:
        messages.append("PASS: GUI runtime method presence")

    productivity_caps = {"menu_find_dialog", "find_next_previous", "clear_scrollback", "save_terminal_output", "open_current_folder"}
    if not productivity_caps.issubset(set(status.get("capabilities", []))):
        ok = False
        messages.append("FAIL: productivity capability schema")
    else:
        messages.append("PASS: productivity capability schema")

    safety_caps = {"dangerous_paste_warning", "warn_only_safety_model", "no_command_logging_default", "no_root_top_banner"}
    if not safety_caps.issubset(set(status.get("capabilities", []))):
        ok = False
        messages.append("FAIL: safety capability schema")
    else:
        messages.append("PASS: safety capability schema")

    desktop_caps = {"desktop_actions", "launcher_repair_helper", "mate_caja_open_here", "icon_cache_refresh", "user_setup_uninstall_safe", "stable_lock_checks", "mate_like_desktop_native", "manual_page"}
    if not desktop_caps.issubset(set(status.get("capabilities", []))):
        ok = False
        messages.append("FAIL: desktop integration capability schema")
    else:
        messages.append("PASS: desktop integration capability schema")

    try:
        if DESKTOP_FILE.exists():
            desktop_text = DESKTOP_FILE.read_text(encoding="utf-8", errors="replace")
            if "[Desktop Action SafeMode]" in desktop_text and "Actions=" in desktop_text:
                messages.append("PASS: desktop quick actions present")
            else:
                ok = False
                messages.append("FAIL: desktop quick actions missing")
        else:
            messages.append("WARN: desktop quick actions skipped outside package path")
    except Exception as exc:
        ok = False
        messages.append(f"FAIL: desktop quick action check -> {exc}")

    source_text = Path(__file__).read_text(encoding="utf-8", errors="replace")
    removed_tokens = ("safety" + "_banner", "_should" + "_show_root_warning", "sentinel-" + "safety-banner")
    if any(token in source_text for token in removed_tokens):
        ok = False
        messages.append("FAIL: root top banner code removed")
    else:
        messages.append("PASS: root top banner code removed")

    if f'VERSION = "{VERSION}"' not in source_text or VERSION != "1.0.4":
        ok = False
        messages.append("FAIL: stable lock version literal")
    else:
        messages.append("PASS: stable lock version literal")

    theme_caps = {"suite_theme_integration", "top_menu_theme_switcher", "sentinel_cyan_light_theme", "dialog_popup_theme_carryover", "vte_terminal_theme_switching"}
    if not theme_caps.issubset(set(status.get("capabilities", []))) or normalize_theme_id("aegis_dark") != "sentinel_suite_dark":
        ok = False
        messages.append("FAIL: theme integration capability schema")
    else:
        messages.append("PASS: theme integration capability schema")

    cyan_light = theme_palette("sentinel_cyan_light")
    cyan_surface_keys = ("window_bg", "panel", "panel_2", "panel_3", "entry_bg", "terminal_bg")
    if any(cyan_light.get(key, "").upper() == "#FFFFFF" for key in cyan_surface_keys):
        ok = False
        messages.append("FAIL: Sentinel Cyan Light surface white removed")
    else:
        messages.append("PASS: Sentinel Cyan Light no-white surfaces")

    def _hex_luma(hex_value: str) -> float:
        raw = str(hex_value).strip().lstrip("#")
        if len(raw) != 6:
            return 255.0
        r, g, b = (int(raw[i:i + 2], 16) for i in (0, 2, 4))
        return (0.2126 * r) + (0.7152 * g) + (0.0722 * b)

    surface_lumas = [_hex_luma(cyan_light.get(key, "#FFFFFF")) for key in cyan_surface_keys]
    # Guard against the Cyan Light preset drifting back into a white/pale theme.
    # It should remain a medium/darker grey base while staying lighter than Cyan Dark.
    if max(surface_lumas) > 170 or min(surface_lumas) < 75:
        ok = False
        messages.append("FAIL: Sentinel Cyan Light darker grey surface range")
    else:
        messages.append("PASS: Sentinel Cyan Light darker grey surface range")

    theme_caps_v104 = {"sentinel_cyan_light_darker_grey"}
    if not theme_caps_v104.issubset(set(status.get("capabilities", []))):
        ok = False
        messages.append("FAIL: darker Cyan Light capability schema")
    else:
        messages.append("PASS: darker Cyan Light capability schema")

    stable_caps = {"stable_lock_checks", "mate_like_desktop_native", "manual_page"}
    if not stable_caps.issubset(set(status.get("capabilities", []))):
        ok = False
        messages.append("FAIL: stable lock capability schema")
    else:
        messages.append("PASS: stable lock capability schema")

    high_risk = analyze_paste_risk("sudo dd if=/tmp/image.iso of=/dev/sda\n")
    if high_risk.get("severity") != "high" or not high_risk.get("warn"):
        ok = False
        messages.append("FAIL: dangerous paste risk detection")
    else:
        messages.append("PASS: dangerous paste risk detection")

    multiline_risk = analyze_paste_risk("echo one\necho two\n")
    if multiline_risk.get("severity") == "none" or multiline_risk.get("line_count") != 2:
        ok = False
        messages.append("FAIL: multiline paste risk detection")
    else:
        messages.append("PASS: multiline paste risk detection")

    return ok, messages


# GUI code is deliberately nested below this point.
def import_gtk_stack() -> Tuple[Any, Any, Any, Any, Any, Any, Any, Any]:
    import gi  # type: ignore

    gi.require_version("Gtk", "3.0")
    gi.require_version("Vte", "2.91")
    from gi.repository import Gdk, GdkPixbuf, Gio, GLib, Gtk, Pango, Vte  # type: ignore

    return Gtk, Gdk, GdkPixbuf, Gio, GLib, Vte, Pango, gi


class GuiUnavailable(RuntimeError):
    pass


def apply_css(Gtk: Any, Gdk: Any, theme_id: Any = "sentinel_suite_dark") -> None:
    p = theme_palette(theme_id)
    css = f"""
    window, dialog, messagedialog, filechooserdialog, aboutdialog {{
        background-color: {p['window_bg']};
        color: {p['text']};
    }}
    .sentinel-root, .sentinel-dialog-area {{
        background-color: {p['window_bg']};
        color: {p['text']};
    }}
    .sentinel-header {{
        background: linear-gradient(90deg, {p['panel']}, {p['panel_2']});
        border: 1px solid {p['accent']};
        border-radius: 10px;
        padding: 10px;
        margin: 8px;
    }}
    .sentinel-title {{
        color: {p['accent']};
        font-weight: bold;
        font-size: 15px;
    }}
    .sentinel-subtitle {{
        color: {p['muted']};
        font-size: 10px;
    }}
    notebook, notebook header, scrolledwindow, viewport {{
        background-color: {p['window_bg']};
        color: {p['text']};
        border-color: {p['border']};
    }}
    notebook tab {{
        background-color: {p['panel']};
        color: {p['text']};
        border: 1px solid {p['border']};
        padding: 1px 6px;
        min-height: 18px;
    }}
    notebook tab:checked {{
        background-color: {p['panel_2']};
        color: {p['accent']};
        border-top: 2px solid {p['accent']};
    }}
    .sentinel-tab-label {{
        font-size: 10px;
        padding: 0px;
        margin: 0px;
    }}
    .sentinel-tab-close {{
        padding: 0px 3px;
        margin: 0px;
        min-height: 14px;
        min-width: 14px;
        border-radius: 3px;
    }}
    menubar, menu, menuitem, .sentinel-popup-menu {{
        background-color: {p['panel']};
        color: {p['text']};
        border-color: {p['border']};
    }}
    menuitem:hover, menuitem:checked {{
        background-color: {p['panel_2']};
        color: {p['accent']};
    }}
    button {{
        background: {p['panel_2']};
        color: {p['text']};
        border: 1px solid {p['accent']};
        border-radius: 6px;
        padding: 5px 8px;
    }}
    button:hover, button:checked {{
        color: {p['accent_2']};
        border-color: {p['accent_2']};
        background: {p['panel_3']};
    }}
    entry, spinbutton, combobox, combobox box, textview, filechooser entry {{
        background-color: {p['entry_bg']};
        color: {p['text']};
        border: 1px solid {p['border']};
        border-radius: 4px;
    }}
    combobox arrow {{
        color: {p['accent']};
    }}
    label, checkbutton, radiobutton {{
        color: {p['text']};
    }}
    .sentinel-status {{
        background-color: {p['panel']};
        color: {p['muted']};
        border-top: 1px solid {p['border']};
        padding: 3px 8px;
    }}
    scrollbar trough {{
        background-color: {p['panel']};
        border: 1px solid {p['border']};
    }}
    scrollbar slider {{
        background-color: {p['panel_3']};
        border-radius: 8px;
        min-width: 10px;
        min-height: 10px;
    }}
    scrollbar slider:hover {{
        background-color: {p['accent']};
    }}
    selection {{
        background-color: {p['selected_bg']};
        color: {p['selected_text']};
    }}
    """
    provider = Gtk.CssProvider()
    provider.load_from_data(css.encode("utf-8"))
    screen = Gdk.Screen.get_default()
    if screen is not None:
        Gtk.StyleContext.add_provider_for_screen(
            screen, provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )


def rgba_from_hex(Gdk: Any, color: str, fallback: str = "#000000") -> Any:
    rgba = Gdk.RGBA()
    if not rgba.parse(color):
        rgba.parse(fallback)
    return rgba


@dataclass
class TerminalTab:
    terminal: Any
    widget: Any
    label: Any
    cwd: str
    child_pid: Optional[int] = None
    custom_title: str = ""


class SentinelTerminalWindow:  # runtime GTK class; not deriving statically to keep imports lazy
    def __init__(self, safe_mode: bool = False, startup_command: Optional[List[str]] = None, startup_cwd: Optional[str] = None, gui_smoke_test: bool = False):
        self.Gtk, self.Gdk, self.GdkPixbuf, self.Gio, self.GLib, self.Vte, self.Pango, _gi = import_gtk_stack()
        Gtk = self.Gtk
        Gdk = self.Gdk
        self.safe_mode = safe_mode
        self.gui_smoke_test = gui_smoke_test
        self.config = load_config(safe_mode=safe_mode)
        apply_css(Gtk, Gdk, self.config.get("theme", "sentinel_suite_dark"))
        self._theme_menu_items: Dict[str, Any] = {}
        self._theme_syncing = False
        self.session_state = load_session_state(safe_mode=safe_mode)
        self.tabs: List[TerminalTab] = []
        self.zoom_delta = 0
        self.last_find_query = ""
        self.startup_cwd = resolve_cwd(startup_cwd or "") if startup_cwd else None
        self.last_window_size = (980, 640)
        self.window = Gtk.Window(title=APP_NAME)
        width, height = 980, 640
        if self.config.get("restore_window_size", True):
            try:
                saved_size = self.session_state.get("window_size", [])
                if isinstance(saved_size, list) and len(saved_size) == 2:
                    width = max(400, min(5000, int(saved_size[0])))
                    height = max(300, min(4000, int(saved_size[1])))
            except Exception as exc:
                log_crash(exc)
        self.last_window_size = (width, height)
        self.window.set_default_size(width, height)
        if ICON_PNG.exists():
            try:
                self.window.set_icon_from_file(str(ICON_PNG))
            except Exception:
                self.window.set_icon_name("sentinel-terminal")
        else:
            self.window.set_icon_name("sentinel-terminal")
        self.window.connect("delete-event", self._on_delete)
        self.window.connect("key-press-event", self._on_key_press)
        self.window.connect("configure-event", self._on_configure_event)

        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        root.get_style_context().add_class("sentinel-root")
        self.window.add(root)

        self._build_menu(root)
        # v0.9.0 RC: header and root/admin top banner removed to maximize terminal workspace.

        self.notebook = Gtk.Notebook()
        self.notebook.set_scrollable(True)
        self.notebook.set_tab_pos(Gtk.PositionType.TOP)
        self.notebook.connect("switch-page", self._on_switch_page)
        root.pack_start(self.notebook, True, True, 0)


        self.status_label = Gtk.Label(label="Ready")
        self.status_label.set_xalign(0)
        self.status_label.get_style_context().add_class("sentinel-status")
        root.pack_end(self.status_label, False, False, 0)

        restored_tabs = False
        if startup_command is None and self.startup_cwd is None and self.config.get("restore_tabs", False):
            restored_tabs = self._restore_session_tabs()
        if not restored_tabs:
            self.create_tab(cwd=self.startup_cwd, command=startup_command)
        self.window.show_all()
        if self.config.get("remember_active_tab", True):
            try:
                active = int(self.session_state.get("active_tab", 0))
                if 0 <= active < len(self.tabs):
                    self.notebook.set_current_page(active)
            except Exception as exc:
                log_crash(exc)
        self.GLib.idle_add(self._focus_current_terminal)
        if gui_smoke_test:
            self.GLib.timeout_add(350, self._smoke_quit)

    def _build_menu(self, root: Any) -> None:
        Gtk = self.Gtk
        if not self.config.get("show_menubar", True):
            return
        accel = Gtk.AccelGroup()
        self.window.add_accel_group(accel)
        menubar = Gtk.MenuBar()

        def menu_item(label: str, callback: Any, accel_key: Optional[str] = None) -> Any:
            item = Gtk.MenuItem(label=label)
            item.connect("activate", callback)
            if accel_key:
                key, mod = Gtk.accelerator_parse(accel_key)
                item.add_accelerator("activate", accel, key, mod, Gtk.AccelFlags.VISIBLE)
            return item

        file_menu = Gtk.Menu()
        file_root = Gtk.MenuItem(label="File")
        file_root.set_submenu(file_menu)
        file_menu.append(menu_item("New Tab", lambda *_: self.create_tab(cwd=self._new_tab_cwd()), "<Primary><Shift>t"))
        file_menu.append(menu_item("Duplicate Tab", lambda *_: self.duplicate_current_tab(), "<Primary><Shift>d"))
        file_menu.append(menu_item("Rename Tab", lambda *_: self.rename_current_tab(), "<Primary><Shift>r"))
        file_menu.append(menu_item("Close Tab", lambda *_: self.close_current_tab(), "<Primary><Shift>w"))
        file_menu.append(Gtk.SeparatorMenuItem())
        file_menu.append(menu_item("Save Output...", lambda *_: self.save_terminal_output(), "<Primary><Shift>s"))
        file_menu.append(menu_item("Open Current Folder", lambda *_: self.open_current_folder(), "<Primary><Shift>o"))
        file_menu.append(menu_item("Preferences", lambda *_: self.show_preferences()))
        file_menu.append(Gtk.SeparatorMenuItem())
        file_menu.append(menu_item("Quit", lambda *_: self.quit(), "<Primary>q"))

        edit_menu = Gtk.Menu()
        edit_root = Gtk.MenuItem(label="Edit")
        edit_root.set_submenu(edit_menu)
        edit_menu.append(menu_item("Copy", lambda *_: self.copy_clipboard(), "<Primary><Shift>c"))
        edit_menu.append(menu_item("Paste", lambda *_: self.safe_paste(), "<Primary><Shift>v"))
        edit_menu.append(menu_item("Select All", lambda *_: self.select_all()))
        edit_menu.append(menu_item("Clear Scrollback", lambda *_: self.clear_scrollback(), "<Primary><Shift>k"))

        search_menu = Gtk.Menu()
        search_root = Gtk.MenuItem(label="Search")
        search_root.set_submenu(search_menu)
        search_menu.append(menu_item("Find...", lambda *_: self.show_find_dialog(), "<Primary><Shift>f"))
        search_menu.append(menu_item("Find Next", lambda *_: self.find_next_from_bar(), "F3"))
        search_menu.append(menu_item("Find Previous", lambda *_: self.find_previous_from_bar(), "<Shift>F3"))

        view_menu = Gtk.Menu()
        view_root = Gtk.MenuItem(label="View")
        view_root.set_submenu(view_menu)
        view_menu.append(menu_item("Zoom In", lambda *_: self.zoom(1), "<Primary>plus"))
        view_menu.append(menu_item("Zoom Out", lambda *_: self.zoom(-1), "<Primary>minus"))
        view_menu.append(menu_item("Reset Zoom", lambda *_: self.reset_zoom(), "<Primary>0"))
        view_menu.append(menu_item("Fullscreen", lambda *_: self.toggle_fullscreen(), "F11"))

        theme_menu = Gtk.Menu()
        theme_root = Gtk.MenuItem(label="Theme")
        theme_root.set_submenu(theme_menu)
        self._theme_menu_items = {}
        for theme_id in THEME_MENU_ORDER:
            item = Gtk.CheckMenuItem(label=THEME_PRESETS[theme_id]["label"])
            item.set_draw_as_radio(True)
            item.connect("toggled", lambda menu_item, tid=theme_id: menu_item.get_active() and not self._theme_syncing and self.set_theme(tid, save=True))
            theme_menu.append(item)
            self._theme_menu_items[theme_id] = item
        self._sync_theme_menu()

        help_menu = Gtk.Menu()
        help_root = Gtk.MenuItem(label="Help")
        help_root.set_submenu(help_menu)
        help_menu.append(menu_item("About", lambda *_: self.show_about()))

        for root_item in (file_root, edit_root, search_root, view_root, theme_root, help_root):
            menubar.append(root_item)
        root.pack_start(menubar, False, False, 0)


    def _palette(self) -> Dict[str, str]:
        return theme_palette(self.config.get("theme", "sentinel_suite_dark"))

    def _sync_theme_menu(self) -> None:
        if not hasattr(self, "_theme_menu_items"):
            return
        active_theme = normalize_theme_id(self.config.get("theme", "sentinel_suite_dark"))
        self._theme_syncing = True
        try:
            for theme_id, item in self._theme_menu_items.items():
                item.set_active(theme_id == active_theme)
        finally:
            self._theme_syncing = False

    def set_theme(self, theme_id: str, save: bool = True) -> None:
        theme_id = normalize_theme_id(theme_id)
        self.config = normalize_config({**self.config, "theme": theme_id})
        apply_css(self.Gtk, self.Gdk, theme_id)
        self._apply_preferences(theme_only=True)
        self._sync_theme_menu()
        if save and not self.safe_mode:
            save_config(self.config)
        self._set_status(f"Theme applied: {THEME_PRESETS[theme_id]['label']}")

    def _apply_dialog_theme(self, dialog: Any) -> None:
        try:
            dialog.get_style_context().add_class("sentinel-dialog")
            content_area = dialog.get_content_area() if hasattr(dialog, "get_content_area") else None
            if content_area is not None:
                content_area.get_style_context().add_class("sentinel-dialog-area")
        except Exception as exc:
            log_crash(exc)

    def _apply_terminal_theme(self, terminal: Any) -> None:
        p = self._palette()
        try:
            terminal.set_color_background(rgba_from_hex(self.Gdk, p["terminal_bg"], "#0B0D10"))
            terminal.set_color_foreground(rgba_from_hex(self.Gdk, p["text"], "#E8E6DF"))
            terminal.set_color_cursor(rgba_from_hex(self.Gdk, p["accent"], "#E19B00"))
            terminal.set_color_highlight(rgba_from_hex(self.Gdk, p["selected_bg"], "#E19B00"))
            terminal.set_color_highlight_foreground(rgba_from_hex(self.Gdk, p["selected_text"], "#05070A"))
        except Exception as exc:
            log_crash(exc)

    def _build_header(self, root: Any) -> None:
        Gtk = self.Gtk
        frame = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        frame.get_style_context().add_class("sentinel-header")
        if ICON_PNG.exists():
            try:
                badge = Gtk.Image.new_from_file(str(ICON_PNG))
                badge.set_pixel_size(48)
                frame.pack_start(badge, False, False, 0)
            except Exception:
                badge = Gtk.Label(label="⬢")
                badge.set_markup(f"<span foreground='{self._palette()['accent']}' size='xx-large'>⬢</span>")
                frame.pack_start(badge, False, False, 0)
        else:
            badge = Gtk.Label(label="⬢")
            badge.set_markup(f"<span foreground='{self._palette()['accent']}' size='xx-large'>⬢</span>")
            frame.pack_start(badge, False, False, 0)
        text_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=1)
        title = Gtk.Label(label=f"{APP_NAME} v{VERSION}")
        title.set_xalign(0)
        title.get_style_context().add_class("sentinel-title")
        subtitle = Gtk.Label(label="SentinelOS / AEGIS protected user terminal")
        subtitle.set_xalign(0)
        subtitle.get_style_context().add_class("sentinel-subtitle")
        text_box.pack_start(title, False, False, 0)
        text_box.pack_start(subtitle, False, False, 0)
        frame.pack_start(text_box, True, True, 0)
        root.pack_start(frame, False, False, 0)

    def _on_configure_event(self, widget: Any, event: Any) -> bool:
        try:
            width = int(getattr(event, "width", self.last_window_size[0]))
            height = int(getattr(event, "height", self.last_window_size[1]))
            self.last_window_size = (max(400, width), max(300, height))
        except Exception:
            pass
        return False

    def _focus_current_terminal(self, *_: Any) -> bool:
        tab = self._current_tab()
        if tab:
            try:
                tab.terminal.grab_focus()
            except Exception as exc:
                log_crash(exc)
        return False

    def _on_switch_page(self, *_: Any) -> None:
        try:
            self.GLib.idle_add(self._focus_current_terminal)
            if self.config.get("remember_active_tab", True):
                self._save_session_state()
        except Exception as exc:
            log_crash(exc)

    def _tab_current_cwd(self, tab: TerminalTab) -> str:
        try:
            uri = tab.terminal.get_current_directory_uri()
            cwd = cwd_from_uri(uri)
            if cwd:
                tab.cwd = cwd
                return cwd
        except Exception:
            pass
        if tab.cwd and Path(tab.cwd).is_dir():
            return tab.cwd
        return resolve_cwd(str(self.config.get("startup_cwd", "")))

    def _session_snapshot(self) -> Dict[str, Any]:
        tabs: List[Dict[str, str]] = []
        for tab in self.tabs:
            try:
                cwd = self._tab_current_cwd(tab)
            except Exception:
                cwd = tab.cwd if tab.cwd and Path(tab.cwd).is_dir() else str(Path.home())
            tabs.append({
                "cwd": cwd,
                "title": str(tab.custom_title or "")[:80],
            })
        return {
            "window_size": [int(self.last_window_size[0]), int(self.last_window_size[1])],
            "active_tab": int(self.notebook.get_current_page()),
            "tabs": tabs,
        }

    def _save_session_state(self) -> None:
        if self.safe_mode:
            return
        try:
            save_session_state(self._session_snapshot())
        except Exception as exc:
            log_crash(exc)

    def _restore_session_tabs(self) -> bool:
        try:
            raw_tabs = self.session_state.get("tabs", [])
            if not isinstance(raw_tabs, list) or not raw_tabs:
                return False
            restored = 0
            for item in raw_tabs[:12]:
                if not isinstance(item, dict):
                    continue
                cwd = str(item.get("cwd", "") or "")
                title = str(item.get("title", "") or "")
                if cwd.startswith("~"):
                    cwd = os.path.expanduser(cwd)
                if cwd and Path(cwd).is_dir():
                    self.create_tab(cwd=str(Path(cwd).resolve()), title=title[:80])
                    restored += 1
            return restored > 0
        except Exception as exc:
            log_crash(exc)
            return False

    def show_find_dialog(self) -> None:
        Gtk = self.Gtk
        try:
            dialog = Gtk.Dialog(title="Find in Terminal", transient_for=self.window, flags=0)
            self._apply_dialog_theme(dialog)
            dialog.add_button("Cancel", Gtk.ResponseType.CANCEL)
            dialog.add_button("Find Previous", Gtk.ResponseType.NO)
            dialog.add_button("Find Next", Gtk.ResponseType.OK)
            dialog.set_default_response(Gtk.ResponseType.OK)
            area = dialog.get_content_area()
            area.set_border_width(10)
            area.set_spacing(8)
            label = Gtk.Label(label="Search terminal output:")
            label.set_xalign(0)
            entry = Gtk.Entry(text=self.last_find_query)
            entry.set_activates_default(True)
            entry.set_placeholder_text("Enter text to find")
            area.pack_start(label, False, False, 0)
            area.pack_start(entry, False, False, 0)
            dialog.show_all()
            entry.grab_focus()
            response = dialog.run()
            query = entry.get_text().strip()
            dialog.destroy()
            if response not in (Gtk.ResponseType.OK, Gtk.ResponseType.NO) or not query:
                self._focus_current_terminal()
                return
            self.last_find_query = query
            if response == Gtk.ResponseType.NO:
                self._find_previous(query)
            else:
                self._find_next(query)
            self._focus_current_terminal()
        except Exception as exc:
            log_crash(exc)
            self._set_status(f"Find unavailable: {exc}")

    def hide_find_bar(self) -> None:
        # Kept as a no-op compatibility shim for old keyboard paths; v1.0.1
        # removed the persistent find bar to avoid cramped terminal rendering.
        self._focus_current_terminal()

    def _current_tab(self) -> Optional[TerminalTab]:
        page = self.notebook.get_current_page()
        if page < 0 or page >= len(self.tabs):
            return None
        return self.tabs[page]

    def _new_tab_cwd(self) -> str:
        mode = str(self.config.get("new_tab_cwd_mode", "current"))
        if mode == "home":
            return str(Path.home())
        if mode == "configured":
            return resolve_cwd(str(self.config.get("startup_cwd", "")))
        tab = self._current_tab()
        if tab:
            cwd = self._tab_current_cwd(tab)
            if cwd and Path(cwd).is_dir():
                return cwd
        return resolve_cwd(str(self.config.get("startup_cwd", "")))

    def _configured_font(self) -> Any:
        family = str(self.config.get("font_family", "Monospace")) or "Monospace"
        size = int(self.config.get("font_size", 11)) + self.zoom_delta
        size = max(6, min(40, size))
        return self.Pango.FontDescription(f"{family} {size}")

    def _cursor_shape_value(self) -> Any:
        shape = str(self.config.get("cursor_shape", "block"))
        if shape == "ibeam":
            return self.Vte.CursorShape.IBEAM
        if shape == "underline":
            return self.Vte.CursorShape.UNDERLINE
        return self.Vte.CursorShape.BLOCK

    def create_tab(self, cwd: Optional[str] = None, command: Optional[List[str]] = None, title: str = "") -> None:
        Gtk = self.Gtk
        Vte = self.Vte
        GLib = self.GLib
        cfg = self.config
        working_dir = cwd or resolve_cwd(str(cfg.get("startup_cwd", "")))
        terminal = Vte.Terminal()
        terminal.set_scrollback_lines(int(cfg.get("scrollback_lines", 10000)))
        terminal.set_audible_bell(bool(cfg.get("audible_bell", False)))
        terminal.set_cursor_blink_mode(
            self.Vte.CursorBlinkMode.ON if cfg.get("cursor_blink", True) else self.Vte.CursorBlinkMode.OFF
        )
        terminal.set_cursor_shape(self._cursor_shape_value())
        terminal.set_font(self._configured_font())
        self._apply_terminal_theme(terminal)
        terminal.connect("button-press-event", self._on_terminal_button)
        terminal.connect("child-exited", self._on_child_exited)
        terminal.connect("window-title-changed", self._on_title_changed)

        label_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=2)
        label = Gtk.Label(label=title or "Terminal")
        label.get_style_context().add_class("sentinel-tab-label")
        close_button = Gtk.Button(label="×")
        close_button.set_relief(Gtk.ReliefStyle.NONE)
        close_button.set_focus_on_click(False)
        close_button.get_style_context().add_class("sentinel-tab-close")
        label_box.pack_start(label, True, True, 0)
        label_box.pack_start(close_button, False, False, 0)
        label_box.show_all()

        page_index = self.notebook.append_page(terminal, label_box)
        tab = TerminalTab(terminal=terminal, widget=terminal, label=label, cwd=working_dir, custom_title=title or "")
        self.tabs.insert(page_index, tab)
        close_button.connect("clicked", lambda *_: self.close_tab(tab))
        self.notebook.set_current_page(page_index)
        self.GLib.idle_add(self._focus_current_terminal)

        shell = resolve_shell(str(cfg.get("default_shell", "")))
        argv = command if command else [shell]
        try:
            terminal.spawn_async(
                Vte.PtyFlags.DEFAULT,
                working_dir,
                argv,
                parse_env_for_vte(),
                GLib.SpawnFlags.DEFAULT,
                None,
                None,
                -1,
                None,
                self._on_spawn_complete,
                tab,
            )
            self._set_status(f"Opened tab in {working_dir}")
            terminal.grab_focus()
        except Exception as exc:
            log_crash(exc)
            tab.label.set_text("Spawn failed")
            self._set_status(f"Shell launch failed: {exc}")

    def _on_spawn_complete(self, terminal: Any, pid: int, error: Any, tab: TerminalTab) -> None:
        if error:
            self._set_status(f"Shell launch error: {error}")
        else:
            tab.child_pid = pid
            self._set_status(f"Shell running: pid {pid}")

    def _on_child_exited(self, terminal: Any, status: int) -> None:
        # The shell command `exit` ends the VTE child process. Close normal exited
        # tabs, but keep the window visible if startup failed abnormally so the user
        # sees the error instead of a disappearing app.
        target: Optional[TerminalTab] = None
        for tab in self.tabs:
            if tab.terminal == terminal:
                target = tab
                break
        self._set_status(f"Shell exited with status {status}")
        if target is None:
            return
        if status not in (0, 256) and len(self.tabs) <= 1:
            try:
                target.label.set_text(f"Exited ({status})")
            except Exception:
                pass
            self._set_status(f"Shell exited unexpectedly with status {status}; window kept open")
            return
        if len(self.tabs) <= 1:
            self._save_session_state()
            self.GLib.idle_add(lambda: (self.Gtk.main_quit(), False)[1])
            return
        self.GLib.idle_add(lambda: (self.close_tab(target), False)[1])

    def _on_title_changed(self, terminal: Any) -> None:
        title = terminal.get_window_title() or "Terminal"
        short = title if len(title) <= 28 else title[:25] + "..."
        for tab in self.tabs:
            if tab.terminal == terminal:
                if not tab.custom_title:
                    tab.label.set_text(short)
                break

    def duplicate_current_tab(self) -> None:
        tab = self._current_tab()
        cwd = self._new_tab_cwd()
        title = ""
        if tab and tab.custom_title:
            title = f"{tab.custom_title} copy"
        self.create_tab(cwd=cwd, title=title)
        self._set_status(f"Duplicated tab in {cwd}")

    def rename_current_tab(self) -> None:
        Gtk = self.Gtk
        tab = self._current_tab()
        if not tab:
            return
        dialog = Gtk.Dialog(title="Rename Tab", transient_for=self.window, flags=0)
        self._apply_dialog_theme(dialog)
        dialog.add_button("Cancel", Gtk.ResponseType.CANCEL)
        dialog.add_button("Rename", Gtk.ResponseType.OK)
        entry = Gtk.Entry(text=tab.custom_title or tab.label.get_text() or "Terminal")
        entry.set_activates_default(True)
        box = dialog.get_content_area()
        box.set_border_width(10)
        box.set_spacing(8)
        box.pack_start(Gtk.Label(label="Tab title:"), False, False, 0)
        box.pack_start(entry, False, False, 0)
        dialog.set_default_response(Gtk.ResponseType.OK)
        dialog.show_all()
        response = dialog.run()
        title = entry.get_text().strip()[:80]
        dialog.destroy()
        if response == Gtk.ResponseType.OK:
            tab.custom_title = title
            tab.label.set_text(title or "Terminal")
            self._set_status("Tab renamed" if title else "Tab title reset")
            self._save_session_state()

    def switch_tab_relative(self, delta: int) -> None:
        count = len(self.tabs)
        if count <= 0:
            return
        page = self.notebook.get_current_page()
        self.notebook.set_current_page((page + delta) % count)

    def switch_tab_number(self, number: int) -> None:
        idx = number - 1
        if 0 <= idx < len(self.tabs):
            self.notebook.set_current_page(idx)

    def close_current_tab(self) -> None:
        tab = self._current_tab()
        if tab:
            self.close_tab(tab)

    def close_tab(self, tab: TerminalTab) -> None:
        if tab not in self.tabs:
            self._set_status("Tab already closed")
            return
        if len(self.tabs) <= 1:
            self.quit()
            return
        idx = self.tabs.index(tab)
        self.notebook.remove_page(idx)
        self.tabs.pop(idx)
        self._set_status("Closed tab")
        self._save_session_state()

    def copy_clipboard(self) -> None:
        tab = self._current_tab()
        if tab:
            try:
                tab.terminal.copy_clipboard_format(self.Vte.Format.TEXT)
            except Exception:
                try:
                    tab.terminal.copy_clipboard()
                except Exception as exc:
                    log_crash(exc)
                    self._set_status("Copy unavailable on this VTE build")

    def safe_paste(self) -> None:
        tab = self._current_tab()
        if not tab:
            return
        clipboard = self.Gtk.Clipboard.get(self.Gdk.SELECTION_CLIPBOARD)
        text = clipboard.wait_for_text()
        if text:
            risk = analyze_paste_risk(text)
            should_warn = False
            if self.config.get("warn_multiline_paste", True) and risk.get("line_count", 0) > 1:
                should_warn = True
            if self.config.get("dangerous_paste_warning", True) and risk.get("severity") in {"medium", "high"}:
                should_warn = True
            if should_warn:
                title = "Sentinel paste safety warning"
                warning = format_paste_risk_warning(risk)
                if not self._confirm(title, warning):
                    self._set_status("Paste cancelled by user")
                    return
                self._set_status("Paste approved by user after warning")
        tab.terminal.paste_clipboard()

    def select_all(self) -> None:
        tab = self._current_tab()
        if tab:
            try:
                tab.terminal.select_all()
            except Exception:
                self._set_status("Select all is not available on this VTE build")

    def zoom(self, delta: int) -> None:
        self.zoom_delta = max(-5, min(12, self.zoom_delta + delta))
        for tab in self.tabs:
            tab.terminal.set_font(self._configured_font())
        self._set_status(f"Zoom offset: {self.zoom_delta:+d}")

    def reset_zoom(self) -> None:
        self.zoom_delta = 0
        for tab in self.tabs:
            tab.terminal.set_font(self._configured_font())
        self._set_status("Zoom reset")

    def toggle_fullscreen(self) -> None:
        state = self.window.get_window().get_state() if self.window.get_window() else 0
        if state & self.Gdk.WindowState.FULLSCREEN:
            self.window.unfullscreen()
        else:
            self.window.fullscreen()

    def show_find(self) -> None:
        self.show_find_dialog()

    def _set_search_regex(self, tab: TerminalTab, query: str) -> bool:
        try:
            regex = self.GLib.Regex.new(self.GLib.Regex.escape_string(query), 0, 0)
            if hasattr(tab.terminal, "search_set_gregex"):
                tab.terminal.search_set_gregex(regex, 0)
                return True
            if hasattr(tab.terminal, "search_set_regex"):
                tab.terminal.search_set_regex(regex, 0)
                return True
        except Exception as exc:
            log_crash(exc)
            self._set_status(f"Find unavailable: {exc}")
        return False

    def find_next_from_bar(self) -> None:
        if self.last_find_query:
            self._find_next(self.last_find_query)
        else:
            self.show_find_dialog()

    def find_previous_from_bar(self) -> None:
        if self.last_find_query:
            self._find_previous(self.last_find_query)
        else:
            self.show_find_dialog()

    def _find_next(self, query: str) -> None:
        tab = self._current_tab()
        if not tab:
            return
        if not self._set_search_regex(tab, query):
            return
        self.last_find_query = query
        try:
            tab.terminal.search_find_next()
            self._set_status(f"Find next: {query}")
        except Exception as exc:
            log_crash(exc)
            self._set_status(f"Find next unavailable: {exc}")

    def _find_previous(self, query: str) -> None:
        tab = self._current_tab()
        if not tab:
            return
        if not self._set_search_regex(tab, query):
            return
        self.last_find_query = query
        try:
            tab.terminal.search_find_previous()
            self._set_status(f"Find previous: {query}")
        except Exception as exc:
            log_crash(exc)
            self._set_status(f"Find previous unavailable: {exc}")

    def clear_scrollback(self) -> None:
        tab = self._current_tab()
        if not tab:
            return
        try:
            tab.terminal.reset(False, True)
            self._set_status("Scrollback cleared")
        except Exception as exc:
            log_crash(exc)
            self._set_status(f"Clear scrollback unavailable: {exc}")

    def _terminal_text_snapshot(self, tab: TerminalTab) -> str:
        try:
            result = tab.terminal.get_text(lambda *_: True)
            if isinstance(result, tuple):
                return str(result[0] or "")
            return str(result or "")
        except TypeError:
            try:
                result = tab.terminal.get_text()
                if isinstance(result, tuple):
                    return str(result[0] or "")
                return str(result or "")
            except Exception as exc:
                log_crash(exc)
        except Exception as exc:
            log_crash(exc)
        return ""

    def save_terminal_output(self) -> None:
        Gtk = self.Gtk
        tab = self._current_tab()
        if not tab:
            return
        dialog = Gtk.FileChooserDialog(
            title="Save Terminal Output",
            transient_for=self.window,
            action=Gtk.FileChooserAction.SAVE,
        )
        self._apply_dialog_theme(dialog)
        dialog.add_button("Cancel", Gtk.ResponseType.CANCEL)
        dialog.add_button("Save", Gtk.ResponseType.OK)
        dialog.set_current_name("sentinel-terminal-output.txt")
        response = dialog.run()
        filename = dialog.get_filename()
        dialog.destroy()
        if response != Gtk.ResponseType.OK or not filename:
            return
        try:
            output = self._terminal_text_snapshot(tab)
            if not output:
                output = "[No terminal output captured by this VTE build.]\n"
            Path(filename).write_text(output, encoding="utf-8", errors="replace")
            self._set_status(f"Saved terminal output: {filename}")
        except Exception as exc:
            log_crash(exc)
            self._set_status(f"Save output failed: {exc}")

    def open_current_folder(self) -> None:
        tab = self._current_tab()
        if not tab:
            return
        cwd = self._tab_current_cwd(tab)
        try:
            launcher = shutil.which("xdg-open") or shutil.which("gio") or ""
            if launcher.endswith("gio"):
                subprocess.Popen([launcher, "open", cwd])
            elif launcher:
                subprocess.Popen([launcher, cwd])
            else:
                self._set_status("No file manager opener found")
                return
            self._set_status(f"Opened folder: {cwd}")
        except Exception as exc:
            log_crash(exc)
            self._set_status(f"Open folder failed: {exc}")

    def show_preferences(self) -> None:
        Gtk = self.Gtk
        dialog = Gtk.Dialog(title="Sentinel Terminal Preferences", transient_for=self.window, flags=0)
        self._apply_dialog_theme(dialog)
        dialog.add_button("Cancel", Gtk.ResponseType.CANCEL)
        dialog.add_button("Apply", Gtk.ResponseType.APPLY)
        dialog.add_button("Save", Gtk.ResponseType.OK)
        dialog.set_default_size(560, 420)

        area = dialog.get_content_area()
        area.set_border_width(12)
        area.set_spacing(10)

        notebook = Gtk.Notebook()
        area.pack_start(notebook, True, True, 0)

        terminal_grid = Gtk.Grid(column_spacing=10, row_spacing=8, margin=12)
        shell_grid = Gtk.Grid(column_spacing=10, row_spacing=8, margin=12)
        safety_grid = Gtk.Grid(column_spacing=10, row_spacing=8, margin=12)

        notebook.append_page(terminal_grid, Gtk.Label(label="Terminal"))
        notebook.append_page(shell_grid, Gtk.Label(label="Shell"))
        notebook.append_page(safety_grid, Gtk.Label(label="Safety"))

        def attach_row(grid: Any, row: int, label_text: str, widget: Any) -> None:
            label = Gtk.Label(label=label_text)
            label.set_xalign(0)
            grid.attach(label, 0, row, 1, 1)
            grid.attach(widget, 1, row, 1, 1)

        # Terminal appearance
        font_button = Gtk.FontButton()
        font_button.set_use_font(True)
        font_button.set_use_size(True)
        font_button.set_font_name(str(self.config.get("font_description", f"{self.config.get('font_family', 'Monospace')} {self.config.get('font_size', 11)}")))

        theme_combo = Gtk.ComboBoxText()
        for value in THEME_MENU_ORDER:
            theme_combo.append(value, THEME_PRESETS[value]["label"])
        theme_combo.set_active_id(normalize_theme_id(self.config.get("theme", "sentinel_suite_dark")))

        cursor_combo = Gtk.ComboBoxText()
        for value, label in [("block", "Block"), ("ibeam", "I-Beam"), ("underline", "Underline")]:
            cursor_combo.append(value, label)
        cursor_combo.set_active_id(str(self.config.get("cursor_shape", "block")))

        scroll_spin = Gtk.SpinButton.new_with_range(100, 500000, 100)
        scroll_spin.set_value(int(self.config.get("scrollback_lines", 10000)))

        cursor_blink_check = Gtk.CheckButton(label="Cursor blink")
        cursor_blink_check.set_active(bool(self.config.get("cursor_blink", True)))
        bell_check = Gtk.CheckButton(label="Audible bell")
        bell_check.set_active(bool(self.config.get("audible_bell", False)))

        attach_row(terminal_grid, 0, "Font", font_button)
        attach_row(terminal_grid, 1, "Theme preset", theme_combo)
        attach_row(terminal_grid, 2, "Cursor shape", cursor_combo)
        attach_row(terminal_grid, 3, "Scrollback lines", scroll_spin)
        terminal_grid.attach(cursor_blink_check, 0, 4, 2, 1)
        terminal_grid.attach(bell_check, 0, 5, 2, 1)

        # Shell/startup
        shell_entry = Gtk.Entry(text=str(self.config.get("default_shell", "")))
        shell_entry.set_placeholder_text("Leave blank to use $SHELL")
        shell_button = Gtk.Button(label="Use detected shell")

        cwd_entry = Gtk.Entry(text=str(self.config.get("startup_cwd", "")))
        cwd_entry.set_placeholder_text("Leave blank to start in home")
        cwd_button = Gtk.Button(label="Browse...")

        cwd_mode_combo = Gtk.ComboBoxText()
        for value, label in [("current", "New tab: current folder"), ("home", "New tab: home folder"), ("configured", "New tab: configured startup folder")]:
            cwd_mode_combo.append(value, label)
        cwd_mode_combo.set_active_id(str(self.config.get("new_tab_cwd_mode", "current")))

        shell_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        shell_box.pack_start(shell_entry, True, True, 0)
        shell_box.pack_start(shell_button, False, False, 0)

        cwd_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        cwd_box.pack_start(cwd_entry, True, True, 0)
        cwd_box.pack_start(cwd_button, False, False, 0)

        def choose_detected_shell(*_: Any) -> None:
            shell_entry.set_text(resolve_shell(""))

        def choose_startup_folder(*_: Any) -> None:
            chooser = Gtk.FileChooserDialog(
                title="Choose startup folder",
                transient_for=dialog,
                action=Gtk.FileChooserAction.SELECT_FOLDER,
            )
            self._apply_dialog_theme(chooser)
            chooser.add_button("Cancel", Gtk.ResponseType.CANCEL)
            chooser.add_button("Choose", Gtk.ResponseType.OK)
            current = cwd_entry.get_text().strip()
            if current and Path(os.path.expanduser(current)).is_dir():
                chooser.set_filename(os.path.expanduser(current))
            response = chooser.run()
            if response == Gtk.ResponseType.OK:
                selected = chooser.get_filename()
                if selected:
                    cwd_entry.set_text(selected)
            chooser.destroy()

        shell_button.connect("clicked", choose_detected_shell)
        cwd_button.connect("clicked", choose_startup_folder)

        attach_row(shell_grid, 0, "Default shell", shell_box)
        attach_row(shell_grid, 1, "Startup folder", cwd_box)
        attach_row(shell_grid, 2, "New tab folder", cwd_mode_combo)

        # Safety
        warn_check = Gtk.CheckButton(label="Warn before multiline paste")
        warn_check.set_active(bool(self.config.get("warn_multiline_paste", True)))
        confirm_check = Gtk.CheckButton(label="Confirm before closing multiple active tabs")
        confirm_check.set_active(bool(self.config.get("confirm_close", True)))
        menubar_check = Gtk.CheckButton(label="Show menu bar")
        menubar_check.set_active(bool(self.config.get("show_menubar", True)))
        restore_size_check = Gtk.CheckButton(label="Restore last window size")
        restore_size_check.set_active(bool(self.config.get("restore_window_size", True)))
        restore_tabs_check = Gtk.CheckButton(label="Restore previous tabs")
        restore_tabs_check.set_active(bool(self.config.get("restore_tabs", False)))
        remember_active_check = Gtk.CheckButton(label="Remember active tab")
        remember_active_check.set_active(bool(self.config.get("remember_active_tab", True)))
        dangerous_paste_check = Gtk.CheckButton(label="Warn before dangerous paste patterns")
        dangerous_paste_check.set_active(bool(self.config.get("dangerous_paste_warning", True)))

        safety_grid.attach(warn_check, 0, 0, 2, 1)
        safety_grid.attach(dangerous_paste_check, 0, 1, 2, 1)
        safety_grid.attach(confirm_check, 0, 2, 2, 1)
        safety_grid.attach(menubar_check, 0, 3, 2, 1)
        safety_grid.attach(restore_size_check, 0, 4, 2, 1)
        safety_grid.attach(restore_tabs_check, 0, 5, 2, 1)
        safety_grid.attach(remember_active_check, 0, 6, 2, 1)

        status = Gtk.Label(label="Apply changes for this session or Save them to disk.")
        status.set_xalign(0)
        area.pack_start(status, False, False, 0)

        def collect_config() -> Dict[str, Any]:
            font_name = font_button.get_font_name() or "Monospace 11"
            parts = font_name.rsplit(" ", 1)
            family = parts[0] if parts else "Monospace"
            try:
                size = int(parts[1]) if len(parts) > 1 else int(self.config.get("font_size", 11))
            except Exception:
                size = int(self.config.get("font_size", 11))
            return normalize_config({
                **self.config,
                "font_family": family,
                "font_size": size,
                "font_description": f"{family} {size}",
                "theme": theme_combo.get_active_id() or "aegis_dark",
                "cursor_shape": cursor_combo.get_active_id() or "block",
                "scrollback_lines": int(scroll_spin.get_value()),
                "cursor_blink": cursor_blink_check.get_active(),
                "audible_bell": bell_check.get_active(),
                "default_shell": shell_entry.get_text().strip(),
                "startup_cwd": cwd_entry.get_text().strip(),
                "new_tab_cwd_mode": cwd_mode_combo.get_active_id() or "current",
                "warn_multiline_paste": warn_check.get_active(),
                "confirm_close": confirm_check.get_active(),
                "show_menubar": menubar_check.get_active(),
                "restore_window_size": restore_size_check.get_active(),
                "restore_tabs": restore_tabs_check.get_active(),
                "remember_active_tab": remember_active_check.get_active(),
                "dangerous_paste_warning": dangerous_paste_check.get_active(),
                "safety_warn_only": True,
                "show_header": False,
            })

        def apply_now(saved: bool = False) -> None:
            self.config = collect_config()
            self._apply_preferences()
            if saved:
                save_config(self.config)
                status.set_markup(f"<span foreground='{AEGIS_SUCCESS}'>Preferences saved.</span>")
            else:
                status.set_markup(f"<span foreground='{AEGIS_SUCCESS}'>Preferences applied for this session.</span>")

        dialog.show_all()
        while True:
            response = dialog.run()
            if response == Gtk.ResponseType.APPLY:
                apply_now(saved=False)
                continue
            if response == Gtk.ResponseType.OK:
                apply_now(saved=True)
                break
            break
        dialog.destroy()

    def _apply_preferences(self, theme_only: bool = False) -> None:
        apply_css(self.Gtk, self.Gdk, self.config.get("theme", "sentinel_suite_dark"))
        font = self._configured_font()
        for tab in self.tabs:
            self._apply_terminal_theme(tab.terminal)
            tab.terminal.set_font(font)
            tab.terminal.set_scrollback_lines(int(self.config.get("scrollback_lines", 10000)))
            tab.terminal.set_audible_bell(bool(self.config.get("audible_bell", False)))
            tab.terminal.set_cursor_blink_mode(
                self.Vte.CursorBlinkMode.ON if self.config.get("cursor_blink", True) else self.Vte.CursorBlinkMode.OFF
            )
            tab.terminal.set_cursor_shape(self._cursor_shape_value())
        if not theme_only:
            self._set_status("Preferences applied")

    def show_about(self) -> None:
        Gtk = self.Gtk
        dialog = Gtk.AboutDialog(transient_for=self.window, modal=True)
        self._apply_dialog_theme(dialog)
        dialog.set_program_name(APP_NAME)
        dialog.set_version(VERSION)
        dialog.set_comments(f"Official lightweight SentinelOS terminal emulator.\n{THEME_PRESETS[normalize_theme_id(self.config.get('theme'))]['label']} themed GTK3/VTE shell.")
        dialog.set_website("https://local.sentinel.os")
        if ICON_PNG.exists():
            try:
                pixbuf = self.GdkPixbuf.Pixbuf.new_from_file_at_scale(str(ICON_PNG), 96, 96, True)
                dialog.set_logo(pixbuf)
            except Exception:
                dialog.set_logo_icon_name("sentinel-terminal")
        else:
            dialog.set_logo_icon_name("sentinel-terminal")
        dialog.run()
        dialog.destroy()

    def _on_terminal_button(self, terminal: Any, event: Any) -> bool:
        if getattr(event, "button", 0) != 3:
            return False
        Gtk = self.Gtk
        menu = Gtk.Menu()
        try:
            menu.get_style_context().add_class("sentinel-popup-menu")
        except Exception:
            pass
        actions = [
            ("Copy", lambda *_: self.copy_clipboard()),
            ("Paste", lambda *_: self.safe_paste()),
            ("Find...", lambda *_: self.show_find_dialog()),
            ("Clear Scrollback", lambda *_: self.clear_scrollback()),
            ("Save Output", lambda *_: self.save_terminal_output()),
            ("Open Current Folder", lambda *_: self.open_current_folder()),
            ("New Tab", lambda *_: self.create_tab(cwd=self._new_tab_cwd())),
            ("Duplicate Tab", lambda *_: self.duplicate_current_tab()),
            ("Rename Tab", lambda *_: self.rename_current_tab()),
            ("Close Tab", lambda *_: self.close_current_tab()),
            ("Preferences", lambda *_: self.show_preferences()),
        ]
        for label, callback in actions:
            item = Gtk.MenuItem(label=label)
            item.connect("activate", callback)
            menu.append(item)
        menu.show_all()
        menu.popup_at_pointer(event)
        return True

    def interrupt_current_task(self) -> None:
        tab = self._current_tab()
        if not tab:
            return
        try:
            # Ctrl+C in a terminal means SIGINT/interrupt. Ctrl+Shift+C remains copy.
            tab.terminal.feed_child(b"\x03", 1)
            self._set_status("Interrupt sent: Ctrl+C")
        except TypeError:
            try:
                tab.terminal.feed_child("\x03", 1)
                self._set_status("Interrupt sent: Ctrl+C")
            except Exception as exc:
                log_crash(exc)
                self._set_status(f"Interrupt unavailable: {exc}")
        except Exception as exc:
            log_crash(exc)
            self._set_status(f"Interrupt unavailable: {exc}")

    def _on_key_press(self, widget: Any, event: Any) -> bool:
        Gdk = self.Gdk
        key = event.keyval
        state = event.state
        ctrl = bool(state & Gdk.ModifierType.CONTROL_MASK)
        shift = bool(state & Gdk.ModifierType.SHIFT_MASK)
        if key == Gdk.KEY_F11:
            self.toggle_fullscreen(); return True
        if key == Gdk.KEY_F3 and shift:
            self.find_previous_from_bar(); return True
        if key == Gdk.KEY_F3:
            self.find_next_from_bar(); return True
        if key == Gdk.KEY_Escape:
            return False
        if ctrl and shift and key in (Gdk.KEY_T, Gdk.KEY_t):
            self.create_tab(cwd=self._new_tab_cwd()); return True
        if ctrl and shift and key in (Gdk.KEY_D, Gdk.KEY_d):
            self.duplicate_current_tab(); return True
        if ctrl and shift and key in (Gdk.KEY_R, Gdk.KEY_r):
            self.rename_current_tab(); return True
        if ctrl and shift and key in (Gdk.KEY_K, Gdk.KEY_k):
            self.clear_scrollback(); return True
        if ctrl and shift and key in (Gdk.KEY_S, Gdk.KEY_s):
            self.save_terminal_output(); return True
        if ctrl and shift and key in (Gdk.KEY_O, Gdk.KEY_o):
            self.open_current_folder(); return True
        if ctrl and key == Gdk.KEY_Page_Down:
            self.switch_tab_relative(1); return True
        if ctrl and key == Gdk.KEY_Page_Up:
            self.switch_tab_relative(-1); return True
        if bool(state & Gdk.ModifierType.MOD1_MASK):
            for num, gdk_key in enumerate((Gdk.KEY_1, Gdk.KEY_2, Gdk.KEY_3, Gdk.KEY_4, Gdk.KEY_5, Gdk.KEY_6, Gdk.KEY_7, Gdk.KEY_8, Gdk.KEY_9), start=1):
                if key == gdk_key:
                    self.switch_tab_number(num); return True
        if ctrl and shift and key in (Gdk.KEY_W, Gdk.KEY_w):
            self.close_current_tab(); return True
        if ctrl and shift and key in (Gdk.KEY_C, Gdk.KEY_c):
            self.copy_clipboard(); return True
        if ctrl and not shift and key in (Gdk.KEY_C, Gdk.KEY_c):
            self.interrupt_current_task(); return True
        if ctrl and shift and key in (Gdk.KEY_V, Gdk.KEY_v):
            self.safe_paste(); return True
        if ctrl and key in (Gdk.KEY_Q, Gdk.KEY_q):
            self.quit(); return True
        return False

    def _on_delete(self, *_: Any) -> bool:
        return not self.quit(confirm_only=True)

    def quit(self, confirm_only: bool = False) -> bool:
        if self.config.get("confirm_close", True) and len(self.tabs) > 1:
            if not self._confirm("Close Sentinel Terminal", f"Close {len(self.tabs)} open terminal tabs?"):
                return False
        if not confirm_only:
            self._save_session_state()
            self.Gtk.main_quit()
        return True

    def _confirm(self, title: str, text: str) -> bool:
        Gtk = self.Gtk
        dialog = Gtk.MessageDialog(
            transient_for=self.window,
            flags=0,
            message_type=Gtk.MessageType.WARNING,
            buttons=Gtk.ButtonsType.OK_CANCEL,
            text=title,
        )
        self._apply_dialog_theme(dialog)
        dialog.format_secondary_text(text)
        response = dialog.run()
        dialog.destroy()
        return response == Gtk.ResponseType.OK

    def _set_status(self, text: str) -> None:
        self.status_label.set_text(text)

    def _smoke_quit(self) -> bool:
        print("GUI smoke test passed")
        self.Gtk.main_quit()
        return False

    def run(self) -> None:
        self.Gtk.main()


def run_gui(args: argparse.Namespace) -> int:
    deps = dependency_status()
    if not deps["gtk_vte_available"]:
        print("Sentinel Terminal GUI dependencies are missing.", file=sys.stderr)
        print("Required Debian packages: python3-gi gir1.2-gtk-3.0 gir1.2-vte-2.91", file=sys.stderr)
        if deps.get("error"):
            print(f"Details: {deps['error']}", file=sys.stderr)
        return 2
    if not deps.get("display_available"):
        print("Sentinel Terminal cannot find a graphical display.", file=sys.stderr)
        print("Start it from a desktop session or run under xvfb-run for smoke testing.", file=sys.stderr)
        return 2
    try:
        command = None
        if args.command:
            command = [resolve_shell(load_config(args.safe_mode).get("default_shell", "")), "-lc", args.command]
        startup_cwd = resolve_cwd(args.working_directory) if getattr(args, "working_directory", None) else None
        win = SentinelTerminalWindow(safe_mode=args.safe_mode, startup_command=command, startup_cwd=startup_cwd, gui_smoke_test=args.gui_smoke_test)
        win.run()
        return 0
    except Exception as exc:
        log_crash(exc)
        print(f"Sentinel Terminal crashed: {exc}", file=sys.stderr)
        print(f"Crash log: {CRASH_LOG}", file=sys.stderr)
        return 1


def print_doctor() -> int:
    status = runtime_check()
    deps = status["dependency_status"]
    print(f"{APP_NAME} Doctor")
    print(f"Version: {VERSION}")
    print(f"Python: {status['python']}")
    print(f"Shell: {status['shell']}")
    print(f"Config: {CONFIG_PATH}")
    print(f"Crash log: {CRASH_LOG}")
    print(f"Package assets: {PACKAGE_SHARE_DIR}")
    print(f"Icon present: {deps.get('icon_png_exists')}")
    print(f"Desktop launcher present: {deps.get('desktop_file_exists')}")
    print(f"GTK/VTE available: {deps.get('gtk_vte_available')}")
    print(f"Display available: {deps.get('display_available')} ({deps.get('display_backend')})")
    if deps.get("error"):
        print(f"Dependency detail: {deps['error']}")
    print(f"Config dir writable: {status['config_dir_writable']}")
    print(f"Data dir writable: {status['data_dir_writable']}")
    print(f"State dir writable: {status['state_dir_writable']}")
    for msg in status["self_test_messages"]:
        print(msg)
    if status["ready_for_gui"]:
        print("Doctor result: PASS — GUI runtime appears ready")
        return 0
    if status["self_test_passed"]:
        print("Doctor result: PASS with runtime warning")
        if not deps.get("gtk_vte_available"):
            print("Install/check: python3-gi gir1.2-gtk-3.0 gir1.2-vte-2.91")
        if not deps.get("display_available"):
            print("No active DISPLAY/WAYLAND_DISPLAY detected in this session.")
        return 0
    print("Doctor result: FAIL")
    return 1

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=f"{APP_NAME} v{VERSION}")
    parser.add_argument("--version", action="store_true", help="print version and exit")
    parser.add_argument("--self-test", action="store_true", help="run non-GUI self-tests")
    parser.add_argument("--doctor", action="store_true", help="run diagnostics")
    parser.add_argument("--runtime-check", action="store_true", help="print detailed host/runtime readiness JSON")
    parser.add_argument("--aegis-status", action="store_true", help="print machine-readable status JSON")
    parser.add_argument("--write-aegis-status", action="store_true", help="write status JSON under user data directory")
    parser.add_argument("--print-config", action="store_true", help="print effective config JSON")
    parser.add_argument("--reset-config", action="store_true", help="backup and reset user config")
    parser.add_argument("--safe-mode", action="store_true", help="start with default config and no saved preferences")
    parser.add_argument("--gui-smoke-test", action="store_true", help="start GUI briefly, then exit")
    parser.add_argument("-e", "--command", help="run command in a shell inside the terminal")
    parser.add_argument("--working-directory", "--cwd", dest="working_directory", help="start the terminal in this directory")
    return parser


def main(argv: Optional[List[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.version:
        print(f"{APP_NAME} {VERSION}")
        return 0
    if args.self_test:
        ok, messages = run_self_test()
        for msg in messages:
            print(msg)
        if ok:
            print("PASS: self-test")
            return 0
        print("FAIL: self-test")
        return 1
    if args.doctor:
        return print_doctor()
    if args.runtime_check:
        print(json.dumps(runtime_check(), indent=2, sort_keys=True))
        return 0
    if args.aegis_status:
        print(json.dumps(format_json_status(), indent=2, sort_keys=True))
        return 0
    if args.write_aegis_status:
        print(json.dumps(write_status(), indent=2, sort_keys=True))
        return 0
    if args.print_config:
        print(json.dumps(load_config(args.safe_mode), indent=2, sort_keys=True))
        return 0
    if args.reset_config:
        reset_config()
        print(f"Reset config: {CONFIG_PATH}")
        return 0
    return run_gui(args)


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
