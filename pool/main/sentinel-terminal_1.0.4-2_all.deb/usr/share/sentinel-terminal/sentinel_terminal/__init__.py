"""Sentinel Terminal package."""

VERSION = "1.0.4"
APP_ID = "sentinel-terminal"
APP_NAME = "Sentinel Terminal"
