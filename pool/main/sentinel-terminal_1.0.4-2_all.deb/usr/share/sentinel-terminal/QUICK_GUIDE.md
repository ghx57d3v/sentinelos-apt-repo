# Sentinel Terminal Quick Guide

Launch:

```sh
sentinel-terminal
```

Open in a specific folder:

```sh
sentinel-terminal --working-directory /path/to/folder
```

Theme switcher:

```text
Theme -> Sentinel Suite Dark / Gold
Theme -> Sentinel Cyan Light
Theme -> Sentinel Cyan Dark
```

Find is in the top menu:

```text
Search -> Find...
Search -> Find Next
Search -> Find Previous
```
