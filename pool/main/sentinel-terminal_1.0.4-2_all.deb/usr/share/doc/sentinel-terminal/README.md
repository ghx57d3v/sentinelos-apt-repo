# Sentinel Terminal v1.0.4 Darker Cyan Light Grey Hotfix

Official lightweight SentinelOS terminal emulator for GTK3/VTE on Debian/MATE.

## Changes in v1.0.4

- Darkened `Sentinel Cyan Light` into a **medium/darker grey base with cyan accents**.
- Kept the theme distinct from `Sentinel Cyan Dark`; it remains the lighter grey/cyan option, just no longer pale.
- Removed pale/near-white surface treatment from the window, panels, entries, and terminal body.
- White remains limited to selected/highlight text where it improves readability.
- Added a self-test guard that rejects Cyan Light surface luminance above the allowed darker-grey range.
- Preserved the top-menu `Theme` switcher and dialog/popup theme carryover from v1.0.2/v1.0.3.
- Preserved v1.0.1 redteam fixes: safer Caja Open Terminal Here, `--working-directory` / `--cwd`, and package bytecode cleanup.

## Install

```sh
chmod +x install.sh
./install.sh
```

Or directly:

```sh
sudo apt install ./sentinel-terminal_1.0.4-1_all.deb
sentinel-terminal-user-setup
```

## Validate

```sh
sentinel-terminal --self-test
sentinel-terminal-runtime-check
sentinel-terminal-doctor
```
