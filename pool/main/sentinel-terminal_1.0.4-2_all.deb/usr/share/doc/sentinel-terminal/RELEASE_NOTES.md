# Sentinel Terminal v1.0.4

Darker Cyan Light Grey Theme Hotfix.

- Darkened Sentinel Cyan Light to a medium/darker grey cyan palette.
- Added no-white and darker-grey luminance regression checks.
- Preserved theme menu, dialog/popup carryover, VTE theme switching, and prior redteam fixes.
