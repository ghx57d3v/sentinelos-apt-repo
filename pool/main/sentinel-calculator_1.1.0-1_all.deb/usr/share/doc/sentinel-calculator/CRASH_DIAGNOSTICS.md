# Sentinel Calculator v1.1.0 Crash Diagnostics

Logs are written to:

```text
~/.local/state/sentinel-calculator/sentinel-calculator.log
```

Run:

```bash
sentinel-calculator-doctor
sentinel-calculator --safe-mode
sentinel-calculator --gui-smoke-test
```

Currency and Market Exchange network errors are non-fatal. If online refresh fails, use cached conversion if a value has already been saved.
