# Sentinel Calculator v1.1.0

**Program:** 103 — SentinelOS Desktop Suite  
**Package:** `sentinel-calculator_1.1.0-1_all.deb`  
**Release:** Market Exchange upgrade

Sentinel Calculator is a themed AEGIS/SentinelOS calculator and utility panel. It preserves the v1.0.1 stable lock and adds an optional, manual-refresh **Market Exchange** tab for crypto and stock/ETF reference prices.

## Modes

- Standard calculator
- Scientific calculator
- Unit Converter — fully offline
- Currency Converter — online refresh plus local cached rates
- Market Exchange — optional manual-refresh crypto and stock/ETF lookup with local cache
- Programmer tools
- Network / CIDR calculator
- Defensive Security utilities
- Electronics / Ohm's law helper

## Install

```bash
sudo apt install ./sentinel-calculator_1.1.0-1_all.deb
sentinel-calculator-user-setup
sentinel-calculator-doctor
```

## Data caches

Currency rates are cached per user at:

```text
~/.local/share/sentinel-calculator/currency_rates_cache.json
```

Market Exchange prices are cached per user at:

```text
~/.local/share/sentinel-calculator/market_exchange_cache.json
```

## Market Exchange policy

Market Exchange is manual-refresh only. It does not auto-poll, trade, connect wallets, connect broker accounts, or provide financial advice. Crypto prices use CoinGecko simple price lookup. Stock/ETF prices use Stooq quote CSV lookup. Cached values are last-known references and may be stale.

## v1.1.0 notes

- Adds `Market Exchange` tab.
- Supports crypto amount × price conversion, for example BTC to AUD.
- Supports stock/ETF amount × latest-available quote, for example AAPL.US shares.
- Adds local cache fallback.
- Adds self-test coverage for market arithmetic and Stooq CSV parsing.
- Preserves SentinelOS / AEGIS dark/gold/cyan theming.
