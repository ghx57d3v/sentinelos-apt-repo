# Sentinel Calculator v1.1.0 Stable Test Checklist

- [ ] `sentinel-calculator --version` prints v1.1.0.
- [ ] `sentinel-calculator --self-test` passes.
- [ ] GUI opens normally from terminal.
- [ ] GUI opens from MATE menu launcher.
- [ ] Unit Converter handles length, data, temperature, and fuel economy.
- [ ] Currency Converter reports a clear error with no cache/offline.
- [ ] Currency Converter refreshes online when network is available.
- [ ] Currency Converter reuses cached rates offline.
- [ ] Market Exchange reports a clear error with no cache/offline.
- [ ] Market Exchange refreshes crypto when network is available.
- [ ] Market Exchange refreshes stock/ETF symbols when network is available.
- [ ] Market Exchange reuses cached prices offline.
- [ ] Ctrl+Q closes the app.
- [ ] `sentinel-calculator-doctor` passes.
