# Sentinel Calculator v1.1.0 Release Notes

## v1.1.0 — Market Exchange Upgrade

Adds a new optional **Market Exchange** tab while preserving the v1.0.1 stable calculator/converter/theming baseline.

### Added

- Crypto reference price lookup and amount conversion.
- Stock/ETF latest-available quote lookup.
- Manual refresh only; no auto-polling.
- Local market cache at `~/.local/share/sentinel-calculator/market_exchange_cache.json`.
- Cached market conversion fallback.
- Market self-test coverage for crypto symbol normalization, value arithmetic, and Stooq CSV parsing.
- Desktop keywords for crypto, stock, market, and exchange.

### Preserved

- Standard and Scientific calculator modes.
- Offline Unit Converter.
- Currency Converter with online refresh and local cache.
- Programmer, Network, defensive Security, and Electronics modes.
- Safe mode, reset settings, crash logging, doctor, and GUI smoke test.
- SentinelOS / AEGIS theme alignment from v1.0.1.

### Market safety policy

Market Exchange is informational only. It does not provide financial advice, place trades, connect wallets, connect exchanges, or connect broker accounts. Prices may be delayed, stale, unavailable, or different from your exchange/broker.
