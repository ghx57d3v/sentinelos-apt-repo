# Sentinel Notes v1.0.2 — Checklist Templates Patch

Program 102 — Sentinel Notes is the local-first notes, tasks, simple finance-table, and AEGIS-ready note app for the Sentinel Desktop Suite.

v1.0.2 preserves the v1 stable-locked baseline from v1.0.1 and adds built-in task/checklist templates for common outings and pre-departure checks.

## Added in v1.0.2

- Built-in holiday/task checklist templates:
  - Camping
  - Snow Trip
  - Car Trip
  - Mountain Climbing / Hiking
  - Picnic
  - General Holiday Packing
  - Pre-Leave the House Checklist
- GUI **Checklist Templates** picker.
- GUI **Tick/Untick** helper for checkbox task lines.
- ENTER in Tasks mode now continues checkbox lists when the current line is a checkbox.
- CLI template commands:

```bash
sentinel-notes --list-checklist-templates-json
sentinel-notes --checklist-template-info camping
sentinel-notes --create-checklist-template pre-leave-house
sentinel-notes --create-checklist-template snow --title "Weekend Snow Trip"
```

## Stable-lock commands

```bash
sentinel-notes --health-json
sentinel-notes --aegis-actions-json
sentinel-notes --aegis-capabilities-json
sentinel-notes --stable-lock-report
```

## Install

```bash
sudo ./install.sh --system --clean-shadow
sudo sentinel-notes-repair "$USER"
sentinel-notes-user-setup --clean-shadow
hash -r
sentinel-notes --version
sentinel-notes --self-check
sentinel-notes-doctor
```

Expected version:

```text
Sentinel Notes 1.0.2 (Program 102)
```

Do not run the app with sudo. User notes belong under the normal user's local data folder, not `/root`.

## GUI use

Open **Sentinel Notes**, click **Checklist Templates**, choose a template, then either:

- **Load Template** to load it into the editor and save when ready, or
- **Create & Save** to immediately create a saved checklist note.

Tick items manually in the text, or place the cursor on a checkbox line and use **Tick/Untick**.

## AEGIS readiness

Sentinel Notes remains local-first and AEGIS-ready: CLI commands, JSON actions, manifest, permission model, audit logs, safe read/write boundaries, Vault export, and user-controlled encrypted access.
