# Sentinel Notes v1.0.2 Release Notes

Program 102 Sentinel Notes v1.0.2 is a post-v1 stable-lock feature patch over v1.0.1.

## Added

- Built-in task/checklist templates for:
  - Camping
  - Snow Trip
  - Car Trip
  - Mountain Climbing / Hiking
  - Picnic
  - General Holiday Packing
  - Pre-Leave the House Checklist
- GUI Checklist Templates picker.
- GUI Tick/Untick helper for checkbox lines.
- Checkbox-list continuation in Tasks mode when pressing ENTER on a checkbox line.
- CLI commands:
  - `--list-checklist-templates-json`
  - `--checklist-template-info TEMPLATE`
  - `--create-checklist-template TEMPLATE`
- AEGIS JSON actions:
  - `list_checklist_templates`
  - `checklist_template_info`
  - `create_checklist_template`

## Preserved

- v1 stable-lock posture.
- Local notes, task/checklist notes, and Finance Tables.
- Optional encryption.
- Local search and Markdown preview.
- Soft-delete trash.
- AEGIS manifest/actions/capabilities/health/stable-lock reports.
- Root write guard.
- Local-only/no-network/no-telemetry posture.

## Accepted v1 baseline limitations

- Rich formatting remains Markdown/helper based.
- Finance Tables remain lightweight local registers rather than a full spreadsheet engine.
- Encrypted notes/registers require the user passphrase and cannot be recovered without it.
