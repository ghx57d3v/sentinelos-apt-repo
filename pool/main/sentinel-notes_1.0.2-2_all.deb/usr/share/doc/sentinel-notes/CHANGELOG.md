# Changelog

## v1.0.2

- Added built-in holiday/task checklist templates: camping, snow trip, car trip, mountain climbing/hiking, picnic, general holiday packing, and pre-leave-house checklist.
- Added GUI Checklist Templates picker.
- Added GUI Tick/Untick helper for checkbox checklist lines.
- Added CLI commands for listing, inspecting, and creating checklist templates.
- Added AEGIS JSON actions for checklist template workflows.
- Preserved v1 stable-lock posture from v1.0.1.

## v1.0.1

- Stable-lock audit hotfix.
- Fixed normal-user self-check root-path crash risk.
- Updated AEGIS manifest/status/schema wording.
- Removed temporary build paths from static manifest.
- Updated installer/repair version checks.
- Added health/actions/capabilities/stable-lock report commands.

## v1.0.0

- Stable lock build for Program 102 Sentinel Notes.
- Tasks mode defaults to numbered lists.
- ENTER in Tasks mode continues numbered sequence.
- Checklist line insertion remains available through the toolbar.
- Ctrl+Q uses the normal close/unsaved-change path.

## Earlier

- v0.9.0: stabilization and self-check.
- v0.8.x: AEGIS review/export/audit, Finance Tables, install repair policy.
- v0.7.0: spreadsheet-style Finance Table cell editing direction.
- v0.6.x: desktop launcher/icon and GUI polish.
