# Sentinel Inventory Changelog

## v1.0.0 — Stable Lock / Audit / Backup Restore Patch

Built over v0.9.0.

Locks Program 115 as the v1 user-ready baseline.

### Added

- `stable-lock-report` JSON output.
- `audit-report` human-readable and machine-readable audit output.
- `export-audit-json`.
- `export-audit-csv`.
- `restore-backup BACKUP_DB --confirm RESTORE_INVENTORY` guarded restore workflow.
- Pre-restore safety copy before replacing the active database.
- `export-v1-bundle` complete local handoff bundle.
- v1 handoff manifest.
- Health JSON readiness flags:
  - `stable_lock_ready`
  - `v1_stable_baseline_locked`
  - `audit_report_ready`
  - `database_integrity_audit_ready`
  - `backup_restore_ready`
  - `v1_handoff_bundle_ready`
  - `stable_lock_report_ready`
- Bridge contract version raised to `1.0.0`.

### Locked baseline capabilities

- Local SQLite inventory database.
- GUI and CLI.
- Desktop/menu launcher and supplied Sentinel inventory icon.
- Sequential SKU autofill.
- USB keyboard-wedge barcode/QR scanner intake.
- Fast scanner movement, batch scan queue, transfer mode, duplicate debounce, and recent scan export.
- Barcode/SKU/serial lookup.
- Label/QR/print-prep exports.
- Expiry/freshness/stock rotation reports.
- Warranty and service/repair records.
- Reports and reorder list.
- Ledger/Pantry bridge exports and bridge bundle.
- Backup/restore/audit/v1 handoff bundle.
- AEGIS/Sentinel Command health JSON.
- Local-only / no-network / no-telemetry posture.

### Schema

Database schema remains v3.

## v0.9.0 — Ledger / Pantry Bridge Prep Patch

Built over v0.8.0.

Adds stable local bridge exports for future Sentinel Ledger, Sentinel Pantry, supplier reorder, Sentinel Command, and AEGIS readers.

### Added

- GUI **Bridge / Handoff** tab.
- Bridge status report and JSON output.
- Sentinel Ledger bridge CSV export.
- Sentinel Ledger bridge JSON export.
- Sentinel Pantry bridge CSV export.
- Sentinel Pantry bridge JSON export.
- Pantry/consumable candidate detection using expiry dates, low-stock thresholds, and practical pantry/consumable keywords.
- Supplier reorder handoff records.
- Bridge bundle export containing:
  - Ledger bridge CSV/JSON
  - Pantry bridge CSV/JSON
  - supplier reorder CSV
  - expiry rotation CSV
  - label payload JSON
  - bridge manifest JSON
- Health JSON readiness flags:
  - `ledger_bridge_export_ready`
  - `pantry_bridge_export_ready`
  - `supplier_reorder_handoff_ready`
  - `bridge_bundle_ready`
  - `bridge_manifest_ready`
  - `v1_bridge_contract_prep_ready`
  - `bridge_tab_ready`
- CLI commands:
  - `bridge-status`
  - `export-ledger-bridge-csv`
  - `export-ledger-bridge-json`
  - `export-pantry-bridge-csv`
  - `export-pantry-bridge-json`
  - `export-bridge-bundle`

### Preserved

- Expiry/freshness/rotation from v0.8.0.
- Label/QR/print prep from v0.7.0.
- Fast scanner movement and batch scanner workflow from v0.6.0.
- USB keyboard-wedge scanner intake from v0.5.0.
- Unknown scan create flow.
- Sequential SKU autofill from v0.4.0.
- Desktop launcher/menu/icon workflow.
- User supplied gold inventory/shield icon.
- Warranty and service tracking.
- Reports and reorder list.
- CSV/JSON export, backup, health JSON, local SQLite storage.
- Local-only / no-network / no-telemetry posture.

### Schema

Database schema remains v3. The bridge patch uses the existing item, expiry, movement, label, scanner, service, and reorder data contracts.

## v0.8.0 — Expiry / Freshness / Stock Rotation Patch

Built over v0.7.0.

Adds stock expiry / best-before tracking so Sentinel Inventory can tell the user what is expired, what is close to expiry, what is still in good date, and what is freshest.

### Added

- Item-level `expiry_date` / best-before field.
- GUI **Expiry / Rotation** tab.
- GUI item form field: **Stock Expiry / Best Before**.
- Item list freshness/status columns.
- Expired stock report.
- Close-to-expiry stock report with default 30-day warning window.
- Good-date stock report.
- Freshest-stock report sorted by furthest future expiry.
- Unknown-expiry count for stock that needs date entry.
- Expiry CSV export.
- Label exports now include expiry date and expiry status.
- Dashboard expiry counts.
- Health JSON readiness flags:
  - `stock_expiry_tracking_ready`
  - `expiry_rotation_ready`
  - `freshest_stock_report_ready`
  - `good_date_stock_report_ready`
  - `expiry_csv_export_ready`
  - `expiry_tab_ready`
- CLI commands:
  - `expiry-report`
  - `freshest-stock`
  - `export-expiry-csv`
- `add --expiry YYYY-MM-DD` and `scan-create --expiry YYYY-MM-DD`.

### Preserved

- Label/QR/print prep from v0.7.0.
- Fast scanner movement and batch scanner workflow from v0.6.0.
- USB keyboard-wedge scanner intake from v0.5.0.
- Unknown scan create flow.
- Sequential SKU autofill from v0.4.0.
- Desktop launcher/menu/icon workflow.
- User supplied gold inventory/shield icon.
- Warranty and service tracking.
- Reports and reorder list.
- CSV/JSON export, backup, health JSON, local SQLite storage.
- Local-only / no-network / no-telemetry posture.

### Schema

Database schema advances to v3. The v3 migration adds `items.expiry_date` plus `idx_items_expiry_date`.

## v0.7.0 — Labels / QR / Print Prep Patch

- Added GUI Labels / QR tab, local QR payloads, printable HTML label sheets, label CSV/JSON, optional QR PNG export, and label readiness health flags.

## v0.6.0 — Fast Stock Movement / Batch Scanner Patch

- Added scanner fast movement mode, batch scans, scan transfer, duplicate debounce, and recent scan export.

## v0.5.0 — Barcode / USB Scanner Intake Patch

- Added GUI Scanner tab with large scanner input field.
- Added barcode/SKU/serial scanner lookup.
- Added scanner restock, consume, adjust, and create-from-scan workflows.
- Added USB HID keyboard-wedge readiness flags.

## v0.4.0 — Sequential SKU / Item Entry Patch

- GUI Items tab auto-fills the next sequential SKU.
- Default SKU sequence: `INV-0001`, `INV-0002`, etc.
- Added `next-sku`, `set-sku-prefix`, and `add --sku-prefix`.
- Expanded health JSON with SKU readiness fields.

## v0.3.0 — Desktop Launcher / Warranty / Service Patch

- Added full desktop shortcut helpers.
- Added warranty expiry reports and service records.
- Added GUI Warranty / Service tab.
- Advanced database schema to v2.

## v0.2.0 — Desktop Icon / Reports / Reorder Patch

- Added supplied inventory icon integration.
- Added reports tab, valuation summaries, and reorder CSV export.

## v0.1.0 — Foundation

- Local SQLite inventory baseline with GUI, CLI, import/export, backup, health JSON, movement log, and MATE launcher.
