# Sentinel System Monitor v1.0.2

## Redteam Safety Hotfix
- Hardened cleanup against symlink-root data loss.
- Blocked cleanup and process actions when run as root.
- Enforced AEGIS local read-only policy at command dispatch.
- Preserved user removals from AEGIS `allowed_commands` and stripped forbidden commands.
- Redacted sensitive process command-line tokens.
- Fixed `/tmp` user-owned cleanup accounting.
- Fixed CLI process query filtering.
- Fixed AEGIS health/recommendation/report key drift.
- Switched internal helper relaunch paths to absolute Sentinel helper paths.
- Removed packaged `__pycache__` bytecode.
