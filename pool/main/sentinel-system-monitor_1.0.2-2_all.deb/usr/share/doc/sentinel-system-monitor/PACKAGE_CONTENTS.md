# Package Contents

- `/usr/bin/sentinel-system-monitor` — GUI launcher
- `/usr/bin/sentinel-system-monitor-widget` — widget launcher with private local error log
- `/usr/bin/sentinel-system-monitor-cli` — CLI interface
- `/usr/bin/sentinel-system-monitor-aegis` — local read-only AEGIS JSON interface
- `/usr/bin/sentinel-system-monitor-doctor` — diagnostics wrapper
- `/usr/share/sentinel-system-monitor/sentinel_system_monitor.py` — application runtime
- `/usr/share/applications/*.desktop` — menu launchers
- `/usr/share/icons/hicolor/.../sentinel-system-monitor.png` — icon asset
