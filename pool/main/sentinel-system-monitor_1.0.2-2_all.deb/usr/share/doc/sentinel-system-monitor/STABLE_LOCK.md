# Sentinel System Monitor Stable Branch

Current package: v1.0.2-1.

v1.0.2 preserves the v1 stable feature set and applies a redteam safety hotfix: symlink-safe cleanup, root destructive-action refusal, AEGIS policy enforcement, sensitive process argument redaction, diagnostics fixes, and clean package hygiene.
