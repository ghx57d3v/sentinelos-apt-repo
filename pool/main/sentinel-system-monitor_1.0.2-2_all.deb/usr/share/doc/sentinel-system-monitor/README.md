# Sentinel System Monitor v1.0.2

Program 108 — local-first SentinelOS system monitor.

This v1.0.2 package is a defensive redteam safety hotfix over v1.0.1. It keeps the local-only/no-telemetry/no-cloud design while hardening cleanup, process-control, AEGIS dispatch, helper execution, diagnostics, and package hygiene.

Install:

```bash
sudo apt install ./sentinel-system-monitor_1.0.2-1_all.deb
```

Useful commands:

```bash
sentinel-system-monitor
sentinel-system-monitor-widget
sentinel-system-monitor-cli status --json
sentinel-system-monitor-cli doctor --json
sentinel-system-monitor-aegis validate-policy
```
