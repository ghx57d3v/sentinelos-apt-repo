# SentinelOS Core Policy

This package owns the first SentinelOS package-delivered policy file:

- `/etc/sysctl.d/99-sentinelos-core.conf`

The v0.1.1 baseline intentionally stays small and defensive. It avoids aggressive hardening that could break desktop workflows.
