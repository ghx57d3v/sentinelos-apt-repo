# SentinelOS Desktop Cursor Baseline

This metapackage moves the cursor family and theme bindings into the
reproducible SentinelOS conversion baseline.

The conversion must run `sentinelos-apply-cursor-baseline` after all official
GTK/Marco desktop themes are installed.

## Base mapping

- Light Cyan desktop → Light Cyan cursor
- Dark Cyan desktop → Light Cyan cursor
- Light Green desktop → Light Green cursor
- Light Purple desktop → Light Purple cursor
- Dark Red desktop → Dark Red cursor
- Dark Pink desktop → Dark Pink cursor

White and Black remain neutral manual cursor choices.

AEGIS Navy/Gold is outside this package and belongs only to the exclusive
AEGIS Sentinel Suite desktop-theme bundle.
