#!/bin/sh
# SentinelOS conversion phase 65: desktop cursor baseline.
# Run after all official SentinelOS GTK/Marco themes have been installed.
set -eu

export DEBIAN_FRONTEND=noninteractive

apt-get update
apt-get install -y \
    sentinelos-cursor-themes=1.2.0-1 \
    sentinelos-theme-cursor-integration=1.0.0-1 \
    sentinelos-desktop-cursor-baseline=1.0.0-1

sentinelos-apply-cursor-baseline
