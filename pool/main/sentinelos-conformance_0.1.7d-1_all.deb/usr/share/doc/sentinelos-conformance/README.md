SentinelOS conformance tools for v0.1.7d.
