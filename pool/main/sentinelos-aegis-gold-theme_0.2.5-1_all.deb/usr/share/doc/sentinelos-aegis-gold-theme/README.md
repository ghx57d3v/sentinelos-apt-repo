AEGIS Gold v0.2.5 polished black/gold theme. Install only with AEGIS option.
