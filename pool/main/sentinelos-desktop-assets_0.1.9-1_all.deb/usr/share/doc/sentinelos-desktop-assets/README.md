SentinelOS desktop experience asset metadata and summary command.
