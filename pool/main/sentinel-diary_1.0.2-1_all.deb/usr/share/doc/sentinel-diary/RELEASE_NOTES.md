# Sentinel Diary v1.0.2 — Redteam Security Cleanup Hotfix

This hotfix preserves the v1 diary storage format while tightening privacy and host-safety behavior.

## Upgrade impact

Direct plaintext CLI secrets are blocked by default. Use `@-` or `@/private/file` for diary, backup, export, and AEGIS passwords.

Example:

```bash
printf '%s' 'my password' | sentinel-diary backup --password @-
```

For emergency compatibility only:

```bash
SENTINEL_DIARY_ALLOW_ARG_SECRETS=1 sentinel-diary backup --password 'my password'
```

Mutating operations refuse to run as root unless explicitly overridden:

```bash
SENTINEL_DIARY_ALLOW_ROOT_WRITE=1
```

## Fixed

- CLI secret leakage risk.
- Symlink-following private storage/export/import paths.
- Root-owned diary mutation risk.
- Restore/import payload validation gaps.
- Plaintext export atomic write safety.
- Launcher repair symlink safety.
- Packaged bytecode clutter.
