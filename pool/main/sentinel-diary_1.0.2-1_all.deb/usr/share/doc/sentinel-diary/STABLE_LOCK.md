# Sentinel Diary v1.0.2 Stable Lock

Program 105 — Sentinel Diary is locked as a stable Sentinel Desktop Suite baseline.

## Stable scope

- Local-first encrypted diary application.
- AES-256-GCM encrypted opaque object storage.
- Encrypted manifest for entry metadata.
- DD/MM/YYYY default display date format with configurable settings.
- Optional password lock using PBKDF2-HMAC-SHA256 key wrapping.
- Past Entries overview with filtering and date navigation.
- Entry management: save, delete, duplicate, jump date, stats, filters.
- Encrypted backup and restore.
- Encrypted import/export plus guarded plaintext Markdown export/import.
- AEGIS local-only read-only integration contract.
- Doctor, repair, integrity, launcher repair, and stable-lock status tools.
- No cloud sync, no telemetry, no remote accounts, and no external API calls.

## Phase path preserved

- v0.6.0 — Import / Export System.
- v0.7.0 — AEGIS Integration Lock.
- v0.8.0 — Doctor + Repair Tools.
- v0.8.1 — DD/MM/YYYY Date Format Settings Patch.
- v0.8.5 — UI Polish Pass.
- v0.9.0 — Release Candidate Validation.
- v1.0.0 — Stable Lock.

## Security note

Sentinel Diary provides app-level encryption by default. It encrypts entry contents,
manifest metadata, backups, and portable exports. It does not claim to convert the
underlying Linux directory into a filesystem-encrypted directory. For that layer,
use LUKS, fscrypt, gocryptfs, or encrypted home storage.
