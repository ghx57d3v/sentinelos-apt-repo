# Sentinel Diary v1.0.2 Package Contents

## Top level

- `README.md`
- `CHANGELOG.md`
- `PACKAGE_CONTENTS.md`
- `STABLE_LOCK.md`
- `install.sh`
- `uninstall.sh`
- `sentinel-diary_1.0.2-1_all.deb`

## Commands

- `sentinel-diary`
- `sentinel-diary-doctor`
- `sentinel-diary-aegis`
- `sentinel-diary-install-launchers`

## Major CLI commands

- `sentinel-diary status`
- `sentinel-diary settings`
- `sentinel-diary set-date-format DD/MM/YYYY`
- `sentinel-diary backup`
- `sentinel-diary restore`
- `sentinel-diary export-encrypted`
- `sentinel-diary import-encrypted`
- `sentinel-diary import-markdown`
- `sentinel-diary integrity`
- `sentinel-diary repair`
- `sentinel-diary doctor --json`
- `sentinel-diary stable-lock`

## Package install paths

- `/usr/bin/sentinel-diary`
- `/usr/bin/sentinel-diary-doctor`
- `/usr/bin/sentinel-diary-aegis`
- `/usr/bin/sentinel-diary-install-launchers`
- `/usr/share/sentinel-diary/sentinel_diary.py`
- `/usr/share/applications/sentinel-diary.desktop`
- `/usr/share/icons/hicolor/512x512/apps/sentinel-diary.png`
- `/usr/share/pixmaps/sentinel-diary.png`
- `/usr/share/doc/sentinel-diary/`


## v1.0.2 Patch Note

- Adds the GUI close hotkey: `Ctrl+Q`.
