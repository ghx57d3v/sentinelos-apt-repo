# Sentinel Diary v1.0.2

Program 105 — Sentinel Diary is the stable local-first encrypted diary for the Sentinel Desktop Suite.

## Core features

- Sentinel/AEGIS themed GUI.
- Supplied Sentinel Diary icon.
- Desktop and menu launcher creation.
- Past Entries sidebar with filters.
- One entry per date, with title, mood, tags, and diary body.
- Default display date format: `DD/MM/YYYY`.
- Configurable date display formats through Settings → Date Format Settings.
- AES-256-GCM encrypted opaque object storage.
- Encrypted manifest.
- Optional password lock using PBKDF2-HMAC-SHA256 key wrapping.
- Encrypted backup and restore.
- Encrypted import/export bundles.
- Guarded plaintext Markdown import/export.
- Local-only read-only AEGIS helper.
- Doctor, repair, integrity, and stable-lock commands.
- No network, no cloud sync, no telemetry, no remote accounts, and no external API calls.

## Install

```bash
unzip sentinel_diary_v1_0_0.zip
cd sentinel_diary_v1_0_0
./install.sh
```

Launch:

```bash
sentinel-diary
```

Run diagnostics:

```bash
sentinel-diary-doctor
sentinel-diary doctor --json
sentinel-diary stable-lock
```

## Storage locations

Diary data is stored under:

```text
~/.local/share/sentinel-diary/
```

Configuration and keyring data are stored under:

```text
~/.config/sentinel-diary/
```

Entries are stored as opaque encrypted objects. Readable dates, titles, moods, tags, and body text are encrypted in the entry payload and encrypted manifest. Internal canonical dates remain `YYYY-MM-DD` for migration compatibility, backups, imports/exports, and AEGIS commands, while the GUI displays `DD/MM/YYYY` by default.

## AEGIS helper

```bash
sentinel-diary-aegis status
sentinel-diary-aegis permissions
sentinel-diary-aegis validate-policy
sentinel-diary-aegis stats
sentinel-diary-aegis list
sentinel-diary-aegis read YYYY-MM-DD
sentinel-diary-aegis search "keyword"
sentinel-diary-aegis filter --tag family
```

AEGIS access is read-only and local-only. Password-locked diaries report password-required state rather than bypassing the lock.

## Security note

Sentinel Diary provides app-level encryption by default. It does not claim to turn the underlying Linux directory into a filesystem-encrypted directory. For true filesystem-directory encryption, use LUKS, fscrypt, gocryptfs, or encrypted home storage.


## v1.0.2 Hotkey Patch

- `Ctrl+Q` closes the Sentinel Diary application.
- File → Exit now displays the `Ctrl+Q` accelerator.
