# Sentinel Diary v1.0.2 — Redteam Security Cleanup Report

## Scope

Defensive audit of `sentinel_diary_v1_0_1(3).zip`, including source, package root, launcher helpers, encrypted storage, import/export, backup/restore, CLI/AEGIS interfaces, and packaging hygiene.

## Verdict

The uploaded v1.0.1 build was functional, but **not clean enough for a privacy-sensitive diary stable baseline**. The main problems were privacy leaks through command-line secrets, symlink-following behavior in private storage/export paths, and restore/import validation gaps that could cause partial writes or host/path surprises.

The patched baseline is **Sentinel Diary v1.0.2 — Redteam Security Cleanup Hotfix**.

## Findings fixed

### High — plaintext password leakage through argv

v1.0.1 accepted secrets directly through options such as `--password`, `--backup-password`, `--export-password`, and AEGIS `--password`. Those values can leak through shell history, process listings, crash logs, and terminal scrollback.

v1.0.2 refuses direct secret arguments by default. Supported safer sources:

```bash
printf '%s' 'secret' | sentinel-diary set-password --password @-
sentinel-diary backup --password @/private/diary.pass --backup-password @/private/backup.pass
```

Direct argv secrets require the explicit compatibility override:

```bash
SENTINEL_DIARY_ALLOW_ARG_SECRETS=1
```

### High — symlink-following storage and export paths

Several operations used `Path.is_file()`, `Path.is_dir()`, `chmod`, `write_text`, `copy2`, or recursive permission hardening in ways that could follow symlinked storage roots, backup folders, export folders, or imported files.

v1.0.2 adds symlink refusal for private storage roots, backup/export destinations, Markdown import sources, encrypted import sources, manifest/settings writes, and launcher destinations. Permission hardening now uses `lstat()` and skips symlinks instead of following them.

### High — root mutation risk

Running the diary as root could create or mutate root-owned diary/config/export files, especially when `HOME` or `SENTINEL_DIARY_HOME` pointed at a normal user's tree.

v1.0.2 blocks mutating commands as root unless the user explicitly sets:

```bash
SENTINEL_DIARY_ALLOW_ROOT_WRITE=1
```

### Medium — restore/import validation gaps

Encrypted backup/export restore decrypted payloads and wrote entries one by one without strict prevalidation of entry count, entry dates, entry field types, or entry text size.

v1.0.2 validates decrypted payload structure before writing and enforces import limits.

### Medium — import/export size and clobber safety

Markdown import and encrypted bundle reads had no practical size guard. Plaintext Markdown export wrote directly to destination paths.

v1.0.2 adds size limits and atomic private writes.

### Low — packaged bytecode

The `.deb` shipped `__pycache__` and `.pyc` bytecode. This is not usually exploitable by itself, but it is messy packaging and can leak build/runtime details.

v1.0.2 removes packaged bytecode.

## Design note

Sentinel Diary still supports the existing device-key mode for compatibility. In that mode, entries are encrypted at rest, but the device master key is stored locally in the private config directory. This protects entry contents from casual browsing of entry files, but not from compromise of the user's config directory. For stronger privacy, enable the password lock.
