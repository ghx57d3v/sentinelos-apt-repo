#!/usr/bin/env python3
"""
Sentinel Diary v1.0.1
Program 105 — local-first encrypted diary for the Sentinel Desktop Suite.

Design rules:
- Local-only by default.
- No cloud sync, telemetry, remote accounts, or online APIs.
- Diary entries are encrypted at rest using AES-256-GCM.
- AEGIS integration is read-only and local-only through explicit CLI commands.
"""

from __future__ import annotations

import argparse
import base64
import dataclasses
import getpass
import hashlib
import hmac
import json
import os
import shutil
import socket
import stat
import sys
import tempfile
import textwrap
import time
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
except Exception as exc:  # pragma: no cover - user-facing dependency guard
    print("Sentinel Diary requires python3-cryptography. Install package: python3-cryptography", file=sys.stderr)
    raise

APP_NAME = "Sentinel Diary"
APP_ID = "sentinel-diary"
VERSION = "1.0.1"
ENTRY_EXT = ".sde.json"  # Sentinel Diary Encrypted JSON envelope
KEY_FILE_NAME = "keyring.json"
POLICY_FILE_NAME = "policy.json"
AEGIS_POLICY_FILE_NAME = "aegis_access.json"
MANIFEST_FILE_NAME = "manifest.sdm.json"
BACKUP_EXT = ".sdbak.json"  # Sentinel Diary encrypted backup bundle
EXPORT_EXT = ".sdexp.json"  # Sentinel Diary encrypted import/export bundle
FIRST_RUN_FILE_NAME = "first_run.json"
SETTINGS_FILE_NAME = "settings.json"
NETWORK_POLICY = {
    "network_allowed": False,
    "cloud_sync": False,
    "telemetry": False,
    "remote_accounts": False,
    "external_api_calls": False,
    "policy": "local-only; deny outbound network features by design",
}
PBKDF2_ITERATIONS = 480_000

DATE_FORMAT_OPTIONS = {
    "DD/MM/YYYY": "%d/%m/%Y",
    "YYYY-MM-DD": "%Y-%m-%d",
    "MM/DD/YYYY": "%m/%d/%Y",
}
DEFAULT_DATE_FORMAT = "DD/MM/YYYY"


def normalize_date_format(value: Optional[str]) -> str:
    if value in DATE_FORMAT_OPTIONS:
        return str(value)
    return DEFAULT_DATE_FORMAT


def default_settings() -> Dict[str, Any]:
    return {
        "version": 1,
        "date_format": DEFAULT_DATE_FORMAT,
        "date_format_options": list(DATE_FORMAT_OPTIONS.keys()),
        "updated_at": utc_now_iso(),
    }


def load_app_settings(paths: "DiaryPaths") -> Dict[str, Any]:
    paths.ensure()
    data = default_settings()
    if paths.settings.exists():
        try:
            loaded = read_json(paths.settings)
            if isinstance(loaded, dict):
                data.update(loaded)
        except Exception:
            pass
    data["date_format"] = normalize_date_format(data.get("date_format"))
    return data


def save_app_settings(paths: "DiaryPaths", settings: Dict[str, Any]) -> None:
    payload = default_settings()
    payload.update(settings)
    payload["date_format"] = normalize_date_format(payload.get("date_format"))
    payload["updated_at"] = utc_now_iso()
    secure_write_json(paths.settings, payload, mode=0o600)


def format_iso_date(iso_date: str, date_format: str = DEFAULT_DATE_FORMAT) -> str:
    fmt_name = normalize_date_format(date_format)
    try:
        return date.fromisoformat(iso_date).strftime(DATE_FORMAT_OPTIONS[fmt_name])
    except Exception:
        return iso_date


def parse_user_date(value: str, date_format: str = DEFAULT_DATE_FORMAT) -> str:
    raw = (value or "").strip()
    if not raw:
        raise ValueError("Date is required")
    # Always accept canonical ISO internally for scripts, imports, and power users.
    try:
        return date.fromisoformat(raw).isoformat()
    except ValueError:
        pass
    fmt_name = normalize_date_format(date_format)
    formats = [DATE_FORMAT_OPTIONS[fmt_name]] + [fmt for name, fmt in DATE_FORMAT_OPTIONS.items() if name != fmt_name]
    seen = set()
    for fmt in formats:
        if fmt in seen:
            continue
        seen.add(fmt)
        try:
            return datetime.strptime(raw, fmt).date().isoformat()
        except ValueError:
            continue
    raise ValueError(f"Date must match {fmt_name} or YYYY-MM-DD")


def parse_optional_user_date(value: str, date_format: str = DEFAULT_DATE_FORMAT) -> str:
    raw = (value or "").strip()
    if not raw:
        return ""
    return parse_user_date(raw, date_format)

SENTINEL_THEME = {
    "bg": "#0B0D10",
    "panel": "#11161C",
    "panel_alt": "#151B22",
    "field": "#07090B",
    "text": "#F4EAD2",
    "muted": "#B8AA8A",
    "gold": "#E19B00",
    "gold_dark": "#8A5F00",
    "cyan": "#03C8FF",
    "border": "#3A2A08",
    "danger": "#D85C4A",
    "success": "#61C884",
    "black": "#050607",
}


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def b64e(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("ascii")


def b64d(data: str) -> bytes:
    return base64.urlsafe_b64decode(data.encode("ascii"))


def secure_write_json(path: Path, payload: Dict[str, Any], mode: int = 0o600) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp_fd, tmp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(tmp_fd, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, indent=2, sort_keys=True)
            fh.write("\n")
        os.chmod(tmp_name, mode)
        os.replace(tmp_name, path)
        os.chmod(path, mode)
    finally:
        if os.path.exists(tmp_name):
            try:
                os.unlink(tmp_name)
            except OSError:
                pass


def read_json(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as fh:
        return json.load(fh)


def ensure_private_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(path, 0o700)
    except OSError:
        pass


def is_private_file(path: Path) -> bool:
    try:
        mode = stat.S_IMODE(path.stat().st_mode)
        return (mode & 0o077) == 0
    except OSError:
        return False




def is_private_dir(path: Path) -> bool:
    try:
        mode = stat.S_IMODE(path.stat().st_mode)
        return path.is_dir() and (mode & 0o077) == 0
    except OSError:
        return False


def best_effort_fs_encryption_status(path: Path) -> Tuple[bool, str]:
    """Best-effort filesystem encryption detection.

    This does not certify encryption. It only detects common encrypted mounts
    such as gocryptfs/eCryptfs and a few obvious encrypted filesystem names.
    App-level object encryption remains the Sentinel Diary baseline either way.
    """
    try:
        target = path.resolve()
    except Exception:
        target = path.expanduser()
    mounts: List[Tuple[Path, str, str]] = []
    try:
        with open("/proc/mounts", "r", encoding="utf-8") as fh:
            for line in fh:
                parts = line.split()
                if len(parts) >= 4:
                    mount_point = Path(parts[1].replace("\\040", " "))
                    mounts.append((mount_point, parts[2].lower(), parts[3].lower()))
    except OSError:
        return False, "unknown; /proc/mounts unavailable"
    best: Optional[Tuple[Path, str, str]] = None
    for mount_point, fs_type, options in mounts:
        try:
            target.relative_to(mount_point)
            if best is None or len(str(mount_point)) > len(str(best[0])):
                best = (mount_point, fs_type, options)
        except ValueError:
            continue
    if best is None:
        return False, "not detected"
    mount_point, fs_type, options = best
    encrypted_types = {"fuse.gocryptfs", "gocryptfs", "ecryptfs", "encfs", "fuse.encfs", "fuse.cryfs", "cryfs"}
    if fs_type in encrypted_types or "encrypt" in fs_type or "encrypted" in options:
        return True, f"detected encrypted mount: {fs_type} at {mount_point}"
    return False, f"not detected on mount {mount_point} ({fs_type}); app-level encryption active"


def derive_password_key(password: str, salt: bytes, iterations: int = PBKDF2_ITERATIONS) -> bytes:
    kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=iterations)
    return kdf.derive(password.encode("utf-8"))


def patch_network_off() -> None:
    """Best-effort runtime guard: this app has no network features and blocks accidental sockets."""

    class NetworkDisabledError(OSError):
        pass

    def _blocked(*_args: Any, **_kwargs: Any) -> Any:
        raise NetworkDisabledError("Sentinel Diary network use is disabled by local-only policy")

    socket.socket = _blocked  # type: ignore[assignment]
    socket.create_connection = _blocked  # type: ignore[assignment]


@dataclasses.dataclass
class DiaryEntry:
    entry_date: str
    title: str = ""
    mood: str = ""
    tags: str = ""
    body: str = ""
    created_at: str = ""
    updated_at: str = ""

    def normalized_tags(self) -> List[str]:
        raw = self.tags.replace(";", ",")
        return [part.strip() for part in raw.split(",") if part.strip()]

    def to_plain_json(self) -> Dict[str, Any]:
        now = utc_now_iso()
        return {
            "version": 1,
            "entry_date": self.entry_date,
            "title": self.title,
            "mood": self.mood,
            "tags": self.normalized_tags(),
            "tags_text": self.tags,
            "body": self.body,
            "created_at": self.created_at or now,
            "updated_at": self.updated_at or now,
        }

    @classmethod
    def from_plain_json(cls, data: Dict[str, Any]) -> "DiaryEntry":
        tags_text = data.get("tags_text")
        if tags_text is None:
            tags = data.get("tags") or []
            tags_text = ", ".join(str(x) for x in tags)
        return cls(
            entry_date=str(data.get("entry_date", "")),
            title=str(data.get("title", "")),
            mood=str(data.get("mood", "")),
            tags=str(tags_text or ""),
            body=str(data.get("body", "")),
            created_at=str(data.get("created_at", "")),
            updated_at=str(data.get("updated_at", "")),
        )


class DiaryPaths:
    def __init__(self, base: Optional[Path] = None) -> None:
        if base is None:
            env_home = os.environ.get("SENTINEL_DIARY_HOME")
            if env_home:
                base = Path(env_home).expanduser()
                self.config = base / "config"
                self.data = base / "data"
            else:
                self.config = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")) / APP_ID
                self.data = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share")) / APP_ID
        else:
            self.config = base / "config"
            self.data = base / "data"
        self.entries = self.data / "entries"
        self.objects = self.entries / "objects"
        self.backups = self.data / "backups"
        self.exports = self.data / "exports"
        self.keyring = self.config / KEY_FILE_NAME
        self.policy = self.config / POLICY_FILE_NAME
        self.aegis_policy = self.config / AEGIS_POLICY_FILE_NAME
        self.manifest = self.entries / MANIFEST_FILE_NAME
        self.first_run = self.config / FIRST_RUN_FILE_NAME
        self.settings = self.config / SETTINGS_FILE_NAME

    def ensure(self) -> None:
        for folder in (self.config, self.data, self.entries, self.objects, self.backups, self.exports):
            ensure_private_dir(folder)
        if not self.policy.exists():
            secure_write_json(self.policy, {"version": 1, **NETWORK_POLICY})
        if not self.aegis_policy.exists():
            secure_write_json(
                self.aegis_policy,
                {
                    "version": 1,
                    "enabled": True,
                    "read_only": True,
                    "local_only": True,
                    "network_allowed": False,
                    "interface": "sentinel-diary-aegis",
                    "notes": "Approved local AEGIS access path; no network transport.",
                },
            )
        if not self.settings.exists():
            secure_write_json(self.settings, default_settings(), mode=0o600)
        self.harden_permissions()

    def harden_permissions(self) -> None:
        for folder in (self.config, self.data, self.entries, self.objects, self.backups, self.exports):
            if folder.exists():
                try:
                    os.chmod(folder, 0o700)
                except OSError:
                    pass
        for file_path in (self.keyring, self.policy, self.aegis_policy, self.manifest, self.settings):
            if file_path.exists():
                try:
                    os.chmod(file_path, 0o600)
                except OSError:
                    pass
        for root in (self.entries, self.backups):
            if root.exists():
                for child in root.rglob("*"):
                    try:
                        if child.is_dir():
                            os.chmod(child, 0o700)
                        elif child.is_file():
                            os.chmod(child, 0o600)
                    except OSError:
                        pass

class Keyring:
    def __init__(self, paths: DiaryPaths, password: Optional[str] = None) -> None:
        self.paths = paths
        self.password = password
        self._master_key: Optional[bytes] = None
        self.paths.ensure()
        if not self.paths.keyring.exists():
            self.create_default_keyring()

    def create_default_keyring(self) -> None:
        master = os.urandom(32)
        payload = {
            "version": 1,
            "mode": "device",
            "algorithm": "AES-256-GCM",
            "created_at": utc_now_iso(),
            "updated_at": utc_now_iso(),
            "password_enabled": False,
            "device_master_key": b64e(master),
            "key_note": "Local app-managed key. Protect this file; mode should be 0600.",
        }
        secure_write_json(self.paths.keyring, payload)
        self._master_key = master

    def status(self) -> Dict[str, Any]:
        data = read_json(self.paths.keyring)
        return {
            "mode": data.get("mode", "unknown"),
            "password_enabled": bool(data.get("password_enabled")),
            "keyring_private": is_private_file(self.paths.keyring),
            "keyring_path": str(self.paths.keyring),
        }

    def master_key(self) -> bytes:
        if self._master_key is not None:
            return self._master_key
        data = read_json(self.paths.keyring)
        mode = data.get("mode")
        if mode == "device":
            self._master_key = b64d(data["device_master_key"])
            return self._master_key
        if mode == "password":
            password = self.password
            if not password:
                password = os.environ.get("SENTINEL_DIARY_PASSWORD")
            if not password:
                password = getpass.getpass("Sentinel Diary password: ")
            try:
                salt = b64d(data["kdf_salt"])
                iterations = int(data.get("kdf_iterations", PBKDF2_ITERATIONS))
                wrapping_key = derive_password_key(password, salt, iterations)
                aes = AESGCM(wrapping_key)
                nonce = b64d(data["wrap_nonce"])
                wrapped = b64d(data["wrapped_master_key"])
                associated_data = b"sentinel-diary-master-key:v1"
                self._master_key = aes.decrypt(nonce, wrapped, associated_data)
                if len(self._master_key) != 32:
                    raise ValueError("Invalid master key length")
                return self._master_key
            except Exception as exc:
                raise PermissionError("Incorrect password or corrupted keyring") from exc
        raise RuntimeError(f"Unsupported keyring mode: {mode!r}")

    def enable_password(self, password: str) -> None:
        if not password or len(password) < 8:
            raise ValueError("Password must be at least 8 characters")
        master = self.master_key()
        salt = os.urandom(16)
        wrapping_key = derive_password_key(password, salt)
        nonce = os.urandom(12)
        aes = AESGCM(wrapping_key)
        associated_data = b"sentinel-diary-master-key:v1"
        wrapped = aes.encrypt(nonce, master, associated_data)
        payload = {
            "version": 1,
            "mode": "password",
            "algorithm": "AES-256-GCM",
            "created_at": read_json(self.paths.keyring).get("created_at", utc_now_iso()),
            "updated_at": utc_now_iso(),
            "password_enabled": True,
            "kdf": "PBKDF2-HMAC-SHA256",
            "kdf_iterations": PBKDF2_ITERATIONS,
            "kdf_salt": b64e(salt),
            "wrap_nonce": b64e(nonce),
            "wrapped_master_key": b64e(wrapped),
            "key_note": "Master key wrapped by user password. AEGIS access requires user-authorized unlock/password.",
        }
        secure_write_json(self.paths.keyring, payload)
        self.password = password
        self._master_key = master

    def disable_password(self, password: Optional[str] = None) -> None:
        if password is not None:
            self.password = password
        master = self.master_key()
        payload = {
            "version": 1,
            "mode": "device",
            "algorithm": "AES-256-GCM",
            "created_at": read_json(self.paths.keyring).get("created_at", utc_now_iso()),
            "updated_at": utc_now_iso(),
            "password_enabled": False,
            "device_master_key": b64e(master),
            "key_note": "Local app-managed key. Protect this file; mode should be 0600.",
        }
        secure_write_json(self.paths.keyring, payload)
        self._master_key = master


class DiaryStore:
    def __init__(self, paths: Optional[DiaryPaths] = None, password: Optional[str] = None) -> None:
        self.paths = paths or DiaryPaths()
        self.paths.ensure()
        self.keyring = Keyring(self.paths, password=password)
        self.paths.harden_permissions()

    def entry_object_id(self, entry_date: str) -> str:
        key = self.keyring.master_key()
        msg = f"sentinel-diary-entry-id:v2:{entry_date}".encode("utf-8")
        return hmac.new(key, msg, hashlib.sha256).hexdigest()

    def entry_path(self, entry_date: str) -> Path:
        object_id = self.entry_object_id(entry_date)
        return self.paths.objects / object_id[:2] / f"{object_id}{ENTRY_EXT}"

    def legacy_entry_path(self, entry_date: str) -> Path:
        year, month = entry_date.split("-")[:2]
        return self.paths.entries / year / month / f"{entry_date}{ENTRY_EXT}"

    def _associated_for_envelope(self, envelope: Dict[str, Any]) -> bytes:
        if envelope.get("object_id"):
            return f"sentinel-diary-entry-object:v2:{envelope['object_id']}".encode("utf-8")
        # Legacy v0.1/v0.2 envelope support. Older builds stored entry_date in plaintext metadata.
        return f"sentinel-diary-entry:{envelope['entry_date']}".encode("utf-8")

    def _encrypt_entry(self, entry: DiaryEntry) -> Dict[str, Any]:
        plain = entry.to_plain_json()
        raw = json.dumps(plain, ensure_ascii=False, sort_keys=True).encode("utf-8")
        nonce = os.urandom(12)
        aes = AESGCM(self.keyring.master_key())
        object_id = self.entry_object_id(entry.entry_date)
        associated = f"sentinel-diary-entry-object:v2:{object_id}".encode("utf-8")
        ciphertext = aes.encrypt(nonce, raw, associated)
        return {
            "version": 2,
            "app": APP_ID,
            "app_version": VERSION,
            "format": "sentinel-diary-encrypted-object",
            "algorithm": "AES-256-GCM",
            "object_id": object_id,
            "nonce": b64e(nonce),
            "ciphertext": b64e(ciphertext),
            "metadata_policy": "date/title/mood/tags/body encrypted inside payload; filename is keyed HMAC object id",
            "network_policy": "local-only",
        }

    def _decrypt_payload(self, envelope: Dict[str, Any]) -> DiaryEntry:
        aes = AESGCM(self.keyring.master_key())
        raw = aes.decrypt(b64d(envelope["nonce"]), b64d(envelope["ciphertext"]), self._associated_for_envelope(envelope))
        entry = DiaryEntry.from_plain_json(json.loads(raw.decode("utf-8")))
        object_id = envelope.get("object_id")
        if object_id and not hmac.compare_digest(str(object_id), self.entry_object_id(entry.entry_date)):
            raise ValueError("Diary object id does not match decrypted entry date")
        return entry

    def exists(self, entry_date: str) -> bool:
        return self.entry_path(entry_date).exists() or self.legacy_entry_path(entry_date).exists()

    def load(self, entry_date: str) -> Optional[DiaryEntry]:
        for path in (self.entry_path(entry_date), self.legacy_entry_path(entry_date)):
            if path.exists():
                return self._decrypt_payload(read_json(path))
        return None

    def save(self, entry: DiaryEntry) -> Path:
        if not entry.entry_date:
            raise ValueError("Entry date required")
        try:
            date.fromisoformat(entry.entry_date)
        except ValueError as exc:
            raise ValueError("Entry date must be YYYY-MM-DD") from exc
        existing = self.load(entry.entry_date)
        if existing and existing.created_at:
            entry.created_at = existing.created_at
        else:
            entry.created_at = entry.created_at or utc_now_iso()
        entry.updated_at = utc_now_iso()
        path = self.entry_path(entry.entry_date)
        path.parent.mkdir(parents=True, exist_ok=True)
        ensure_private_dir(path.parent)
        if path.exists():
            self.backup_file(path, reason="overwrite")
        legacy = self.legacy_entry_path(entry.entry_date)
        if legacy.exists() and legacy != path:
            self.backup_file(legacy, reason="legacy-migrate")
        secure_write_json(path, self._encrypt_entry(entry), mode=0o600)
        if legacy.exists() and legacy != path:
            try:
                legacy.unlink()
            except OSError:
                pass
        self.write_manifest()
        self.paths.harden_permissions()
        return path

    def delete(self, entry_date: str) -> bool:
        deleted = False
        for path in (self.entry_path(entry_date), self.legacy_entry_path(entry_date)):
            if path.exists():
                self.backup_file(path, reason="delete")
                path.unlink()
                deleted = True
        if deleted:
            self.write_manifest()
            self.paths.harden_permissions()
        return deleted

    def backup_file(self, path: Path, reason: str) -> Path:
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        object_name = path.stem.split(".")[0]
        # Legacy date filenames are converted to an opaque digest in backup names.
        if path.name.endswith(ENTRY_EXT) and "-" in object_name:
            object_name = hashlib.sha256(object_name.encode("utf-8")).hexdigest()
        dest = self.paths.backups / f"{object_name}.{reason}.{stamp}.bak"
        dest.parent.mkdir(parents=True, exist_ok=True)
        ensure_private_dir(dest.parent)
        shutil.copy2(path, dest)
        try:
            os.chmod(dest, 0o600)
        except OSError:
            pass
        return dest

    def iter_envelopes(self) -> Iterable[Path]:
        if not self.paths.entries.exists():
            return []
        return sorted(p for p in self.paths.entries.glob(f"**/*{ENTRY_EXT}") if p.is_file())

    def list_dates(self) -> List[str]:
        return [entry.entry_date for entry in self.list_entries()]

    def list_entries(self) -> List[DiaryEntry]:
        entries: List[DiaryEntry] = []
        seen: set[str] = set()
        for path in self.iter_envelopes():
            try:
                entry = self._decrypt_payload(read_json(path))
                if entry.entry_date not in seen:
                    entries.append(entry)
                    seen.add(entry.entry_date)
            except Exception:
                continue
        return sorted(entries, key=lambda e: e.entry_date)

    def search(self, query: str) -> List[DiaryEntry]:
        terms = [t.lower() for t in query.split() if t.strip()]
        if not terms:
            return []
        matches = []
        for entry in self.list_entries():
            haystack = "\n".join([entry.entry_date, entry.title, entry.mood, entry.tags, entry.body]).lower()
            if all(term in haystack for term in terms):
                matches.append(entry)
        return matches

    def manifest_payload(self) -> Dict[str, Any]:
        return {
            "version": 1,
            "app": APP_ID,
            "app_version": VERSION,
            "updated_at": utc_now_iso(),
            "storage_layout": "opaque-object-store-v2",
            "entries": [
                {
                    "entry_date": entry.entry_date,
                    "object_id": self.entry_object_id(entry.entry_date),
                    "title": entry.title,
                    "mood": entry.mood,
                    "tags": entry.normalized_tags(),
                    "created_at": entry.created_at,
                    "updated_at": entry.updated_at,
                }
                for entry in self.list_entries()
            ],
        }

    def write_manifest(self) -> Path:
        payload = self.manifest_payload()
        raw = json.dumps(payload, ensure_ascii=False, sort_keys=True).encode("utf-8")
        aes = AESGCM(self.keyring.master_key())
        nonce = os.urandom(12)
        associated = b"sentinel-diary-manifest:v1"
        envelope = {
            "version": 1,
            "app": APP_ID,
            "format": "sentinel-diary-encrypted-manifest",
            "algorithm": "AES-256-GCM",
            "nonce": b64e(nonce),
            "ciphertext": b64e(aes.encrypt(nonce, raw, associated)),
            "metadata_policy": "dates/titles/moods/tags are encrypted inside this manifest",
        }
        secure_write_json(self.paths.manifest, envelope, mode=0o600)
        return self.paths.manifest

    def read_manifest(self) -> Dict[str, Any]:
        if not self.paths.manifest.exists():
            self.write_manifest()
        envelope = read_json(self.paths.manifest)
        aes = AESGCM(self.keyring.master_key())
        raw = aes.decrypt(b64d(envelope["nonce"]), b64d(envelope["ciphertext"]), b"sentinel-diary-manifest:v1")
        return json.loads(raw.decode("utf-8"))

    def migrate_legacy_entries(self) -> int:
        migrated = 0
        for path in list(self.iter_envelopes()):
            try:
                envelope = read_json(path)
                if envelope.get("version") == 1 and envelope.get("entry_date"):
                    entry = self._decrypt_payload(envelope)
                    self.save(entry)
                    if path.exists() and path != self.entry_path(entry.entry_date):
                        self.backup_file(path, reason="legacy-migrate")
                        path.unlink()
                    migrated += 1
            except Exception:
                continue
        if migrated:
            self.write_manifest()
        self.paths.harden_permissions()
        return migrated

    def export_entry_markdown(self, entry: DiaryEntry, folder: Optional[Path] = None) -> Path:
        folder = folder or self.paths.exports
        folder.mkdir(parents=True, exist_ok=True)
        ensure_private_dir(folder)
        safe_date = entry.entry_date
        dest = folder / f"Sentinel_Diary_{safe_date}.md"
        tags = ", ".join(entry.normalized_tags())
        text = f"# {entry.title or 'Sentinel Diary'}\n\n"
        text += f"- Date: {entry.entry_date}\n"
        if entry.mood:
            text += f"- Mood: {entry.mood}\n"
        if tags:
            text += f"- Tags: {tags}\n"
        text += f"- Created: {entry.created_at}\n- Updated: {entry.updated_at}\n\n---\n\n{entry.body}\n"
        dest.write_text(text, encoding="utf-8")
        try:
            os.chmod(dest, 0o600)
        except OSError:
            pass
        return dest

    def export_all_markdown(self, folder: Optional[Path] = None) -> List[Path]:
        folder = folder or self.paths.exports / datetime.now().strftime("Diary_Export_%Y%m%d-%H%M%S")
        folder.mkdir(parents=True, exist_ok=True)
        ensure_private_dir(folder)
        return [self.export_entry_markdown(entry, folder) for entry in self.list_entries()]


    def filter_entries(
        self,
        query: str = "",
        start_date: str = "",
        end_date: str = "",
        tag: str = "",
        mood: str = "",
    ) -> List[DiaryEntry]:
        """Return entries filtered locally after decryption in memory."""
        terms = [t.lower() for t in query.split() if t.strip()]
        wanted_tag = tag.strip().lower()
        wanted_mood = mood.strip().lower()
        results: List[DiaryEntry] = []
        for entry in self.list_entries():
            if start_date and entry.entry_date < start_date:
                continue
            if end_date and entry.entry_date > end_date:
                continue
            if wanted_mood and wanted_mood not in entry.mood.lower():
                continue
            if wanted_tag:
                tags = [x.lower() for x in entry.normalized_tags()]
                tag_text = entry.tags.lower()
                if wanted_tag not in tags and wanted_tag not in tag_text:
                    continue
            haystack = "\n".join([entry.entry_date, entry.title, entry.mood, entry.tags, entry.body]).lower()
            if terms and not all(term in haystack for term in terms):
                continue
            results.append(entry)
        return sorted(results, key=lambda e: e.entry_date)

    def entry_stats(self) -> Dict[str, Any]:
        entries = self.list_entries()
        tag_counts: Dict[str, int] = {}
        mood_counts: Dict[str, int] = {}
        for entry in entries:
            if entry.mood:
                mood_counts[entry.mood] = mood_counts.get(entry.mood, 0) + 1
            for tag in entry.normalized_tags():
                tag_counts[tag] = tag_counts.get(tag, 0) + 1
        return {
            "count": len(entries),
            "first_date": entries[0].entry_date if entries else "",
            "last_date": entries[-1].entry_date if entries else "",
            "tags": tag_counts,
            "moods": mood_counts,
        }

    def duplicate_entry(self, source_date: str, target_date: str) -> Path:
        source = self.load(source_date)
        if source is None:
            raise FileNotFoundError(f"No source entry for {source_date}")
        try:
            date.fromisoformat(target_date)
        except ValueError as exc:
            raise ValueError("Target date must be YYYY-MM-DD") from exc
        if self.exists(target_date):
            raise FileExistsError(f"Entry already exists for {target_date}")
        copy = DiaryEntry(
            entry_date=target_date,
            title=(source.title + " (copy)").strip(),
            mood=source.mood,
            tags=source.tags,
            body=source.body,
        )
        return self.save(copy)

    def export_encrypted_backup(self, folder: Optional[Path] = None, backup_password: Optional[str] = None) -> Path:
        """Create an encrypted backup bundle containing all diary entries.

        Without a backup password, the bundle is encrypted with the current diary master key.
        With a backup password, it is encrypted with a separate PBKDF2-derived backup key.
        """
        folder = folder or self.paths.backups
        folder.mkdir(parents=True, exist_ok=True)
        ensure_private_dir(folder)
        payload = {
            "version": 1,
            "app": APP_ID,
            "app_version": VERSION,
            "created_at": utc_now_iso(),
            "entry_count": len(self.list_entries()),
            "entries": [entry.to_plain_json() for entry in self.list_entries()],
            "network_policy": NETWORK_POLICY,
        }
        raw = json.dumps(payload, ensure_ascii=False, sort_keys=True).encode("utf-8")
        associated = b"sentinel-diary-backup:v1"
        salt = os.urandom(16)
        if backup_password:
            key = derive_password_key(backup_password, salt)
            key_mode = "backup-password"
        else:
            key = self.keyring.master_key()
            key_mode = "diary-master-key"
        nonce = os.urandom(12)
        aes = AESGCM(key)
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        dest = folder / f"sentinel_diary_backup_{stamp}{BACKUP_EXT}"
        envelope = {
            "version": 1,
            "app": APP_ID,
            "app_version": VERSION,
            "format": "sentinel-diary-encrypted-backup",
            "algorithm": "AES-256-GCM",
            "kdf": "PBKDF2-HMAC-SHA256" if backup_password else "none",
            "kdf_iterations": PBKDF2_ITERATIONS if backup_password else 0,
            "kdf_salt": b64e(salt) if backup_password else "",
            "key_mode": key_mode,
            "nonce": b64e(nonce),
            "ciphertext": b64e(aes.encrypt(nonce, raw, associated)),
            "entry_count": payload["entry_count"],
            "created_at": payload["created_at"],
            "metadata_policy": "entry contents and backup manifest are encrypted inside ciphertext",
        }
        secure_write_json(dest, envelope, mode=0o600)
        self.paths.harden_permissions()
        return dest

    def restore_encrypted_backup(self, backup_path: Path, backup_password: Optional[str] = None, overwrite: bool = False) -> int:
        envelope = read_json(backup_path.expanduser())
        if envelope.get("format") != "sentinel-diary-encrypted-backup":
            raise ValueError("Not a Sentinel Diary encrypted backup")
        associated = b"sentinel-diary-backup:v1"
        if envelope.get("key_mode") == "backup-password":
            if not backup_password:
                raise PermissionError("Backup password required")
            key = derive_password_key(backup_password, b64d(envelope["kdf_salt"]), int(envelope.get("kdf_iterations") or PBKDF2_ITERATIONS))
        else:
            key = self.keyring.master_key()
        aes = AESGCM(key)
        raw = aes.decrypt(b64d(envelope["nonce"]), b64d(envelope["ciphertext"]), associated)
        payload = json.loads(raw.decode("utf-8"))
        restored = 0
        for item in payload.get("entries", []):
            entry = DiaryEntry.from_plain_json(item)
            if not overwrite and self.exists(entry.entry_date):
                continue
            self.save(entry)
            restored += 1
        self.write_manifest()
        self.paths.harden_permissions()
        return restored

    def selected_entries(
        self,
        dates: Optional[List[str]] = None,
        query: str = "",
        start_date: str = "",
        end_date: str = "",
        tag: str = "",
        mood: str = "",
    ) -> List[DiaryEntry]:
        """Return an ordered entry selection for import/export workflows."""
        if dates:
            found: List[DiaryEntry] = []
            for item in dates:
                entry = self.load(item)
                if entry:
                    found.append(entry)
            return sorted(found, key=lambda e: e.entry_date)
        if query or start_date or end_date or tag or mood:
            return self.filter_entries(query=query, start_date=start_date, end_date=end_date, tag=tag, mood=mood)
        return self.list_entries()

    def export_encrypted_entries(
        self,
        folder: Optional[Path] = None,
        backup_password: Optional[str] = None,
        dates: Optional[List[str]] = None,
        query: str = "",
        start_date: str = "",
        end_date: str = "",
        tag: str = "",
        mood: str = "",
    ) -> Path:
        """Create an encrypted portable export bundle for selected entries."""
        folder = folder or self.paths.exports
        folder.mkdir(parents=True, exist_ok=True)
        ensure_private_dir(folder)
        entries = self.selected_entries(dates=dates, query=query, start_date=start_date, end_date=end_date, tag=tag, mood=mood)
        payload = {
            "version": 1,
            "app": APP_ID,
            "app_version": VERSION,
            "format": "sentinel-diary-plain-export-payload",
            "created_at": utc_now_iso(),
            "entry_count": len(entries),
            "selection": {
                "dates": dates or [],
                "query": query,
                "start_date": start_date,
                "end_date": end_date,
                "tag": tag,
                "mood": mood,
            },
            "entries": [entry.to_plain_json() for entry in entries],
            "network_policy": NETWORK_POLICY,
        }
        raw = json.dumps(payload, ensure_ascii=False, sort_keys=True).encode("utf-8")
        associated = b"sentinel-diary-encrypted-export:v1"
        salt = os.urandom(16)
        if backup_password:
            key = derive_password_key(backup_password, salt)
            key_mode = "export-password"
        else:
            key = self.keyring.master_key()
            key_mode = "diary-master-key"
        nonce = os.urandom(12)
        aes = AESGCM(key)
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        dest = folder / f"sentinel_diary_export_{stamp}{EXPORT_EXT}"
        envelope = {
            "version": 1,
            "app": APP_ID,
            "app_version": VERSION,
            "format": "sentinel-diary-encrypted-export",
            "algorithm": "AES-256-GCM",
            "kdf": "PBKDF2-HMAC-SHA256" if backup_password else "none",
            "kdf_iterations": PBKDF2_ITERATIONS if backup_password else 0,
            "kdf_salt": b64e(salt) if backup_password else "",
            "key_mode": key_mode,
            "nonce": b64e(nonce),
            "ciphertext": b64e(aes.encrypt(nonce, raw, associated)),
            "entry_count": payload["entry_count"],
            "created_at": payload["created_at"],
            "metadata_policy": "portable export metadata and diary content are encrypted inside ciphertext",
            "network_policy": "local-only",
        }
        secure_write_json(dest, envelope, mode=0o600)
        self.paths.harden_permissions()
        return dest

    def import_encrypted_entries(self, export_path: Path, backup_password: Optional[str] = None, overwrite: bool = False) -> int:
        """Import an encrypted export or backup bundle."""
        envelope = read_json(export_path.expanduser())
        fmt = envelope.get("format")
        if fmt == "sentinel-diary-encrypted-export":
            associated = b"sentinel-diary-encrypted-export:v1"
            password_modes = {"export-password", "backup-password"}
        elif fmt == "sentinel-diary-encrypted-backup":
            associated = b"sentinel-diary-backup:v1"
            password_modes = {"backup-password", "export-password"}
        else:
            raise ValueError("Not a Sentinel Diary encrypted export/backup")
        if envelope.get("key_mode") in password_modes:
            if not backup_password:
                raise PermissionError("Export/backup password required")
            key = derive_password_key(backup_password, b64d(envelope.get("kdf_salt", "")), int(envelope.get("kdf_iterations") or PBKDF2_ITERATIONS))
        else:
            key = self.keyring.master_key()
        raw = AESGCM(key).decrypt(b64d(envelope["nonce"]), b64d(envelope["ciphertext"]), associated)
        payload = json.loads(raw.decode("utf-8"))
        restored = 0
        for item in payload.get("entries", []):
            entry = DiaryEntry.from_plain_json(item)
            if not overwrite and self.exists(entry.entry_date):
                continue
            self.save(entry)
            restored += 1
        self.write_manifest()
        self.paths.harden_permissions()
        return restored

    def import_markdown_file(self, markdown_path: Path, entry_date: Optional[str] = None, overwrite: bool = False) -> Path:
        """Import a single Markdown/text file as a diary entry.

        This is intentionally conservative: imported files become normal encrypted
        diary entries immediately after save.
        """
        src = markdown_path.expanduser()
        text = src.read_text(encoding="utf-8")
        title = src.stem
        body_lines: List[str] = []
        parsed_date = entry_date or ""
        for line in text.splitlines():
            stripped = line.strip()
            if stripped.startswith("# ") and title == src.stem:
                title = stripped[2:].strip() or title
                continue
            low = stripped.lower()
            if not parsed_date and low.startswith("- date:"):
                parsed_date = stripped.split(":", 1)[1].strip()
                continue
            body_lines.append(line)
        if not parsed_date:
            # Try YYYY-MM-DD from filename, otherwise use today.
            for part in src.stem.replace("_", "-").split("-"):
                pass
            import re
            match = re.search(r"(\d{4}-\d{2}-\d{2})", src.stem)
            parsed_date = match.group(1) if match else date.today().isoformat()
        try:
            date.fromisoformat(parsed_date)
        except ValueError as exc:
            raise ValueError("Imported entry date must be YYYY-MM-DD") from exc
        if self.exists(parsed_date) and not overwrite:
            raise FileExistsError(f"Entry already exists for {parsed_date}; use overwrite to replace it")
        entry = DiaryEntry(entry_date=parsed_date, title=title, body="\n".join(body_lines).strip())
        return self.save(entry)

    def integrity_report(self) -> Dict[str, Any]:
        """Return machine-readable storage integrity status without network use."""
        report: Dict[str, Any] = {
            "ok": True,
            "app": APP_ID,
            "version": VERSION,
            "checked_at": utc_now_iso(),
            "paths": {
                "data": str(self.paths.data),
                "config": str(self.paths.config),
                "entries": str(self.paths.entries),
                "objects": str(self.paths.objects),
                "manifest": str(self.paths.manifest),
            },
            "checks": [],
            "entry_count": 0,
            "errors": [],
        }
        def add(name: str, ok: bool, note: str = "") -> None:
            report["checks"].append({"name": name, "ok": bool(ok), "note": note})
            if not ok:
                report["ok"] = False
        add("data_directory_exists", self.paths.data.exists(), str(self.paths.data))
        add("config_directory_exists", self.paths.config.exists(), str(self.paths.config))
        add("objects_directory_exists", self.paths.objects.exists(), str(self.paths.objects))
        add("data_directory_private", is_private_dir(self.paths.data), "expected mode 0700")
        add("config_directory_private", is_private_dir(self.paths.config), "expected mode 0700")
        add("keyring_private", is_private_file(self.paths.keyring), "expected mode 0600")
        try:
            entries = self.list_entries()
            report["entry_count"] = len(entries)
            add("entries_decryptable", True, f"{len(entries)} entries")
        except Exception as exc:
            report["errors"].append(str(exc))
            add("entries_decryptable", False, str(exc))
        try:
            manifest = self.read_manifest()
            add("manifest_decryptable", True, f"{len(manifest.get('entries', []))} manifest entries")
        except Exception as exc:
            report["errors"].append(str(exc))
            add("manifest_decryptable", False, str(exc))
        fs_encrypted, fs_note = best_effort_fs_encryption_status(self.paths.entries)
        report["filesystem_encryption_detected"] = fs_encrypted
        report["filesystem_encryption_note"] = fs_note
        report["network_policy"] = NETWORK_POLICY
        return report

    def repair_storage(self, reset_policy: bool = False, reset_aegis_policy: bool = False, rebuild_manifest: bool = True) -> Dict[str, Any]:
        """Repair local permissions, policy files, and encrypted manifest."""
        actions: List[str] = []
        self.paths.ensure()
        self.paths.harden_permissions()
        actions.append("hardened directory/file permissions")
        if reset_policy or not self.paths.policy.exists():
            secure_write_json(self.paths.policy, {"version": 1, **NETWORK_POLICY}, mode=0o600)
            actions.append("reset local-only network policy")
        if reset_aegis_policy or not self.paths.aegis_policy.exists():
            secure_write_json(
                self.paths.aegis_policy,
                {
                    "version": 1,
                    "enabled": True,
                    "read_only": True,
                    "local_only": True,
                    "network_allowed": False,
                    "interface": "sentinel-diary-aegis",
                    "json_output": True,
                    "schema_version": "aegis-diary-v1",
                    "notes": "Approved local read-only AEGIS access path; no network transport.",
                },
                mode=0o600,
            )
            actions.append("reset AEGIS local read-only policy")
        if rebuild_manifest:
            self.write_manifest()
            actions.append("rebuilt encrypted manifest")
        self.paths.harden_permissions()
        return {"ok": True, "actions": actions, "integrity": self.integrity_report()}


class DiaryGUI:
    def __init__(self) -> None:
        patch_network_off()
        import tkinter as tk
        from tkinter import messagebox, simpledialog, ttk, filedialog

        self.tk = tk
        self.ttk = ttk
        self.messagebox = messagebox
        self.simpledialog = simpledialog
        self.filedialog = filedialog
        self.paths = DiaryPaths()
        self.paths.ensure()
        self.settings = load_app_settings(self.paths)
        self.date_format = normalize_date_format(self.settings.get("date_format"))
        self.password: Optional[str] = None
        self.root = tk.Tk()
        self.date_format_var = tk.StringVar(value=self.date_format)
        self.root.title(f"{APP_NAME} v{VERSION}")
        self.root.geometry("1180x780")
        self.root.minsize(980, 640)
        self._load_icon()
        self._apply_theme()
        self.store = self._open_store_with_unlock()
        self.current_date = date.today().isoformat()
        self.privacy_hidden = False
        self.last_body_cache = ""
        self._overview_busy = False
        self.overview_dates: List[str] = []
        self._build_ui()
        self.load_date(self.current_date)

    def _load_icon(self) -> None:
        candidates = [
            Path("/usr/share/icons/hicolor/512x512/apps/sentinel-diary.png"),
            Path("/usr/share/pixmaps/sentinel-diary.png"),
            Path(__file__).resolve().parent / "assets" / "sentinel-diary.png",
        ]
        for path in candidates:
            if path.exists():
                try:
                    img = self.tk.PhotoImage(file=str(path))
                    self.root.iconphoto(True, img)
                    self._icon_ref = img
                    break
                except Exception:
                    pass

    def _open_store_with_unlock(self) -> DiaryStore:
        paths = self.paths
        paths.ensure()
        if paths.keyring.exists():
            try:
                status = Keyring(paths).status()
                if status.get("password_enabled"):
                    for _attempt in range(3):
                        password = self.simpledialog.askstring(APP_NAME, "Diary password:", show="*", parent=self.root)
                        if password is None:
                            self.root.destroy()
                            raise SystemExit(0)
                        try:
                            store = DiaryStore(paths, password=password)
                            store.keyring.master_key()
                            self.password = password
                            return store
                        except PermissionError:
                            self.messagebox.showerror(APP_NAME, "Incorrect password.")
                    self.root.destroy()
                    raise SystemExit(1)
            except SystemExit:
                raise
            except Exception:
                pass
        return DiaryStore(paths)

    def _apply_theme(self) -> None:
        """Apply the Sentinel/AEGIS dark visual system to Tk and ttk widgets."""
        tk = self.tk
        ttk = self.ttk
        t = SENTINEL_THEME
        self.root.configure(bg=t["bg"])
        self.root.option_add("*Font", "TkDefaultFont 10")
        self.root.option_add("*Menu.background", t["panel"])
        self.root.option_add("*Menu.foreground", t["text"])
        self.root.option_add("*Menu.activeBackground", t["gold"])
        self.root.option_add("*Menu.activeForeground", t["black"])
        self.root.option_add("*Menu.relief", "flat")
        self.root.option_add("*Menu.borderWidth", 0)
        style = ttk.Style(self.root)
        self.style = style
        try:
            style.theme_use("clam")
        except Exception:
            pass
        style.configure(".", background=t["bg"], foreground=t["text"], fieldbackground=t["field"], bordercolor=t["border"], lightcolor=t["border"], darkcolor=t["border"])
        style.configure("Sentinel.TFrame", background=t["bg"])
        style.configure("Panel.TFrame", background=t["panel"])
        style.configure("Sentinel.TLabel", background=t["bg"], foreground=t["text"])
        style.configure("Muted.TLabel", background=t["bg"], foreground=t["muted"])
        style.configure("Gold.TLabel", background=t["bg"], foreground=t["gold"], font=("TkDefaultFont", 10, "bold"))
        style.configure("Title.TLabel", background=t["panel"], foreground=t["gold"], font=("TkDefaultFont", 20, "bold"))
        style.configure("Subtitle.TLabel", background=t["panel"], foreground=t["muted"], font=("TkDefaultFont", 9))
        style.configure("Sentinel.TButton", background=t["panel_alt"], foreground=t["text"], bordercolor=t["border"], focusthickness=1, focuscolor=t["gold"], padding=(10, 5))
        style.map("Sentinel.TButton", background=[("active", t["gold"]), ("pressed", t["gold_dark"])], foreground=[("active", t["black"]), ("pressed", t["black"])])
        style.configure("Primary.TButton", background=t["gold"], foreground=t["black"], bordercolor=t["gold"], padding=(12, 6), font=("TkDefaultFont", 10, "bold"))
        style.map("Primary.TButton", background=[("active", "#F0B01B"), ("pressed", t["gold_dark"])], foreground=[("active", t["black"]), ("pressed", t["black"])])
        style.configure("Sentinel.TEntry", fieldbackground=t["field"], foreground=t["text"], insertcolor=t["gold"], bordercolor=t["border"], lightcolor=t["border"], darkcolor=t["border"], padding=(6, 4))
        style.configure("Sentinel.TLabelframe", background=t["bg"], foreground=t["gold"], bordercolor=t["border"], lightcolor=t["border"], darkcolor=t["border"])
        style.configure("Sentinel.TLabelframe.Label", background=t["bg"], foreground=t["gold"], font=("TkDefaultFont", 10, "bold"))
        style.configure("Status.TLabel", background=t["panel"], foreground=t["muted"], anchor="w", padding=(8, 5))
        style.configure("Vertical.TScrollbar", background=t["panel_alt"], troughcolor=t["black"], bordercolor=t["border"], arrowcolor=t["gold"])

    def _style_menu(self, menu: Any) -> None:
        t = SENTINEL_THEME
        try:
            menu.configure(
                bg=t["panel"],
                fg=t["text"],
                activebackground=t["gold"],
                activeforeground=t["black"],
                disabledforeground=t["muted"],
                relief="flat",
                borderwidth=0,
            )
        except Exception:
            pass

    def _tk_entry(self, parent: Any, **kwargs: Any) -> Any:
        t = SENTINEL_THEME
        return self.tk.Entry(
            parent,
            bg=t["field"],
            fg=t["text"],
            insertbackground=t["gold"],
            relief="flat",
            highlightthickness=1,
            highlightbackground=t["border"],
            highlightcolor=t["gold"],
            disabledbackground=t["panel_alt"],
            disabledforeground=t["muted"],
            **kwargs,
        )

    def _tk_label(self, parent: Any, text: str, *, muted: bool = False, gold: bool = False, **kwargs: Any) -> Any:
        t = SENTINEL_THEME
        fg = t["gold"] if gold else (t["muted"] if muted else t["text"])
        return self.tk.Label(parent, text=text, bg=t["bg"], fg=fg, **kwargs)

    def _badge(self, parent: Any, text: str, *, cyan: bool = False) -> Any:
        t = SENTINEL_THEME
        return self.tk.Label(
            parent,
            text=text,
            bg=t["cyan"] if cyan else t["gold"],
            fg=t["black"],
            padx=8,
            pady=3,
            font=("TkDefaultFont", 8, "bold"),
        )

    def _build_ui(self) -> None:
        tk = self.tk
        ttk = self.ttk
        t = SENTINEL_THEME

        menubar = tk.Menu(self.root)
        self._style_menu(menubar)
        file_menu = tk.Menu(menubar, tearoff=False)
        self._style_menu(file_menu)
        file_menu.add_command(label="Save Entry", accelerator="Ctrl+S", command=self.save_current)
        file_menu.add_command(label="Duplicate Entry", command=self.duplicate_current)
        file_menu.add_command(label="Delete Entry", command=self.delete_current)
        file_menu.add_separator()
        file_menu.add_command(label="Encrypted Backup", command=self.backup_encrypted)
        file_menu.add_command(label="Restore Encrypted Backup", command=self.restore_encrypted)
        file_menu.add_command(label="Encrypted Export Selected/Filtered", command=self.export_encrypted_selected)
        file_menu.add_command(label="Import Encrypted Export", command=self.import_encrypted_export_gui)
        file_menu.add_command(label="Import Markdown/Text", command=self.import_markdown_gui)
        file_menu.add_separator()
        file_menu.add_command(label="Export Current Entry", command=self.export_current)
        file_menu.add_command(label="Export All Entries", command=self.export_all)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", accelerator="Ctrl+Q", command=self.close_app)
        menubar.add_cascade(label="File", menu=file_menu)

        privacy_menu = tk.Menu(menubar, tearoff=False)
        self._style_menu(privacy_menu)
        privacy_menu.add_command(label="First-Run Privacy Setup", command=self.first_run_privacy_setup)
        privacy_menu.add_command(label="Toggle Privacy View", accelerator="Ctrl+H", command=self.toggle_privacy)
        privacy_menu.add_command(label="Lock Diary", command=self.lock_diary)
        privacy_menu.add_separator()
        privacy_menu.add_command(label="Set / Change Password", command=self.set_password)
        privacy_menu.add_command(label="Disable Password Lock", command=self.disable_password)
        privacy_menu.add_separator()
        privacy_menu.add_command(label="Show Security Status", command=self.show_security_status)
        privacy_menu.add_command(label="Run Storage Repair", command=self.run_storage_repair)
        menubar.add_cascade(label="Privacy", menu=privacy_menu)

        view_menu = tk.Menu(menubar, tearoff=False)
        self._style_menu(view_menu)
        view_menu.add_command(label="Jump to Date", accelerator="Ctrl+J", command=self.jump_to_date)
        view_menu.add_command(label="Refresh Past Entries", accelerator="F5", command=self.refresh_overview)
        view_menu.add_command(label="Load Selected Past Entry", command=self.load_selected_overview)
        menubar.add_cascade(label="View", menu=view_menu)

        settings_menu = tk.Menu(menubar, tearoff=False)
        self._style_menu(settings_menu)
        settings_menu.add_command(label="Date Format Settings", command=self.choose_date_format)
        settings_menu.add_separator()
        for fmt_name in DATE_FORMAT_OPTIONS:
            settings_menu.add_radiobutton(
                label=fmt_name,
                variable=self.date_format_var,
                value=fmt_name,
                command=lambda fmt_name=fmt_name: self.set_date_format(fmt_name),
            )
        menubar.add_cascade(label="Settings", menu=settings_menu)

        aegis_menu = tk.Menu(menubar, tearoff=False)
        self._style_menu(aegis_menu)
        aegis_menu.add_command(label="Show AEGIS Local Access Info", command=self.show_aegis_info)
        aegis_menu.add_command(label="Show Network Policy", command=self.show_network_policy)
        menubar.add_cascade(label="AEGIS", menu=aegis_menu)

        help_menu = tk.Menu(menubar, tearoff=False)
        self._style_menu(help_menu)
        help_menu.add_command(label="Keyboard Shortcuts", command=self.show_shortcuts)
        help_menu.add_command(label="Stable Lock Status", command=self.show_stable_lock)
        help_menu.add_command(label="About Sentinel Diary", command=self.show_about)
        menubar.add_cascade(label="Help", menu=help_menu)
        self.root.config(menu=menubar)

        outer = tk.Frame(self.root, bg=t["bg"], padx=14, pady=14)
        outer.pack(fill="both", expand=True)

        header = tk.Frame(
            outer,
            bg=t["panel"],
            padx=12,
            pady=10,
            highlightbackground=t["border"],
            highlightcolor=t["gold"],
            highlightthickness=1,
        )
        header.pack(fill="x")
        if hasattr(self, "_icon_ref"):
            try:
                self._header_icon = self._icon_ref.subsample(8, 8)
                tk.Label(header, image=self._header_icon, bg=t["panel"]).pack(side="left", padx=(0, 10))
            except Exception:
                pass
        title_block = tk.Frame(header, bg=t["panel"])
        title_block.pack(side="left", fill="x", expand=True)
        tk.Label(title_block, text="Sentinel Diary", bg=t["panel"], fg=t["gold"], font=("TkDefaultFont", 20, "bold")).pack(anchor="w")
        tk.Label(title_block, text="Program 105 · encrypted local diary · AEGIS local-only · network disabled", bg=t["panel"], fg=t["muted"], font=("TkDefaultFont", 9)).pack(anchor="w")
        badge_box = tk.Frame(header, bg=t["panel"])
        badge_box.pack(side="right")
        self._badge(badge_box, "AES-256-GCM").pack(side="top", anchor="e", pady=(0, 4))
        self._badge(badge_box, "AEGIS READ-ONLY", cyan=True).pack(side="top", anchor="e", pady=(0, 4))
        self._badge(badge_box, "LOCAL ONLY").pack(side="top", anchor="e", pady=(0, 4))
        self._badge(badge_box, "v1 STABLE", cyan=True).pack(side="top", anchor="e")

        nav = tk.Frame(outer, bg=t["bg"])
        nav.pack(fill="x", pady=(12, 8))
        ttk.Button(nav, text="◀ Previous Day", style="Sentinel.TButton", command=lambda: self.shift_day(-1)).pack(side="left")
        ttk.Button(nav, text="Today", style="Sentinel.TButton", command=lambda: self.load_date(date.today().isoformat())).pack(side="left", padx=5)
        ttk.Button(nav, text="Next Day ▶", style="Sentinel.TButton", command=lambda: self.shift_day(1)).pack(side="left")
        tk.Label(nav, text=f"Date ({self.date_format}):", bg=t["bg"], fg=t["gold"], font=("TkDefaultFont", 10, "bold")).pack(side="left", padx=(18, 4))
        self.date_var = tk.StringVar(value=self.format_date(self.current_date))
        date_entry = self._tk_entry(nav, textvariable=self.date_var, width=14)
        date_entry.pack(side="left", ipady=4)
        ttk.Button(nav, text="Load", style="Sentinel.TButton", command=lambda: self.load_date(self.date_var.get().strip())).pack(side="left", padx=5)
        ttk.Button(nav, text="Jump", style="Sentinel.TButton", command=self.jump_to_date).pack(side="left", padx=(0, 5))
        ttk.Button(nav, text="Save Entry", style="Primary.TButton", command=self.save_current).pack(side="right")
        ttk.Button(nav, text="Encrypted Backup", style="Sentinel.TButton", command=self.backup_encrypted).pack(side="right", padx=(0, 6))

        workspace = tk.Frame(outer, bg=t["bg"])
        workspace.pack(fill="both", expand=True)

        overview = tk.LabelFrame(
            workspace,
            text="  Past Entries  ",
            bg=t["bg"],
            fg=t["gold"],
            padx=8,
            pady=8,
            width=285,
            highlightbackground=t["border"],
            highlightthickness=1,
            font=("TkDefaultFont", 10, "bold"),
        )
        overview.pack(side="left", fill="y", padx=(0, 10))
        overview.pack_propagate(False)

        self.overview_count_var = tk.StringVar(value="0 saved entries")
        tk.Label(
            overview,
            textvariable=self.overview_count_var,
            bg=t["bg"],
            fg=t["cyan"],
            anchor="w",
            font=("TkDefaultFont", 8, "bold"),
        ).pack(fill="x", pady=(0, 6))

        self.overview_filter_var = tk.StringVar()
        overview_filter = self._tk_entry(overview, textvariable=self.overview_filter_var)
        overview_filter.pack(fill="x", ipady=4, pady=(0, 6))
        overview_filter.bind("<Return>", lambda _e: self.refresh_overview())
        filter_grid = tk.Frame(overview, bg=t["bg"])
        filter_grid.pack(fill="x", pady=(0, 6))
        self.overview_start_var = tk.StringVar()
        self.overview_end_var = tk.StringVar()
        self.overview_tag_var = tk.StringVar()
        self.overview_mood_var = tk.StringVar()
        tk.Label(filter_grid, text=f"From ({self.date_format})", bg=t["bg"], fg=t["muted"], font=("TkDefaultFont", 8)).grid(row=0, column=0, sticky="w")
        self._tk_entry(filter_grid, textvariable=self.overview_start_var, width=11).grid(row=0, column=1, sticky="ew", padx=(3,0))
        tk.Label(filter_grid, text=f"To ({self.date_format})", bg=t["bg"], fg=t["muted"], font=("TkDefaultFont", 8)).grid(row=1, column=0, sticky="w")
        self._tk_entry(filter_grid, textvariable=self.overview_end_var, width=11).grid(row=1, column=1, sticky="ew", padx=(3,0), pady=(3,0))
        tk.Label(filter_grid, text="Tag", bg=t["bg"], fg=t["muted"], font=("TkDefaultFont", 8)).grid(row=2, column=0, sticky="w")
        self._tk_entry(filter_grid, textvariable=self.overview_tag_var, width=11).grid(row=2, column=1, sticky="ew", padx=(3,0), pady=(3,0))
        tk.Label(filter_grid, text="Mood", bg=t["bg"], fg=t["muted"], font=("TkDefaultFont", 8)).grid(row=3, column=0, sticky="w")
        self._tk_entry(filter_grid, textvariable=self.overview_mood_var, width=11).grid(row=3, column=1, sticky="ew", padx=(3,0), pady=(3,0))
        filter_grid.columnconfigure(1, weight=1)

        overview_buttons = tk.Frame(overview, bg=t["bg"])
        overview_buttons.pack(fill="x", pady=(0, 6))
        ttk.Button(overview_buttons, text="Refresh", style="Sentinel.TButton", command=self.refresh_overview).pack(side="left", fill="x", expand=True, padx=(0, 4))
        ttk.Button(overview_buttons, text="Today", style="Sentinel.TButton", command=lambda: self.load_date(date.today().isoformat())).pack(side="left", fill="x", expand=True)

        overview_list_frame = tk.Frame(overview, bg=t["bg"])
        overview_list_frame.pack(fill="both", expand=True)
        self.overview_list = tk.Listbox(
            overview_list_frame,
            height=18,
            bg=t["field"],
            fg=t["text"],
            selectbackground=t["gold_dark"],
            selectforeground=t["text"],
            relief="flat",
            highlightthickness=1,
            highlightbackground=t["border"],
            highlightcolor=t["gold"],
            activestyle="none",
        )
        self.overview_list.pack(side="left", fill="both", expand=True)
        overview_scroll = ttk.Scrollbar(overview_list_frame, orient="vertical", command=self.overview_list.yview, style="Vertical.TScrollbar")
        overview_scroll.pack(side="right", fill="y")
        self.overview_list.configure(yscrollcommand=overview_scroll.set)
        self.overview_list.bind("<<ListboxSelect>>", self.on_overview_select)
        self.overview_list.bind("<Double-Button-1>", self.on_overview_select)

        ttk.Button(overview, text="Load Selected", style="Primary.TButton", command=self.load_selected_overview).pack(fill="x", pady=(8, 4))
        ttk.Button(overview, text="Clear Filter", style="Sentinel.TButton", command=self.clear_overview_filter).pack(fill="x")
        tk.Label(
            overview,
            text="Overview decrypts entry titles locally in memory only.",
            bg=t["bg"],
            fg=t["muted"],
            wraplength=245,
            justify="left",
            font=("TkDefaultFont", 8),
        ).pack(fill="x", pady=(8, 0))

        editor = tk.Frame(workspace, bg=t["bg"])
        editor.pack(side="left", fill="both", expand=True)

        meta = tk.Frame(
            editor,
            bg=t["panel_alt"],
            padx=10,
            pady=10,
            highlightbackground=t["border"],
            highlightthickness=1,
        )
        meta.pack(fill="x", pady=(0, 8))
        tk.Label(meta, text="Title", bg=t["panel_alt"], fg=t["gold"], font=("TkDefaultFont", 9, "bold")).grid(row=0, column=0, sticky="w")
        self.title_var = tk.StringVar()
        self._tk_entry(meta, textvariable=self.title_var).grid(row=0, column=1, sticky="ew", padx=(6, 14), ipady=4)
        tk.Label(meta, text="Mood", bg=t["panel_alt"], fg=t["gold"], font=("TkDefaultFont", 9, "bold")).grid(row=0, column=2, sticky="w")
        self.mood_var = tk.StringVar()
        self._tk_entry(meta, textvariable=self.mood_var, width=20).grid(row=0, column=3, sticky="ew", padx=(6, 0), ipady=4)
        tk.Label(meta, text="Tags", bg=t["panel_alt"], fg=t["gold"], font=("TkDefaultFont", 9, "bold")).grid(row=1, column=0, sticky="w", pady=(8, 0))
        self.tags_var = tk.StringVar()
        self._tk_entry(meta, textvariable=self.tags_var).grid(row=1, column=1, columnspan=3, sticky="ew", padx=(6, 0), pady=(8, 0), ipady=4)
        meta.columnconfigure(1, weight=3)
        meta.columnconfigure(3, weight=1)

        body_frame = tk.LabelFrame(
            editor,
            text="  Entry  ",
            bg=t["bg"],
            fg=t["gold"],
            padx=8,
            pady=8,
            highlightbackground=t["border"],
            highlightthickness=1,
            font=("TkDefaultFont", 10, "bold"),
        )
        body_frame.pack(fill="both", expand=True, pady=(0, 8))
        self.body_text = tk.Text(
            body_frame,
            wrap="word",
            undo=True,
            padx=12,
            pady=12,
            bg=t["field"],
            fg=t["text"],
            insertbackground=t["gold"],
            selectbackground=t["gold_dark"],
            selectforeground=t["text"],
            relief="flat",
            highlightthickness=1,
            highlightbackground=t["border"],
            highlightcolor=t["gold"],
        )
        self.body_text.pack(side="left", fill="both", expand=True)
        scroll = ttk.Scrollbar(body_frame, orient="vertical", command=self.body_text.yview, style="Vertical.TScrollbar")
        scroll.pack(side="right", fill="y")
        self.body_text.configure(yscrollcommand=scroll.set)

        search = tk.LabelFrame(
            editor,
            text="  Search encrypted entries  ",
            bg=t["bg"],
            fg=t["gold"],
            padx=8,
            pady=8,
            highlightbackground=t["border"],
            highlightthickness=1,
            font=("TkDefaultFont", 10, "bold"),
        )
        search.pack(fill="x")
        self.search_var = tk.StringVar()
        self._tk_entry(search, textvariable=self.search_var).pack(side="left", fill="x", expand=True, padx=(0, 6), ipady=4)
        ttk.Button(search, text="Search", style="Sentinel.TButton", command=self.search_entries).pack(side="left", padx=(0, 6))
        self.search_list = tk.Listbox(
            search,
            height=4,
            bg=t["field"],
            fg=t["text"],
            selectbackground=t["gold_dark"],
            selectforeground=t["text"],
            relief="flat",
            highlightthickness=1,
            highlightbackground=t["border"],
            highlightcolor=t["gold"],
        )
        self.search_list.pack(side="left", fill="both", expand=True, padx=(0, 0))
        self.search_list.bind("<<ListboxSelect>>", self.on_search_select)

        status_frame = tk.Frame(outer, bg=t["panel"], highlightbackground=t["border"], highlightthickness=1)
        status_frame.pack(fill="x", pady=(8, 0))
        self.status_var = tk.StringVar(value="Ready. Entries are encrypted at rest. Sentinel/AEGIS theme active.")
        tk.Label(status_frame, textvariable=self.status_var, bg=t["panel"], fg=t["muted"], anchor="w", padx=8, pady=6).pack(side="left", fill="x", expand=True)
        tk.Label(status_frame, text="network: disabled", bg=t["panel"], fg=t["cyan"], padx=8, pady=6, font=("TkDefaultFont", 8, "bold")).pack(side="right")

        self.root.bind("<Control-s>", lambda _e: self.save_current())
        self.root.bind("<Control-h>", lambda _e: self.toggle_privacy())
        self.root.bind("<Control-j>", lambda _e: self.jump_to_date())
        self.root.bind("<F5>", lambda _e: self.refresh_overview())
        self.root.bind_all("<Control-q>", self.close_app)
        self.root.bind_all("<Control-Q>", self.close_app)
        self.root.protocol("WM_DELETE_WINDOW", self.close_app)
        self.root.after(400, self.offer_first_run_setup)

    def close_app(self, _event: Any = None) -> str:
        self.root.destroy()
        return "break"

    def show_shortcuts(self) -> None:
        self.messagebox.showinfo(
            APP_NAME,
            "Keyboard shortcuts\n\n"
            "Ctrl+S — Save current entry\n"
            "Ctrl+H — Toggle privacy view\n"
            "Ctrl+J — Jump to date\n"
            "Ctrl+Q — Close application\n"
            "F5 — Refresh past entries\n\n"
            "Dates display using your Settings → Date Format Settings preference. Internal encrypted storage remains YYYY-MM-DD for compatibility.",
        )

    def show_stable_lock(self) -> None:
        self.messagebox.showinfo(
            APP_NAME,
            f"Sentinel Diary v{VERSION} Stable Lock\n\n"
            "Program 105 — Sentinel Desktop Suite\n"
            "Status: stable baseline locked\n"
            "Storage: AES-256-GCM encrypted opaque object store\n"
            "AEGIS: local-only read-only helper contract preserved\n"
            "Network: disabled / no cloud / no telemetry\n"
            f"Date display: {self.date_format}\n\n"
            "Validated phase path: v0.6.0 import/export, v0.7.0 AEGIS Integration Lock, v0.8.0 doctor/repair, v0.8.1 date settings, v0.9.0 release candidate, v1.0.0 stable lock, v1.0.1 Ctrl+Q close hotkey patch.",
        )

    def show_about(self) -> None:
        self.messagebox.showinfo(
            APP_NAME,
            f"Sentinel Diary v{VERSION}\n\n"
            "Program 105 — encrypted local diary for SentinelOS.\n\n"
            "Built for local-first personal journaling with encrypted storage, optional password locking, private backups, import/export, AEGIS local read-only access, and a network-disabled design.",
        )

    def refresh_overview(self, select_date: Optional[str] = None) -> None:
        if not hasattr(self, "overview_list"):
            return
        query = self.overview_filter_var.get().strip() if hasattr(self, "overview_filter_var") else ""
        try:
            start_date = self.parse_date(self.overview_start_var.get().strip()) if hasattr(self, "overview_start_var") and self.overview_start_var.get().strip() else ""
            end_date = self.parse_date(self.overview_end_var.get().strip()) if hasattr(self, "overview_end_var") and self.overview_end_var.get().strip() else ""
        except ValueError as exc:
            self.status_var.set(str(exc))
            return
        tag = self.overview_tag_var.get().strip() if hasattr(self, "overview_tag_var") else ""
        mood = self.overview_mood_var.get().strip() if hasattr(self, "overview_mood_var") else ""
        self._overview_busy = True
        try:
            self.overview_list.delete(0, "end")
            self.overview_dates = []
            entries = sorted(self.store.filter_entries(query=query, start_date=start_date, end_date=end_date, tag=tag, mood=mood), key=lambda entry: entry.entry_date, reverse=True)
            for entry in entries:
                self.overview_dates.append(entry.entry_date)
                title = entry.title or "(untitled)"
                if len(title) > 34:
                    title = title[:31] + "..."
                mood = f" · {entry.mood}" if entry.mood else ""
                self.overview_list.insert("end", f"{self.format_date(entry.entry_date)} · {title}{mood}")
            self.overview_count_var.set(f"{len(self.overview_dates)} saved entries")
            if select_date:
                for index, entry_date in enumerate(self.overview_dates):
                    if entry_date == select_date:
                        self.overview_list.selection_set(index)
                        self.overview_list.see(index)
                        break
        finally:
            self._overview_busy = False

    def clear_overview_filter(self) -> None:
        if hasattr(self, "overview_filter_var"):
            self.overview_filter_var.set("")
        for attr in ("overview_start_var", "overview_end_var", "overview_tag_var", "overview_mood_var"):
            if hasattr(self, attr):
                getattr(self, attr).set("")
        self.refresh_overview(select_date=self.current_date)

    def load_selected_overview(self) -> None:
        if not hasattr(self, "overview_list"):
            return
        selection = self.overview_list.curselection()
        if not selection:
            self.status_var.set("No past entry selected.")
            return
        index = int(selection[0])
        if 0 <= index < len(self.overview_dates):
            self.load_date(self.overview_dates[index])

    def on_overview_select(self, _event: Any) -> None:
        if getattr(self, "_overview_busy", False):
            return
        self.load_selected_overview()

    def body_get(self) -> str:
        return self.body_text.get("1.0", "end-1c")

    def body_set(self, text: str) -> None:
        self.body_text.delete("1.0", "end")
        self.body_text.insert("1.0", text)

    def clear_fields(self) -> None:
        self.title_var.set("")
        self.mood_var.set("")
        self.tags_var.set("")
        self.body_set("")

    def load_date(self, date_str: str) -> None:
        try:
            iso_date = self.parse_date(date_str)
        except ValueError as exc:
            self.messagebox.showerror(APP_NAME, str(exc))
            return
        self.current_date = iso_date
        self.date_var.set(self.format_date(iso_date))
        entry = self.store.load(iso_date)
        self.clear_fields()
        shown_date = self.format_date(iso_date)
        if entry:
            self.title_var.set(entry.title)
            self.mood_var.set(entry.mood)
            self.tags_var.set(entry.tags)
            self.body_set(entry.body)
            self.status_var.set(f"Loaded encrypted entry for {shown_date}.")
        else:
            self.status_var.set(f"No entry yet for {shown_date}.")
        self.refresh_overview(select_date=iso_date)

    def shift_day(self, delta: int) -> None:
        try:
            current = date.fromisoformat(self.parse_date(self.date_var.get().strip()))
        except ValueError:
            current = date.today()
        self.load_date((current + timedelta(days=delta)).isoformat())

    def save_current(self) -> None:
        try:
            entry_date = self.parse_date(self.date_var.get().strip())
        except ValueError as exc:
            self.messagebox.showerror(APP_NAME, str(exc))
            return
        entry = DiaryEntry(
            entry_date=entry_date,
            title=self.title_var.get().strip(),
            mood=self.mood_var.get().strip(),
            tags=self.tags_var.get().strip(),
            body=self.body_get(),
        )
        try:
            path = self.store.save(entry)
            self.current_date = entry.entry_date
            self.date_var.set(self.format_date(entry.entry_date))
            self.refresh_overview(select_date=entry.entry_date)
            self.status_var.set(f"Saved encrypted entry: {path.name}")
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))

    def delete_current(self) -> None:
        try:
            deleted_date = self.parse_date(self.date_var.get().strip())
        except ValueError as exc:
            self.messagebox.showerror(APP_NAME, str(exc))
            return
        if not self.messagebox.askyesno(APP_NAME, f"Delete entry for {self.format_date(deleted_date)}? A backup will be kept."):
            return
        if self.store.delete(deleted_date):
            self.clear_fields()
            self.refresh_overview()
            self.status_var.set("Entry deleted. Encrypted backup retained.")
        else:
            self.status_var.set("No entry found to delete.")

    def toggle_privacy(self) -> None:
        if self.privacy_hidden:
            self.body_set(self.last_body_cache)
            self.privacy_hidden = False
            self.status_var.set("Privacy view disabled.")
        else:
            self.last_body_cache = self.body_get()
            self.body_set("[Privacy view enabled — entry hidden on screen]")
            self.privacy_hidden = True
            self.status_var.set("Privacy view enabled. Text hidden on screen only.")

    def lock_diary(self) -> None:
        status = self.store.keyring.status()
        self.clear_fields()
        self.status_var.set("Diary locked.")
        if status.get("password_enabled"):
            password = self.simpledialog.askstring(APP_NAME, "Unlock diary password:", show="*", parent=self.root)
            if password is None:
                return
            try:
                self.store = DiaryStore(self.paths, password=password)
                self.store.keyring.master_key()
                self.password = password
                self.load_date(self.current_date)
                self.status_var.set("Diary unlocked.")
            except Exception:
                self.messagebox.showerror(APP_NAME, "Unlock failed.")
        else:
            self.load_date(self.current_date)
            self.messagebox.showinfo(APP_NAME, "Password lock is not enabled. Use Privacy → Set / Change Password for stronger locking.")

    def set_password(self) -> None:
        p1 = self.simpledialog.askstring(APP_NAME, "New diary password, minimum 8 characters:", show="*", parent=self.root)
        if p1 is None:
            return
        p2 = self.simpledialog.askstring(APP_NAME, "Confirm new password:", show="*", parent=self.root)
        if p1 != p2:
            self.messagebox.showerror(APP_NAME, "Passwords do not match.")
            return
        try:
            self.store.keyring.enable_password(p1)
            self.password = p1
            self.messagebox.showinfo(APP_NAME, "Password lock enabled. Diary master key is now password-wrapped.")
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))

    def disable_password(self) -> None:
        if not self.messagebox.askyesno(APP_NAME, "Disable password lock? Entries remain encrypted with the local app key."):
            return
        password = self.password
        if self.store.keyring.status().get("password_enabled") and not password:
            password = self.simpledialog.askstring(APP_NAME, "Current password:", show="*", parent=self.root)
        try:
            self.store.keyring.disable_password(password=password)
            self.password = None
            self.messagebox.showinfo(APP_NAME, "Password lock disabled. Entries remain encrypted at rest.")
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))

    def search_entries(self) -> None:
        query = self.search_var.get().strip()
        self.search_list.delete(0, "end")
        for entry in self.store.search(query):
            label = f"{self.format_date(entry.entry_date)} — {entry.title or '(untitled)'}"
            self.search_list.insert("end", label)
        self.status_var.set("Search complete. Results decrypted locally in memory only.")

    def on_search_select(self, _event: Any) -> None:
        selection = self.search_list.curselection()
        if not selection:
            return
        label = self.search_list.get(selection[0])
        self.load_date(label.split(" — ", 1)[0])

    def confirm_plaintext_export(self) -> bool:
        return self.messagebox.askyesno(
            APP_NAME,
            "Markdown export writes decrypted plaintext files.\n\n"
            "Only export to a private or encrypted location. Continue?",
            parent=self.root,
        )

    def export_current(self) -> None:
        if not self.confirm_plaintext_export():
            return
        entry = self.store.load(self.parse_date(self.date_var.get().strip()))
        if not entry:
            self.messagebox.showinfo(APP_NAME, "No saved entry to export.")
            return
        folder = self.filedialog.askdirectory(title="Choose export folder")
        if not folder:
            return
        path = self.store.export_entry_markdown(entry, Path(folder))
        self.messagebox.showinfo(APP_NAME, f"Exported:\n{path}")

    def export_all(self) -> None:
        if not self.confirm_plaintext_export():
            return
        folder = self.filedialog.askdirectory(title="Choose export folder")
        if not folder:
            return
        paths = self.store.export_all_markdown(Path(folder))
        self.messagebox.showinfo(APP_NAME, f"Exported {len(paths)} entries.")


    def jump_to_date(self) -> None:
        value = self.simpledialog.askstring(APP_NAME, f"Jump to date ({self.date_format}; ISO also accepted):", initialvalue=self.date_var.get().strip(), parent=self.root)
        if not value:
            return
        self.load_date(value.strip())

    def duplicate_current(self) -> None:
        try:
            source_date = self.parse_date(self.date_var.get().strip())
        except ValueError as exc:
            self.messagebox.showerror(APP_NAME, str(exc))
            return
        if not self.store.exists(source_date):
            self.messagebox.showinfo(APP_NAME, "Save this entry before duplicating it.")
            return
        target = self.simpledialog.askstring(APP_NAME, f"Duplicate to date ({self.date_format}; ISO also accepted):", parent=self.root)
        if not target:
            return
        try:
            target_iso = self.parse_date(target.strip())
            self.store.duplicate_entry(source_date, target_iso)
            self.refresh_overview(select_date=target_iso)
            self.load_date(target_iso)
            self.status_var.set(f"Duplicated entry {self.format_date(source_date)} to {self.format_date(target_iso)}.")
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))

    def format_date(self, iso_date: str) -> str:
        return format_iso_date(iso_date, self.date_format)

    def parse_date(self, value: str) -> str:
        return parse_user_date(value, self.date_format)

    def set_date_format(self, fmt_name: str) -> None:
        fmt_name = normalize_date_format(fmt_name)
        self.date_format = fmt_name
        self.date_format_var.set(fmt_name)
        self.settings["date_format"] = fmt_name
        save_app_settings(self.paths, self.settings)
        # Re-render the current date field and overview using the new display format.
        self.date_var.set(self.format_date(self.current_date))
        self.refresh_overview(select_date=self.current_date)
        self.status_var.set(f"Date format changed to {fmt_name}.")

    def choose_date_format(self) -> None:
        options = "\n".join(f"- {name}" for name in DATE_FORMAT_OPTIONS)
        value = self.simpledialog.askstring(
            APP_NAME,
            "Choose date format:\n\n" + options,
            initialvalue=self.date_format,
            parent=self.root,
        )
        if not value:
            return
        value = value.strip().upper()
        aliases = {
            "DD/MM/YYY": "DD/MM/YYYY",
            "DD/MM/YYYY": "DD/MM/YYYY",
            "YYYY-MM-DD": "YYYY-MM-DD",
            "MM/DD/YYYY": "MM/DD/YYYY",
        }
        fmt_name = aliases.get(value, value)
        if fmt_name not in DATE_FORMAT_OPTIONS:
            self.messagebox.showerror(APP_NAME, "Supported formats: " + ", ".join(DATE_FORMAT_OPTIONS))
            return
        self.set_date_format(fmt_name)

    def offer_first_run_setup(self) -> None:
        marker = self.paths.first_run
        if marker.exists():
            return
        try:
            status = self.store.keyring.status()
        except Exception:
            return
        secure_write_json(marker, {"version": 1, "offered_at": utc_now_iso()}, mode=0o600)
        if status.get("password_enabled"):
            return
        if self.messagebox.askyesno(
            APP_NAME,
            "Sentinel Diary is encrypted by default.\n\n"
            "Do you want to add a password lock now for stronger protection?\n\n"
            "You can also do this later from Privacy → Set / Change Password.",
            parent=self.root,
        ):
            self.set_password()

    def first_run_privacy_setup(self) -> None:
        try:
            status = self.store.keyring.status()
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))
            return
        detail = (
            "Sentinel Diary privacy setup\n\n"
            "• Entries are encrypted at rest with AES-256-GCM.\n"
            "• Opaque filenames hide readable diary dates.\n"
            "• The encrypted manifest hides titles, moods, tags, and dates.\n"
            "• A password lock wraps the diary master key for stronger protection.\n\n"
            f"Password lock currently enabled: {status.get('password_enabled')}\n\n"
            "Enable/change password lock now?"
        )
        if self.messagebox.askyesno(APP_NAME, detail, parent=self.root):
            self.set_password()

    def backup_encrypted(self) -> None:
        folder = self.filedialog.askdirectory(title="Choose encrypted backup folder")
        if not folder:
            return
        password = None
        if self.messagebox.askyesno(APP_NAME, "Protect this backup with a separate backup password?", parent=self.root):
            p1 = self.simpledialog.askstring(APP_NAME, "Backup password:", show="*", parent=self.root)
            if p1 is None:
                return
            p2 = self.simpledialog.askstring(APP_NAME, "Confirm backup password:", show="*", parent=self.root)
            if p1 != p2:
                self.messagebox.showerror(APP_NAME, "Backup passwords do not match.")
                return
            password = p1
        try:
            path = self.store.export_encrypted_backup(Path(folder), backup_password=password)
            self.messagebox.showinfo(APP_NAME, f"Encrypted backup created:\n{path}")
            self.status_var.set(f"Encrypted backup created: {path.name}")
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))

    def restore_encrypted(self) -> None:
        filename = self.filedialog.askopenfilename(
            title="Choose Sentinel Diary encrypted backup",
            filetypes=[("Sentinel Diary backup", "*.sdbak.json"), ("JSON", "*.json"), ("All files", "*")],
        )
        if not filename:
            return
        password = None
        if self.messagebox.askyesno(APP_NAME, "Was this backup protected with a separate backup password?", parent=self.root):
            password = self.simpledialog.askstring(APP_NAME, "Backup password:", show="*", parent=self.root)
            if password is None:
                return
        overwrite = self.messagebox.askyesno(APP_NAME, "Overwrite existing entries with matching dates?", parent=self.root)
        try:
            restored = self.store.restore_encrypted_backup(Path(filename), backup_password=password, overwrite=overwrite)
            self.refresh_overview(select_date=self.current_date)
            self.messagebox.showinfo(APP_NAME, f"Restored {restored} entries from encrypted backup.")
            self.status_var.set(f"Restored {restored} entries from encrypted backup.")
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))

    def show_security_status(self) -> None:
        status = self.store.keyring.status()
        fs_encrypted, fs_note = best_effort_fs_encryption_status(self.paths.entries)
        self.messagebox.showinfo(
            APP_NAME,
            f"App encryption: AES-256-GCM object store\n"
            f"Storage: {self.paths.entries}\n"
            f"Object store: {self.paths.objects}\n"
            f"Manifest: encrypted\n"
            f"Directory permissions private: {is_private_dir(self.paths.entries)}\n"
            f"Filesystem directory encryption detected: {fs_encrypted}\n"
            f"Filesystem note: {fs_note}\n"
            f"Key mode: {status.get('mode')}\n"
            f"Password lock: {status.get('password_enabled')}\n"
            f"Keyring private: {status.get('keyring_private')}\n"
            f"Network allowed: False",
        )

    def export_encrypted_selected(self) -> None:
        folder = self.filedialog.askdirectory(title="Choose encrypted export folder")
        if not folder:
            return
        password = None
        if self.messagebox.askyesno(APP_NAME, "Protect this export with a separate export password?", parent=self.root):
            password = self.simpledialog.askstring(APP_NAME, "Export password:", show="*", parent=self.root)
            if not password:
                return
            p2 = self.simpledialog.askstring(APP_NAME, "Confirm export password:", show="*", parent=self.root)
            if password != p2:
                self.messagebox.showerror(APP_NAME, "Export passwords do not match.")
                return
        try:
            path = self.store.export_encrypted_entries(
                Path(folder),
                backup_password=password,
                query=self.filter_var.get().strip() if hasattr(self, "filter_var") else "",
                start_date=getattr(self, "filter_start_var", self.tk.StringVar(value="")).get().strip() if hasattr(self, "filter_start_var") else "",
                end_date=getattr(self, "filter_end_var", self.tk.StringVar(value="")).get().strip() if hasattr(self, "filter_end_var") else "",
                tag=getattr(self, "filter_tag_var", self.tk.StringVar(value="")).get().strip() if hasattr(self, "filter_tag_var") else "",
                mood=getattr(self, "filter_mood_var", self.tk.StringVar(value="")).get().strip() if hasattr(self, "filter_mood_var") else "",
            )
            self.messagebox.showinfo(APP_NAME, f"Encrypted export created:\n{path}")
            self.status_var.set(f"Encrypted export created: {path.name}")
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))

    def import_encrypted_export_gui(self) -> None:
        filename = self.filedialog.askopenfilename(
            title="Choose Sentinel Diary encrypted export/backup",
            filetypes=[("Sentinel Diary export/backup", "*.sdexp.json *.sdbak.json"), ("JSON", "*.json"), ("All files", "*")],
        )
        if not filename:
            return
        password = None
        if self.messagebox.askyesno(APP_NAME, "Was this export protected with a separate export/backup password?", parent=self.root):
            password = self.simpledialog.askstring(APP_NAME, "Export/backup password:", show="*", parent=self.root)
            if password is None:
                return
        overwrite = self.messagebox.askyesno(APP_NAME, "Overwrite existing entries with matching dates?", parent=self.root)
        try:
            restored = self.store.import_encrypted_entries(Path(filename), backup_password=password, overwrite=overwrite)
            self.refresh_overview()
            self.messagebox.showinfo(APP_NAME, f"Imported {restored} entries.")
            self.status_var.set(f"Imported {restored} encrypted entries.")
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))

    def import_markdown_gui(self) -> None:
        filename = self.filedialog.askopenfilename(
            title="Choose Markdown/text file to import",
            filetypes=[("Markdown/Text", "*.md *.txt"), ("All files", "*")],
        )
        if not filename:
            return
        entry_date = self.simpledialog.askstring(APP_NAME, f"Entry date {self.date_format} (blank = detect/today; ISO also accepted):", parent=self.root)
        overwrite = self.messagebox.askyesno(APP_NAME, "Overwrite existing entry if the date already exists?", parent=self.root)
        try:
            entry_iso = self.parse_date(entry_date.strip()) if entry_date and entry_date.strip() else None
            path = self.store.import_markdown_file(Path(filename), entry_date=entry_iso, overwrite=overwrite)
            self.refresh_overview()
            self.messagebox.showinfo(APP_NAME, f"Imported and encrypted entry:\n{path.name}")
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))

    def run_storage_repair(self) -> None:
        if not self.messagebox.askyesno(APP_NAME, "Repair permissions, policies, and encrypted manifest now?", parent=self.root):
            return
        try:
            report = self.store.repair_storage(reset_policy=True, reset_aegis_policy=True, rebuild_manifest=True)
            self.refresh_overview()
            actions = "\n".join(f"- {item}" for item in report.get("actions", []))
            self.messagebox.showinfo(APP_NAME, "Repair complete:\n" + actions)
            self.status_var.set("Storage repair complete.")
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))


    def show_aegis_info(self) -> None:
        self.messagebox.showinfo(
            APP_NAME,
            "AEGIS local read-only interface:\n\n"
            "sentinel-diary-aegis status\n"
            "sentinel-diary-aegis list\n"
            "sentinel-diary-aegis read YYYY-MM-DD\n"
            "sentinel-diary-aegis search <query>\n\n"
            "No network transport is used. Password-protected diaries require user-authorized unlock/password.",
        )

    def show_network_policy(self) -> None:
        self.messagebox.showinfo(APP_NAME, json.dumps(NETWORK_POLICY, indent=2))

    def run(self) -> None:
        self.root.mainloop()


def cmd_settings(args: argparse.Namespace) -> int:
    paths = DiaryPaths()
    settings = load_app_settings(paths)
    if getattr(args, "json", False):
        print(json.dumps(settings, indent=2, ensure_ascii=False))
    else:
        print(f"Date format: {settings.get('date_format', DEFAULT_DATE_FORMAT)}")
        print("Available formats: " + ", ".join(DATE_FORMAT_OPTIONS))
    return 0


def cmd_set_date_format(args: argparse.Namespace) -> int:
    paths = DiaryPaths()
    settings = load_app_settings(paths)
    fmt_name = normalize_date_format(args.format)
    if args.format not in DATE_FORMAT_OPTIONS:
        raise SystemExit("Supported formats: " + ", ".join(DATE_FORMAT_OPTIONS))
    settings["date_format"] = fmt_name
    save_app_settings(paths, settings)
    print(f"Date format set to {fmt_name}")
    return 0


def cmd_init(args: argparse.Namespace) -> int:
    patch_network_off()
    store = DiaryStore(password=args.password)
    print(f"{APP_NAME} initialized")
    print(f"data: {store.paths.data}")
    print(f"config: {store.paths.config}")
    print("encryption: AES-256-GCM")
    print("network: disabled")
    return 0


def cmd_status(_args: argparse.Namespace) -> int:
    patch_network_off()
    paths = DiaryPaths()
    paths.ensure()
    store = DiaryStore(paths)
    status = store.keyring.status()
    print(f"{APP_NAME} v{VERSION}")
    print(f"Program: 105")
    fs_encrypted, fs_note = best_effort_fs_encryption_status(paths.entries)
    print(f"Date format: {load_app_settings(paths).get('date_format', DEFAULT_DATE_FORMAT)}")
    print(f"Data: {paths.data}")
    print(f"Entries: {len(store.list_dates())}")
    print(f"Storage layout: opaque encrypted object store")
    print(f"Entries path: {paths.objects}")
    print(f"Encrypted manifest: {paths.manifest}")
    print(f"Directory permissions private: {is_private_dir(paths.entries)}")
    print(f"Filesystem directory encryption detected: {fs_encrypted} ({fs_note})")
    print(f"Encryption: AES-256-GCM")
    print(f"Key mode: {status.get('mode')}")
    print(f"Password lock: {status.get('password_enabled')}")
    print(f"Network allowed: False")
    print(f"AEGIS local interface: enabled/read-only")
    return 0


def cmd_data_dir(_args: argparse.Namespace) -> int:
    print(DiaryPaths().data)
    return 0


def cmd_export_all(args: argparse.Namespace) -> int:
    patch_network_off()
    print("WARNING: Markdown export writes decrypted plaintext files. Use only with a private/encrypted destination.", file=sys.stderr)
    store = DiaryStore(password=args.password)
    folder = Path(args.folder).expanduser() if args.folder else None
    paths = store.export_all_markdown(folder)
    print(f"Exported {len(paths)} entries")
    for path in paths:
        print(path)
    return 0



def cmd_backup(args: argparse.Namespace) -> int:
    patch_network_off()
    store = DiaryStore(password=args.password)
    backup_password = args.backup_password
    if args.ask_backup_password:
        p1 = getpass.getpass("Backup password: ")
        p2 = getpass.getpass("Confirm backup password: ")
        if p1 != p2:
            print("Backup passwords do not match", file=sys.stderr)
            return 2
        backup_password = p1
    folder = Path(args.folder).expanduser() if args.folder else None
    path = store.export_encrypted_backup(folder, backup_password=backup_password)
    print(path)
    return 0


def cmd_restore(args: argparse.Namespace) -> int:
    patch_network_off()
    store = DiaryStore(password=args.password)
    backup_password = args.backup_password
    if args.ask_backup_password:
        backup_password = getpass.getpass("Backup password: ")
    restored = store.restore_encrypted_backup(Path(args.backup_file), backup_password=backup_password, overwrite=args.overwrite)
    print(f"Restored {restored} entries")
    return 0


def _prompt_optional_bundle_password(args: argparse.Namespace, label: str = "Export/backup") -> Optional[str]:
    password = getattr(args, "backup_password", None) or getattr(args, "export_password", None)
    ask = bool(getattr(args, "ask_backup_password", False) or getattr(args, "ask_export_password", False))
    if ask:
        p1 = getpass.getpass(f"{label} password: ")
        p2 = getpass.getpass(f"Confirm {label.lower()} password: ")
        if p1 != p2:
            raise ValueError("Passwords do not match")
        password = p1
    return password


def cmd_export_encrypted(args: argparse.Namespace) -> int:
    patch_network_off()
    store = load_store_for_cli(args)
    bundle_password = _prompt_optional_bundle_password(args, "Export")
    path = store.export_encrypted_entries(
        Path(args.folder).expanduser() if args.folder else None,
        backup_password=bundle_password,
        dates=args.date or None,
        query=args.query or "",
        start_date=args.start or "",
        end_date=args.end or "",
        tag=args.tag or "",
        mood=args.mood or "",
    )
    print(path)
    return 0


def cmd_import_encrypted(args: argparse.Namespace) -> int:
    patch_network_off()
    store = load_store_for_cli(args)
    bundle_password = args.backup_password or args.export_password
    if args.ask_backup_password or args.ask_export_password:
        bundle_password = getpass.getpass("Export/backup password: ")
    restored = store.import_encrypted_entries(Path(args.export_file), backup_password=bundle_password, overwrite=args.overwrite)
    print(f"Imported {restored} entries")
    return 0


def cmd_import_markdown(args: argparse.Namespace) -> int:
    patch_network_off()
    store = load_store_for_cli(args)
    path = store.import_markdown_file(Path(args.markdown_file), entry_date=args.date, overwrite=args.overwrite)
    print(path)
    return 0


def cmd_integrity(args: argparse.Namespace) -> int:
    patch_network_off()
    store = load_store_for_cli(args)
    report = store.integrity_report()
    print(json.dumps(report, indent=None if args.compact else 2, ensure_ascii=False))
    return 0 if report.get("ok") else 1


def cmd_repair(args: argparse.Namespace) -> int:
    patch_network_off()
    store = load_store_for_cli(args)
    report = store.repair_storage(reset_policy=args.reset_policy, reset_aegis_policy=args.reset_aegis_policy, rebuild_manifest=not args.no_rebuild_manifest)
    if args.launchers:
        helper = shutil.which("sentinel-diary-install-launchers")
        if helper:
            import subprocess
            try:
                subprocess.run([helper], check=False)
                report.setdefault("actions", []).append("ran launcher repair helper")
            except Exception as exc:
                report.setdefault("warnings", []).append(f"launcher repair failed: {exc}")
        else:
            report.setdefault("warnings", []).append("launcher helper not found in PATH")
    print(json.dumps(report, indent=2, ensure_ascii=False))
    return 0 if report.get("ok") else 1


def cmd_stats(args: argparse.Namespace) -> int:
    patch_network_off()
    store = DiaryStore(password=args.password)
    print(json.dumps(store.entry_stats(), indent=2, ensure_ascii=False))
    return 0


def cmd_filter(args: argparse.Namespace) -> int:
    patch_network_off()
    store = DiaryStore(password=args.password)
    results = store.filter_entries(query=args.query or "", start_date=args.start or "", end_date=args.end or "", tag=args.tag or "", mood=args.mood or "")
    payload = [
        {
            "entry_date": entry.entry_date,
            "title": entry.title,
            "mood": entry.mood,
            "tags": entry.normalized_tags(),
            "created_at": entry.created_at,
            "updated_at": entry.updated_at,
        }
        for entry in results
    ]
    print(json.dumps({"ok": True, "count": len(payload), "entries": payload}, indent=2, ensure_ascii=False))
    return 0

def cmd_set_password(args: argparse.Namespace) -> int:
    patch_network_off()
    password = args.password or getpass.getpass("New Sentinel Diary password: ")
    confirm = args.password or getpass.getpass("Confirm Sentinel Diary password: ")
    if password != confirm:
        print("Passwords do not match", file=sys.stderr)
        return 2
    store = DiaryStore(password=args.current_password)
    store.keyring.enable_password(password)
    print("Password lock enabled. Entries remain encrypted at rest.")
    return 0


def cmd_disable_password(args: argparse.Namespace) -> int:
    patch_network_off()
    password = args.password or os.environ.get("SENTINEL_DIARY_PASSWORD")
    if not password:
        password = getpass.getpass("Current Sentinel Diary password: ")
    store = DiaryStore(password=password)
    store.keyring.disable_password(password)
    print("Password lock disabled. Entries remain encrypted using local app-managed key.")
    return 0


def format_entry_text(entry: DiaryEntry) -> str:
    return textwrap.dedent(
        f"""
        Date: {entry.entry_date}
        Title: {entry.title}
        Mood: {entry.mood}
        Tags: {entry.tags}
        Created: {entry.created_at}
        Updated: {entry.updated_at}

        {entry.body}
        """
    ).strip()


def load_store_for_cli(args: argparse.Namespace) -> DiaryStore:
    password = getattr(args, "password", None) or os.environ.get("SENTINEL_DIARY_PASSWORD")
    return DiaryStore(password=password)


def aegis_policy_ok(paths: DiaryPaths) -> Tuple[bool, str]:
    paths.ensure()
    policy = read_json(paths.aegis_policy)
    if not policy.get("enabled", False):
        return False, "AEGIS access disabled"
    if not policy.get("read_only", False):
        return False, "AEGIS interface must remain read-only"
    if not policy.get("local_only", False):
        return False, "AEGIS interface must remain local-only"
    if policy.get("network_allowed", True):
        return False, "Network access is not allowed"
    return True, "ok"


def aegis_policy_details(paths: DiaryPaths) -> Dict[str, Any]:
    paths.ensure()
    details = {
        "ok": True,
        "policy_path": str(paths.aegis_policy),
        "required": {
            "enabled": True,
            "read_only": True,
            "local_only": True,
            "network_allowed": False,
        },
        "checks": [],
    }
    try:
        policy = read_json(paths.aegis_policy)
    except Exception as exc:
        return {"ok": False, "error": str(exc), "policy_path": str(paths.aegis_policy)}
    for key, expected in details["required"].items():
        actual = policy.get(key)
        ok = actual is expected
        details["checks"].append({"key": key, "expected": expected, "actual": actual, "ok": ok})
        if not ok:
            details["ok"] = False
    details["policy"] = policy
    return details


def keyring_locked_status(paths: DiaryPaths) -> Dict[str, Any]:
    paths.ensure()
    try:
        status = Keyring(paths).status()
        return {
            "password_enabled": bool(status.get("password_enabled")),
            "key_mode": status.get("mode"),
            "password_required_for_aegis": bool(status.get("password_enabled")),
        }
    except Exception as exc:
        return {"password_enabled": None, "key_mode": "unknown", "error": str(exc)}


def cmd_aegis(args: argparse.Namespace) -> int:
    patch_network_off()
    paths = DiaryPaths()
    policy_details = aegis_policy_details(paths)
    if not policy_details.get("ok"):
        print(json.dumps({"ok": False, "error": "AEGIS policy validation failed", "policy": policy_details}, indent=2))
        return 3
    try:
        if args.aegis_command == "validate-policy":
            print(json.dumps({"ok": True, "policy": policy_details}, indent=2, ensure_ascii=False))
            return 0
        if args.aegis_command == "permissions":
            payload = {
                "ok": True,
                "schema_version": "aegis-diary-v1",
                "app": APP_NAME,
                "version": VERSION,
                "program": 105,
                "access": {
                    "read_only": True,
                    "local_only": True,
                    "network_allowed": False,
                    "raw_file_scraping_required": False,
                    "interface": "sentinel-diary-aegis",
                },
                "keyring": keyring_locked_status(paths),
                "policy": policy_details,
            }
            print(json.dumps(payload, indent=2, ensure_ascii=False))
            return 0
        store = load_store_for_cli(args)
        status = store.keyring.status()
        base = {
            "schema_version": "aegis-diary-v1",
            "ok": True,
            "app": APP_NAME,
            "version": VERSION,
            "program": 105,
            "local_only": True,
            "network_allowed": False,
            "read_only": True,
            "password_enabled": status.get("password_enabled"),
            "key_mode": status.get("mode"),
            "policy_ok": True,
        }
        if args.aegis_command == "status":
            payload = {
                **base,
                "entries": len(store.list_dates()),
                "stats": store.entry_stats(),
                "capabilities": [
                    "status", "permissions", "validate-policy", "list", "read", "search", "filter", "stats"
                ],
                "encrypted_backup_supported": True,
                "encrypted_import_export_supported": True,
                "doctor_repair_supported": True,
            }
        elif args.aegis_command == "stats":
            payload = {**base, "stats": store.entry_stats()}
        elif args.aegis_command == "list":
            entries = store.list_entries()
            payload = {
                **base,
                "dates": [e.entry_date for e in entries],
                "entries": [
                    {
                        "entry_date": e.entry_date,
                        "title": e.title,
                        "mood": e.mood,
                        "tags": e.normalized_tags(),
                        "created_at": e.created_at,
                        "updated_at": e.updated_at,
                    }
                    for e in entries
                ],
            }
        elif args.aegis_command == "read":
            entry = store.load(args.date)
            payload = {**base, "entry": entry.to_plain_json() if entry else None}
        elif args.aegis_command == "search":
            payload = {**base, "results": [e.to_plain_json() for e in store.search(args.query)]}
        elif args.aegis_command == "filter":
            payload = {
                **base,
                "results": [
                    e.to_plain_json()
                    for e in store.filter_entries(query=args.query or "", start_date=args.start or "", end_date=args.end or "", tag=args.tag or "", mood=args.mood or "")
                ],
            }
        else:
            payload = {"ok": False, "error": "Unknown AEGIS command"}
            print(json.dumps(payload, indent=2))
            return 2
        print(json.dumps(payload, indent=None if getattr(args, "compact", False) else 2, ensure_ascii=False))
        return 0
    except PermissionError as exc:
        print(json.dumps({"ok": False, "error": str(exc), "password_required": True, "schema_version": "aegis-diary-v1"}, indent=2))
        return 4

def cmd_stable_lock(args: argparse.Namespace) -> int:
    patch_network_off()
    paths = DiaryPaths()
    paths.ensure()
    settings = load_app_settings(paths)
    try:
        key_status = Keyring(paths).status()
    except Exception as exc:
        key_status = {"mode": "unknown", "password_enabled": None, "keyring_private": False, "error": str(exc)}
    fs_encrypted, fs_note = best_effort_fs_encryption_status(paths.entries)
    payload = {
        "ok": True,
        "app": APP_NAME,
        "version": VERSION,
        "program": 105,
        "release_channel": "stable",
        "stable_lock": True,
        "checked_at": utc_now_iso(),
        "date_format_default": DEFAULT_DATE_FORMAT,
        "date_format_current": settings.get("date_format", DEFAULT_DATE_FORMAT),
        "storage": {
            "app_level_encryption": "AES-256-GCM opaque object store",
            "entries": str(paths.entries),
            "objects": str(paths.objects),
            "manifest": str(paths.manifest),
            "filesystem_directory_encryption_detected": fs_encrypted,
            "filesystem_note": fs_note,
        },
        "keyring": key_status,
        "network": NETWORK_POLICY,
        "aegis_policy": aegis_policy_details(paths),
        "validated_phase_path": [
            "v0.6.0 import/export system",
            "v0.7.0 AEGIS Integration Lock",
            "v0.8.0 doctor/repair tools",
            "v0.8.1 DD/MM/YYYY date settings",
            "v0.8.5 UI polish pass",
            "v0.9.0 release candidate validation",
            "v1.0.0 stable lock",
            "v1.0.1 Ctrl+Q close hotkey patch",
        ],
    }
    if getattr(args, "json", False):
        print(json.dumps(payload, indent=2, ensure_ascii=False))
    else:
        print(f"{APP_NAME} v{VERSION} stable lock")
        print("Program: 105")
        print("Release channel: stable")
        print("Storage: AES-256-GCM opaque object store")
        print("Default date format: DD/MM/YYYY")
        print("AEGIS: local-only read-only contract preserved")
        print("Network: disabled / no cloud / no telemetry")
        print("Validated phase path:")
        for phase in payload["validated_phase_path"]:
            print(f"- {phase}")
    return 0

def cmd_doctor(args: argparse.Namespace) -> int:
    patch_network_off()
    paths = DiaryPaths()
    paths.ensure()
    paths.harden_permissions()
    key_status: Dict[str, Any]
    try:
        key_status = Keyring(paths).status()
    except Exception as exc:
        key_status = {"mode": "unknown", "password_enabled": None, "keyring_private": False, "error": str(exc)}
    store: Optional[DiaryStore] = None
    integrity: Dict[str, Any]
    supplied_password = getattr(args, "password", None)
    if key_status.get("password_enabled") and not supplied_password:
        integrity = {
            "ok": True,
            "locked": True,
            "password_required": True,
            "note": "Diary is password-locked; provide --password for decryptable entry checks.",
            "entry_count": "locked",
            "checks": [],
        }
    else:
        try:
            store = DiaryStore(paths, password=supplied_password)
            integrity = store.integrity_report()
        except PermissionError as exc:
            integrity = {
                "ok": True,
                "locked": True,
                "password_required": True,
                "note": str(exc),
                "entry_count": "locked",
                "checks": [],
            }
    fs_encrypted, fs_note = best_effort_fs_encryption_status(paths.entries)
    aegis_details = aegis_policy_details(paths)
    checks = []
    def add(name: str, ok: bool, note: str = "") -> None:
        checks.append({"name": name, "ok": bool(ok), "note": note})
    add("data directory", paths.data.exists(), str(paths.data))
    add("config directory", paths.config.exists(), str(paths.config))
    add("entries directory", paths.entries.exists(), str(paths.entries))
    add("opaque object store", paths.objects.exists(), str(paths.objects))
    add("encrypted manifest", paths.manifest.exists() or key_status.get("password_enabled") is True, str(paths.manifest))
    add("data directory private", is_private_dir(paths.data), "expected 0700")
    add("config directory private", is_private_dir(paths.config), "expected 0700")
    add("entries directory private", is_private_dir(paths.entries), "expected 0700")
    add("keyring exists", paths.keyring.exists(), str(paths.keyring))
    add("keyring private", bool(key_status.get("keyring_private")), "expected 0600")
    try:
        policy = read_json(paths.policy)
        add("network policy disabled", policy.get("network_allowed") is False, "local-only")
    except Exception as exc:
        add("network policy readable", False, str(exc))
    add("AEGIS local read-only policy", bool(aegis_details.get("ok")), "sentinel-diary-aegis")
    icon_paths = [Path("/usr/share/icons/hicolor/512x512/apps/sentinel-diary.png"), Path("/usr/share/pixmaps/sentinel-diary.png")]
    add("launcher icon installed", any(p.exists() for p in icon_paths), "warning only outside installed system")
    desktop_path = Path("/usr/share/applications/sentinel-diary.desktop")
    add("menu launcher installed", desktop_path.exists(), "warning only outside installed system")
    report = {
        "ok": all(item["ok"] for item in checks if item["name"] not in {"launcher icon installed", "menu launcher installed"}) and bool(integrity.get("ok", True)),
        "app": APP_NAME,
        "version": VERSION,
        "program": 105,
        "checked_at": utc_now_iso(),
        "checks": checks,
        "integrity": integrity,
        "keyring": key_status,
        "aegis_policy": aegis_details,
        "storage": {
            "app_level_encryption": "active AES-256-GCM object store",
            "objects": str(paths.objects),
            "manifest": str(paths.manifest),
            "filesystem_directory_encryption_detected": fs_encrypted,
            "filesystem_note": fs_note,
        },
        "network": NETWORK_POLICY,
        "repair_command": "sentinel-diary repair --reset-policy --reset-aegis-policy",
    }
    if getattr(args, "repair", False) and store is not None:
        repair = store.repair_storage(reset_policy=True, reset_aegis_policy=True, rebuild_manifest=True)
        report["repair"] = repair
        report["ok"] = bool(repair.get("ok"))
    if getattr(args, "json", False):
        print(json.dumps(report, indent=2, ensure_ascii=False))
    else:
        print(f"{APP_NAME} doctor v{VERSION}")
        for item in checks:
            print(f"[{'PASS' if item['ok'] else 'WARN'}] {item['name']}" + (f" — {item['note']}" if item.get('note') else ""))
        if integrity.get("locked"):
            print("Entries: locked/password required for decryptable entry count")
        else:
            print(f"Entries: {integrity.get('entry_count', 0)}")
        print("App-level storage encryption: active (AES-256-GCM object store)")
        print(f"Object store: {paths.objects}")
        print(f"Encrypted manifest: {paths.manifest}")
        print(f"Filesystem directory encryption detected: {fs_encrypted} ({fs_note})")
        print("Network: disabled/local-only")
        print("Repair: sentinel-diary repair --reset-policy --reset-aegis-policy")
    return 0 if report.get("ok") else 1

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=f"{APP_NAME} v{VERSION}")
    sub = parser.add_subparsers(dest="command")

    sub.add_parser("gui", help="Launch the desktop GUI")
    p = sub.add_parser("init", help="Initialize encrypted local diary storage")
    p.add_argument("--password", help="Password for password-protected keyrings")
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("status", help="Show local status")
    p.set_defaults(func=cmd_status)

    p = sub.add_parser("data-dir", help="Print diary data directory")
    p.set_defaults(func=cmd_data_dir)

    p = sub.add_parser("settings", help="Show Sentinel Diary settings")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_settings)

    p = sub.add_parser("set-date-format", help="Set display date format")
    p.add_argument("format", choices=list(DATE_FORMAT_OPTIONS.keys()))
    p.set_defaults(func=cmd_set_date_format)

    p = sub.add_parser("export-all", help="Export all entries as Markdown")
    p.add_argument("folder", nargs="?")
    p.add_argument("--password")
    p.set_defaults(func=cmd_export_all)

    p = sub.add_parser("backup", help="Create an encrypted Sentinel Diary backup")
    p.add_argument("folder", nargs="?", help="Backup folder; defaults to private diary backup directory")
    p.add_argument("--password", help="Current diary password if the diary is password-locked")
    p.add_argument("--backup-password", help="Optional separate password for the backup bundle")
    p.add_argument("--ask-backup-password", action="store_true", help="Prompt for a separate backup password")
    p.set_defaults(func=cmd_backup)

    p = sub.add_parser("restore", help="Restore entries from an encrypted Sentinel Diary backup")
    p.add_argument("backup_file")
    p.add_argument("--password", help="Current diary password if the diary is password-locked")
    p.add_argument("--backup-password", help="Backup password if the backup was separately protected")
    p.add_argument("--ask-backup-password", action="store_true", help="Prompt for the backup password")
    p.add_argument("--overwrite", action="store_true", help="Overwrite existing entries with matching dates")
    p.set_defaults(func=cmd_restore)

    p = sub.add_parser("export-encrypted", help="Export selected entries as an encrypted portable bundle")
    p.add_argument("folder", nargs="?", help="Export folder; defaults to private diary export directory")
    p.add_argument("--password", help="Current diary password if the diary is password-locked")
    p.add_argument("--export-password", help="Optional separate password for this export")
    p.add_argument("--backup-password", help="Alias for --export-password")
    p.add_argument("--ask-export-password", action="store_true", help="Prompt for a separate export password")
    p.add_argument("--ask-backup-password", action="store_true", help="Alias for --ask-export-password")
    p.add_argument("--date", action="append", help="Specific entry date to include; can be repeated")
    p.add_argument("--query", default="")
    p.add_argument("--start", default="")
    p.add_argument("--end", default="")
    p.add_argument("--tag", default="")
    p.add_argument("--mood", default="")
    p.set_defaults(func=cmd_export_encrypted)

    p = sub.add_parser("import-encrypted", help="Import an encrypted Sentinel Diary export or backup")
    p.add_argument("export_file")
    p.add_argument("--password", help="Current diary password if the diary is password-locked")
    p.add_argument("--export-password", help="Export password if separately protected")
    p.add_argument("--backup-password", help="Backup password alias")
    p.add_argument("--ask-export-password", action="store_true", help="Prompt for export password")
    p.add_argument("--ask-backup-password", action="store_true", help="Prompt for backup password alias")
    p.add_argument("--overwrite", action="store_true", help="Overwrite existing entries with matching dates")
    p.set_defaults(func=cmd_import_encrypted)

    p = sub.add_parser("import-markdown", help="Import a Markdown/text file as an encrypted diary entry")
    p.add_argument("markdown_file")
    p.add_argument("--date", help="Entry date YYYY-MM-DD; defaults to detected filename date or today")
    p.add_argument("--password", help="Current diary password if the diary is password-locked")
    p.add_argument("--overwrite", action="store_true", help="Overwrite existing entry with same date")
    p.set_defaults(func=cmd_import_markdown)

    p = sub.add_parser("integrity", help="Verify encrypted storage/keyring/manifest integrity")
    p.add_argument("--password", help="Current diary password if the diary is password-locked")
    p.add_argument("--compact", action="store_true", help="Emit compact JSON")
    p.set_defaults(func=cmd_integrity)

    p = sub.add_parser("repair", help="Repair permissions, policies, manifest, and optionally launchers")
    p.add_argument("--password", help="Current diary password if the diary is password-locked")
    p.add_argument("--reset-policy", action="store_true", help="Reset local-only network policy")
    p.add_argument("--reset-aegis-policy", action="store_true", help="Reset AEGIS read-only local policy")
    p.add_argument("--no-rebuild-manifest", action="store_true", help="Do not rebuild encrypted manifest")
    p.add_argument("--launchers", action="store_true", help="Run desktop/menu launcher repair helper when available")
    p.set_defaults(func=cmd_repair)

    p = sub.add_parser("stats", help="Show entry counts, first/last dates, tags, and moods")
    p.add_argument("--password")
    p.set_defaults(func=cmd_stats)

    p = sub.add_parser("filter", help="List entries matching date/tag/mood/text filters")
    p.add_argument("--query", default="")
    p.add_argument("--start", default="")
    p.add_argument("--end", default="")
    p.add_argument("--tag", default="")
    p.add_argument("--mood", default="")
    p.add_argument("--password")
    p.set_defaults(func=cmd_filter)

    p = sub.add_parser("set-password", help="Enable or change password lock")
    p.add_argument("--password", help="New password; avoid shell history when possible")
    p.add_argument("--current-password", help="Current password if already locked")
    p.set_defaults(func=cmd_set_password)

    p = sub.add_parser("disable-password", help="Disable password lock while retaining encryption")
    p.add_argument("--password", help="Current password")
    p.set_defaults(func=cmd_disable_password)

    p = sub.add_parser("aegis", help="AEGIS local read-only interface")
    p.add_argument("--password", help="Password for password-protected diaries")
    p.add_argument("--compact", action="store_true", help="Emit compact JSON")
    aegis_sub = p.add_subparsers(dest="aegis_command", required=True)
    aegis_sub.add_parser("status")
    aegis_sub.add_parser("permissions")
    aegis_sub.add_parser("validate-policy")
    aegis_sub.add_parser("stats")
    aegis_sub.add_parser("list")
    p_read = aegis_sub.add_parser("read")
    p_read.add_argument("date")
    p_search = aegis_sub.add_parser("search")
    p_search.add_argument("query")
    p_filter = aegis_sub.add_parser("filter")
    p_filter.add_argument("--query", default="")
    p_filter.add_argument("--start", default="")
    p_filter.add_argument("--end", default="")
    p_filter.add_argument("--tag", default="")
    p_filter.add_argument("--mood", default="")
    p.set_defaults(func=cmd_aegis)

    p = sub.add_parser("stable-lock", help="Show Sentinel Diary v1 stable lock report")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_stable_lock)

    p = sub.add_parser("doctor", help="Run diagnostics")
    p.add_argument("--password", help="Current diary password if the diary is password-locked")
    p.add_argument("--json", action="store_true", help="Emit machine-readable JSON report")
    p.add_argument("--repair", action="store_true", help="Run safe repair while diagnosing")
    p.set_defaults(func=cmd_doctor)
    return parser


def main(argv: Optional[List[str]] = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if not argv:
        try:
            DiaryGUI().run()
            return 0
        except Exception as exc:
            print(f"GUI failed: {exc}", file=sys.stderr)
            return 1
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.command == "gui":
        DiaryGUI().run()
        return 0
    if not hasattr(args, "func"):
        parser.print_help()
        return 2
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
