# Sentinel Diary Changelog

## v1.0.0 — Stable Lock

- Locked Program 105 Sentinel Diary as a stable Sentinel Desktop Suite baseline.
- Added stable-lock reporting: `sentinel-diary stable-lock` and `sentinel-diary stable-lock --json`.
- Added GUI Help menu with About, Keyboard Shortcuts, and Stable Lock Status.
- Added v1 stable badge in the Sentinel/AEGIS themed header.
- Finalized documentation for storage, encryption, AEGIS access, date formats, backup/restore, doctor/repair, and release status.
- Preserved the full validated phase path, including the v0.7.0 AEGIS Integration Lock.

## v0.9.0 — Release Candidate Validation

- Validated fresh storage initialization.
- Validated encrypted storage roundtrip.
- Validated password-enabled and password-required behavior.
- Validated encrypted backup/restore and encrypted import/export commands.
- Validated doctor, repair, integrity, settings, and AEGIS helper command paths.
- Validated launcher/menu packaging and package metadata.
- Confirmed no-network/no-cloud/no-telemetry design remains active.

## v0.8.5 — UI Polish Pass

- Added Help/About surface for user-facing release information.
- Added keyboard shortcut reference.
- Kept Sentinel/AEGIS dark-gold/cyan interface styling consistent.
- Preserved supplied Sentinel Diary icon, desktop launcher, and menu launcher behavior.

## v0.8.1 — Date Format Settings Patch

- Changed the default GUI display date format to `DD/MM/YYYY`.
- Added Settings → Date Format Settings.
- Added selectable display formats: `DD/MM/YYYY`, `YYYY-MM-DD`, and `MM/DD/YYYY`.
- Date entry, jump-to-date, duplicate-entry prompts, search results, and past-entry overview now render dates using the configured display format.
- Internal encrypted storage remains canonical `YYYY-MM-DD` for compatibility, migration safety, import/export, and AEGIS tooling.
- Added CLI settings helpers: `sentinel-diary settings` and `sentinel-diary set-date-format`.

## v0.8.0 — Doctor + Repair Tools

- Added `sentinel-diary integrity` JSON storage verification.
- Expanded `sentinel-diary doctor` with JSON mode and password-lock-safe diagnostics.
- Added `sentinel-diary repair` for permissions, local-only policy, AEGIS policy, encrypted manifest rebuild, and optional launcher repair.
- Doctor reports app-level encryption, object store, encrypted manifest, filesystem-encryption detection, network policy, and repair command.

## v0.7.0 — AEGIS Integration Lock

- Formalized the AEGIS helper contract as `aegis-diary-v1`.
- Added `permissions`, `validate-policy`, `stats`, and filtered AEGIS commands.
- AEGIS helper remains read-only, local-only, and network-disabled.
- Machine-readable JSON output includes policy, permission, capability, and keyring state metadata.
- Password-locked diaries report password-required status instead of bypassing user lock state.

## v0.6.0 — Import / Export System

- Added encrypted portable export bundles with `.sdexp.json` extension.
- Added selected export by date, query, tag, mood, and date range.
- Added encrypted import for `.sdexp.json` exports and `.sdbak.json` backups.
- Added Markdown/text import into encrypted diary entries.
- Kept plaintext Markdown export available with warning behavior.

## Preserved from earlier foundations

- AES-256-GCM encrypted opaque object storage.
- Encrypted manifest.
- Optional password lock via PBKDF2-HMAC-SHA256 wrapped master key.
- Encrypted backups and restore.
- Past Entries overview.
- Sentinel/AEGIS theme and supplied icon.
- Desktop/menu launcher creation and repair helper.
- No network, no cloud sync, no telemetry, no remote accounts.
