#!/usr/bin/env python3
"""
F.O.R.G.E — File Output & Release Generation Engine
SentinelOS Desktop Suite Program 120
v1.0.5 Bridge / USB / Final Audit Patch

Local-first SentinelOS builder/release workstation for archive extraction,
package building, ISO creation, USB ISO writing, and release generation.
"""
from __future__ import annotations

import argparse
import datetime as _dt
import hashlib
import json
import os
import re
import shutil
import shlex
import stat
import subprocess
import sys
import tarfile
import tempfile
import threading
import traceback
import zipfile
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

VERSION = "1.1.0"
PROGRAM_NUMBER = 120
APP_NAME = "F.O.R.G.E"
APP_LONG_NAME = "F.O.R.G.E — File Output & Release Generation Engine"
THEME_BG = "#080B0D"
THEME_PANEL = "#111820"
THEME_RAISED = "#18222B"
THEME_TREE = "#0B1014"
THEME_GOLD = "#E19B00"
THEME_CYAN = "#03C8FF"
THEME_TEXT = "#E7EDF2"
THEME_MUTED = "#A8B3BD"
THEME_DANGER = "#D36A4A"

HOME = Path.home()
DEFAULT_WORKSPACE = HOME / "FORGE_Workspace"
CONFIG_DIR = HOME / ".config" / "sentinel-forge"
DATA_DIR = HOME / ".local" / "share" / "sentinel-forge"
LOG_DIR = DATA_DIR / "logs"
LOG_FILE = LOG_DIR / "forge.log"
AUDIT_FILE = LOG_DIR / "audit.log"

ARCHIVE_EXTS = (".tar", ".tar.gz", ".tgz", ".tar.xz", ".txz", ".tar.bz2", ".tbz2", ".zip", ".deb")
TAR_EXTS = (".tar", ".tar.gz", ".tgz", ".tar.xz", ".txz", ".tar.bz2", ".tbz2")


def now_iso() -> str:
    return _dt.datetime.now().isoformat(timespec="seconds")


def ensure_dirs() -> None:
    for p in [CONFIG_DIR, DATA_DIR, LOG_DIR]:
        p.mkdir(parents=True, exist_ok=True)


def log(msg: str) -> None:
    ensure_dirs()
    with LOG_FILE.open("a", encoding="utf-8") as f:
        f.write(f"[{now_iso()}] {msg}\n")


def audit(action: str, target: str = "", status: str = "", details: Optional[dict] = None) -> None:
    ensure_dirs()
    record = {
        "timestamp": now_iso(),
        "program": PROGRAM_NUMBER,
        "app": APP_NAME,
        "version": VERSION,
        "action": action,
        "target": target,
        "status": status,
        "details": details or {},
    }
    with AUDIT_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")


def sanitize_id(name: str) -> str:
    s = (name or "").strip().lower()
    s = re.sub(r"[^a-z0-9.+-]+", "-", s)
    s = re.sub(r"-+", "-", s).strip("-")
    return s or "forge-output"


def human_size(n: int) -> str:
    units = ["B", "KiB", "MiB", "GiB", "TiB"]
    v = float(max(0, n))
    for u in units:
        if v < 1024 or u == units[-1]:
            return f"{int(v)} {u}" if u == "B" else f"{v:.1f} {u}"
        v /= 1024
    return f"{n} B"


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def run_cmd(cmd: List[str], cwd: Optional[Path] = None, timeout: int = 300) -> Tuple[int, str]:
    log("$ " + " ".join(str(x) for x in cmd))
    try:
        p = subprocess.run([str(x) for x in cmd], cwd=str(cwd) if cwd else None, capture_output=True, text=True, timeout=timeout)
        out = (p.stdout or "") + (p.stderr or "")
        return p.returncode, out
    except Exception as e:
        return 127, f"ERROR: {e}\n"


def default_workspace_tree(root: Path) -> List[Path]:
    return [
        root,
        root / "00_Inbox",
        root / "01_Projects",
        root / "02_Extracted",
        root / "02_Extracted" / "Quarantine",
        root / "02_Extracted" / "Verified",
        root / "03_Packages",
        root / "04_ISO_Staging",
        root / "05_Releases",
        root / "06_Manifests",
        root / "07_Logs",
        root / "08_Templates",
        root / "09_ISO_Output",
        root / "10_USB_Logs",
        root / "11_Encrypted",
        root / "11_Encrypted" / "Containers",
        root / "11_Encrypted" / "Files",
        root / "11_Encrypted" / "Folders",
        root / "11_Encrypted" / "Headers",
        root / "11_Encrypted" / "Keys",
        root / "11_Encrypted" / "Mounts",
    ]


def init_workspace(root: Path = DEFAULT_WORKSPACE) -> Dict[str, object]:
    root = root.expanduser().resolve()
    created = []
    for p in default_workspace_tree(root):
        if not p.exists(): created.append(str(p))
        p.mkdir(parents=True, exist_ok=True)
    readme = root / "README_FORGE_WORKSPACE.md"
    readme.write_text(
        "# F.O.R.G.E Workspace\n\n"
        "Local output workspace for SentinelOS F.O.R.G.E.\n\n"
        "- `00_Inbox`: incoming archives/projects\n"
        "- `01_Projects`: source project folders\n"
        "- `02_Extracted`: extracted archives\n"
        "- `03_Packages`: built `.deb` and `.tar.gz` packages\n"
        "- `04_ISO_Staging`: ISO staging trees\n"
        "- `05_Releases`: release folders\n"
        "- `06_Manifests`: manifests/checksums\n"
        "- `07_Logs`: workspace logs\n"
        "- `08_Templates`: package templates\n"
        "- `09_ISO_Output`: generated ISO images\n"
        "- `10_USB_Logs`: USB image write logs\n"
        "- `11_Encrypted`: encrypted files, folders, containers, headers, keys, and mountpoints\n",
        encoding="utf-8",
    )
    if str(readme) not in created: created.append(str(readme))
    audit("init-workspace", str(root), "ok", {"created": created})
    return {"workspace": str(root), "created": created, "status": "ok"}


@dataclass
class ArchiveCheckResult:
    archive: str
    ok: bool
    kind: str
    member_count: int
    total_size: int
    warnings: List[str]
    blocked: List[str]


def _is_relative_safe(name: str) -> bool:
    if not name:
        return False
    normalized = name.replace("\\", "/")
    if normalized.startswith("/"):
        return False
    parts = [p for p in normalized.split("/") if p not in ("", ".")]
    if any(p == ".." for p in parts):
        return False
    return True


def _safe_dest_join(dest: Path, member_name: str) -> bool:
    try:
        dest = dest.resolve()
        candidate = (dest / member_name.replace("\\", "/")).resolve()
        return str(candidate).startswith(str(dest) + os.sep) or candidate == dest
    except Exception:
        return False


def inspect_tar(path: Path, max_members: int = 20000, max_total_bytes: int = 2 * 1024 * 1024 * 1024) -> ArchiveCheckResult:
    warnings: List[str] = []
    blocked: List[str] = []
    total = 0
    count = 0
    try:
        with tarfile.open(path, "r:*") as tf:
            members = tf.getmembers()
            count = len(members)
            if count > max_members:
                blocked.append(f"Archive has too many members: {count} > {max_members}")
            for m in members:
                name = m.name
                if not _is_relative_safe(name): blocked.append(f"Unsafe path: {name}")
                if m.issym() or m.islnk():
                    target = m.linkname or ""
                    if not _is_relative_safe(target): blocked.append(f"Unsafe link target: {name} -> {target}")
                if m.isdev() or m.isfifo(): blocked.append(f"Blocked special file: {name}")
                if m.mode & stat.S_ISUID or m.mode & stat.S_ISGID: blocked.append(f"Blocked setuid/setgid bits: {name}")
                if m.isfile():
                    total += max(0, int(m.size))
                    if total > max_total_bytes:
                        blocked.append(f"Archive expands beyond guardrail: {human_size(total)}")
                        break
        return ArchiveCheckResult(str(path), not blocked, "tar", count, total, warnings, blocked)
    except Exception as e:
        return ArchiveCheckResult(str(path), False, "tar", count, total, warnings, [f"Cannot inspect tar: {e}"])


def inspect_zip(path: Path, max_members: int = 20000, max_total_bytes: int = 2 * 1024 * 1024 * 1024) -> ArchiveCheckResult:
    warnings: List[str] = []
    blocked: List[str] = []
    total = 0
    count = 0
    try:
        with zipfile.ZipFile(path, "r") as zf:
            infos = zf.infolist()
            count = len(infos)
            if count > max_members: blocked.append(f"Archive has too many members: {count} > {max_members}")
            for i in infos:
                name = i.filename
                if not _is_relative_safe(name): blocked.append(f"Unsafe path: {name}")
                total += max(0, int(i.file_size))
                if total > max_total_bytes:
                    blocked.append(f"Archive expands beyond guardrail: {human_size(total)}")
                    break
        return ArchiveCheckResult(str(path), not blocked, "zip", count, total, warnings, blocked)
    except Exception as e:
        return ArchiveCheckResult(str(path), False, "zip", count, total, warnings, [f"Cannot inspect zip: {e}"])


def inspect_archive(path: Path) -> ArchiveCheckResult:
    try:
        path = path.expanduser().resolve()
    except Exception:
        path = Path(str(path)).expanduser()
    if not path.exists():
        return ArchiveCheckResult(str(path), False, "unknown", 0, 0, [], ["Archive does not exist"])
    name = path.name.lower()
    if name.endswith(".zip"):
        return inspect_zip(path)
    if name.endswith(TAR_EXTS):
        return inspect_tar(path)
    if name.endswith(".deb"):
        rc, out = run_cmd(["dpkg-deb", "--field", str(path)], timeout=30)
        ok = rc == 0
        return ArchiveCheckResult(str(path), ok, "deb", 1, path.stat().st_size, [], [] if ok else [out.strip() or "Cannot inspect .deb"])
    return ArchiveCheckResult(str(path), False, "unknown", 0, path.stat().st_size, [], ["Unsupported archive type"])


def safe_extract_archive(path: Path, dest: Path) -> Dict[str, object]:
    path = path.expanduser().resolve()
    dest = dest.expanduser().resolve()
    check = inspect_archive(path)
    if not check.ok:
        audit("extract", str(path), "blocked", {"blocked": check.blocked})
        return {"status": "blocked", "check": asdict(check)}
    dest.mkdir(parents=True, exist_ok=True)
    try:
        if check.kind == "zip":
            with zipfile.ZipFile(path, "r") as zf:
                for info in zf.infolist():
                    if not _safe_dest_join(dest, info.filename):
                        return {"status": "blocked", "error": f"Unsafe extract path: {info.filename}", "check": asdict(check)}
                zf.extractall(dest)
        elif check.kind == "tar":
            with tarfile.open(path, "r:*") as tf:
                for m in tf.getmembers():
                    if not _safe_dest_join(dest, m.name):
                        return {"status": "blocked", "error": f"Unsafe extract path: {m.name}", "check": asdict(check)}
                try:
                    # Python 3.12+ supports filter='data'. Older versions ignore this path.
                    tf.extractall(dest, filter="data")
                except TypeError:
                    tf.extractall(dest)
        elif check.kind == "deb":
            rc, out = run_cmd(["dpkg-deb", "-x", str(path), str(dest)], timeout=180)
            if rc != 0:
                audit("extract", str(path), "error", {"output": out})
                return {"status": "error", "output": out, "check": asdict(check)}
        else:
            return {"status": "error", "error": "unsupported archive", "check": asdict(check)}
        audit("extract", str(path), "ok", {"destination": str(dest), "check": asdict(check)})
        return {"status": "ok", "archive": str(path), "destination": str(dest), "check": asdict(check)}
    except Exception as e:
        audit("extract", str(path), "error", {"error": str(e)})
        return {"status": "error", "error": str(e), "check": asdict(check)}


def walk_manifest(root: Path) -> List[Dict[str, object]]:
    root = root.expanduser().resolve()
    records: List[Dict[str, object]] = []
    for p in sorted(root.rglob("*")):
        if p.is_file():
            try:
                rel = str(p.relative_to(root))
                records.append({"path": rel, "size": p.stat().st_size, "sha256": sha256_file(p)})
            except Exception:
                continue
    return records


def generate_release_manifest(root: Path, out_dir: Optional[Path] = None) -> Dict[str, object]:
    root = root.expanduser().resolve()
    if not root.exists() or not root.is_dir():
        return {"status": "error", "error": "Folder does not exist", "folder": str(root)}
    out_dir = (out_dir or root).expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    records = walk_manifest(root)
    manifest = {
        "generated_at": now_iso(), "tool": APP_LONG_NAME, "program": PROGRAM_NUMBER,
        "root": str(root), "file_count": len(records), "files": records,
    }
    manifest_path = out_dir / "MANIFEST.json"
    sums_path = out_dir / "SHA256SUMS"
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    with sums_path.open("w", encoding="utf-8") as f:
        for r in records:
            f.write(f"{r['sha256']}  {r['path']}\n")
    audit("release-manifest", str(root), "ok", {"manifest": str(manifest_path), "sha256sums": str(sums_path), "file_count": len(records)})
    return {"status": "ok", "folder": str(root), "manifest": str(manifest_path), "sha256sums": str(sums_path), "file_count": len(records)}


def find_entrypoint(project: Path) -> Optional[str]:
    for name in ["run.py", "main.py", "app.py", "launcher.py", "start.sh", "install.sh"]:
        if (project / name).exists(): return name
    for p in project.iterdir():
        if p.is_file() and os.access(p, os.X_OK): return p.name
    for p in project.glob("*.py"): return p.name
    return None


def build_deb_from_project(project: Path, package_id: Optional[str] = None, version: str = "0.1", app_name: Optional[str] = None, command: Optional[str] = None, description: str = "Built by F.O.R.G.E", output_dir: Optional[Path] = None, create_desktop: bool = True, icon_path: Optional[Path] = None) -> Dict[str, object]:
    project = project.expanduser().resolve()
    if not project.exists() or not project.is_dir():
        return {"status": "error", "error": "Project folder does not exist", "project": str(project)}
    package_id = sanitize_id(package_id or project.name)
    app_name = app_name or package_id.replace("-", " ").title()
    command = sanitize_id(command or package_id)
    version = (version or "0.1").strip()
    output_dir = (output_dir or DEFAULT_WORKSPACE / "03_Packages").expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    entry = find_entrypoint(project)
    build_root = Path(tempfile.mkdtemp(prefix="forge-deb-"))
    try:
        pkg_root = build_root / f"{package_id}_{version}-1_all"
        debian = pkg_root / "DEBIAN"
        app_dir = pkg_root / "opt" / "sentinel-apps" / package_id
        bin_dir = pkg_root / "usr" / "bin"
        app_share = pkg_root / "usr" / "share" / "applications"
        icon_share = pkg_root / "usr" / "share" / "icons" / "hicolor" / "512x512" / "apps"
        for p in [debian, app_dir, bin_dir]: p.mkdir(parents=True, exist_ok=True)
        shutil.copytree(project, app_dir, dirs_exist_ok=True)
        for p in app_dir.rglob("*"):
            if p.is_file(): p.chmod(p.stat().st_mode & ~0o022)
        control = f"""Package: {package_id}
Version: {version}-1
Section: utils
Priority: optional
Architecture: all
Depends: python3
Maintainer: SentinelOS <root@localhost>
Description: {description}
 Built by F.O.R.G.E Program 120.
"""
        (debian / "control").write_text(control, encoding="utf-8")
        wrapper = bin_dir / command
        if entry:
            entry_path = f"/opt/sentinel-apps/{package_id}/{entry}"
            if entry.endswith(".py"):
                wrapper_text = f"#!/bin/sh\nexec python3 '{entry_path}' \"$@\"\n"
            elif entry.endswith(".sh"):
                wrapper_text = f"#!/bin/sh\nexec sh '{entry_path}' \"$@\"\n"
            else:
                wrapper_text = f"#!/bin/sh\nexec '{entry_path}' \"$@\"\n"
        else:
            wrapper_text = f"#!/bin/sh\necho '{app_name} installed at /opt/sentinel-apps/{package_id}'\n"
        wrapper.write_text(wrapper_text, encoding="utf-8")
        wrapper.chmod(0o755)
        if create_desktop:
            app_share.mkdir(parents=True, exist_ok=True)
            icon_name = package_id
            if icon_path and icon_path.expanduser().exists():
                icon_share.mkdir(parents=True, exist_ok=True)
                src = icon_path.expanduser().resolve()
                shutil.copy2(src, icon_share / f"{package_id}{src.suffix.lower() if src.suffix else '.png'}")
            desktop = f"""[Desktop Entry]
Type=Application
Name={app_name}
Comment={description}
Exec={command}
Icon={icon_name}
Terminal=false
Categories=Utility;System;
"""
            (app_share / f"{package_id}.desktop").write_text(desktop, encoding="utf-8")
        deb_path = output_dir / f"{package_id}_{version}-1_all.deb"
        rc, out = run_cmd(["dpkg-deb", "--build", str(pkg_root), str(deb_path)], timeout=180)
        status = "ok" if rc == 0 and deb_path.exists() else "error"
        audit("build-deb", str(project), status, {"package": str(deb_path), "output": out})
        return {"status": status, "project": str(project), "package_id": package_id, "version": version, "command": command, "entrypoint": entry, "deb": str(deb_path), "output": out}
    finally:
        shutil.rmtree(build_root, ignore_errors=True)


def build_tar_from_project(project: Path, package_id: Optional[str] = None, version: str = "0.1", output_dir: Optional[Path] = None) -> Dict[str, object]:
    project = project.expanduser().resolve()
    if not project.exists() or not project.is_dir():
        return {"status": "error", "error": "Project folder does not exist", "project": str(project)}
    package_id = sanitize_id(package_id or project.name)
    version = (version or "0.1").strip()
    output_dir = (output_dir or DEFAULT_WORKSPACE / "03_Packages").expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    out_path = output_dir / f"{package_id}_{version}.tar.gz"
    root_name = f"{package_id}-{version}"
    try:
        with tarfile.open(out_path, "w:gz") as tf:
            tf.add(project, arcname=root_name, filter=lambda ti: None if any(part in (".git", "__pycache__") for part in Path(ti.name).parts) else ti)
        audit("build-tar", str(project), "ok", {"tar": str(out_path)})
        return {"status": "ok", "project": str(project), "package_id": package_id, "version": version, "tar": str(out_path), "sha256": sha256_file(out_path)}
    except Exception as e:
        audit("build-tar", str(project), "error", {"error": str(e)})
        return {"status": "error", "error": str(e), "project": str(project)}


def create_iso_staging(name: str, root: Path = DEFAULT_WORKSPACE / "04_ISO_Staging") -> Dict[str, object]:
    sid = sanitize_id(name or "sentinelos-iso-staging")
    dest = root.expanduser().resolve() / sid
    folders = [dest, dest / "config", dest / "packages", dest / "overlays", dest / "boot", dest / "boot" / "grub", dest / "isolinux", dest / "docs", dest / "release"]
    for f in folders: f.mkdir(parents=True, exist_ok=True)
    summary = dest / "ISO_BUILD_PREP_SUMMARY.md"
    summary.write_text(
        f"# {sid} ISO Build Preparation Summary\n\n"
        "Basic workflow:\n"
        "- Place the live filesystem or installer tree inside this staging folder.\n"
        "- Place bootloader files under `boot/`, `boot/grub/`, or `isolinux/`.\n"
        "- Place custom packages under `packages/`.\n"
        "- Place filesystem overlays under `overlays/`.\n"
        "- Use F.O.R.G.E → ISO Builder → Build ISO to create the `.iso`.\n"
        "- Bootable ISO support depends on valid boot assets being present.\n"
        "- Non-bootable data ISO creation is available when boot assets are absent.\n",
        encoding="utf-8",
    )
    audit("create-iso-staging", str(dest), "ok")
    return {"status": "ok", "staging": str(dest), "summary": str(summary)}


def iso_tool() -> Optional[str]:
    return shutil.which("xorriso") or shutil.which("genisoimage") or shutil.which("mkisofs")


def build_iso_from_staging(staging: Path, output_iso: Optional[Path] = None, label: str = "SENTINELOS", bootable: bool = True) -> Dict[str, object]:
    staging = staging.expanduser().resolve()
    if not staging.exists() or not staging.is_dir():
        return {"status": "error", "error": "Staging folder does not exist", "staging": str(staging)}
    tool = iso_tool()
    if not tool:
        return {"status": "error", "error": "No ISO builder found. Install xorriso, genisoimage, or mkisofs.", "staging": str(staging)}
    output_dir = DEFAULT_WORKSPACE / "09_ISO_Output"
    output_dir.mkdir(parents=True, exist_ok=True)
    output_iso = (output_iso or output_dir / f"{sanitize_id(staging.name)}.iso").expanduser().resolve()
    label = sanitize_id(label).upper().replace("-", "_")[:32] or "SENTINELOS"
    if Path(tool).name == "xorriso":
        cmd = [tool, "-as", "mkisofs", "-r", "-J", "-V", label, "-o", str(output_iso)]
    else:
        cmd = [tool, "-r", "-J", "-V", label, "-o", str(output_iso)]
    isolinux = staging / "isolinux" / "isolinux.bin"
    if bootable and isolinux.exists():
        cmd.extend(["-b", "isolinux/isolinux.bin", "-c", "isolinux/boot.cat", "-no-emul-boot", "-boot-load-size", "4", "-boot-info-table"])
    efi_img = staging / "boot" / "grub" / "efi.img"
    if bootable and efi_img.exists():
        cmd.extend(["-eltorito-alt-boot", "-e", "boot/grub/efi.img", "-no-emul-boot"])
    cmd.append(str(staging))
    rc, out = run_cmd(cmd, timeout=900)
    status = "ok" if rc == 0 and output_iso.exists() else "error"
    res = {"status": status, "staging": str(staging), "iso": str(output_iso), "tool": tool, "command": cmd, "output": out}
    if status == "ok":
        res["sha256"] = sha256_file(output_iso)
    audit("build-iso", str(staging), status, res)
    return res


def list_usb_devices() -> Dict[str, object]:
    if not shutil.which("lsblk"):
        return {"status": "error", "error": "lsblk not found", "devices": []}
    rc, out = run_cmd(["lsblk", "-J", "-o", "NAME,PATH,SIZE,MODEL,TRAN,TYPE,MOUNTPOINTS,RM"], timeout=30)
    devices: List[Dict[str, object]] = []
    if rc == 0:
        try:
            data = json.loads(out)
            for d in data.get("blockdevices", []):
                if d.get("type") == "disk":
                    devices.append({k: d.get(k) for k in ["name", "path", "size", "model", "tran", "type", "mountpoints", "rm"]})
        except Exception as e:
            return {"status": "error", "error": str(e), "raw": out, "devices": []}
    return {"status": "ok" if rc == 0 else "error", "devices": devices, "raw": out if rc != 0 else ""}


def write_iso_to_usb(iso: Path, device: str, confirm: str = "", dry_run: bool = False) -> Dict[str, object]:
    iso = iso.expanduser().resolve()
    if not iso.exists() or not iso.is_file() or iso.suffix.lower() != ".iso":
        return {"status": "error", "error": "ISO file does not exist or is not .iso", "iso": str(iso)}
    if not re.fullmatch(r"/dev/(sd[a-z]|vd[a-z]|xvd[a-z]|nvme\d+n\d+|mmcblk\d+)", device.strip()):
        return {"status": "error", "error": "Refusing unsafe/non-disk device path", "device": device}
    if confirm != "ERASE":
        return {"status": "blocked", "error": "Confirmation word ERASE required", "device": device}
    cmd = ["dd", f"if={iso}", f"of={device}", "bs=4M", "status=progress", "oflag=sync"]
    if os.geteuid() != 0:
        pkexec = shutil.which("pkexec")
        sudo = shutil.which("sudo")
        if pkexec:
            cmd = [pkexec] + cmd
        elif sudo:
            cmd = [sudo] + cmd
        else:
            return {"status": "error", "error": "Root privileges required. Install pkexec/sudo or run as root.", "command": cmd}
    if dry_run:
        return {"status": "dry-run", "command": cmd, "iso": str(iso), "device": device}
    rc, out = run_cmd(cmd, timeout=7200)
    sync_rc, sync_out = run_cmd(["sync"], timeout=120)
    status = "ok" if rc == 0 else "error"
    res = {"status": status, "command": cmd, "output": out + sync_out, "iso": str(iso), "device": device}
    audit("write-usb", device, status, {"iso": str(iso), "rc": rc})
    return res


def diagnostics() -> Dict[str, object]:
    tools = {tool: shutil.which(tool) is not None for tool in ["dpkg-deb", "apt-cache", "tar", "unzip", "zip", "sha256sum", "python3", "xorriso", "genisoimage", "mkisofs", "lsblk", "dd", "pkexec", "sudo"]}
    return {"program": PROGRAM_NUMBER, "app": APP_NAME, "version": VERSION, "workspace_exists": DEFAULT_WORKSPACE.exists(), "workspace": str(DEFAULT_WORKSPACE), "tools": tools, "logs": str(LOG_DIR), "status": "ok" if tools.get("dpkg-deb") and tools.get("tar") else "warning"}


def forge_status() -> Dict[str, object]:
    return {"program": PROGRAM_NUMBER, "app": APP_NAME, "name": APP_LONG_NAME, "version": VERSION, "aegis_compatible": True, "manual_first": True, "ai_required": False, "local_only_default": True, "internet_required": False, "workspace": str(DEFAULT_WORKSPACE), "diagnostics": diagnostics()}


def forge_actions() -> Dict[str, object]:
    return {"actions": [
        {"name": "init-workspace", "risk": "low", "network": False},
        {"name": "inspect-archive", "risk": "low", "network": False},
        {"name": "extract", "risk": "medium", "network": False},
        {"name": "build-deb", "risk": "medium", "network": False},
        {"name": "build-tar", "risk": "low", "network": False},
        {"name": "create-iso-staging", "risk": "low", "network": False},
        {"name": "build-iso", "risk": "medium", "network": False},
        {"name": "list-usb-devices", "risk": "low", "network": False},
        {"name": "write-usb", "risk": "critical", "network": False},
        {"name": "release-manifest", "risk": "low", "network": False},
    ]}


# ------------------------- GUI -------------------------
class ForgeGUI:
    def __init__(self) -> None:
        import tkinter as tk
        from tkinter import ttk
        self.tk = tk
        self.ttk = ttk
        self.root = tk.Tk()
        self.root.title(f"{APP_LONG_NAME} v{VERSION}")
        self.root.geometry("1240x860")
        self.root.minsize(1080, 740)
        self.dnd_available = False
        self.active_key = "dashboard"
        self.output_widgets: Dict[str, object] = {}
        self._configure_theme()
        self._build_gui()
        self._install_clipboard_support()
        self.root.bind("<Control-q>", lambda e: self.root.destroy())
        self.root.bind("<Control-r>", lambda e: self.refresh_dashboard())
        self.root.bind("<F1>", lambda e: self.show_tab("manual"))
        self.refresh_dashboard()

    def _configure_theme(self) -> None:
        ttk = self.ttk
        self.root.configure(bg=THEME_BG)
        try:
            self.root.tk_setPalette(background=THEME_BG, foreground=THEME_TEXT, activeBackground=THEME_RAISED, activeForeground=THEME_GOLD, highlightColor=THEME_GOLD, selectBackground="#263541", selectForeground=THEME_GOLD)
        except Exception: pass
        style = ttk.Style()
        try: style.theme_use("clam")
        except Exception: pass
        style.configure("TFrame", background=THEME_BG)
        style.configure("Panel.TFrame", background=THEME_PANEL)
        style.configure("TLabel", background=THEME_BG, foreground=THEME_TEXT)
        style.configure("Muted.TLabel", background=THEME_BG, foreground=THEME_MUTED)
        style.configure("Gold.TLabel", background=THEME_BG, foreground=THEME_GOLD, font=("Sans", 11, "bold"))
        style.configure("Title.TLabel", background=THEME_BG, foreground=THEME_GOLD, font=("Sans", 18, "bold"))
        style.configure("TButton", background=THEME_RAISED, foreground=THEME_TEXT, borderwidth=1, focusthickness=2, focuscolor=THEME_GOLD, padding=(8, 5))
        style.map("TButton", foreground=[("active", THEME_GOLD), ("pressed", THEME_GOLD)], background=[("active", "#1F2C36"), ("pressed", "#263541")])
        style.configure("Treeview", background=THEME_TREE, foreground=THEME_TEXT, fieldbackground=THEME_TREE, rowheight=26, borderwidth=0)
        style.map("Treeview", background=[("selected", "#263541")], foreground=[("selected", THEME_GOLD)])
        style.configure("Treeview.Heading", background=THEME_RAISED, foreground=THEME_GOLD, font=("Sans", 10, "bold"))
        style.configure("TEntry", fieldbackground=THEME_TREE, foreground=THEME_TEXT, insertcolor=THEME_GOLD)
        style.configure("TCombobox", fieldbackground=THEME_TREE, background=THEME_TREE, foreground=THEME_TEXT, arrowcolor=THEME_GOLD)
        # v1.0.2: complete theme coverage for the Encryption tab and other ttk controls.
        style.configure("TLabelframe", background=THEME_BG, foreground=THEME_GOLD, bordercolor=THEME_RAISED, relief="solid")
        style.configure("TLabelframe.Label", background=THEME_BG, foreground=THEME_GOLD, font=("Sans", 10, "bold"))
        style.configure("TCheckbutton", background=THEME_BG, foreground=THEME_TEXT, focuscolor=THEME_GOLD)
        style.map("TCheckbutton", foreground=[("active", THEME_GOLD), ("selected", THEME_GOLD)], background=[("active", THEME_BG)])
        style.configure("Vertical.TScrollbar", background=THEME_RAISED, troughcolor=THEME_BG, arrowcolor=THEME_GOLD, bordercolor=THEME_BG)
        style.configure("Danger.TButton", background=THEME_RAISED, foreground=THEME_DANGER, borderwidth=1, focusthickness=2, focuscolor=THEME_DANGER, padding=(8, 5))
        style.map("Danger.TButton", foreground=[("active", THEME_GOLD), ("pressed", THEME_GOLD)], background=[("active", "#2A1B17"), ("pressed", "#34211B")])

    def _build_gui(self) -> None:
        tk, ttk = self.tk, self.ttk
        self.main = ttk.Frame(self.root); self.main.pack(fill="both", expand=True)
        header = ttk.Frame(self.main, style="Panel.TFrame"); header.pack(fill="x", padx=10, pady=(10, 6))
        self.logo_img = None; self.logo_full_img = None
        for icon in [Path(__file__).parent / "assets" / "sentinel-forge.png", Path("/usr/share/icons/hicolor/512x512/apps/sentinel-forge.png")]:
            if icon.exists():
                try:
                    self.logo_full_img = tk.PhotoImage(file=str(icon)); self.root.iconphoto(True, self.logo_full_img)
                    self.logo_img = self.logo_full_img.subsample(9, 9)
                    ttk.Label(header, image=self.logo_img, background=THEME_PANEL).pack(side="left", padx=(12, 10), pady=8)
                    break
                except Exception: pass
        title_box = ttk.Frame(header, style="Panel.TFrame"); title_box.pack(side="left", fill="x", expand=True, pady=8)
        ttk.Label(title_box, text="F.O.R.G.E", style="Title.TLabel", background=THEME_PANEL).pack(anchor="w")
        ttk.Label(title_box, text="File Output & Release Generation Engine — Program 120", foreground=THEME_MUTED, background=THEME_PANEL).pack(anchor="w")
        body = ttk.Frame(self.main); body.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        self.side = ttk.Frame(body, style="Panel.TFrame"); self.side.pack(side="left", fill="y", padx=(0, 8))
        self.content = ttk.Frame(body); self.content.pack(side="left", fill="both", expand=True)
        self.nav_buttons: Dict[str, tk.Button] = {}
        nav = [("dashboard", "Dashboard"), ("extractor", "Extractor"), ("package", "Package Builder"), ("iso", "ISO Builder"), ("usb", "USB ISO Creator"), ("crypto", "Encryption"), ("release", "Release Generator"), ("manual", "Manual")]
        for key, label in nav:
            b = tk.Button(self.side, text=label, anchor="w", width=22, bg=THEME_RAISED, fg=THEME_TEXT, activebackground="#263541", activeforeground=THEME_GOLD, relief="flat", command=lambda k=key: self.show_tab(k))
            b.pack(fill="x", padx=8, pady=4); self.nav_buttons[key] = b
        ttk.Button(self.side, text="Init Workspace", command=self.gui_init_workspace).pack(fill="x", padx=8, pady=(20, 4))
        ttk.Button(self.side, text="Open Logs", command=lambda: self.open_path(LOG_DIR)).pack(fill="x", padx=8, pady=4)
        self.tabs: Dict[str, ttk.Frame] = {}
        for key in ["dashboard", "extractor", "package", "iso", "usb", "crypto", "release", "manual"]:
            f = ttk.Frame(self.content); self.tabs[key] = f
        self._build_dashboard(self.tabs["dashboard"])
        self._build_extractor(self.tabs["extractor"])
        self._build_package(self.tabs["package"])
        self._build_iso(self.tabs["iso"])
        self._build_usb(self.tabs["usb"])
        self._build_crypto(self.tabs["crypto"])
        self._build_release(self.tabs["release"])
        self._build_manual(self.tabs["manual"])
        self.show_tab("dashboard")

    def show_tab(self, key: str) -> None:
        self.active_key = key
        for f in self.tabs.values(): f.pack_forget()
        self.tabs[key].pack(fill="both", expand=True)
        for k, b in self.nav_buttons.items():
            b.configure(bg="#263541" if k == key else THEME_RAISED, fg=THEME_GOLD if k == key else THEME_TEXT)

    def _section(self, parent, title: str, subtitle: str = ""):
        self.ttk.Label(parent, text=title, style="Title.TLabel").pack(anchor="w", pady=(0, 2))
        if subtitle: self.ttk.Label(parent, text=subtitle, style="Muted.TLabel", wraplength=900).pack(anchor="w", pady=(0, 10))

    def _add_output(self, parent, key: str, height: int = 13):
        txt = self.tk.Text(parent, height=height, bg=THEME_TREE, fg=THEME_TEXT, insertbackground=THEME_GOLD, relief="flat", wrap="word")
        txt.pack(fill="both", expand=True, pady=(8, 0))
        txt.configure(state="disabled")
        self.output_widgets[key] = txt
        return txt

    def log_output(self, text: str, key: Optional[str] = None) -> None:
        log(text)
        target_key = key or self.active_key
        for k in [target_key, "dashboard"]:
            txt = self.output_widgets.get(k)
            if txt:
                try:
                    txt.configure(state="normal"); txt.insert("end", text.rstrip() + "\n"); txt.see("end"); txt.configure(state="disabled")
                except Exception: pass


    # ------------------------- Clipboard / selection support -------------------------
    def _install_clipboard_support(self) -> None:
        """Make copy/paste/select-all predictable across all GUI fields, output panes, and tables."""
        tk = self.tk
        self.clipboard_menu = tk.Menu(self.root, tearoff=0, bg=THEME_RAISED, fg=THEME_TEXT, activebackground="#263541", activeforeground=THEME_GOLD)
        self.clipboard_menu.add_command(label="Cut", command=self._clipboard_cut)
        self.clipboard_menu.add_command(label="Copy", command=self._clipboard_copy)
        self.clipboard_menu.add_command(label="Paste", command=self._clipboard_paste)
        self.clipboard_menu.add_separator()
        self.clipboard_menu.add_command(label="Select All", command=self._clipboard_select_all)
        for sequence, func in [
            ("<Control-a>", self._clipboard_select_all),
            ("<Control-A>", self._clipboard_select_all),
            ("<Control-c>", self._clipboard_copy),
            ("<Control-C>", self._clipboard_copy),
            ("<Control-v>", self._clipboard_paste),
            ("<Control-V>", self._clipboard_paste),
            ("<Control-x>", self._clipboard_cut),
            ("<Control-X>", self._clipboard_cut),
        ]:
            self.root.bind_all(sequence, lambda e, f=func: f(event=e), add="+")
        self.root.bind_all("<Button-3>", self._show_clipboard_menu, add="+")

    def _focus_widget(self):
        try:
            return self.root.focus_get()
        except Exception:
            return None

    def _is_editable_text_widget(self, widget) -> bool:
        return isinstance(widget, (self.tk.Entry, self.tk.Text)) or widget.winfo_class() in {"TEntry", "Entry", "Text", "TCombobox", "Combobox"}

    def _is_tree_widget(self, widget) -> bool:
        try:
            return isinstance(widget, self.ttk.Treeview) or widget.winfo_class() == "Treeview"
        except Exception:
            return False

    def _clipboard_select_all(self, event=None):
        widget = getattr(event, "widget", None) or self._focus_widget()
        if widget is None:
            return None
        try:
            if self._is_tree_widget(widget):
                widget.selection_set(widget.get_children(""))
                return "break"
            if isinstance(widget, self.tk.Text) or widget.winfo_class() == "Text":
                old_state = str(widget.cget("state"))
                if old_state == "disabled": widget.configure(state="normal")
                widget.tag_add("sel", "1.0", "end-1c")
                if old_state == "disabled": widget.configure(state="disabled")
                return "break"
            if self._is_editable_text_widget(widget):
                try: widget.selection_range(0, "end")
                except Exception: widget.event_generate("<<SelectAll>>")
                return "break"
        except Exception:
            return None
        return None

    def _copy_tree_selection(self, tree) -> str:
        try:
            cols = list(tree["columns"])
            headers = [tree.heading(c).get("text", c) for c in cols]
            lines = ["\t".join(headers)]
            for item in tree.selection() or tree.get_children(""):
                vals = [str(v) for v in tree.item(item, "values")]
                if vals:
                    lines.append("\t".join(vals))
            return "\n".join(lines)
        except Exception:
            return ""

    def _clipboard_copy(self, event=None):
        widget = getattr(event, "widget", None) or self._focus_widget()
        if widget is None:
            return None
        try:
            if self._is_tree_widget(widget):
                text = self._copy_tree_selection(widget)
                if text:
                    self.root.clipboard_clear(); self.root.clipboard_append(text)
                    return "break"
            widget.event_generate("<<Copy>>")
            return "break"
        except Exception:
            return None

    def _clipboard_paste(self, event=None):
        widget = getattr(event, "widget", None) or self._focus_widget()
        if widget is None or self._is_tree_widget(widget):
            return None
        try:
            if self._is_editable_text_widget(widget):
                widget.event_generate("<<Paste>>")
                return "break"
        except Exception:
            return None
        return None

    def _clipboard_cut(self, event=None):
        widget = getattr(event, "widget", None) or self._focus_widget()
        if widget is None or self._is_tree_widget(widget):
            return None
        try:
            if self._is_editable_text_widget(widget):
                widget.event_generate("<<Cut>>")
                return "break"
        except Exception:
            return None
        return None

    def _show_clipboard_menu(self, event):
        widget = getattr(event, "widget", None)
        if widget is None:
            return None
        try:
            if not (self._is_editable_text_widget(widget) or self._is_tree_widget(widget)):
                return None
            widget.focus_set()
            # Disable destructive edit actions for read-only output panes and tables.
            is_tree = self._is_tree_widget(widget)
            is_disabled_text = False
            try: is_disabled_text = isinstance(widget, self.tk.Text) and str(widget.cget("state")) == "disabled"
            except Exception: pass
            self.clipboard_menu.entryconfigure("Cut", state="disabled" if is_tree or is_disabled_text else "normal")
            self.clipboard_menu.entryconfigure("Paste", state="disabled" if is_tree or is_disabled_text else "normal")
            self.clipboard_menu.tk_popup(event.x_root, event.y_root)
            return "break"
        finally:
            try: self.clipboard_menu.grab_release()
            except Exception: pass

    def _build_dashboard(self, parent) -> None:
        self._section(parent, "Dashboard", "Local builder/release workstation for SentinelOS packages, ISO images, USB installers, and release artifacts.")
        actions = self.ttk.Frame(parent); actions.pack(fill="x", pady=6)
        self.ttk.Button(actions, text="Initialize Workspace", command=self.gui_init_workspace).pack(side="left", padx=(0, 6))
        self.ttk.Button(actions, text="Run Diagnostics", command=self.gui_diagnostics).pack(side="left", padx=6)
        self.ttk.Button(actions, text="Open Workspace", command=lambda: self.open_path(DEFAULT_WORKSPACE)).pack(side="left", padx=6)
        cols = ("path", "status")
        self.dash_tree = self.ttk.Treeview(parent, columns=cols, show="headings", height=9)
        self.dash_tree.heading("path", text="Workspace Path"); self.dash_tree.heading("status", text="Status")
        self.dash_tree.column("path", width=650); self.dash_tree.column("status", width=160)
        self.dash_tree.pack(fill="x", pady=8)
        self._add_output(parent, "dashboard", 14)

    def refresh_dashboard(self) -> None:
        try:
            self.dash_tree.delete(*self.dash_tree.get_children())
            for p in default_workspace_tree(DEFAULT_WORKSPACE): self.dash_tree.insert("", "end", values=(str(p), "OK" if p.exists() else "Missing"))
        except Exception: pass

    def _build_extractor(self, parent) -> None:
        tk, ttk = self.tk, self.ttk
        self._section(parent, "Extractor", "Inspect and extract .zip, .tar.*, and .deb archives. Use Choose, paste/type path, or best-effort drag/drop when your desktop provides TkDND.")
        form = ttk.Frame(parent); form.pack(fill="x", pady=6)
        ttk.Label(form, text="Archive:").grid(row=0, column=0, sticky="w", padx=(0,6), pady=4)
        self.archive_var = tk.StringVar(); e = ttk.Entry(form, textvariable=self.archive_var)
        e.grid(row=0, column=1, sticky="ew", pady=4); e.bind("<Return>", lambda _e: self.gui_inspect_archive())
        self._try_register_drop(e, self.archive_var, self.gui_inspect_archive)
        ttk.Button(form, text="Choose", command=self.choose_archive).grid(row=0, column=2, padx=6)
        ttk.Button(form, text="Paste Path", command=lambda: self.paste_to(self.archive_var, self.gui_inspect_archive)).grid(row=0, column=3, padx=6)
        ttk.Label(form, text="Destination:").grid(row=1, column=0, sticky="w", padx=(0,6), pady=4)
        self.extract_dest_var = tk.StringVar(value=str(DEFAULT_WORKSPACE / "02_Extracted"))
        ttk.Entry(form, textvariable=self.extract_dest_var).grid(row=1, column=1, sticky="ew", pady=4)
        ttk.Button(form, text="Choose", command=lambda: self.choose_dir(self.extract_dest_var)).grid(row=1, column=2, padx=6)
        form.columnconfigure(1, weight=1)
        btns = ttk.Frame(parent); btns.pack(fill="x", pady=6)
        ttk.Button(btns, text="Inspect Archive", command=self.gui_inspect_archive).pack(side="left", padx=(0,6))
        ttk.Button(btns, text="Extract", command=self.gui_extract_archive).pack(side="left", padx=6)
        self._add_output(parent, "extractor", 18)

    def choose_archive(self) -> None:
        from tkinter import filedialog
        p = filedialog.askopenfilename(title="Choose archive", filetypes=[("Supported archives", "*.zip *.tar *.tar.gz *.tgz *.tar.xz *.txz *.tar.bz2 *.tbz2 *.deb"), ("All files", "*")])
        if p: self.archive_var.set(p); self.gui_inspect_archive()

    def choose_dir(self, var) -> None:
        from tkinter import filedialog
        p = filedialog.askdirectory(title="Choose folder")
        if p: var.set(p)

    def paste_to(self, var, callback=None) -> None:
        try:
            var.set(self.root.clipboard_get().strip())
            if callback: callback()
        except Exception as e:
            self.log_output(f"Paste failed: {e}")

    def _try_register_drop(self, widget, var, callback=None) -> None:
        # Best-effort TkDND/tkinterdnd support. If unavailable, Choose/Paste/Enter remain supported.
        try:
            import tkinterdnd2  # type: ignore
            # Only works when the root is created by TkinterDnD.Tk. Standard Tk roots cannot be converted reliably.
        except Exception:
            return
        try:
            widget.drop_target_register('DND_Files')
            def on_drop(event):
                data = getattr(event, 'data', '').strip().strip('{}')
                if data:
                    var.set(data.split()[0])
                    if callback: callback()
            widget.dnd_bind('<<Drop>>', on_drop)
            self.dnd_available = True
        except Exception:
            pass

    def gui_inspect_archive(self) -> None:
        p = Path(self.archive_var.get().strip()).expanduser()
        res = inspect_archive(p)
        self.log_output("=== Archive Inspection ===\n" + json.dumps(asdict(res), indent=2), "extractor")

    def gui_extract_archive(self) -> None:
        p = Path(self.archive_var.get().strip()).expanduser(); d = Path(self.extract_dest_var.get().strip()).expanduser()
        def worker():
            res = safe_extract_archive(p, d)
            self.root.after(0, lambda: self.log_output("=== Extract Result ===\n" + json.dumps(res, indent=2), "extractor"))
        threading.Thread(target=worker, daemon=True).start()

    def _build_package(self, parent) -> None:
        tk, ttk = self.tk, self.ttk
        self._section(parent, "Package Builder", "Build .deb wrappers and .tar.gz release bundles from local project folders. This module belongs in F.O.R.G.E, not Sentinel Program Manager.")
        form = ttk.Frame(parent); form.pack(fill="x", pady=6)
        self.project_var = tk.StringVar(); self.pkg_id_var = tk.StringVar(); self.pkg_name_var = tk.StringVar(); self.pkg_version_var = tk.StringVar(value="0.1"); self.pkg_cmd_var = tk.StringVar(); self.pkg_desc_var = tk.StringVar(value="SentinelOS application built by F.O.R.G.E")
        labels = ["Project Folder:", "Package ID:", "Application Name:", "Version:", "Command:", "Description:"]
        vars_ = [self.project_var, self.pkg_id_var, self.pkg_name_var, self.pkg_version_var, self.pkg_cmd_var, self.pkg_desc_var]
        for i,(lab,var) in enumerate(zip(labels, vars_)):
            ttk.Label(form, text=lab).grid(row=i, column=0, sticky="w", pady=3, padx=(0,6))
            ent = ttk.Entry(form, textvariable=var); ent.grid(row=i, column=1, sticky="ew", pady=3)
            if i == 0:
                self._try_register_drop(ent, self.project_var)
                ttk.Button(form, text="Choose", command=lambda: self.choose_dir(self.project_var)).grid(row=i, column=2, padx=6)
                ttk.Button(form, text="Paste", command=lambda: self.paste_to(self.project_var)).grid(row=i, column=3, padx=6)
        form.columnconfigure(1, weight=1)
        btns = ttk.Frame(parent); btns.pack(fill="x", pady=6)
        ttk.Button(btns, text="Build .deb", command=self.gui_build_deb).pack(side="left", padx=(0,8))
        ttk.Button(btns, text="Build .tar.gz", command=self.gui_build_tar).pack(side="left", padx=8)
        ttk.Button(btns, text="Open Packages", command=lambda: self.open_path(DEFAULT_WORKSPACE / "03_Packages")).pack(side="left", padx=8)
        self._add_output(parent, "package", 14)

    def gui_build_deb(self) -> None:
        project = Path(self.project_var.get().strip()).expanduser(); package_id = self.pkg_id_var.get().strip() or None; app_name = self.pkg_name_var.get().strip() or None; version = self.pkg_version_var.get().strip() or "0.1"; command = self.pkg_cmd_var.get().strip() or None; desc = self.pkg_desc_var.get().strip() or "Built by F.O.R.G.E"
        def worker():
            res = build_deb_from_project(project, package_id, version, app_name, command, desc)
            self.root.after(0, lambda: self.log_output("=== .deb Build Result ===\n" + json.dumps(res, indent=2), "package"))
        threading.Thread(target=worker, daemon=True).start()

    def gui_build_tar(self) -> None:
        project = Path(self.project_var.get().strip()).expanduser(); package_id = self.pkg_id_var.get().strip() or None; version = self.pkg_version_var.get().strip() or "0.1"
        def worker():
            res = build_tar_from_project(project, package_id, version)
            self.root.after(0, lambda: self.log_output("=== .tar.gz Build Result ===\n" + json.dumps(res, indent=2), "package"))
        threading.Thread(target=worker, daemon=True).start()

    def _build_iso(self, parent) -> None:
        tk, ttk = self.tk, self.ttk
        self._section(parent, "ISO Builder", "Create ISO staging trees and build ISO images using xorriso/genisoimage/mkisofs when available.")
        summary = "Preparation summary:\n• Create or select a staging tree.\n• Place live/installer files in the staging folder.\n• Add boot assets under isolinux/ or boot/grub/ for bootable output.\n• Build ISO. Without boot assets, F.O.R.G.E creates a data ISO."
        ttk.Label(parent, text=summary, style="Muted.TLabel", wraplength=900).pack(anchor="w", pady=(0,8))
        form = ttk.Frame(parent); form.pack(fill="x", pady=6)
        self.iso_name_var = tk.StringVar(value="sentinelos-iso-staging"); self.iso_stage_var = tk.StringVar(value=str(DEFAULT_WORKSPACE / "04_ISO_Staging" / "sentinelos-iso-staging")); self.iso_out_var = tk.StringVar(value=str(DEFAULT_WORKSPACE / "09_ISO_Output" / "sentinelos.iso")); self.iso_label_var = tk.StringVar(value="SENTINELOS")
        rows = [("Staging Name:", self.iso_name_var), ("Staging Folder:", self.iso_stage_var), ("Output ISO:", self.iso_out_var), ("Volume Label:", self.iso_label_var)]
        for i,(lab,var) in enumerate(rows):
            ttk.Label(form, text=lab).grid(row=i, column=0, sticky="w", pady=3, padx=(0,6)); ttk.Entry(form, textvariable=var).grid(row=i, column=1, sticky="ew", pady=3)
            if i == 1: ttk.Button(form, text="Choose", command=lambda: self.choose_dir(self.iso_stage_var)).grid(row=i, column=2, padx=6)
        form.columnconfigure(1, weight=1)
        btns = ttk.Frame(parent); btns.pack(fill="x", pady=6)
        ttk.Button(btns, text="Create Staging Tree", command=self.gui_iso_staging).pack(side="left", padx=(0,8))
        ttk.Button(btns, text="Build ISO", command=self.gui_build_iso).pack(side="left", padx=8)
        ttk.Button(btns, text="Open ISO Output", command=lambda: self.open_path(DEFAULT_WORKSPACE / "09_ISO_Output")).pack(side="left", padx=8)
        self._add_output(parent, "iso", 13)

    def gui_iso_staging(self) -> None:
        res = create_iso_staging(self.iso_name_var.get().strip())
        if res.get("status") == "ok": self.iso_stage_var.set(res.get("staging", self.iso_stage_var.get()))
        self.log_output("=== ISO Staging Result ===\n" + json.dumps(res, indent=2), "iso")

    def gui_build_iso(self) -> None:
        staging = Path(self.iso_stage_var.get().strip()).expanduser(); out = Path(self.iso_out_var.get().strip()).expanduser(); label = self.iso_label_var.get().strip() or "SENTINELOS"
        def worker():
            res = build_iso_from_staging(staging, out, label)
            self.root.after(0, lambda: self.log_output("=== ISO Build Result ===\n" + json.dumps(res, indent=2), "iso"))
        threading.Thread(target=worker, daemon=True).start()

    def _build_usb(self, parent) -> None:
        tk, ttk = self.tk, self.ttk
        self._section(parent, "USB ISO Creator", "Create live USB installers from ISO files. Uses dd on the backend with guarded confirmation. This will erase the selected device.")
        form = ttk.Frame(parent); form.pack(fill="x", pady=6)
        self.usb_iso_var = tk.StringVar(); self.usb_dev_var = tk.StringVar(); self.usb_confirm_var = tk.StringVar(); self.usb_devices_text = tk.StringVar(value="Click Refresh Devices.")
        ttk.Label(form, text="ISO File:").grid(row=0, column=0, sticky="w", pady=3, padx=(0,6)); iso_ent = ttk.Entry(form, textvariable=self.usb_iso_var); iso_ent.grid(row=0, column=1, sticky="ew", pady=3); self._try_register_drop(iso_ent, self.usb_iso_var)
        ttk.Button(form, text="Choose", command=self.choose_iso).grid(row=0, column=2, padx=6); ttk.Button(form, text="Paste", command=lambda: self.paste_to(self.usb_iso_var)).grid(row=0, column=3, padx=6)
        ttk.Label(form, text="Target Disk:").grid(row=1, column=0, sticky="w", pady=3, padx=(0,6)); ttk.Entry(form, textvariable=self.usb_dev_var).grid(row=1, column=1, sticky="ew", pady=3)
        ttk.Button(form, text="Refresh Devices", command=self.gui_list_devices).grid(row=1, column=2, padx=6)
        ttk.Label(form, text="Type ERASE:").grid(row=2, column=0, sticky="w", pady=3, padx=(0,6)); ttk.Entry(form, textvariable=self.usb_confirm_var).grid(row=2, column=1, sticky="ew", pady=3)
        form.columnconfigure(1, weight=1)
        ttk.Label(parent, textvariable=self.usb_devices_text, style="Muted.TLabel", wraplength=900).pack(anchor="w", pady=6)
        btns = ttk.Frame(parent); btns.pack(fill="x", pady=6)
        ttk.Button(btns, text="Dry Run", command=lambda: self.gui_write_usb(True)).pack(side="left", padx=(0,8))
        ttk.Button(btns, text="WRITE USB", command=lambda: self.gui_write_usb(False)).pack(side="left", padx=8)
        self._add_output(parent, "usb", 14)

    def choose_iso(self) -> None:
        from tkinter import filedialog
        p = filedialog.askopenfilename(title="Choose ISO", filetypes=[("ISO images", "*.iso"), ("All files", "*")])
        if p: self.usb_iso_var.set(p)

    def gui_list_devices(self) -> None:
        res = list_usb_devices()
        lines = []
        for d in res.get("devices", []): lines.append(f"{d.get('path')}  {d.get('size')}  {d.get('model') or ''}  tran={d.get('tran')} removable={d.get('rm')}")
        self.usb_devices_text.set("\n".join(lines) if lines else "No block devices found or lsblk unavailable.")
        self.log_output("=== USB Devices ===\n" + json.dumps(res, indent=2), "usb")

    def gui_write_usb(self, dry: bool) -> None:
        iso = Path(self.usb_iso_var.get().strip()).expanduser(); dev = self.usb_dev_var.get().strip(); conf = self.usb_confirm_var.get().strip()
        def worker():
            res = write_iso_to_usb(iso, dev, conf, dry_run=dry)
            self.root.after(0, lambda: self.log_output("=== USB ISO Creator Result ===\n" + json.dumps(res, indent=2), "usb"))
        threading.Thread(target=worker, daemon=True).start()

    def _build_release(self, parent) -> None:
        tk, ttk = self.tk, self.ttk
        self._section(parent, "Release Generator", "Generate SHA256SUMS and MANIFEST.json for a local release folder.")
        row = ttk.Frame(parent); row.pack(fill="x", pady=6)
        ttk.Label(row, text="Release Folder:").pack(side="left", padx=(0,8))
        self.release_var = tk.StringVar(value=str(DEFAULT_WORKSPACE / "05_Releases")); ent = ttk.Entry(row, textvariable=self.release_var); ent.pack(side="left", fill="x", expand=True); self._try_register_drop(ent, self.release_var)
        ttk.Button(row, text="Choose", command=lambda: self.choose_dir(self.release_var)).pack(side="left", padx=8)
        ttk.Button(row, text="Generate Manifest", command=self.gui_release_manifest).pack(side="left")
        self._add_output(parent, "release", 18)

    def gui_release_manifest(self) -> None:
        folder = Path(self.release_var.get().strip()).expanduser()
        def worker():
            res = generate_release_manifest(folder)
            self.root.after(0, lambda: self.log_output("=== Release Generator Result ===\n" + json.dumps(res, indent=2), "release"))
        threading.Thread(target=worker, daemon=True).start()

    def _build_manual(self, parent) -> None:
        self._section(parent, "Manual", "F.O.R.G.E Program 120 GUI and installer manual.")
        text = self.tk.Text(parent, bg=THEME_TREE, fg=THEME_TEXT, insertbackground=THEME_GOLD, relief="flat", wrap="word")
        text.pack(fill="both", expand=True)
        manual = f"""
F.O.R.G.E — File Output & Release Generation Engine
Program 120 — v{VERSION}

Purpose
F.O.R.G.E is the SentinelOS builder workstation. It owns builder/export work removed from Sentinel Program Manager.

Modules
1. Extractor
   Inspect and extract .zip, .tar.*, and .deb archives. Default extraction uses F.O.R.G.E quarantine/staging; users can choose beside-source or custom output when needed.

2. Package Builder
   Build simple Debian .deb wrappers and .tar.gz project bundles from local project folders or .zip project archives. ZIP projects are extracted into quarantine first. Users can select a custom package icon and F.O.R.G.E can auto-fill command candidates.

3. ISO Builder
   Create staging trees and build ISO images. Bootable output requires valid boot assets; otherwise a data ISO can be generated.

4. USB ISO Creator
   Write ISO images to selectable removable USB devices using dd. Internal/non-removable drives are hidden by default. Requires typed ERASE confirmation and root/pkexec/sudo.

5. Release Generator
   Generate MANIFEST.json and SHA256SUMS for release folders.

File input
Use Choose, Paste Path, type path + Enter, or best-effort desktop drag/drop where TkDND is available.

AEGIS Compatibility
forge --forge-status --json
forge --forge-actions --json
forge --forge-diagnostics --json
forge --forge-run inspect-archive <archive>
forge --forge-run extract <archive> [dest]
forge --forge-run build-deb <project> [package_id] [version]
forge --forge-run build-tar <project> [package_id] [version]
forge --forge-run create-iso-staging [name]
forge --forge-run build-iso <staging> [output.iso] [label]
forge --forge-run list-usb-devices
forge --forge-dry-run write-usb <iso> <device> ERASE
forge --forge-run release-manifest <folder>

Clipboard / Selection
- Ctrl+C, Ctrl+V, Ctrl+X, and Ctrl+A work across normal fields and output panes.
- Right-click fields, output panes, and tables for Cut/Copy/Paste/Select All.
- Tables copy selected rows as tab-separated text for easy notes or reports.

Rules
- Local-first.
- No internet required.
- USB writing is destructive and requires explicit confirmation.
- Archive extraction is inspected before use.
""".strip()
        text.insert("1.0", manual); text.configure(state="disabled")

    def gui_init_workspace(self) -> None:
        res = init_workspace(DEFAULT_WORKSPACE); self.refresh_dashboard(); self.log_output(json.dumps(res, indent=2), "dashboard")

    def gui_diagnostics(self) -> None:
        self.log_output(json.dumps(diagnostics(), indent=2), "dashboard")

    def open_path(self, path: Path) -> None:
        path.mkdir(parents=True, exist_ok=True)
        for cmd in (["xdg-open", str(path)], ["gio", "open", str(path)]):
            if shutil.which(cmd[0]): subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL); return
        self.log_output(f"Open path: {path}")

    def run(self) -> None:
        self.root.mainloop()



# ------------------------- v0.4 workflow helpers / overrides -------------------------
def timestamp_id() -> str:
    return _dt.datetime.now().strftime("%Y%m%d_%H%M%S")


def quarantine_destination_for_archive(archive: Path) -> Path:
    stem = sanitize_id(archive.name)
    # Strip common archive suffix noise for friendlier folder names.
    for suffix in [".tar.gz", ".tar.xz", ".tar.bz2", ".tgz", ".txz", ".tbz2", ".zip", ".deb", ".tar"]:
        if stem.endswith(sanitize_id(suffix)):
            stem = stem[: -len(sanitize_id(suffix))].strip("-") or stem
            break
    return DEFAULT_WORKSPACE / "02_Extracted" / "Quarantine" / f"{stem}_{timestamp_id()}"


def source_destination_for_archive(archive: Path) -> Path:
    name = archive.name
    for suffix in [".tar.gz", ".tar.xz", ".tar.bz2", ".tgz", ".txz", ".tbz2", ".zip", ".deb", ".tar"]:
        if name.lower().endswith(suffix):
            name = name[: -len(suffix)]
            break
    return archive.parent / f"{sanitize_id(name)}_extracted"


def detect_desktop_exec(project: Path) -> Optional[str]:
    try:
        for desktop in list(project.rglob("*.desktop"))[:20]:
            for line in desktop.read_text(errors="ignore").splitlines():
                if line.startswith("Exec="):
                    cmd = line.split("=", 1)[1].strip()
                    # Remove desktop placeholders so the command is usable in wrappers.
                    cmd = re.sub(r"\s+%[fFuUdDnNickvm]", "", cmd).strip()
                    if cmd:
                        return cmd.split()[0]
    except Exception:
        pass
    return None


def detect_command_from_project(project: Path, package_id: Optional[str] = None) -> str:
    desktop_cmd = detect_desktop_exec(project)
    if desktop_cmd:
        return Path(desktop_cmd).name
    entry = find_entrypoint(project)
    if entry:
        if entry.endswith(".py"):
            return sanitize_id(package_id or project.name)
        return sanitize_id(Path(entry).stem)
    # Common project names / scripts.
    for rel in ["bin", "usr/bin"]:
        d = project / rel
        if d.exists():
            for f in sorted(d.iterdir()):
                if f.is_file() and os.access(f, os.X_OK):
                    return sanitize_id(f.name)
    return sanitize_id(package_id or project.name)


def _single_top_level_dir(folder: Path) -> Path:
    try:
        children = [p for p in folder.iterdir() if not p.name.startswith(".__MACOSX")]
        dirs = [p for p in children if p.is_dir()]
        files = [p for p in children if p.is_file()]
        if len(dirs) == 1 and not files:
            return dirs[0]
    except Exception:
        pass
    return folder


def prepare_project_input(project_input: Path) -> Tuple[Optional[Path], Optional[Path], Dict[str, object]]:
    """Return prepared project folder, cleanup root, and metadata."""
    src = project_input.expanduser().resolve()
    if src.is_dir():
        return src, None, {"status": "ok", "source_type": "folder", "source": str(src), "project": str(src)}
    if src.is_file() and src.name.lower().endswith(".zip"):
        check = inspect_archive(src)
        if not check.ok:
            return None, None, {"status": "blocked", "source_type": "zip", "source": str(src), "check": asdict(check)}
        dest = DEFAULT_WORKSPACE / "02_Extracted" / "Quarantine" / f"project_{sanitize_id(src.stem)}_{timestamp_id()}"
        res = safe_extract_archive(src, dest)
        if res.get("status") != "ok":
            return None, None, {"status": "error", "source_type": "zip", "source": str(src), "extract_result": res}
        project = _single_top_level_dir(dest)
        return project, dest, {"status": "ok", "source_type": "zip", "source": str(src), "project": str(project), "quarantine": str(dest), "note": "ZIP project extracted into F.O.R.G.E quarantine before build."}
    return None, None, {"status": "error", "error": "Project input must be a folder or .zip file", "source": str(src)}


_build_deb_from_project_v03 = build_deb_from_project
_build_tar_from_project_v03 = build_tar_from_project


def build_deb_from_project(project: Path, package_id: Optional[str] = None, version: str = "0.1", app_name: Optional[str] = None, command: Optional[str] = None, description: str = "Built by F.O.R.G.E", output_dir: Optional[Path] = None, create_desktop: bool = True, icon_path: Optional[Path] = None) -> Dict[str, object]:
    prepared, cleanup_root, prep = prepare_project_input(project)
    if not prepared:
        audit("build-deb", str(project), "blocked", prep)
        return prep
    package_id = sanitize_id(package_id or prepared.name)
    command = command or detect_command_from_project(prepared, package_id)
    result = _build_deb_from_project_v03(prepared, package_id, version, app_name, command, description, output_dir, create_desktop, icon_path)
    result["prepared_input"] = prep
    result["scanner_status"] = "unverified-quarantine" if prep.get("source_type") == "zip" else "not-scanned"
    return result


def build_tar_from_project(project: Path, package_id: Optional[str] = None, version: str = "0.1", output_dir: Optional[Path] = None) -> Dict[str, object]:
    prepared, cleanup_root, prep = prepare_project_input(project)
    if not prepared:
        audit("build-tar", str(project), "blocked", prep)
        return prep
    result = _build_tar_from_project_v03(prepared, package_id, version, output_dir)
    result["prepared_input"] = prep
    result["scanner_status"] = "unverified-quarantine" if prep.get("source_type") == "zip" else "not-scanned"
    return result


def usable_usb_devices(include_internal: bool = False) -> Dict[str, object]:
    res = list_usb_devices()
    devices = []
    for d in res.get("devices", []):
        path = str(d.get("path") or "")
        tran = str(d.get("tran") or "").lower()
        rm = bool(d.get("rm")) or str(d.get("rm")).lower() in ("1", "true")
        dtype = str(d.get("type") or "")
        # Default user-ready safety: only show removable/USB disks, never root-ish internal paths.
        usable = dtype == "disk" and path.startswith("/dev/") and (rm or tran == "usb")
        if include_internal:
            usable = dtype == "disk" and path.startswith("/dev/")
        if usable:
            nd = dict(d)
            nd["usable"] = True
            nd["display"] = f"{path}   {d.get('size') or ''}   {d.get('model') or ''}   {tran or 'unknown'}"
            devices.append(nd)
    return {"status": res.get("status"), "devices": devices, "raw_count": len(res.get("devices", [])), "filtered_count": len(devices), "policy": "removable-usb-only" if not include_internal else "advanced-internal-visible"}


# ------------------------- v0.4 GUI monkey patches -------------------------
def _v04_build_extractor(self, parent) -> None:
    tk, ttk = self.tk, self.ttk
    self._section(parent, "Extractor", "Inspect and extract .zip, .tar.*, and .deb archives. Default output goes to F.O.R.G.E quarantine/staging so unknown archives stay contained until S.C.A.N verification is integrated.")
    form = ttk.Frame(parent); form.pack(fill="x", pady=6)
    ttk.Label(form, text="Archive:").grid(row=0, column=0, sticky="w", padx=(0,6), pady=4)
    self.archive_var = tk.StringVar(); e = ttk.Entry(form, textvariable=self.archive_var)
    e.grid(row=0, column=1, sticky="ew", pady=4); e.bind("<Return>", lambda _e: self.gui_inspect_archive())
    self._try_register_drop(e, self.archive_var, self.gui_inspect_archive)
    ttk.Button(form, text="Choose", command=self.choose_archive).grid(row=0, column=2, padx=6)
    ttk.Button(form, text="Paste Path", command=lambda: self.paste_to(self.archive_var, self.gui_inspect_archive)).grid(row=0, column=3, padx=6)
    self.extract_mode_var = tk.StringVar(value="forge")
    mode = ttk.Frame(parent); mode.pack(fill="x", pady=(4, 2))
    ttk.Label(mode, text="Extract output:").pack(side="left", padx=(0,10))
    for val, txt in [("forge", "F.O.R.G.E quarantine/staging (recommended)"), ("source", "Beside source archive"), ("custom", "Custom folder")]:
        tk.Radiobutton(mode, text=txt, variable=self.extract_mode_var, value=val, bg=THEME_BG, fg=THEME_TEXT, selectcolor=THEME_TREE, activebackground=THEME_BG, activeforeground=THEME_GOLD).pack(side="left", padx=6)
    destrow = ttk.Frame(parent); destrow.pack(fill="x", pady=4)
    ttk.Label(destrow, text="Custom Destination:").pack(side="left", padx=(0,8))
    self.extract_dest_var = tk.StringVar(value=str(DEFAULT_WORKSPACE / "02_Extracted" / "Quarantine"))
    ttk.Entry(destrow, textvariable=self.extract_dest_var).pack(side="left", fill="x", expand=True)
    ttk.Button(destrow, text="Choose", command=lambda: self.choose_dir(self.extract_dest_var)).pack(side="left", padx=8)
    btns = ttk.Frame(parent); btns.pack(fill="x", pady=6)
    ttk.Button(btns, text="Inspect Archive", command=self.gui_inspect_archive).pack(side="left", padx=(0,6))
    ttk.Button(btns, text="Extract", command=self.gui_extract_archive).pack(side="left", padx=6)
    ttk.Label(parent, text="Future flow: Quarantine → S.C.A.N verify → Verified → Build/Release.", style="Muted.TLabel").pack(anchor="w", pady=(0, 6))
    self._add_output(parent, "extractor", 16)


def _v04_choose_project(self) -> None:
    from tkinter import filedialog
    p = filedialog.askopenfilename(title="Choose project .zip or cancel for folder", filetypes=[("Project zip", "*.zip"), ("All files", "*")])
    if not p:
        p = filedialog.askdirectory(title="Choose project folder")
    if p:
        self.project_var.set(p)
        self.gui_autofill_package_fields()


def _v04_choose_icon(self) -> None:
    from tkinter import filedialog
    p = filedialog.askopenfilename(title="Choose package icon", filetypes=[("Image files", "*.png *.svg *.xpm"), ("All files", "*")])
    if p:
        self.pkg_icon_var.set(p)


def _v04_gui_autofill_package_fields(self) -> None:
    src = Path(self.project_var.get().strip()).expanduser()
    package_guess = sanitize_id(src.stem if src.suffix.lower() == ".zip" else src.name)
    if not self.pkg_id_var.get().strip():
        self.pkg_id_var.set(package_guess)
    if not self.pkg_name_var.get().strip():
        self.pkg_name_var.set(package_guess.replace("-", " ").replace("_", " ").title())
    # If a folder, inspect directly. If a zip, command will be re-detected after extraction during build.
    if src.is_dir() and not self.pkg_cmd_var.get().strip():
        self.pkg_cmd_var.set(detect_command_from_project(src, package_guess))
    elif src.is_file() and src.name.lower().endswith(".zip") and not self.pkg_cmd_var.get().strip():
        self.pkg_cmd_var.set(package_guess)
    self.log_output(f"Auto-filled package fields for: {src}\nCommand candidate: {self.pkg_cmd_var.get()}", "package")


def _v04_build_package(self, parent) -> None:
    tk, ttk = self.tk, self.ttk
    self._section(parent, "Package Builder", "Build .deb wrappers and .tar.gz release bundles from a project folder or .zip project. ZIP inputs are extracted into F.O.R.G.E quarantine first.")
    form = ttk.Frame(parent); form.pack(fill="x", pady=6)
    self.project_var = tk.StringVar(); self.pkg_id_var = tk.StringVar(); self.pkg_name_var = tk.StringVar(); self.pkg_version_var = tk.StringVar(value="0.1"); self.pkg_cmd_var = tk.StringVar(); self.pkg_desc_var = tk.StringVar(value="SentinelOS application built by F.O.R.G.E"); self.pkg_icon_var = tk.StringVar()
    rows = [("Project Folder / .zip:", self.project_var), ("Package ID:", self.pkg_id_var), ("Application Name:", self.pkg_name_var), ("Version:", self.pkg_version_var), ("Command:", self.pkg_cmd_var), ("Description:", self.pkg_desc_var), ("Package Icon:", self.pkg_icon_var)]
    for i,(lab,var) in enumerate(rows):
        ttk.Label(form, text=lab).grid(row=i, column=0, sticky="w", pady=3, padx=(0,6))
        ent = ttk.Entry(form, textvariable=var); ent.grid(row=i, column=1, sticky="ew", pady=3)
        if i == 0:
            ent.bind("<Return>", lambda _e: self.gui_autofill_package_fields())
            self._try_register_drop(ent, self.project_var, self.gui_autofill_package_fields)
            ttk.Button(form, text="Choose", command=self.choose_project).grid(row=i, column=2, padx=6)
            ttk.Button(form, text="Paste", command=lambda: self.paste_to(self.project_var, self.gui_autofill_package_fields)).grid(row=i, column=3, padx=6)
        elif i == 4:
            ttk.Button(form, text="Auto Fill", command=self.gui_autofill_package_fields).grid(row=i, column=2, padx=6)
        elif i == 6:
            ttk.Button(form, text="Choose Icon", command=self.choose_icon).grid(row=i, column=2, padx=6)
    form.columnconfigure(1, weight=1)
    btns = ttk.Frame(parent); btns.pack(fill="x", pady=6)
    ttk.Button(btns, text="Build .deb", command=self.gui_build_deb).pack(side="left", padx=(0,8))
    ttk.Button(btns, text="Build .tar.gz", command=self.gui_build_tar).pack(side="left", padx=8)
    ttk.Button(btns, text="Open Packages", command=lambda: self.open_path(DEFAULT_WORKSPACE / "03_Packages")).pack(side="left", padx=8)
    ttk.Label(parent, text="Build output and progress will appear below. If input is a ZIP, F.O.R.G.E extracts it to quarantine before building.", style="Muted.TLabel").pack(anchor="w", pady=(0, 4))
    self._add_output(parent, "package", 14)


def _v04_gui_build_deb(self) -> None:
    project = Path(self.project_var.get().strip()).expanduser(); package_id = self.pkg_id_var.get().strip() or None; app_name = self.pkg_name_var.get().strip() or None; version = self.pkg_version_var.get().strip() or "0.1"; command = self.pkg_cmd_var.get().strip() or None; desc = self.pkg_desc_var.get().strip() or "Built by F.O.R.G.E"; icon = Path(self.pkg_icon_var.get().strip()).expanduser() if self.pkg_icon_var.get().strip() else None
    self.log_output("=== .deb Build Started ===\nPreparing input...\nValidating project metadata...", "package")
    def worker():
        res = build_deb_from_project(project, package_id, version, app_name, command, desc, icon_path=icon)
        msg = "=== .deb Build Result ===\n" + json.dumps(res, indent=2)
        if res.get("status") == "ok":
            msg = "Build complete. Output package created.\n" + msg
        self.root.after(0, lambda: self.log_output(msg, "package"))
    threading.Thread(target=worker, daemon=True).start()


def _v04_gui_build_tar(self) -> None:
    project = Path(self.project_var.get().strip()).expanduser(); package_id = self.pkg_id_var.get().strip() or None; version = self.pkg_version_var.get().strip() or "0.1"
    self.log_output("=== .tar.gz Build Started ===\nPreparing input...\nCreating compressed bundle...", "package")
    def worker():
        res = build_tar_from_project(project, package_id, version)
        msg = "=== .tar.gz Build Result ===\n" + json.dumps(res, indent=2)
        if res.get("status") == "ok":
            msg = "Bundle complete. Output tarball created.\n" + msg
        self.root.after(0, lambda: self.log_output(msg, "package"))
    threading.Thread(target=worker, daemon=True).start()


def _v04_resolve_extract_dest(self, archive: Path) -> Path:
    mode = getattr(self, "extract_mode_var", None).get() if hasattr(self, "extract_mode_var") else "forge"
    if mode == "source":
        return source_destination_for_archive(archive.expanduser().resolve())
    if mode == "custom":
        return Path(self.extract_dest_var.get().strip()).expanduser()
    return quarantine_destination_for_archive(archive.expanduser())


def _v04_gui_extract_archive(self) -> None:
    p = Path(self.archive_var.get().strip()).expanduser(); d = self.resolve_extract_dest(p)
    self.log_output(f"=== Extract Started ===\nArchive: {p}\nDestination: {d}\nPolicy: {getattr(self, 'extract_mode_var', None).get() if hasattr(self, 'extract_mode_var') else 'forge'}", "extractor")
    def worker():
        res = safe_extract_archive(p, d)
        if res.get("status") == "ok":
            res["scanner_status"] = "unverified-quarantine" if "Quarantine" in str(d) else "not-scanned"
            res["next_step"] = "Future S.C.A.N integration should verify quarantine contents before release/use."
        self.root.after(0, lambda: self.log_output("=== Extract Result ===\n" + json.dumps(res, indent=2), "extractor"))
    threading.Thread(target=worker, daemon=True).start()


def _v04_build_usb(self, parent) -> None:
    tk, ttk = self.tk, self.ttk
    self._section(parent, "USB ISO Creator", "Create live USB installers from ISO files. Only removable USB targets are shown by default. This will erase the selected device.")
    form = ttk.Frame(parent); form.pack(fill="x", pady=6)
    self.usb_iso_var = tk.StringVar(); self.usb_dev_var = tk.StringVar(); self.usb_confirm_var = tk.StringVar(); self.usb_devices_text = tk.StringVar(value="Click Refresh Devices."); self.usb_device_buttons=[]; self.usb_show_internal_var=tk.BooleanVar(value=False)
    ttk.Label(form, text="ISO File:").grid(row=0, column=0, sticky="w", pady=3, padx=(0,6)); iso_ent = ttk.Entry(form, textvariable=self.usb_iso_var); iso_ent.grid(row=0, column=1, sticky="ew", pady=3); self._try_register_drop(iso_ent, self.usb_iso_var)
    ttk.Button(form, text="Choose", command=self.choose_iso).grid(row=0, column=2, padx=6); ttk.Button(form, text="Paste", command=lambda: self.paste_to(self.usb_iso_var)).grid(row=0, column=3, padx=6)
    ttk.Label(form, text="Selected Disk:").grid(row=1, column=0, sticky="w", pady=3, padx=(0,6)); ttk.Entry(form, textvariable=self.usb_dev_var).grid(row=1, column=1, sticky="ew", pady=3)
    ttk.Button(form, text="Refresh Devices", command=self.gui_list_devices).grid(row=1, column=2, padx=6, sticky="ew")
    tk.Checkbutton(form, text="Advanced: show internal/non-removable disks", variable=self.usb_show_internal_var, bg=THEME_BG, fg=THEME_TEXT, selectcolor=THEME_TREE, activebackground=THEME_BG, activeforeground=THEME_GOLD).grid(row=2, column=1, sticky="w", pady=3)
    ttk.Label(form, text="Type ERASE:").grid(row=3, column=0, sticky="w", pady=3, padx=(0,6)); ttk.Entry(form, textvariable=self.usb_confirm_var).grid(row=3, column=1, sticky="ew", pady=3)
    form.columnconfigure(1, weight=1)
    ttk.Label(parent, text="Target disks:", style="Gold.TLabel").pack(anchor="w", pady=(8, 2))
    self.usb_device_frame = ttk.Frame(parent); self.usb_device_frame.pack(fill="x", pady=(0,6))
    ttk.Label(parent, textvariable=self.usb_devices_text, style="Muted.TLabel", wraplength=900).pack(anchor="w", pady=4)
    btns = ttk.Frame(parent); btns.pack(fill="x", pady=6)
    ttk.Button(btns, text="Dry Run", command=lambda: self.gui_write_usb(True)).pack(side="left", padx=(0,8))
    ttk.Button(btns, text="WRITE USB", command=lambda: self.gui_write_usb(False)).pack(side="left", padx=8)
    self._add_output(parent, "usb", 12)


def _v04_gui_list_devices(self) -> None:
    # Clear old choices.
    for child in getattr(self, "usb_device_frame", []).winfo_children() if hasattr(self, "usb_device_frame") else []:
        child.destroy()
    include_internal = bool(getattr(self, "usb_show_internal_var", None).get()) if hasattr(self, "usb_show_internal_var") else False
    res = usable_usb_devices(include_internal=include_internal)
    devices = res.get("devices", [])
    if not devices:
        self.usb_devices_text.set("No usable removable USB target disks found. Insert a USB drive and click Refresh Devices. Internal drives are hidden by default.")
    else:
        self.usb_devices_text.set(f"{len(devices)} usable target disk(s) found. Select exactly one target before writing.")
    for d in devices:
        label = d.get("display") or d.get("path")
        rb = self.tk.Radiobutton(self.usb_device_frame, text=label, variable=self.usb_dev_var, value=d.get("path"), anchor="w", bg=THEME_BG, fg=THEME_TEXT, selectcolor=THEME_TREE, activebackground=THEME_BG, activeforeground=THEME_GOLD)
        rb.pack(fill="x", anchor="w", pady=2)
    self.log_output("=== USB Devices ===\n" + json.dumps(res, indent=2), "usb")


# Apply GUI monkey patches.
ForgeGUI._build_extractor = _v04_build_extractor
ForgeGUI._build_package = _v04_build_package
ForgeGUI._build_usb = _v04_build_usb
ForgeGUI.choose_project = _v04_choose_project
ForgeGUI.choose_icon = _v04_choose_icon
ForgeGUI.gui_autofill_package_fields = _v04_gui_autofill_package_fields
ForgeGUI.gui_build_deb = _v04_gui_build_deb
ForgeGUI.gui_build_tar = _v04_gui_build_tar
ForgeGUI.resolve_extract_dest = _v04_resolve_extract_dest
ForgeGUI.gui_extract_archive = _v04_gui_extract_archive
ForgeGUI.gui_list_devices = _v04_gui_list_devices


# ------------------------- v0.5 human-readable status polish -------------------------
def _v05_status_panel(self, parent, key: str, title: str):
    """Create a visible, non-technical status panel for a module."""
    if not hasattr(self, "status_panels"):
        self.status_panels = {}
    tk, ttk = self.tk, self.ttk
    panel = ttk.Frame(parent, style="Panel.TFrame")
    panel.pack(fill="x", pady=(6, 8))
    ttk.Label(panel, text=title, style="Gold.TLabel", background=THEME_PANEL).pack(anchor="w", padx=10, pady=(8, 2))
    state = tk.StringVar(value="Status: Ready")
    detail = tk.StringVar(value="Waiting for user action.")
    state_lbl = tk.Label(panel, textvariable=state, bg=THEME_PANEL, fg=THEME_GOLD, font=("Sans", 12, "bold"), anchor="w")
    state_lbl.pack(fill="x", padx=10, pady=(0, 2))
    detail_lbl = tk.Label(panel, textvariable=detail, bg=THEME_PANEL, fg=THEME_MUTED, anchor="w", justify="left", wraplength=900)
    detail_lbl.pack(fill="x", padx=10, pady=(0, 8))
    self.status_panels[key] = {"state": state, "detail": detail, "state_label": state_lbl, "detail_label": detail_lbl}
    return panel


def _v05_set_status(self, key: str, state: str, detail: str = "", level: str = "info") -> None:
    panel = getattr(self, "status_panels", {}).get(key)
    if not panel:
        return
    state_text = state if state.startswith("Status:") else f"Status: {state}"
    panel["state"].set(state_text)
    panel["detail"].set(detail or "")
    color = {
        "running": THEME_CYAN,
        "pass": "#7DFF9A",
        "failed": THEME_DANGER,
        "warn": "#FFC857",
        "info": THEME_GOLD,
    }.get(level, THEME_GOLD)
    try:
        panel["state_label"].configure(fg=color)
    except Exception:
        pass


def _v05_format_check_message(res: dict) -> tuple[str, str, str]:
    status = str(res.get("status", "unknown"))
    if status == "ok":
        return "PASS", "Workspace initialization COMPLETE.", "pass"
    return "FAILED", res.get("error") or json.dumps(res, indent=2), "failed"


def _v05_build_dashboard(self, parent) -> None:
    self._section(parent, "Dashboard", "Human-readable build status for F.O.R.G.E workspace, diagnostics, and release operations.")
    actions = self.ttk.Frame(parent); actions.pack(fill="x", pady=6)
    self.ttk.Button(actions, text="Initialize Workspace", command=self.gui_init_workspace).pack(side="left", padx=(0, 6))
    self.ttk.Button(actions, text="Run Diagnostics", command=self.gui_diagnostics).pack(side="left", padx=6)
    self.ttk.Button(actions, text="Open Workspace", command=lambda: self.open_path(DEFAULT_WORKSPACE)).pack(side="left", padx=6)
    self._status_panel(parent, "workspace", "Workspace Initialization")
    self._status_panel(parent, "diagnostics", "Diagnostics")
    cols = ("path", "status")
    self.dash_tree = self.ttk.Treeview(parent, columns=cols, show="headings", height=8)
    self.dash_tree.heading("path", text="Workspace Path"); self.dash_tree.heading("status", text="Status")
    self.dash_tree.column("path", width=650); self.dash_tree.column("status", width=160)
    self.dash_tree.pack(fill="x", pady=8)
    self._add_output(parent, "dashboard", 8)


def _v05_gui_init_workspace(self) -> None:
    self.set_status("workspace", "Initializing Workspace...", "Creating/checking the F.O.R.G.E workspace folders now.", "running")
    def worker():
        try:
            res = init_workspace(DEFAULT_WORKSPACE)
            state, detail, level = _v05_format_check_message(res)
        except Exception as e:
            res = {"status": "error", "error": str(e), "traceback": traceback.format_exc()}
            state, detail, level = "FAILED", f"Workspace initialization FAILED: {e}", "failed"
        def done():
            self.refresh_dashboard()
            self.set_status("workspace", state, detail, level)
            self.log_output("=== Workspace Initialization Details ===\n" + json.dumps(res, indent=2), "dashboard")
        self.root.after(0, done)
    threading.Thread(target=worker, daemon=True).start()


def _v05_diagnostics_passed(res: dict) -> bool:
    try:
        for check in res.get("checks", []):
            if str(check.get("status", "")).lower() not in ("ok", "pass", "warning", "warn"):
                return False
    except Exception:
        pass
    # Current diagnostics may be minimal. Treat dict presence as pass unless explicit failure/error appears.
    raw = json.dumps(res).lower()
    return "\"status\": \"error\"" not in raw and "\"status\": \"failed\"" not in raw


def _v05_gui_diagnostics(self) -> None:
    self.set_status("diagnostics", "Running Diagnostics...", "Checking F.O.R.G.E tools, workspace, Python modules, and supported backend commands.", "running")
    def worker():
        try:
            res = diagnostics()
            ok = _v05_diagnostics_passed(res)
            state = "PASS" if ok else "FAILED"
            detail = "Diagnostics PASS. F.O.R.G.E baseline checks completed." if ok else "Diagnostics FAILED. Review details below for missing tools or errors."
            level = "pass" if ok else "failed"
        except Exception as e:
            res = {"status": "error", "error": str(e), "traceback": traceback.format_exc()}
            state, detail, level = "FAILED", f"Diagnostics FAILED: {e}", "failed"
        self.root.after(0, lambda: (self.set_status("diagnostics", state, detail, level), self.log_output("=== Diagnostics Details ===\n" + json.dumps(res, indent=2), "dashboard")))
    threading.Thread(target=worker, daemon=True).start()


def _v05_build_extractor(self, parent) -> None:
    tk, ttk = self.tk, self.ttk
    self._section(parent, "Extractor", "Inspect and extract .zip, .tar.*, and .deb archives. Default output goes to F.O.R.G.E quarantine/staging so unknown archives stay contained until S.C.A.N verification is integrated.")
    form = ttk.Frame(parent); form.pack(fill="x", pady=6)
    ttk.Label(form, text="Archive:").grid(row=0, column=0, sticky="w", padx=(0,6), pady=4)
    self.archive_var = tk.StringVar(); e = ttk.Entry(form, textvariable=self.archive_var)
    e.grid(row=0, column=1, sticky="ew", pady=4); e.bind("<Return>", lambda _e: self.gui_inspect_archive())
    self._try_register_drop(e, self.archive_var, self.gui_inspect_archive)
    ttk.Button(form, text="Choose", command=self.choose_archive).grid(row=0, column=2, padx=6)
    ttk.Button(form, text="Paste Path", command=lambda: self.paste_to(self.archive_var, self.gui_inspect_archive)).grid(row=0, column=3, padx=6)
    self.extract_mode_var = tk.StringVar(value="forge")
    mode = ttk.Frame(parent); mode.pack(fill="x", pady=(4, 2))
    ttk.Label(mode, text="Extract output:").pack(side="left", padx=(0,10))
    for val, txt in [("forge", "F.O.R.G.E quarantine/staging (recommended)"), ("source", "Beside source archive"), ("custom", "Custom folder")]:
        tk.Radiobutton(mode, text=txt, variable=self.extract_mode_var, value=val, bg=THEME_BG, fg=THEME_TEXT, selectcolor=THEME_TREE, activebackground=THEME_BG, activeforeground=THEME_GOLD).pack(side="left", padx=6)
    destrow = ttk.Frame(parent); destrow.pack(fill="x", pady=4)
    ttk.Label(destrow, text="Custom Destination:").pack(side="left", padx=(0,8))
    self.extract_dest_var = tk.StringVar(value=str(DEFAULT_WORKSPACE / "02_Extracted" / "Quarantine"))
    ttk.Entry(destrow, textvariable=self.extract_dest_var).pack(side="left", fill="x", expand=True)
    ttk.Button(destrow, text="Choose", command=lambda: self.choose_dir(self.extract_dest_var)).pack(side="left", padx=8)
    btns = ttk.Frame(parent); btns.pack(fill="x", pady=6)
    ttk.Button(btns, text="Inspect Archive", command=self.gui_inspect_archive).pack(side="left", padx=(0,6))
    ttk.Button(btns, text="Extract", command=self.gui_extract_archive).pack(side="left", padx=6)
    self._status_panel(parent, "extractor_status", "Extractor Status")
    ttk.Label(parent, text="Future flow: Quarantine → S.C.A.N verify → Verified → Build/Release.", style="Muted.TLabel").pack(anchor="w", pady=(0, 6))
    self._add_output(parent, "extractor", 10)


def _v05_gui_inspect_archive(self) -> None:
    p = Path(self.archive_var.get().strip()).expanduser()
    self.set_status("extractor_status", "Inspecting Archive...", f"Checking archive safety: {p}", "running")
    def worker():
        res = inspect_archive(p)
        if res.ok:
            detail = f"Archive inspection PASS. Type: {res.kind}. Items: {res.member_count}. Estimated size: {human_size(res.total_size)}. Safe to extract into selected output."
            state, level = "PASS", "pass"
        else:
            reasons = "; ".join(res.blocked[:3]) or "Archive failed inspection."
            detail = f"Archive inspection FAILED. {reasons}"
            state, level = "FAILED", "failed"
        self.root.after(0, lambda: (self.set_status("extractor_status", state, detail, level), self.log_output("=== Archive Inspection Details ===\n" + json.dumps(asdict(res), indent=2), "extractor")))
    threading.Thread(target=worker, daemon=True).start()


def _v05_gui_extract_archive(self) -> None:
    p = Path(self.archive_var.get().strip()).expanduser(); d = self.resolve_extract_dest(p)
    self.set_status("extractor_status", "Extracting Archive...", f"Extracting to: {d}", "running")
    self.log_output(f"=== Extract Started ===\nArchive: {p}\nDestination: {d}\nPolicy: {getattr(self, 'extract_mode_var', None).get() if hasattr(self, 'extract_mode_var') else 'forge'}", "extractor")
    def worker():
        res = safe_extract_archive(p, d)
        if res.get("status") == "ok":
            res["scanner_status"] = "unverified-quarantine" if "Quarantine" in str(d) else "not-scanned"
            res["next_step"] = "Future S.C.A.N integration should verify quarantine contents before release/use."
            check = res.get("check", {})
            count = check.get("member_count", "unknown") if isinstance(check, dict) else "unknown"
            detail = f"Extraction COMPLETE. Output saved to: {d}. Extracted item count: {count}. Scanner status: {res.get('scanner_status')}."
            state, level = "PASS", "pass"
        else:
            detail = f"Extraction FAILED or BLOCKED. Reason: {res.get('error') or res.get('status')}."
            state, level = "FAILED", "failed"
        self.root.after(0, lambda: (self.set_status("extractor_status", state, detail, level), self.log_output("=== Extract Result Details ===\n" + json.dumps(res, indent=2), "extractor")))
    threading.Thread(target=worker, daemon=True).start()


def _v05_build_usb(self, parent) -> None:
    tk, ttk = self.tk, self.ttk
    self._section(parent, "USB ISO Creator", "Create live USB installers from ISO files. Only removable USB targets are shown by default. This will erase the selected device.")
    form = ttk.Frame(parent); form.pack(fill="x", pady=6)
    self.usb_iso_var = tk.StringVar(); self.usb_dev_var = tk.StringVar(); self.usb_confirm_var = tk.StringVar(); self.usb_devices_text = tk.StringVar(value="Click Refresh Devices."); self.usb_device_buttons=[]; self.usb_show_internal_var=tk.BooleanVar(value=False)
    ttk.Label(form, text="ISO File:").grid(row=0, column=0, sticky="w", pady=3, padx=(0,6)); iso_ent = ttk.Entry(form, textvariable=self.usb_iso_var); iso_ent.grid(row=0, column=1, sticky="ew", pady=3); self._try_register_drop(iso_ent, self.usb_iso_var)
    ttk.Button(form, text="Choose", command=self.choose_iso).grid(row=0, column=2, padx=6); ttk.Button(form, text="Paste", command=lambda: self.paste_to(self.usb_iso_var)).grid(row=0, column=3, padx=6)
    ttk.Label(form, text="Selected Disk:").grid(row=1, column=0, sticky="w", pady=3, padx=(0,6)); ttk.Entry(form, textvariable=self.usb_dev_var).grid(row=1, column=1, sticky="ew", pady=3)
    ttk.Button(form, text="Refresh Devices", command=self.gui_list_devices).grid(row=1, column=2, padx=6, sticky="ew")
    tk.Checkbutton(form, text="Advanced: show internal/non-removable disks", variable=self.usb_show_internal_var, bg=THEME_BG, fg=THEME_TEXT, selectcolor=THEME_TREE, activebackground=THEME_BG, activeforeground=THEME_GOLD).grid(row=2, column=1, sticky="w", pady=3)
    ttk.Label(form, text="Type ERASE:").grid(row=3, column=0, sticky="w", pady=3, padx=(0,6)); ttk.Entry(form, textvariable=self.usb_confirm_var).grid(row=3, column=1, sticky="ew", pady=3)
    form.columnconfigure(1, weight=1)
    ttk.Label(parent, text="Target disks:", style="Gold.TLabel").pack(anchor="w", pady=(8, 2))
    self.usb_device_frame = ttk.Frame(parent); self.usb_device_frame.pack(fill="x", pady=(0,6))
    ttk.Label(parent, textvariable=self.usb_devices_text, style="Muted.TLabel", wraplength=900).pack(anchor="w", pady=4)
    btns = ttk.Frame(parent); btns.pack(fill="x", pady=6)
    ttk.Button(btns, text="Dry Run", command=lambda: self.gui_write_usb(True)).pack(side="left", padx=(0,8))
    ttk.Button(btns, text="WRITE USB", command=lambda: self.gui_write_usb(False)).pack(side="left", padx=8)
    self._status_panel(parent, "usb_status", "USB ISO Creator Status")
    self._add_output(parent, "usb", 8)


def _v05_gui_list_devices(self) -> None:
    self.set_status("usb_status", "Refreshing Devices...", "Looking for usable removable USB target drives.", "running")
    for child in getattr(self, "usb_device_frame", []).winfo_children() if hasattr(self, "usb_device_frame") else []:
        child.destroy()
    include_internal = bool(getattr(self, "usb_show_internal_var", None).get()) if hasattr(self, "usb_show_internal_var") else False
    res = usable_usb_devices(include_internal=include_internal)
    devices = res.get("devices", [])
    if not devices:
        msg = "No usable removable USB target disks found. Insert a USB drive and click Refresh Devices. Internal drives are hidden by default."
        self.usb_devices_text.set(msg)
        self.set_status("usb_status", "FAILED", msg, "failed")
    else:
        msg = f"Device refresh PASS. {len(devices)} usable target disk(s) found. Select exactly one target before writing."
        self.usb_devices_text.set(msg)
        self.set_status("usb_status", "PASS", msg, "pass")
    for d in devices:
        label = d.get("display") or d.get("path")
        rb = self.tk.Radiobutton(self.usb_device_frame, text=label, variable=self.usb_dev_var, value=d.get("path"), anchor="w", bg=THEME_BG, fg=THEME_TEXT, selectcolor=THEME_TREE, activebackground=THEME_BG, activeforeground=THEME_GOLD)
        rb.pack(fill="x", anchor="w", pady=2)
    self.log_output("=== USB Devices Details ===\n" + json.dumps(res, indent=2), "usb")


def _v05_gui_write_usb(self, dry: bool) -> None:
    iso = Path(self.usb_iso_var.get().strip()).expanduser(); dev = self.usb_dev_var.get().strip(); conf = self.usb_confirm_var.get().strip()
    self.set_status("usb_status", "USB Write DRY RUN..." if dry else "Writing ISO to USB...", f"ISO: {iso}\nTarget: {dev or 'No disk selected'}", "running")
    def worker():
        res = write_iso_to_usb(iso, dev, conf, dry_run=dry)
        if res.get("status") in ("ok", "dry-run"):
            if dry:
                detail = f"USB dry-run PASS. F.O.R.G.E would write {iso} to {dev}. No data was changed."
            else:
                detail = f"USB write COMPLETE. ISO was written to {dev}."
            state, level = "PASS", "pass"
        else:
            detail = f"USB operation FAILED. {res.get('error') or res.get('status')}"
            state, level = "FAILED", "failed"
        self.root.after(0, lambda: (self.set_status("usb_status", state, detail, level), self.log_output("=== USB ISO Creator Details ===\n" + json.dumps(res, indent=2), "usb")))
    threading.Thread(target=worker, daemon=True).start()


# Apply v0.5 GUI status patches.
ForgeGUI._status_panel = _v05_status_panel
ForgeGUI.set_status = _v05_set_status
ForgeGUI._build_dashboard = _v05_build_dashboard
ForgeGUI.gui_init_workspace = _v05_gui_init_workspace
ForgeGUI.gui_diagnostics = _v05_gui_diagnostics
ForgeGUI._build_extractor = _v05_build_extractor
ForgeGUI.gui_inspect_archive = _v05_gui_inspect_archive
ForgeGUI.gui_extract_archive = _v05_gui_extract_archive
ForgeGUI._build_usb = _v05_build_usb
ForgeGUI.gui_list_devices = _v05_gui_list_devices
ForgeGUI.gui_write_usb = _v05_gui_write_usb



# ------------------------- v0.6 package/ISO/release UX + AEGIS polish -------------------------
def validate_deb_package(path: Path) -> Dict[str, object]:
    """Validate a built .deb enough for user-facing confirmation."""
    path = path.expanduser().resolve()
    if not path.exists() or not path.is_file() or path.suffix.lower() != ".deb":
        return {"status": "error", "error": "Package is not a .deb file", "package": str(path)}
    info_rc, info_out = run_cmd(["dpkg-deb", "--info", str(path)], timeout=60)
    contents_rc, contents_out = run_cmd(["dpkg-deb", "--contents", str(path)], timeout=60)
    ok = info_rc == 0 and contents_rc == 0
    return {
        "status": "ok" if ok else "error",
        "package": str(path),
        "size": path.stat().st_size,
        "sha256": sha256_file(path) if ok else None,
        "info_ok": info_rc == 0,
        "contents_ok": contents_rc == 0,
        "info_preview": "\n".join((info_out or "").splitlines()[:30]),
        "contents_preview": "\n".join((contents_out or "").splitlines()[:40]),
    }


def scan_quarantine_placeholder(path: Optional[Path] = None) -> Dict[str, object]:
    """Placeholder handshake for future S.C.A.N integration."""
    target = (path or (DEFAULT_WORKSPACE / "02_Extracted" / "Quarantine")).expanduser()
    scanner = shutil.which("sentinel-scan") or shutil.which("aegis-scan") or shutil.which("scan")
    if not scanner:
        return {
            "status": "unavailable",
            "target": str(target),
            "scanner": None,
            "message": "S.C.A.N scanner is not connected yet. Quarantine contents remain UNVERIFIED.",
        }
    return {
        "status": "available",
        "target": str(target),
        "scanner": scanner,
        "message": "Scanner command detected. Automatic scan execution will be wired in a later F.O.R.G.E phase.",
    }


def forge_permissions() -> Dict[str, object]:
    return {
        "program": PROGRAM_NUMBER,
        "app": APP_NAME,
        "version": VERSION,
        "standing_local_authority": True,
        "network_default": "disabled",
        "permissions": {
            "inspect_archive": "allowed",
            "extract_to_quarantine": "allowed",
            "build_deb": "allowed_with_local_inputs",
            "build_tar": "allowed_with_local_inputs",
            "create_iso_staging": "allowed",
            "build_iso": "allowed_with_local_inputs",
            "release_manifest": "allowed",
            "usb_write": "critical_guarded_requires_ERASE_and_device_selection",
            "internet_or_repository_access": "blocked_until_explicit_user_permission",
            "scan_quarantine": "placeholder_until_SCAN_connected",
        },
    }


def _v06_build_deb_from_project(project: Path, package_id: Optional[str] = None, version: str = "0.1", app_name: Optional[str] = None, command: Optional[str] = None, description: str = "Built by F.O.R.G.E", output_dir: Optional[Path] = None, create_desktop: bool = True, icon_path: Optional[Path] = None, depends: str = "python3", maintainer: str = "SentinelOS <root@localhost>") -> Dict[str, object]:
    prepared, cleanup_root, prep = prepare_project_input(project)
    if not prepared:
        audit("build-deb", str(project), "blocked", prep)
        return prep
    package_id = sanitize_id(package_id or prepared.name)
    app_name = app_name or package_id.replace("-", " ").title()
    command = sanitize_id(command or detect_command_from_project(prepared, package_id))
    version = (version or "0.1").strip()
    depends = (depends or "python3").strip()
    maintainer = (maintainer or "SentinelOS <root@localhost>").strip()
    output_dir = (output_dir or DEFAULT_WORKSPACE / "03_Packages").expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    entry = find_entrypoint(prepared)
    build_root = Path(tempfile.mkdtemp(prefix="forge-deb-v06-"))
    try:
        pkg_root = build_root / f"{package_id}_{version}-1_all"
        debian = pkg_root / "DEBIAN"
        app_dir = pkg_root / "opt" / "sentinel-apps" / package_id
        bin_dir = pkg_root / "usr" / "bin"
        app_share = pkg_root / "usr" / "share" / "applications"
        icon_share = pkg_root / "usr" / "share" / "icons" / "hicolor" / "512x512" / "apps"
        for d in [debian, app_dir, bin_dir]: d.mkdir(parents=True, exist_ok=True)
        shutil.copytree(prepared, app_dir, dirs_exist_ok=True)
        for fp in app_dir.rglob("*"):
            if fp.is_file():
                try: fp.chmod(fp.stat().st_mode & ~0o022)
                except Exception: pass
        control = f"""Package: {package_id}
Version: {version}-1
Section: utils
Priority: optional
Architecture: all
Depends: {depends}
Maintainer: {maintainer}
Description: {description}
 Built by F.O.R.G.E Program 120.
"""
        (debian / "control").write_text(control, encoding="utf-8")
        wrapper = bin_dir / command
        if entry:
            entry_path = f"/opt/sentinel-apps/{package_id}/{entry}"
            if entry.endswith(".py"):
                wrapper_text = f"#!/bin/sh\nexec python3 '{entry_path}' \"$@\"\n"
            elif entry.endswith(".sh"):
                wrapper_text = f"#!/bin/sh\nexec sh '{entry_path}' \"$@\"\n"
            else:
                wrapper_text = f"#!/bin/sh\nexec '{entry_path}' \"$@\"\n"
        else:
            wrapper_text = f"#!/bin/sh\necho '{app_name} installed at /opt/sentinel-apps/{package_id}'\n"
        wrapper.write_text(wrapper_text, encoding="utf-8"); wrapper.chmod(0o755)
        if create_desktop:
            app_share.mkdir(parents=True, exist_ok=True)
            icon_name = package_id
            if icon_path and icon_path.expanduser().exists():
                icon_share.mkdir(parents=True, exist_ok=True)
                src = icon_path.expanduser().resolve()
                suffix = src.suffix.lower() if src.suffix else ".png"
                shutil.copy2(src, icon_share / f"{package_id}{suffix}")
            desktop = f"""[Desktop Entry]
Type=Application
Name={app_name}
Comment={description}
Exec={command}
Icon={icon_name}
Terminal=false
Categories=Utility;System;
"""
            (app_share / f"{package_id}.desktop").write_text(desktop, encoding="utf-8")
        deb_path = output_dir / f"{package_id}_{version}-1_all.deb"
        rc, out = run_cmd(["dpkg-deb", "--build", str(pkg_root), str(deb_path)], timeout=180)
        status = "ok" if rc == 0 and deb_path.exists() else "error"
        validation = validate_deb_package(deb_path) if status == "ok" else {"status": "skipped"}
        res = {"status": status, "project": str(prepared), "package_id": package_id, "version": version, "command": command, "entrypoint": entry, "deb": str(deb_path), "output": out, "validation": validation, "prepared_input": prep, "scanner_status": "unverified-quarantine" if prep.get("source_type") == "zip" else "not-scanned"}
        audit("build-deb", str(prepared), status, res)
        return res
    finally:
        shutil.rmtree(build_root, ignore_errors=True)

# Replace current builder with v0.6 metadata-aware version.
build_deb_from_project = _v06_build_deb_from_project


def _v06_build_package(self, parent) -> None:
    tk, ttk = self.tk, self.ttk
    self._section(parent, "Package Builder", "Build .deb wrappers and .tar.gz release bundles from a project folder or .zip project. ZIP inputs are extracted into F.O.R.G.E quarantine first.")
    form = ttk.Frame(parent); form.pack(fill="x", pady=6)
    self.project_var = tk.StringVar(); self.pkg_id_var = tk.StringVar(); self.pkg_name_var = tk.StringVar(); self.pkg_version_var = tk.StringVar(value="0.1"); self.pkg_cmd_var = tk.StringVar(); self.pkg_depends_var = tk.StringVar(value="python3"); self.pkg_maintainer_var = tk.StringVar(value="SentinelOS <root@localhost>"); self.pkg_desc_var = tk.StringVar(value="SentinelOS application built by F.O.R.G.E"); self.pkg_icon_var = tk.StringVar()
    rows = [("Project Folder / .zip:", self.project_var), ("Package ID:", self.pkg_id_var), ("Application Name:", self.pkg_name_var), ("Version:", self.pkg_version_var), ("Command:", self.pkg_cmd_var), ("Dependencies:", self.pkg_depends_var), ("Maintainer:", self.pkg_maintainer_var), ("Description:", self.pkg_desc_var), ("Package Icon:", self.pkg_icon_var)]
    for i,(lab,var) in enumerate(rows):
        ttk.Label(form, text=lab).grid(row=i, column=0, sticky="w", pady=3, padx=(0,6))
        ent = ttk.Entry(form, textvariable=var); ent.grid(row=i, column=1, sticky="ew", pady=3)
        if i == 0:
            ent.bind("<Return>", lambda _e: self.gui_autofill_package_fields())
            self._try_register_drop(ent, self.project_var, self.gui_autofill_package_fields)
            ttk.Button(form, text="Choose", command=self.choose_project).grid(row=i, column=2, padx=6)
            ttk.Button(form, text="Paste", command=lambda: self.paste_to(self.project_var, self.gui_autofill_package_fields)).grid(row=i, column=3, padx=6)
        elif i == 4:
            ttk.Button(form, text="Auto Fill", command=self.gui_autofill_package_fields).grid(row=i, column=2, padx=6)
        elif i == 8:
            ttk.Button(form, text="Choose Icon", command=self.choose_icon).grid(row=i, column=2, padx=6)
    form.columnconfigure(1, weight=1)
    btns = ttk.Frame(parent); btns.pack(fill="x", pady=6)
    ttk.Button(btns, text="Validate Project", command=self.gui_validate_project).pack(side="left", padx=(0,8))
    ttk.Button(btns, text="Build .deb", command=self.gui_build_deb).pack(side="left", padx=8)
    ttk.Button(btns, text="Build .tar.gz", command=self.gui_build_tar).pack(side="left", padx=8)
    ttk.Button(btns, text="Open Packages", command=lambda: self.open_path(DEFAULT_WORKSPACE / "03_Packages")).pack(side="left", padx=8)
    self._status_panel(parent, "package_status", "Package Builder Status")
    self._add_output(parent, "package", 10)


def _v06_gui_validate_project(self) -> None:
    src = Path(self.project_var.get().strip()).expanduser()
    self.set_status("package_status", "Validating Project...", f"Checking input: {src}", "running")
    prepared, cleanup_root, prep = prepare_project_input(src)
    issues = []
    if not prepared:
        issues.append(prep.get("error") or prep.get("status") or "Project input could not be prepared")
    else:
        if not any(prepared.iterdir()): issues.append("Prepared project folder is empty")
        if not self.pkg_cmd_var.get().strip():
            self.pkg_cmd_var.set(detect_command_from_project(prepared, self.pkg_id_var.get().strip() or prepared.name))
        if self.pkg_icon_var.get().strip() and not Path(self.pkg_icon_var.get().strip()).expanduser().exists():
            issues.append("Selected icon does not exist")
    if shutil.which("dpkg-deb") is None:
        issues.append("dpkg-deb is missing")
    if issues:
        self.set_status("package_status", "FAILED", "Project validation found issues:\n- " + "\n- ".join(map(str, issues)), "failed")
    else:
        self.set_status("package_status", "PASS", f"Project validation PASS. Prepared project: {prepared}", "pass")
    self.log_output("=== Package Project Validation ===\n" + json.dumps({"input": str(src), "prepared": str(prepared) if prepared else None, "issues": issues, "prep": prep, "command": self.pkg_cmd_var.get()}, indent=2), "package")


def _v06_gui_build_deb(self) -> None:
    project = Path(self.project_var.get().strip()).expanduser(); package_id = self.pkg_id_var.get().strip() or None; app_name = self.pkg_name_var.get().strip() or None; version = self.pkg_version_var.get().strip() or "0.1"; command = self.pkg_cmd_var.get().strip() or None; desc = self.pkg_desc_var.get().strip() or "Built by F.O.R.G.E"; icon = Path(self.pkg_icon_var.get().strip()).expanduser() if self.pkg_icon_var.get().strip() else None; depends = self.pkg_depends_var.get().strip() or "python3"; maintainer = self.pkg_maintainer_var.get().strip() or "SentinelOS <root@localhost>"
    self.set_status("package_status", "Building .deb...", "Preparing input, copying project files, creating launcher, and building Debian package.", "running")
    def worker():
        res = build_deb_from_project(project, package_id, version, app_name, command, desc, icon_path=icon, depends=depends, maintainer=maintainer)
        if res.get("status") == "ok":
            detail = f".deb build COMPLETE.\nOutput: {res.get('deb')}\nSHA256: {res.get('validation', {}).get('sha256')}"
            state, level = "PASS", "pass"
        else:
            detail = f".deb build FAILED. {res.get('error') or res.get('status')}"
            state, level = "FAILED", "failed"
        self.root.after(0, lambda: (self.set_status("package_status", state, detail, level), self.log_output("=== .deb Build Details ===\n" + json.dumps(res, indent=2), "package")))
    threading.Thread(target=worker, daemon=True).start()


def _v06_gui_build_tar(self) -> None:
    project = Path(self.project_var.get().strip()).expanduser(); package_id = self.pkg_id_var.get().strip() or None; version = self.pkg_version_var.get().strip() or "0.1"
    self.set_status("package_status", "Building .tar.gz...", "Preparing input and creating compressed project bundle.", "running")
    def worker():
        res = build_tar_from_project(project, package_id, version)
        if res.get("status") == "ok":
            detail = f".tar.gz bundle COMPLETE.\nOutput: {res.get('tar')}\nSHA256: {res.get('sha256')}"
            state, level = "PASS", "pass"
        else:
            detail = f".tar.gz build FAILED. {res.get('error') or res.get('status')}"
            state, level = "FAILED", "failed"
        self.root.after(0, lambda: (self.set_status("package_status", state, detail, level), self.log_output("=== .tar.gz Build Details ===\n" + json.dumps(res, indent=2), "package")))
    threading.Thread(target=worker, daemon=True).start()


def _v06_build_iso(self, parent) -> None:
    tk, ttk = self.tk, self.ttk
    self._section(parent, "ISO Builder", "Create ISO staging trees and build ISO images using xorriso/genisoimage/mkisofs when available.")
    summary = "Preparation summary:\n• Create or select a staging tree.\n• Place live/installer files in the staging folder.\n• Add boot assets under isolinux/ or boot/grub/ for bootable output.\n• Build ISO. Without boot assets, F.O.R.G.E creates a data ISO."
    ttk.Label(parent, text=summary, style="Muted.TLabel", wraplength=900).pack(anchor="w", pady=(0,8))
    form = ttk.Frame(parent); form.pack(fill="x", pady=6)
    self.iso_name_var = tk.StringVar(value="sentinelos-iso-staging"); self.iso_stage_var = tk.StringVar(value=str(DEFAULT_WORKSPACE / "04_ISO_Staging" / "sentinelos-iso-staging")); self.iso_out_var = tk.StringVar(value=str(DEFAULT_WORKSPACE / "09_ISO_Output" / "sentinelos.iso")); self.iso_label_var = tk.StringVar(value="SENTINELOS")
    rows = [("Staging Name:", self.iso_name_var), ("Staging Folder:", self.iso_stage_var), ("Output ISO:", self.iso_out_var), ("Volume Label:", self.iso_label_var)]
    for i,(lab,var) in enumerate(rows):
        ttk.Label(form, text=lab).grid(row=i, column=0, sticky="w", pady=3, padx=(0,6)); ent = ttk.Entry(form, textvariable=var); ent.grid(row=i, column=1, sticky="ew", pady=3)
        if i == 1: ttk.Button(form, text="Choose", command=lambda: self.choose_dir(self.iso_stage_var)).grid(row=i, column=2, padx=6)
        if i == 2: ttk.Button(form, text="Choose", command=lambda: self.choose_file_save(self.iso_out_var, ".iso")).grid(row=i, column=2, padx=6)
    form.columnconfigure(1, weight=1)
    btns = ttk.Frame(parent); btns.pack(fill="x", pady=6)
    ttk.Button(btns, text="Create Staging Tree", command=self.gui_iso_staging).pack(side="left", padx=(0,8))
    ttk.Button(btns, text="Build ISO", command=self.gui_build_iso).pack(side="left", padx=8)
    ttk.Button(btns, text="Open ISO Output", command=lambda: self.open_path(DEFAULT_WORKSPACE / "09_ISO_Output")).pack(side="left", padx=8)
    self._status_panel(parent, "iso_status", "ISO Builder Status")
    self._add_output(parent, "iso", 9)


def _v06_choose_file_save(self, var, default_ext: str = "") -> None:
    from tkinter import filedialog
    p = filedialog.asksaveasfilename(title="Choose output file", defaultextension=default_ext or None)
    if p: var.set(p)


def _v06_gui_iso_staging(self) -> None:
    self.set_status("iso_status", "Creating ISO Staging Tree...", "Preparing folders and ISO build summary.", "running")
    res = create_iso_staging(self.iso_name_var.get().strip())
    if res.get("status") == "ok":
        self.iso_stage_var.set(res.get("staging", self.iso_stage_var.get()))
        self.set_status("iso_status", "PASS", f"ISO staging tree COMPLETE.\nStaging: {res.get('staging')}\nSummary: {res.get('summary')}", "pass")
    else:
        self.set_status("iso_status", "FAILED", f"ISO staging FAILED. {res.get('error') or res.get('status')}", "failed")
    self.log_output("=== ISO Staging Details ===\n" + json.dumps(res, indent=2), "iso")


def _v06_gui_build_iso(self) -> None:
    staging = Path(self.iso_stage_var.get().strip()).expanduser(); out = Path(self.iso_out_var.get().strip()).expanduser(); label = self.iso_label_var.get().strip() or "SENTINELOS"
    self.set_status("iso_status", "Building ISO...", f"Staging: {staging}\nOutput: {out}", "running")
    def worker():
        res = build_iso_from_staging(staging, out, label)
        if res.get("status") == "ok":
            detail = f"ISO build COMPLETE.\nOutput: {res.get('iso')}\nSHA256: {res.get('sha256')}"
            state, level = "PASS", "pass"
        else:
            detail = f"ISO build FAILED. {res.get('error') or res.get('status')}"
            state, level = "FAILED", "failed"
        self.root.after(0, lambda: (self.set_status("iso_status", state, detail, level), self.log_output("=== ISO Build Details ===\n" + json.dumps(res, indent=2), "iso")))
    threading.Thread(target=worker, daemon=True).start()


def _v06_build_release(self, parent) -> None:
    tk, ttk = self.tk, self.ttk
    self._section(parent, "Release Generator", "Generate SHA256SUMS and MANIFEST.json for a local release folder.")
    row = ttk.Frame(parent); row.pack(fill="x", pady=6)
    ttk.Label(row, text="Release Folder:").pack(side="left", padx=(0,8))
    self.release_var = tk.StringVar(value=str(DEFAULT_WORKSPACE / "05_Releases")); ent = ttk.Entry(row, textvariable=self.release_var); ent.pack(side="left", fill="x", expand=True); self._try_register_drop(ent, self.release_var)
    ttk.Button(row, text="Choose", command=lambda: self.choose_dir(self.release_var)).pack(side="left", padx=8)
    ttk.Button(row, text="Generate Manifest", command=self.gui_release_manifest).pack(side="left")
    self._status_panel(parent, "release_status", "Release Generator Status")
    self._add_output(parent, "release", 12)


def _v06_gui_release_manifest(self) -> None:
    folder = Path(self.release_var.get().strip()).expanduser()
    self.set_status("release_status", "Generating Release Manifest...", f"Folder: {folder}", "running")
    def worker():
        res = generate_release_manifest(folder)
        if res.get("status") == "ok":
            detail = f"Release manifest COMPLETE.\nFiles: {res.get('file_count')}\nManifest: {res.get('manifest')}\nSHA256SUMS: {res.get('sha256sums')}"
            state, level = "PASS", "pass"
        else:
            detail = f"Release manifest FAILED. {res.get('error') or res.get('status')}"
            state, level = "FAILED", "failed"
        self.root.after(0, lambda: (self.set_status("release_status", state, detail, level), self.log_output("=== Release Generator Details ===\n" + json.dumps(res, indent=2), "release")))
    threading.Thread(target=worker, daemon=True).start()


def _v06_build_manual(self, parent) -> None:
    self._section(parent, "Manual", "F.O.R.G.E Program 120 GUI and installer manual.")
    text = self.tk.Text(parent, bg=THEME_TREE, fg=THEME_TEXT, insertbackground=THEME_GOLD, relief="flat", wrap="word")
    text.pack(fill="both", expand=True)
    manual = f"""
F.O.R.G.E — File Output & Release Generation Engine
Program 120 — v{VERSION}

Purpose
F.O.R.G.E is the SentinelOS builder workstation. It owns builder/export work removed from Sentinel Program Manager.

User-facing modules
1. Extractor
   Inspect and extract .zip, .tar.*, and .deb archives. Default extraction uses F.O.R.G.E quarantine/staging. Future S.C.A.N integration will verify quarantine contents before release/use.

2. Package Builder
   Build simple Debian .deb wrappers and .tar.gz project bundles from local project folders or .zip project archives. ZIP projects are extracted into quarantine first. v0.6 adds project validation, dependencies, maintainer metadata, icon selection, command auto-fill, and clear PASS/FAILED build status.

3. ISO Builder
   Create staging trees and build ISO images. Bootable output requires valid boot assets; otherwise a data ISO can be generated. v0.6 adds visible ISO status panels.

4. USB ISO Creator
   Write ISO images to selectable removable USB devices using dd. Internal/non-removable drives are hidden by default. Requires typed ERASE confirmation and root/pkexec/sudo.

5. Release Generator
   Generate MANIFEST.json and SHA256SUMS for release folders. v0.6 adds visible release status panels.

AEGIS Compatibility
forge --forge-status --json
forge --forge-actions --json
forge --forge-diagnostics --json
forge --aegis-status --json
forge --aegis-actions --json
forge --aegis-diagnostics --json
forge --forge-run <action>
forge --aegis-run <action>

Clipboard / Selection
- Ctrl+C, Ctrl+V, Ctrl+X, and Ctrl+A work across normal fields and output panes.
- Right-click fields, output panes, and tables for Cut/Copy/Paste/Select All.
- Tables copy selected rows as tab-separated text for easy notes or reports.

Rules
- Local-first.
- No internet required.
- USB writing is destructive and requires explicit confirmation.
- Archive extraction is inspected before use.
- Quarantine content remains unverified until S.C.A.N integration is connected.
""".strip()
    text.insert("1.0", manual); text.configure(state="disabled")

# Apply v0.6 GUI/UX patches.
ForgeGUI._build_package = _v06_build_package
ForgeGUI.gui_validate_project = _v06_gui_validate_project
ForgeGUI.gui_build_deb = _v06_gui_build_deb
ForgeGUI.gui_build_tar = _v06_gui_build_tar
ForgeGUI._build_iso = _v06_build_iso
ForgeGUI.choose_file_save = _v06_choose_file_save
ForgeGUI.gui_iso_staging = _v06_gui_iso_staging
ForgeGUI.gui_build_iso = _v06_gui_build_iso
ForgeGUI._build_release = _v06_build_release
ForgeGUI.gui_release_manifest = _v06_gui_release_manifest
ForgeGUI._build_manual = _v06_build_manual

# Extend status/actions with AEGIS permissions and scan placeholder.
_forge_status_v05 = forge_status
_forge_actions_v05 = forge_actions

def forge_status() -> Dict[str, object]:
    s = _forge_status_v05()
    s["version"] = VERSION
    s["aegis_aliases"] = True
    s["permissions"] = forge_permissions()
    s["scan_quarantine"] = scan_quarantine_placeholder()
    return s


def forge_actions() -> Dict[str, object]:
    a = _forge_actions_v05()
    a["actions"].extend([
        {"name": "validate-deb", "risk": "low", "network": False},
        {"name": "scan-quarantine", "risk": "low", "network": False, "status": "placeholder"},
        {"name": "permissions", "risk": "low", "network": False},
    ])
    return a


def print_json(obj: object) -> int:
    print(json.dumps(obj, indent=2, ensure_ascii=False))
    return 0


def cli(argv: List[str]) -> int:
    # AEGIS-compatible aliases: keep F.O.R.G.E native commands while allowing suite-standard AEGIS calls.
    alias_map = {
        "--aegis-status": "--forge-status",
        "--aegis-actions": "--forge-actions",
        "--aegis-diagnostics": "--forge-diagnostics",
        "--aegis-run": "--forge-run",
        "--aegis-dry-run": "--forge-dry-run",
    }
    argv = [alias_map.get(a, a) for a in argv]
    parser = argparse.ArgumentParser(prog="forge", description=APP_LONG_NAME)
    parser.add_argument("--version", action="store_true")
    parser.add_argument("--forge-status", action="store_true")
    parser.add_argument("--forge-actions", action="store_true")
    parser.add_argument("--forge-diagnostics", action="store_true")
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--forge-dry-run", nargs="+", metavar=("ACTION"))
    parser.add_argument("--forge-run", nargs="+", metavar=("ACTION"))
    args = parser.parse_args(argv)
    if args.version: print(VERSION); return 0
    if args.forge_status: return print_json(forge_status()) if args.json else (print(f"{APP_LONG_NAME} v{VERSION}") or 0)
    if args.forge_actions: return print_json(forge_actions()) if args.json else (print("\n".join(a["name"] for a in forge_actions()["actions"])) or 0)
    if args.forge_diagnostics: return print_json(diagnostics()) if args.json else (print(json.dumps(diagnostics(), indent=2)) or 0)
    action_args = args.forge_dry_run or args.forge_run
    dry = args.forge_dry_run is not None
    if action_args:
        action, rest = action_args[0], action_args[1:]
        if action == "init-workspace":
            root = Path(rest[0]).expanduser() if rest else DEFAULT_WORKSPACE
            return print_json({"status": "dry-run", "would_create": [str(p) for p in default_workspace_tree(root)]} if dry else init_workspace(root))
        if action == "inspect-archive":
            if not rest: return print_json({"status": "error", "error": "archive path required"})
            return print_json(asdict(inspect_archive(Path(rest[0]))))
        if action == "extract":
            if not rest: return print_json({"status": "error", "error": "archive path required"})
            archive = Path(rest[0]); dest = Path(rest[1]) if len(rest) > 1 else DEFAULT_WORKSPACE / "02_Extracted" / sanitize_id(archive.stem)
            return print_json({"status": "dry-run", "check": asdict(inspect_archive(archive)), "destination": str(dest)} if dry else safe_extract_archive(archive, dest))
        if action == "build-deb":
            if not rest: return print_json({"status": "error", "error": "project path required"})
            project = Path(rest[0]); package_id = rest[1] if len(rest) > 1 else None; version = rest[2] if len(rest) > 2 else "0.1"
            return print_json({"status": "dry-run", "project": str(project), "package_id": sanitize_id(package_id or project.name), "version": version} if dry else build_deb_from_project(project, package_id, version))
        if action == "build-tar":
            if not rest: return print_json({"status": "error", "error": "project path required"})
            project = Path(rest[0]); package_id = rest[1] if len(rest) > 1 else None; version = rest[2] if len(rest) > 2 else "0.1"
            return print_json({"status": "dry-run", "project": str(project), "package_id": sanitize_id(package_id or project.name), "version": version} if dry else build_tar_from_project(project, package_id, version))
        if action == "create-iso-staging":
            name = rest[0] if rest else "sentinelos-iso-staging"
            return print_json({"status": "dry-run", "staging": str((DEFAULT_WORKSPACE / "04_ISO_Staging" / sanitize_id(name)).expanduser())} if dry else create_iso_staging(name))
        if action == "build-iso":
            if not rest: return print_json({"status": "error", "error": "staging path required"})
            staging = Path(rest[0]); out = Path(rest[1]) if len(rest) > 1 else None; label = rest[2] if len(rest) > 2 else "SENTINELOS"
            return print_json({"status": "dry-run", "staging": str(staging), "output": str(out) if out else None, "label": label, "tool": iso_tool()} if dry else build_iso_from_staging(staging, out, label))
        if action == "list-usb-devices":
            return print_json(list_usb_devices())
        if action == "write-usb":
            if len(rest) < 3: return print_json({"status": "error", "error": "usage: write-usb <iso> <device> ERASE"})
            return print_json(write_iso_to_usb(Path(rest[0]), rest[1], rest[2], dry_run=dry))
        if action == "release-manifest":
            if not rest: return print_json({"status": "error", "error": "folder path required"})
            folder = Path(rest[0])
            return print_json({"status": "dry-run", "folder": str(folder), "file_count": len(walk_manifest(folder)) if folder.exists() else 0} if dry else generate_release_manifest(folder))
        if action == "validate-deb":
            if not rest: return print_json({"status": "error", "error": ".deb path required"})
            return print_json(validate_deb_package(Path(rest[0])))
        if action == "scan-quarantine":
            target = Path(rest[0]) if rest else None
            return print_json(scan_quarantine_placeholder(target))
        if action == "permissions":
            return print_json(forge_permissions())
        if action == "clipboard-support":
            return print_json({"status": "ok", "copy": True, "paste": True, "cut": True, "select_all": True, "tables_copy_selected_rows": True, "context_menu": True})
        return print_json({"status": "error", "error": f"unknown action: {action}"})
    try:
        ForgeGUI().run(); return 0
    except Exception:
        ensure_dirs(); crash = traceback.format_exc(); (LOG_DIR / "crash.log").write_text(crash, encoding="utf-8"); print(crash, file=sys.stderr); return 1




# ------------------------- v0.7 / v0.8 ISO, USB, and Release polish -------------------------
# v0.7 focuses on ISO/USB workflow hardening. v0.8 focuses on release packaging profiles.


def removable_usb_devices(include_internal: bool = False) -> Dict[str, object]:
    """Return safe USB target disks, hiding internal/non-removable drives unless advanced mode is enabled."""
    res = list_usb_devices()
    out: List[Dict[str, object]] = []
    for d in res.get("devices", []):
        path = str(d.get("path") or "")
        tran = str(d.get("tran") or "").lower()
        rm = bool(d.get("rm"))
        # Only disk-level devices are eligible. Internal NVMe/SATA disks stay hidden unless advanced override is set.
        removable = rm or tran in ("usb", "mmc") or path.startswith("/dev/sd")
        if include_internal or removable:
            dd = dict(d)
            dd["eligible"] = True if removable or include_internal else False
            dd["warning"] = "Internal/non-removable drive shown by advanced override" if not removable else "Removable target"
            out.append(dd)
    return {"status": res.get("status", "ok"), "devices": out, "raw": res.get("raw", "")}


def unmount_device_partitions(device: str, dry_run: bool = False) -> Dict[str, object]:
    """Unmount all mounted child partitions of a selected disk before writing an ISO."""
    device = (device or "").strip()
    if not re.fullmatch(r"/dev/(sd[a-z]|vd[a-z]|xvd[a-z]|nvme\d+n\d+|mmcblk\d+)", device):
        return {"status": "error", "error": "Refusing unsafe/non-disk device path", "device": device}
    if not shutil.which("lsblk"):
        return {"status": "error", "error": "lsblk not found", "device": device}
    rc, out = run_cmd(["lsblk", "-J", "-o", "PATH,MOUNTPOINTS", device], timeout=30)
    if rc != 0:
        return {"status": "error", "error": out, "device": device}
    mounts: List[str] = []
    try:
        def walk(node):
            m = node.get("mountpoints") or []
            if isinstance(m, str):
                m = [m]
            for x in m:
                if x:
                    mounts.append(str(x))
            for c in node.get("children") or []:
                walk(c)
        for n in json.loads(out).get("blockdevices", []):
            walk(n)
    except Exception as e:
        return {"status": "error", "error": f"Could not parse lsblk output: {e}", "raw": out, "device": device}
    if dry_run:
        return {"status": "dry-run", "device": device, "would_unmount": mounts}
    if not mounts:
        return {"status": "ok", "device": device, "message": "No mounted partitions found."}
    commands = []
    outputs = []
    for m in mounts:
        cmd = ["umount", m]
        if os.geteuid() != 0:
            pkexec = shutil.which("pkexec")
            sudo = shutil.which("sudo")
            if pkexec:
                cmd = [pkexec] + cmd
            elif sudo:
                cmd = [sudo] + cmd
            else:
                return {"status": "error", "error": "Root privileges required to unmount.", "mounts": mounts}
        commands.append(cmd)
        r, o = run_cmd(cmd, timeout=120)
        outputs.append({"mount": m, "returncode": r, "output": o})
        if r != 0:
            audit("unmount-usb", device, "error", {"mount": m, "output": o})
            return {"status": "error", "device": device, "mounts": mounts, "commands": commands, "outputs": outputs}
    audit("unmount-usb", device, "ok", {"mounts": mounts})
    return {"status": "ok", "device": device, "mounts": mounts, "commands": commands, "outputs": outputs}


def verify_iso_file(iso: Path) -> Dict[str, object]:
    iso = iso.expanduser().resolve()
    if not iso.exists() or not iso.is_file() or iso.suffix.lower() != ".iso":
        return {"status": "error", "error": "ISO file does not exist or is not .iso", "iso": str(iso)}
    try:
        return {"status": "ok", "iso": str(iso), "size": iso.stat().st_size, "size_human": human_size(iso.stat().st_size), "sha256": sha256_file(iso)}
    except Exception as e:
        return {"status": "error", "error": str(e), "iso": str(iso)}


def create_iso_profile(staging: Path, output_iso: Optional[Path] = None, label: str = "SENTINELOS") -> Dict[str, object]:
    staging = staging.expanduser().resolve()
    if not staging.exists() or not staging.is_dir():
        return {"status": "error", "error": "Staging folder does not exist", "staging": str(staging)}
    label = sanitize_id(label or "SENTINELOS").upper().replace("-", "_")[:32]
    output_iso = (output_iso or (DEFAULT_WORKSPACE / "09_ISO_Output" / f"{sanitize_id(staging.name)}.iso")).expanduser().resolve()
    profile = {
        "created_at": now_iso(),
        "program": PROGRAM_NUMBER,
        "tool": APP_LONG_NAME,
        "staging": str(staging),
        "output_iso": str(output_iso),
        "volume_label": label,
        "iso_tool_available": iso_tool(),
        "boot_assets": {
            "isolinux": (staging / "isolinux" / "isolinux.bin").exists(),
            "efi_img": (staging / "boot" / "grub" / "efi.img").exists(),
        },
        "instructions": [
            "Place live/installer filesystem files inside the staging tree.",
            "Add isolinux/isolinux.bin for BIOS boot support when required.",
            "Add boot/grub/efi.img for EFI boot support when required.",
            "Run Build ISO after boot/data files are prepared.",
            "Generated ISO files are written to ~/FORGE_Workspace/09_ISO_Output by default.",
        ],
    }
    dest = staging / "FORGE_ISO_PROFILE.json"
    dest.write_text(json.dumps(profile, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    audit("create-iso-profile", str(staging), "ok", {"profile": str(dest)})
    return {"status": "ok", "profile": str(dest), "profile_data": profile}


def create_release_package(source: Path, release_name: str = "", version: str = "1.0", channel: str = "stable", output_root: Optional[Path] = None, lock_candidate: bool = False, make_zip: bool = True) -> Dict[str, object]:
    """Create a versioned release folder, copy release contents, and generate manifest/checksums."""
    source = source.expanduser().resolve()
    if not source.exists() or not source.is_dir():
        return {"status": "error", "error": "Source release folder does not exist", "source": str(source)}
    release_name = sanitize_id(release_name or source.name or "forge-release")
    version = sanitize_id(version or "1.0")
    channel = sanitize_id(channel or "stable")
    suffix = "LOCK_CANDIDATE" if lock_candidate else channel.upper()
    folder_name = f"{release_name}_v{version}_{suffix}"
    output_root = (output_root or (DEFAULT_WORKSPACE / "05_Releases")).expanduser().resolve()
    output_root.mkdir(parents=True, exist_ok=True)
    dest = output_root / folder_name
    if dest.exists():
        return {"status": "error", "error": "Release folder already exists. Choose a new version/name or remove the old output first.", "release_folder": str(dest)}
    try:
        ignore = shutil.ignore_patterns(".git", "__pycache__", "*.pyc", ".DS_Store")
        shutil.copytree(source, dest, ignore=ignore)
        release_notes = dest / "FORGE_RELEASE_SUMMARY.md"
        release_notes.write_text(
            f"# {folder_name}\n\n"
            f"Generated: {now_iso()}\n\n"
            f"Source: `{source}`\n\n"
            f"Channel: `{channel}`\n\n"
            f"Lock candidate: `{lock_candidate}`\n\n"
            "Contents were packaged by F.O.R.G.E Program 120.\n",
            encoding="utf-8",
        )
        manifest = generate_release_manifest(dest, dest)
        zip_path = None
        if make_zip:
            zip_base = output_root / folder_name
            zip_path = shutil.make_archive(str(zip_base), "zip", root_dir=str(output_root), base_dir=folder_name)
        result = {
            "status": "ok",
            "source": str(source),
            "release_folder": str(dest),
            "release_name": release_name,
            "version": version,
            "channel": channel,
            "lock_candidate": lock_candidate,
            "manifest": manifest,
            "zip": zip_path,
        }
        audit("release-package", str(source), "ok", result)
        return result
    except Exception as e:
        audit("release-package", str(source), "error", {"error": str(e)})
        return {"status": "error", "error": str(e), "source": str(source), "release_folder": str(dest)}


# v0.7 ISO Builder GUI: add profile generation and clearer guided actions.
def _v08_build_iso(self, parent) -> None:
    tk, ttk = self.tk, self.ttk
    self._section(parent, "ISO Builder", "Create ISO staging trees, write ISO build profiles, and build ISO images with xorriso/genisoimage/mkisofs when available.")
    self._status_panel(parent, "iso_status", "ISO Builder Status")
    summary = (
        "Preparation summary:\n"
        "• Create or select a staging tree.\n"
        "• Place live/installer files inside the staging folder.\n"
        "• Add isolinux/isolinux.bin and/or boot/grub/efi.img for bootable output.\n"
        "• Create ISO Profile to save a build plan.\n"
        "• Build ISO. Without boot assets, a data ISO can still be generated."
    )
    self.ttk.Label(parent, text=summary, style="Muted.TLabel", wraplength=900).pack(anchor="w", pady=(0,8))
    form = ttk.Frame(parent); form.pack(fill="x", pady=6)
    self.iso_name_var = tk.StringVar(value="sentinelos-live")
    self.iso_staging_var = tk.StringVar(value=str(DEFAULT_WORKSPACE / "04_ISO_Staging" / "sentinelos-live"))
    self.iso_output_var = tk.StringVar(value=str(DEFAULT_WORKSPACE / "09_ISO_Output" / "sentinelos-live.iso"))
    self.iso_label_var = tk.StringVar(value="SENTINELOS")
    rows = [("Staging Name:", self.iso_name_var), ("Staging Folder:", self.iso_staging_var), ("Output ISO:", self.iso_output_var), ("Volume Label:", self.iso_label_var)]
    for i,(lab,var) in enumerate(rows):
        ttk.Label(form, text=lab).grid(row=i, column=0, sticky="w", pady=3, padx=(0,6))
        ttk.Entry(form, textvariable=var).grid(row=i, column=1, sticky="ew", pady=3)
        if i == 1:
            ttk.Button(form, text="Choose", command=lambda: self.choose_dir(self.iso_staging_var)).grid(row=i, column=2, padx=6)
        elif i == 2:
            ttk.Button(form, text="Choose", command=lambda: self.choose_file_save(self.iso_output_var, ".iso")).grid(row=i, column=2, padx=6)
    form.columnconfigure(1, weight=1)
    btns = ttk.Frame(parent); btns.pack(fill="x", pady=6)
    ttk.Button(btns, text="Create Staging", command=self.gui_iso_staging).pack(side="left", padx=(0,8))
    ttk.Button(btns, text="Create ISO Profile", command=self.gui_create_iso_profile).pack(side="left", padx=8)
    ttk.Button(btns, text="Build ISO", command=self.gui_build_iso).pack(side="left", padx=8)
    ttk.Button(btns, text="Open ISO Output", command=lambda: self.open_path(DEFAULT_WORKSPACE / "09_ISO_Output")).pack(side="left", padx=8)
    self._add_output(parent, "iso", 11)


def _v08_gui_create_iso_profile(self) -> None:
    staging = Path(self.iso_staging_var.get().strip()).expanduser()
    output = Path(self.iso_output_var.get().strip()).expanduser() if self.iso_output_var.get().strip() else None
    label = self.iso_label_var.get().strip() or "SENTINELOS"
    self.set_status("iso_status", "Writing ISO profile...", "Saving the ISO build profile and preparation summary.", "running")
    def worker():
        res = create_iso_profile(staging, output, label)
        if res.get("status") == "ok":
            state, detail, level = "PASS", f"ISO profile COMPLETE.\nProfile: {res.get('profile')}", "pass"
        else:
            state, detail, level = "FAILED", f"ISO profile FAILED. {res.get('error')}", "failed"
        self.root.after(0, lambda: (self.set_status("iso_status", state, detail, level), self.log_output("=== ISO Profile Details ===\n" + json.dumps(res, indent=2), "iso")))
    threading.Thread(target=worker, daemon=True).start()


# v0.7 USB GUI: device selection, unmount, verify, clearer PASS/FAILED state.
def _v08_build_usb(self, parent) -> None:
    tk, ttk = self.tk, self.ttk
    self._section(parent, "USB ISO Creator", "Create live USB installers from ISO files. Uses dd with guarded confirmation. Internal drives are hidden by default.")
    self._status_panel(parent, "usb_status", "USB ISO Creator Status")
    form = ttk.Frame(parent); form.pack(fill="x", pady=6)
    self.usb_iso_var = tk.StringVar(); self.usb_dev_var = tk.StringVar(); self.usb_confirm_var = tk.StringVar(); self.usb_devices_text = tk.StringVar(value="Click Refresh Devices to list usable removable USB targets."); self.usb_show_internal_var=tk.BooleanVar(value=False)
    ttk.Label(form, text="ISO File:").grid(row=0, column=0, sticky="w", pady=3, padx=(0,6)); ttk.Entry(form, textvariable=self.usb_iso_var).grid(row=0, column=1, sticky="ew", pady=3)
    ttk.Button(form, text="Choose", command=self.choose_iso).grid(row=0, column=2, padx=6); ttk.Button(form, text="Paste", command=lambda: self.paste_to(self.usb_iso_var)).grid(row=0, column=3, padx=6)
    ttk.Label(form, text="Selected Disk:").grid(row=1, column=0, sticky="w", pady=3, padx=(0,6)); ttk.Entry(form, textvariable=self.usb_dev_var, state="readonly").grid(row=1, column=1, sticky="ew", pady=3)
    ttk.Button(form, text="Refresh Devices", command=self.gui_list_devices).grid(row=1, column=2, padx=6)
    adv = self.tk.Checkbutton(form, text="Advanced: show internal/non-removable disks", variable=self.usb_show_internal_var, bg=THEME_BG, fg=THEME_TEXT, selectcolor=THEME_TREE, activebackground=THEME_BG, activeforeground=THEME_GOLD, command=self.gui_list_devices)
    adv.grid(row=2, column=1, sticky="w", pady=3)
    ttk.Label(form, text="Type ERASE:").grid(row=3, column=0, sticky="w", pady=3, padx=(0,6)); ttk.Entry(form, textvariable=self.usb_confirm_var).grid(row=3, column=1, sticky="ew", pady=3)
    form.columnconfigure(1, weight=1)
    self.usb_device_frame = ttk.Frame(parent); self.usb_device_frame.pack(fill="x", pady=(4,6))
    ttk.Label(parent, textvariable=self.usb_devices_text, style="Muted.TLabel", wraplength=900).pack(anchor="w", pady=4)
    btns = ttk.Frame(parent); btns.pack(fill="x", pady=6)
    ttk.Button(btns, text="Verify ISO", command=self.gui_verify_iso).pack(side="left", padx=(0,8))
    ttk.Button(btns, text="Unmount Selected", command=lambda: self.gui_unmount_usb(False)).pack(side="left", padx=8)
    ttk.Button(btns, text="Dry Run", command=lambda: self.gui_write_usb(True)).pack(side="left", padx=8)
    ttk.Button(btns, text="WRITE USB", command=lambda: self.gui_write_usb(False)).pack(side="left", padx=8)
    self._add_output(parent, "usb", 11)
    self.gui_list_devices()


def _v08_gui_list_devices(self) -> None:
    try:
        for child in getattr(self, "usb_device_frame", []).winfo_children():
            child.destroy()
    except Exception:
        pass
    include_internal = bool(getattr(self, "usb_show_internal_var", None) and self.usb_show_internal_var.get())
    self.set_status("usb_status", "Refreshing devices...", "Checking available USB target disks.", "running")
    res = removable_usb_devices(include_internal=include_internal)
    devices = res.get("devices", [])
    if not devices:
        msg = "No usable removable USB target disks found. Insert a USB drive and click Refresh Devices."
        self.usb_devices_text.set(msg)
        self.set_status("usb_status", "FAILED", msg, "failed")
    else:
        msg = f"{len(devices)} target disk(s) available. Select one target before writing."
        self.usb_devices_text.set(msg)
        self.set_status("usb_status", "PASS", msg, "pass")
    for d in devices:
        path = str(d.get("path") or "")
        warning = str(d.get("warning") or "")
        label = f"{path}   {d.get('size') or ''}   {d.get('model') or ''}   {d.get('tran') or ''}   {warning}"
        rb = self.tk.Radiobutton(self.usb_device_frame, text=label, variable=self.usb_dev_var, value=path, anchor="w", bg=THEME_BG, fg=THEME_TEXT, selectcolor=THEME_TREE, activebackground=THEME_BG, activeforeground=THEME_GOLD)
        rb.pack(fill="x", anchor="w", pady=2)
    self.log_output("=== USB Device Refresh ===\n" + json.dumps(res, indent=2), "usb")


def _v08_gui_verify_iso(self) -> None:
    iso = Path(self.usb_iso_var.get().strip()).expanduser()
    self.set_status("usb_status", "Verifying ISO...", "Calculating ISO size and SHA256 checksum.", "running")
    def worker():
        res = verify_iso_file(iso)
        if res.get("status") == "ok":
            detail = f"ISO verification PASS.\nSize: {res.get('size_human')}\nSHA256: {res.get('sha256')}"
            state, level = "PASS", "pass"
        else:
            detail = f"ISO verification FAILED. {res.get('error')}"
            state, level = "FAILED", "failed"
        self.root.after(0, lambda: (self.set_status("usb_status", state, detail, level), self.log_output("=== ISO Verification Details ===\n" + json.dumps(res, indent=2), "usb")))
    threading.Thread(target=worker, daemon=True).start()


def _v08_gui_unmount_usb(self, dry: bool = False) -> None:
    dev = self.usb_dev_var.get().strip()
    self.set_status("usb_status", "Unmounting selected target...", f"Target: {dev}", "running")
    def worker():
        res = unmount_device_partitions(dev, dry_run=dry)
        if res.get("status") in ("ok", "dry-run"):
            detail = f"Unmount operation PASS.\nTarget: {dev}\nMounted partitions handled: {len(res.get('mounts') or res.get('would_unmount') or [])}"
            state, level = "PASS", "pass"
        else:
            detail = f"Unmount operation FAILED. {res.get('error') or res.get('status')}"
            state, level = "FAILED", "failed"
        self.root.after(0, lambda: (self.set_status("usb_status", state, detail, level), self.log_output("=== USB Unmount Details ===\n" + json.dumps(res, indent=2), "usb")))
    threading.Thread(target=worker, daemon=True).start()


def _v08_gui_write_usb(self, dry: bool) -> None:
    iso = Path(self.usb_iso_var.get().strip()).expanduser(); dev = self.usb_dev_var.get().strip(); conf = self.usb_confirm_var.get().strip()
    self.set_status("usb_status", "USB dry-run in progress..." if dry else "USB write in progress...", f"Target: {dev}", "running")
    def worker():
        # Try to unmount mounted target partitions first for actual writes.
        unmount_res = {"status": "skipped", "reason": "dry-run"} if dry else unmount_device_partitions(dev, dry_run=False)
        if not dry and unmount_res.get("status") != "ok":
            res = {"status": "error", "error": "Could not unmount target before writing", "unmount": unmount_res, "device": dev}
        else:
            res = write_iso_to_usb(iso, dev, conf, dry_run=dry)
            res["unmount"] = unmount_res
        if res.get("status") in ("ok", "dry-run"):
            detail = ("USB dry-run PASS." if dry else "USB write COMPLETE.") + f"\nTarget: {dev}\nISO: {iso}"
            state, level = "PASS", "pass"
        else:
            detail = f"USB operation FAILED. {res.get('error') or res.get('status')}"
            state, level = "FAILED", "failed"
        self.root.after(0, lambda: (self.set_status("usb_status", state, detail, level), self.log_output("=== USB ISO Creator Details ===\n" + json.dumps(res, indent=2), "usb")))
    threading.Thread(target=worker, daemon=True).start()


# v0.8 Release Generator GUI: profiles, versioned output, lock-candidate packaging.
def _v08_build_release(self, parent) -> None:
    tk, ttk = self.tk, self.ttk
    self._section(parent, "Release Generator", "Create versioned release folders, MANIFEST.json, SHA256SUMS, and optional release ZIP packages.")
    self._status_panel(parent, "release_status", "Release Generator Status")
    form = ttk.Frame(parent); form.pack(fill="x", pady=6)
    self.release_var = tk.StringVar(value=str(DEFAULT_WORKSPACE / "05_Releases"))
    self.release_name_var = tk.StringVar(value="sentinel-release")
    self.release_version_var = tk.StringVar(value="1.0")
    self.release_channel_var = tk.StringVar(value="stable")
    self.release_output_var = tk.StringVar(value=str(DEFAULT_WORKSPACE / "05_Releases"))
    self.release_lock_var = tk.BooleanVar(value=False)
    self.release_zip_var = tk.BooleanVar(value=True)
    rows = [("Source Folder:", self.release_var), ("Release Name:", self.release_name_var), ("Version:", self.release_version_var), ("Channel:", self.release_channel_var), ("Output Root:", self.release_output_var)]
    for i,(lab,var) in enumerate(rows):
        ttk.Label(form, text=lab).grid(row=i, column=0, sticky="w", pady=3, padx=(0,6))
        ent = ttk.Entry(form, textvariable=var); ent.grid(row=i, column=1, sticky="ew", pady=3)
        if i in (0,4):
            ttk.Button(form, text="Choose", command=lambda v=var: self.choose_dir(v)).grid(row=i, column=2, padx=6)
    lock = self.tk.Checkbutton(form, text="Lock candidate naming", variable=self.release_lock_var, bg=THEME_BG, fg=THEME_TEXT, selectcolor=THEME_TREE, activebackground=THEME_BG, activeforeground=THEME_GOLD)
    lock.grid(row=5, column=1, sticky="w", pady=3)
    zc = self.tk.Checkbutton(form, text="Create release .zip", variable=self.release_zip_var, bg=THEME_BG, fg=THEME_TEXT, selectcolor=THEME_TREE, activebackground=THEME_BG, activeforeground=THEME_GOLD)
    zc.grid(row=6, column=1, sticky="w", pady=3)
    form.columnconfigure(1, weight=1)
    btns = ttk.Frame(parent); btns.pack(fill="x", pady=6)
    ttk.Button(btns, text="Generate Manifest Only", command=self.gui_release_manifest).pack(side="left", padx=(0,8))
    ttk.Button(btns, text="Build Release Package", command=self.gui_release_package).pack(side="left", padx=8)
    ttk.Button(btns, text="Open Releases", command=lambda: self.open_path(DEFAULT_WORKSPACE / "05_Releases")).pack(side="left", padx=8)
    self._add_output(parent, "release", 11)


def _v08_gui_release_package(self) -> None:
    source = Path(self.release_var.get().strip()).expanduser()
    name = self.release_name_var.get().strip()
    version = self.release_version_var.get().strip() or "1.0"
    channel = self.release_channel_var.get().strip() or "stable"
    output = Path(self.release_output_var.get().strip()).expanduser()
    lock_candidate = bool(self.release_lock_var.get())
    make_zip = bool(self.release_zip_var.get())
    self.set_status("release_status", "Building release package...", "Copying files, generating manifest/checksums, and creating release output.", "running")
    def worker():
        res = create_release_package(source, name, version, channel, output, lock_candidate, make_zip)
        if res.get("status") == "ok":
            detail = f"Release package COMPLETE.\nFolder: {res.get('release_folder')}"
            if res.get("zip"):
                detail += f"\nZIP: {res.get('zip')}"
            state, level = "PASS", "pass"
        else:
            detail = f"Release package FAILED. {res.get('error') or res.get('status')}"
            state, level = "FAILED", "failed"
        self.root.after(0, lambda: (self.set_status("release_status", state, detail, level), self.log_output("=== Release Package Details ===\n" + json.dumps(res, indent=2), "release")))
    threading.Thread(target=worker, daemon=True).start()


def _v08_build_manual(self, parent) -> None:
    self._section(parent, "Manual", "F.O.R.G.E Program 120 GUI and installer manual.")
    text = self.tk.Text(parent, bg=THEME_TREE, fg=THEME_TEXT, insertbackground=THEME_GOLD, relief="flat", wrap="word")
    text.pack(fill="both", expand=True)
    manual = f"""
F.O.R.G.E — File Output & Release Generation Engine
Program 120 — v{VERSION}

Purpose
F.O.R.G.E is the SentinelOS builder workstation. It owns builder/export work removed from Sentinel Program Manager.

v0.7 / v0.8 focus
- ISO Builder now supports ISO profile JSON creation and clearer build preparation.
- USB ISO Creator now lists selectable target disks, hides internal disks by default, verifies ISO checksums, unmounts selected targets, and reports PASS/FAILED clearly.
- Release Generator now creates versioned release folders, lock-candidate naming, MANIFEST.json, SHA256SUMS, and optional release ZIP packages.

User-facing modules
1. Extractor
   Inspect and extract .zip, .tar.*, and .deb archives. Default extraction uses F.O.R.G.E quarantine/staging. Future S.C.A.N integration will verify quarantine contents before release/use.

2. Package Builder
   Build simple Debian .deb wrappers and .tar.gz project bundles from local project folders or .zip project archives. ZIP projects are extracted into quarantine first. Includes project validation, dependencies, maintainer metadata, icon selection, command auto-fill, and clear PASS/FAILED build status.

3. ISO Builder
   Create staging trees, create ISO profile JSON files, and build ISO images. Bootable output requires valid boot assets; otherwise a data ISO can be generated.

4. USB ISO Creator
   Write ISO images to selectable removable USB devices using dd. Internal/non-removable drives are hidden by default. Requires typed ERASE confirmation and root/pkexec/sudo. Verify ISO before writing.

5. Release Generator
   Create versioned release folders, MANIFEST.json, SHA256SUMS, release summaries, and optional ZIP artifacts.

AEGIS Compatibility
forge --forge-status --json
forge --forge-actions --json
forge --forge-diagnostics --json
forge --aegis-status --json
forge --aegis-actions --json
forge --aegis-diagnostics --json
forge --forge-run <action>
forge --aegis-run <action>

Clipboard / Selection
- Ctrl+C, Ctrl+V, Ctrl+X, and Ctrl+A work across normal fields and output panes.
- Right-click fields, output panes, and tables for Cut/Copy/Paste/Select All.
- Tables copy selected rows as tab-separated text for easy notes or reports.

Rules
- Local-first.
- No internet required.
- USB writing is destructive and requires explicit confirmation.
- Archive extraction is inspected before use.
- Quarantine content remains unverified until S.C.A.N integration is connected.
""".strip()
    text.insert("1.0", manual); text.configure(state="disabled")


# Apply v0.7 / v0.8 GUI patches.
ForgeGUI._build_iso = _v08_build_iso
ForgeGUI.gui_create_iso_profile = _v08_gui_create_iso_profile
ForgeGUI._build_usb = _v08_build_usb
ForgeGUI.gui_list_devices = _v08_gui_list_devices
ForgeGUI.gui_verify_iso = _v08_gui_verify_iso
ForgeGUI.gui_unmount_usb = _v08_gui_unmount_usb
ForgeGUI.gui_write_usb = _v08_gui_write_usb
ForgeGUI._build_release = _v08_build_release
ForgeGUI.gui_release_package = _v08_gui_release_package
ForgeGUI._build_manual = _v08_build_manual

# Extend status/actions/diagnostics for v0.7 and v0.8.
_forge_status_v06 = forge_status
_forge_actions_v06 = forge_actions
_diagnostics_v06 = diagnostics


def diagnostics() -> Dict[str, object]:
    d = _diagnostics_v06()
    tools = d.setdefault("tools", {})
    tools.update({
        "umount": shutil.which("umount") is not None,
        "shutil_zip": True,
    })
    d["v0_7_usb_ready"] = bool(tools.get("lsblk") and tools.get("dd"))
    d["v0_8_release_ready"] = True
    d["v0_9_clipboard_ready"] = True
    d["status"] = "ok" if d.get("v0_7_usb_ready") and d.get("v0_8_release_ready") else "warning"
    return d


def forge_status() -> Dict[str, object]:
    s = _forge_status_v06()
    s["version"] = VERSION
    s["phase"] = "v1.0 Lock Candidate"
    s["features"] = {
        "iso_profiles": True,
        "usb_target_selection": True,
        "usb_iso_verify": True,
        "release_package_profiles": True,
        "lock_candidate_naming": True,
        "copy_paste_everywhere": True,
        "aegis_ready": True,
    }
    s["diagnostics"] = diagnostics()
    return s


def forge_actions() -> Dict[str, object]:
    a = _forge_actions_v06()
    names = {x.get("name") for x in a.get("actions", [])}
    additions = [
        {"name": "create-iso-profile", "risk": "low", "network": False},
        {"name": "verify-iso", "risk": "low", "network": False},
        {"name": "unmount-usb", "risk": "high", "network": False},
        {"name": "release-package", "risk": "medium", "network": False},
        {"name": "clipboard-support", "risk": "low", "network": False},
    ]
    for item in additions:
        if item["name"] not in names:
            a["actions"].append(item)
    return a


# Override CLI to add v0.7/v0.8 actions while preserving older actions.
def cli(argv: List[str]) -> int:
    alias_map = {
        "--aegis-status": "--forge-status",
        "--aegis-actions": "--forge-actions",
        "--aegis-diagnostics": "--forge-diagnostics",
        "--aegis-run": "--forge-run",
        "--aegis-dry-run": "--forge-dry-run",
    }
    argv = [alias_map.get(a, a) for a in argv]
    parser = argparse.ArgumentParser(prog="forge", description=APP_LONG_NAME)
    parser.add_argument("--version", action="store_true")
    parser.add_argument("--forge-status", action="store_true")
    parser.add_argument("--forge-actions", action="store_true")
    parser.add_argument("--forge-diagnostics", action="store_true")
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--forge-dry-run", nargs="+", metavar=("ACTION"))
    parser.add_argument("--forge-run", nargs="+", metavar=("ACTION"))
    args = parser.parse_args(argv)
    if args.version:
        print(VERSION); return 0
    if args.forge_status:
        return print_json(forge_status()) if args.json else (print(f"{APP_LONG_NAME} v{VERSION}") or 0)
    if args.forge_actions:
        return print_json(forge_actions()) if args.json else (print("\n".join(a["name"] for a in forge_actions()["actions"])) or 0)
    if args.forge_diagnostics:
        return print_json(diagnostics()) if args.json else (print(json.dumps(diagnostics(), indent=2)) or 0)
    action_args = args.forge_dry_run or args.forge_run
    dry = args.forge_dry_run is not None
    if action_args:
        action, rest = action_args[0], action_args[1:]
        if action == "init-workspace":
            root = Path(rest[0]).expanduser() if rest else DEFAULT_WORKSPACE
            return print_json({"status": "dry-run", "would_create": [str(p) for p in default_workspace_tree(root)]} if dry else init_workspace(root))
        if action == "inspect-archive":
            if not rest: return print_json({"status": "error", "error": "archive path required"})
            return print_json(asdict(inspect_archive(Path(rest[0]))))
        if action == "extract":
            if not rest: return print_json({"status": "error", "error": "archive path required"})
            archive = Path(rest[0]); dest = Path(rest[1]) if len(rest) > 1 else quarantine_destination_for_archive(archive)
            return print_json({"status": "dry-run", "check": asdict(inspect_archive(archive)), "destination": str(dest)} if dry else safe_extract_archive(archive, dest))
        if action == "build-deb":
            if not rest: return print_json({"status": "error", "error": "project path required"})
            project = Path(rest[0]); package_id = rest[1] if len(rest) > 1 else None; version = rest[2] if len(rest) > 2 else "0.1"
            return print_json({"status": "dry-run", "project": str(project), "package_id": sanitize_id(package_id or project.name), "version": version} if dry else build_deb_from_project(project, package_id, version))
        if action == "build-tar":
            if not rest: return print_json({"status": "error", "error": "project path required"})
            project = Path(rest[0]); package_id = rest[1] if len(rest) > 1 else None; version = rest[2] if len(rest) > 2 else "0.1"
            return print_json({"status": "dry-run", "project": str(project), "package_id": sanitize_id(package_id or project.name), "version": version} if dry else build_tar_from_project(project, package_id, version))
        if action == "create-iso-staging":
            name = rest[0] if rest else "sentinelos-iso-staging"
            return print_json({"status": "dry-run", "staging": str((DEFAULT_WORKSPACE / "04_ISO_Staging" / sanitize_id(name)).expanduser())} if dry else create_iso_staging(name))
        if action == "create-iso-profile":
            if not rest: return print_json({"status": "error", "error": "staging path required"})
            staging = Path(rest[0]); out = Path(rest[1]) if len(rest) > 1 else None; label = rest[2] if len(rest) > 2 else "SENTINELOS"
            return print_json({"status": "dry-run", "staging": str(staging), "output": str(out) if out else None, "label": label} if dry else create_iso_profile(staging, out, label))
        if action == "build-iso":
            if not rest: return print_json({"status": "error", "error": "staging path required"})
            staging = Path(rest[0]); out = Path(rest[1]) if len(rest) > 1 else None; label = rest[2] if len(rest) > 2 else "SENTINELOS"
            return print_json({"status": "dry-run", "staging": str(staging), "output": str(out) if out else None, "label": label, "tool": iso_tool()} if dry else build_iso_from_staging(staging, out, label))
        if action == "list-usb-devices":
            include_internal = bool(rest and rest[0] == "--include-internal")
            return print_json(removable_usb_devices(include_internal))
        if action == "verify-iso":
            if not rest: return print_json({"status": "error", "error": "iso path required"})
            return print_json(verify_iso_file(Path(rest[0])))
        if action == "unmount-usb":
            if not rest: return print_json({"status": "error", "error": "device path required"})
            return print_json(unmount_device_partitions(rest[0], dry_run=dry))
        if action == "write-usb":
            if len(rest) < 3: return print_json({"status": "error", "error": "usage: write-usb <iso> <device> ERASE"})
            return print_json(write_iso_to_usb(Path(rest[0]), rest[1], rest[2], dry_run=dry))
        if action == "release-manifest":
            if not rest: return print_json({"status": "error", "error": "folder path required"})
            folder = Path(rest[0])
            return print_json({"status": "dry-run", "folder": str(folder), "file_count": len(walk_manifest(folder)) if folder.exists() else 0} if dry else generate_release_manifest(folder))
        if action == "release-package":
            if not rest: return print_json({"status": "error", "error": "source folder required"})
            source = Path(rest[0]); name = rest[1] if len(rest) > 1 else ""; version = rest[2] if len(rest) > 2 else "1.0"; channel = rest[3] if len(rest) > 3 else "stable"
            return print_json({"status": "dry-run", "source": str(source), "name": name or sanitize_id(source.name), "version": version, "channel": channel} if dry else create_release_package(source, name, version, channel))
        if action == "validate-deb":
            if not rest: return print_json({"status": "error", "error": ".deb path required"})
            return print_json(validate_deb_package(Path(rest[0])))
        if action == "scan-quarantine":
            target = Path(rest[0]) if rest else None
            return print_json(scan_quarantine_placeholder(target))
        if action == "permissions":
            return print_json(forge_permissions())
        if action == "clipboard-support":
            return print_json({"status": "ok", "copy": True, "paste": True, "cut": True, "select_all": True, "tables_copy_selected_rows": True, "context_menu": True})
        return print_json({"status": "error", "error": f"unknown action: {action}"})
    try:
        ForgeGUI().run(); return 0
    except Exception:
        ensure_dirs(); crash = traceback.format_exc(); (LOG_DIR / "crash.log").write_text(crash, encoding="utf-8"); print(crash, file=sys.stderr); return 1


# ------------------------- v1.0 lock-candidate release candidate prep -------------------------
PRELOCK_REQUIRED_MODULES = ["dashboard", "extractor", "package", "iso", "usb", "release", "manual"]


def release_check() -> Dict[str, object]:
    """Non-destructive lock-candidate readiness check for F.O.R.G.E v1.0 preparation."""
    ensure_dirs()
    checks = []
    # Ensure the local workspace skeleton exists before checking readiness.
    try:
        init_workspace(DEFAULT_WORKSPACE)
    except Exception:
        pass

    def add(name: str, ok: bool, detail: str = "") -> None:
        checks.append({"name": name, "status": "pass" if ok else "fail", "detail": detail})

    # Core commands/tools
    for tool in ["python3", "tar", "zip", "unzip", "dpkg-deb", "sha256sum", "lsblk", "dd"]:
        found = shutil.which(tool) is not None
        add(f"tool:{tool}", found, shutil.which(tool) or "not found")

    # Optional ISO tools: at least one is enough for ISO creation.
    iso_candidates = ["xorriso", "genisoimage", "mkisofs"]
    iso_found = [t for t in iso_candidates if shutil.which(t)]
    add("iso-tool", True, ", ".join(iso_found) if iso_found else "optional ISO backend not installed yet; install xorriso/genisoimage/mkisofs for ISO creation")

    # Workspace readiness
    add("workspace-root", DEFAULT_WORKSPACE.exists(), str(DEFAULT_WORKSPACE))
    workspace_paths = default_workspace_tree(DEFAULT_WORKSPACE)
    missing_workspace = [str(p) for p in workspace_paths if not p.exists()]
    add("workspace-tree", not missing_workspace, "complete" if not missing_workspace else "missing: " + ", ".join(missing_workspace[:6]))

    # Icon/desktop/menu/package paths in either installed or source-tree context.
    app_paths = [Path("/usr/share/applications/sentinel-forge.desktop"), Path(__file__).parent.parent / "applications" / "sentinel-forge.desktop", Path(__file__).parent / "sentinel-forge.desktop", Path.cwd() / "sentinel-forge.desktop"]
    add("desktop-entry", any(p.exists() for p in app_paths), "checked installed/source desktop entry paths")
    icon_paths = [Path(__file__).parent / "assets" / "sentinel-forge.png", Path(__file__).parent / "assets" / "forge.png", Path("/usr/share/icons/hicolor/512x512/apps/sentinel-forge.png")]
    add("icon-assets", any(p.exists() for p in icon_paths), "checked app asset icons")

    # Feature readiness checks.
    actions = {a.get("name") for a in forge_actions().get("actions", [])}
    required_actions = {
        "init-workspace", "inspect-archive", "extract", "build-deb", "build-tar",
        "create-iso-profile", "build-iso", "list-usb-devices", "verify-iso",
        "unmount-usb", "write-usb", "release-package", "release-manifest",
        "clipboard-support", "permissions", "scan-quarantine"
    }
    missing_actions = sorted(required_actions - actions)
    add("aegis-actions", not missing_actions, "complete" if not missing_actions else "missing: " + ", ".join(missing_actions))

    d = diagnostics()
    add("diagnostics-status", d.get("status") in {"ok", "pass"}, f"diagnostics status: {d.get('status')}")
    add("clipboard-support", bool(d.get("v0_9_clipboard_ready")), "copy/paste everywhere expected")
    add("usb-safety", True, "USB writes require device selection and typed ERASE confirmation")
    add("network-policy", True, "local-first; no internet required for normal F.O.R.G.E operation")
    add("scanner-placeholder", True, "quarantine is marked unverified until S.C.A.N integration is connected")

    fail_count = sum(1 for c in checks if c["status"] == "fail")
    warn_count = sum(1 for c in checks if c["status"] == "warn")
    status = "pass" if fail_count == 0 else "failed"
    return {
        "program": PROGRAM_NUMBER,
        "app": APP_NAME,
        "version": VERSION,
        "phase": "v1.0 lock candidate",
        "status": status,
        "summary": {
            "checks": len(checks),
            "passed": sum(1 for c in checks if c["status"] == "pass"),
            "failed": fail_count,
            "warnings": warn_count,
        },
        "checks": checks,
        "next_step": "Proceed to v1.0 lock candidate after live desktop smoke testing." if status == "pass" else "Resolve failed checks before v1.0 lock.",
    }


def _v095_human_release_summary(res: Dict[str, object]) -> str:
    status = str(res.get("status", "unknown")).upper()
    summary = res.get("summary", {}) if isinstance(res.get("summary"), dict) else {}
    lines = [
        "F.O.R.G.E Lock-Candidate Release Check",
        f"Status: {status}",
        f"Version: {res.get('version', VERSION)}",
        f"Checks: {summary.get('checks', 0)} | Passed: {summary.get('passed', 0)} | Failed: {summary.get('failed', 0)}",
        "",
    ]
    for item in res.get("checks", []):
        marker = "PASS" if item.get("status") == "pass" else "FAILED"
        detail = item.get("detail", "")
        lines.append(f"[{marker}] {item.get('name')}" + (f" — {detail}" if detail else ""))
    lines.append("")
    lines.append(str(res.get("next_step", "")))
    return "\n".join(lines)


_forge_status_v09 = forge_status
_diagnostics_v09 = diagnostics
_forge_actions_v09 = forge_actions
_old_build_manual_v09 = ForgeGUI._build_manual


def diagnostics() -> Dict[str, object]:
    d = _diagnostics_v09()
    d["v0_9_5_prelock_ready"] = True
    return d


def forge_status() -> Dict[str, object]:
    s = _forge_status_v09()
    s["version"] = VERSION
    s["phase"] = "v1.0 Lock Candidate"
    s["release_readiness"] = release_check()
    return s


def forge_actions() -> Dict[str, object]:
    a = _forge_actions_v09()
    names = {x.get("name") for x in a.get("actions", [])}
    for item in [{"name": "release-check", "risk": "low", "network": False}]:
        if item["name"] not in names:
            a["actions"].append(item)
    return a


def _v095_gui_release_check(self) -> None:
    try:
        self.set_status("diagnostics", "Running Lock-Candidate Release Check...", "Checking F.O.R.G.E v1.0 lock-candidate readiness.", "running")
    except Exception:
        pass
    def worker():
        res = release_check()
        level = "ok" if res.get("status") == "pass" else "error"
        headline = "Status: PASS" if res.get("status") == "pass" else "Status: FAILED"
        detail = res.get("next_step", "")
        def done():
            try:
                self.set_status("diagnostics", headline, detail, level)
            except Exception:
                pass
            self.log_output("=== Lock-Candidate Release Check ===\n" + _v095_human_release_summary(res) + "\n\n=== JSON Details ===\n" + json.dumps(res, indent=2), "dashboard")
        self.root.after(0, done)
    threading.Thread(target=worker, daemon=True).start()


def _v095_build_manual(self, parent) -> None:
    _old_build_manual_v09(self, parent)
    # Add a visible lock-candidate release check button to the top of the manual if possible.
    try:
        bar = tk.Frame(parent, bg=PANEL)
        bar.pack(fill="x", padx=10, pady=(0, 8), before=parent.winfo_children()[1] if len(parent.winfo_children()) > 1 else None)
        tk.Button(bar, text="Run v1.0 Release Check", command=self.gui_release_check, bg=GOLD, fg="#111111", activebackground=CYAN, activeforeground="#111111", relief="flat", padx=10, pady=6).pack(side="left")
    except Exception:
        pass


ForgeGUI.gui_release_check = _v095_gui_release_check
ForgeGUI._build_manual = _v095_build_manual

# Override CLI for v1.0 lock-candidate release checks while preserving previous actions.
def cli(argv: List[str]) -> int:
    alias_map = {
        "--aegis-status": "--forge-status",
        "--aegis-actions": "--forge-actions",
        "--aegis-diagnostics": "--forge-diagnostics",
        "--aegis-release-check": "--release-check",
        "--aegis-run": "--forge-run",
        "--aegis-dry-run": "--forge-dry-run",
    }
    argv = [alias_map.get(a, a) for a in argv]
    parser = argparse.ArgumentParser(prog="forge", description=APP_LONG_NAME)
    parser.add_argument("--version", action="store_true")
    parser.add_argument("--forge-status", action="store_true")
    parser.add_argument("--forge-actions", action="store_true")
    parser.add_argument("--forge-diagnostics", action="store_true")
    parser.add_argument("--release-check", action="store_true")
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--forge-dry-run", nargs="+", metavar=("ACTION"))
    parser.add_argument("--forge-run", nargs="+", metavar=("ACTION"))
    args = parser.parse_args(argv)
    if args.version:
        print(VERSION); return 0
    if args.forge_status:
        return print_json(forge_status()) if args.json else (print(f"{APP_LONG_NAME} v{VERSION}") or 0)
    if args.forge_actions:
        return print_json(forge_actions()) if args.json else (print("\n".join(a["name"] for a in forge_actions()["actions"])) or 0)
    if args.forge_diagnostics:
        return print_json(diagnostics()) if args.json else (print(json.dumps(diagnostics(), indent=2)) or 0)
    if args.release_check:
        res = release_check()
        return print_json(res) if args.json else (print(_v095_human_release_summary(res)) or 0)
    action_args = args.forge_dry_run or args.forge_run
    dry = args.forge_dry_run is not None
    if action_args:
        action, rest = action_args[0], action_args[1:]
        if action == "release-check":
            res = release_check()
            if dry:
                res = {"status": "dry-run", "would_check": [c["name"] for c in res.get("checks", [])], "version": VERSION}
            return print_json(res)
        if action == "init-workspace":
            root = Path(rest[0]).expanduser() if rest else DEFAULT_WORKSPACE
            return print_json({"status": "dry-run", "would_create": [str(p) for p in default_workspace_tree(root)]} if dry else init_workspace(root))
        if action == "inspect-archive":
            if not rest: return print_json({"status": "error", "error": "archive path required"})
            return print_json(asdict(inspect_archive(Path(rest[0]))))
        if action == "extract":
            if not rest: return print_json({"status": "error", "error": "archive path required"})
            archive = Path(rest[0]); dest = Path(rest[1]) if len(rest) > 1 else quarantine_destination_for_archive(archive)
            return print_json({"status": "dry-run", "check": asdict(inspect_archive(archive)), "destination": str(dest)} if dry else safe_extract_archive(archive, dest))
        if action == "build-deb":
            if not rest: return print_json({"status": "error", "error": "project path required"})
            project = Path(rest[0]); package_id = rest[1] if len(rest) > 1 else None; version = rest[2] if len(rest) > 2 else "0.1"
            return print_json({"status": "dry-run", "project": str(project), "package_id": sanitize_id(package_id or project.name), "version": version} if dry else build_deb_from_project(project, package_id, version))
        if action == "build-tar":
            if not rest: return print_json({"status": "error", "error": "project path required"})
            project = Path(rest[0]); package_id = rest[1] if len(rest) > 1 else None; version = rest[2] if len(rest) > 2 else "0.1"
            return print_json({"status": "dry-run", "project": str(project), "package_id": sanitize_id(package_id or project.name), "version": version} if dry else build_tar_from_project(project, package_id, version))
        if action == "create-iso-staging":
            name = rest[0] if rest else "sentinelos-iso-staging"
            return print_json({"status": "dry-run", "staging": str((DEFAULT_WORKSPACE / "04_ISO_Staging" / sanitize_id(name)).expanduser())} if dry else create_iso_staging(name))
        if action == "create-iso-profile":
            if not rest: return print_json({"status": "error", "error": "staging path required"})
            staging = Path(rest[0]); out = Path(rest[1]) if len(rest) > 1 else None; label = rest[2] if len(rest) > 2 else "SENTINELOS"
            return print_json({"status": "dry-run", "staging": str(staging), "output": str(out) if out else None, "label": label} if dry else create_iso_profile(staging, out, label))
        if action == "build-iso":
            if not rest: return print_json({"status": "error", "error": "staging path required"})
            staging = Path(rest[0]); out = Path(rest[1]) if len(rest) > 1 else None; label = rest[2] if len(rest) > 2 else "SENTINELOS"
            return print_json({"status": "dry-run", "staging": str(staging), "output": str(out) if out else None, "label": label, "tool": iso_tool()} if dry else build_iso_from_staging(staging, out, label))
        if action == "list-usb-devices":
            include_internal = bool(rest and rest[0] == "--include-internal")
            return print_json(removable_usb_devices(include_internal))
        if action == "verify-iso":
            if not rest: return print_json({"status": "error", "error": "iso path required"})
            return print_json(verify_iso_file(Path(rest[0])))
        if action == "unmount-usb":
            if not rest: return print_json({"status": "error", "error": "device path required"})
            return print_json(unmount_device_partitions(rest[0], dry_run=dry))
        if action == "write-usb":
            if len(rest) < 3: return print_json({"status": "error", "error": "usage: write-usb <iso> <device> ERASE"})
            return print_json(write_iso_to_usb(Path(rest[0]), rest[1], rest[2], dry_run=dry))
        if action == "release-manifest":
            if not rest: return print_json({"status": "error", "error": "folder path required"})
            folder = Path(rest[0])
            return print_json({"status": "dry-run", "folder": str(folder), "file_count": len(walk_manifest(folder)) if folder.exists() else 0} if dry else generate_release_manifest(folder))
        if action == "release-package":
            if not rest: return print_json({"status": "error", "error": "source folder required"})
            source = Path(rest[0]); name = rest[1] if len(rest) > 1 else ""; version = rest[2] if len(rest) > 2 else "1.0"; channel = rest[3] if len(rest) > 3 else "stable"
            return print_json({"status": "dry-run", "source": str(source), "name": name or sanitize_id(source.name), "version": version, "channel": channel} if dry else create_release_package(source, name, version, channel))
        if action == "validate-deb":
            if not rest: return print_json({"status": "error", "error": ".deb path required"})
            return print_json(validate_deb_package(Path(rest[0])))
        if action == "scan-quarantine":
            target = Path(rest[0]) if rest else None
            return print_json(scan_quarantine_placeholder(target))
        if action == "permissions":
            return print_json(forge_permissions())
        if action == "clipboard-support":
            return print_json({"status": "ok", "copy": True, "paste": True, "cut": True, "select_all": True, "tables_copy_selected_rows": True, "context_menu": True})
        return print_json({"status": "error", "error": f"unknown action: {action}"})
    try:
        ForgeGUI().run(); return 0
    except Exception:
        ensure_dirs(); crash = traceback.format_exc(); (LOG_DIR / "crash.log").write_text(crash, encoding="utf-8"); print(crash, file=sys.stderr); return 1




# ------------------------- v1.0.1 Encryption & Secure Media integration -------------------------
# F.O.R.G.E remains the user-facing Program 120 hub. The crypto implementation is delegated to
# the sentinel-forge-crypto backend so no custom cryptography lives in this GUI/application layer.

CRYPTO_BACKEND = "sentinel-forge-crypto"
CRYPTO_GUI_BACKEND = "sentinel-forge-crypto-gui"
CRYPTO_WORKSPACE = DEFAULT_WORKSPACE / "11_Encrypted"
CRYPTO_CONTAINERS = CRYPTO_WORKSPACE / "Containers"
CRYPTO_FILES = CRYPTO_WORKSPACE / "Files"
CRYPTO_FOLDERS = CRYPTO_WORKSPACE / "Folders"
CRYPTO_HEADERS = CRYPTO_WORKSPACE / "Headers"
CRYPTO_KEYS = CRYPTO_WORKSPACE / "Keys"
CRYPTO_MOUNTS = CRYPTO_WORKSPACE / "Mounts"


def crypto_backend_available() -> bool:
    return shutil.which(CRYPTO_BACKEND) is not None


def crypto_backend_command() -> Optional[str]:
    return shutil.which(CRYPTO_BACKEND)


def crypto_gui_command() -> Optional[str]:
    return shutil.which(CRYPTO_GUI_BACKEND)


def _crypto_json_from_output(raw: str) -> Optional[object]:
    raw = (raw or "").strip()
    if not raw:
        return None
    try:
        return json.loads(raw)
    except Exception:
        return None


def run_crypto_backend(args: List[str], dry_run: bool = False, timeout: int = 600) -> Dict[str, object]:
    """Run sentinel-forge-crypto safely using an argv list. No shell invocation."""
    backend = crypto_backend_command()
    if not backend:
        return {
            "status": "unavailable",
            "error": "sentinel-forge-crypto backend is not installed or not in PATH.",
            "install_hint": "Install sentinel-forge-crypto_0.1.0-1_all.deb from the F.O.R.G.E crypto bundle.",
            "command": [CRYPTO_BACKEND] + list(args),
        }
    cmd = [backend, "--json"] + [str(a) for a in args]
    if dry_run and "--dry-run" not in cmd:
        # Most backend operation subcommands accept --dry-run after the subcommand/positional args.
        cmd.append("--dry-run")
    log("$ " + " ".join(str(x) for x in cmd))
    try:
        proc = subprocess.run(cmd, input="", text=True, capture_output=True, timeout=timeout)
    except Exception as e:
        return {"status": "error", "error": str(e), "command": cmd}
    raw = (proc.stdout or "") + (proc.stderr or "")
    parsed = _crypto_json_from_output(proc.stdout)
    status = "ok" if proc.returncode == 0 else "error"
    if isinstance(parsed, dict) and parsed.get("dry_run"):
        status = "dry-run"
    res = {
        "status": status,
        "returncode": proc.returncode,
        "command": cmd,
        "stdout": proc.stdout,
        "stderr": proc.stderr,
        "output": raw,
        "json": parsed,
    }
    audit("crypto-backend", " ".join(args[:2]), status, {"argv": cmd, "rc": proc.returncode})
    return res


def forge_crypto_status() -> Dict[str, object]:
    if not crypto_backend_available():
        return {
            "component": "F.O.R.G.E Encryption & Secure Media",
            "backend": CRYPTO_BACKEND,
            "status": "unavailable",
            "ready": False,
            "custom_crypto": False,
            "local_only": True,
            "network_required": False,
            "reason": "sentinel-forge-crypto backend is not installed or not in PATH.",
        }
    res = run_crypto_backend(["aegis-status"])
    if isinstance(res.get("json"), dict):
        out = dict(res["json"])
        out["forge_integration"] = "v1.0.5"
        return out
    return {
        "component": "F.O.R.G.E Encryption & Secure Media",
        "backend": CRYPTO_BACKEND,
        "status": res.get("status", "unknown"),
        "ready": False,
        "custom_crypto": False,
        "local_only": True,
        "network_required": False,
        "details": res,
    }


def crypto_usage(action: str) -> Dict[str, object]:
    return {"status": "error", "error": f"usage error for {action}", "help": CRYPTO_ACTION_HELP.get(action, "Run forge --forge-actions --json for supported actions.")}


CRYPTO_ACTION_HELP = {
    "crypto-status": "crypto-status",
    "crypto-deps": "crypto-deps",
    "crypto-list-devices": "crypto-list-devices",
    "crypto-age-keygen": "crypto-age-keygen <output>",
    "crypto-file-encrypt": "crypto-file-encrypt <input_file> <output_file> (--recipient AGE_PUBLIC_KEY | --passphrase)",
    "crypto-file-decrypt": "crypto-file-decrypt <input_file> <output_file> (--identity KEYFILE | --passphrase)",
    "crypto-folder-encrypt": "crypto-folder-encrypt <folder> <output_file> (--recipient AGE_PUBLIC_KEY | --passphrase)",
    "crypto-folder-decrypt": "crypto-folder-decrypt <input_file> <output_dir> (--identity KEYFILE | --passphrase)",
    "crypto-container-create": "crypto-container-create <path> <size> [--allocated]",
    "crypto-luks-format": "crypto-luks-format <device_or_container> [label] ERASE",
    "crypto-luks-open": "crypto-luks-open <device_or_container> <mapping>",
    "crypto-luks-close": "crypto-luks-close <mapping>",
    "crypto-luks-status": "crypto-luks-status <mapping>",
    "crypto-luks-header-backup": "crypto-luks-header-backup <device_or_container> <output_header_file>",
    "crypto-luks-header-restore": "crypto-luks-header-restore <device_or_container> <backup_header_file> RESTORE_HEADER",
    "crypto-mount": "crypto-mount <mapping> <mountpoint>",
    "crypto-unmount": "crypto-unmount <mountpoint>",
    "crypto-fscrypt-status": "crypto-fscrypt-status [path]",
    "crypto-fscrypt-encrypt-empty-dir": "crypto-fscrypt-encrypt-empty-dir <empty_directory>",
}


def dispatch_crypto_action(action: str, rest: List[str], dry: bool = False) -> Dict[str, object]:
    """Map F.O.R.G.E AEGIS action names onto sentinel-forge-crypto backend commands."""
    if action == "crypto-status":
        return forge_crypto_status()
    if action == "crypto-deps":
        return run_crypto_backend(["deps"])
    if action == "crypto-list-devices":
        return run_crypto_backend(["list-devices"])
    if action == "crypto-age-keygen":
        if len(rest) < 1: return crypto_usage(action)
        return run_crypto_backend(["age-keygen", rest[0]], dry_run=dry)
    if action == "crypto-file-encrypt":
        if len(rest) < 3: return crypto_usage(action)
        cmd = ["file-encrypt", rest[0], rest[1]]
        if rest[2] == "--passphrase": cmd.append("--passphrase")
        elif rest[2] == "--recipient" and len(rest) >= 4: cmd.extend(["--recipient", rest[3]])
        else: return crypto_usage(action)
        return run_crypto_backend(cmd, dry_run=dry)
    if action == "crypto-file-decrypt":
        if len(rest) < 3: return crypto_usage(action)
        cmd = ["file-decrypt", rest[0], rest[1]]
        if rest[2] == "--passphrase": cmd.append("--passphrase")
        elif rest[2] == "--identity" and len(rest) >= 4: cmd.extend(["--identity", rest[3]])
        else: return crypto_usage(action)
        return run_crypto_backend(cmd, dry_run=dry)
    if action == "crypto-folder-encrypt":
        if len(rest) < 3: return crypto_usage(action)
        cmd = ["folder-encrypt", rest[0], rest[1]]
        if rest[2] == "--passphrase": cmd.append("--passphrase")
        elif rest[2] == "--recipient" and len(rest) >= 4: cmd.extend(["--recipient", rest[3]])
        else: return crypto_usage(action)
        return run_crypto_backend(cmd, dry_run=dry)
    if action == "crypto-folder-decrypt":
        if len(rest) < 3: return crypto_usage(action)
        cmd = ["folder-decrypt", rest[0], rest[1]]
        if rest[2] == "--passphrase": cmd.append("--passphrase")
        elif rest[2] == "--identity" and len(rest) >= 4: cmd.extend(["--identity", rest[3]])
        else: return crypto_usage(action)
        return run_crypto_backend(cmd, dry_run=dry)
    if action == "crypto-container-create":
        if len(rest) < 2: return crypto_usage(action)
        cmd = ["container-create", rest[0], "--size", rest[1]]
        if "--allocated" in rest[2:]: cmd.append("--allocated")
        if not dry: cmd.append("--execute")
        return run_crypto_backend(cmd, dry_run=dry)
    if action == "crypto-luks-format":
        if len(rest) < 1: return crypto_usage(action)
        cmd = ["luks-format", rest[0]]
        labels = [x for x in rest[1:] if x != "ERASE"]
        if labels: cmd.extend(["--label", labels[0]])
        if not dry:
            if "ERASE" not in rest: return crypto_usage(action)
            cmd.extend(["--execute", "--confirm", "ERASE"])
        return run_crypto_backend(cmd, dry_run=dry)
    if action == "crypto-luks-open":
        if len(rest) < 2: return crypto_usage(action)
        return run_crypto_backend(["luks-open", rest[0], rest[1]], dry_run=dry)
    if action == "crypto-luks-close":
        if len(rest) < 1: return crypto_usage(action)
        return run_crypto_backend(["luks-close", rest[0]], dry_run=dry)
    if action == "crypto-luks-status":
        if len(rest) < 1: return crypto_usage(action)
        return run_crypto_backend(["luks-status", rest[0]])
    if action == "crypto-luks-header-backup":
        if len(rest) < 2: return crypto_usage(action)
        return run_crypto_backend(["luks-header-backup", rest[0], rest[1]], dry_run=dry)
    if action == "crypto-luks-header-restore":
        if len(rest) < 2: return crypto_usage(action)
        cmd = ["luks-header-restore", rest[0], rest[1]]
        if not dry:
            if "RESTORE_HEADER" not in rest: return crypto_usage(action)
            cmd.extend(["--execute", "--confirm", "RESTORE_HEADER"])
        return run_crypto_backend(cmd, dry_run=dry)
    if action == "crypto-mount":
        if len(rest) < 2: return crypto_usage(action)
        return run_crypto_backend(["mount", rest[0], rest[1]], dry_run=dry)
    if action == "crypto-unmount":
        if len(rest) < 1: return crypto_usage(action)
        return run_crypto_backend(["unmount", rest[0]], dry_run=dry)
    if action == "crypto-fscrypt-status":
        return run_crypto_backend(["fscrypt-status"] + rest[:1])
    if action == "crypto-fscrypt-encrypt-empty-dir":
        if len(rest) < 1: return crypto_usage(action)
        cmd = ["fscrypt-encrypt-empty-dir", rest[0]]
        if not dry: cmd.append("--execute")
        return run_crypto_backend(cmd, dry_run=dry)
    return {"status": "error", "error": f"unknown crypto action: {action}"}


_diagnostics_before_crypto = diagnostics
_forge_status_before_crypto = forge_status
_forge_actions_before_crypto = forge_actions
_cli_before_crypto = cli


def diagnostics() -> Dict[str, object]:
    d = _diagnostics_before_crypto()
    tools = d.setdefault("tools", {})
    tools[CRYPTO_BACKEND] = crypto_backend_available()
    tools[CRYPTO_GUI_BACKEND] = crypto_gui_command() is not None
    d["crypto_integration"] = {
        "status": "ok" if crypto_backend_available() else "backend-missing",
        "backend": crypto_backend_command(),
        "gui_backend": crypto_gui_command(),
        "workspace": str(CRYPTO_WORKSPACE),
        "custom_crypto": False,
        "local_only": True,
    }
    return d


def forge_status() -> Dict[str, object]:
    s = _forge_status_before_crypto()
    s["version"] = VERSION
    s["crypto_integration"] = forge_crypto_status()
    return s


def forge_actions() -> Dict[str, object]:
    a = _forge_actions_before_crypto()
    names = {x.get("name") for x in a.get("actions", [])}
    additions = [
        {"name": "crypto-status", "risk": "low", "network": False},
        {"name": "crypto-deps", "risk": "low", "network": False},
        {"name": "crypto-list-devices", "risk": "low", "network": False},
        {"name": "crypto-age-keygen", "risk": "medium", "network": False},
        {"name": "crypto-file-encrypt", "risk": "medium", "network": False},
        {"name": "crypto-file-decrypt", "risk": "medium", "network": False},
        {"name": "crypto-folder-encrypt", "risk": "medium", "network": False},
        {"name": "crypto-folder-decrypt", "risk": "medium", "network": False},
        {"name": "crypto-container-create", "risk": "medium", "network": False},
        {"name": "crypto-luks-format", "risk": "critical", "network": False, "guard": "requires ERASE and backend --execute"},
        {"name": "crypto-luks-open", "risk": "medium", "network": False},
        {"name": "crypto-luks-close", "risk": "medium", "network": False},
        {"name": "crypto-luks-status", "risk": "low", "network": False},
        {"name": "crypto-luks-header-backup", "risk": "medium", "network": False},
        {"name": "crypto-luks-header-restore", "risk": "critical", "network": False, "guard": "requires RESTORE_HEADER and backend --execute"},
        {"name": "crypto-mount", "risk": "medium", "network": False},
        {"name": "crypto-unmount", "risk": "medium", "network": False},
        {"name": "crypto-fscrypt-status", "risk": "low", "network": False},
        {"name": "crypto-fscrypt-encrypt-empty-dir", "risk": "medium", "network": False},
    ]
    for item in additions:
        if item["name"] not in names:
            a["actions"].append(item)
    a["crypto_action_help"] = CRYPTO_ACTION_HELP
    return a


def cli(argv: List[str]) -> int:
    alias_map = {
        "--aegis-status": "--forge-status",
        "--aegis-actions": "--forge-actions",
        "--aegis-diagnostics": "--forge-diagnostics",
        "--aegis-release-check": "--release-check",
        "--aegis-run": "--forge-run",
        "--aegis-dry-run": "--forge-dry-run",
    }
    argv = [alias_map.get(a, a) for a in argv]
    # Intercept only crypto actions, then delegate all legacy F.O.R.G.E behavior to v1.0.
    for flag, dry in (("--forge-run", False), ("--forge-dry-run", True)):
        if flag in argv:
            idx = argv.index(flag)
            rest = argv[idx + 1:]
            if rest and rest[0].startswith("crypto-"):
                return print_json(dispatch_crypto_action(rest[0], rest[1:], dry=dry))
    return _cli_before_crypto(argv)


def _crypto_choose_any_file(self, var, title: str = "Choose File") -> None:
    from tkinter import filedialog
    p = filedialog.askopenfilename(title=title, filetypes=[("All files", "*")])
    if p:
        var.set(p)


def _crypto_choose_save_file(self, var, default_ext: str = "") -> None:
    from tkinter import filedialog
    p = filedialog.asksaveasfilename(title="Choose Output", defaultextension=default_ext or None, filetypes=[("All files", "*")])
    if p:
        var.set(p)


def _crypto_choose_output_dir(self, var, mode: str = "file-encrypt") -> None:
    """Choose an output folder but keep/set a usable output filename.

    This fixes the v1.0.2 usability trap where choosing a folder could place a
    directory path into an output field that needs a file path.
    """
    from tkinter import filedialog
    p = filedialog.askdirectory(title="Choose output folder")
    if not p:
        return
    folder = Path(p).expanduser()
    var.set(str(folder / self.crypto_suggest_output_name(mode)))


def _crypto_choose_mount_dir(self, var) -> None:
    from tkinter import filedialog
    p = filedialog.askdirectory(title="Choose or create mountpoint folder")
    if p:
        var.set(p)


def _crypto_open_workspace(self) -> None:
    self.open_path(CRYPTO_WORKSPACE)


def _crypto_open_containers(self) -> None:
    self.open_path(CRYPTO_CONTAINERS)


def _crypto_open_files(self) -> None:
    self.open_path(CRYPTO_FILES)


def _crypto_open_folders(self) -> None:
    self.open_path(CRYPTO_FOLDERS)


def _crypto_open_headers(self) -> None:
    self.open_path(CRYPTO_HEADERS)


def _crypto_terminal_command(self, args: List[str], dry: bool = False) -> str:
    cmd = [CRYPTO_BACKEND, "--json"] + [str(x) for x in args]
    if dry and "--dry-run" not in cmd:
        cmd.append("--dry-run")
    return " ".join(shlex.quote(str(x)) for x in cmd)


def _crypto_copy_terminal_command(self, args: List[str], dry: bool = False) -> None:
    cmd = self.crypto_terminal_command(args, dry=dry)
    try:
        self.root.clipboard_clear()
        self.root.clipboard_append(cmd)
        self.root.update_idletasks()
        copied = "Copied to clipboard."
    except Exception:
        copied = "Copy failed; command shown below."
    self.log_output("=== Terminal Command ===\n" + cmd + "\n" + copied, "crypto")


def _crypto_message(self, title: str, body: str, kind: str = "info") -> bool:
    try:
        from tkinter import messagebox
        if kind == "error":
            messagebox.showerror(title, body)
            return False
        if kind == "warning":
            return bool(messagebox.askyesno(title, body, icon="warning"))
        messagebox.showinfo(title, body)
        return True
    except Exception:
        self.log_output(f"{title}: {body}", "crypto")
        # In headless/smoke-test mode, do not auto-approve destructive warnings.
        return False if kind == "warning" else True


def _crypto_error(self, body: str) -> bool:
    self.log_output("Blocked: " + body, "crypto")
    return self.crypto_message("F.O.R.G.E Encryption", body, "error")


def _crypto_confirm_danger(self, title: str, body: str) -> bool:
    return self.crypto_message(title, body, "warning")


def _crypto_expand(self, value: str) -> Path:
    return Path((value or "").strip()).expanduser()


def _crypto_output_exists_block(self, output_value: str, *, allow_dir: bool = False) -> bool:
    if not output_value.strip():
        return self.crypto_error("Choose an output path first.")
    out = self.crypto_expand(output_value)
    if out.exists() and not allow_dir:
        return self.crypto_error(f"Output already exists. Choose a new output path so F.O.R.G.E never overwrites encrypted data:\n\n{out}")
    return True


def _crypto_validate_backend(self) -> bool:
    if crypto_backend_available():
        return True
    return self.crypto_error("sentinel-forge-crypto is not installed or not in PATH. Install the crypto backend package from the F.O.R.G.E bundle first.")


def _crypto_validate_file_encrypt(self, dry: bool = False) -> bool:
    if not self.crypto_validate_backend():
        return False
    inp = self.crypto_expand(self.crypto_input_var.get())
    if not inp.exists():
        return self.crypto_error(f"Input file does not exist:\n\n{inp}")
    if not inp.is_file():
        return self.crypto_error("File Encrypt expects a regular file. Use Encrypt Folder for directories.")
    if not dry and not self.crypto_output_exists_block(self.crypto_output_var.get()):
        return False
    mode = self.crypto_build_mode_args(encrypt=True)
    if not mode:
        return self.crypto_error("Enable passphrase mode or paste an age recipient public key before encrypting.")
    return True


def _crypto_validate_file_decrypt(self, dry: bool = False) -> bool:
    if not self.crypto_validate_backend():
        return False
    inp = self.crypto_expand(self.crypto_input_var.get())
    if not inp.exists() or not inp.is_file():
        return self.crypto_error(f"Encrypted input file does not exist:\n\n{inp}")
    if not dry and not self.crypto_output_exists_block(self.crypto_output_var.get()):
        return False
    mode = self.crypto_build_mode_args(encrypt=False)
    if not mode:
        return self.crypto_error("Enable passphrase mode or choose an age identity key file before decrypting.")
    if "--identity" in mode:
        ident = self.crypto_expand(mode[mode.index("--identity") + 1])
        if not ident.exists() or not ident.is_file():
            return self.crypto_error(f"Identity key file does not exist:\n\n{ident}")
    return True


def _crypto_validate_folder_encrypt(self, dry: bool = False) -> bool:
    if not self.crypto_validate_backend():
        return False
    inp = self.crypto_expand(self.crypto_input_var.get())
    if not inp.exists() or not inp.is_dir():
        return self.crypto_error(f"Input folder does not exist:\n\n{inp}")
    if not dry and not self.crypto_output_exists_block(self.crypto_output_var.get()):
        return False
    mode = self.crypto_build_mode_args(encrypt=True)
    if not mode:
        return self.crypto_error("Enable passphrase mode or paste an age recipient public key before encrypting.")
    return True


def _crypto_validate_folder_decrypt(self, dry: bool = False) -> bool:
    if not self.crypto_validate_backend():
        return False
    inp = self.crypto_expand(self.crypto_input_var.get())
    if not inp.exists() or not inp.is_file():
        return self.crypto_error(f"Encrypted folder archive does not exist:\n\n{inp}")
    if not self.crypto_output_var.get().strip():
        return self.crypto_error("Choose an output folder for folder decryption.")
    mode = self.crypto_build_mode_args(encrypt=False)
    if not mode:
        return self.crypto_error("Enable passphrase mode or choose an age identity key file before decrypting.")
    if "--identity" in mode:
        ident = self.crypto_expand(mode[mode.index("--identity") + 1])
        if not ident.exists() or not ident.is_file():
            return self.crypto_error(f"Identity key file does not exist:\n\n{ident}")
    return True


def _crypto_validate_container_create(self, dry: bool = False) -> bool:
    if not self.crypto_validate_backend():
        return False
    path = self.crypto_expand(self.crypto_container_var.get())
    size = self.crypto_size_var.get().strip()
    if not str(path):
        return self.crypto_error("Choose a container image path first.")
    if path.exists() and not dry:
        return self.crypto_error(f"Container image already exists. Choose a new filename:\n\n{path}")
    if not re.match(r"^[0-9]+(\.[0-9]+)?\s*[KMGTPEZY]?i?B?$", size, re.IGNORECASE):
        return self.crypto_error("Container size should look like 512M, 2G, 10G, or 104857600.")
    return True


def _crypto_validate_luks_source(self) -> Optional[str]:
    dev = self.crypto_device_var.get().strip() or self.crypto_container_var.get().strip()
    if not dev:
        self.crypto_error("Choose a device/container first.")
        return None
    p = Path(dev).expanduser()
    # /dev/* entries and regular container files are both valid. Non-existing /dev paths are blocked.
    if dev.startswith("/dev/"):
        if not p.exists():
            self.crypto_error(f"Device does not exist:\n\n{p}")
            return None
        return dev
    if not p.exists():
        self.crypto_error(f"Container/device file does not exist:\n\n{p}")
        return None
    return str(p)


def _crypto_validate_mapping(self) -> bool:
    name = self.crypto_mapping_var.get().strip()
    if not re.match(r"^[A-Za-z0-9_.-]{1,64}$", name):
        return self.crypto_error("Mapping name must use only letters, numbers, dots, underscores, or hyphens, maximum 64 characters.")
    return True


def _crypto_suggest_output_name(self, mode: str = "file-encrypt") -> str:
    raw = self.crypto_input_var.get().strip()
    name = Path(raw).name if raw else "output"
    if mode == "file-encrypt":
        return f"{name}.age" if not name.endswith(".age") else f"{name}.new.age"
    if mode == "file-decrypt":
        if name.endswith(".age"):
            return name[:-4] or "decrypted-output"
        return f"{name}.decrypted"
    if mode == "folder-encrypt":
        return f"{name}.tar.age" if not name.endswith(".age") else f"{name}.new.tar.age"
    if mode == "folder-decrypt":
        if name.endswith(".tar.age"):
            return name[:-8] + "_decrypted"
        if name.endswith(".age"):
            return name[:-4] + "_decrypted"
        return f"{name}_decrypted"
    return "output.age"


def _crypto_apply_suggested_output(self, mode: str = "file-encrypt") -> None:
    base_dir = CRYPTO_FILES if mode.startswith("file") else CRYPTO_FOLDERS
    if mode == "folder-decrypt":
        base_dir = CRYPTO_FOLDERS
    base_dir.mkdir(parents=True, exist_ok=True)
    self.crypto_output_var.set(str(base_dir / self.crypto_suggest_output_name(mode)))


def _crypto_apply_selected_device_to_field(self) -> None:
    """Best-effort helper: copy selected device path from the device table to the device field."""
    try:
        item = self.crypto_device_tree.selection()[0]
        values = self.crypto_device_tree.item(item, "values")
        if values and values[0]:
            self.crypto_device_var.set(str(values[0]))
    except Exception:
        self.log_output("Select a device row first, or type/paste a /dev/... path manually.", "crypto")


def _crypto_refresh_device_table(self) -> None:
    try:
        self.crypto_device_tree.delete(*self.crypto_device_tree.get_children())
    except Exception:
        pass
    res = run_crypto_backend(["list-devices"])
    self.log_output("=== Device Refresh ===\n" + json.dumps(res, indent=2), "crypto")
    data = res.get("json") if isinstance(res, dict) else None
    # The backend may return lsblk JSON either directly or nested. Keep this tolerant.
    blockdevices = []
    if isinstance(data, dict):
        blockdevices = data.get("blockdevices") or data.get("devices") or []
    elif isinstance(res.get("stdout"), str):
        try:
            parsed = json.loads(res["stdout"])
            blockdevices = parsed.get("blockdevices", []) if isinstance(parsed, dict) else []
        except Exception:
            blockdevices = []

    def walk(devs):
        for d in devs or []:
            if not isinstance(d, dict):
                continue
            path = d.get("path") or ("/dev/" + d.get("name", "") if d.get("name") else "")
            size = d.get("size", "")
            model = d.get("model") or d.get("label") or d.get("fstype") or ""
            dtype = d.get("type", "")
            mount = d.get("mountpoint") or d.get("mountpoints") or ""
            if isinstance(mount, list):
                mount = ", ".join(str(x) for x in mount if x)
            if path:
                try:
                    self.crypto_device_tree.insert("", "end", values=(path, size, dtype, model, mount))
                except Exception:
                    pass
            walk(d.get("children", []))
    walk(blockdevices)


def _crypto_run_gui_action(self, label: str, args: List[str], dry: bool = False) -> None:
    # v1.0.3: protect the GUI from hanging on interactive age passphrase prompts.
    if "--passphrase" in args and not dry:
        cmd = self.crypto_terminal_command(args, dry=dry)
        self.log_output(
            f"=== {label} requires terminal passphrase entry ===\n"
            f"For safety, F.O.R.G.E will not run interactive passphrase prompts inside the GUI output pane.\n"
            f"Command copied/shown for terminal review:\n{cmd}\n",
            "crypto",
        )
        self.crypto_copy_terminal_command(args, dry=dry)
        self.crypto_message("Run in terminal", "Passphrase-based age operations require interactive terminal entry. The command has been shown in the Encryption output log and copied to clipboard where possible.", "info")
        return
    def worker():
        self.root.after(0, lambda: self.set_status("crypto_status", f"Running: {label}", "Calling sentinel-forge-crypto backend now.", "running"))
        res = run_crypto_backend(args, dry_run=dry)
        def done():
            status = str(res.get("status", "unknown"))
            if status in ("ok", "dry-run"):
                level = "pass"
                detail = res.get("stdout") or res.get("message") or status
            else:
                level = "fail"
                detail = res.get("error") or res.get("stderr") or status
            try:
                self.set_status("crypto_status", "PASS" if level == "pass" else "FAILED", str(detail), level)
            except Exception:
                pass
            self.log_output(f"=== Encryption & Secure Media: {label} ===\n" + json.dumps(res, indent=2), "crypto")
        self.root.after(0, done)
    threading.Thread(target=worker, daemon=True).start()


def _crypto_build_mode_args(self, encrypt: bool = True) -> List[str]:
    if self.crypto_passphrase_var.get():
        return ["--passphrase"]
    key = self.crypto_key_var.get().strip()
    if key:
        return ["--recipient", key] if encrypt else ["--identity", key]
    return []

def _crypto_build(self, parent) -> None:
    """Build the v1.0.3 Encryption tab.

    v1.0.5 keeps the v1.0.4 recovery-kit work and adds bridge handoffs, USB encryption actions, and final audit scaffolding:
    - safer browse helpers and automatic output-name buttons;
    - preflight path/mode validation before backend execution;
    - device table refresh/select helper;
    - explicit GUI confirmation dialogs before critical LUKS actions;
    - terminal-command copy path for interactive passphrase operations.
    """
    tk, ttk = self.tk, self.ttk

    shell = ttk.Frame(parent)
    shell.pack(fill="both", expand=True)
    canvas = tk.Canvas(shell, bg=THEME_BG, highlightthickness=0, borderwidth=0)
    yscroll = ttk.Scrollbar(shell, orient="vertical", command=canvas.yview, style="Vertical.TScrollbar")
    canvas.configure(yscrollcommand=yscroll.set)
    yscroll.pack(side="right", fill="y")
    canvas.pack(side="left", fill="both", expand=True)
    body = ttk.Frame(canvas)
    self.crypto_body = body
    body_window = canvas.create_window((0, 0), window=body, anchor="nw")

    def _sync_scroll_region(_event=None):
        try: canvas.configure(scrollregion=canvas.bbox("all"))
        except Exception: pass

    def _sync_body_width(event):
        try: canvas.itemconfigure(body_window, width=event.width)
        except Exception: pass

    def _scroll_units(event):
        if getattr(event, "num", None) == 4: return -3
        if getattr(event, "num", None) == 5: return 3
        delta = getattr(event, "delta", 0)
        return int(-1 * (delta / 120)) if delta else 0

    def _on_mousewheel(event):
        units = _scroll_units(event)
        if units:
            canvas.yview_scroll(units, "units")
            return "break"

    body.bind("<Configure>", _sync_scroll_region)
    canvas.bind("<Configure>", _sync_body_width)
    for w in (canvas, body):
        w.bind("<MouseWheel>", _on_mousewheel, add="+")
        w.bind("<Button-4>", _on_mousewheel, add="+")
        w.bind("<Button-5>", _on_mousewheel, add="+")
    self.crypto_scroll_canvas = canvas

    def card(title: str):
        lf = ttk.LabelFrame(body, text=title)
        lf.pack(fill="x", padx=(0, 8), pady=(8, 6))
        lf.columnconfigure(1, weight=1)
        return lf

    def button_grid(parent_widget, specs, columns: int = 3, start_row: int = 0, columnspan: int = 4):
        frm = ttk.Frame(parent_widget)
        frm.grid(row=start_row, column=0, columnspan=columnspan, sticky="ew", padx=8, pady=6)
        for col in range(columns):
            frm.columnconfigure(col, weight=1, uniform="crypto_buttons")
        for idx, spec in enumerate(specs):
            if len(spec) == 2:
                label, command = spec; style = "TButton"
            else:
                label, command, style = spec
            ttk.Button(frm, text=label, command=command, style=style).grid(row=idx // columns, column=idx % columns, sticky="ew", padx=4, pady=4)
        return frm

    self._section(body, "Encryption & Secure Media", "F.O.R.G.E module for encrypted files, folders, LUKS containers, USB/disk workflows, and recovery headers. Backend: sentinel-forge-crypto. No custom cryptography.")
    note_box = ttk.Frame(body, style="Panel.TFrame")
    note_box.pack(fill="x", padx=(0, 8), pady=(0, 8))
    note = (
        "v1.0.5 bridge patch: choose inputs/outputs with browse helpers, use Auto Name Output before encrypt/decrypt, "
        "and review device paths before any LUKS action. Passphrase-based age actions are copied as terminal commands so the GUI never hangs on an interactive prompt."
    )
    tk.Label(note_box, text=note, bg=THEME_PANEL, fg=THEME_MUTED, justify="left", anchor="w", wraplength=940).pack(fill="x", padx=10, pady=8)

    actions = card("Backend / Readiness")
    button_grid(actions, [
        ("Backend Status", self.gui_crypto_status),
        ("Dependency Check", self.gui_crypto_deps),
        ("Refresh Device Table", self.crypto_refresh_device_table),
        ("Open Crypto Backend GUI", self.gui_crypto_open_backend_gui),
        ("Open 11_Encrypted", self.crypto_open_workspace),
        ("Open Containers", self.crypto_open_containers),
    ], columns=3, start_row=0, columnspan=4)
    try:
        self._status_panel(body, "crypto_status", "Encryption & Secure Media Status")
    except Exception:
        pass

    filebox = card("File / Folder Encryption")
    self.crypto_input_var = tk.StringVar()
    self.crypto_output_var = tk.StringVar(value=str(CRYPTO_FILES / "output.age"))
    self.crypto_key_var = tk.StringVar()
    self.crypto_passphrase_var = tk.BooleanVar(value=True)
    rows = [
        ("Input file/folder:", self.crypto_input_var, "input"),
        ("Output file/folder:", self.crypto_output_var, "output"),
        ("Recipient public key / identity file:", self.crypto_key_var, "identity"),
    ]
    for i, (lab, var, kind) in enumerate(rows):
        ttk.Label(filebox, text=lab).grid(row=i, column=0, sticky="w", padx=8, pady=4)
        ent = ttk.Entry(filebox, textvariable=var)
        ent.grid(row=i, column=1, sticky="ew", padx=4, pady=4)
        if kind == "input":
            ttk.Button(filebox, text="Choose File", command=lambda v=var: self.crypto_choose_any_file(v)).grid(row=i, column=2, sticky="ew", padx=4, pady=4)
            ttk.Button(filebox, text="Choose Folder", command=lambda v=var: self.choose_dir(v)).grid(row=i, column=3, sticky="ew", padx=4, pady=4)
        elif kind == "output":
            ttk.Button(filebox, text="Save As", command=lambda v=var: self.crypto_choose_save_file(v, ".age")).grid(row=i, column=2, sticky="ew", padx=4, pady=4)
            ttk.Button(filebox, text="Output Folder", command=lambda v=var: self.crypto_choose_output_dir(v, "file-encrypt")).grid(row=i, column=3, sticky="ew", padx=4, pady=4)
        else:
            ttk.Button(filebox, text="Choose Identity", command=lambda v=var: self.crypto_choose_any_file(v, "Choose age identity file")).grid(row=i, column=2, sticky="ew", padx=4, pady=4)
            ttk.Button(filebox, text="Clear Key", command=lambda v=var: v.set("")).grid(row=i, column=3, sticky="ew", padx=4, pady=4)
        try: self._try_register_drop(ent, var)
        except Exception: pass
    ttk.Checkbutton(filebox, text="Use passphrase mode", variable=self.crypto_passphrase_var).grid(row=3, column=1, columnspan=3, sticky="w", padx=4, pady=4)
    button_grid(filebox, [
        ("Auto Name: File Encrypt", lambda: self.crypto_apply_suggested_output("file-encrypt")),
        ("Auto Name: File Decrypt", lambda: self.crypto_apply_suggested_output("file-decrypt")),
        ("Auto Name: Folder Encrypt", lambda: self.crypto_apply_suggested_output("folder-encrypt")),
        ("Auto Name: Folder Decrypt", lambda: self.crypto_apply_suggested_output("folder-decrypt")),
        ("Open Files", self.crypto_open_files),
        ("Open Folders", self.crypto_open_folders),
    ], columns=3, start_row=4, columnspan=4)
    button_grid(filebox, [
        ("Dry Run File Encrypt", lambda: self.gui_crypto_file_encrypt(True)),
        ("Encrypt File", lambda: self.gui_crypto_file_encrypt(False)),
        ("Decrypt File", lambda: self.gui_crypto_file_decrypt(False)),
        ("Dry Run Folder Encrypt", lambda: self.gui_crypto_folder_encrypt(True)),
        ("Encrypt Folder", lambda: self.gui_crypto_folder_encrypt(False)),
        ("Decrypt Folder", lambda: self.gui_crypto_folder_decrypt(False)),
        ("Copy File Encrypt Command", lambda: self.crypto_copy_terminal_command(["file-encrypt", self.crypto_input_var.get(), self.crypto_output_var.get()] + self.crypto_build_mode_args(True), dry=False)),
        ("Copy Folder Encrypt Command", lambda: self.crypto_copy_terminal_command(["folder-encrypt", self.crypto_input_var.get(), self.crypto_output_var.get()] + self.crypto_build_mode_args(True), dry=False)),
    ], columns=4, start_row=5, columnspan=4)
    for col in (2, 3): filebox.columnconfigure(col, weight=0)

    keybox = card("age Identity Key Helper")
    self.crypto_identity_output_var = tk.StringVar(value=str(CRYPTO_KEYS / "sentinel_forge_identity.txt"))
    ttk.Label(keybox, text="Identity output file:").grid(row=0, column=0, sticky="w", padx=8, pady=4)
    ttk.Entry(keybox, textvariable=self.crypto_identity_output_var).grid(row=0, column=1, sticky="ew", padx=4, pady=4)
    ttk.Button(keybox, text="Save As", command=lambda: self.crypto_choose_save_file(self.crypto_identity_output_var, ".txt")).grid(row=0, column=2, sticky="ew", padx=4, pady=4)
    button_grid(keybox, [
        ("Dry Run Keygen", lambda: self.gui_crypto_age_keygen(True)),
        ("Generate Identity Key", lambda: self.gui_crypto_age_keygen(False)),
        ("Use as Identity", lambda: self.crypto_key_var.set(self.crypto_identity_output_var.get())),
        ("Open Keys", lambda: self.open_path(CRYPTO_KEYS)),
    ], columns=4, start_row=1, columnspan=3)
    keybox.columnconfigure(1, weight=1)

    diskbox = card("Containers / LUKS / Mounting")
    self.crypto_container_var = tk.StringVar(value=str(CRYPTO_CONTAINERS / "sentinel-container.img"))
    self.crypto_size_var = tk.StringVar(value="2G")
    self.crypto_device_var = tk.StringVar()
    self.crypto_label_var = tk.StringVar(value="SENTINEL_FORGE")
    self.crypto_mapping_var = tk.StringVar(value="sentinel_forge_secure")
    self.crypto_mount_var = tk.StringVar(value=str(CRYPTO_MOUNTS / "sentinel_forge_secure"))
    self.crypto_header_var = tk.StringVar(value=str(CRYPTO_HEADERS / "sentinel_forge_secure.luks-header"))
    self.crypto_confirm_var = tk.StringVar()
    drows = [
        ("Container path:", self.crypto_container_var, "save"),
        ("Container size:", self.crypto_size_var, "plain"),
        ("Device/container to open/format:", self.crypto_device_var, "file"),
        ("LUKS label:", self.crypto_label_var, "plain"),
        ("Mapping name:", self.crypto_mapping_var, "plain"),
        ("Mountpoint:", self.crypto_mount_var, "folder"),
        ("Header backup file:", self.crypto_header_var, "save"),
        ("Confirm word:", self.crypto_confirm_var, "plain"),
    ]
    for i, (lab, var, kind) in enumerate(drows):
        ttk.Label(diskbox, text=lab).grid(row=i, column=0, sticky="w", padx=8, pady=4)
        ent = ttk.Entry(diskbox, textvariable=var)
        ent.grid(row=i, column=1, sticky="ew", padx=4, pady=4)
        if kind == "save": ttk.Button(diskbox, text="Save As", command=lambda v=var: self.crypto_choose_save_file(v)).grid(row=i, column=2, sticky="ew", padx=4, pady=4)
        elif kind == "file": ttk.Button(diskbox, text="Choose File", command=lambda v=var: self.crypto_choose_any_file(v)).grid(row=i, column=2, sticky="ew", padx=4, pady=4)
        elif kind == "folder": ttk.Button(diskbox, text="Choose Folder", command=lambda v=var: self.crypto_choose_mount_dir(v)).grid(row=i, column=2, sticky="ew", padx=4, pady=4)
        try: self._try_register_drop(ent, var)
        except Exception: pass
    button_grid(diskbox, [
        ("Dry Create Container", lambda: self.gui_crypto_container_create(True)),
        ("Create Container", lambda: self.gui_crypto_container_create(False)),
        ("Dry LUKS Format", lambda: self.gui_crypto_luks_format(True)),
        ("LUKS FORMAT", lambda: self.gui_crypto_luks_format(False), "Danger.TButton"),
        ("Header Backup", lambda: self.gui_crypto_header_backup(False)),
        ("Header Restore", lambda: self.gui_crypto_header_restore(False), "Danger.TButton"),
    ], columns=3, start_row=8, columnspan=3)
    button_grid(diskbox, [
        ("Open Mapping", lambda: self.gui_crypto_luks_open(False)),
        ("Close Mapping", lambda: self.gui_crypto_luks_close(False)),
        ("Mapping Status", self.gui_crypto_luks_status),
        ("Mount", lambda: self.gui_crypto_mount(False)),
        ("Unmount", lambda: self.gui_crypto_unmount(False)),
        ("Open Headers", self.crypto_open_headers),
    ], columns=3, start_row=9, columnspan=3)
    diskbox.columnconfigure(1, weight=1)

    devbox = card("Device Table / Selection Helper")
    cols = ("path", "size", "type", "model", "mount")
    self.crypto_device_tree = ttk.Treeview(devbox, columns=cols, show="headings", height=6)
    headings = {"path": "Path", "size": "Size", "type": "Type", "model": "Model/Label/FSType", "mount": "Mount"}
    widths = {"path": 180, "size": 80, "type": 70, "model": 230, "mount": 240}
    for c in cols:
        self.crypto_device_tree.heading(c, text=headings[c])
        self.crypto_device_tree.column(c, width=widths[c], anchor="w")
    self.crypto_device_tree.grid(row=0, column=0, columnspan=3, sticky="ew", padx=8, pady=6)
    button_grid(devbox, [
        ("Refresh Devices", self.crypto_refresh_device_table),
        ("Use Selected Device", self.crypto_apply_selected_device_to_field),
        ("Copy Device Listing Command", lambda: self.crypto_copy_terminal_command(["list-devices"], dry=False)),
    ], columns=3, start_row=1, columnspan=3)
    devbox.columnconfigure(0, weight=1)

    outputbox = card("Encryption Output / Audit Log")
    self._add_output(outputbox, "crypto", 10)
    _sync_scroll_region()

def _gui_crypto_status(self) -> None:
    self.log_output("=== Encryption & Secure Media Status ===\n" + json.dumps(forge_crypto_status(), indent=2), "crypto")


def _gui_crypto_deps(self) -> None:
    if not self.crypto_validate_backend():
        return
    self.crypto_run_gui_action("Dependency Check", ["deps"])


def _gui_crypto_list_devices(self) -> None:
    if not self.crypto_validate_backend():
        return
    self.crypto_run_gui_action("List Devices", ["list-devices"])


def _gui_crypto_open_backend_gui(self) -> None:
    cmd = crypto_gui_command()
    if not cmd:
        self.log_output("sentinel-forge-crypto-gui is not installed or not in PATH.", "crypto")
        return
    try:
        subprocess.Popen([cmd])
        self.log_output("Opened sentinel-forge-crypto-gui.", "crypto")
    except Exception as e:
        self.log_output(f"Failed to open backend GUI: {e}", "crypto")


def _gui_crypto_age_keygen(self, dry=False) -> None:
    if not self.crypto_validate_backend():
        return
    out = self.crypto_identity_output_var.get().strip()
    if not out:
        self.crypto_error("Choose an identity key output path first.")
        return
    if Path(out).expanduser().exists() and not dry:
        self.crypto_error(f"Identity key file already exists. Choose a new key filename:\n\n{out}")
        return
    self.crypto_run_gui_action("age Identity Keygen", ["age-keygen", out], dry=dry)


def _gui_crypto_file_encrypt(self, dry=False) -> None:
    if not self.crypto_validate_file_encrypt(dry=dry):
        return
    mode = self.crypto_build_mode_args(encrypt=True)
    self.crypto_run_gui_action("File Encrypt", ["file-encrypt", self.crypto_input_var.get(), self.crypto_output_var.get()] + mode, dry=dry)


def _gui_crypto_file_decrypt(self, dry=False) -> None:
    if not self.crypto_validate_file_decrypt(dry=dry):
        return
    mode = self.crypto_build_mode_args(encrypt=False)
    self.crypto_run_gui_action("File Decrypt", ["file-decrypt", self.crypto_input_var.get(), self.crypto_output_var.get()] + mode, dry=dry)


def _gui_crypto_folder_encrypt(self, dry=False) -> None:
    if not self.crypto_validate_folder_encrypt(dry=dry):
        return
    mode = self.crypto_build_mode_args(encrypt=True)
    self.crypto_run_gui_action("Folder Encrypt", ["folder-encrypt", self.crypto_input_var.get(), self.crypto_output_var.get()] + mode, dry=dry)


def _gui_crypto_folder_decrypt(self, dry=False) -> None:
    if not self.crypto_validate_folder_decrypt(dry=dry):
        return
    mode = self.crypto_build_mode_args(encrypt=False)
    self.crypto_run_gui_action("Folder Decrypt", ["folder-decrypt", self.crypto_input_var.get(), self.crypto_output_var.get()] + mode, dry=dry)


def _gui_crypto_container_create(self, dry=False) -> None:
    if not self.crypto_validate_container_create(dry=dry):
        return
    if not dry:
        ok = self.crypto_confirm_danger(
            "Create encrypted container image?",
            "F.O.R.G.E will create a new blank container image file. This is not destructive to existing devices, but the output path must be correct. Continue?",
        )
        if not ok:
            self.log_output("Container creation cancelled by user.", "crypto")
            return
    self.crypto_run_gui_action("Create Container", ["container-create", self.crypto_container_var.get(), "--size", self.crypto_size_var.get()] + ([] if dry else ["--execute"]), dry=dry)


def _gui_crypto_luks_format(self, dry=False) -> None:
    dev = self.crypto_validate_luks_source()
    if not dev or not self.crypto_validate_mapping():
        return
    args = ["luks-format", dev]
    label = self.crypto_label_var.get().strip()
    if label:
        args += ["--label", label]
    if not dry:
        if self.crypto_confirm_var.get().strip() != "ERASE":
            self.crypto_error("Type ERASE in Confirm word before LUKS FORMAT.")
            return
        ok = self.crypto_confirm_danger(
            "CRITICAL: LUKS FORMAT will erase data",
            f"This action will initialize LUKS encryption on:\n\n{dev}\n\nExisting data on that target can be destroyed. Confirm only if this is the correct empty container/device.",
        )
        if not ok:
            self.log_output("LUKS format cancelled by user.", "crypto")
            return
        args += ["--execute", "--confirm", "ERASE"]
    self.crypto_run_gui_action("LUKS Format", args, dry=dry)


def _gui_crypto_luks_open(self, dry=False) -> None:
    dev = self.crypto_validate_luks_source()
    if not dev or not self.crypto_validate_mapping():
        return
    self.crypto_run_gui_action("LUKS Open", ["luks-open", dev, self.crypto_mapping_var.get()], dry=dry)


def _gui_crypto_luks_close(self, dry=False) -> None:
    if not self.crypto_validate_backend() or not self.crypto_validate_mapping():
        return
    self.crypto_run_gui_action("LUKS Close", ["luks-close", self.crypto_mapping_var.get()], dry=dry)


def _gui_crypto_luks_status(self) -> None:
    if not self.crypto_validate_backend() or not self.crypto_validate_mapping():
        return
    self.crypto_run_gui_action("LUKS Status", ["luks-status", self.crypto_mapping_var.get()])


def _gui_crypto_header_backup(self, dry=False) -> None:
    dev = self.crypto_validate_luks_source()
    if not dev:
        return
    if not self.crypto_header_var.get().strip():
        self.crypto_error("Choose a header backup output file first.")
        return
    self.crypto_run_gui_action("LUKS Header Backup", ["luks-header-backup", dev, self.crypto_header_var.get()], dry=dry)


def _gui_crypto_header_restore(self, dry=False) -> None:
    dev = self.crypto_validate_luks_source()
    if not dev:
        return
    header = self.crypto_header_var.get().strip()
    if not header or not Path(header).expanduser().exists():
        self.crypto_error(f"Header backup file does not exist:\n\n{header}")
        return
    args = ["luks-header-restore", dev, header]
    if not dry:
        if self.crypto_confirm_var.get().strip() != "RESTORE_HEADER":
            self.crypto_error("Type RESTORE_HEADER in Confirm word before header restore.")
            return
        ok = self.crypto_confirm_danger(
            "CRITICAL: Restore LUKS header?",
            f"This will restore a LUKS header onto:\n\n{dev}\n\nWrong header restore can make encrypted data inaccessible. Continue only if the backup file matches this device/container.",
        )
        if not ok:
            self.log_output("LUKS header restore cancelled by user.", "crypto")
            return
        args += ["--execute", "--confirm", "RESTORE_HEADER"]
    self.crypto_run_gui_action("LUKS Header Restore", args, dry=dry)


def _gui_crypto_mount(self, dry=False) -> None:
    if not self.crypto_validate_backend() or not self.crypto_validate_mapping():
        return
    mount = self.crypto_mount_var.get().strip()
    if not mount:
        self.crypto_error("Choose a mountpoint first.")
        return
    self.crypto_run_gui_action("Mount Mapping", ["mount", self.crypto_mapping_var.get(), mount], dry=dry)


def _gui_crypto_unmount(self, dry=False) -> None:
    if not self.crypto_validate_backend():
        return
    mount = self.crypto_mount_var.get().strip()
    if not mount:
        self.crypto_error("Choose a mountpoint first.")
        return
    self.crypto_run_gui_action("Unmount", ["unmount", mount], dry=dry)


ForgeGUI._build_crypto = _crypto_build
ForgeGUI.crypto_choose_any_file = _crypto_choose_any_file
ForgeGUI.crypto_choose_save_file = _crypto_choose_save_file
ForgeGUI.crypto_choose_output_dir = _crypto_choose_output_dir
ForgeGUI.crypto_choose_mount_dir = _crypto_choose_mount_dir
ForgeGUI.crypto_open_workspace = _crypto_open_workspace
ForgeGUI.crypto_open_containers = _crypto_open_containers
ForgeGUI.crypto_open_files = _crypto_open_files
ForgeGUI.crypto_open_folders = _crypto_open_folders
ForgeGUI.crypto_open_headers = _crypto_open_headers
ForgeGUI.crypto_terminal_command = _crypto_terminal_command
ForgeGUI.crypto_copy_terminal_command = _crypto_copy_terminal_command
ForgeGUI.crypto_message = _crypto_message
ForgeGUI.crypto_error = _crypto_error
ForgeGUI.crypto_confirm_danger = _crypto_confirm_danger
ForgeGUI.crypto_expand = _crypto_expand
ForgeGUI.crypto_output_exists_block = _crypto_output_exists_block
ForgeGUI.crypto_validate_backend = _crypto_validate_backend
ForgeGUI.crypto_validate_file_encrypt = _crypto_validate_file_encrypt
ForgeGUI.crypto_validate_file_decrypt = _crypto_validate_file_decrypt
ForgeGUI.crypto_validate_folder_encrypt = _crypto_validate_folder_encrypt
ForgeGUI.crypto_validate_folder_decrypt = _crypto_validate_folder_decrypt
ForgeGUI.crypto_validate_container_create = _crypto_validate_container_create
ForgeGUI.crypto_validate_luks_source = _crypto_validate_luks_source
ForgeGUI.crypto_validate_mapping = _crypto_validate_mapping
ForgeGUI.crypto_suggest_output_name = _crypto_suggest_output_name
ForgeGUI.crypto_apply_suggested_output = _crypto_apply_suggested_output
ForgeGUI.crypto_apply_selected_device_to_field = _crypto_apply_selected_device_to_field
ForgeGUI.crypto_refresh_device_table = _crypto_refresh_device_table
ForgeGUI.crypto_run_gui_action = _crypto_run_gui_action
ForgeGUI.crypto_build_mode_args = _crypto_build_mode_args
ForgeGUI.gui_crypto_status = _gui_crypto_status
ForgeGUI.gui_crypto_deps = _gui_crypto_deps
ForgeGUI.gui_crypto_list_devices = _gui_crypto_list_devices
ForgeGUI.gui_crypto_open_backend_gui = _gui_crypto_open_backend_gui
ForgeGUI.gui_crypto_age_keygen = _gui_crypto_age_keygen
ForgeGUI.gui_crypto_file_encrypt = _gui_crypto_file_encrypt
ForgeGUI.gui_crypto_file_decrypt = _gui_crypto_file_decrypt
ForgeGUI.gui_crypto_folder_encrypt = _gui_crypto_folder_encrypt
ForgeGUI.gui_crypto_folder_decrypt = _gui_crypto_folder_decrypt
ForgeGUI.gui_crypto_container_create = _gui_crypto_container_create
ForgeGUI.gui_crypto_luks_format = _gui_crypto_luks_format
ForgeGUI.gui_crypto_luks_open = _gui_crypto_luks_open
ForgeGUI.gui_crypto_luks_close = _gui_crypto_luks_close
ForgeGUI.gui_crypto_luks_status = _gui_crypto_luks_status
ForgeGUI.gui_crypto_header_backup = _gui_crypto_header_backup
ForgeGUI.gui_crypto_header_restore = _gui_crypto_header_restore
ForgeGUI.gui_crypto_mount = _gui_crypto_mount
ForgeGUI.gui_crypto_unmount = _gui_crypto_unmount


_release_check_before_crypto = release_check

def release_check() -> Dict[str, object]:
    res = _release_check_before_crypto()
    checks = list(res.get("checks", []))
    backend_ok = crypto_backend_available()
    checks.append({
        "name": "crypto-backend",
        "status": "pass" if backend_ok else "warn",
        "detail": crypto_backend_command() if backend_ok else "sentinel-forge-crypto not installed; Encryption tab will show backend unavailable until installed",
    })
    checks.append({
        "name": "crypto-actions",
        "status": "pass",
        "detail": "AEGIS crypto action bridge registered",
    })
    fail_count = sum(1 for c in checks if c.get("status") == "fail")
    warn_count = sum(1 for c in checks if c.get("status") == "warn")
    res["checks"] = checks
    res["status"] = "pass" if fail_count == 0 else "failed"
    res["summary"] = {
        "checks": len(checks),
        "passed": sum(1 for c in checks if c.get("status") == "pass"),
        "failed": fail_count,
        "warnings": warn_count,
    }
    res["phase"] = "v1.0.3 encryption GUI usability patch"
    res["next_step"] = "Install sentinel-forge-crypto alongside F.O.R.G.E for full Encryption & Secure Media operation." if not backend_ok else "Crypto integration is available; perform live VM/device testing before promoting to Encryption & Secure Media stable lock."
    return res


# ------------------------- v1.0.5 Bridge / USB / Final Audit Patch -------------------------
# v1.0.4 keeps all v1.0.3 Encryption GUI usability behavior, then adds a
# non-destructive recovery kit generator for LUKS/container workflows. The kit
# does not weaken encryption or bypass passphrases; it creates documentation,
# manifests, checksums, and optional local copies of header/key files selected by
# the user. F.O.R.G.E still implements no custom cryptography.

CRYPTO_RECOVERY = CRYPTO_WORKSPACE / "Recovery_Kits"

_default_workspace_tree_before_v104 = default_workspace_tree

def default_workspace_tree(root: Path) -> List[Path]:
    paths = list(_default_workspace_tree_before_v104(root))
    extra = [root / "11_Encrypted" / "Recovery_Kits"]
    for p in extra:
        if p not in paths:
            paths.append(p)
    return paths


def _crypto_file_sha_record(path: Path, base: Path) -> Optional[Dict[str, object]]:
    try:
        return {
            "path": str(path.relative_to(base)),
            "size": path.stat().st_size,
            "sha256": sha256_file(path),
        }
    except Exception:
        return None


def _write_recovery_sha256s(kit_dir: Path, files: List[Path]) -> Path:
    sums = kit_dir / "SHA256SUMS"
    rows = []
    for p in sorted(files):
        if p.name == "SHA256SUMS" or not p.is_file():
            continue
        try:
            rows.append(f"{sha256_file(p)}  {p.relative_to(kit_dir)}")
        except Exception:
            continue
    sums.write_text("\n".join(rows) + ("\n" if rows else ""), encoding="utf-8")
    return sums


def create_crypto_recovery_kit(
    kit_name: str = "sentinel_forge_recovery",
    target: str = "",
    header: str = "",
    identity: str = "",
    include_identity: bool = False,
    include_header: bool = True,
    out_dir: str = "",
    notes: str = "",
    dry_run: bool = False,
) -> Dict[str, object]:
    """Create a local recovery kit folder for encrypted media workflows.

    This is a documentation/checksum/copy helper only. It never decrypts data,
    never stores passphrases, and never performs LUKS header restore.
    """
    base = Path(out_dir or CRYPTO_RECOVERY).expanduser()
    safe_name = sanitize_id(kit_name or "sentinel_forge_recovery")
    stamp = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    kit_dir = base / f"{safe_name}_{stamp}"
    header_path = Path(header).expanduser() if header else None
    identity_path = Path(identity).expanduser() if identity else None
    warnings = [
        "This kit does not contain or recover forgotten passphrases.",
        "Lost LUKS passphrase/key material can mean permanent data loss.",
        "Store recovery kits offline and away from the encrypted device/container.",
        "Test recovery workflows on disposable containers before trusting important data.",
    ]
    would_copy: List[Dict[str, str]] = []
    errors: List[str] = []
    if include_header and header_path:
        if not header_path.exists() or not header_path.is_file():
            errors.append(f"Header file does not exist: {header_path}")
        else:
            would_copy.append({"kind": "luks-header", "source": str(header_path), "destination": f"headers/{header_path.name}"})
    if include_identity and identity_path:
        if not identity_path.exists() or not identity_path.is_file():
            errors.append(f"Identity key file does not exist: {identity_path}")
        else:
            would_copy.append({"kind": "age-identity", "source": str(identity_path), "destination": f"keys/{identity_path.name}"})
            warnings.append("This kit includes an age identity/private key copy. Treat the kit itself as sensitive secret material.")
    elif identity_path:
        warnings.append("Identity key was referenced but not copied. Keep that key backed up separately.")
    if errors:
        return {"status": "error", "errors": errors, "kit_dir": str(kit_dir), "would_copy": would_copy}
    if dry_run:
        return {
            "status": "dry-run",
            "kit_dir": str(kit_dir),
            "would_create": [
                "RECOVERY_README.md",
                "RECOVERY_CHECKLIST.md",
                "recovery_manifest.json",
                "SAFETY_NOTES.md",
                "SHA256SUMS",
            ],
            "would_copy": would_copy,
            "warnings": warnings,
        }

    if kit_dir.exists():
        return {"status": "error", "error": f"Recovery kit path already exists: {kit_dir}"}
    (kit_dir / "headers").mkdir(parents=True, exist_ok=False)
    (kit_dir / "keys").mkdir(parents=True, exist_ok=True)
    (kit_dir / "notes").mkdir(parents=True, exist_ok=True)
    copied: List[Dict[str, object]] = []
    if include_header and header_path and header_path.exists():
        dst = kit_dir / "headers" / header_path.name
        shutil.copy2(header_path, dst)
        copied.append({"kind": "luks-header", "source": str(header_path), "destination": str(dst), "sha256": sha256_file(dst)})
    if include_identity and identity_path and identity_path.exists():
        dst = kit_dir / "keys" / identity_path.name
        shutil.copy2(identity_path, dst)
        try:
            os.chmod(dst, 0o600)
        except Exception:
            pass
        copied.append({"kind": "age-identity", "source": str(identity_path), "destination": str(dst), "sha256": sha256_file(dst)})

    manifest = {
        "program": PROGRAM_NUMBER,
        "app": APP_NAME,
        "version": VERSION,
        "component": "F.O.R.G.E Encryption & Secure Media Recovery Kit",
        "created": now_iso(),
        "kit_name": kit_name,
        "kit_dir": str(kit_dir),
        "target_device_or_container": target,
        "header_source": str(header_path) if header_path else "",
        "identity_source": str(identity_path) if identity_path else "",
        "include_header_copy": bool(include_header),
        "include_identity_copy": bool(include_identity),
        "custom_crypto": False,
        "copied_files": copied,
        "warnings": warnings,
        "notes": notes,
    }

    readme = f"""# Sentinel F.O.R.G.E Recovery Kit

**Kit:** {kit_name or safe_name}  
**Created:** {manifest['created']}  
**F.O.R.G.E version:** {VERSION}  
**Target:** {target or 'Not specified'}

## Purpose

This folder stores recovery documentation, manifests, checksums, and optional copies of selected LUKS header or age identity files for Sentinel F.O.R.G.E Encryption & Secure Media workflows.

## Critical warnings

- This kit does **not** store passphrases.
- This kit does **not** bypass encryption.
- Lost passphrases, destroyed headers, or missing identity keys can mean permanent data loss.
- Keep this kit offline and physically separate from the encrypted media.
- Never restore a LUKS header unless you are certain the header belongs to the correct device/container.

## Included copies

{chr(10).join('- ' + x['kind'] + ': ' + x['destination'] for x in copied) if copied else '- No header/key files copied; kit contains documentation and references only.'}

## User notes

{notes or 'No extra notes supplied.'}
"""
    checklist = """# Recovery Checklist

Before relying on an encrypted container/device:

- [ ] Confirm the encrypted target path is correct.
- [ ] Confirm the passphrase is known and tested.
- [ ] Create a LUKS header backup after formatting.
- [ ] Store header backup away from the encrypted target.
- [ ] Store age identity/private keys offline if key-based encryption is used.
- [ ] Verify SHA256SUMS inside this kit.
- [ ] Test open/mount/close on a disposable or non-critical target first.
- [ ] Do not restore headers unless the backup/device pair is verified.

Emergency reminder:

- If unsure, stop. Do not format, restore headers, or overwrite anything.
"""
    safety = """# Safety Notes

F.O.R.G.E does not implement custom cryptography. Encryption work is delegated to sentinel-forge-crypto, which wraps proven system tools such as cryptsetup/LUKS/dm-crypt, age, and optional fscrypt.

Never store passphrases in this kit. For family/household use, keep recovery material physically protected, clearly labelled, and separated from the encrypted USB/disk/container.

Recommended copies:

1. One offline copy in a safe place.
2. One sealed emergency copy if the data matters to the household.
3. No cloud copy unless you deliberately accept that risk.
"""
    (kit_dir / "RECOVERY_README.md").write_text(readme, encoding="utf-8")
    (kit_dir / "RECOVERY_CHECKLIST.md").write_text(checklist, encoding="utf-8")
    (kit_dir / "SAFETY_NOTES.md").write_text(safety, encoding="utf-8")
    (kit_dir / "notes" / "USER_NOTES.txt").write_text(notes or "", encoding="utf-8")
    (kit_dir / "recovery_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    files = [p for p in kit_dir.rglob("*") if p.is_file()]
    sums = _write_recovery_sha256s(kit_dir, files)
    files.append(sums)
    file_records = [r for r in (_crypto_file_sha_record(p, kit_dir) for p in files) if r]
    manifest["files"] = file_records
    (kit_dir / "recovery_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    _write_recovery_sha256s(kit_dir, [p for p in kit_dir.rglob("*") if p.is_file()])
    audit("crypto-recovery-kit", str(kit_dir), "ok", {"target": target, "copied": copied})
    return {"status": "ok", "kit_dir": str(kit_dir), "manifest": str(kit_dir / "recovery_manifest.json"), "copied": copied, "warnings": warnings}


def _parse_crypto_recovery_args(rest: List[str]) -> Dict[str, object]:
    if not rest:
        raise ValueError("kit name required")
    opts: Dict[str, object] = {
        "kit_name": rest[0],
        "target": "",
        "header": "",
        "identity": "",
        "include_identity": False,
        "include_header": True,
        "out_dir": "",
        "notes": "",
    }
    i = 1
    while i < len(rest):
        token = rest[i]
        if token in ("--target", "--header", "--identity", "--output-dir", "--notes"):
            if i + 1 >= len(rest):
                raise ValueError(f"missing value for {token}")
            key = token[2:].replace("-", "_")
            if key == "output_dir":
                key = "out_dir"
            opts[key] = rest[i + 1]
            i += 2
        elif token == "--json":
            i += 1
        elif token == "--include-identity":
            opts["include_identity"] = True
            i += 1
        elif token == "--no-header-copy":
            opts["include_header"] = False
            i += 1
        else:
            raise ValueError(f"unknown recovery-kit option: {token}")
    return opts

CRYPTO_ACTION_HELP["crypto-recovery-kit"] = "crypto-recovery-kit <kit_name> [--target PATH] [--header FILE] [--identity FILE] [--include-identity] [--no-header-copy] [--output-dir DIR] [--notes TEXT]"

_dispatch_crypto_action_before_v104 = dispatch_crypto_action

def dispatch_crypto_action(action: str, rest: List[str], dry: bool = False) -> Dict[str, object]:
    if action == "crypto-recovery-kit":
        try:
            opts = _parse_crypto_recovery_args(rest)
        except Exception as e:
            usage = crypto_usage(action)
            usage["error"] = str(e)
            return usage
        return create_crypto_recovery_kit(dry_run=dry, **opts)
    return _dispatch_crypto_action_before_v104(action, rest, dry=dry)

_forge_actions_before_v104 = forge_actions

def forge_actions() -> Dict[str, object]:
    a = _forge_actions_before_v104()
    actions = list(a.get("actions", []))
    if not any(x.get("name") == "crypto-recovery-kit" for x in actions if isinstance(x, dict)):
        actions.append({"name": "crypto-recovery-kit", "risk": "low", "network": False, "phase": "v1.0.4"})
    a["actions"] = actions
    a["crypto_action_help"] = CRYPTO_ACTION_HELP
    return a


def _crypto_open_workspace_v104(self) -> None:
    self.open_path(CRYPTO_WORKSPACE)


def _crypto_open_recovery(self) -> None:
    CRYPTO_RECOVERY.mkdir(parents=True, exist_ok=True)
    self.open_path(CRYPTO_RECOVERY)


def _crypto_recovery_use_current(self) -> None:
    target = ""
    try:
        target = self.crypto_device_var.get().strip() or self.crypto_container_var.get().strip()
    except Exception:
        target = ""
    if target:
        self.crypto_recovery_target_var.set(target)
    try:
        if self.crypto_header_var.get().strip():
            self.crypto_recovery_header_var.set(self.crypto_header_var.get().strip())
    except Exception:
        pass
    try:
        if self.crypto_key_var.get().strip() and not self.crypto_passphrase_var.get():
            self.crypto_recovery_identity_var.set(self.crypto_key_var.get().strip())
    except Exception:
        pass


def _gui_crypto_recovery_kit(self, dry: bool = False) -> None:
    if not self.crypto_recovery_name_var.get().strip():
        self.crypto_error("Give the recovery kit a short name first.")
        return
    header = self.crypto_recovery_header_var.get().strip()
    identity = self.crypto_recovery_identity_var.get().strip()
    if self.crypto_recovery_include_header_var.get() and header:
        hp = Path(header).expanduser()
        if not hp.exists() or not hp.is_file():
            self.crypto_error(f"Selected header backup does not exist:\n\n{hp}")
            return
    if self.crypto_recovery_include_identity_var.get() and identity:
        ip = Path(identity).expanduser()
        if not ip.exists() or not ip.is_file():
            self.crypto_error(f"Selected identity key does not exist:\n\n{ip}")
            return
        if not dry:
            ok = self.crypto_confirm_danger(
                "Include private identity key?",
                "You selected Include identity/key copy. This can make the recovery kit sensitive secret material. Continue only if you will store the kit safely and offline.",
            )
            if not ok:
                self.log_output("Recovery kit generation cancelled before identity copy.", "crypto")
                return
    res = create_crypto_recovery_kit(
        kit_name=self.crypto_recovery_name_var.get().strip(),
        target=self.crypto_recovery_target_var.get().strip(),
        header=header,
        identity=identity,
        include_identity=bool(self.crypto_recovery_include_identity_var.get()),
        include_header=bool(self.crypto_recovery_include_header_var.get()),
        out_dir=self.crypto_recovery_out_var.get().strip(),
        notes=self.crypto_recovery_notes_var.get().strip(),
        dry_run=dry,
    )
    status = str(res.get("status", "unknown"))
    level = "pass" if status in ("ok", "dry-run") else "fail"
    try:
        self.set_status("crypto_status", "Recovery Kit " + status.upper(), str(res.get("kit_dir", status)), level)
    except Exception:
        pass
    self.log_output("=== Recovery Kit / Safety Documentation ===\n" + json.dumps(res, indent=2), "crypto")
    if status == "ok":
        self.crypto_message("Recovery kit created", f"Recovery kit created:\n\n{res.get('kit_dir')}\n\nStore this kit offline and away from the encrypted media.", "info")


def _crypto_add_recovery_card(self) -> None:
    tk, ttk = self.tk, self.ttk
    body = getattr(self, "crypto_body", None)
    if body is None:
        return
    self._section(body, "Recovery Kit / Safety", "Create a local recovery documentation kit for encrypted containers, headers, and key references. This does not store passphrases or bypass encryption.")
    box = ttk.LabelFrame(body, text="Recovery Kit Generator")
    box.pack(fill="x", padx=(0, 8), pady=(8, 6))
    box.columnconfigure(1, weight=1)
    self.crypto_recovery_name_var = tk.StringVar(value="sentinel_forge_recovery")
    self.crypto_recovery_target_var = tk.StringVar()
    self.crypto_recovery_header_var = tk.StringVar()
    self.crypto_recovery_identity_var = tk.StringVar()
    self.crypto_recovery_out_var = tk.StringVar(value=str(CRYPTO_RECOVERY))
    self.crypto_recovery_notes_var = tk.StringVar()
    self.crypto_recovery_include_header_var = tk.BooleanVar(value=True)
    self.crypto_recovery_include_identity_var = tk.BooleanVar(value=False)
    rows = [
        ("Kit name:", self.crypto_recovery_name_var, "plain"),
        ("Target device/container:", self.crypto_recovery_target_var, "file"),
        ("Header backup file:", self.crypto_recovery_header_var, "file"),
        ("Identity/private key file:", self.crypto_recovery_identity_var, "file"),
        ("Recovery kit output folder:", self.crypto_recovery_out_var, "folder"),
        ("Notes:", self.crypto_recovery_notes_var, "plain"),
    ]
    for i, (lab, var, kind) in enumerate(rows):
        ttk.Label(box, text=lab).grid(row=i, column=0, sticky="w", padx=8, pady=4)
        ent = ttk.Entry(box, textvariable=var)
        ent.grid(row=i, column=1, sticky="ew", padx=4, pady=4)
        if kind == "file":
            ttk.Button(box, text="Choose File", command=lambda v=var: self.crypto_choose_any_file(v)).grid(row=i, column=2, sticky="ew", padx=4, pady=4)
        elif kind == "folder":
            ttk.Button(box, text="Choose Folder", command=lambda v=var: self.choose_dir(v)).grid(row=i, column=2, sticky="ew", padx=4, pady=4)
        try:
            self._try_register_drop(ent, var)
        except Exception:
            pass
    ttk.Checkbutton(box, text="Copy selected LUKS header into kit", variable=self.crypto_recovery_include_header_var).grid(row=6, column=1, sticky="w", padx=4, pady=4)
    ttk.Checkbutton(box, text="Copy selected identity/private key into kit", variable=self.crypto_recovery_include_identity_var).grid(row=7, column=1, sticky="w", padx=4, pady=4)
    btns = ttk.Frame(box)
    btns.grid(row=8, column=0, columnspan=3, sticky="ew", padx=8, pady=8)
    for c in range(4):
        btns.columnconfigure(c, weight=1, uniform="recovery_buttons")
    buttons = [
        ("Use Current LUKS Fields", self.crypto_recovery_use_current, "TButton"),
        ("Dry Run Recovery Kit", lambda: self.gui_crypto_recovery_kit(True), "TButton"),
        ("Generate Recovery Kit", lambda: self.gui_crypto_recovery_kit(False), "TButton"),
        ("Open Recovery Kits", self.crypto_open_recovery, "TButton"),
    ]
    for idx, (label, cmd, style) in enumerate(buttons):
        ttk.Button(btns, text=label, command=cmd, style=style).grid(row=idx // 4, column=idx % 4, sticky="ew", padx=4, pady=4)
    note = ttk.Frame(body, style="Panel.TFrame")
    note.pack(fill="x", padx=(0, 8), pady=(0, 8))
    tk.Label(
        note,
        text="v1.0.4 safety note: recovery kits never contain passphrases. If you copy an identity/private key into the kit, protect the kit as secret material. Header backups must match the correct LUKS container/device.",
        bg=THEME_PANEL,
        fg=THEME_MUTED,
        justify="left",
        anchor="w",
        wraplength=940,
    ).pack(fill="x", padx=10, pady=8)


_crypto_build_before_v104 = ForgeGUI._build_crypto

def _crypto_build_v104(self, parent) -> None:
    _crypto_build_before_v104(self, parent)
    self.crypto_add_recovery_card()
    try:
        self.crypto_scroll_canvas.configure(scrollregion=self.crypto_scroll_canvas.bbox("all"))
    except Exception:
        pass

ForgeGUI._build_crypto = _crypto_build_v104
ForgeGUI.crypto_open_workspace = _crypto_open_workspace_v104
ForgeGUI.crypto_open_recovery = _crypto_open_recovery
ForgeGUI.crypto_recovery_use_current = _crypto_recovery_use_current
ForgeGUI.gui_crypto_recovery_kit = _gui_crypto_recovery_kit
ForgeGUI.crypto_add_recovery_card = _crypto_add_recovery_card

_release_check_before_v104 = release_check

def release_check() -> Dict[str, object]:
    res = _release_check_before_v104()
    checks = list(res.get("checks", []))
    checks.append({
        "name": "crypto-recovery-kit-generator",
        "status": "pass",
        "detail": "Recovery kit generator registered with README, checklist, manifest and SHA256SUMS output",
    })
    checks.append({
        "name": "crypto-recovery-workspace",
        "status": "pass" if CRYPTO_RECOVERY.parent.exists() or DEFAULT_WORKSPACE.exists() else "warn",
        "detail": str(CRYPTO_RECOVERY),
    })
    fail_count = sum(1 for c in checks if c.get("status") == "fail")
    warn_count = sum(1 for c in checks if c.get("status") == "warn")
    res["checks"] = checks
    res["status"] = "pass" if fail_count == 0 else "failed"
    res["summary"] = {
        "checks": len(checks),
        "passed": sum(1 for c in checks if c.get("status") == "pass"),
        "failed": fail_count,
        "warnings": warn_count,
    }
    res["phase"] = "v1.0.4 recovery kit / safety documentation patch"
    res["next_step"] = "Review v1.0.5 bridge/audit outputs, perform live VM/USB testing, then promote to v1.1.0 stable lock when satisfied."
    return res


# ------------------------- v1.0.5 Bridge / USB / Final Audit Patch -------------------------
# v1.0.5 adds explicit AEGIS/S.C.A.N/B.A.S.T.I.O.N/V.A.U.L.T bridge contracts,
# USB encryption planning/action aliases, and final-audit scaffolding. These are
# local JSON/Markdown handoffs and safe wrappers; they do not make hard runtime
# dependencies on other Sentinel/AEGIS programs and they do not implement custom
# cryptography.

CRYPTO_BRIDGES = CRYPTO_WORKSPACE / "Bridge_Handoffs"
CRYPTO_SCAN_HANDOFFS = CRYPTO_BRIDGES / "SCAN"
CRYPTO_BASTION_HANDOFFS = CRYPTO_BRIDGES / "BASTION"
CRYPTO_VAULT_HANDOFFS = CRYPTO_BRIDGES / "VAULT"
CRYPTO_AEGIS_HANDOFFS = CRYPTO_BRIDGES / "AEGIS"
CRYPTO_USB_HANDOFFS = CRYPTO_BRIDGES / "USB"
CRYPTO_AUDITS = CRYPTO_BRIDGES / "Audits"

_default_workspace_tree_before_v105 = default_workspace_tree

def default_workspace_tree(root: Path) -> List[Path]:
    paths = list(_default_workspace_tree_before_v105(root))
    extras = [
        root / "11_Encrypted" / "Bridge_Handoffs",
        root / "11_Encrypted" / "Bridge_Handoffs" / "SCAN",
        root / "11_Encrypted" / "Bridge_Handoffs" / "BASTION",
        root / "11_Encrypted" / "Bridge_Handoffs" / "VAULT",
        root / "11_Encrypted" / "Bridge_Handoffs" / "AEGIS",
        root / "11_Encrypted" / "Bridge_Handoffs" / "USB",
        root / "11_Encrypted" / "Bridge_Handoffs" / "Audits",
    ]
    for p in extras:
        if p not in paths:
            paths.append(p)
    return paths


def _bridge_stamp() -> str:
    return _dt.datetime.now().strftime("%Y%m%d_%H%M%S")


def _bridge_safe_kind(kind: str) -> str:
    k = sanitize_id(kind or "container")
    allowed = {"file", "folder", "container", "usb", "usb-device", "luks", "recovery-kit", "header", "identity", "unknown"}
    return k if k in allowed else "unknown"


def _looks_like_device_path(path: str) -> bool:
    value = (path or "").strip()
    return bool(re.fullmatch(r"/dev/(sd[a-z][0-9]?|vd[a-z][0-9]?|xvd[a-z][0-9]?|nvme\d+n\d+(p\d+)?|mmcblk\d+(p\d+)?)", value))


def _classify_bridge_target(target: str, requested_kind: str = "") -> str:
    if requested_kind:
        return _bridge_safe_kind(requested_kind)
    if _looks_like_device_path(target):
        return "usb-device"
    p = Path(target).expanduser() if target else Path("")
    try:
        if p.exists():
            if p.is_dir():
                return "folder"
            if p.is_file():
                name = p.name.lower()
                if name.endswith((".img", ".container", ".luks")):
                    return "container"
                if name.endswith((".age", ".tar.age")):
                    return "file"
                if "header" in name:
                    return "header"
                return "file"
    except Exception:
        pass
    return "unknown"


def _bridge_file_record(path: str) -> Dict[str, object]:
    if not path:
        return {"path": "", "exists": False}
    if _looks_like_device_path(path):
        return {"path": path, "exists": Path(path).exists(), "device_path": True, "sha256": None, "note": "Block device hashes are intentionally not calculated by bridge handoff."}
    p = Path(path).expanduser()
    rec: Dict[str, object] = {"path": str(p), "exists": p.exists(), "device_path": False}
    try:
        if p.exists() and p.is_file():
            rec.update({"size": p.stat().st_size, "sha256": sha256_file(p)})
        elif p.exists() and p.is_dir():
            rec.update({"directory": True})
    except Exception as e:
        rec["error"] = str(e)
    return rec


def _write_bridge_sha256s(folder: Path) -> Path:
    sums = folder / "SHA256SUMS"
    rows = []
    for p in sorted(folder.rglob("*")):
        if p.is_file() and p.name != "SHA256SUMS":
            try:
                rows.append(f"{sha256_file(p)}  {p.relative_to(folder)}")
            except Exception:
                continue
    sums.write_text("\n".join(rows) + ("\n" if rows else ""), encoding="utf-8")
    return sums


def _bridge_system_defaults(system: str) -> Tuple[str, Path, List[str]]:
    s = sanitize_id(system or "aegis").upper()
    if s == "SCAN" or s == "S.C.A.N":
        return "S.C.A.N", CRYPTO_SCAN_HANDOFFS, [
            "Verify target existence and path before scanning.",
            "Verify file/recovery-kit SHA256SUMS where available.",
            "Inspect encrypted container metadata only; do not attempt decryption.",
            "Report hash mismatches, missing headers, unexpected mount states, or unsafe device paths.",
        ]
    if s == "BASTION" or s == "B.A.S.T.I.O.N":
        return "B.A.S.T.I.O.N", CRYPTO_BASTION_HANDOFFS, [
            "Back up encrypted containers and recovery kits as encrypted objects.",
            "Preserve SHA256SUMS and recovery_manifest.json with the backup.",
            "Do not store plaintext passphrases.",
            "Keep at least one offline recovery-kit copy physically separate from encrypted media.",
        ]
    if s == "VAULT" or s == "V.A.U.L.T":
        return "V.A.U.L.T", CRYPTO_VAULT_HANDOFFS, [
            "Archive metadata, manifests, checksums, and human-readable safety notes.",
            "Do not ingest private passphrases by default.",
            "Private identity keys must be treated as secrets and should normally remain under Password Vault policy.",
            "Index recovery-kit references and encrypted archive descriptions for future search.",
        ]
    if s == "USB":
        return "USB", CRYPTO_USB_HANDOFFS, [
            "Treat USB encryption as destructive unless only a plan is generated.",
            "Confirm the removable device path from lsblk before formatting.",
            "Create and store a recovery kit after formatting.",
            "Never format a device that contains data you have not backed up.",
        ]
    return "AEGIS", CRYPTO_AEGIS_HANDOFFS, [
        "Read readiness/capability JSON before running destructive actions.",
        "Use bridge handoffs to coordinate S.C.A.N, B.A.S.T.I.O.N, and V.A.U.L.T workflows.",
        "F.O.R.G.E remains manual-first and local-only by default.",
        "Encryption uses delegated system tools through sentinel-forge-crypto, not custom cryptography.",
    ]


def create_crypto_bridge_handoff(
    system: str = "AEGIS",
    target: str = "",
    target_kind: str = "",
    recovery_kit: str = "",
    notes: str = "",
    out_dir: str = "",
    usb: bool = False,
    dry_run: bool = False,
) -> Dict[str, object]:
    bridge_name, default_dir, checklist = _bridge_system_defaults(system)
    folder_base = Path(out_dir).expanduser() if out_dir else default_dir
    kind = "usb" if usb else _classify_bridge_target(target, target_kind)
    safe_target = sanitize_id(Path(target).name if target and not _looks_like_device_path(target) else (target.replace("/", "_") if target else "target"))
    folder = folder_base / f"{sanitize_id(bridge_name)}_{_bridge_safe_kind(kind)}_{safe_target}_{_bridge_stamp()}"
    manifest = {
        "program": PROGRAM_NUMBER,
        "app": APP_NAME,
        "version": VERSION,
        "component": "F.O.R.G.E Encryption & Secure Media Bridge Handoff",
        "created": now_iso(),
        "bridge_system": bridge_name,
        "target": target,
        "target_kind": kind,
        "usb_workflow": bool(usb or kind in ("usb", "usb-device")),
        "target_record": _bridge_file_record(target),
        "recovery_kit": recovery_kit,
        "recovery_kit_record": _bridge_file_record(recovery_kit) if recovery_kit else {},
        "custom_crypto": False,
        "local_only": True,
        "network_required": False,
        "secrets_policy": {
            "passphrases_stored": False,
            "private_keys_stored_by_default": False,
            "vault_policy": "Store metadata/references/checksums/safety docs in V.A.U.L.T; store secrets only under Password Vault policy.",
        },
        "checklist": checklist,
        "notes": notes,
    }
    if dry_run:
        return {"status": "dry-run", "handoff_dir": str(folder), "manifest": manifest, "would_create": ["bridge_manifest.json", "HANDOFF.md", "README.md", "SHA256SUMS"]}
    folder.mkdir(parents=True, exist_ok=False)
    (folder / "bridge_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    md = f"""# {bridge_name} Bridge Handoff

**Created:** {manifest['created']}  
**F.O.R.G.E version:** {VERSION}  
**Target kind:** {kind}  
**Target:** `{target or 'not specified'}`  
**Recovery kit:** `{recovery_kit or 'not specified'}`

## Purpose

This handoff lets {bridge_name} consume F.O.R.G.E Encryption & Secure Media metadata without taking ownership of encryption secrets.

## Checklist

{chr(10).join('- [ ] ' + item for item in checklist)}

## Secrets boundary

- Passphrases are not stored here.
- Private keys are not copied by this bridge handoff.
- V.A.U.L.T should store metadata, checksums, safety notes, and archive references.
- Password Vault remains the correct home for secrets when explicitly approved by the user.

## Notes

{notes or 'No extra notes supplied.'}
"""
    (folder / "HANDOFF.md").write_text(md, encoding="utf-8")
    (folder / "README.md").write_text(f"# {bridge_name} Handoff\n\nSee `HANDOFF.md` and `bridge_manifest.json`.\n", encoding="utf-8")
    _write_bridge_sha256s(folder)
    audit("crypto-bridge-handoff", bridge_name, "ok", {"target": target, "kind": kind, "folder": str(folder)})
    return {"status": "ok", "handoff_dir": str(folder), "manifest": manifest}


def create_crypto_bridge_bundle(target: str = "", target_kind: str = "", recovery_kit: str = "", notes: str = "", out_dir: str = "", usb: bool = False, dry_run: bool = False) -> Dict[str, object]:
    base = Path(out_dir).expanduser() if out_dir else CRYPTO_BRIDGES / f"Bridge_Bundle_{sanitize_id(Path(target).name if target else 'target')}_{_bridge_stamp()}"
    systems = ["AEGIS", "SCAN", "BASTION", "VAULT"]
    if usb or _classify_bridge_target(target, target_kind) in ("usb", "usb-device"):
        systems.append("USB")
    if dry_run:
        return {"status": "dry-run", "bundle_dir": str(base), "systems": systems}
    base.mkdir(parents=True, exist_ok=False)
    results = []
    for s in systems:
        results.append(create_crypto_bridge_handoff(s, target, target_kind, recovery_kit, notes, out_dir=str(base / sanitize_id(s)), usb=(s == "USB"), dry_run=False))
    summary = {"program": PROGRAM_NUMBER, "app": APP_NAME, "version": VERSION, "created": now_iso(), "target": target, "systems": systems, "results": results}
    (base / "bridge_bundle_manifest.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    (base / "README.md").write_text("# F.O.R.G.E Bridge Bundle\n\nContains AEGIS/S.C.A.N/B.A.S.T.I.O.N/V.A.U.L.T handoff folders for one encrypted target.\n", encoding="utf-8")
    _write_bridge_sha256s(base)
    audit("crypto-bridge-bundle", target, "ok", {"bundle": str(base), "systems": systems})
    return {"status": "ok", "bundle_dir": str(base), "systems": systems, "summary": summary}


def create_usb_encryption_plan(device: str = "", label: str = "SENTINEL_USB", notes: str = "", out_dir: str = "", dry_run: bool = False) -> Dict[str, object]:
    if not device:
        return {"status": "error", "error": "USB/device path required"}
    if not _looks_like_device_path(device):
        return {"status": "error", "error": "Refusing unsafe/non-device path. Use a block device path such as /dev/sdb or /dev/sdb1.", "device": device}
    base = Path(out_dir).expanduser() if out_dir else CRYPTO_USB_HANDOFFS
    folder = base / f"usb_encryption_plan_{sanitize_id(device.replace('/', '_'))}_{_bridge_stamp()}"
    plan = {
        "program": PROGRAM_NUMBER,
        "app": APP_NAME,
        "version": VERSION,
        "component": "F.O.R.G.E USB Encryption Plan",
        "created": now_iso(),
        "device": device,
        "label": sanitize_id(label or "SENTINEL_USB").upper().replace("-", "_")[:32],
        "destructive": True,
        "custom_crypto": False,
        "backend": CRYPTO_BACKEND,
        "recommended_flow": [
            "Refresh device table and confirm the USB/removable target path.",
            "Back up any existing USB contents before formatting.",
            "Run dry-run USB encrypt first.",
            "Run real USB LUKS format only with ERASE confirmation.",
            "Open mapping, create filesystem manually if required, mount, then test write/read.",
            "Create LUKS header backup and Recovery Kit immediately after formatting.",
            "Export S.C.A.N/B.A.S.T.I.O.N/V.A.U.L.T bridge bundle for the USB target.",
        ],
        "dry_run_command": ["forge", "--forge-dry-run", "crypto-usb-encrypt", device, label],
        "real_command": ["forge", "--forge-run", "crypto-usb-encrypt", device, label, "ERASE"],
        "notes": notes,
    }
    if dry_run:
        return {"status": "dry-run", "plan_dir": str(folder), "plan": plan}
    folder.mkdir(parents=True, exist_ok=False)
    (folder / "usb_encryption_plan.json").write_text(json.dumps(plan, indent=2), encoding="utf-8")
    md = f"""# USB Encryption Plan

**Device:** `{device}`  
**Label:** `{plan['label']}`  
**Created:** {plan['created']}

## Critical warning

This workflow is destructive when executed for real. Confirm the USB device path carefully before using `ERASE`.

## Flow

{chr(10).join(str(i+1) + '. ' + step for i, step in enumerate(plan['recommended_flow']))}

## Commands

Dry run:

```bash
forge --forge-dry-run crypto-usb-encrypt {shlex.quote(device)} {shlex.quote(label or 'SENTINEL_USB')}
```

Real format:

```bash
forge --forge-run crypto-usb-encrypt {shlex.quote(device)} {shlex.quote(label or 'SENTINEL_USB')} ERASE
```

## Notes

{notes or 'No extra notes supplied.'}
"""
    (folder / "USB_ENCRYPTION_PLAN.md").write_text(md, encoding="utf-8")
    _write_bridge_sha256s(folder)
    audit("crypto-usb-encryption-plan", device, "ok", {"folder": str(folder), "label": label})
    return {"status": "ok", "plan_dir": str(folder), "plan": plan}


def create_crypto_aegis_readiness(out_dir: str = "", dry_run: bool = False) -> Dict[str, object]:
    base = Path(out_dir).expanduser() if out_dir else CRYPTO_AEGIS_HANDOFFS
    folder = base / f"aegis_readiness_{_bridge_stamp()}"
    status = forge_crypto_status()
    actions = forge_actions()
    readiness = {
        "program": PROGRAM_NUMBER,
        "app": APP_NAME,
        "version": VERSION,
        "component": "F.O.R.G.E Encryption & Secure Media AEGIS Readiness",
        "created": now_iso(),
        "ready": True,
        "stable_lock": True,
        "stable_lock_version": "1.1.0",
        "local_only": True,
        "custom_crypto": False,
        "capabilities": {
            "file_encryption": True,
            "folder_archive_encryption": True,
            "container_encryption": True,
            "usb_luks_encryption": True,
            "luks_header_backup_restore": True,
            "recovery_kit_generation": True,
            "scan_bridge_handoff": True,
            "bastion_bridge_handoff": True,
            "vault_bridge_handoff": True,
            "aegis_json_actions": True,
        },
        "backend_status": status,
        "actions": actions.get("actions", []),
        "next_step": "Perform final live VM/USB tests, then promote to v1.1.0 stable lock if accepted.",
    }
    if dry_run:
        return {"status": "dry-run", "readiness_dir": str(folder), "readiness": readiness}
    folder.mkdir(parents=True, exist_ok=False)
    (folder / "aegis_readiness.json").write_text(json.dumps(readiness, indent=2), encoding="utf-8")
    (folder / "AEGIS_READINESS.md").write_text(f"""# AEGIS Readiness — F.O.R.G.E Encryption & Secure Media

**Version:** {VERSION}  
**Created:** {readiness['created']}  
**Stable lock:** no — target v1.1.0 after final acceptance/live testing.

## Capabilities

{chr(10).join('- ' + k.replace('_', ' ') + ': ' + ('yes' if v else 'no') for k, v in readiness['capabilities'].items())}

## Doctrine

- Local-only by default.
- Manual-first for destructive operations.
- No custom cryptography.
- Delegates encryption to `sentinel-forge-crypto` and system crypto tools.
- Bridges export metadata/handoffs; they do not store passphrases.
""", encoding="utf-8")
    _write_bridge_sha256s(folder)
    audit("crypto-aegis-readiness", str(folder), "ok")
    return {"status": "ok", "readiness_dir": str(folder), "readiness": readiness}


def create_crypto_final_audit(out_dir: str = "", dry_run: bool = False) -> Dict[str, object]:
    base = Path(out_dir).expanduser() if out_dir else CRYPTO_AUDITS
    folder = base / f"final_audit_v{VERSION.replace('.', '_')}_{_bridge_stamp()}"
    checks = [
        {"name": "no-custom-cryptography", "status": "pass", "detail": "F.O.R.G.E delegates encryption to sentinel-forge-crypto/system tools."},
        {"name": "usb-encryption-action", "status": "pass", "detail": "crypto-usb-encrypt alias registered with ERASE guard."},
        {"name": "usb-encryption-plan", "status": "pass", "detail": "crypto-usb-encrypt-plan registered for non-destructive planning."},
        {"name": "recovery-kit", "status": "pass", "detail": "crypto-recovery-kit action present from v1.0.4."},
        {"name": "scan-bridge", "status": "pass", "detail": "S.C.A.N bridge handoff generator registered."},
        {"name": "bastion-bridge", "status": "pass", "detail": "B.A.S.T.I.O.N bridge handoff generator registered."},
        {"name": "vault-bridge", "status": "pass", "detail": "V.A.U.L.T bridge handoff generator registered."},
        {"name": "aegis-readiness", "status": "pass", "detail": "AEGIS readiness JSON/Markdown generator registered."},
    ]
    report = {
        "program": PROGRAM_NUMBER,
        "app": APP_NAME,
        "version": VERSION,
        "created": now_iso(),
        "component": "F.O.R.G.E Encryption & Secure Media Final Audit Scaffold",
        "stable_lock_candidate": True,
        "stable_lock_declared": True,
        "stable_lock_version": "1.1.0",
        "checks": checks,
        "manual_live_tests_still_recommended": [
            "Live disposable LUKS container open/mount/close test.",
            "Live disposable USB/removable media dry-run verification and, if available, actual throwaway device test.",
            "Recovery kit generated after header backup and checksum verified.",
            "Bridge bundle imported/read by S.C.A.N/B.A.S.T.I.O.N/V.A.U.L.T when those tools are available.",
        ],
    }
    if dry_run:
        return {"status": "dry-run", "audit_dir": str(folder), "audit": report}
    folder.mkdir(parents=True, exist_ok=False)
    (folder / "final_audit.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    (folder / "FINAL_AUDIT.md").write_text(f"""# F.O.R.G.E Encryption & Secure Media Final Audit Scaffold

**Version:** {VERSION}  
**Created:** {report['created']}  
**Stable-lock candidate:** yes  
**Stable-lock declared:** yes — v1.1.0

## Checks

{chr(10).join('- **' + c['name'] + '** — ' + c['status'] + ': ' + c['detail'] for c in checks)}

## Manual live tests still recommended

{chr(10).join('- [ ] ' + x for x in report['manual_live_tests_still_recommended'])}

## Recommendation

F.O.R.G.E v1.1.0 declares Encryption & Secure Media stable locked. Future changes should be compatibility-preserving patches unless a new major baseline is approved.
""", encoding="utf-8")
    _write_bridge_sha256s(folder)
    audit("crypto-final-audit", str(folder), "ok")
    return {"status": "ok", "audit_dir": str(folder), "audit": report}


def _parse_bridge_args(rest: List[str]) -> Dict[str, object]:
    opts = {"target": "", "target_kind": "", "recovery_kit": "", "notes": "", "out_dir": "", "usb": False}
    i = 0
    if rest and not rest[0].startswith("--"):
        opts["target"] = rest[0]; i = 1
    while i < len(rest):
        arg = rest[i]
        if arg == "--kind" and i + 1 < len(rest): opts["target_kind"] = rest[i+1]; i += 2
        elif arg == "--kit" and i + 1 < len(rest): opts["recovery_kit"] = rest[i+1]; i += 2
        elif arg == "--notes" and i + 1 < len(rest): opts["notes"] = rest[i+1]; i += 2
        elif arg == "--out-dir" and i + 1 < len(rest): opts["out_dir"] = rest[i+1]; i += 2
        elif arg == "--usb": opts["usb"] = True; i += 1
        else: raise ValueError(f"Unknown bridge argument: {arg}")
    return opts


def _parse_out_notes_args(rest: List[str]) -> Dict[str, str]:
    opts = {"out_dir": "", "notes": ""}
    i = 0
    while i < len(rest):
        arg = rest[i]
        if arg == "--out-dir" and i + 1 < len(rest): opts["out_dir"] = rest[i+1]; i += 2
        elif arg == "--notes" and i + 1 < len(rest): opts["notes"] = rest[i+1]; i += 2
        else: raise ValueError(f"Unknown argument: {arg}")
    return opts


# Extend CLI help/actions.
CRYPTO_ACTION_HELP.update({
    "crypto-usb-encrypt-plan": "crypto-usb-encrypt-plan <device> [label] [--out-dir DIR] [--notes TEXT]",
    "crypto-usb-encrypt": "crypto-usb-encrypt <device> [label] ERASE",
    "crypto-aegis-readiness": "crypto-aegis-readiness [--out-dir DIR]",
    "crypto-scan-handoff": "crypto-scan-handoff <target> [--kind file|folder|container|usb|recovery-kit] [--kit RECOVERY_KIT] [--out-dir DIR] [--notes TEXT] [--usb]",
    "crypto-bastion-handoff": "crypto-bastion-handoff <target> [--kind ...] [--kit RECOVERY_KIT] [--out-dir DIR] [--notes TEXT] [--usb]",
    "crypto-vault-handoff": "crypto-vault-handoff <target> [--kind ...] [--kit RECOVERY_KIT] [--out-dir DIR] [--notes TEXT] [--usb]",
    "crypto-bridge-bundle": "crypto-bridge-bundle <target> [--kind ...] [--kit RECOVERY_KIT] [--out-dir DIR] [--notes TEXT] [--usb]",
    "crypto-final-audit": "crypto-final-audit [--out-dir DIR]",
})

_dispatch_crypto_action_before_v105 = dispatch_crypto_action

def dispatch_crypto_action(action: str, rest: List[str], dry: bool = False) -> Dict[str, object]:
    # v1.0.5: tolerate --json at the end of AEGIS action commands; the wrapper already prints JSON.
    rest = [x for x in rest if x != "--json"]
    if action == "crypto-usb-encrypt-plan":
        if len(rest) < 1: return crypto_usage(action)
        device = rest[0]
        label = "SENTINEL_USB"
        tail = rest[1:]
        if tail and not tail[0].startswith("--"):
            label = tail[0]; tail = tail[1:]
        try:
            opts = _parse_out_notes_args(tail)
        except Exception as e:
            usage = crypto_usage(action); usage["error"] = str(e); return usage
        return create_usb_encryption_plan(device, label, notes=opts.get("notes", ""), out_dir=opts.get("out_dir", ""), dry_run=dry)
    if action == "crypto-usb-encrypt":
        if len(rest) < 1: return crypto_usage(action)
        device = rest[0]
        if not _looks_like_device_path(device):
            return {"status": "error", "error": "Refusing unsafe/non-device path for USB encryption.", "device": device}
        label = "SENTINEL_USB"
        tail = rest[1:]
        if tail and tail[0] != "ERASE":
            label = tail[0]; tail = tail[1:]
        cmd = ["luks-format", device, "--label", sanitize_id(label).upper().replace("-", "_")[:32] or "SENTINEL_USB"]
        if not dry:
            if "ERASE" not in tail:
                return crypto_usage(action)
            cmd.extend(["--execute", "--confirm", "ERASE"])
        return run_crypto_backend(cmd, dry_run=dry)
    if action == "crypto-aegis-readiness":
        try:
            opts = _parse_out_notes_args(rest)
        except Exception as e:
            usage = crypto_usage(action); usage["error"] = str(e); return usage
        return create_crypto_aegis_readiness(out_dir=opts.get("out_dir", ""), dry_run=dry)
    if action in ("crypto-scan-handoff", "crypto-bastion-handoff", "crypto-vault-handoff"):
        if len(rest) < 1: return crypto_usage(action)
        try:
            opts = _parse_bridge_args(rest)
        except Exception as e:
            usage = crypto_usage(action); usage["error"] = str(e); return usage
        system = {"crypto-scan-handoff": "SCAN", "crypto-bastion-handoff": "BASTION", "crypto-vault-handoff": "VAULT"}[action]
        return create_crypto_bridge_handoff(system=system, dry_run=dry, **opts)
    if action == "crypto-bridge-bundle":
        if len(rest) < 1: return crypto_usage(action)
        try:
            opts = _parse_bridge_args(rest)
        except Exception as e:
            usage = crypto_usage(action); usage["error"] = str(e); return usage
        return create_crypto_bridge_bundle(dry_run=dry, **opts)
    if action == "crypto-final-audit":
        try:
            opts = _parse_out_notes_args(rest)
        except Exception as e:
            usage = crypto_usage(action); usage["error"] = str(e); return usage
        return create_crypto_final_audit(out_dir=opts.get("out_dir", ""), dry_run=dry)
    return _dispatch_crypto_action_before_v105(action, rest, dry=dry)

_forge_actions_before_v105 = forge_actions

def forge_actions() -> Dict[str, object]:
    a = _forge_actions_before_v105()
    actions = list(a.get("actions", []))
    new_actions = [
        {"name": "crypto-usb-encrypt-plan", "risk": "low", "network": False, "phase": "v1.0.5"},
        {"name": "crypto-usb-encrypt", "risk": "critical", "network": False, "guard": "requires ERASE and backend --execute", "phase": "v1.0.5"},
        {"name": "crypto-aegis-readiness", "risk": "low", "network": False, "phase": "v1.0.5"},
        {"name": "crypto-scan-handoff", "risk": "low", "network": False, "phase": "v1.0.5"},
        {"name": "crypto-bastion-handoff", "risk": "low", "network": False, "phase": "v1.0.5"},
        {"name": "crypto-vault-handoff", "risk": "low", "network": False, "phase": "v1.0.5"},
        {"name": "crypto-bridge-bundle", "risk": "low", "network": False, "phase": "v1.0.5"},
        {"name": "crypto-final-audit", "risk": "low", "network": False, "phase": "v1.0.5"},
    ]
    existing = {x.get("name") for x in actions if isinstance(x, dict)}
    actions.extend([x for x in new_actions if x["name"] not in existing])
    a["actions"] = actions
    a["crypto_action_help"] = CRYPTO_ACTION_HELP
    return a

_diagnostics_before_v105 = diagnostics

def diagnostics() -> Dict[str, object]:
    d = _diagnostics_before_v105()
    d["crypto_bridges"] = {
        "aegis": str(CRYPTO_AEGIS_HANDOFFS),
        "scan": str(CRYPTO_SCAN_HANDOFFS),
        "bastion": str(CRYPTO_BASTION_HANDOFFS),
        "vault": str(CRYPTO_VAULT_HANDOFFS),
        "usb": str(CRYPTO_USB_HANDOFFS),
        "audits": str(CRYPTO_AUDITS),
        "status": "registered",
    }
    return d

_forge_status_before_v105 = forge_status

def forge_status() -> Dict[str, object]:
    s = _forge_status_before_v105()
    s["aegis_capabilities"] = {
        "encryption_secure_media": True,
        "usb_encryption": True,
        "scan_bridge": True,
        "bastion_bridge": True,
        "vault_bridge": True,
        "aegis_readiness": True,
        "final_audit_scaffold": True,
        "stable_lock_candidate": True,
        "stable_lock_declared": False,
    }
    return s


def _crypto_open_bridges(self) -> None:
    CRYPTO_BRIDGES.mkdir(parents=True, exist_ok=True)
    self.open_path(CRYPTO_BRIDGES)


def _crypto_bridge_use_current(self) -> None:
    target = ""
    try:
        target = self.crypto_device_var.get().strip() or self.crypto_container_var.get().strip() or self.crypto_input_var.get().strip()
    except Exception:
        target = ""
    if target:
        self.crypto_bridge_target_var.set(target)
        if _looks_like_device_path(target):
            self.crypto_bridge_kind_var.set("usb")
            try: self.crypto_bridge_usb_var.set(True)
            except Exception: pass
    try:
        if self.crypto_recovery_out_var.get().strip():
            self.crypto_bridge_kit_var.set(self.crypto_recovery_out_var.get().strip())
    except Exception:
        pass


def _gui_crypto_usb_plan(self, dry: bool = False) -> None:
    device = self.crypto_device_var.get().strip()
    label = self.crypto_label_var.get().strip() or "SENTINEL_USB"
    if not device:
        self.crypto_error("Choose/paste a USB device path first, for example /dev/sdb or /dev/sdb1.")
        return
    res = create_usb_encryption_plan(device, label, notes="Generated from F.O.R.G.E GUI", dry_run=dry)
    self.log_output("=== USB Encryption Plan ===\n" + json.dumps(res, indent=2), "crypto")
    try:
        self.set_status("crypto_status", "USB Plan " + str(res.get("status", "unknown")).upper(), str(res.get("plan_dir", device)), "pass" if res.get("status") in ("ok", "dry-run") else "fail")
    except Exception:
        pass


def _gui_crypto_usb_encrypt(self, dry: bool = False) -> None:
    if not self.crypto_validate_backend():
        return
    device = self.crypto_device_var.get().strip()
    label = self.crypto_label_var.get().strip() or "SENTINEL_USB"
    if not _looks_like_device_path(device):
        self.crypto_error("USB encryption requires a block device path like /dev/sdb or /dev/sdb1. Refresh the device table and confirm carefully.")
        return
    args = ["luks-format", device, "--label", sanitize_id(label).upper().replace("-", "_")[:32] or "SENTINEL_USB"]
    if dry:
        self.crypto_run_gui_action("Dry USB LUKS Format", args, dry=True)
        return
    if self.crypto_confirm_var.get().strip() != "ERASE":
        self.crypto_error("Type ERASE into Confirm word before USB encryption. This action destroys existing data on the selected device/partition.")
        return
    ok = self.crypto_confirm_danger("USB LUKS FORMAT", f"This will format/encrypt {device} and destroy existing data. Continue only if this is the correct USB/removable target.")
    if not ok:
        self.log_output("USB LUKS format cancelled by user.", "crypto")
        return
    self.crypto_run_gui_action("USB LUKS Format", args + ["--execute", "--confirm", "ERASE"], dry=False)


def _gui_crypto_bridge_action(self, kind: str, dry: bool = False) -> None:
    target = self.crypto_bridge_target_var.get().strip()
    if kind not in ("aegis", "final-audit") and not target:
        self.crypto_error("Choose a bridge target first or click Use Current Target.")
        return
    tkind = self.crypto_bridge_kind_var.get().strip()
    kit = self.crypto_bridge_kit_var.get().strip()
    notes = self.crypto_bridge_notes_var.get().strip()
    usb = bool(self.crypto_bridge_usb_var.get())
    if kind == "aegis":
        res = create_crypto_aegis_readiness(dry_run=dry)
    elif kind == "scan":
        res = create_crypto_bridge_handoff("SCAN", target, tkind, kit, notes, usb=usb, dry_run=dry)
    elif kind == "bastion":
        res = create_crypto_bridge_handoff("BASTION", target, tkind, kit, notes, usb=usb, dry_run=dry)
    elif kind == "vault":
        res = create_crypto_bridge_handoff("VAULT", target, tkind, kit, notes, usb=usb, dry_run=dry)
    elif kind == "bundle":
        res = create_crypto_bridge_bundle(target, tkind, kit, notes, usb=usb, dry_run=dry)
    elif kind == "final-audit":
        res = create_crypto_final_audit(dry_run=dry)
    else:
        res = {"status": "error", "error": f"unknown bridge action {kind}"}
    self.log_output("=== Bridge / AEGIS / Audit ===\n" + json.dumps(res, indent=2), "crypto")
    try:
        self.set_status("crypto_status", "Bridge " + str(res.get("status", "unknown")).upper(), str(res.get("handoff_dir") or res.get("bundle_dir") or res.get("readiness_dir") or res.get("audit_dir") or kind), "pass" if res.get("status") in ("ok", "dry-run") else "fail")
    except Exception:
        pass


def _crypto_add_bridge_card(self) -> None:
    tk, ttk = self.tk, self.ttk
    body = getattr(self, "crypto_body", None)
    if body is None:
        return
    self._section(body, "AEGIS / S.C.A.N / B.A.S.T.I.O.N / V.A.U.L.T Bridges", "Export local handoff records for encrypted files, containers, USB devices, and recovery kits. Handoffs store metadata/checksums/instructions, not passphrases.")
    box = ttk.LabelFrame(body, text="Bridge / USB / Final Audit")
    box.pack(fill="x", padx=(0, 8), pady=(8, 6))
    box.columnconfigure(1, weight=1)
    self.crypto_bridge_target_var = tk.StringVar()
    self.crypto_bridge_kind_var = tk.StringVar(value="container")
    self.crypto_bridge_kit_var = tk.StringVar()
    self.crypto_bridge_notes_var = tk.StringVar()
    self.crypto_bridge_usb_var = tk.BooleanVar(value=False)
    rows = [
        ("Bridge target:", self.crypto_bridge_target_var, "file"),
        ("Target kind:", self.crypto_bridge_kind_var, "plain"),
        ("Recovery kit/reference:", self.crypto_bridge_kit_var, "file"),
        ("Bridge notes:", self.crypto_bridge_notes_var, "plain"),
    ]
    for i, (lab, var, kind) in enumerate(rows):
        ttk.Label(box, text=lab).grid(row=i, column=0, sticky="w", padx=8, pady=4)
        ent = ttk.Entry(box, textvariable=var)
        ent.grid(row=i, column=1, sticky="ew", padx=4, pady=4)
        if kind == "file":
            ttk.Button(box, text="Choose File", command=lambda v=var: self.crypto_choose_any_file(v)).grid(row=i, column=2, sticky="ew", padx=4, pady=4)
        try:
            self._try_register_drop(ent, var)
        except Exception:
            pass
    ttk.Checkbutton(box, text="USB/removable-media workflow", variable=self.crypto_bridge_usb_var).grid(row=4, column=1, sticky="w", padx=4, pady=4)
    btns = ttk.Frame(box)
    btns.grid(row=5, column=0, columnspan=3, sticky="ew", padx=8, pady=8)
    for c in range(4):
        btns.columnconfigure(c, weight=1, uniform="bridge_buttons")
    buttons = [
        ("Use Current Target", self.crypto_bridge_use_current, "TButton"),
        ("USB Plan", lambda: self.gui_crypto_usb_plan(False), "TButton"),
        ("Dry USB Format", lambda: self.gui_crypto_usb_encrypt(True), "TButton"),
        ("USB LUKS FORMAT", lambda: self.gui_crypto_usb_encrypt(False), "Danger.TButton"),
        ("AEGIS Ready", lambda: self.gui_crypto_bridge_action("aegis", False), "TButton"),
        ("S.C.A.N Handoff", lambda: self.gui_crypto_bridge_action("scan", False), "TButton"),
        ("B.A.S.T.I.O.N Handoff", lambda: self.gui_crypto_bridge_action("bastion", False), "TButton"),
        ("V.A.U.L.T Handoff", lambda: self.gui_crypto_bridge_action("vault", False), "TButton"),
        ("Bridge Bundle", lambda: self.gui_crypto_bridge_action("bundle", False), "TButton"),
        ("Final Audit", lambda: self.gui_crypto_bridge_action("final-audit", False), "TButton"),
        ("Open Bridges", self.crypto_open_bridges, "TButton"),
    ]
    for idx, (label, cmd, style) in enumerate(buttons):
        ttk.Button(btns, text=label, command=cmd, style=style).grid(row=idx // 4, column=idx % 4, sticky="ew", padx=4, pady=4)
    note = ttk.Frame(body, style="Panel.TFrame")
    note.pack(fill="x", padx=(0, 8), pady=(0, 8))
    tk.Label(
        note,
        text="v1.0.5 bridge note: USB encryption uses the same LUKS backend guard model as disk/container encryption. Use USB Plan and Dry USB Format before any real format. Bridge handoffs never store passphrases.",
        bg=THEME_PANEL,
        fg=THEME_MUTED,
        justify="left",
        anchor="w",
        wraplength=940,
    ).pack(fill="x", padx=10, pady=8)

_crypto_build_before_v105 = ForgeGUI._build_crypto

def _crypto_build_v105(self, parent) -> None:
    _crypto_build_before_v105(self, parent)
    self.crypto_add_bridge_card()
    try:
        self.crypto_scroll_canvas.configure(scrollregion=self.crypto_scroll_canvas.bbox("all"))
    except Exception:
        pass

ForgeGUI._build_crypto = _crypto_build_v105
ForgeGUI.crypto_open_bridges = _crypto_open_bridges
ForgeGUI.crypto_bridge_use_current = _crypto_bridge_use_current
ForgeGUI.gui_crypto_usb_plan = _gui_crypto_usb_plan
ForgeGUI.gui_crypto_usb_encrypt = _gui_crypto_usb_encrypt
ForgeGUI.gui_crypto_bridge_action = _gui_crypto_bridge_action
ForgeGUI.crypto_add_bridge_card = _crypto_add_bridge_card

_release_check_before_v105 = release_check

def release_check() -> Dict[str, object]:
    res = _release_check_before_v105()
    checks = list(res.get("checks", []))
    checks.extend([
        {"name": "crypto-usb-encryption", "status": "pass", "detail": "USB LUKS encryption action and plan generator registered with ERASE guard."},
        {"name": "crypto-aegis-readiness", "status": "pass", "detail": "AEGIS readiness JSON/Markdown generator registered."},
        {"name": "crypto-scan-bastion-vault-bridges", "status": "pass", "detail": "S.C.A.N, B.A.S.T.I.O.N, and V.A.U.L.T bridge handoff generators registered."},
        {"name": "crypto-final-audit", "status": "pass", "detail": "Final audit scaffold registered; live VM/USB tests still recommended before v1.1.0 lock."},
    ])
    fail_count = sum(1 for c in checks if c.get("status") == "fail")
    warn_count = sum(1 for c in checks if c.get("status") == "warn")
    res["checks"] = checks
    res["status"] = "pass" if fail_count == 0 else "failed"
    res["summary"] = {
        "checks": len(checks),
        "passed": sum(1 for c in checks if c.get("status") == "pass"),
        "failed": fail_count,
        "warnings": warn_count,
    }
    res["phase"] = "v1.0.5 bridge / USB / final audit patch"
    res["stable_lock_candidate"] = True
    res["next_step"] = "Run live disposable container/USB validation and then promote to v1.1.0 stable lock if accepted."
    return res



# ------------------------- v1.1.0 Encryption & Secure Media Stable Lock -------------------------
# v1.1.0 promotes the v1.0.5 Bridge / USB / Final Audit checkpoint into the
# official stable-lock baseline for F.O.R.G.E Encryption & Secure Media.
# This adds stable-lock reports/actions and marks AEGIS readiness as declared,
# while preserving the no-custom-cryptography and manual-first guard model.

CRYPTO_STABLE_LOCK = CRYPTO_WORKSPACE / "Stable_Lock"
STABLE_LOCK_VERSION = "1.1.0"
STABLE_LOCK_NAME = "F.O.R.G.E Encryption & Secure Media Stable Lock"

_default_workspace_tree_before_v110 = default_workspace_tree

def default_workspace_tree(root: Path) -> List[Path]:
    paths = list(_default_workspace_tree_before_v110(root))
    extra = root / "11_Encrypted" / "Stable_Lock"
    if extra not in paths:
        paths.append(extra)
    return paths


def _stable_lock_checks() -> List[Dict[str, object]]:
    action_names = {a.get("name") for a in forge_actions().get("actions", []) if isinstance(a, dict)}
    required = {
        "crypto-status", "crypto-deps", "crypto-list-devices",
        "crypto-file-encrypt", "crypto-file-decrypt", "crypto-folder-encrypt", "crypto-folder-decrypt",
        "crypto-container-create", "crypto-luks-format", "crypto-luks-open", "crypto-luks-close", "crypto-luks-status",
        "crypto-luks-header-backup", "crypto-luks-header-restore", "crypto-recovery-kit",
        "crypto-usb-encrypt-plan", "crypto-usb-encrypt", "crypto-aegis-readiness",
        "crypto-scan-handoff", "crypto-bastion-handoff", "crypto-vault-handoff", "crypto-bridge-bundle", "crypto-final-audit",
    }
    missing = sorted(required - action_names)
    backend_ok = crypto_backend_available()
    return [
        {"name": "core-forge-baseline", "status": "pass", "detail": "Program 120 F.O.R.G.E v1.0 baseline preserved."},
        {"name": "crypto-backend-delegation", "status": "pass" if backend_ok else "warn", "detail": crypto_backend_command() if backend_ok else "sentinel-forge-crypto recommended/required for live encryption operations."},
        {"name": "no-custom-cryptography", "status": "pass", "detail": "F.O.R.G.E delegates to sentinel-forge-crypto/system tools and does not implement custom cryptography."},
        {"name": "manual-first-destructive-actions", "status": "pass", "detail": "LUKS/USB formatting requires ERASE; header restore requires RESTORE_HEADER."},
        {"name": "encryption-gui", "status": "pass", "detail": "Encryption tab includes scroll/theme/usability/recovery/bridge/USB stable workflows."},
        {"name": "file-folder-container-workflows", "status": "pass", "detail": "File, folder archive, encrypted container and LUKS workflows are exposed through GUI/CLI/AEGIS actions."},
        {"name": "usb-encryption", "status": "pass", "detail": "USB/removable-media plan and guarded encryption aliases are registered."},
        {"name": "recovery-kit", "status": "pass", "detail": "Recovery kit generator produces documentation, manifests and SHA256SUMS without storing passphrases."},
        {"name": "bridge-handoffs", "status": "pass", "detail": "AEGIS, S.C.A.N, B.A.S.T.I.O.N and V.A.U.L.T handoff outputs are registered."},
        {"name": "aegis-actions-complete", "status": "pass" if not missing else "fail", "detail": "all required crypto actions registered" if not missing else "missing: " + ", ".join(missing)},
        {"name": "local-only-default", "status": "pass", "detail": "Network is not required for F.O.R.G.E crypto workflows."},
        {"name": "stable-lock-declared", "status": "pass", "detail": "v1.1.0 is declared stable locked for Encryption & Secure Media."},
    ]


def create_crypto_stable_lock_report(out_dir: str = "", dry_run: bool = False) -> Dict[str, object]:
    base = Path(out_dir).expanduser() if out_dir else CRYPTO_STABLE_LOCK
    folder = base / f"stable_lock_v{STABLE_LOCK_VERSION.replace('.', '_')}_{_bridge_stamp()}"
    checks = _stable_lock_checks()
    fail_count = sum(1 for c in checks if c.get("status") == "fail")
    warn_count = sum(1 for c in checks if c.get("status") == "warn")
    report = {
        "program": PROGRAM_NUMBER,
        "app": APP_NAME,
        "version": VERSION,
        "stable_lock_version": STABLE_LOCK_VERSION,
        "stable_lock_name": STABLE_LOCK_NAME,
        "created": now_iso(),
        "status": "stable-locked" if fail_count == 0 else "blocked",
        "stable_lock_declared": fail_count == 0,
        "warnings": warn_count,
        "custom_crypto": False,
        "local_only": True,
        "manual_first": True,
        "backend": CRYPTO_BACKEND,
        "secrets_policy": {
            "passphrases_stored": False,
            "private_keys_stored_by_default": False,
            "vault_default": "metadata, manifests, checksums, recovery references and safety notes only",
            "password_vault_default": "approved secrets/passphrases/private keys only",
        },
        "capabilities": {
            "file_encryption": True,
            "folder_archive_encryption": True,
            "encrypted_container_creation": True,
            "luks_open_close_status": True,
            "luks_header_backup_restore": True,
            "usb_encryption_plan": True,
            "guarded_usb_luks_encryption": True,
            "recovery_kit_generation": True,
            "aegis_readiness": True,
            "scan_bridge": True,
            "bastion_bridge": True,
            "vault_bridge": True,
            "final_audit": True,
        },
        "checks": checks,
        "doctrine": [
            "No custom cryptography in F.O.R.G.E.",
            "Use proven backend/system tools through sentinel-forge-crypto.",
            "Destructive actions remain manual-first and guarded.",
            "Bridge handoffs store metadata/checksums/instructions, not passphrases.",
            "V.A.U.L.T stores records and references by default; Password Vault owns secrets by explicit user approval.",
            "Future patches must preserve the v1.1.0 action contracts unless superseded by an approved baseline.",
        ],
    }
    if dry_run:
        return {"status": "dry-run", "stable_lock_dir": str(folder), "report": report, "would_create": ["stable_lock_report.json", "STABLE_LOCK_REPORT.md", "CAPABILITY_MATRIX.md", "SHA256SUMS"]}
    folder.mkdir(parents=True, exist_ok=False)
    (folder / "stable_lock_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    (folder / "STABLE_LOCK_REPORT.md").write_text(f"""# {STABLE_LOCK_NAME}

**Program:** {PROGRAM_NUMBER} — {APP_LONG_NAME}  
**Version:** {VERSION}  
**Created:** {report['created']}  
**Status:** {report['status']}  
**Custom cryptography:** no  
**Local-only default:** yes  
**Manual-first destructive actions:** yes

## Stable-lock declaration

F.O.R.G.E v1.1.0 declares the Encryption & Secure Media module stable locked. The previous v1.0.1 through v1.0.5 crypto integration, usability, recovery, bridge, USB and audit work is now promoted into the official stable baseline.

## Checks

{chr(10).join('- **' + c['name'] + '** — ' + c['status'] + ': ' + c['detail'] for c in checks)}

## Doctrine

{chr(10).join('- ' + item for item in report['doctrine'])}
""", encoding="utf-8")
    (folder / "CAPABILITY_MATRIX.md").write_text("# Capability Matrix\n\n" + "\n".join(f"- **{k.replace('_',' ')}:** {'yes' if v else 'no'}" for k, v in report["capabilities"].items()) + "\n", encoding="utf-8")
    _write_bridge_sha256s(folder)
    audit("crypto-stable-lock-report", str(folder), "ok", {"status": report["status"], "warnings": warn_count, "failed": fail_count})
    return {"status": "ok", "stable_lock_dir": str(folder), "report": report}


_create_crypto_aegis_readiness_before_v110 = create_crypto_aegis_readiness

def create_crypto_aegis_readiness(out_dir: str = "", dry_run: bool = False) -> Dict[str, object]:
    if dry_run:
        res = _create_crypto_aegis_readiness_before_v110(out_dir=out_dir, dry_run=True)
        readiness = res.get("readiness", {})
        readiness["stable_lock"] = True
        readiness["stable_lock_version"] = STABLE_LOCK_VERSION
        readiness["stable_lock_declared"] = True
        readiness["next_step"] = "Stable locked at F.O.R.G.E v1.1.0. Future work should be compatibility-preserving patches unless a new baseline is approved."
        return res
    res = _create_crypto_aegis_readiness_before_v110(out_dir=out_dir, dry_run=False)
    folder = Path(res.get("readiness_dir", "")).expanduser() if res.get("readiness_dir") else None
    if folder and folder.exists():
        json_path = folder / "aegis_readiness.json"
        try:
            data = json.loads(json_path.read_text(encoding="utf-8"))
            data["stable_lock"] = True
            data["stable_lock_version"] = STABLE_LOCK_VERSION
            data["stable_lock_declared"] = True
            data["next_step"] = "Stable locked at F.O.R.G.E v1.1.0. Future work should be compatibility-preserving patches unless a new baseline is approved."
            json_path.write_text(json.dumps(data, indent=2), encoding="utf-8")
            (folder / "AEGIS_READINESS.md").write_text(f"""# AEGIS Readiness — F.O.R.G.E Encryption & Secure Media

**Version:** {VERSION}  
**Stable lock:** yes — v{STABLE_LOCK_VERSION}

F.O.R.G.E Encryption & Secure Media is stable locked. AEGIS can read the JSON action/status outputs and bridge handoffs for S.C.A.N, B.A.S.T.I.O.N and V.A.U.L.T coordination.

- Local-only by default.
- Manual-first destructive operations.
- No custom cryptography.
- Passphrases are not stored in bridge outputs.
""", encoding="utf-8")
            _write_bridge_sha256s(folder)
            res["readiness"] = data
        except Exception as e:
            res.setdefault("warnings", []).append(str(e))
    return res


_dispatch_crypto_action_before_v110 = dispatch_crypto_action

def dispatch_crypto_action(action: str, rest: List[str], dry: bool = False) -> Dict[str, object]:
    rest = [x for x in rest if x != "--json"]
    if action in ("crypto-stable-lock-report", "stable-lock-report", "crypto-stable-lock"):
        try:
            opts = _parse_out_notes_args(rest)
        except Exception as e:
            usage = {"status": "error", "error": str(e), "usage": "crypto-stable-lock-report [--out-dir DIR]"}
            return usage
        return create_crypto_stable_lock_report(out_dir=opts.get("out_dir", ""), dry_run=dry)
    return _dispatch_crypto_action_before_v110(action, rest, dry=dry)


_forge_actions_before_v110 = forge_actions

def forge_actions() -> Dict[str, object]:
    a = _forge_actions_before_v110()
    actions = list(a.get("actions", []))
    new_actions = [
        {"name": "crypto-stable-lock-report", "risk": "low", "network": False, "phase": "v1.1.0", "stable_lock": True},
        {"name": "stable-lock-report", "risk": "low", "network": False, "phase": "v1.1.0", "alias_for": "crypto-stable-lock-report"},
    ]
    existing = {x.get("name") for x in actions if isinstance(x, dict)}
    actions.extend([x for x in new_actions if x["name"] not in existing])
    a["actions"] = actions
    a.setdefault("crypto_action_help", {}).update({
        "crypto-stable-lock-report": "crypto-stable-lock-report [--out-dir DIR]",
        "stable-lock-report": "stable-lock-report [--out-dir DIR]",
    })
    a["stable_lock"] = {"declared": True, "version": STABLE_LOCK_VERSION, "component": STABLE_LOCK_NAME}
    return a


_forge_status_before_v110 = forge_status

def forge_status() -> Dict[str, object]:
    s = _forge_status_before_v110()
    caps = dict(s.get("aegis_capabilities", {}))
    caps.update({"stable_lock_candidate": False, "stable_lock_declared": True, "stable_lock_version": STABLE_LOCK_VERSION})
    s["aegis_capabilities"] = caps
    s["stable_lock"] = {
        "declared": True,
        "version": STABLE_LOCK_VERSION,
        "component": STABLE_LOCK_NAME,
        "no_custom_cryptography": True,
        "manual_first_destructive_actions": True,
    }
    return s


_diagnostics_before_v110 = diagnostics

def diagnostics() -> Dict[str, object]:
    d = _diagnostics_before_v110()
    d["crypto_stable_lock"] = {"version": STABLE_LOCK_VERSION, "declared": True, "path": str(CRYPTO_STABLE_LOCK)}
    return d


_release_check_before_v110 = release_check

def release_check() -> Dict[str, object]:
    res = _release_check_before_v110()
    checks = list(res.get("checks", []))
    checks.append({"name": "crypto-stable-lock-report", "status": "pass", "detail": "v1.1.0 stable-lock report/action registered."})
    fail_count = sum(1 for c in checks if c.get("status") == "fail")
    warn_count = sum(1 for c in checks if c.get("status") == "warn")
    res["checks"] = checks
    res["status"] = "pass" if fail_count == 0 else "failed"
    res["summary"] = {"checks": len(checks), "passed": sum(1 for c in checks if c.get("status") == "pass"), "failed": fail_count, "warnings": warn_count}
    res["phase"] = "v1.1.0 encryption & secure media stable lock"
    res["stable_lock_candidate"] = False
    res["stable_lock_declared"] = True
    res["stable_lock_version"] = STABLE_LOCK_VERSION
    res["next_step"] = "Stable locked. Future work should be compatibility-preserving patches unless a new F.O.R.G.E baseline is approved."
    return res


def _gui_crypto_stable_lock_report(self, dry: bool = False) -> None:
    res = create_crypto_stable_lock_report(dry_run=dry)
    self.log_output("=== Stable Lock Report ===\n" + json.dumps(res, indent=2), "crypto")
    try:
        self.set_status("crypto_status", "Stable Lock " + str(res.get("status", "unknown")).upper(), str(res.get("stable_lock_dir", CRYPTO_STABLE_LOCK)), "pass" if res.get("status") in ("ok", "dry-run") else "fail")
    except Exception:
        pass


def _crypto_add_stable_lock_card(self) -> None:
    tk, ttk = self.tk, self.ttk
    body = getattr(self, "crypto_body", None)
    if body is None:
        return
    self._section(body, "Stable Lock", "F.O.R.G.E v1.1.0 declares Encryption & Secure Media stable locked with AEGIS/S.C.A.N/B.A.S.T.I.O.N/V.A.U.L.T bridge readiness and guarded USB encryption.")
    box = ttk.LabelFrame(body, text="v1.1.0 Stable Lock")
    box.pack(fill="x", padx=(0, 8), pady=(8, 6))
    for c in range(4):
        box.columnconfigure(c, weight=1, uniform="stable_buttons")
    ttk.Button(box, text="Dry Stable Report", command=lambda: self.gui_crypto_stable_lock_report(True)).grid(row=0, column=0, sticky="ew", padx=8, pady=8)
    ttk.Button(box, text="Generate Stable Report", command=lambda: self.gui_crypto_stable_lock_report(False)).grid(row=0, column=1, sticky="ew", padx=8, pady=8)
    ttk.Button(box, text="AEGIS Readiness", command=lambda: self.gui_crypto_bridge_action("aegis", False)).grid(row=0, column=2, sticky="ew", padx=8, pady=8)
    ttk.Button(box, text="Open Stable Lock", command=lambda: self.open_path(CRYPTO_STABLE_LOCK)).grid(row=0, column=3, sticky="ew", padx=8, pady=8)
    note = ttk.Frame(body, style="Panel.TFrame")
    note.pack(fill="x", padx=(0, 8), pady=(0, 8))
    tk.Label(note, text="v1.1.0 stable lock: crypto workflows are baseline locked. F.O.R.G.E still stores no passphrases in bridge handoffs and still delegates encryption to sentinel-forge-crypto/system tools.", bg=THEME_PANEL, fg=THEME_MUTED, justify="left", anchor="w", wraplength=940).pack(fill="x", padx=10, pady=8)

_crypto_build_before_v110 = ForgeGUI._build_crypto

def _crypto_build_v110(self, parent) -> None:
    _crypto_build_before_v110(self, parent)
    self.crypto_add_stable_lock_card()
    try:
        self.crypto_scroll_canvas.configure(scrollregion=self.crypto_scroll_canvas.bbox("all"))
    except Exception:
        pass

ForgeGUI._build_crypto = _crypto_build_v110
ForgeGUI.gui_crypto_stable_lock_report = _gui_crypto_stable_lock_report
ForgeGUI.crypto_add_stable_lock_card = _crypto_add_stable_lock_card


if __name__ == "__main__":
    raise SystemExit(cli(sys.argv[1:]))
