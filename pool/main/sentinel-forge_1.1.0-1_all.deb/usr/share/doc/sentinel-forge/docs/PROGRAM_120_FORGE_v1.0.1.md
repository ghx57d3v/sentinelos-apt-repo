# Program 120 — Sentinel F.O.R.G.E v1.0.1 Crypto Integration Patch

## Purpose
v1.0.1 integrates Encryption & Secure Media into the F.O.R.G.E user interface and AEGIS action surface while preserving F.O.R.G.E v1.0 as the builder/release workstation baseline.

## Architecture
F.O.R.G.E remains the Program 120 front-end. Encryption work is delegated to the `sentinel-forge-crypto` backend so F.O.R.G.E does not implement custom cryptography.

Backend tools wrapped by `sentinel-forge-crypto`:
- `cryptsetup` / LUKS / dm-crypt for block devices and encrypted container images
- `age` for file and folder archive encryption
- optional `fscrypt` for native empty-directory filesystem encryption

## Added GUI module
New sidebar tab:
- Encryption

GUI functions:
- Backend status
- Dependency check
- Device listing
- Open standalone backend GUI
- File encrypt/decrypt
- Folder archive encrypt/decrypt
- Encrypted container creation
- LUKS format/open/close/status
- LUKS header backup/restore
- Mount/unmount mapping helpers

## Added workspace folders
- `11_Encrypted/Containers`
- `11_Encrypted/Files`
- `11_Encrypted/Folders`
- `11_Encrypted/Headers`
- `11_Encrypted/Keys`
- `11_Encrypted/Mounts`

## AEGIS/CLI actions added
- `crypto-status`
- `crypto-deps`
- `crypto-list-devices`
- `crypto-age-keygen`
- `crypto-file-encrypt`
- `crypto-file-decrypt`
- `crypto-folder-encrypt`
- `crypto-folder-decrypt`
- `crypto-container-create`
- `crypto-luks-format`
- `crypto-luks-open`
- `crypto-luks-close`
- `crypto-luks-status`
- `crypto-luks-header-backup`
- `crypto-luks-header-restore`
- `crypto-mount`
- `crypto-unmount`
- `crypto-fscrypt-status`
- `crypto-fscrypt-encrypt-empty-dir`

## Safety locks preserved
- LUKS format still requires explicit `ERASE` confirmation and backend `--execute`.
- LUKS header restore still requires explicit `RESTORE_HEADER` confirmation and backend `--execute`.
- No shell string execution is used for the F.O.R.G.E-to-backend bridge.
- F.O.R.G.E v1.0.1 remains local-only and network-free by default.

## Install note
Install `sentinel-forge-crypto` before or alongside `sentinel-forge` to activate the encryption backend.
