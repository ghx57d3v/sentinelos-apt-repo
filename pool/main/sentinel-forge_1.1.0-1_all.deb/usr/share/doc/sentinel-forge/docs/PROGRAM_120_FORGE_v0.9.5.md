# Program 120 — F.O.R.G.E v1.0 Lock Candidate

F.O.R.G.E v1.0 is the lock-candidate phase before v1.0. It adds release-readiness checks for the builder workstation and exposes them through the GUI, CLI, and AEGIS-compatible JSON interface.

## Added

- `--release-check` and `--release-check --json` CLI command.
- `--aegis-release-check --json` alias.
- `forge --aegis-run release-check` and dry-run support.
- A release-readiness section in `--aegis-status --json`.
- Manual-page lock-candidate release check button.
- Human-readable PASS/FAILED release-check summary.

## Pre-lock checks

The check validates required local tools, workspace tree readiness, icon/desktop assets, AEGIS action availability, diagnostics status, clipboard support, USB safeguards, local-first network policy, and quarantine/S.C.A.N placeholder readiness.

## Notes

F.O.R.G.E remains local-first. ISO backends such as `xorriso`, `genisoimage`, or `mkisofs` are optional until the user actively builds an ISO.
