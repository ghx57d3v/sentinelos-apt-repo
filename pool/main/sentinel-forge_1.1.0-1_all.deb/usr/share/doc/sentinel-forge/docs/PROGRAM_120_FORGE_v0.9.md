# Program 120 — F.O.R.G.E v0.9

## Clipboard + AEGIS/User-Ready Polish

F.O.R.G.E v0.9 adds consistent clipboard behavior across the GUI before v1.0 hardening.

### User-facing clipboard support

- `Ctrl+C` copies selected text or selected table rows.
- `Ctrl+V` pastes into editable fields.
- `Ctrl+X` cuts from editable fields.
- `Ctrl+A` selects all text in the focused field/output pane, or all rows in a table.
- Right-click context menu is available on fields, output panes, and tables.
- Tables copy selected rows as tab-separated text so users can paste results into notes, bug reports, manuals, or release docs.

### AEGIS status

The AEGIS/CLI layer now reports clipboard readiness through diagnostics and exposes:

```bash
forge --aegis-run clipboard-support
```

This does not require network access.
