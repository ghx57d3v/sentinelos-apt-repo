# Program 120 — F.O.R.G.E v0.7

Phase focus: ISO Builder and USB ISO Creator hardening.

- ISO profile JSON generation.
- Visible ISO preparation status.
- USB target selection with removable drives shown by default.
- Internal/non-removable disks hidden unless advanced mode is enabled.
- ISO checksum verification.
- Unmount selected target before writing.
- Guarded `dd` backend retained.
