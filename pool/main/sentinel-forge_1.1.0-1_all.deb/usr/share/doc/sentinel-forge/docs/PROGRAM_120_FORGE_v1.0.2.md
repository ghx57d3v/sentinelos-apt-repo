# Program 120 — Sentinel F.O.R.G.E v1.0.2

## Status

Layout/theme patch over F.O.R.G.E v1.0.1.

## Purpose

Improve the integrated Encryption & Secure Media tab so it fits inside smaller application windows and visually matches the rest of F.O.R.G.E.

## Changes

- Scrollable Encryption tab body.
- Responsive button grids instead of fixed horizontal button rows.
- Themed label frames, checkboxes, scrollbars, note panel, danger buttons, and output/audit log card.
- No change to cryptographic implementation: F.O.R.G.E still delegates to sentinel-forge-crypto.
- Destructive safety guards remain unchanged: ERASE for LUKS format and RESTORE_HEADER for header restore.
