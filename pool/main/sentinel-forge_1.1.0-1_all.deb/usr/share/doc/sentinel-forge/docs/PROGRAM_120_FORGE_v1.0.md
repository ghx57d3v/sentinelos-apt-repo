# Program 120 — F.O.R.G.E v1.0 Lock Candidate

F.O.R.G.E v1.0 is the user-ready lock-candidate baseline for the SentinelOS builder workstation.

## Locked role

F.O.R.G.E — File Output & Release Generation Engine — is Program 120 of the SentinelOS Desktop Suite. It provides local-first tools for safe archive extraction, package building, ISO preparation, USB ISO writing, release packaging, manifests, and checksums.

## v1.0 baseline

- Sentinel/AEGIS themed GUI.
- Desktop/menu launcher and icon integration.
- F.O.R.G.E workspace initialization.
- Safe extractor with quarantine/staging workflow.
- Package Builder for `.deb` wrappers and `.tar.gz` bundles.
- `.zip` project input support.
- Icon selection and command auto-fill support.
- ISO Builder with profiles and prep guidance.
- USB ISO Creator with removable-drive targeting, safeguards, dry-run, unmount, and verification support.
- Release Generator with versioned folders, manifests, SHA256SUMS, summaries, and optional ZIP output.
- AEGIS-compatible CLI/JSON actions.
- Diagnostics, release-check, clipboard support, and human PASS/FAILED status panels.

## Status

Program 120 — F.O.R.G.E v1.0 Lock Candidate complete.
