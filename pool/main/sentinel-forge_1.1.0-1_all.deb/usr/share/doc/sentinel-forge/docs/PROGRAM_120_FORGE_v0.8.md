# Program 120 — F.O.R.G.E v0.8

Phase focus: Release Generator and user-ready workflow polish.

- Versioned release folder generation.
- Release name/version/channel fields.
- Lock-candidate naming option.
- `FORGE_RELEASE_SUMMARY.md` output.
- `MANIFEST.json` and `SHA256SUMS` output.
- Optional release ZIP output.
- AEGIS CLI actions added for ISO profiles, ISO verification, USB unmount, and release-package builds.
