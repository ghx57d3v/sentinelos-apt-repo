# Program 120 — F.O.R.G.E v0.4

F.O.R.G.E v0.4 improves the core builder workflow before user-ready hardening.

## Extraction policy

Extractor can save output to:

1. F.O.R.G.E quarantine/staging — recommended default.
2. Beside the source archive.
3. A custom user-selected folder.

The quarantine path is designed for future S.C.A.N verification.

## Package Builder

Package Builder accepts both folders and `.zip` projects. ZIP projects are extracted safely to quarantine before building.

Supported outputs:

- `.deb` wrapper package
- `.tar.gz` project bundle

Package Builder also supports icon selection and command auto-fill.

## USB ISO Creator

USB targets are selected visually from a removable-disk list. Internal drives are hidden by default.
