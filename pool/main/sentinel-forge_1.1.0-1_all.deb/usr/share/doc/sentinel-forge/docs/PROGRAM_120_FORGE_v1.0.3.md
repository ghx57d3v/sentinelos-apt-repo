# Program 120 — Sentinel F.O.R.G.E v1.0.3

## Status

Encryption GUI Usability Patch over F.O.R.G.E v1.0.2.

## Purpose

Make the integrated Encryption & Secure Media tab safer and easier to use before final stable-lock work.

## Changes

- Preflight validation before encryption, container, LUKS, mount, and header actions.
- Automatic output filename helpers for file/folder encrypt/decrypt workflows.
- Corrected output-folder browse behavior.
- age identity-key helper.
- Device table refresh and selected-device copy workflow.
- GUI confirmation dialogs for critical LUKS format/header restore actions.
- Interactive passphrase-based age actions are copied as terminal commands instead of being run inside the GUI output pane.
- No custom cryptography; all crypto operations are delegated to sentinel-forge-crypto.

## Stable-lock note

v1.0.3 is not the final Encryption stable lock. Recommended next patch: v1.0.4 Recovery Kit and safety documentation.
