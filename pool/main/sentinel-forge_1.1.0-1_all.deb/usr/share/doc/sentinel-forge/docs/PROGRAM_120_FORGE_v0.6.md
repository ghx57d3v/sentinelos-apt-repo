# Program 120 — F.O.R.G.E v0.6

## Package Builder + AEGIS Polish

v0.6 improves the user-facing builder workflow and expands AEGIS compatibility.

### Changes

- Package Builder now has human PASS/FAILED status panels.
- Added project validation before build.
- Added dependency and maintainer fields for `.deb` output.
- Kept icon picker and command auto-fill.
- Built `.deb` packages are validated with `dpkg-deb --info` and `dpkg-deb --contents`.
- ISO Builder now shows visible PASS/FAILED status for staging and ISO builds.
- Release Generator now shows visible PASS/FAILED status for manifest generation.
- Added AEGIS alias commands: `--aegis-status`, `--aegis-actions`, `--aegis-diagnostics`, `--aegis-run`, and `--aegis-dry-run`.
- Added AEGIS permissions manifest output.
- Added S.C.A.N quarantine placeholder status for future scanner handoff.

### Doctrine

F.O.R.G.E remains local-first, AEGIS-capable, and guarded for high-risk operations.
