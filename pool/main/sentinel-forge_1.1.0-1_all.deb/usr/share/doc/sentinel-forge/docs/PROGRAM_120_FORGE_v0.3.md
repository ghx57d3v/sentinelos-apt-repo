# Program 120 — F.O.R.G.E v0.3

Repair + feature build for Program 120.

## Modules
- Dashboard
- Extractor
- Package Builder
- ISO Builder
- USB ISO Creator
- Release Generator
- Manual

## Safety
USB writing requires the confirmation word `ERASE` and only accepts whole-disk device paths such as `/dev/sdX`, `/dev/nvme0n1`, or `/dev/mmcblk0`.
