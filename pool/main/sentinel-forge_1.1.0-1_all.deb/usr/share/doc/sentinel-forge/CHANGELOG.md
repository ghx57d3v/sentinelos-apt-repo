# F.O.R.G.E Changelog

## v1.1.0 — Encryption & Secure Media Stable Lock

- Promotes the v1.0.1-v1.0.5 Encryption & Secure Media sequence to stable lock.
- Adds stable-lock report generator/action: `crypto-stable-lock-report` and alias `stable-lock-report`.
- Marks AEGIS readiness/status as stable-lock declared.
- Adds Stable Lock workspace folder under `11_Encrypted/Stable_Lock`.
- Adds GUI Stable Lock card in the Encryption tab.
- Preserves USB encryption planning/action aliases, Recovery Kit, bridge handoffs, final audit, and no-custom-cryptography doctrine.
- Keeps destructive actions guarded by `ERASE` / `RESTORE_HEADER` through the backend safety model.

# Changelog

## v1.0.5

Bridge / USB / Final Audit Patch.

- Added `crypto-usb-encrypt-plan` action.
- Added `crypto-usb-encrypt` guarded LUKS action alias for USB/removable-media workflows.
- Added AEGIS readiness generator.
- Added S.C.A.N bridge handoff generator.
- Added B.A.S.T.I.O.N bridge handoff generator.
- Added V.A.U.L.T bridge handoff generator.
- Added combined bridge bundle generator.
- Added final audit scaffold.
- Added `11_Encrypted/Bridge_Handoffs` workspace tree.
- Added GUI bridge/USB/final-audit section in the Encryption tab.
- Preserved v1.0.4 Recovery Kit / Safety Documentation behavior.
