# Sentinel F.O.R.G.E v1.1.0

Program 120 — F.O.R.G.E, File Output & Release Generation Engine.

v1.1.0 is the Bridge / USB / Final Audit Patch over v1.0.4. It preserves the v1.0 baseline, crypto integration, scrollable/themed Encryption tab, GUI usability improvements, and Recovery Kit generator, then adds AEGIS/S.C.A.N/B.A.S.T.I.O.N/V.A.U.L.T bridge handoffs plus explicit USB encryption workflows.

## New in v1.1.0

- USB encryption plan generator.
- Guarded USB LUKS encryption action.
- AEGIS readiness report output.
- S.C.A.N bridge handoff output.
- B.A.S.T.I.O.N bridge handoff output.
- V.A.U.L.T bridge handoff output.
- Combined bridge bundle output.
- Final audit scaffold.
- `11_Encrypted/Bridge_Handoffs` workspace tree.

## Install

```bash
sudo apt install ./sentinel-forge-crypto_0.1.0-1_all.deb ./sentinel-forge_1.1.0-1_all.deb
```

F.O.R.G.E does not implement custom cryptography. Encryption remains delegated to `sentinel-forge-crypto`.


## v1.1.0 Stable Lock

F.O.R.G.E v1.1.0 promotes Encryption & Secure Media to stable lock. It preserves the v1.0 Program 120 baseline and the v1.0.1-v1.0.5 crypto integration sequence, including scroll/theme fixes, GUI usability, Recovery Kit generation, USB encryption planning/action aliases, AEGIS readiness, S.C.A.N/B.A.S.T.I.O.N/V.A.U.L.T bridge handoffs, and final audit scaffolding.

Stable-lock doctrine:

- F.O.R.G.E implements no custom cryptography.
- Live encryption delegates to sentinel-forge-crypto and system tools.
- Destructive actions remain manual-first and guarded.
- Bridge handoffs store metadata, manifests, checksums and instructions, not passphrases.
- V.A.U.L.T stores references/records by default; Password Vault owns secrets when explicitly approved.

New action:

```bash
forge --forge-run crypto-stable-lock-report --json
```
