# SentinelOS v0.1.6g — F.O.R.G.E 1.1 Baseline + Report Hotfix

Updates Program 120 Sentinel F.O.R.G.E to v1.1.0, installs/adopts sentinel-forge-crypto v0.1.0 when available, and fixes the v0.1.6f sentinelctl syntax error while preserving report logging behavior.
