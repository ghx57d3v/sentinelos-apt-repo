#!/usr/bin/env python3
import os, subprocess, hashlib, gzip, time
root='/opt/sentinel/repo'; pool=os.path.join(root,'pool/main'); dist=os.path.join(root,'dists/trixie'); bindir=os.path.join(dist,'sentinel/binary-all')
os.makedirs(pool, exist_ok=True); os.makedirs(bindir, exist_ok=True)
packages=[]
for fn in sorted(os.listdir(pool)) if os.path.isdir(pool) else []:
    if not fn.endswith('.deb'): continue
    path=os.path.join(pool,fn); rel=os.path.relpath(path, root)
    fields={}
    for f in ['Package','Version','Architecture','Maintainer','Depends','Description','Section','Priority']:
        r=subprocess.run(['dpkg-deb','-f',path,f],text=True,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
        if r.returncode==0 and r.stdout.strip(): fields[f]=r.stdout.rstrip()
    data=open(path,'rb').read(); fields['Filename']=rel; fields['Size']=str(len(data)); fields['MD5sum']=hashlib.md5(data).hexdigest(); fields['SHA1']=hashlib.sha1(data).hexdigest(); fields['SHA256']=hashlib.sha256(data).hexdigest(); packages.append(fields)
text=''
for fields in packages:
    for k in ['Package','Version','Architecture','Maintainer','Depends','Filename','Size','MD5sum','SHA1','SHA256','Section','Priority','Description']:
        if k in fields: text += f'{k}: {fields[k]}\n'
    text+='\n'
open(os.path.join(bindir,'Packages'),'w').write(text)
with gzip.GzipFile(os.path.join(bindir,'Packages.gz'),'wb',mtime=0) as gz: gz.write(text.encode())
release_fields=[('Origin','SentinelOS'),('Label','SentinelOS Local'),('Suite','trixie'),('Codename','trixie'),('Architectures','all'),('Components','sentinel'),('Date',time.strftime('%a, %d %b %Y %H:%M:%S +0000', time.gmtime()))]
rel=''.join(f'{k}: {v}\n' for k,v in release_fields)
for alg,name in [(hashlib.md5,'MD5Sum'),(hashlib.sha1,'SHA1'),(hashlib.sha256,'SHA256')]:
    rel+=f'{name}:\n'
    for p in ['sentinel/binary-all/Packages','sentinel/binary-all/Packages.gz']:
        f=os.path.join(dist,p); data=open(f,'rb').read(); rel+=f' {alg(data).hexdigest()} {len(data)} {p}\n'
open(os.path.join(dist,'Release'),'w').write(rel)
print('SentinelOS local repo metadata rebuilt')
