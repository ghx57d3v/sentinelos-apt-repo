# Sentinel Browser v1.0.0-rc18

Phase 5B browser-first download UX correction.

## Download model

Sentinel Browser now handles active downloads like Firefox/Chrome: the Browser owns the WebKit transfer, progress indicator, and active cancel action. Download Guard is not called during active transfer. After WebKit reports the download as finished, Browser starts a background handoff to Download Guard using `--import-completed-download`.

Completed files remain in guarded staging/quarantine and only move to the user's Downloads folder after explicit Download Guard release.

## Clean Debian rule

Sentinel Browser must run on clean Debian with its declared dependencies and the matching `sentinel-download-guard` package. AEGIS/Sentinel Command integration is advisory JSON/status only and is not required for normal operation.

## New checks

```bash
sentinel-browser --phase5b-browser-first-test
sentinel-browser --release-candidate-status
```


## RC18 Download UX Polish

- Downloads button uses green active/completed feedback.
- Active downloads remain Browser-owned to avoid WebKit UI freezes.
- Downloads page now exposes Review / Release for quarantined files and Go to File / Show Folder for released files.
- Go to File is intentionally unavailable before Download Guard release approval.


## v1.0.0-rc18 RC3-based v1 security gate

RC18 is built from the confirmed-good RC3 base, not from RC4/RC5. It preserves browser-first active downloads and Download Guard post-completion quarantine/review/release, while adding clean Debian independence and private-directory/security gate checks. No AEGIS/Sentinel Command runtime is required.


## RC18 Home / Vault / Network polish
- Default local home page: `about:sentinel-home`.
- Bookmarks toolbar row title text hidden; bookmark buttons remain.
- Vault login prompt includes `Save to Vault` without Browser storing credentials.
- Preferences include Network/Proxy/VPN settings; AEGIS remains optional.

## v1.0.0-rc18 Bookmarks/Security controls polish
- Removed the remaining literal Bookmarks label from the favourites/bookmarks toolbar row so the row space is available for user bookmarks.
- Security controls are now user-editable checkbox selections in Preferences → Security.
- Sensitive permission boxes fall back to Ask when unchecked, not silent Allow.

## v1.0.0-rc18 Downloads page status guidance
- Adds a clear note to the Downloads page header: live active-download progress belongs in the bottom status bar/toolbar indicator.
- Keeps the Downloads page stable/manual-refresh to avoid reintroducing the RC4 live-refresh glitch that could interfere with downloads.
- No download architecture changes: Browser owns active transfer; Download Guard reviews completed files after transfer.


## RC18 notes

- Default/factory bookmarks are removed; the favourites/bookmarks bar starts empty.
- The local homepage still provides quick links without preloading bookmarks.
- Sentinel Wallet integration is status/open-only and explicit-click. Browser stores no wallet secrets and payment/signing/broadcast paths remain disabled.


## RC20 Wallet passphrase escrow awareness
Browser can report Sentinel Wallet optional encrypted passphrase escrow status, but Browser never receives or stores wallet passphrases. Escrow is handled only by Wallet as explicit user-approved AEGIS Vault / Password Vault handoff.


## v1.0.1 Wallet Transaction + DApp Login Bridge

Sentinel Browser now detects the Sentinel Wallet v1.0.1 transaction/dApp-login bridge and can create local request-response records for dApp login and transaction signing. Browser never stores wallet seeds, private keys, passphrases, or signing material. Browser does not sign or broadcast transactions itself; Wallet remains the signing authority and returns public signatures/signed payloads only after explicit user approval.


## v1.0.2 Homepage Default

Sentinel Browser installs the SentinelOS Browser Home landing page and opens it by default through `sentinel://home`. Use `sentinel-browser --homepage-status` to inspect the installed file, local security markers, and checksum.

Homepage v1.0.4 defaults to Melbourne, VIC when no city is selected, keeps user-selected city/weather locally across Browser restarts, and opens the Browser at a wider 1280x760 default size.


## v1.1.0 Blockchain / Tor compatibility patch

- Adds a TOR toolbar switch left of the address/search bar. Once local Tor is installed and listening on socks5://127.0.0.1:9050, the switch routes normal web pages through Tor without editing settings.
- Moves the HTTPS/security indicator into the address/search bar as an embedded entry icon.
- Adds a minimal injected blockchain provider bridge (`window.ethereum`, `window.sentinelEthereum`, `window.sentinelSolana`) that forwards dApp login/sign/transaction requests to Sentinel Wallet for explicit user approval.
- Browser remains unable to read/store seed phrases, private keys, wallet passphrases, signing material, or card data.


## v1.1.1 GUI installer option awareness

Browser and Download Guard are treated as an inseparable install pair. The v1.1.1 master installer can enable Basic Browser only, optional Tor support, optional blockchain provider injection, and optional Wallet install/integration. Browser-side Wallet toolbar packing now respects the local `wallet_integration_enabled` preference; blockchain provider injection and the TOR switch remain config-controlled.


## v1.1.3 Tor UX / Wallet Approval Hotfix
- Tor status and test panels are user-readable AEGIS-themed GUI dialogs, not JSON/console-style windows.
- TOR button shows active Tor exit country when available, with setup/off/on fallback labels.
- WalletConnect requests auto-open Sentinel Wallet and Wallet shows an Approve / Reject prompt.


## v1.1.12 ETH/SOL Provider Discovery Repair
Restores dApp wallet detection after the manual-approval patch. Fixes malformed Solana Wallet Standard feature key syntax and keeps provider discovery always visible while approval/signing remains manual-user-action gated.


### v1.1.13 — Uniswap ETH Popup Regression Repair

Keeps ETH/SOL provider discovery visible while preventing repeated ETH approval popups after an origin has already been approved. Repeated `eth_requestAccounts` and `wallet_requestPermissions` return the cached account/permission set for the current origin; unsupported methods reject cleanly without opening Wallet; and manual approval no longer uses long-lived `navigator.userActivation.hasBeenActive`.


## v1.1.16 Bookmark Folders Hotfix

- Adds user-created bookmark folders from the Bookmarks top menu.
- The bookmark editor now includes an optional Folder field.
- Bookmarks menu groups saved pages into folder submenus.
- The favourites/bookmarks toolbar shows folder buttons that open folder menus.
- Preserves legacy flat bookmarks, Tor button restore behavior, Download Guard hardening, and Wallet baseline safety.

### v1.1.17 bookmark toolbar usability
- Drag a top-level bookmark button left/right onto another bookmark button to reposition it.
- Drag a bookmark button onto a folder button to move it into that folder.
- Right-click the bookmarks toolbar for quick Add Bookmark / Add Bookmark Folder actions.
- Right-click a bookmark for open, edit, delete, copy, add, and move-to-folder actions.
