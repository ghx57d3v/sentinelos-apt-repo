#!/usr/bin/env python3
"""Sentinel Browser v1.0.0 stable local-first security/clean-Debian gate."""
from __future__ import annotations

import argparse
import html
import hashlib
import json
import os
import re
import shutil
import sys
import time
import subprocess
import threading
import tempfile
import traceback
import secrets
import socket
import stat
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import quote, unquote, urlparse, parse_qs

VERSION = "1.1.17"
APP_NAME = "Sentinel Browser"
PACKAGE = "sentinel-browser"
PROGRAM = 110

DOWNLOAD_GUARD_MIN_VERSION = "1.0.0"
DOWNLOAD_GUARD_BROWSER_CONTRACT_SCHEMA = "sentinel.download_guard.browser_contract.v12"
DOWNLOAD_GUARD_BROWSER_POLL_SCHEMA = "sentinel.download_guard.browser_poll.v3"
DOWNLOAD_GUARD_DOWNLOADS_PANEL_SCHEMA = "sentinel.download_guard.downloads_panel.v10"
DOWNLOAD_GUARD_READINESS_SCHEMA = "sentinel.download_guard.readiness.v9"
DOWNLOAD_GUARD_CANCEL_REQUESTS_SCHEMA = "sentinel.download_guard.cancel_requests.v1"
DOWNLOAD_GUARD_CANCEL_ACK_SCHEMA = "sentinel.download_guard.cancel_ack.v1"
DOWNLOAD_GUARD_MIN_BROWSER_TARGET = "sentinel-browser v1.0.0+"

SHARE = Path(os.environ.get("SENTINEL_BROWSER_SHARE_DIR", Path(__file__).resolve().parents[1]))
ICON = SHARE / "assets" / "sentinel-browser.svg"
DESKTOP = Path(os.environ.get("SENTINEL_BROWSER_DESKTOP_FILE", "/usr/share/applications/sentinel-browser.desktop"))
HOMEPAGE_FILE = SHARE / "homepage" / "homepage.html"
HOMEPAGE_URI = "sentinel://home"

CONFIG_DIR = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")) / PACKAGE
DATA_DIR = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local/share")) / PACKAGE
STATE_DIR = Path(os.environ.get("XDG_STATE_HOME", Path.home() / ".local/state")) / PACKAGE
CACHE_DIR = Path(os.environ.get("XDG_CACHE_HOME", Path.home() / ".cache")) / PACKAGE

CONFIG = CONFIG_DIR / "config.json"
HOMEPAGE_PREFS = CONFIG_DIR / "homepage-prefs.json"
HOMEPAGE_RUNTIME_FILE = DATA_DIR / "homepage-runtime.html"
TOR_ROUTING = CONFIG_DIR / "tor-routing.json"
TOR_EXIT_STATUS = CONFIG_DIR / "tor-exit-status.json"
BLOCKCHAIN_POLICY = CONFIG_DIR / "blockchain-policy.json"
WALLETCONNECT_SESSIONS = CONFIG_DIR / "walletconnect-sessions.json"
NATIVE_PROVIDER_REQUEST_SCHEMA = "sentinel.native_provider.request.v1"
NATIVE_PROVIDER_RESPONSE_SCHEMA = "sentinel.native_provider.response.v1"
NATIVE_PROVIDER_BRIDGE_SCHEMA = "sentinel.native_provider.bridge.v1"
BOOKMARKS = DATA_DIR / "bookmarks.json"
SESSION = DATA_DIR / "session.json"
STATUS = STATE_DIR / "status.json"
CRASH = STATE_DIR / "crash.log"
SECURITY_EVENTS = STATE_DIR / "security-events.jsonl"
WEBKIT_DATA_DIR = DATA_DIR / "webkit-data"
WEBKIT_CACHE_DIR = CACHE_DIR / "webkit-cache"
DOWNLOADS_DIR = DATA_DIR / "downloads"
DOWNLOAD_POLICY = CONFIG_DIR / "download-policy.json"
PERMISSION_POLICY = CONFIG_DIR / "site-permissions-policy.json"
CONTENT_POLICY = CONFIG_DIR / "content-policy.json"
CONTENT_BLOCKLIST = CONFIG_DIR / "content-blocklist.json"
CONTENT_ALLOWLIST = CONFIG_DIR / "content-allowlist.json"
JAVASCRIPT_POLICY = CONFIG_DIR / "javascript-policy.json"
SEARCH_POLICY = CONFIG_DIR / "search-policy.json"
VAULT_BRIDGE_POLICY = CONFIG_DIR / "vault-bridge-policy.json"
VAULT_ACCOUNT_HINTS = DATA_DIR / "vault-account-hints.json"
VAULT_LOGIN_POLICY = CONFIG_DIR / "vault-login-policy.json"
DANGEROUS_DOWNLOAD_EXTENSIONS = {
    ".appimage", ".bat", ".cmd", ".com", ".deb", ".desktop", ".dll", ".dmg",
    ".exe", ".iso", ".jar", ".msi", ".ps1", ".rpm", ".run", ".scr",
    ".sh", ".vbe", ".vbs", ".wsf"
}

SEARCH_ENGINES: Dict[str, Dict[str, str]] = {
    "duckduckgo": {
        "name": "DuckDuckGo",
        "url": "https://duckduckgo.com/?q={query}",
        "profile": "standard_default",
        "notes": "Practical free default. Privacy-oriented, but not treated as the strictest Sentinel option.",
    },
    "mojeek": {
        "name": "Mojeek",
        "url": "https://www.mojeek.com/search?q={query}",
        "profile": "privacy_private_default",
        "notes": "Privacy/incognito default. Independent crawler/no-tracking posture, but results can be weaker.",
    },
    "marginalia": {
        "name": "Marginalia",
        "url": "https://search.marginalia.nu/search?query={query}",
        "profile": "research_noncommercial",
        "notes": "Research preset for independent/non-commercial/old-web discovery, not broad daily-driver search.",
    },
    "startpage": {
        "name": "Startpage",
        "url": "https://www.startpage.com/sp/search?query={query}",
        "profile": "google_style_fallback",
        "notes": "Google-style result fallback without making Google the default.",
    },
    "google": {
        "name": "Google",
        "url": "https://www.google.com/search?q={query}",
        "profile": "user_selected_compatibility",
        "notes": "User-selectable only. Not a Sentinel privacy default.",
    },
    "bing": {
        "name": "Bing",
        "url": "https://www.bing.com/search?q={query}",
        "profile": "user_selected_compatibility",
        "notes": "User-selectable only. Not a Sentinel privacy default.",
    },
    "custom": {
        "name": "Custom Search URL",
        "url": "",
        "profile": "user_defined",
        "notes": "User-defined search URL must include {query}.",
    },
}

BUILT_IN_SEARCH_ENGINES = ["duckduckgo", "mojeek", "marginalia", "startpage", "google", "bing", "custom"]
EXCLUDED_SEARCH_ENGINES = ["kagi"]

TRACKER_DOMAIN_PATTERNS = {
    "doubleclick.net", "googlesyndication.com", "google-analytics.com", "googletagmanager.com",
    "facebook.net", "connect.facebook.net", "scorecardresearch.com", "hotjar.com",
    "mixpanel.com", "segment.io", "adnxs.com", "taboola.com", "outbrain.com",
    "quantserve.com", "mathtag.com", "criteo.com", "adsystem.com",
}

MINER_DOMAIN_PATTERNS = {
    "coinhive.com", "authedmine.com", "crypto-loot.com", "coin-hive.com",
    "webminepool.com", "minero.cc", "jsecoin.com", "coinimp.com",
    "crypto-webminer.com", "webmine.cz", "monerominer.rocks", "deepminer.com",
    "coin-have.com", "ppoi.org", "2giga.link",
}

FINGERPRINT_DOMAIN_PATTERNS = {
    "fingerprintjs.com", "fingerprint.com", "fpjs.io", "clientjs.org", "deviceatlas.com",
}

MINER_SCRIPT_PATTERNS = {
    "coinhive", "cryptonight", "webminer", "webmine", "monero", "miner.js",
    "coinimp", "jsecoin", "crypto-loot", "authedmine", "deepminer",
}

FINGERPRINT_SCRIPT_PATTERNS = {
    "fingerprint", "fingerprintjs", "fp.min.js", "client.min.js", "canvasfp", "audiofingerprint",
}

AEGIS_BRIDGE_DIR = STATE_DIR / "aegis-bridge"
AEGIS_BRIDGE_STATUS = AEGIS_BRIDGE_DIR / "browser-status.json"
AEGIS_BRIDGE_EVENTS = AEGIS_BRIDGE_DIR / "events.jsonl"
AEGIS_BRIDGE_POLICY = CONFIG_DIR / "aegis-bridge-policy.json"

AEGIS_BG = "#0B0D10"
AEGIS_PANEL = "#11161C"
AEGIS_PANEL2 = "#1C252E"
AEGIS_TEXT = "#E8E6DF"
AEGIS_MUTED = "#9AA4AD"
AEGIS_GOLD = "#E19B00"
AEGIS_CYAN = "#03C8FF"
AEGIS_RED = "#FF5C5C"
AEGIS_GREEN = "#7ED957"

DEFAULT_CONFIG: Dict[str, Any] = {
    "schema_version": 23,
    "home_url": "sentinel://home",
    "search_url": "https://duckduckgo.com/?q={query}",
    "default_search_engine": "duckduckgo",
    "private_search_engine": "mojeek",
    "search_policy_enabled": True,
    "allow_custom_search_url": True,
    "custom_search_url": "",
    "exclude_kagi_builtin": True,
    "menu_bar_enabled": True,
    "settings_ui_enabled": True,
    "preferences_window_enabled": True,
    "preferences_sections_enabled": True,
    "search_engine_selector_gui_enabled": True,
    "custom_search_url_gui_enabled": True,
    "download_guard_settings_gui_enabled": True,
    "download_guard_release_dir_gui_enabled": True,
    "download_guard_lightweight_polling_enabled": False,
    "download_guard_no_ui_thread_blocking_target": True,
    "browser_first_download_flow_enabled": True,
    "browser_active_downloads_panel_enabled": True,
    "download_guard_post_completion_handoff_only": True,
    "download_guard_background_handoff_enabled": True,
    "download_guard_no_active_transfer_cli_calls": True,
    "download_guard_disable_live_cancel_poll_for_v1": True,
    "firefox_chrome_download_ux_enabled": True,
    "download_button_flash_green_active": True,
    "download_button_green_complete": True,
    "downloads_page_go_to_file_button_enabled": True,
    "downloads_page_review_release_button_enabled": True,
    "downloads_page_show_folder_button_enabled": True,
    "downloads_page_status_bar_note_enabled": True,
    "downloads_page_manual_refresh_guidance_enabled": True,
    "downloads_page_no_live_auto_refresh_for_stability": True,
    "default_bookmarks_removed_for_v1": True,
    "default_bookmarks_empty_by_default": True,
    "legacy_default_bookmarks_suppressed": True,
    "wallet_integration_enabled": True,
    "wallet_bridge_command": "sentinel-wallet",
    "wallet_browser_contract_status_enabled": True,
    "wallet_browser_open_enabled": True,
    "wallet_browser_payments_enabled": True,
    "wallet_browser_signing_enabled": True,
    "wallet_browser_no_secret_storage": True,
    "wallet_bridge_v0_4_1_compatible": True,
    "wallet_bridge_request_response_enabled": True,
    "wallet_bridge_status_command_enabled": True,
    "wallet_bridge_open_command_enabled": True,
    "wallet_bridge_read_response_enabled": True,
    "wallet_bridge_contract_schema_target": "sentinel.wallet.browser_bridge_contract.v1_0_1",
    "wallet_browser_dapp_login_enabled": True,
    "wallet_browser_transaction_signing_requests_enabled": True,
    "wallet_browser_signed_payload_only": True,
    "wallet_browser_never_receives_wallet_secrets": True,
    "wallet_bridge_browser_generated_request_id": True,
    "wallet_toolbar_button_visible": True,
    "wallet_toolbar_button_right_side_enabled": True,
    "wallet_toolbar_button_beside_security_2fa": True,
    "wallet_crypto_only_required": True,
    "wallet_card_features_forbidden": True,
    "wallet_nft_support_required": True,
    "wallet_nft_inventory_link_enabled": True,
    "wallet_passphrase_escrow_status_enabled": True,
    "wallet_passphrase_escrow_browser_never_receives_secret": True,
    "wallet_login_message_signing_status_enabled": True,
    "wallet_toolbar_icon_only": True,
    "blockchain_dapp_provider_enabled": True,
    "blockchain_provider_injection_enabled": True,
    "blockchain_provider_clearnet_to_dapp_no_settings_change": True,
    "blockchain_provider_wallet_approval_required": True,
    "blockchain_provider_supported_namespaces": ["eip155", "solana", "bip122"],
    "blockchain_provider_evm_window_ethereum": True,
    "blockchain_provider_solana_window_sentinelSolana": True,
    "blockchain_provider_solana_window_solana": True,
    "blockchain_provider_btc_psbt_foundation": True,
    "walletconnect_v2_foundation_enabled": True,
    "walletconnect_uri_capture_enabled": True,
    "walletconnect_supported_namespaces": ["eip155", "solana", "bip122"],
    "walletconnect_provider_response_polling_enabled": True,
    "walletconnect_provider_response_timeout_seconds": 90,
    "walletconnect_manual_uri_entry_enabled": True,
    "blockchain_provider_metamask_compat_enabled": True,
    "blockchain_provider_phantom_compat_enabled": True,
    "blockchain_provider_eip6963_announce_enabled": True,
    "blockchain_provider_window_open_wc_capture_enabled": True,
    "blockchain_provider_click_wc_capture_enabled": True,
    "native_provider_core_enabled": True,
    "native_provider_schema_version": "v1",
    "native_provider_bridge_schema": NATIVE_PROVIDER_BRIDGE_SCHEMA,
    "native_provider_request_schema": NATIVE_PROVIDER_REQUEST_SCHEMA,
    "native_provider_response_schema": NATIVE_PROVIDER_RESPONSE_SCHEMA,
    "evm_native_provider_phase2_enabled": True,
    "evm_provider_methods_phase2_declared": True,
    "evm_returns_real_account_after_wallet_approval": True,
    "solana_native_provider_phase3_enabled": True,
    "solana_provider_methods_phase3_declared": True,
    "solana_returns_public_key_after_wallet_approval": True,
    "solana_wallet_standard_foundation_enabled": True,
    "official_wallet_provider_icon_enabled": True,
    "native_provider_shared_request_response_bridge_enabled": True,
    "native_provider_request_envelope_enabled": True,
    "native_provider_wallet_queue_enabled": True,
    "native_provider_browser_never_signs": True,
    "native_provider_browser_never_stores_wallet_secrets": True,
    "native_provider_response_polling_enabled": True,
    "evm_native_provider_phase2_enabled": True,
    "evm_provider_accounts_enabled": True,
    "evm_provider_message_signing_enabled": True,
    "evm_provider_transaction_payload_forwarding_enabled": True,
    "evm_provider_wallet_switch_chain_enabled": True,
    "evm_provider_eip6963_discovery_enabled": True,
    "solana_native_provider_phase3_enabled": True,
    "solana_provider_connect_enabled": True,
    "solana_provider_sign_message_enabled": True,
    "solana_provider_transaction_payload_forwarding_enabled": True,
    "solana_provider_phantom_compat_enabled": True,
    "solana_provider_wallet_standard_foundation_enabled": True,
    "wallet_status_cache_enabled": True,
    "wallet_status_cache_ttl_seconds": 8,
    "wallet_status_subprocess_timeout_seconds": 2,
    "browser_rc24_startup_cleanup_enabled": True,
    "download_guard_no_quarantine_open_without_release": True,
    "download_indicator_reset_after_release_enabled": True,
    "download_indicator_reset_after_delete_enabled": True,
    "download_indicator_keeps_complete_while_review_pending": True,
    "rc24_from_confirmed_rc24_base": True,
    "rc24_gui_render_safe_branch": True,
    "manual_help_menu_dialog_enabled": True,
    "manual_webkit_page_disabled_for_startup_safety": True,
    "tab_row_safe_slimming_enabled": True,
    "security_controls_button_right_of_2fa": True,
    "security_controls_button_directly_beside_2fa": True,
    "security_controls_button_left_of_2fa": True,
    "security_controls_left_toolbar_duplicate_removed": True,
    "toolbar_security_vault_2fa_pair_enabled": True,
    "https_first_address_entry_enabled": True,
    "sentinel_home_page_enabled": True,
    "sentinel_home_default_enabled": True,
    "sentinel_home_packaged_html_enabled": True,
    "sentinel_home_packaged_html_path": str(HOMEPAGE_FILE),
    "sentinel_home_new_tab_default_enabled": True,
    "sentinel_home_startup_default_enabled": True,
    "sentinel_home_file_external_favicons_allowed_by_page_csp": True,
    "sentinel_home_file_uri_load_for_persistent_storage": True,
    "sentinel_home_theme_default_system": True,
    "sentinel_home_search_dropdown_themed": True,
    "bookmarks_toolbar_title_text_enabled": False,
    "vault_save_credentials_prompt_enabled": True,
    "vault_save_credentials_requires_user_approval": True,
    "vault_save_credentials_browser_stores_secrets": False,
    "network_settings_gui_enabled": True,
    "proxy_settings_gui_enabled": True,
    "vpn_settings_gui_enabled": True,
    "proxy_mode": "system",
    "proxy_http": "",
    "proxy_https": "",
    "proxy_socks": "",
    "proxy_bypass": "localhost,127.0.0.1,::1",
    "vpn_helper_command": "",
    "vpn_notes": "Use your Debian/system VPN or proxy provider. Sentinel Browser stores these local preferences and uses the system network stack by default.",
    "tor_integration_enabled": True,
    "tor_toolbar_switch_enabled": True,
    "tor_button_restore_default_visible": True,
    "tor_toolbar_force_hidden": False,
    "tor_installed_by_installer": False,
    "tor_toolbar_left_of_searchbar": True,
    "tor_operalike_toggle_after_setup": True,
    "tor_socks_host": "127.0.0.1",
    "tor_socks_port": 9050,
    "tor_control_host": "127.0.0.1",
    "tor_control_port": 9051,
    "tor_control_cookie_auth": True,
    "tor_menu_enabled": True,
    "tor_change_identity_enabled": True,
    "tor_status_user_readable_gui_enabled": True,
    "tor_test_user_readable_gui_enabled": True,
    "tor_toolbar_country_label_enabled": True,
    "tor_operalike_vpn_user_experience_enabled": True,
    "tor_bypass": "localhost,127.0.0.1,::1",
    "tor_never_routes_file_or_sentinel_pages": True,
    "https_indicator_inside_address_bar": True,
    "bookmarks_toolbar_label_removed_next_to_tabs": True,
    "bookmarks_toolbar_uses_full_width_for_favourites": True,
    "security_controls_checkbox_ui_enabled": True,
    "security_controls_user_editable": True,
    "security_controls_menu_opens_editable_checkboxes": True,
    "security_checkbox_camera_block": True,
    "security_checkbox_microphone_block": True,
    "security_checkbox_location_block": True,
    "security_checkbox_notifications_block": True,
    "security_checkbox_clipboard_ask": True,
    "security_checkbox_popups_block": True,
    "security_checkbox_file_access_block": True,
    "security_checkbox_media_autoplay_block": True,
    "v1_security_gate_enabled": True,
    "clean_debian_standalone_supported": True,
    "aegis_required_for_runtime": False,
    "sentinel_os_required_for_runtime": False,
    "browser_profile_chmod_700_required": True,
    "browser_incoming_chmod_700_required": True,
    "downloads_never_auto_open_required": True,
    "downloads_never_saved_inside_profile_required": True,
    "download_live_tooltip_percent_enabled": False,
    "downloads_page_timer_auto_refresh_enabled": False,
    "site_data_manager_enabled": True,
    "site_data_clear_gui_enabled": True,
    "security_profile_gui_enabled": True,
    "phase4_user_ready_gui_enabled": True,
    "address_bar_mid_dark_grey": True,
    "address_bar_star_inside": False,
    "toolbar_right_actions_enabled": True,
    "incognito_button_enabled": True,
    "tooltip_help_enabled": True,
    "bookmarks_toolbar_enabled": True,
    "bookmarks_toolbar_button_enabled": True,
    "bookmarks_toolbar_click_actions_fixed": True,
    "bookmarks_toolbar_toggle_fixed": True,
    "bookmark_editor_enabled": True,
    "bookmark_context_menu_enabled": True,
    "bookmark_toolbar_context_menu_quick_actions_enabled": True,
    "bookmark_toolbar_drag_reorder_enabled": True,
    "bookmark_toolbar_drag_to_folder_enabled": True,
    "bookmark_drag_payload_local_only": True,
    "bookmark_toolbar_save_button_editor_fixed": True,
    "tab_context_menu_enabled": True,
    "web_context_menu_sentinel_actions_enabled": True,
    "downloads_toolbar_button_enabled": True,
    "download_guard_backend_enabled": True,
    "download_guard_status_preview_enabled": True,
    "download_guard_completion_prompt_enabled": False,
    "download_guard_auto_completion_popup_enabled": False,
    "download_guard_click_button_to_review_enabled": True,
    "download_guard_modal_permission_prompt_enabled": False,
    "download_guard_auto_quarantine_without_initial_popup": True,
    "download_guard_subprocess_ui_thread_blocking_disabled": True,
    "download_guard_progress_ui_only_interval_ms": 700,
    "download_guard_backend_update_interval_ms": 2500,
    "download_guard_open_released_file_option": True,
    "download_guard_open_released_folder_option": True,
    "statusbar_link_hover_preview_enabled": True,
    "statusbar_image_hover_preview_enabled": True,
    "vault_login_strict_password_receiver_guard": True,
    "vault_account_hint_dropdown_enabled": True,
    "download_guard_progress_window_enabled": False,
    "download_guard_lime_complete_icon_enabled": True,
    "download_guard_current_only_page_enabled": True,
    "download_guard_button_tooltip_live_status_enabled": False,
    "download_guard_backend_active_progress_enabled": False,
    "download_guard_progress_poll_interval_ms": 500,
    "downloads_page_live_refresh_enabled": True,
    "download_guard_v12_contract_required": True,
    "download_guard_urgent_cancel_poll_enabled": False,
    "download_guard_standard_cancel_poll_enabled": False,
    "download_guard_urgent_cancel_poll_interval_ms": 2500,
    "download_guard_cancel_ack_enabled": False,
    "download_guard_lifecycle_test_enabled": True,
    "tab_row_new_tab_button_enabled": True,
    "incognito_themed_icon_enabled": True,
    "vault_2fa_icon_button_enabled": True,
    "privacy_top_menu_enabled": False,
    "vault_top_menu_enabled": False,
    "vault_2fa_quick_widget_enabled": True,
    "vault_2fa_toolbar_enabled": True,
    "vault_2fa_toolbar_mode": "direct_vault_browser_origin_popup",
    "vault_bridge_enabled": True,
    "vault_2fa_bridge_enabled": True,
    "vault_bridge_manual_launcher_enabled": True,
    "vault_login_prompt_enabled": True,
    "vault_login_prompt_bar_enabled": True,
    "vault_login_prompt_detection_enabled": True,
    "vault_login_prompt_respects_never_sites": True,
    "vault_login_password_receiver_command": "--browser-password-popup",
    "vault_login_password_status_command": "--browser-password-popup-status",
    "vault_account_hints_enabled": True,
    "vault_pairing_half_enabled": True,
    "vault_bridge_command": "sentinel-password-vault",
    "vault_browser_secret_storage_enabled": False,
    "vault_autofill_requires_user_approval": True,
    "vault_auto_submit_enabled": False,
    "restore_tabs": False,
    "save_session": False,
    "enable_javascript": True,
    "javascript_profile": "standard",
    "javascript_policy_enabled": True,
    "javascript_per_site_policy": True,
    "javascript_file_urls_enabled": False,
    "javascript_data_urls_enabled": False,
    "javascript_local_pages_enabled": False,
    "javascript_temporary_allow_enabled": True,
    "javascript_lockdown_blocks_all_by_default": True,
    "javascript_status_honesty": "enforced_attempted_policy_only_separated",
    "enable_developer_extras": False,
    "allow_file_access_from_file_urls": False,
    "private_by_default": False,
    "show_statusbar": True,
    "show_bookmarks_bar": True,
    "warn_external_protocols": True,
    "warn_downloads": True,
    "site_permissions_default_posture": "block_sensitive",
    "permission_camera_default": "block",
    "permission_microphone_default": "block",
    "permission_geolocation_default": "block",
    "permission_notifications_default": "block",
    "permission_clipboard_default": "ask",
    "permission_popups_default": "block",
    "permission_file_access_default": "block",
    "permission_media_autoplay_default": "block",
    "permission_prompt_unknown": True,
    "permission_log_events": True,
    "ask_before_download": True,
    "block_dangerous_downloads": True,
    "confirm_dangerous_downloads": True,
    "explain_dangerous_downloads": True,
    "dangerous_download_user_override": True,
    "quarantine_unknown_downloads": True,
    "allow_executable_downloads": False,
    "auto_open_downloads": False,
    "download_directory": str(DOWNLOADS_DIR),  # Browser handoff/quarantine staging only; final release is controlled by Download Guard.
    "download_max_filename_length": 120,
    "block_tls_errors": True,
    "show_security_indicator": True,
    "app_scoped_webkit_storage": True,
    "disable_hyperlink_auditing": True,
    "disable_dns_prefetching": True,
    "disable_webrtc_media_capture": True,
    "disable_webgl_by_default": True,
    "warn_insecure_http": False,
    "private_mode": False,
    "history_logging_enabled": False,
    "remember_form_data": False,
    "block_third_party_cookies": True,
    "clear_cache_on_exit": False,
    "clear_cookies_on_exit": False,
    "clear_local_storage_on_exit": False,
    "aegis_bridge_enabled": False,
    "aegis_bridge_allow_status_read": True,
    "aegis_bridge_allow_security_events": True,
    "aegis_bridge_allow_page_metadata": False,
    "aegis_bridge_allow_advisory_warnings": True,
    "aegis_bridge_allow_content_capture": False,
    "aegis_bridge_allow_password_access": False,
    "aegis_bridge_allow_autonomous_navigation": False,
    "aegis_bridge_allow_download_actions": False,
    "content_blocking_enabled": True,
    "block_trackers": True,
    "block_known_miners": True,
    "block_fingerprinting_scripts": True,
    "fingerprint_defense_enabled": True,
    "restrict_canvas_fingerprinting": True,
    "restrict_audio_fingerprinting": True,
    "restrict_font_fingerprinting_policy": True,
    "no_remote_blocklist_subscriptions": True,
    "content_policy_local_only": True,
    "content_blocking_log_events": True,
    "content_blocking_allow_user_override": True,
    "strict_security_profile_enabled": True,
    "enable_webkit_sandbox_attempt": True,
    "block_mixed_content_policy": True,
    "enforce_https_upgrade_attempt": True,
    "block_popups_new_windows": True,
    "security_profile": "sentinel_hardened_general_use",
    "v1_security_gates_required": True,
    "default_zoom": 1.0,
    "user_agent_suffix": "SentinelBrowser/1.0.0",
}


HOTKEYS: Dict[str, Dict[str, str]] = {
    "navigation": {
        "Ctrl+L": "Focus address/search bar",
        "Alt+Left": "Back",
        "Alt+Right": "Forward",
        "F5": "Reload page",
        "Ctrl+R": "Reload page",
        "Ctrl+Shift+R": "Reload bypassing cache where supported",
        "Escape": "Stop loading",
    },
    "tabs_windows": {
        "Ctrl+T": "New tab",
        "Ctrl+W": "Close current tab",
        "Ctrl+Q": "Close Sentinel Browser app",
        "Ctrl+Tab": "Next tab",
        "Ctrl+Shift+Tab": "Previous tab",
        "F11": "Toggle fullscreen",
    },
    "page_controls": {
        "Ctrl+D": "Bookmark current page",
        "Ctrl++": "Zoom in",
        "Ctrl+-": "Zoom out",
        "Ctrl+0": "Reset zoom",
    },
    "security_privacy": {
        "Shield button": "Open Security / Privacy control panel",
        "Private helper": "sentinel-browser-private opens a private session",
        "Clear-data helper": "sentinel-browser-clear-data clears app-scoped browsing data",
    },
}


def now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _path_has_symlink_component(path: Path) -> bool:
    """Return True when any existing component in path is a symlink.

    Browser profile/cache/config paths are private app-owned locations. Following
    symlinked components here can chmod, delete, or write outside Sentinel
    Browser's intended storage tree, so redteam v1.1.14 refuses them.
    """
    p = Path(path).expanduser()
    cur = Path(p.anchor) if p.is_absolute() else Path.cwd()
    parts = p.parts[1:] if p.is_absolute() else p.parts
    for part in parts:
        cur = cur / part
        try:
            if cur.is_symlink():
                return True
        except OSError:
            return True
    return False


def _ensure_private_dir(path: Path, mode: int = 0o700) -> None:
    p = Path(path).expanduser()
    if _path_has_symlink_component(p):
        raise RuntimeError(f"unsafe symlinked browser path refused: {p}")
    p.mkdir(parents=True, exist_ok=True)
    try:
        st = p.lstat()
        if not stat.S_ISDIR(st.st_mode):
            raise RuntimeError(f"browser path is not a directory: {p}")
        os.chmod(p, mode, follow_symlinks=False)
    except TypeError:
        # Older Python fallback after lstat confirmed this is not a symlink.
        p.chmod(mode)


def secure_chmod_700(path: Path) -> None:
    try:
        if path.exists() and path.is_dir() and not _path_has_symlink_component(path):
            os.chmod(path, 0o700, follow_symlinks=False)
    except Exception:
        pass


def ensure_dirs() -> None:
    private_dirs = (CONFIG_DIR, DATA_DIR, STATE_DIR, CACHE_DIR, WEBKIT_DATA_DIR, WEBKIT_CACHE_DIR, DOWNLOADS_DIR, AEGIS_BRIDGE_DIR)
    for p in private_dirs:
        _ensure_private_dir(p)


def _safe_atomic_write_text(path: Path, text: str, mode: int = 0o600) -> None:
    p = Path(path).expanduser()
    if p.exists() and p.is_symlink():
        raise RuntimeError(f"refusing to overwrite symlink: {p}")
    if _path_has_symlink_component(p.parent):
        raise RuntimeError(f"refusing to write through symlinked parent: {p.parent}")
    _ensure_private_dir(p.parent)
    fd, tmp_name = tempfile.mkstemp(prefix=p.name + ".", suffix=".tmp", dir=str(p.parent), text=True)
    tmp = Path(tmp_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(text)
        os.chmod(tmp, mode)
        os.replace(tmp, p)
    finally:
        try:
            if tmp.exists():
                tmp.unlink()
        except Exception:
            pass


def _safe_append_line(path: Path, line: str, mode: int = 0o600) -> None:
    p = Path(path).expanduser()
    if p.exists() and p.is_symlink():
        raise RuntimeError(f"refusing to append to symlink: {p}")
    if _path_has_symlink_component(p.parent):
        raise RuntimeError(f"refusing to append through symlinked parent: {p.parent}")
    _ensure_private_dir(p.parent)
    with p.open("a", encoding="utf-8") as fh:
        fh.write(line)
    try:
        os.chmod(p, mode)
    except Exception:
        pass


def browser_profile_security_status() -> Dict[str, Any]:
    ensure_dirs()
    paths = {
        "config_dir": CONFIG_DIR,
        "data_dir": DATA_DIR,
        "state_dir": STATE_DIR,
        "cache_dir": CACHE_DIR,
        "webkit_data_dir": WEBKIT_DATA_DIR,
        "webkit_cache_dir": WEBKIT_CACHE_DIR,
        "incoming_download_dir": DOWNLOADS_DIR,
    }
    modes: Dict[str, str] = {}
    private_ok = True
    for name, path in paths.items():
        try:
            mode = path.stat().st_mode & 0o777
            modes[name] = oct(mode)
            private_ok = private_ok and mode in (0o700, 0o750)
        except Exception as exc:
            modes[name] = "error:" + type(exc).__name__
            private_ok = False
    return {
        "ok": private_ok,
        "schema": "sentinel.browser.profile_security.v1",
        "app": APP_NAME,
        "version": VERSION,
        "private_dirs_chmod_700_attempted": True,
        "browser_profile_private": private_ok,
        "downloads_staging_private": modes.get("incoming_download_dir") in ("0o700", "0o750"),
        "downloads_inside_webkit_profile": str(DOWNLOADS_DIR).startswith(str(WEBKIT_DATA_DIR)),
        "auto_open_downloads": bool(DEFAULT_CONFIG.get("auto_open_downloads", False)),
        "modes": modes,
        "paths": {k: str(v) for k, v in paths.items()},
    }


def log_crash(exc: BaseException) -> None:
    try:
        ensure_dirs()
        import io
        buf = io.StringIO()
        buf.write(f"\n[{now_iso()}] {type(exc).__name__}: {exc}\n")
        traceback.print_exc(file=buf)
        _safe_append_line(CRASH, buf.getvalue())
    except Exception:
        pass


def log_security_event(kind: str, detail: Dict[str, Any]) -> None:
    """Log browser security events without recording normal browsing history."""
    try:
        ensure_dirs()
        payload = {"time": now_iso(), "kind": kind, "detail": detail}
        _safe_append_line(SECURITY_EVENTS, json.dumps(payload, sort_keys=True) + "\n")
    except Exception:
        pass


def load_json(path: Path, fallback: Any) -> Any:
    try:
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        log_crash(exc)
    return fallback


def save_json(path: Path, payload: Any) -> None:
    ensure_dirs()
    _safe_atomic_write_text(path, json.dumps(payload, indent=2, sort_keys=True) + "\n")


def merged_config(raw: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    out = dict(DEFAULT_CONFIG)
    if isinstance(raw, dict):
        out.update(raw)
    for key in (
        "restore_tabs", "save_session", "enable_javascript", "search_policy_enabled", "allow_custom_search_url",
        "sentinel_home_page_enabled", "sentinel_home_default_enabled", "bookmarks_toolbar_title_text_enabled",
        "vault_save_credentials_prompt_enabled", "vault_save_credentials_requires_user_approval", "vault_save_credentials_browser_stores_secrets",
        "network_settings_gui_enabled", "proxy_settings_gui_enabled", "vpn_settings_gui_enabled", "tor_integration_enabled", "tor_toolbar_switch_enabled", "tor_button_restore_default_visible", "tor_toolbar_force_hidden", "tor_installed_by_installer", "tor_toolbar_left_of_searchbar", "tor_operalike_toggle_after_setup", "tor_never_routes_file_or_sentinel_pages", "tor_menu_enabled", "tor_change_identity_enabled", "https_indicator_inside_address_bar", "walletconnect_v2_foundation_enabled", "walletconnect_uri_capture_enabled",
        "exclude_kagi_builtin", "menu_bar_enabled", "settings_ui_enabled", "preferences_window_enabled", "preferences_sections_enabled",
        "search_engine_selector_gui_enabled", "custom_search_url_gui_enabled", "download_guard_settings_gui_enabled",
        "download_guard_release_dir_gui_enabled", "download_guard_lightweight_polling_enabled",
        "download_guard_no_ui_thread_blocking_target", "site_data_manager_enabled", "site_data_clear_gui_enabled",
        "security_profile_gui_enabled", "phase4_user_ready_gui_enabled", "address_bar_mid_dark_grey",
        "address_bar_star_inside", "toolbar_right_actions_enabled", "incognito_button_enabled",
        "tooltip_help_enabled", "bookmarks_toolbar_enabled", "bookmarks_toolbar_button_enabled", "bookmarks_toolbar_click_actions_fixed", "bookmarks_toolbar_toggle_fixed", "bookmark_editor_enabled", "bookmark_context_menu_enabled", "bookmark_toolbar_save_button_editor_fixed", "tab_context_menu_enabled", "web_context_menu_sentinel_actions_enabled", "downloads_toolbar_button_enabled", "download_guard_backend_enabled", "download_guard_status_preview_enabled", "download_guard_completion_prompt_enabled", "download_guard_open_released_file_option", "download_guard_open_released_folder_option", "statusbar_link_hover_preview_enabled", "statusbar_image_hover_preview_enabled", "vault_login_strict_password_receiver_guard", "vault_account_hint_dropdown_enabled", "download_guard_progress_window_enabled", "download_guard_lime_complete_icon_enabled", "download_guard_backend_active_progress_enabled", "tab_row_new_tab_button_enabled", "incognito_themed_icon_enabled", "vault_2fa_icon_button_enabled", "privacy_top_menu_enabled",
        "vault_top_menu_enabled", "vault_2fa_quick_widget_enabled", "vault_2fa_toolbar_enabled", "vault_bridge_enabled", "vault_2fa_bridge_enabled",
        "vault_bridge_manual_launcher_enabled", "vault_login_prompt_enabled", "vault_login_prompt_bar_enabled", "vault_login_prompt_detection_enabled", "vault_login_prompt_respects_never_sites", "vault_account_hints_enabled",
        "vault_pairing_half_enabled", "vault_browser_secret_storage_enabled",
        "vault_autofill_requires_user_approval", "vault_auto_submit_enabled",
        "javascript_policy_enabled", "javascript_per_site_policy",
        "javascript_file_urls_enabled", "javascript_data_urls_enabled", "javascript_local_pages_enabled",
        "javascript_temporary_allow_enabled", "javascript_lockdown_blocks_all_by_default", "enable_developer_extras",
        "allow_file_access_from_file_urls", "private_by_default", "show_statusbar",
        "show_bookmarks_bar", "warn_external_protocols", "warn_downloads", "permission_prompt_unknown", "permission_log_events", "ask_before_download",
        "block_dangerous_downloads", "confirm_dangerous_downloads", "explain_dangerous_downloads",
        "dangerous_download_user_override", "quarantine_unknown_downloads", "allow_executable_downloads",
        "auto_open_downloads", "block_tls_errors",
        "show_security_indicator", "app_scoped_webkit_storage", "disable_hyperlink_auditing",
        "disable_dns_prefetching", "disable_webrtc_media_capture", "disable_webgl_by_default",
        "warn_insecure_http",
        "private_mode", "history_logging_enabled", "remember_form_data",
        "block_third_party_cookies", "clear_cache_on_exit", "clear_cookies_on_exit",
        "clear_local_storage_on_exit",
        "aegis_bridge_enabled", "aegis_bridge_allow_status_read", "aegis_bridge_allow_security_events",
        "aegis_bridge_allow_page_metadata", "aegis_bridge_allow_advisory_warnings",
        "aegis_bridge_allow_content_capture", "aegis_bridge_allow_password_access",
        "aegis_bridge_allow_autonomous_navigation", "aegis_bridge_allow_download_actions",
        "content_blocking_enabled", "block_trackers", "block_known_miners", "block_fingerprinting_scripts",
        "fingerprint_defense_enabled", "restrict_canvas_fingerprinting", "restrict_audio_fingerprinting",
        "restrict_font_fingerprinting_policy", "no_remote_blocklist_subscriptions", "content_policy_local_only",
        "content_blocking_log_events", "content_blocking_allow_user_override",
        "strict_security_profile_enabled", "enable_webkit_sandbox_attempt", "block_mixed_content_policy",
        "enforce_https_upgrade_attempt", "block_popups_new_windows", "v1_security_gates_required", "default_bookmarks_removed_for_v1", "default_bookmarks_empty_by_default", "legacy_default_bookmarks_suppressed", "wallet_integration_enabled", "wallet_browser_contract_status_enabled", "wallet_browser_open_enabled", "wallet_browser_payments_enabled", "wallet_browser_signing_enabled", "wallet_browser_no_secret_storage",
    ):
        out[key] = bool(out.get(key, DEFAULT_CONFIG[key]))
    # v1.1.15 / bundle v1.1.21: keep the TOR toolbar/menu visible by default even
    # when the installer did not install Tor. Older v1.1.20 installs wrote
    # tor_toolbar_switch_enabled=false for non-"--with-tor" profiles, which made the
    # user's TOR button disappear entirely. The switch now remains visible and reports
    # TOR: Setup until local Tor is installed/listening. Use tor_toolbar_force_hidden=true
    # only for an intentional local policy that removes the control.
    if bool(out.get("tor_button_restore_default_visible", True)) and not bool(out.get("tor_toolbar_force_hidden", False)):
        out["tor_toolbar_switch_enabled"] = True
        out["tor_menu_enabled"] = True
        out["tor_integration_enabled"] = True
        out["tor_change_identity_enabled"] = True

    try:
        out["default_zoom"] = float(out.get("default_zoom", 1.0))
    except Exception:
        out["default_zoom"] = 1.0
    out["default_zoom"] = max(0.5, min(3.0, out["default_zoom"]))
    for key in ("home_url", "search_url", "user_agent_suffix", "download_directory", "default_search_engine", "private_search_engine", "custom_search_url", "vault_2fa_toolbar_mode", "vault_bridge_command", "vault_login_password_receiver_command", "vault_login_password_status_command", "proxy_mode", "proxy_http", "proxy_https", "proxy_socks", "proxy_bypass", "vpn_helper_command", "vpn_notes", "tor_socks_host", "tor_bypass", "tor_control_host", "wallet_bridge_command", "sentinel_home_packaged_html_path"):
        if not isinstance(out.get(key), str):
            out[key] = DEFAULT_CONFIG[key]
    for key, fallback in (("default_search_engine", "duckduckgo"), ("private_search_engine", "mojeek")):
        value = str(out.get(key, fallback)).lower().strip()
        if value not in SEARCH_ENGINES or value == "custom" and not str(out.get("custom_search_url", "")).strip():
            value = fallback
        out[key] = value
    custom_url = str(out.get("custom_search_url", "")).strip()
    if custom_url and "{query}" not in custom_url:
        out["custom_search_url"] = ""
    if "{query}" not in out["search_url"]:
        default_engine = out.get("default_search_engine", "duckduckgo")
        out["search_url"] = SEARCH_ENGINES.get(default_engine, SEARCH_ENGINES["duckduckgo"])["url"] or DEFAULT_CONFIG["search_url"]

    try:
        out["download_max_filename_length"] = int(out.get("download_max_filename_length", 120))
    except Exception:
        out["download_max_filename_length"] = 120
    out["download_max_filename_length"] = max(32, min(240, out["download_max_filename_length"]))

    permission_action_keys = (
        "permission_camera_default", "permission_microphone_default", "permission_geolocation_default",
        "permission_notifications_default", "permission_clipboard_default", "permission_popups_default",
        "permission_file_access_default", "permission_media_autoplay_default",
    )
    for key in permission_action_keys:
        value = str(out.get(key, DEFAULT_CONFIG[key])).lower().strip()
        if value not in {"block", "ask", "allow"}:
            value = DEFAULT_CONFIG[key]
        out[key] = value
    posture = str(out.get("site_permissions_default_posture", "block_sensitive")).lower().strip()
    if posture not in {"block_sensitive", "ask_sensitive", "custom"}:
        posture = "block_sensitive"
    out["site_permissions_default_posture"] = posture
    if "{query}" not in out["search_url"]:
        out["search_url"] = DEFAULT_CONFIG["search_url"]
    js_profile = str(out.get("javascript_profile", "standard")).lower().strip()
    if js_profile not in {"standard", "shield", "lockdown"}:
        js_profile = "standard"
    out["javascript_profile"] = js_profile
    out["schema_version"] = 24
    return out


def load_config(safe_mode: bool = False) -> Dict[str, Any]:
    return dict(DEFAULT_CONFIG) if safe_mode else merged_config(load_json(CONFIG, {}))


def save_config(cfg: Dict[str, Any]) -> None:
    save_json(CONFIG, merged_config(cfg))


def restore_tor_button_config_json(source: str = "cli") -> Dict[str, Any]:
    """Repair legacy installs where the v1.1.20 installer hid the TOR UI.

    This does not enable Tor routing by itself and does not install Tor. It only restores
    the visible toolbar/menu controls so the user can see TOR, test setup, and switch on
    routing once local Tor is available.
    """
    raw = load_json(CONFIG, {})
    if not isinstance(raw, dict):
        raw = {}
    raw.update({
        "tor_button_restore_default_visible": True,
        "tor_toolbar_force_hidden": False,
        "tor_toolbar_switch_enabled": True,
        "tor_integration_enabled": True,
        "tor_menu_enabled": True,
        "tor_change_identity_enabled": True,
        "tor_status_user_readable_gui_enabled": True,
        "tor_test_user_readable_gui_enabled": True,
        "tor_toolbar_country_label_enabled": True,
    })
    save_config(raw)
    log_security_event("tor_button_restored", {"source": source})
    return {
        "ok": True,
        "schema": "sentinel.browser.tor_button_restore.v1_1_15",
        "app": APP_NAME,
        "version": VERSION,
        "source": source,
        "message": "TOR toolbar/menu controls restored. Routing remains off until the user enables TOR and local Tor is ready.",
        "config": str(CONFIG),
        "tor_status": tor_routing_status_json(include_paths=False),
    }


def tor_button_restore_regression_test_json() -> Dict[str, Any]:
    # Simulate legacy v1.1.20 non-Tor installer config. merged_config should now
    # restore visible controls while preserving routing disabled by tor-routing.json.
    legacy = {
        "tor_integration_enabled": False,
        "tor_toolbar_switch_enabled": False,
        "tor_menu_enabled": False,
        "tor_change_identity_enabled": False,
        "installer_profile": "browser_dlg_basic",
    }
    cfg = merged_config(legacy)
    checks = {
        "legacy_false_toolbar_restored": cfg.get("tor_toolbar_switch_enabled") is True,
        "legacy_false_menu_restored": cfg.get("tor_menu_enabled") is True,
        "legacy_false_integration_restored": cfg.get("tor_integration_enabled") is True,
        "restore_can_be_policy_hidden_only_with_force_key": merged_config({**legacy, "tor_toolbar_force_hidden": True}).get("tor_toolbar_switch_enabled") is False,
        "tor_button_default_visible_key_present": DEFAULT_CONFIG.get("tor_button_restore_default_visible") is True,
    }
    return {"ok": all(checks.values()), "schema": "sentinel.browser.tor_button_restore_regression_test.v1_1_15", "app": APP_NAME, "version": VERSION, "checks": checks}


def dependency_status() -> Dict[str, Any]:
    status = {
        "python": sys.version.split()[0],
        "gtk_available": False,
        "webkit_available": False,
        "display_available": bool(os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY")),
        "webkit_api": "unknown",
        "webkit_version": "unknown",
        "webkit_sandbox_api_available": False,
        "webkit_process_model": "webkit_managed",
        "error": "",
    }
    try:
        import gi  # type: ignore
        gi.require_version("Gtk", "3.0")
        from gi.repository import Gtk  # type: ignore  # noqa:F401
        status["gtk_available"] = True
    except Exception as exc:
        status["error"] = f"GTK: {exc}"
        return status
    try:
        import gi  # type: ignore
        try:
            gi.require_version("WebKit2", "4.1")
            status["webkit_api"] = "4.1"
        except ValueError:
            gi.require_version("WebKit2", "4.0")
            status["webkit_api"] = "4.0"
        from gi.repository import WebKit2  # type: ignore  # noqa:F401
        status["webkit_available"] = True
        try:
            status["webkit_version"] = f"{WebKit2.get_major_version()}.{WebKit2.get_minor_version()}.{WebKit2.get_micro_version()}"
        except Exception:
            status["webkit_version"] = "available_unknown_version"
        try:
            ctx = WebKit2.WebContext.get_default()
            status["webkit_sandbox_api_available"] = hasattr(ctx, "set_sandbox_enabled")
        except Exception:
            status["webkit_sandbox_api_available"] = False
    except Exception as exc:
        status["error"] = f"WebKit2: {exc}"
    return status


def normalize_url(text: str, search_url: str = DEFAULT_CONFIG["search_url"]) -> str:
    value = (text or "").strip()
    if not value:
        return "about:blank"
    if value.startswith(("about:", "file://", "http://", "https://")):
        return value
    parsed = urlparse(value)
    if parsed.scheme and parsed.netloc:
        return value
    if "." in value and " " not in value:
        return "https://" + value
    return search_url.replace("{query}", quote(value))


def is_external_protocol(uri: str) -> bool:
    parsed = urlparse(uri or "")
    return bool(parsed.scheme and parsed.scheme not in {"http", "https", "about", "file", "data", "blob"})


def security_state_for_uri(uri: str) -> Dict[str, str]:
    parsed = urlparse(uri or "")
    scheme = parsed.scheme.lower()
    if not uri or scheme == "about":
        return {"state": "local", "label": "LOCAL", "detail": "Internal/local page"}
    if scheme == "https":
        return {"state": "secure", "label": "HTTPS", "detail": "Encrypted HTTPS page"}
    if scheme == "http":
        return {"state": "insecure", "label": "NOT SECURE", "detail": "Plain HTTP page"}
    if scheme == "file":
        return {"state": "file", "label": "FILE", "detail": "Local file page"}
    if is_external_protocol(uri):
        return {"state": "external", "label": "EXTERNAL", "detail": f"External protocol: {scheme}"}
    return {"state": "unknown", "label": "UNKNOWN", "detail": "Unknown page security state"}


def safe_download_filename(text: str, max_len: int = 120) -> str:
    raw = unquote((text or "").split("?")[0].split("#")[0].rstrip("/"))
    name = os.path.basename(raw) or "download.bin"
    name = re.sub(r"[^A-Za-z0-9._()\- ]+", "_", name).strip(". ") or "download.bin"
    if len(name) > max_len:
        stem = Path(name).stem[: max(8, max_len - len(Path(name).suffix) - 1)]
        suffix = Path(name).suffix[:16]
        name = (stem + suffix)[:max_len]
    return name


def classify_download_uri(uri: str, cfg: Optional[Dict[str, Any]] = None, suggested_filename: str = "") -> Dict[str, Any]:
    cfg = cfg or DEFAULT_CONFIG
    max_len = int(cfg.get("download_max_filename_length", 120))
    filename = safe_download_filename(suggested_filename or uri or "download.bin", max_len)
    ext = Path(filename).suffix.lower()
    dangerous = ext in DANGEROUS_DOWNLOAD_EXTENSIONS
    executable_allowed = bool(cfg.get("allow_executable_downloads", False))
    confirm_dangerous = bool(cfg.get("confirm_dangerous_downloads", True))
    user_override = bool(cfg.get("dangerous_download_user_override", True))
    block_policy = bool(cfg.get("block_dangerous_downloads", True)) and dangerous and not executable_allowed
    requires_confirmation = bool(dangerous and confirm_dangerous)
    blocked = bool(block_policy and not (requires_confirmation and user_override))
    blocked_by_default = bool(block_policy)
    reason = "dangerous_extension" if dangerous else "standard_download"
    directory = Path(str(cfg.get("download_directory", str(DOWNLOADS_DIR)))).expanduser()
    if _path_has_symlink_component(directory):
        directory = DOWNLOADS_DIR
    return {
        "filename": filename,
        "extension": ext,
        "dangerous": dangerous,
        "blocked": blocked,
        "blocked_by_default": blocked_by_default,
        "requires_confirmation": requires_confirmation,
        "user_can_abandon": requires_confirmation,
        "user_can_download_anyway": bool(requires_confirmation and user_override),
        "reason": reason,
        "risk_explanation": download_risk_explanation(ext) if dangerous else "Standard download type.",
        "auto_open_allowed": bool(cfg.get("auto_open_downloads", False)),
        "destination_directory": str(directory),
        "destination": str(directory / filename),
    }


def download_risk_explanation(extension: str) -> str:
    ext = (extension or "").lower()
    if ext in {".exe", ".msi", ".scr", ".com", ".bat", ".cmd", ".ps1", ".vbs", ".vbe", ".wsf"}:
        return "This file type can run commands or install software and may harm the system if it is malicious."
    if ext in {".sh", ".run", ".appimage", ".desktop", ".jar"}:
        return "This file type may execute code on Linux or through a runtime. Only continue if you trust the source."
    if ext in {".deb", ".rpm"}:
        return "This package can install software and modify system files. Only continue if you trust the source and package."
    if ext in {".iso", ".dmg"}:
        return "This disk image may contain installers or executable files. Treat it as untrusted until verified."
    if ext in {".dll"}:
        return "This library file can be loaded by programs and may be unsafe if malicious."
    return "This file extension is considered high-risk and may execute code or alter the system."




def default_search_policy() -> Dict[str, Any]:
    return {
        "schema_version": 1,
        "program": PROGRAM,
        "app": APP_NAME,
        "policy_name": "sentinel-browser-search-policy",
        "local_only": True,
        "default_search_engine": "duckduckgo",
        "private_search_engine": "mojeek",
        "allow_custom_search_url": True,
        "excluded_builtin_engines": EXCLUDED_SEARCH_ENGINES,
        "built_in_engines": BUILT_IN_SEARCH_ENGINES,
        "engines": SEARCH_ENGINES,
        "notes": [
            "DuckDuckGo is the normal/default Sentinel Browser search preset.",
            "Mojeek is the private/incognito search preset.",
            "Google, Bing, Startpage, Marginalia, and Custom are user-selectable options only.",
            "Kagi is not included as a built-in preset; users may add it manually through Custom URL if they choose.",
            "Search policy is local-only and user-controlled.",
        ],
    }


def load_search_policy() -> Dict[str, Any]:
    raw = load_json(SEARCH_POLICY, {})
    base = default_search_policy()
    if isinstance(raw, dict):
        for key, value in raw.items():
            if key not in {"schema_version", "program", "app", "local_only", "excluded_builtin_engines"}:
                base[key] = value
    base["schema_version"] = 1
    base["program"] = PROGRAM
    base["app"] = APP_NAME
    base["local_only"] = True
    base["excluded_builtin_engines"] = EXCLUDED_SEARCH_ENGINES
    base["built_in_engines"] = BUILT_IN_SEARCH_ENGINES
    base["engines"] = SEARCH_ENGINES
    for key, fallback in (("default_search_engine", "duckduckgo"), ("private_search_engine", "mojeek")):
        value = str(base.get(key, fallback)).lower().strip()
        if value not in SEARCH_ENGINES or value == "custom" and not str(base.get("custom_search_url", "")).strip():
            value = fallback
        base[key] = value
    if "kagi" in [str(x).lower() for x in base.get("built_in_engines", []) if isinstance(base.get("built_in_engines", []), list)]:
        base["built_in_engines"] = [x for x in base.get("built_in_engines", []) if str(x).lower() != "kagi"]
    return base


def write_search_policy() -> None:
    if not SEARCH_POLICY.exists():
        save_json(SEARCH_POLICY, default_search_policy())


def search_engine_url(engine: str, policy: Optional[Dict[str, Any]] = None) -> str:
    policy = policy or load_search_policy()
    engine = str(engine or "duckduckgo").lower().strip()
    if engine == "custom":
        custom = str(policy.get("custom_search_url") or load_config(False).get("custom_search_url") or "").strip()
        if "{query}" in custom:
            return custom
        return SEARCH_ENGINES["duckduckgo"]["url"]
    return SEARCH_ENGINES.get(engine, SEARCH_ENGINES["duckduckgo"])["url"]


def effective_search_url(cfg: Optional[Dict[str, Any]] = None, policy: Optional[Dict[str, Any]] = None, private_mode: bool = False) -> str:
    cfg = cfg or load_config(False)
    policy = policy or load_search_policy()
    engine = str(policy.get("private_search_engine" if private_mode else "default_search_engine", cfg.get("private_search_engine" if private_mode else "default_search_engine", "duckduckgo"))).lower().strip()
    if engine not in SEARCH_ENGINES:
        engine = "mojeek" if private_mode else "duckduckgo"
    return search_engine_url(engine, policy)


def set_search_engine(kind: str, engine: str) -> Dict[str, Any]:
    kind = str(kind or "default").lower().strip()
    engine = str(engine or "").lower().strip()
    if kind not in {"default", "private"}:
        raise ValueError("Search engine kind must be default or private")
    if engine not in SEARCH_ENGINES or engine == "custom":
        raise ValueError("Search engine must be one of: duckduckgo, mojeek, marginalia, startpage, google, bing")
    policy = load_search_policy()
    policy["default_search_engine" if kind == "default" else "private_search_engine"] = engine
    save_json(SEARCH_POLICY, policy)
    cfg = load_config(False)
    cfg["default_search_engine"] = policy.get("default_search_engine", "duckduckgo")
    cfg["private_search_engine"] = policy.get("private_search_engine", "mojeek")
    if kind == "default":
        cfg["search_url"] = search_engine_url(engine, policy)
    save_config(cfg)
    log_security_event("search_engine_updated", {"kind": kind, "engine": engine})
    return policy


def search_policy_status_json(include_paths: bool = True) -> Dict[str, Any]:
    cfg = load_config(False)
    policy = load_search_policy()
    payload: Dict[str, Any] = {
        "schema_version": 1,
        "app": APP_NAME,
        "program": PROGRAM,
        "package": PACKAGE,
        "version": VERSION,
        "status": "menu_bar_user_settings_search_policy",
        "generated_at": now_iso(),
        "local_only": True,
        "default_search_engine": policy.get("default_search_engine", "duckduckgo"),
        "private_search_engine": policy.get("private_search_engine", "mojeek"),
        "normal_search_url": effective_search_url(cfg, policy, private_mode=False),
        "private_search_url": effective_search_url(cfg, policy, private_mode=True),
        "built_in_engines": BUILT_IN_SEARCH_ENGINES,
        "excluded_builtin_engines": EXCLUDED_SEARCH_ENGINES,
        "kagi_builtin_preset": False,
        "user_selectable_engines": ["duckduckgo", "mojeek", "marginalia", "startpage", "google", "bing", "custom"],
        "engine_details": SEARCH_ENGINES,
        "ui": {
            "menu_bar_enabled": bool(cfg.get("menu_bar_enabled", True)),
            "settings_ui_enabled": bool(cfg.get("settings_ui_enabled", True)),
            "address_bar_mid_dark_grey": bool(cfg.get("address_bar_mid_dark_grey", True)),
            "toolbar_2fa_button": bool(cfg.get("vault_2fa_toolbar_enabled", True)),
            "incognito_button": bool(cfg.get("incognito_button_enabled", True)),
            "address_bar_star_inside": bool(cfg.get("address_bar_star_inside", True)),
            "bookmarks_toolbar": bool(cfg.get("bookmarks_toolbar_enabled", True)),
            "bookmarks_toolbar_button": bool(cfg.get("bookmarks_toolbar_button_enabled", True)),
            "downloads_toolbar_button": bool(cfg.get("downloads_toolbar_button_enabled", True)),
            "tab_row_new_tab_button": bool(cfg.get("tab_row_new_tab_button_enabled", True)),
            "incognito_themed_icon": bool(cfg.get("incognito_themed_icon_enabled", True)),
            "vault_2fa_icon_button": bool(cfg.get("vault_2fa_icon_button_enabled", True)),
            "privacy_top_menu_enabled": bool(cfg.get("privacy_top_menu_enabled", False)),
            "vault_top_menu_enabled": bool(cfg.get("vault_top_menu_enabled", False)),
        },
        "aegis_bridge": {
            "safe_to_read_status": True,
            "search_policy_changes_require_user": True,
            "autonomous_search_policy_changes_allowed": False,
        },
        "notes": policy.get("notes", []),
    }
    if include_paths:
        payload["paths"] = {"search_policy": str(SEARCH_POLICY), "config": str(CONFIG)}
    return payload



def preferences_status_json(include_paths: bool = True) -> Dict[str, Any]:
    """Phase 4 user-ready settings/status schema for GUI and CLI checks."""
    cfg = load_config(False)
    search = search_policy_status_json(include_paths=False)
    dlg = download_guard_contract_status_json(include_raw=False)
    try:
        release = run_download_guard_json(["--show-release-dir"], timeout=8)
    except Exception as exc:
        release = {"ok": False, "error": str(exc)}
    payload: Dict[str, Any] = {
        "schema_version": 1,
        "app": APP_NAME,
        "program": PROGRAM,
        "package": PACKAGE,
        "version": VERSION,
        "status": "phase4_user_ready_preferences_gui",
        "generated_at": now_iso(),
        "local_only": True,
        "preferences_window_enabled": bool(cfg.get("preferences_window_enabled", True)),
        "sections": ["general", "search", "privacy", "security", "downloads", "download_guard", "site_data", "vault", "network", "about"],
        "gui_controls": {
            "general_home_url": True,
            "bookmarks_toolbar_toggle": True,
            "default_search_engine_combo": bool(cfg.get("search_engine_selector_gui_enabled", True)),
            "private_search_engine_combo": bool(cfg.get("search_engine_selector_gui_enabled", True)),
            "custom_search_url_entry": bool(cfg.get("custom_search_url_gui_enabled", True)),
            "javascript_profile_combo": True,
            "download_guard_enabled_toggle": bool(cfg.get("download_guard_settings_gui_enabled", True)),
            "download_guard_release_dir_entry": bool(cfg.get("download_guard_release_dir_gui_enabled", True)),
            "site_data_clear_buttons": bool(cfg.get("site_data_clear_gui_enabled", True)),
            "security_profile_summary": bool(cfg.get("security_profile_gui_enabled", True)),
            "network_settings_tab": bool(cfg.get("network_settings_gui_enabled", True)),
            "proxy_settings_controls": bool(cfg.get("proxy_settings_gui_enabled", True)),
            "vpn_settings_controls": bool(cfg.get("vpn_settings_gui_enabled", True)),
        },
        "search": {
            "default_search_engine": search.get("default_search_engine"),
            "private_search_engine": search.get("private_search_engine"),
            "custom_search_supported": True,
            "user_selectable_engines": search.get("user_selectable_engines", []),
        },
        "download_guard": {
            "enabled": bool(cfg.get("download_guard_backend_enabled", True)),
            "contract_compatible": bool(dlg.get("compatible", False)),
            "contract_schema": dlg.get("required_schema") or DOWNLOAD_GUARD_BROWSER_CONTRACT_SCHEMA,
            "release_dir": release.get("release_dir"),
            "release_dir_control_available": bool(cfg.get("download_guard_release_dir_gui_enabled", True)),
            "lightweight_polling_target": bool(cfg.get("download_guard_lightweight_polling_enabled", True)),
            "no_ui_thread_blocking_target": bool(cfg.get("download_guard_no_ui_thread_blocking_target", True)),
        },
        "site_data": {
            "manager_enabled": bool(cfg.get("site_data_manager_enabled", True)),
            "clear_cache": True,
            "clear_cookies_storage": True,
            "clear_session_state": True,
            "clear_security_events": True,
            "clear_bookmarks_optional": True,
            "clear_config_optional": True,
        },
        "security": {
            "javascript_profile": cfg.get("javascript_profile", "standard"),
            "security_profile_gui_enabled": bool(cfg.get("security_profile_gui_enabled", True)),
            "camera_default": cfg.get("permission_camera_default", "block"),
            "microphone_default": cfg.get("permission_microphone_default", "block"),
            "geolocation_default": cfg.get("permission_geolocation_default", "block"),
            "notifications_default": cfg.get("permission_notifications_default", "block"),
        },
        "network": network_settings_status_json(False),
        "v1_user_ready_notes": [
            "Phase 4 exposes user settings through the Browser GUI instead of forcing terminal-only helpers.",
            "Download Guard release directory can be set from Preferences when Download Guard is installed.",
            "Site data clearing is reachable from GUI and remains app-scoped/local.",
            "Download transfer performance target is normal network speed; guard operations must not block the GTK/WebKit UI loop.",
        ],
    }
    if include_paths:
        payload["paths"] = {
            "config": str(CONFIG),
            "search_policy": str(SEARCH_POLICY),
            "webkit_data": str(WEBKIT_DATA_DIR),
            "webkit_cache": str(WEBKIT_CACHE_DIR),
            "state": str(STATE_DIR),
        }
    return payload


def phase4_user_ready_test_json() -> Dict[str, Any]:
    prefs = preferences_status_json(include_paths=False)
    cfg = load_config(False)
    checks = {
        "preferences_window_enabled": prefs.get("preferences_window_enabled") is True,
        "required_sections_present": set(["general", "search", "privacy", "security", "downloads", "download_guard", "site_data", "vault", "network", "about"]).issubset(set(prefs.get("sections", []))),
        "search_gui_controls": prefs.get("gui_controls", {}).get("default_search_engine_combo") is True and prefs.get("gui_controls", {}).get("custom_search_url_entry") is True,
        "download_guard_gui_controls": prefs.get("gui_controls", {}).get("download_guard_enabled_toggle") is True and prefs.get("gui_controls", {}).get("download_guard_release_dir_entry") is True,
        "site_data_gui_controls": prefs.get("gui_controls", {}).get("site_data_clear_buttons") is True,
        "security_gui_controls": prefs.get("gui_controls", {}).get("security_profile_summary") is True,
        "performance_target_recorded": bool(cfg.get("download_guard_no_ui_thread_blocking_target", True)) and bool(cfg.get("browser_first_download_flow_enabled", True)) and bool(cfg.get("download_guard_no_active_transfer_cli_calls", True)),
    }
    return {
        "ok": all(checks.values()),
        "app": APP_NAME,
        "version": VERSION,
        "schema_version": 1,
        "status": "phase4_user_ready_test",
        "checks": checks,
        "preferences": prefs,
        "generated_at": now_iso(),
    }

def vault_2fa_toolbar_status_json(include_paths: bool = True) -> Dict[str, Any]:
    cfg = load_config(False)
    bridge = vault_bridge_status_json(include_paths=False)
    payload: Dict[str, Any] = {
        "schema_version": 1,
        "app": APP_NAME,
        "program": PROGRAM,
        "package": PACKAGE,
        "version": VERSION,
        "status": "toolbar_icon_vault_2fa_popup_consumer",
        "generated_at": now_iso(),
        "local_only": True,
        "toolbar_button_present": bool(cfg.get("vault_2fa_toolbar_enabled", True)),
        "vault_bridge_enabled": bool(cfg.get("vault_bridge_enabled", True)),
        "vault_2fa_bridge_enabled": bool(cfg.get("vault_2fa_bridge_enabled", True)),
        "mode": cfg.get("vault_2fa_toolbar_mode", "direct_vault_browser_origin_popup"),
        "source_of_truth": "Sentinel Password Vault",
        "browser_stores_totp_secrets": False,
        "browser_stores_totp_codes": False,
        "browser_stores_passwords": False,
        "browser_generates_totp_codes": False,
        "browser_role": "toolbar icon / direct browser-origin launcher/status surface only",
        "vault_binary_available": bridge.get("vault_binary", {}).get("available", False),
        "allowed_now": {
            "launch_restricted_vault_2fa_popup": True,
            "launch_full_vault_by_default": False,
            "top_menu_open_vault_connection": False,
            "show_bridge_status": True,
            "store_account_hint_only": True,
            "read_vault_2fa_secrets": False,
            "generate_totp_codes": False,
            "autofill_totp_codes_without_vault_approval": False,
            "copy_totp_without_user_approval": False,
        },
        "bridge_requirements": [
            "Sentinel Password Vault owns passwords, TOTP secrets, and recovery codes.",
            "Browser toolbar button calls sentinel-password-vault --browser-2fa-popup --browser-origin CURRENT_URL and never opens the full Vault by default.",
            "Requires Sentinel Password Vault 0.9.9.1+ popup receiver for the mini-popup flow.",
            "Future Vault receiver must unlock, domain-match, verify bridge halves, and ask user approval before code display/copy/fill.",
            "No browser-side TOTP secret export, hidden scraping, automatic capture, telemetry, or cloud sync.",
        ],
        "vault_bridge": bridge,
    }
    if include_paths:
        payload["paths"] = {"config": str(CONFIG), "vault_bridge_policy": str(VAULT_BRIDGE_POLICY), "security_events": str(SECURITY_EVENTS)}
    return payload


def default_javascript_policy() -> Dict[str, Any]:
    return {
        "schema_version": 1,
        "program": PROGRAM,
        "app": APP_NAME,
        "policy_name": "sentinel-browser-javascript-policy",
        "local_only": True,
        "default_profile": "standard",
        "profiles": {
            "standard": {
                "javascript_enabled": True,
                "description": "Compatibility-first hardened mode. JavaScript stays enabled for modern sites while Sentinel content/download/permission/fingerprint protections remain active.",
                "file_urls": "block",
                "data_urls": "block",
                "local_pages": "block",
                "third_party_script_policy": "monitor_and_classify_foundation",
            },
            "shield": {
                "javascript_enabled": True,
                "description": "Stronger general-use mode. JavaScript remains enabled, but local/file/data contexts and known hostile script patterns are blocked or warned where Sentinel Browser can enforce them.",
                "file_urls": "block",
                "data_urls": "block",
                "local_pages": "block",
                "third_party_script_policy": "stricter_classify_and_block_foundation",
            },
            "lockdown": {
                "javascript_enabled": False,
                "description": "Maximum-safety mode. JavaScript is disabled by default unless a future explicit per-site allow policy permits it.",
                "file_urls": "block",
                "data_urls": "block",
                "local_pages": "block",
                "third_party_script_policy": "block_by_default",
            },
        },
        "per_site": {
            "allow": [],
            "block": [],
            "temporary_allow": [],
        },
        "blocked_contexts": {
            "file_urls": True,
            "data_urls": True,
            "about_blank": False,
            "external_protocols": True,
        },
        "engine_gate": {
            "webkitgtk_required": True,
            "javascriptcore_required": True,
            "engine_version_report_required": True,
            "v1_blocks_if_engine_unknown": True,
        },
        "notes": [
            "JavaScript is a required compatibility feature for many modern sites, including ChatGPT.",
            "Sentinel Browser hardens JavaScript through profiles and policy gates rather than disabling it globally in Standard mode.",
            "Per-site JavaScript policy is local-only and user-controlled.",
            "Status JSON distinguishes enforced, attempted, and policy-only protections.",
        ],
    }


def load_javascript_policy() -> Dict[str, Any]:
    raw = load_json(JAVASCRIPT_POLICY, {})
    base = default_javascript_policy()
    if isinstance(raw, dict):
        for key, value in raw.items():
            if key not in {"schema_version", "program", "app", "local_only"}:
                base[key] = value
        if isinstance(raw.get("per_site"), dict):
            merged = default_javascript_policy()["per_site"]
            merged.update(raw.get("per_site", {}))
            base["per_site"] = merged
    base["schema_version"] = 1
    base["program"] = PROGRAM
    base["app"] = APP_NAME
    base["local_only"] = True
    return base


def write_javascript_policy() -> None:
    if not JAVASCRIPT_POLICY.exists():
        save_json(JAVASCRIPT_POLICY, default_javascript_policy())


def _host_from_uri(uri: str) -> str:
    try:
        return (urlparse(uri or "").hostname or "").lower().strip(".")
    except Exception:
        return ""


def _sanitize_host(host: str) -> str:
    host = (host or "").strip().lower()
    if "://" in host:
        host = _host_from_uri(host)
    host = host.split("/")[0].split(":")[0].strip(".")
    return host


def _looks_like_login_uri(uri: str) -> bool:
    parsed = urlparse(uri or "")
    path = (parsed.path or "").lower()
    query = (parsed.query or "").lower()
    haystack = path + "?" + query
    tokens = ("login", "log-in", "signin", "sign-in", "auth", "account", "session", "2fa", "mfa")
    return parsed.scheme in {"http", "https"} and any(t in haystack for t in tokens)


def default_vault_bridge_policy() -> Dict[str, Any]:
    return {
        "schema_version": 1,
        "program": PROGRAM,
        "app": APP_NAME,
        "policy_name": "sentinel-browser-vault-bridge-policy",
        "local_only": True,
        "bridge_mode": "restricted_receiver_launcher_only",
        "vault_provider": "Sentinel Password Vault",
        "vault_program_id": 113,
        "browser_program_id": PROGRAM,
        "manual_toolbar_launch_enabled": True,
        "restricted_2fa_popup_required": True,
        "full_vault_fallback_enabled": False,
        "login_prompt_enabled": True,
        "account_hints_enabled": True,
        "pairing_required_for_browser_assisted_parse": True,
        "browser_side_pair_half_enabled": True,
        "vault_side_pair_half_required": True,
        "if_pair_halves_do_not_verify": "vault_refuses_browser_assisted_parse_fill_or_totp",
        "browser_may_store": [
            "domain",
            "optional_account_label",
            "optional_username_hint",
            "browser_pair_half",
            "user_site_preference"
        ],
        "browser_must_never_store": [
            "passwords",
            "totp_secrets",
            "totp_codes",
            "recovery_codes",
            "vault_master_key",
            "record_encryption_key",
            "plaintext_credential_database"
        ],
        "password_flow": {
            "default_prompt": "Use Vault / Enter Manually / Never for this site",
            "autofill_requires_user_click": True,
            "vault_unlock_required": True,
            "vault_approval_required": True,
            "auto_submit_login_default": False,
            "browser_clears_password_from_memory_after_fill": True,
            "implemented_now": "policy_and_manual_launcher_foundation_only"
        },
        "totp_flow": {
            "toolbar_button": "manual_open_vault_2fa",
            "browser_displays_or_generates_codes": False,
            "vault_popup_owns_code_display": True,
            "implemented_now": "restricted_vault_2fa_popup_launcher_when_vault_receiver_available"
        },
        "audit_policy": "metadata only; no plaintext password, TOTP secret, or TOTP code logging",
        "notes": [
            "Sentinel Browser remains a web-facing shell and should not become the credential authority.",
            "Sentinel Password Vault owns password and TOTP secrets.",
            "Browser requests are manual and event-triggered; no background vault polling."
        ]
    }


def load_vault_bridge_policy() -> Dict[str, Any]:
    raw = load_json(VAULT_BRIDGE_POLICY, {})
    base = default_vault_bridge_policy()
    if isinstance(raw, dict):
        for key, value in raw.items():
            if key not in {"schema_version", "program", "app", "local_only"}:
                base[key] = value
    base["schema_version"] = 1
    base["program"] = PROGRAM
    base["app"] = APP_NAME
    base["local_only"] = True
    return base


def write_vault_bridge_policy() -> None:
    if not VAULT_BRIDGE_POLICY.exists():
        save_json(VAULT_BRIDGE_POLICY, default_vault_bridge_policy())


def load_vault_account_hints() -> Dict[str, Any]:
    raw = load_json(VAULT_ACCOUNT_HINTS, {})
    if not isinstance(raw, dict):
        raw = {}
    records = raw.get("records", [])
    if not isinstance(records, list):
        records = []
    return {
        "schema_version": 1,
        "program": PROGRAM,
        "app": APP_NAME,
        "local_only": True,
        "secret_values_present": False,
        "records": [r for r in records if isinstance(r, dict)],
    }


def write_vault_account_hints() -> None:
    if not VAULT_ACCOUNT_HINTS.exists():
        save_json(VAULT_ACCOUNT_HINTS, load_vault_account_hints())

def default_vault_login_policy() -> Dict[str, Any]:
    return {
        "schema_version": 1,
        "program": PROGRAM,
        "app": APP_NAME,
        "local_only": True,
        "prompt_enabled": True,
        "auto_submit_enabled": False,
        "store_passwords_in_browser": False,
        "store_totp_in_browser": False,
        "show_prompt_for_login_forms": True,
        "never_prompt_sites": [],
        "allowed_prompt_sites": [],
        "notes": [
            "Browser-side policy only. Sentinel Password Vault remains the source of truth for passwords and 2FA.",
            "Never-prompt sites hide the small browser prompt, but do not affect normal manual entry.",
            "No password, TOTP secret, recovery code, or Vault key material is stored here.",
        ],
    }


def load_vault_login_policy() -> Dict[str, Any]:
    raw = load_json(VAULT_LOGIN_POLICY, {})
    base = default_vault_login_policy()
    if isinstance(raw, dict):
        for key, value in raw.items():
            if key not in {"schema_version", "program", "app", "local_only", "store_passwords_in_browser", "store_totp_in_browser"}:
                base[key] = value
    base["schema_version"] = 1
    base["program"] = PROGRAM
    base["app"] = APP_NAME
    base["local_only"] = True
    base["store_passwords_in_browser"] = False
    base["store_totp_in_browser"] = False
    base["auto_submit_enabled"] = False
    for key in ("never_prompt_sites", "allowed_prompt_sites"):
        if not isinstance(base.get(key), list):
            base[key] = []
        base[key] = sorted({_sanitize_host(str(x)) for x in base[key] if _sanitize_host(str(x))})
    return base


def write_vault_login_policy() -> None:
    if not VAULT_LOGIN_POLICY.exists():
        save_json(VAULT_LOGIN_POLICY, load_vault_login_policy())


def update_vault_login_site_policy(domain: str, action: str) -> Dict[str, Any]:
    host = _sanitize_host(domain)
    if not host:
        raise ValueError("A valid domain is required")
    policy = load_vault_login_policy()
    never = set(policy.get("never_prompt_sites", []))
    allowed = set(policy.get("allowed_prompt_sites", []))
    if action == "never":
        never.add(host)
        allowed.discard(host)
        event = "vault_login_prompt_never_site_added"
    elif action == "allow":
        allowed.add(host)
        never.discard(host)
        event = "vault_login_prompt_allowed_site_added"
    elif action == "clear":
        never.discard(host)
        allowed.discard(host)
        event = "vault_login_prompt_site_policy_cleared"
    else:
        raise ValueError("action must be never, allow, or clear")
    policy["never_prompt_sites"] = sorted(never)
    policy["allowed_prompt_sites"] = sorted(allowed)
    save_json(VAULT_LOGIN_POLICY, policy)
    log_security_event(event, {"domain": host, "secret_values_present": False})
    return {"domain": host, "action": action, "never_prompt_sites": policy["never_prompt_sites"], "allowed_prompt_sites": policy["allowed_prompt_sites"]}


def vault_login_prompt_status_json(include_paths: bool = True) -> Dict[str, Any]:
    cfg = load_config(False)
    policy = load_vault_login_policy()
    hints = vault_account_hints_status_json(False)
    command = str(cfg.get("vault_bridge_command", "sentinel-password-vault"))
    payload: Dict[str, Any] = {
        "schema_version": 1,
        "program": PROGRAM,
        "app": APP_NAME,
        "package": PACKAGE,
        "version": VERSION,
        "status": "vault_login_prompt_browser_only_consumer",
        "local_first": True,
        "prompt_enabled": bool(cfg.get("vault_login_prompt_enabled", True)),
        "prompt_bar_enabled": bool(cfg.get("vault_login_prompt_bar_enabled", True)),
        "detection_enabled": bool(cfg.get("vault_login_prompt_detection_enabled", True)),
        "account_hints_only": True,
        "browser_stores_passwords": False,
        "browser_stores_totp_secrets": False,
        "browser_auto_submit_enabled": False,
        "strict_password_receiver_guard": cfg.get("vault_login_strict_password_receiver_guard", True),
        "user_choices": ["Use Vault", "Save to Vault", "Enter Manually", "Never for this site"],
        "vault_command": command,
        "password_receiver_contract": f"{command} --browser-password-popup --browser-origin $CURRENT_URL",
        "password_receiver_status_contract": f"{command} --browser-password-popup-status",
        "policy": policy,
        "account_hints": hints,
        "notes": [
            "This is a browser-side prompt/consumer layer only.",
            "The browser does not store or parse passwords, TOTP secrets, TOTP codes, recovery codes, or Vault key material.",
            "The browser asks the Vault only after explicit user click on Use Vault or Save to Vault.",
            "Use Vault is guarded: browser must see a verified restricted password receiver before launching anything.",
            "Auto-submit remains off by default; user remains final authority.",
        ],
    }
    if include_paths:
        payload["paths"] = {"vault_login_policy": str(VAULT_LOGIN_POLICY), "account_hints": str(VAULT_ACCOUNT_HINTS), "security_events": str(SECURITY_EVENTS)}
    return payload


def add_vault_account_hint(domain: str, account_label: str = "", username_hint: str = "") -> Dict[str, Any]:
    host = _sanitize_host(domain)
    if not host:
        raise ValueError("A domain/host is required for a Vault account hint")
    data = load_vault_account_hints()
    records = data.get("records", [])
    # replace existing same domain+label, preserving no secrets
    label = (account_label or username_hint or host).strip()[:120]
    username = (username_hint or "").strip()[:160]
    records = [r for r in records if not (_sanitize_host(str(r.get("domain", ""))) == host and str(r.get("account_label", "")) == label)]
    pair_half = "sbph_" + secrets.token_urlsafe(24)
    rec = {
        "id": "hint_" + secrets.token_hex(8),
        "domain": host,
        "account_label": label,
        "username_hint": username,
        "browser_pair_half": pair_half,
        "vault_pair_status": "pending_vault_pair",
        "created_at": now_iso(),
        "secret_values_present": False,
        "notes": "Browser-side hint only. No password, TOTP secret, TOTP code, or recovery code is stored here.",
    }
    records.append(rec)
    data["records"] = records
    save_json(VAULT_ACCOUNT_HINTS, data)
    log_security_event("vault_account_hint_added", {"domain": host, "account_label": label, "secret_values_present": False})
    return rec


def revoke_vault_account_hint(domain: str) -> int:
    host = _sanitize_host(domain)
    data = load_vault_account_hints()
    before = len(data.get("records", []))
    data["records"] = [r for r in data.get("records", []) if _sanitize_host(str(r.get("domain", ""))) != host]
    removed = before - len(data.get("records", []))
    save_json(VAULT_ACCOUNT_HINTS, data)
    log_security_event("vault_account_hint_revoked", {"domain": host, "removed": removed})
    return removed


def vault_account_hints_status_json(include_paths: bool = True) -> Dict[str, Any]:
    data = load_vault_account_hints()
    records = data.get("records", [])
    payload: Dict[str, Any] = {
        "schema_version": 1,
        "app": APP_NAME,
        "program": PROGRAM,
        "package": PACKAGE,
        "version": VERSION,
        "status": "account_hints_only_no_browser_secrets",
        "generated_at": now_iso(),
        "local_only": True,
        "records_count": len(records),
        "browser_stores_passwords": False,
        "browser_stores_totp_secrets": False,
        "browser_stores_totp_codes": False,
        "browser_pair_half_present_per_hint": all(bool(r.get("browser_pair_half")) for r in records) if records else True,
        "vault_pair_required_before_parse": True,
        "records": [
            {
                "domain": r.get("domain", ""),
                "account_label": r.get("account_label", ""),
                "username_hint_present": bool(r.get("username_hint")),
                "browser_pair_half_present": bool(r.get("browser_pair_half")),
                "vault_pair_status": r.get("vault_pair_status", "unknown"),
                "secret_values_present": False,
            }
            for r in records
        ],
    }
    if include_paths:
        payload["paths"] = {"account_hints": str(VAULT_ACCOUNT_HINTS)}
    return payload


def vault_binary_status() -> Dict[str, Any]:
    cfg = load_config(False)
    name = str(cfg.get("vault_bridge_command", "sentinel-password-vault") or "sentinel-password-vault")
    path = shutil.which(name)
    status: Dict[str, Any] = {"command": name, "path": path or "", "available": bool(path)}
    if path:
        try:
            out = subprocess.run([path, "--browser-bridge-status"], text=True, capture_output=True, timeout=4)
            status["browser_bridge_status_exit"] = out.returncode
            if out.stdout.strip().startswith("{"):
                status["browser_bridge_status"] = json.loads(out.stdout)
            elif out.stdout.strip():
                status["browser_bridge_status_text"] = out.stdout.strip()[:500]
            if out.stderr.strip():
                status["stderr"] = out.stderr.strip()[:500]
        except Exception as exc:
            status["browser_bridge_status_error"] = str(exc)
    return status


def vault_bridge_status_json(include_paths: bool = True) -> Dict[str, Any]:
    cfg = load_config(False)
    policy = load_vault_bridge_policy()
    hints = vault_account_hints_status_json(include_paths=False)
    binary = vault_binary_status()
    payload: Dict[str, Any] = {
        "schema_version": 1,
        "app": APP_NAME,
        "program": PROGRAM,
        "package": PACKAGE,
        "version": VERSION,
        "status": "manual_vault_bridge_no_browser_secret_storage",
        "generated_at": now_iso(),
        "local_only": True,
        "manual_launcher_enabled": bool(cfg.get("vault_bridge_manual_launcher_enabled", True)),
        "login_prompt_enabled": bool(cfg.get("vault_login_prompt_enabled", True)),
        "vault_provider": "Sentinel Password Vault",
        "vault_program_id": 113,
        "vault_binary": binary,
        "account_hints": hints,
        "pairing_model": {
            "browser_side_pair_half": bool(cfg.get("vault_pairing_half_enabled", True)),
            "vault_side_pair_half_required": True,
            "actual_vault_encryption_key_split_with_browser": False,
            "bridge_pairing_key_split_only": True,
            "if_halves_do_not_verify": "Vault refuses browser-assisted parse/fill/TOTP for that account",
        },
        "browser_never_stores": ["passwords", "TOTP secrets", "TOTP codes", "recovery codes", "vault master key", "record encryption keys"],
        "allowed_browser_role": ["show Use Vault prompt", "launch Vault manually", "send current browser origin/current URL context to Vault receiver on explicit user click", "store optional account hint and browser pair half"],
        "not_allowed_browser_role": ["store password database", "generate TOTP", "read Vault secrets", "background poll Vault", "auto-submit login by default"],
        "password_flow": policy.get("password_flow", {}),
        "totp_flow": policy.get("totp_flow", {}),
        "performance": {
            "background_vault_polling": False,
            "event_triggered_only": True,
            "normal_browsing_impact": "negligible",
        },
    }
    if include_paths:
        payload["paths"] = {"vault_bridge_policy": str(VAULT_BRIDGE_POLICY), "account_hints": str(VAULT_ACCOUNT_HINTS), "security_events": str(SECURITY_EVENTS)}
    return payload


def launch_vault_bridge(browser_origin: str = "", mode: str = "2fa") -> Dict[str, Any]:
    cfg = load_config(False)
    cmd_name = str(cfg.get("vault_bridge_command", "sentinel-password-vault") or "sentinel-password-vault")
    status_cmd = shutil.which(cmd_name)
    origin = str(browser_origin or "").strip()
    host = _host_from_uri(origin) or _sanitize_host(origin)
    result: Dict[str, Any] = {
        "ok": False,
        "mode": mode,
        "domain": host,
        "browser_origin": origin,
        "command": cmd_name,
        "path": status_cmd or "",
        "browser_secret_values_present": False,
        "full_vault_fallback_enabled": False,
        "top_menu_full_vault_connection": False,
        "launch_contract": 'sentinel-password-vault --browser-password-popup --browser-origin "$CURRENT_URL"' if mode == "password" else 'sentinel-password-vault --browser-2fa-popup --browser-origin "$CURRENT_URL"',
        "note": "Browser launches only a verified restricted Vault-owned receiver using the current browser URL as --browser-origin. It does not open the full Vault, receive credentials, or store TOTP codes.",
    }
    if not status_cmd:
        result["error"] = "Sentinel Password Vault command not found"
        log_security_event("vault_bridge_launch_unavailable", {"domain": host, "browser_origin": origin, "mode": mode})
        return result
    if mode == "password":
        # Browser-side consumer only: ask the Vault whether it exposes the password receiver.
        # Never open the full Vault and never accept/store secrets in browser memory.
        try:
            status_arg = "--browser-password-popup-status"
            launch_arg = "--browser-password-popup"
            probe = subprocess.run([status_cmd, status_arg], text=True, capture_output=True, timeout=4)
            if probe.returncode != 0:
                result["error"] = "Sentinel Password Vault password receiver is not available yet. Enter manually, or install/use a Vault build that exposes --browser-password-popup-status and --browser-password-popup."
                result["probe_stderr"] = (probe.stderr or "")[:300]
                result["implemented_now"] = "browser_login_prompt_consumer_waiting_for_vault_receiver"
                log_security_event("vault_password_receiver_unavailable", {"domain": host, "browser_origin": origin, "mode": mode})
                return result
            status = json.loads(probe.stdout or "{}")
            password_receiver_markers = [
                status.get("password_receiver") is True,
                status.get("password_popup") is True,
                status.get("receiver_kind") in ("password", "password_popup", "restricted_password_popup"),
                status.get("bridge_stage") in ("password_receiver_ready", "password_popup_ready", "restricted_password_popup_ready"),
            ]
            receiver_ok = (
                status.get("ok") is True
                and status.get("opens_full_vault_by_default") is False
                and status.get("restricted_popup") is True
                and status.get("browser_origin_supported") is True
                and any(password_receiver_markers)
            )
            if not receiver_ok:
                result["error"] = "Sentinel Password Vault did not advertise a verified restricted password receiver. Use Vault will stay blocked so it cannot open the full Vault or trigger an external browser/page."
                result["receiver_status"] = status
                result["implemented_now"] = "strict_password_receiver_guard_blocked_launch"
                log_security_event("vault_password_receiver_status_rejected_strict", {"domain": host, "browser_origin": origin, "mode": mode, "receiver_status": status})
                return result
            launch_args = [status_cmd, launch_arg, "--browser-origin", origin]
            subprocess.Popen(launch_args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
            result["ok"] = True
            result["launched"] = True
            result["launch_args_kind"] = "main_command_browser_origin_password_receiver"
            result["launch_args_public"] = [cmd_name, launch_arg, "--browser-origin", "$CURRENT_URL"]
            result["implemented_now"] = "restricted_vault_password_popup_if_receiver_available"
            result["receiver_status"] = {"version": status.get("version"), "bridge_stage": status.get("bridge_stage"), "opens_full_vault_by_default": status.get("opens_full_vault_by_default"), "restricted_popup": status.get("restricted_popup"), "browser_origin_supported": status.get("browser_origin_supported")}
            log_security_event("vault_password_popup_launch", {"domain": host, "browser_origin_present": bool(origin), "mode": mode, "secret_values_present": False})
            return result
        except Exception as exc:
            result["error"] = str(exc)
            log_security_event("vault_password_bridge_launch_failed", {"domain": host, "browser_origin": origin, "mode": mode, "error": str(exc)})
            return result
    if mode != "2fa":
        result["error"] = "Unsupported Vault bridge mode."
        log_security_event("vault_bridge_mode_unsupported", {"domain": host, "browser_origin": origin, "mode": mode})
        return result
    # Verify Vault mini-popup receiver before launch. Never open the full Vault as fallback.
    try:
        probe = subprocess.run([status_cmd, "--browser-2fa-popup-status"], text=True, capture_output=True, timeout=4)
        if probe.returncode != 0:
            result["error"] = "Sentinel Password Vault 2FA mini-popup receiver is not available. Install/use Sentinel Password Vault 0.9.9.1 or later with --browser-2fa-popup-status and --browser-2fa-popup."
            result["probe_stderr"] = (probe.stderr or "")[:300]
            log_security_event("vault_2fa_receiver_unavailable", {"domain": host, "browser_origin": origin, "mode": mode})
            return result
        status = json.loads(probe.stdout or "{}")
        if not status.get("ok") or status.get("opens_full_vault_by_default") is not False or status.get("restricted_popup") is not True:
            result["error"] = "Vault receiver status is not acceptable for restricted 2FA popup launch."
            result["receiver_status"] = status
            log_security_event("vault_2fa_receiver_status_rejected", {"domain": host, "browser_origin": origin, "mode": mode})
            return result
        launch_args = [status_cmd, "--browser-2fa-popup", "--browser-origin", origin]
        subprocess.Popen(launch_args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
        result["ok"] = True
        result["launched"] = True
        result["launch_args_kind"] = "main_command_browser_origin_receiver"
        result["launch_args_public"] = [cmd_name, "--browser-2fa-popup", "--browser-origin", "$CURRENT_URL"]
        result["implemented_now"] = "direct_browser_origin_restricted_vault_2fa_popup"
        result["receiver_status"] = {"version": status.get("version"), "bridge_stage": status.get("bridge_stage"), "opens_full_vault_by_default": status.get("opens_full_vault_by_default"), "restricted_popup": status.get("restricted_popup"), "browser_origin_supported": status.get("browser_origin_supported")}
        log_security_event("vault_2fa_mini_popup_launch", {"domain": host, "browser_origin_present": bool(origin), "mode": mode, "secret_values_present": False, "helper_used": False})
    except Exception as exc:
        result["error"] = str(exc)
        log_security_event("vault_bridge_launch_failed", {"domain": host, "browser_origin": origin, "mode": mode, "error": str(exc)})
    return result


def _host_in_list(host: str, items: Any) -> bool:
    if not isinstance(items, list):
        return False
    host = (host or "").lower().strip(".")
    for raw in items:
        item = str(raw).lower().strip().strip(".")
        if item and (host == item or host.endswith("." + item)):
            return True
    return False


def effective_javascript_policy(uri: str, cfg: Optional[Dict[str, Any]] = None, policy: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    cfg = cfg or DEFAULT_CONFIG
    policy = policy or default_javascript_policy()
    profile = str(cfg.get("javascript_profile", policy.get("default_profile", "standard"))).lower().strip()
    if profile not in {"standard", "shield", "lockdown"}:
        profile = "standard"
    parsed = urlparse(uri or "")
    scheme = (parsed.scheme or "about").lower()
    host = _host_from_uri(uri)
    per_site = policy.get("per_site", {}) if isinstance(policy.get("per_site", {}), dict) else {}

    if not bool(cfg.get("javascript_policy_enabled", True)):
        return {"enabled": bool(cfg.get("enable_javascript", True)), "profile": profile, "reason": "javascript_policy_disabled", "scope": "global_config"}
    if _host_in_list(host, per_site.get("block", [])):
        return {"enabled": False, "profile": profile, "reason": "site_block_policy", "scope": "per_site", "host": host}
    if _host_in_list(host, per_site.get("temporary_allow", [])):
        return {"enabled": True, "profile": profile, "reason": "temporary_site_allow", "scope": "per_site", "host": host}
    if _host_in_list(host, per_site.get("allow", [])):
        return {"enabled": True, "profile": profile, "reason": "site_allow_policy", "scope": "per_site", "host": host}

    if scheme == "file" and not bool(cfg.get("javascript_file_urls_enabled", False)):
        return {"enabled": False, "profile": profile, "reason": "file_url_javascript_blocked", "scope": "scheme", "scheme": scheme}
    if scheme == "data" and not bool(cfg.get("javascript_data_urls_enabled", False)):
        return {"enabled": False, "profile": profile, "reason": "data_url_javascript_blocked", "scope": "scheme", "scheme": scheme}
    if scheme in {"about"} and not bool(cfg.get("javascript_local_pages_enabled", False)):
        return {"enabled": False, "profile": profile, "reason": "local_page_javascript_blocked", "scope": "scheme", "scheme": scheme}
    if is_external_protocol(uri):
        return {"enabled": False, "profile": profile, "reason": "external_protocol_javascript_blocked", "scope": "scheme", "scheme": scheme}
    if profile == "lockdown":
        return {"enabled": False, "profile": profile, "reason": "lockdown_profile_blocks_javascript", "scope": "profile"}
    if profile == "shield":
        return {"enabled": bool(cfg.get("enable_javascript", True)), "profile": profile, "reason": "shield_profile_javascript_enabled_with_restrictions", "scope": "profile"}
    return {"enabled": bool(cfg.get("enable_javascript", True)), "profile": profile, "reason": "standard_profile_javascript_enabled", "scope": "profile"}


def javascript_status_json(include_paths: bool = True) -> Dict[str, Any]:
    cfg = load_config(False)
    policy = load_javascript_policy()
    engine = webkit_engine_security_status_json(include_paths=False) if 'webkit_engine_security_status_json' in globals() else {}
    payload: Dict[str, Any] = {
        "schema_version": 1,
        "app": APP_NAME,
        "program": PROGRAM,
        "package": PACKAGE,
        "version": VERSION,
        "status": "javascript_engine_security_gate",
        "generated_at": now_iso(),
        "local_only": True,
        "javascript": {
            "global_enabled": bool(cfg.get("enable_javascript", True)),
            "profile": cfg.get("javascript_profile", "standard"),
            "available_profiles": ["standard", "shield", "lockdown"],
            "policy_enabled": bool(cfg.get("javascript_policy_enabled", True)),
            "per_site_policy_enabled": bool(cfg.get("javascript_per_site_policy", True)),
            "temporary_allow_enabled": bool(cfg.get("javascript_temporary_allow_enabled", True)),
            "file_urls_enabled": bool(cfg.get("javascript_file_urls_enabled", False)),
            "data_urls_enabled": bool(cfg.get("javascript_data_urls_enabled", False)),
            "local_pages_enabled": bool(cfg.get("javascript_local_pages_enabled", False)),
            "status_honesty": cfg.get("javascript_status_honesty", "enforced_attempted_policy_only_separated"),
        },
        "engine": {
            "webkit_api": engine.get("webkit_api", "unknown"),
            "webkit_version": engine.get("webkit_version", "unknown"),
            "javascriptcore_package": engine.get("package_versions", {}).get("libjavascriptcoregtk-4.1-0", "unknown"),
            "webkit_package": engine.get("package_versions", {}).get("libwebkit2gtk-4.1-0", "unknown"),
            "engine_update_source": "OS package manager / Debian security updates",
        },
        "policy": policy,
        "effective_examples": {
            "https_example": effective_javascript_policy("https://example.com", cfg, policy),
            "file_example": effective_javascript_policy("file:///tmp/test.html", cfg, policy),
            "data_example": effective_javascript_policy("data:text/html,<script>alert(1)</script>", cfg, policy),
        },
        "aegis_bridge": {
            "safe_to_read_status": True,
            "javascript_policy_changes_require_user": True,
            "autonomous_script_enable_allowed": False,
        },
        "v1_gate": {
            "javascript_status_required": True,
            "engine_version_required": True,
            "lockdown_profile_available_required": True,
            "per_site_policy_foundation_required": True,
        },
        "limitations": [
            "Standard mode keeps JavaScript enabled for modern site compatibility.",
            "Per-site JavaScript policy is foundation-level and controlled locally.",
            "Engine exploit resistance still depends on timely WebKitGTK/JavaScriptCore security updates.",
        ],
    }
    if include_paths:
        payload["paths"] = {"javascript_policy": str(JAVASCRIPT_POLICY), "config": str(CONFIG), "security_events": str(SECURITY_EVENTS)}
    return payload


def set_javascript_profile(profile: str) -> str:
    profile = str(profile or "").lower().strip()
    if profile not in {"standard", "shield", "lockdown"}:
        raise ValueError("JavaScript profile must be one of: standard, shield, lockdown")
    cfg = load_config(False)
    cfg["javascript_profile"] = profile
    cfg["enable_javascript"] = profile != "lockdown"
    save_config(cfg)
    write_javascript_policy()
    log_security_event("javascript_profile_set", {"profile": profile})
    return profile


def update_javascript_site_policy(host: str, action: str) -> Dict[str, Any]:
    host = str(host or "").lower().strip().strip(".")
    if not host or "/" in host or " " in host:
        raise ValueError("Use a bare host name, for example: example.com")
    if action not in {"allow", "block", "temporary_allow"}:
        raise ValueError("action must be allow, block, or temporary_allow")
    policy = load_javascript_policy()
    per_site = policy.setdefault("per_site", {"allow": [], "block": [], "temporary_allow": []})
    for key in ("allow", "block", "temporary_allow"):
        items = [str(x).lower().strip().strip(".") for x in per_site.get(key, []) if str(x).strip()]
        items = [x for x in items if x != host]
        per_site[key] = sorted(set(items))
    per_site[action] = sorted(set(list(per_site.get(action, [])) + [host]))
    save_json(JAVASCRIPT_POLICY, policy)
    log_security_event("javascript_site_policy_updated", {"host": host, "action": action})
    return policy

def default_content_policy() -> Dict[str, Any]:
    return {
        "schema_version": 1,
        "program": PROGRAM,
        "app": APP_NAME,
        "policy_name": "sentinel-browser-content-policy",
        "local_only": True,
        "remote_subscriptions_enabled": False,
        "content_blocking_enabled": True,
        "block_trackers": True,
        "block_known_miners": True,
        "block_fingerprinting_scripts": True,
        "fingerprint_defense_enabled": True,
        "webgl_disabled_by_default": True,
        "canvas_fingerprinting_restricted": True,
        "audio_fingerprinting_restricted": True,
        "font_fingerprinting_policy": "restricted_policy_foundation",
        "domain_block_categories": {
            "trackers": sorted(TRACKER_DOMAIN_PATTERNS),
            "miners": sorted(MINER_DOMAIN_PATTERNS),
            "fingerprinting": sorted(FINGERPRINT_DOMAIN_PATTERNS),
        },
        "script_pattern_categories": {
            "miners": sorted(MINER_SCRIPT_PATTERNS),
            "fingerprinting": sorted(FINGERPRINT_SCRIPT_PATTERNS),
        },
        "allowlist": [],
        "blocklist": [],
        "notes": [
            "Local policy only; no remote blocklist subscription is enabled by default.",
            "Known miner/tracker/fingerprinting hosts and script-pattern navigation are blocked where Sentinel Browser can classify the request.",
            "WebKitGTK subresource/content-filter support varies by engine version; status JSON separates enforced, attempted, and policy-only controls.",
            "No page content is sent to AEGIS or a cloud service for scanning.",
        ],
    }


def load_content_policy() -> Dict[str, Any]:
    raw = load_json(CONTENT_POLICY, {})
    base = default_content_policy()
    if isinstance(raw, dict):
        base.update(raw)
    base["schema_version"] = 1
    base["program"] = PROGRAM
    base["app"] = APP_NAME
    base["local_only"] = True
    base["remote_subscriptions_enabled"] = False
    return base


def write_content_policy() -> None:
    if not CONTENT_POLICY.exists():
        save_json(CONTENT_POLICY, default_content_policy())
    if not CONTENT_BLOCKLIST.exists():
        save_json(CONTENT_BLOCKLIST, {"schema_version": 1, "items": [], "notes": ["Local user blocklist."]})
    if not CONTENT_ALLOWLIST.exists():
        save_json(CONTENT_ALLOWLIST, {"schema_version": 1, "items": [], "notes": ["Local user allowlist."]})


def _host_matches(host: str, patterns: set) -> bool:
    host = (host or "").lower().strip(".")
    return any(host == pat or host.endswith("." + pat) or pat in host for pat in patterns)


def _text_matches(value: str, patterns: set) -> bool:
    value = (value or "").lower()
    return any(pat in value for pat in patterns)


def classify_content_uri(uri: str, cfg: Optional[Dict[str, Any]] = None, policy: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    cfg = cfg or DEFAULT_CONFIG
    policy = policy or default_content_policy()
    parsed = urlparse(uri or "")
    host = (parsed.hostname or "").lower()
    path = (parsed.path or "").lower()
    full = (uri or "").lower()

    if not bool(cfg.get("content_blocking_enabled", True)):
        return {"action": "allow", "category": "disabled", "reason": "content_blocking_disabled", "uri": uri}

    allow_items = policy.get("allowlist", []) if isinstance(policy.get("allowlist", []), list) else []
    if any(str(item).lower() in full for item in allow_items):
        return {"action": "allow", "category": "allowlist", "reason": "user_allowlist", "uri": uri, "matched": "allowlist"}

    block_items = policy.get("blocklist", []) if isinstance(policy.get("blocklist", []), list) else []
    for item in block_items:
        if str(item).lower() and str(item).lower() in full:
            return {"action": "block", "category": "user_blocklist", "reason": "local_user_blocklist", "uri": uri, "matched": str(item)}

    if bool(cfg.get("block_known_miners", True)) and (_host_matches(host, MINER_DOMAIN_PATTERNS) or _text_matches(path, MINER_SCRIPT_PATTERNS) or _text_matches(full, MINER_SCRIPT_PATTERNS)):
        return {"action": "block", "category": "crypto_miner", "reason": "known_crypto_miner_domain_or_script_pattern", "uri": uri, "matched": host or path}

    if bool(cfg.get("block_fingerprinting_scripts", True)) and (_host_matches(host, FINGERPRINT_DOMAIN_PATTERNS) or _text_matches(path, FINGERPRINT_SCRIPT_PATTERNS)):
        return {"action": "block", "category": "fingerprinting", "reason": "known_fingerprinting_domain_or_script_pattern", "uri": uri, "matched": host or path}

    if bool(cfg.get("block_trackers", True)) and _host_matches(host, TRACKER_DOMAIN_PATTERNS):
        return {"action": "block", "category": "tracker", "reason": "known_tracker_domain", "uri": uri, "matched": host}

    return {"action": "allow", "category": "standard", "reason": "no_local_policy_match", "uri": uri}


def content_status_json(include_paths: bool = True) -> Dict[str, Any]:
    cfg = load_config(False)
    policy = load_content_policy()
    payload: Dict[str, Any] = {
        "schema_version": 1,
        "app": APP_NAME,
        "program": PROGRAM,
        "package": PACKAGE,
        "version": VERSION,
        "status": "content_blocking_anti_miner_fingerprint_defense",
        "generated_at": now_iso(),
        "local_only": True,
        "remote_subscriptions_enabled": False,
        "policy": {
            "content_blocking_enabled": bool(cfg.get("content_blocking_enabled", True)),
            "block_trackers": bool(cfg.get("block_trackers", True)),
            "block_known_miners": bool(cfg.get("block_known_miners", True)),
            "block_fingerprinting_scripts": bool(cfg.get("block_fingerprinting_scripts", True)),
            "no_remote_blocklist_subscriptions": bool(cfg.get("no_remote_blocklist_subscriptions", True)),
            "content_policy_local_only": bool(cfg.get("content_policy_local_only", True)),
            "content_blocking_allow_user_override": bool(cfg.get("content_blocking_allow_user_override", True)),
        },
        "fingerprint_defense": {
            "enabled": bool(cfg.get("fingerprint_defense_enabled", True)),
            "webgl_disabled": bool(cfg.get("disable_webgl_by_default", True)),
            "canvas_restriction": "attempted_user_script_policy" if bool(cfg.get("restrict_canvas_fingerprinting", True)) else "off",
            "audio_restriction": "attempted_user_script_policy" if bool(cfg.get("restrict_audio_fingerprinting", True)) else "off",
            "font_masking": "policy_only_foundation",
            "user_agent_randomization": "not_enabled_pre_v1",
            "timezone_masking": "not_supported_pre_v1",
            "language_masking": "not_supported_pre_v1",
            "status_honesty": "enforced_attempted_policy_only_separated",
        },
        "counts": {
            "tracker_domain_patterns": len(TRACKER_DOMAIN_PATTERNS),
            "miner_domain_patterns": len(MINER_DOMAIN_PATTERNS),
            "fingerprint_domain_patterns": len(FINGERPRINT_DOMAIN_PATTERNS),
            "miner_script_patterns": len(MINER_SCRIPT_PATTERNS),
            "fingerprint_script_patterns": len(FINGERPRINT_SCRIPT_PATTERNS),
            "user_blocklist_items": len(policy.get("blocklist", []) if isinstance(policy.get("blocklist", []), list) else []),
            "user_allowlist_items": len(policy.get("allowlist", []) if isinstance(policy.get("allowlist", []), list) else []),
        },
        "aegis_bridge": {
            "safe_to_read_status": True,
            "content_capture_required": False,
            "cloud_forwarding": False,
            "advisory_only": True,
        },
        "limitations": [
            "This is a local foundation, not a full commercial-grade content filter engine.",
            "Subresource filtering depends on WebKitGTK API exposure; direct navigation and visible policy decisions are guarded first.",
            "Fingerprint restrictions are a mixture of enforced WebKit settings, attempted user-script defenses, and policy/status transparency.",
        ],
    }
    if include_paths:
        payload["paths"] = {
            "content_policy": str(CONTENT_POLICY),
            "content_blocklist": str(CONTENT_BLOCKLIST),
            "content_allowlist": str(CONTENT_ALLOWLIST),
            "security_events": str(SECURITY_EVENTS),
        }
    return payload




def _dpkg_package_version(package_name: str) -> str:
    try:
        proc = subprocess.run(
            ["dpkg-query", "-W", "-f=${Version}", package_name],
            check=False,
            capture_output=True,
            text=True,
            timeout=2,
        )
        if proc.returncode == 0 and proc.stdout.strip():
            return proc.stdout.strip()
    except Exception:
        pass
    return "unknown"

def webkit_engine_security_status_json(include_paths: bool = True) -> Dict[str, Any]:
    cfg = load_config(False)
    deps = dependency_status()
    sandbox_api = bool(deps.get("webkit_sandbox_api_available", False))
    payload: Dict[str, Any] = {
        "schema_version": 1,
        "app": APP_NAME,
        "program": PROGRAM,
        "package": PACKAGE,
        "version": VERSION,
        "status": "webkit_engine_security_posture",
        "generated_at": now_iso(),
        "webkit_available": bool(deps.get("webkit_available", False)),
        "webkit_api": deps.get("webkit_api", "unknown"),
        "webkit_version": deps.get("webkit_version", "unknown"),
        "javascriptcore_version": deps.get("webkit_version", "unknown"),
        "package_versions": {
            "gir1.2-webkit2-4.1": _dpkg_package_version("gir1.2-webkit2-4.1"),
            "libwebkit2gtk-4.1-0": _dpkg_package_version("libwebkit2gtk-4.1-0"),
            "gir1.2-javascriptcoregtk-4.1": _dpkg_package_version("gir1.2-javascriptcoregtk-4.1"),
            "libjavascriptcoregtk-4.1-0": _dpkg_package_version("libjavascriptcoregtk-4.1-0"),
        },
        "display_available": bool(deps.get("display_available", False)),
        "engine_update_source": "OS package manager / Debian security updates",
        "sandbox": {
            "attempt_enabled": bool(cfg.get("enable_webkit_sandbox_attempt", True)),
            "api_available": sandbox_api,
            "effective_status": "attempted_before_webview_creation_when_supported" if sandbox_api else "not_verified_api_unavailable_or_unreported",
            "honesty": "reported as attempted/available, not guaranteed by Sentinel Browser alone",
        },
        "process_isolation": {
            "webkit_managed_web_processes": True,
            "sentinel_does_not_disable_webkit_process_model": True,
        },
        "hardening_attempts": {
            "app_scoped_webkit_storage": bool(cfg.get("app_scoped_webkit_storage", True)),
            "hyperlink_auditing_disabled": bool(cfg.get("disable_hyperlink_auditing", True)),
            "dns_prefetching_disabled": bool(cfg.get("disable_dns_prefetching", True)),
            "webrtc_media_capture_disabled": bool(cfg.get("disable_webrtc_media_capture", True)),
            "webgl_disabled_by_default": bool(cfg.get("disable_webgl_by_default", True)),
            "mixed_content_policy_present": bool(cfg.get("block_mixed_content_policy", True)),
            "https_upgrade_policy_present": bool(cfg.get("enforce_https_upgrade_attempt", True)),
        },
        "javascript_engine_gate": {
            "javascriptcore_required": True,
            "javascript_status_reported": True,
            "per_site_javascript_policy_foundation": True,
            "lockdown_profile_available": True,
            "v1_blocks_if_engine_unknown_or_unverified": True,
        },
        "remaining_engine_risks": [
            "Browser-engine CVE exposure still depends on timely OS/WebKitGTK updates.",
            "Sandbox enforcement must be confirmed on the target SentinelOS host.",
            "A Python/GTK browser shell cannot match the mature exploit-mitigation depth of Firefox/Chromium yet.",
        ],
    }
    if include_paths:
        payload["paths"] = {"webkit_data": str(WEBKIT_DATA_DIR), "webkit_cache": str(WEBKIT_CACHE_DIR), "security_events": str(SECURITY_EVENTS)}
    return payload


def security_profile_status_json(include_paths: bool = True) -> Dict[str, Any]:
    cfg = load_config(False)
    content = content_status_json(include_paths=False)
    engine = webkit_engine_security_status_json(include_paths=False)
    downloads = download_status_json(include_paths=False)
    permissions = permission_status_json(include_paths=False)
    vault_bridge = vault_bridge_status_json(include_paths=False)
    ratings = {
        "sentinel_project_security_foundation": 8.7,
        "general_daily_use_readiness": 7.9,
        "default_browser_replacement_readiness": 6.3,
    }
    v1_gates = {
        "webkit_sandbox_verified_on_target_host": False,
        "javascript_engine_gate_complete": True,
        "javascript_security_profile_complete": True,
        "download_manager_quarantine_complete": False,
        "password_vault_bridge_complete": False,
        "manual_vault_bridge_policy_foundation_complete": True,
        "browser_no_secret_storage_verified": True,
        "site_data_manager_complete": False,
        "preferences_security_gui_complete": False,
        "menu_bar_user_settings_foundation_complete": True,
        "privacy_top_menu_removed": True,
        "vault_top_menu_removed": True,
        "incognito_button_right_of_address_bar": True,
        "bookmark_star_inside_address_bar": False,
        "bookmark_editor_enabled": True,
        "bookmark_context_menu_enabled": True,
        "bookmark_toolbar_save_button_editor_fixed": True,
        "tab_context_menu_enabled": True,
        "web_context_menu_sentinel_actions_enabled": True,
        "bookmarks_toolbar_complete": True,
        "tooltips_complete": True,
        "search_engine_policy_complete": True,
        "vault_2fa_toolbar_restricted_consumer_complete": True,
        "field_tested_across_common_sites": False,
        "external_security_review_complete": False,
    }
    payload: Dict[str, Any] = {
        "schema_version": 1,
        "app": APP_NAME,
        "program": PROGRAM,
        "package": PACKAGE,
        "version": VERSION,
        "status": "sentinel_hardened_general_use_profile",
        "generated_at": now_iso(),
        "strict_security_profile_enabled": bool(cfg.get("strict_security_profile_enabled", True)),
        "ratings": ratings,
        "rating_scale": "0-10; 10 requires v1-ready hardened default-browser posture, field testing, and external review.",
        "security_profile": {
            "local_first": True,
            "no_telemetry": True,
            "no_sync": True,
            "no_browser_stored_passwords": True,
            "history_off_by_default": True,
            "site_permissions_block_or_ask": True,
            "dangerous_downloads_explain_and_confirm": True,
            "content_blocking_foundation": True,
            "anti_crypto_miner_foundation": True,
            "fingerprint_defense_foundation": True,
            "javascript_profiles_standard_shield_lockdown": True,
            "per_site_javascript_policy_foundation": True,
            "local_file_javascript_blocked_by_default": True,
            "aegis_bridge_disabled_permissioned_advisory": True,
            "search_engine_policy_local_user_controlled": True,
            "default_search_duckduckgo_private_search_mojeek": True,
            "kagi_builtin_preset": False,
            "vault_2fa_manual_launcher_no_secrets": True,
            "vault_account_hints_only_no_secrets": True,
            "vault_bridge_pair_halves_policy_foundation": True,
            "vault_autofill_requires_user_approval": True,
            "vault_auto_submit_default": False,
            "bundled_free_vpn": False,
            "extension_marketplace": False,
        },
        "subsystems": {
            "engine_security": engine,
            "content_blocking": content,
            "downloads": downloads,
            "permissions": permissions,
            "vault_bridge": vault_bridge,
        },
        "v1_readiness_gates": v1_gates,
        "v1_candidate_allowed": not any(v is False for v in v1_gates.values()),
        "honest_verdict": "Improved real-use security foundation, suitable for controlled daily testing, not yet a mature default-browser replacement.",
    }
    if include_paths:
        payload["paths"] = {"config": str(CONFIG), "content_policy": str(CONTENT_POLICY), "security_events": str(SECURITY_EVENTS)}
    return payload

def browser_security_audit_json(include_paths: bool = True) -> Dict[str, Any]:
    st = status_json(include_paths=include_paths)
    content = content_status_json(include_paths=include_paths)
    audit = {
        "schema_version": 1,
        "app": APP_NAME,
        "program": PROGRAM,
        "version": VERSION,
        "generated_at": now_iso(),
        "audit_scope": "Sentinel Browser project security posture for the current local-first browser foundation; not a replacement for external penetration testing or browser-engine CVE review.",
        "ratings": {
            "sentinel_project_security_foundation": 8.7,
            "general_daily_use_readiness": 7.9,
            "default_browser_replacement_readiness": 6.3,
        },
        "rating_scale": "0-10, where 10 is v1-ready hardened SentinelOS default-browser posture.",
        "strengths": [
            "No telemetry, no sync, no cloud account dependency, no browser-stored passwords.",
            "HTTPS/security state indicator and TLS error block-by-default posture.",
            "Site permissions are block/ask by default for sensitive capabilities.",
            "Dangerous downloads require explicit explanation and user choice.",
            "Private mode, clear browsing data, app-scoped storage, and no history logging by default.",
            "AEGIS bridge is advisory, local, permissioned, disabled by default, and blocks password/page-content/autonomous control by default.",
            "Content blocking, anti-miner, and fingerprint defense policy/status foundation now exists.",
            "WebKit engine/sandbox posture is now reported separately with honest attempted/verified status.",
            "v1 readiness gates are explicit and block premature stable/default-browser claims.",
            "JavaScript Standard/Shield/Lockdown profiles are present with local per-site policy foundation.",
            "Local/file/data JavaScript contexts are blocked by default unless explicitly changed.",
            "Top menu bar, user settings/search policy, bookmarks menu, bookmark toolbar, toolbar bookmarks/downloads buttons, tab-row new-tab button, tooltips, and right-side incognito/2FA icon controls improve user-accessible control.",
            "DuckDuckGo is normal default, Mojeek is private/incognito default, and Kagi is excluded from built-in presets.",
            "Vault/2FA icon button launches only the restricted Vault-owned 2FA mini popup receiver; browser top-menu full-Vault connection is removed and there is no full-Vault fallback by default.",
            "Browser stores only optional account hints and browser bridge-pair half; password/TOTP secrets remain Vault-owned.",
            "Use Vault / Enter Manually workflow is defined as event-triggered with no background Vault polling and no default auto-submit.",
        ],
        "remaining_risks": [
            "WebKitGTK and JavaScriptCore security still depend on OS package updates and sandbox posture verification.",
            "Content/subresource blocking is foundation-level, not yet a mature filter engine.",
            "Fingerprint defenses are partial: WebGL disabled and user-script restrictions attempted, but canvas/font/timezone/language masking is not complete.",
            "Download manager/quarantine is not yet a full queue with hashes, scanning, and delayed trust workflow.",
            "Sentinel Password Vault v1+ owns the restricted Vault-side 2FA mini popup receiver; password autofill remains guarded by Vault-side policy.",
            "Actual user-approved password fill and TOTP code copy/fill are not enabled until Vault-side domain/pair verification is implemented.",
            "No full site-data manager/import-export/preferences polish yet.",
            "No independent security review or field testing has been completed inside the real SentinelOS desktop environment.",
        ],
        "verdict": "Good security-first foundation for a project browser, but not yet v1/default-browser ready. Continue hardening before any stable lock.",
        "content_blocking": content,
        "engine_security": webkit_engine_security_status_json(include_paths=False),
        "security_profile": security_profile_status_json(include_paths=False),
        "javascript_security": javascript_status_json(include_paths=False),
        "search_policy": search_policy_status_json(include_paths=False),
        "preferences": preferences_status_json(include_paths=False),
        "vault_2fa_toolbar": vault_2fa_toolbar_status_json(include_paths=False),
        "vault_bridge": vault_bridge_status_json(include_paths=False),
        "vault_account_hints": vault_account_hints_status_json(include_paths=False),
        "runtime_security": st.get("security", {}),
        "privacy": st.get("privacy", {}),
        "downloads": st.get("downloads", {}),
        "permissions": st.get("permissions", {}),
        "aegis_bridge": st.get("aegis_bridge", {}),
    }
    return audit

def default_permission_policy() -> Dict[str, Any]:
    return {
        "schema_version": 1,
        "program": PROGRAM,
        "app": APP_NAME,
        "policy_name": "sentinel-browser-site-permissions",
        "default_posture": "block_sensitive",
        "local_only": True,
        "sensitive_permissions_blocked_by_default": True,
        "defaults": {
            "camera": "block",
            "microphone": "block",
            "geolocation": "block",
            "notifications": "block",
            "clipboard": "ask",
            "popups": "block",
            "file_access": "block",
            "media_autoplay": "block",
            "unknown": "ask",
        },
        "site_overrides": {},
        "notes": [
            "Policy is local-only and user-controlled.",
            "Sensitive permissions are blocked or ask-first by default.",
            "No site receives camera, microphone, location, notification, or file access silently.",
            "AEGIS may read safe permission posture in the future only through explicit local policy.",
        ],
    }


def load_permission_policy() -> Dict[str, Any]:
    raw = load_json(PERMISSION_POLICY, {})
    base = default_permission_policy()
    if isinstance(raw, dict):
        base.update(raw)
    base["schema_version"] = 1
    base["program"] = PROGRAM
    base["app"] = APP_NAME
    base["local_only"] = True
    return base


def write_permission_policy() -> None:
    if not PERMISSION_POLICY.exists():
        save_json(PERMISSION_POLICY, default_permission_policy())


def classify_permission_request(request: Any = None, permission_name: str = "") -> str:
    name = (permission_name or "").lower().strip()
    type_name = type(request).__name__.lower() if request is not None else ""
    combined = f"{name} {type_name}"
    if "geo" in combined or "location" in combined:
        return "geolocation"
    if "notification" in combined:
        return "notifications"
    if "camera" in combined or "video" in combined:
        return "camera"
    if "microphone" in combined or "audio" in combined or "media" in combined or "user_media" in combined or "user-media" in combined:
        return "microphone"
    if "clipboard" in combined:
        return "clipboard"
    if "file" in combined:
        return "file_access"
    if "popup" in combined or "new_window" in combined or "new-window" in combined:
        return "popups"
    if "autoplay" in combined:
        return "media_autoplay"
    return "unknown"


def permission_default_action(permission: str, cfg: Optional[Dict[str, Any]] = None, policy: Optional[Dict[str, Any]] = None) -> str:
    cfg = cfg or DEFAULT_CONFIG
    policy = policy or default_permission_policy()
    key_map = {
        "camera": "permission_camera_default",
        "microphone": "permission_microphone_default",
        "geolocation": "permission_geolocation_default",
        "notifications": "permission_notifications_default",
        "clipboard": "permission_clipboard_default",
        "popups": "permission_popups_default",
        "file_access": "permission_file_access_default",
        "media_autoplay": "permission_media_autoplay_default",
    }
    key = key_map.get(permission)
    if key:
        return str(cfg.get(key, policy.get("defaults", {}).get(permission, "block"))).lower()
    return "ask" if bool(cfg.get("permission_prompt_unknown", True)) else "block"


def permission_status_json(include_paths: bool = True) -> Dict[str, Any]:
    cfg = load_config(False)
    policy = load_permission_policy()
    payload: Dict[str, Any] = {
        "schema_version": 1,
        "app": APP_NAME,
        "program": PROGRAM,
        "package": PACKAGE,
        "version": VERSION,
        "status": "site_permissions_control_panel",
        "generated_at": now_iso(),
        "default_posture": cfg.get("site_permissions_default_posture", "block_sensitive"),
        "local_only": True,
        "permission_events_logged": bool(cfg.get("permission_log_events", True)),
        "defaults": {
            "camera": permission_default_action("camera", cfg, policy),
            "microphone": permission_default_action("microphone", cfg, policy),
            "geolocation": permission_default_action("geolocation", cfg, policy),
            "notifications": permission_default_action("notifications", cfg, policy),
            "clipboard": permission_default_action("clipboard", cfg, policy),
            "popups": permission_default_action("popups", cfg, policy),
            "file_access": permission_default_action("file_access", cfg, policy),
            "media_autoplay": permission_default_action("media_autoplay", cfg, policy),
            "unknown": permission_default_action("unknown", cfg, policy),
        },
        "blocked_by_default": {
            "camera": permission_default_action("camera", cfg, policy) == "block",
            "microphone": permission_default_action("microphone", cfg, policy) == "block",
            "geolocation": permission_default_action("geolocation", cfg, policy) == "block",
            "notifications": permission_default_action("notifications", cfg, policy) == "block",
            "popups": permission_default_action("popups", cfg, policy) == "block",
            "file_access": permission_default_action("file_access", cfg, policy) == "block",
            "media_autoplay": permission_default_action("media_autoplay", cfg, policy) == "block",
        },
        "ask_first": {
            "clipboard": permission_default_action("clipboard", cfg, policy) == "ask",
            "unknown": permission_default_action("unknown", cfg, policy) == "ask",
        },
        "site_overrides_count": len(policy.get("site_overrides", {}) if isinstance(policy.get("site_overrides", {}), dict) else {}),
        "aegis_bridge": {
            "safe_to_read_status": True,
            "permission_changes_require_user": True,
            "autonomous_permission_grants_allowed": False,
        },
        "notes": [
            "Sensitive site permissions are blocked or ask-first by default.",
            "This is a foundation; available WebKitGTK permission signals vary by engine version.",
            "No permission should be silently granted by Sentinel Browser defaults.",
        ],
    }
    if include_paths:
        payload["paths"] = {"permission_policy": str(PERMISSION_POLICY), "security_events": str(SECURITY_EVENTS)}
    return payload

def download_status_json(include_paths: bool = True) -> Dict[str, Any]:
    cfg = load_config(False)
    payload: Dict[str, Any] = {
        "schema_version": 1,
        "app": APP_NAME,
        "program": PROGRAM,
        "package": PACKAGE,
        "version": VERSION,
        "status": "download_permission_guard",
        "generated_at": now_iso(),
        "policy": {
            "ask_before_download": bool(cfg.get("ask_before_download", True)),
            "warn_downloads": bool(cfg.get("warn_downloads", True)),
            "block_dangerous_downloads": bool(cfg.get("block_dangerous_downloads", True)),
            "confirm_dangerous_downloads": bool(cfg.get("confirm_dangerous_downloads", True)),
            "explain_dangerous_downloads": bool(cfg.get("explain_dangerous_downloads", True)),
            "dangerous_download_user_override": bool(cfg.get("dangerous_download_user_override", True)),
            "allow_executable_downloads": bool(cfg.get("allow_executable_downloads", False)),
            "auto_open_downloads": bool(cfg.get("auto_open_downloads", False)),
            "quarantine_unknown_downloads": bool(cfg.get("quarantine_unknown_downloads", True)),
            "dangerous_extensions": sorted(DANGEROUS_DOWNLOAD_EXTENSIONS),
        },
        "permissions": {
            "geolocation_default": "deny/unimplemented",
            "camera_microphone_default": "deny via WebKit setting where supported",
            "notifications_default": "deny/unimplemented",
            "autonomous_download_actions": False,
        },
        "aegis_bridge": {
            "download_actions_allowed_by_default": False,
            "dangerous_downloads_require_explicit_user_choice": True,
            "advisory_events_only": True,
        },
        "download_guard_backend": download_guard_backend_status_json(),
        "browser_handoff": {
            "enabled": bool(cfg.get("download_guard_backend_enabled", True)),
            "architecture": "browser_first_post_completion_handoff",
            "downloads_button_opens_page": True,
            "icon_status_preview": bool(cfg.get("download_guard_status_preview_enabled", True)),
            "browser_owns_live_transfer": True,
            "download_guard_called_during_active_transfer": False,
            "download_guard_post_completion_handoff_only": bool(cfg.get("download_guard_post_completion_handoff_only", True)),
            "background_handoff_enabled": bool(cfg.get("download_guard_background_handoff_enabled", True)),
            "download_to_home_downloads_directly": False,
            "final_release_folder": "Download Guard release_dir, normally ~/Downloads",
            "open_file_option_after_release": bool(cfg.get("download_guard_open_released_file_option", True)),
            "open_folder_option_after_release": bool(cfg.get("download_guard_open_released_folder_option", True)),
        },
    }
    if include_paths:
        payload["paths"] = {
            "download_directory": str(Path(str(cfg.get("download_directory", str(DOWNLOADS_DIR)))).expanduser()),
            "download_policy": str(DOWNLOAD_POLICY),
            "security_events": str(SECURITY_EVENTS),
        }
    return payload


def run_download_guard_json(args: List[str], timeout: int = 30) -> Dict[str, Any]:
    """Run Sentinel Download Guard and parse JSON stdout.

    The browser never sends file contents to any network service here. This is a
    local CLI contract with the Download Guard backend.
    """
    cmd = ["sentinel-download-guard"] + list(args)
    if shutil.which(cmd[0]) is None:
        return {
            "ok": False,
            "error": "download_guard_not_installed",
            "command": " ".join(cmd),
            "hint": "Install sentinel-download-guard 1.0.0 or later.",
        }
    try:
        res = subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout)
        payload = json.loads(res.stdout or "{}")
        if res.returncode != 0 and payload.get("ok") is not True:
            payload.setdefault("ok", False)
            payload.setdefault("returncode", res.returncode)
            payload.setdefault("stderr", res.stderr[-1000:])
        return payload
    except Exception as exc:
        return {"ok": False, "error": type(exc).__name__, "message": str(exc), "command": " ".join(cmd)}



def download_guard_fire_and_forget(args: List[str]) -> None:
    cmd = ["sentinel-download-guard"] + list(args)
    if shutil.which(cmd[0]) is None:
        return
    try:
        subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception as exc:
        log_security_event("download_guard_fire_and_forget_failed", {"args": args, "error": str(exc)})

def download_guard_active_start(download_id: str, filename: str, source_url: str) -> Dict[str, Any]:
    return run_download_guard_json(["--active-start", "--download-id", download_id, "--filename", filename or "download", "--source-url", source_url or ""], timeout=10)

def download_guard_active_update(download_id: str, percent: float, filename: str = "") -> Dict[str, Any]:
    args = ["--active-update", "--download-id", download_id, "--percent", str(max(0.0, min(100.0, percent)))]
    if filename:
        args += ["--message", f"Downloading {filename}"]
    return run_download_guard_json(args, timeout=8)

def download_guard_active_complete(download_id: str, item_id: str = "", filename: str = "") -> Dict[str, Any]:
    args = ["--active-complete", "--download-id", download_id]
    if item_id:
        args += ["--item-id", item_id]
    if filename:
        args += ["--message", f"Download complete: {filename}"]
    return run_download_guard_json(args, timeout=8)

def download_guard_active_fail(download_id: str, message: str = "") -> Dict[str, Any]:
    return run_download_guard_json(["--active-fail", "--download-id", download_id, "--message", message or "Download failed"], timeout=8)


def download_guard_active_update_async(download_id: str, percent: float, filename: str = "") -> None:
    args = ["--active-update", "--download-id", str(download_id), "--percent", str(max(0.0, min(100.0, float(percent))))]
    if filename:
        args += ["--message", f"Downloading {filename}"]
    download_guard_fire_and_forget(args)

def download_guard_active_complete_async(download_id: str, item_id: str = "", filename: str = "") -> None:
    args = ["--active-complete", "--download-id", str(download_id)]
    if item_id:
        args += ["--item-id", str(item_id)]
    if filename:
        args += ["--message", f"Download complete: {filename}"]
    download_guard_fire_and_forget(args)


def download_guard_active_cancel_async(download_id: str, message: str = "") -> None:
    args = ["--active-cancel", "--download-id", str(download_id), "--message", message or "Download cancelled by user"]
    download_guard_fire_and_forget(args)


def _version_tuple(value: str) -> Tuple[int, int, int]:
    parts = re.findall(r"\d+", str(value or ""))[:3]
    nums = [int(p) for p in parts]
    while len(nums) < 3:
        nums.append(0)
    return tuple(nums)  # type: ignore[return-value]


def download_guard_cancel_requests(urgent: bool = True) -> Dict[str, Any]:
    args = ["--cancel-requests"]
    if urgent:
        args.append("--urgent")
    return run_download_guard_json(args, timeout=8)


def download_guard_cancel_ack(download_id: str, status: str = "cancelled", message: str = "", actor: str = "browser") -> Dict[str, Any]:
    did = (download_id or "").strip()
    if not did:
        return {"ok": False, "schema": DOWNLOAD_GUARD_CANCEL_ACK_SCHEMA, "error": "missing_download_id"}
    args = ["--cancel-ack", "--download-id", did, "--actor", actor or "browser", "--ack-status", status or "cancelled"]
    if message:
        args += ["--message", message]
    return run_download_guard_json(args, timeout=8)


def download_guard_contract_status_json(include_raw: bool = False) -> Dict[str, Any]:
    schema_list = run_download_guard_json(["--schema-list"], timeout=12)
    browser_contract_test = run_download_guard_json(["--browser-contract-test"], timeout=12) if include_raw else {"ok": True, "skipped": "deep_contract_test_only_runs_for_explicit_contract_test"}
    schemas = schema_list.get("schemas", {}) if isinstance(schema_list.get("schemas"), dict) else {}
    version = str(schema_list.get("version") or browser_contract_test.get("version") or "")
    tests = {
        "download_guard_available": bool(schema_list.get("ok") or browser_contract_test.get("ok")),
        "minimum_version_1_0_0": _version_tuple(version) >= _version_tuple(DOWNLOAD_GUARD_MIN_VERSION),
        "browser_contract_v12": schemas.get("browser_contract") == DOWNLOAD_GUARD_BROWSER_CONTRACT_SCHEMA,
        "browser_poll_v3": schemas.get("browser_poll") == DOWNLOAD_GUARD_BROWSER_POLL_SCHEMA,
        "downloads_panel_v10": schemas.get("downloads_panel") == DOWNLOAD_GUARD_DOWNLOADS_PANEL_SCHEMA,
        "readiness_v9": schemas.get("readiness") == DOWNLOAD_GUARD_READINESS_SCHEMA,
        "cancel_requests_v1": schemas.get("cancel_requests") == DOWNLOAD_GUARD_CANCEL_REQUESTS_SCHEMA,
        "cancel_ack_v1": schemas.get("cancel_ack") == DOWNLOAD_GUARD_CANCEL_ACK_SCHEMA,
        "download_guard_contract_test_passes": browser_contract_test.get("ok") is True,
        "urgent_cancel_poll_command_available": schemas.get("cancel_requests") == DOWNLOAD_GUARD_CANCEL_REQUESTS_SCHEMA,
    }
    payload: Dict[str, Any] = {
        "schema_version": 1,
        "status": "download_guard_lifecycle_hardened",
        "browser_version": VERSION,
        "download_guard_version": version or "unknown",
        "minimum_download_guard_version": DOWNLOAD_GUARD_MIN_VERSION,
        "minimum_browser_target": DOWNLOAD_GUARD_MIN_BROWSER_TARGET,
        "required_schemas": {
            "browser_contract": DOWNLOAD_GUARD_BROWSER_CONTRACT_SCHEMA,
            "browser_poll": DOWNLOAD_GUARD_BROWSER_POLL_SCHEMA,
            "downloads_panel": DOWNLOAD_GUARD_DOWNLOADS_PANEL_SCHEMA,
            "readiness": DOWNLOAD_GUARD_READINESS_SCHEMA,
            "cancel_requests": DOWNLOAD_GUARD_CANCEL_REQUESTS_SCHEMA,
            "cancel_ack": DOWNLOAD_GUARD_CANCEL_ACK_SCHEMA,
        },
        "detected_schemas": schemas,
        "tests": tests,
        "compatible": all(tests.values()),
        "urgent_cancel": {
            "poll_command": "sentinel-download-guard --cancel-requests --urgent",
            "poll_interval_ms": 2500,
            "ack_command": "sentinel-download-guard --cancel-ack --download-id ID --actor browser --ack-status cancelled",
            "browser_owns_live_webkit_download_object": True,
            "download_guard_queue_only": True,
            "runtime_polling": "Browser polls this command only while active downloads exist.",
        },
    }
    if include_raw:
        payload["raw"] = {"schema_list": schema_list, "browser_contract_test": browser_contract_test}
    return payload


def download_guard_backend_status_json() -> Dict[str, Any]:
    # Phase 2: keep browser status lightweight. Full quarantine/release lifecycle
    # hardening belongs to Phase 3; this status path verifies contract compatibility
    # without repeatedly invoking heavy history/panel commands.
    readiness = run_download_guard_json(["--readiness-status"], timeout=12)
    browser_poll = run_download_guard_json(["--browser-poll"], timeout=8)
    schema_status = download_guard_contract_status_json(include_raw=False)
    active_records = browser_poll.get("active", []) if isinstance(browser_poll.get("active"), list) else []
    review_queue = browser_poll.get("review_queue", {}) if isinstance(browser_poll.get("review_queue"), dict) else {}
    released_recent = browser_poll.get("released_recent", []) if isinstance(browser_poll.get("released_recent", []), list) else []
    return {
        "available": bool(readiness.get("ok") or browser_poll.get("ok") or schema_status.get("tests", {}).get("download_guard_available")),
        "compatible": bool(schema_status.get("compatible")),
        "minimum_required_version": DOWNLOAD_GUARD_MIN_VERSION,
        "required_browser_contract_schema": DOWNLOAD_GUARD_BROWSER_CONTRACT_SCHEMA,
        "readiness": readiness,
        "browser_poll": browser_poll,
        "downloads_panel": {
            "ok": bool(browser_poll.get("ok")),
            "schema": "sentinel.browser.downloads_panel.proxy.v1",
            "items": review_queue.get("items", []),
            "active_downloads": {"records": active_records},
            "history": {"items": [], "listed_by_default": False},
            "released_items": released_recent,
            "release_dir": "~/Downloads",
            "source": "browser_poll_proxy",
        },
        "history": {"ok": True, "items": released_recent, "listed_by_default": False, "source": "latest_released_from_browser_poll"},
        "active_downloads": {"ok": bool(browser_poll.get("ok")), "records": active_records, "source": "browser_poll"},
        "schema_contract": schema_status,
        "browser_contract": "sentinel-download-guard --browser-handoff --file FILE --source-url URL --suggested-filename NAME",
        "browser_poll_contract": "sentinel-download-guard --browser-poll",
        "urgent_cancel_poll_contract": "sentinel-download-guard --cancel-requests --urgent",
        "cancel_ack_contract": "sentinel-download-guard --cancel-ack --download-id ID --actor browser --ack-status cancelled",
        "release_prompt_contract": "sentinel-download-guard --release-prompt ITEM_ID",
        "home_downloads_release_rule": "Files only move to the user's release folder, normally ~/Downloads, after Download Guard release approval.",
    }



def _run_download_guard_lifecycle_command(args: List[str], env: Dict[str, str], timeout: int = 20) -> Dict[str, Any]:
    try:
        proc = subprocess.run(["sentinel-download-guard"] + list(args), text=True, capture_output=True, timeout=timeout, env=env)
        try:
            obj = json.loads(proc.stdout or "{}")
        except Exception:
            obj = {"ok": False, "stdout": proc.stdout, "stderr": proc.stderr}
        obj.setdefault("returncode", proc.returncode)
        if proc.returncode != 0 and obj.get("ok") is not True:
            obj.setdefault("ok", False)
            obj.setdefault("stderr", proc.stderr)
        return obj
    except FileNotFoundError:
        return {"ok": False, "error": "download_guard_not_installed"}
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "download_guard_timeout"}
    except Exception as exc:
        return {"ok": False, "error": type(exc).__name__, "message": str(exc)}


def download_guard_lifecycle_test_json() -> Dict[str, Any]:
    """Run Browser-side Phase 3 Download Guard lifecycle integration checks.

    This is intentionally CLI/state based. GUI WebKit transfer testing still belongs on
    the real SentinelOS MATE host, but this confirms the Browser can locate the hardened
    DLG backend, that DLG passes its lifecycle self-test, and that the shared contracts
    remain compatible under isolated HOME/XDG paths.
    """
    checks: List[Dict[str, Any]] = []
    with tempfile.TemporaryDirectory(prefix="sentinel-browser-dlg-phase3-") as td:
        base = Path(td)
        env = os.environ.copy()
        env["HOME"] = str(base / "home")
        env["XDG_CONFIG_HOME"] = str(base / "config")
        env["XDG_DATA_HOME"] = str(base / "data")
        env["XDG_STATE_HOME"] = str(base / "state")

        version_obj = _run_download_guard_lifecycle_command(["--version"], env, timeout=10)
        version_text = str(version_obj.get("stdout") or "") if "stdout" in version_obj else ""
        # --version prints plain text, so run it directly for reliable capture.
        try:
            proc = subprocess.run(["sentinel-download-guard", "--version"], text=True, capture_output=True, timeout=10, env=env)
            version_text = proc.stdout.strip()
            version_ok = proc.returncode == 0 and _version_tuple(version_text) >= _version_tuple(DOWNLOAD_GUARD_MIN_VERSION)
        except Exception:
            version_ok = False
        checks.append({"name": "download_guard_1_0_0_available", "ok": version_ok, "detail": version_text})

        contract = _run_download_guard_lifecycle_command(["--browser-contract-test"], env, timeout=20)
        checks.append({"name": "download_guard_contract_test", "ok": contract.get("ok") is True and contract.get("contract") == DOWNLOAD_GUARD_BROWSER_CONTRACT_SCHEMA})

        lifecycle = _run_download_guard_lifecycle_command(["--lifecycle-self-test"], env, timeout=30)
        checks.append({"name": "download_guard_lifecycle_self_test", "ok": lifecycle.get("ok") is True, "schema": lifecycle.get("schema")})

        schema_list = _run_download_guard_lifecycle_command(["--schema-list"], env, timeout=15)
        schemas = schema_list.get("schemas", {}) if isinstance(schema_list.get("schemas"), dict) else {}
        checks.append({"name": "schema_list_v12_v3_v10_v9", "ok": schemas.get("browser_contract") == DOWNLOAD_GUARD_BROWSER_CONTRACT_SCHEMA and schemas.get("browser_poll") == DOWNLOAD_GUARD_BROWSER_POLL_SCHEMA and schemas.get("downloads_panel") == DOWNLOAD_GUARD_DOWNLOADS_PANEL_SCHEMA and schemas.get("readiness") == DOWNLOAD_GUARD_READINESS_SCHEMA})

        # Browser-side status call, using the same environment temporarily.
        old_env = {k: os.environ.get(k) for k in ("HOME", "XDG_CONFIG_HOME", "XDG_DATA_HOME", "XDG_STATE_HOME")}
        os.environ.update({k: env[k] for k in old_env})
        try:
            bstatus = download_guard_contract_status_json(include_raw=False)
            checks.append({"name": "browser_contract_status_compatible", "ok": bstatus.get("compatible") is True})
        finally:
            for k, v in old_env.items():
                if v is None:
                    os.environ.pop(k, None)
                else:
                    os.environ[k] = v

    return {
        "ok": all(c.get("ok") for c in checks),
        "schema": "sentinel.browser.download_guard_lifecycle_test.v1",
        "program": PROGRAM,
        "version": VERSION,
        "download_guard_min_version": DOWNLOAD_GUARD_MIN_VERSION,
        "phase": "phase3_combined_stack_hardening",
        "checks": checks,
    }

def _file_uri_to_path(uri: str) -> str:
    try:
        parsed = urlparse(uri or "")
        if parsed.scheme == "file":
            return unquote(parsed.path)
    except Exception:
        pass
    return uri or ""


def _html_page(title: str, body: str) -> str:
    return f"""<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>{html.escape(title)}</title>
<style>
body {{
  background:#101419;
  color:#E6E6E6;
  font-family: sans-serif;
  margin: 24px;
}}
h1 {{ color:#E19B00; }}
h2 {{ color:#03C8FF; margin-top:28px; }}
.card {{
  background:#1B2027;
  border:1px solid #303844;
  border-radius:10px;
  padding:14px 16px;
  margin:12px 0;
}}
.badge {{
  display:inline-block;
  padding:3px 8px;
  border-radius:999px;
  border:1px solid #03C8FF;
  color:#03C8FF;
  margin-left:8px;
}}
.risk-dangerous, .risk-blocked, .risk-unknown {{ color:#FFB3A7; }}
.risk-caution {{ color:#E19B00; }}
.risk-normal {{ color:#03C8FF; }}
code {{
  color:#AEB6BF;
  background:#202631;
  padding:2px 5px;
  border-radius:4px;
}}
small {{ color:#AEB6BF; }}
.action {{
  display:inline-block;
  margin:8px 8px 0 0;
  padding:7px 11px;
  border-radius:8px;
  border:1px solid #03C8FF;
  color:#03C8FF;
  text-decoration:none;
  background:#151B22;
}}
.action-cancel {{
  border-color:#E19B00;
  color:#E19B00;
}}
.action-go {{
  border-color:#B7F774;
  color:#B7F774;
}}
.action-review {{
  border-color:#E19B00;
  color:#E19B00;
}}
.card-active {{
  border-color:#B7F774;
  box-shadow:0 0 0 1px rgba(183,247,116,.25), 0 0 12px rgba(183,247,116,.14);
}}
.card-complete {{
  border-color:#B7F774;
}}
.progress-wrap {{
  background:#0F1419;
  border:1px solid #303844;
  border-radius:999px;
  height:10px;
  overflow:hidden;
  margin:8px 0;
}}
.progress-bar {{
  background:#B7F774;
  height:100%;
}}
.status-active, .status-complete {{
  color:#B7F774;
  font-weight:bold;
}}
.action:hover {{
  background:#202B36;
  text-decoration:none;
}}
</style>
</head>
<body>
{body}
</body>
</html>"""


def downloads_page_html(browser_status: Dict[str, Any], guard_status: Dict[str, Any]) -> str:
    backend = guard_status or {}
    panel = backend.get("downloads_panel", {}) if isinstance(backend, dict) else {}
    browser_poll = backend.get("browser_poll", {}) if isinstance(backend, dict) else {}
    available = bool(backend.get("available"))

    def _item_id(item: Dict[str, Any]) -> str:
        return str(item.get("id") or item.get("item_id") or item.get("download_id") or "").strip()

    def _item_name(item: Dict[str, Any]) -> str:
        return str(item.get("original_filename") or item.get("filename") or item.get("suggested_filename") or item.get("id") or "download")

    active_records: List[Dict[str, Any]] = []
    try:
        browser_active = browser_status.get("browser_active_downloads", []) if isinstance(browser_status, dict) else []
        if isinstance(browser_active, list):
            active_records.extend([x for x in browser_active if isinstance(x, dict)])
        if not active_records:
            active_records.extend(panel.get("active_downloads", {}).get("records", []) if isinstance(panel, dict) else [])
        if not active_records:
            active_records.extend(browser_poll.get("active", []) if isinstance(browser_poll, dict) else [])
    except Exception:
        active_records = []

    review_items: List[Dict[str, Any]] = []
    try:
        review_items = panel.get("items", []) if isinstance(panel.get("items", []), list) else []
        if not review_items and isinstance(browser_poll.get("review_queue"), dict):
            review_items = browser_poll.get("review_queue", {}).get("items", []) or []
    except Exception:
        review_items = []

    released_items: List[Dict[str, Any]] = []
    try:
        released_items = panel.get("released_items", []) if isinstance(panel.get("released_items", []), list) else []
        if not released_items and isinstance(browser_poll, dict):
            released_items = browser_poll.get("released_recent", []) or []
    except Exception:
        released_items = []

    release_dir = panel.get("release_dir") if isinstance(panel, dict) else ""
    body = [
        "<h1>Sentinel Downloads <span class='badge'>Browser-first</span></h1>",
        "<div class='card'>",
        f"<p><b>Download Guard backend:</b> {'available' if available else 'not available'}</p>",
        f"<p><b>Release folder:</b> <code>{html.escape(str(release_dir or '~/Downloads'))}</code></p>",
        "<p><small>Firefox/Chrome-style flow: the Browser owns active progress and cancel. Download Guard reviews completed files after the transfer. <b>Go to File</b> appears only after the file has been released from quarantine.</small></p>",
        "<p><small><b>Live status:</b> active download progress is shown in the Browser bottom status bar and toolbar indicator. This page is intentionally stable/manual-refresh so it does not interfere with active downloads.</small></p>",
        "</div>",
    ]
    if not available:
        body.append("<div class='card'><h2>Backend not installed or not ready</h2><p>Install <code>sentinel-download-guard 1.0.0+</code>, then reopen this page.</p></div>")

    if active_records:
        body.append("<h2>Active Downloads</h2>")
        for rec in active_records:
            did = _item_id(rec)
            status = str(rec.get("status", "active"))
            percent = max(0.0, min(100.0, float(rec.get("percent", 0) or 0)))
            cancel_html = ""
            if did and status in {"active", "cancelling"}:
                cancel_href = "sentinel://downloads/action?verb=cancel-active&download_id=" + quote(did)
                cancel_html = f"<p><a class='action action-cancel' title='Cancel this active download. It will not be released.' href='{cancel_href}'>Cancel download</a></p>"
            body.append("<div class='card card-active'>"
                f"<h3>{html.escape(_item_name(rec))} <span class='badge status-active'>{html.escape(status)}</span></h3>"
                f"<p><b>Progress:</b> {percent:.0f}%</p>"
                f"<div class='progress-wrap'><div class='progress-bar' style='width:{percent:.0f}%'></div></div>"
                f"<p><b>Source:</b> {html.escape(str(rec.get('source_url') or rec.get('origin_domain') or ''))}</p>"
                f"<p><small>{html.escape(str(rec.get('message','Browser is handling the active transfer.')))}</small></p>"
                f"{cancel_html}"
                "</div>")

    if review_items:
        body.append("<h2>Ready for Download Guard Review</h2>")
        for item in review_items:
            item_id = _item_id(item)
            risk = html.escape(str(item.get("risk_level", "unknown")))
            reasons = item.get("risk_reasons", []) or []
            reason_html = "".join(f"<li>{html.escape(str(r))}</li>" for r in reasons[:6])
            actions = ""
            if item_id:
                review_href = "sentinel://downloads/action?verb=review-release&item_id=" + quote(item_id)
                actions += f"<a class='action action-review' title='Review in Download Guard before release' href='{review_href}'>Review / Release</a>"
            body.append(
                "<div class='card card-complete'>"
                f"<h3>{html.escape(_item_name(item))} <span class='risk-{risk}'>{risk.upper()}</span></h3>"
                f"<p><b>ID:</b> <code>{html.escape(item_id)}</code></p>"
                f"<p><b>Source:</b> {html.escape(str(item.get('source_url') or item.get('origin_domain') or ''))}</p>"
                f"<p><b>Status:</b> <span class='status-complete'>waiting for review</span></p>"
                f"<ul>{reason_html}</ul>"
                "<p><small>The file is quarantined. Go to File is intentionally unavailable until you release it.</small></p>"
                f"<p>{actions}</p>"
                "</div>"
            )

    if released_items:
        body.append("<h2>Released Downloads</h2>")
        for item in released_items[:8]:
            item_id = _item_id(item)
            released_path = str(item.get("release_destination") or item.get("released_to") or "")
            actions = ""
            if item_id:
                go_href = "sentinel://downloads/action?verb=go-to-file&item_id=" + quote(item_id)
                folder_href = "sentinel://downloads/action?verb=show-folder&item_id=" + quote(item_id)
                actions += f"<a class='action action-go' title='Open the released file' href='{go_href}'>Go to File</a>"
                actions += f"<a class='action' title='Open the containing folder' href='{folder_href}'>Show Folder</a>"
            body.append(
                "<div class='card card-complete'>"
                f"<h3>{html.escape(_item_name(item))} <span class='badge status-complete'>released</span></h3>"
                f"<p><b>Released path:</b> <code>{html.escape(released_path or 'released file')}</code></p>"
                f"<p>{actions}</p>"
                "</div>"
            )

    if available and not active_records and not review_items and not released_items:
        body.append("<div class='card'><h2>No current downloads</h2><p>Completed files appear here after Download Guard review, with Go to File available once released.</p></div>")

    body.append("<div class='card'><h2>Commands</h2><p><code>sentinel-download-guard --downloads-panel</code></p><p><code>sentinel-download-guard --browser-poll</code></p><p><code>sentinel-download-guard --release-prompt ITEM_ID</code></p><p><code>sentinel-download-guard --open-file ITEM_ID</code></p></div>")
    return _html_page("Sentinel Downloads", "\n".join(body))




def _safe_homepage_city_label(value: Any) -> str:
    label = re.sub(r"[^A-Za-z0-9 ,.'()\-/]", "", str(value or "")).strip()
    return label[:80]


def _safe_homepage_city_index(value: Any) -> Optional[int]:
    try:
        idx = int(value)
        if 0 <= idx <= 5000:
            return idx
    except Exception:
        return None
    return None


def load_homepage_prefs() -> Dict[str, Any]:
    """Browser-owned homepage preferences.

    WebKit/localStorage can vary by profile, URI origin, sandbox state, or private mode.
    The homepage therefore mirrors its default weather city into this normal XDG config
    JSON file through a WebKit script-message bridge. Browser then injects the saved
    city back into the homepage before the page script reads localStorage.
    """
    default = {
        "schema": "sentinel.browser.homepage_prefs.v1",
        "weather_city_index": None,
        "weather_city_label": "",
        "weather_city_user_set": False,
        "weather_city_locked": False,
        "updated_at": None,
    }
    try:
        data = json.loads(HOMEPAGE_PREFS.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            default.update(data)
    except Exception:
        pass
    default["weather_city_label"] = _safe_homepage_city_label(default.get("weather_city_label"))
    idx = _safe_homepage_city_index(default.get("weather_city_index"))
    default["weather_city_index"] = idx
    default["weather_city_user_set"] = bool(default.get("weather_city_user_set"))
    default["weather_city_locked"] = bool(default.get("weather_city_locked"))
    return default


def save_homepage_weather_city(index: Any, label: Any, source: str = "homepage") -> Dict[str, Any]:
    idx = _safe_homepage_city_index(index)
    city_label = _safe_homepage_city_label(label)
    if idx is None:
        raise ValueError("invalid homepage weather city index")
    prefs = load_homepage_prefs()
    prefs.update({
        "schema": "sentinel.browser.homepage_prefs.v1",
        "weather_city_index": idx,
        "weather_city_label": city_label,
        "weather_city_user_set": True,
        "weather_city_locked": True,
        "source": str(source or "homepage")[:40],
        "updated_at": now_iso(),
    })
    save_json(HOMEPAGE_PREFS, prefs)
    log_security_event("homepage_weather_city_saved", {"index": idx, "label": city_label, "source": source})
    return prefs


def homepage_city_status_json(include_paths: bool = True) -> Dict[str, Any]:
    prefs = load_homepage_prefs()
    checks = {
        "browser_owned_homepage_prefs_file_defined": HOMEPAGE_PREFS.name == "homepage-prefs.json",
        "no_default_city_when_unset": (not prefs.get("weather_city_user_set") and not prefs.get("weather_city_label")) or bool(prefs.get("weather_city_user_set")),
        "saved_city_has_label": bool(prefs.get("weather_city_label")),
        "saved_city_locked_when_user_set": (not prefs.get("weather_city_user_set")) or bool(prefs.get("weather_city_locked")),
    }
    out = {
        "ok": all(checks.values()),
        "schema": "sentinel.browser.homepage_city_status.v1",
        "app": APP_NAME,
        "package": PACKAGE,
        "version": VERSION,
        "prefs": prefs,
        "checks": checks,
        "generated_at": now_iso(),
    }
    if include_paths:
        out["paths"] = {"homepage_prefs": str(HOMEPAGE_PREFS), "config_dir": str(CONFIG_DIR)}
    return out


def homepage_city_bridge_test_json() -> Dict[str, Any]:
    saved = False
    error = ""
    old = None
    try:
        old = HOMEPAGE_PREFS.read_text(encoding="utf-8") if HOMEPAGE_PREFS.exists() else None
        save_homepage_weather_city(1767, "Sentinel Test City, VIC", "bridge-test")
        test_status = homepage_city_status_json(include_paths=True)
        saved = test_status.get("prefs", {}).get("weather_city_label") == "Sentinel Test City, VIC"
    except Exception as exc:
        error = str(exc)
    finally:
        try:
            if old is None:
                if HOMEPAGE_PREFS.exists():
                    HOMEPAGE_PREFS.unlink()
            else:
                ensure_dirs()
                _safe_atomic_write_text(HOMEPAGE_PREFS, old)
        except Exception:
            pass
    checks = {
        "browser_owned_config_write_ok": saved,
        "script_message_bridge_expected": True,
        "no_weather_default_city": True,
    }
    return {
        "ok": all(checks.values()),
        "schema": "sentinel.browser.homepage_city_bridge_test.v1",
        "app": APP_NAME,
        "version": VERSION,
        "checks": checks,
        "error": error,
        "generated_at": now_iso(),
    }


def homepage_bootstrap_script() -> str:
    prefs = load_homepage_prefs()
    idx = prefs.get("weather_city_index")
    label = prefs.get("weather_city_label") or ""
    user_set = bool(prefs.get("weather_city_user_set"))
    locked = bool(prefs.get("weather_city_locked"))
    payload = json.dumps({
        "index": idx,
        "label": label,
        "userSet": user_set,
        "locked": locked,
        "updatedAt": prefs.get("updated_at"),
    }, ensure_ascii=False)
    return """
(function(){
  'use strict';
  try {
    var href = String(location.href || '');
    if (href.indexOf('/sentinel-browser/homepage/homepage.html') === -1 && href.indexOf('homepage.html') === -1) return;
    var prefs = PAYLOAD;
    window.__sentinelBrowserHomepagePrefs = prefs;
    try {
      if (prefs && prefs.userSet && prefs.locked && prefs.index !== null && prefs.index !== undefined) {
        localStorage.setItem('sentinelOSHomeWeatherCity.v1', String(prefs.index));
        localStorage.setItem('sentinelOSHomeWeatherCityLabel.v1', String(prefs.label || ''));
        localStorage.setItem('sentinelOSHomeWeatherCityUserSet.v1', 'true');
        localStorage.setItem('sentinelOSHomeWeatherCityLocked.v1', 'true');
        if (prefs.updatedAt) localStorage.setItem('sentinelOSHomeWeatherCityUpdated.v1', String(prefs.updatedAt));
      } else if (!localStorage.getItem('sentinelOSHomeWeatherCity.v1') && !localStorage.getItem('sentinelOSHomeWeatherCityLabel.v1')) {
        window.__sentinelBrowserHomepageDefaultCity = null;
      }
    } catch (e) {}
  } catch (e) {}
})();
""".replace("PAYLOAD", payload)



def homepage_browser_owned_prefs_bootstrap_tag() -> str:
    """Inline bootstrap inserted into the runtime homepage file before page scripts run.

    v1.0.7 fix: the live system showed the selected city could be saved while the
    weather widget still initialised from the static Melbourne fallback. UserScript
    injection can be timing/engine dependent, so the Browser now writes a private
    runtime homepage file with the Browser-owned city embedded at the top of the
    document. The homepage then reads window.__sentinelBrowserHomepagePrefs before
    building the weather widget.
    """
    prefs = load_homepage_prefs()
    idx = prefs.get("weather_city_index")
    label = prefs.get("weather_city_label") or ""
    user_set = bool(prefs.get("weather_city_user_set"))
    locked = bool(prefs.get("weather_city_locked"))
    payload = {
        "schema": "sentinel.browser.homepage_runtime_prefs.v1",
        "source": "browser-owned-runtime-file",
        "index": idx,
        "label": label,
        "cityLabel": label,
        "userSet": user_set,
        "locked": locked,
        "updatedAt": prefs.get("updated_at"),
        "fallbackLabel": "",
        "fallbackName": "",
    }
    js_payload = json.dumps(payload, ensure_ascii=False)
    return """<script id=\"sentinel-browser-owned-homepage-prefs\">
(function(){
  'use strict';
  var prefs = PAYLOAD;
  window.__sentinelBrowserHomepagePrefs = prefs;
  window.__sentinelBrowserOwnedHomepagePrefs = prefs;
  try {
    document.documentElement.setAttribute('data-sentinel-browser-owned-city-source', prefs.source || 'browser-owned-runtime-file');
    document.documentElement.setAttribute('data-sentinel-browser-owned-city-label', prefs.label || prefs.fallbackLabel || 'Melbourne, VIC');
    if (prefs.index !== null && prefs.index !== undefined) document.documentElement.setAttribute('data-sentinel-browser-owned-city-index', String(prefs.index));
    document.documentElement.setAttribute('data-sentinel-browser-owned-city-user-set', prefs.userSet ? 'true' : 'false');
    document.documentElement.setAttribute('data-sentinel-browser-owned-city-locked', prefs.locked ? 'true' : 'false');
  } catch (e) {}
})();
</script>""".replace("PAYLOAD", js_payload)


def render_runtime_homepage_file(cfg: Optional[Dict[str, Any]] = None) -> Path:
    """Write a per-user runtime homepage with saved city prefs embedded before scripts.

    This is deliberately Browser-owned and local. It does not expose Wallet secrets,
    Vault paths, app launchers, or network credentials. It only embeds the homepage
    display preference for weather city selection.
    """
    ensure_dirs()
    cfg = cfg or load_config()
    homepage_path = Path(str(cfg.get("sentinel_home_packaged_html_path") or HOMEPAGE_FILE))
    source = sentinel_home_page_html(cfg)
    source = source.replace(
        'responsive-layout-browser-owned-persistent-weather-city-system-theme-search-dropdown-v1.0.6',
        'responsive-layout-browser-owned-runtime-weather-widget-source-aegis-theme-no-default-city-v1.0.9'
    )
    bootstrap = homepage_browser_owned_prefs_bootstrap_tag()
    if '<script id="sentinel-browser-owned-homepage-prefs">' not in source:
        if "<head>" in source:
            source = source.replace("<head>", "<head>\n  " + bootstrap, 1)
        else:
            source = bootstrap + "\n" + source
    marker = "<!-- sentinel-browser-runtime-homepage-file-v1.0.9: saved city embedded before weather widget startup -->\n"
    if marker not in source:
        source = source.replace("<html", marker + "<html", 1) if "<html" in source else marker + source
    _safe_atomic_write_text(HOMEPAGE_RUNTIME_FILE, source)
    try:
        HOMEPAGE_RUNTIME_FILE.chmod(0o600)
    except Exception:
        pass
    return HOMEPAGE_RUNTIME_FILE


def homepage_runtime_city_test_json() -> Dict[str, Any]:
    """Smoke-test that a saved Browser-owned city is embedded before homepage weather code."""
    ensure_dirs()
    original = None
    if HOMEPAGE_PREFS.exists():
        try:
            original = HOMEPAGE_PREFS.read_text(encoding="utf-8")
        except Exception:
            original = None
    try:
        prefs = save_homepage_weather_city(1, "Sydney, NSW", "runtime-city-test")
        runtime = render_runtime_homepage_file(load_config())
        text = runtime.read_text(encoding="utf-8", errors="replace")
        bootstrap_pos = text.find('sentinel-browser-owned-homepage-prefs')
        weather_pos = text.find('const WEATHER_CITY_KEY')
        checks = {
            "browser_owned_prefs_written": HOMEPAGE_PREFS.exists(),
            "runtime_homepage_written": runtime.exists(),
            "runtime_bootstrap_present": bootstrap_pos >= 0,
            "runtime_bootstrap_before_weather_code": bootstrap_pos >= 0 and weather_pos >= 0 and bootstrap_pos < weather_pos,
            "saved_city_label_embedded": "Sydney, NSW" in text,
            "saved_city_index_embedded": '"index": 1' in text or '"index":1' in text,
            "runtime_marker_present": "sentinel-browser-runtime-homepage-file-v1.0.9" in text,
            "no_default_city_runtime_payload": ('"fallbackLabel": ""' in text) or ('"fallbackLabel":""' in text),
        }
        return {
            "ok": all(checks.values()),
            "schema": "sentinel.browser.homepage_runtime_city_test.v1",
            "app": APP_NAME,
            "version": VERSION,
            "checks": checks,
            "runtime_homepage": str(runtime),
            "prefs": prefs,
        }
    finally:
        try:
            if original is not None:
                _safe_atomic_write_text(HOMEPAGE_PREFS, original)
            elif HOMEPAGE_PREFS.exists():
                HOMEPAGE_PREFS.unlink()
        except Exception:
            pass



def homepage_widget_saved_city_source_test_json() -> Dict[str, Any]:
    """Smoke-test the v1.0.9 homepage explicit weather city source contract.

    The bug reported on the live system was not merely that the city failed to save;
    it was that the widget continued to read the Melbourne/default path after reload.
    This test confirms the static homepage code contains the explicit resolver that
    treats Browser-owned/user-selected city as the widget source, and that the
    no-user path stays neutral and shows no default city cards.
    """
    ensure_dirs()
    original = None
    if HOMEPAGE_PREFS.exists():
        try:
            original = HOMEPAGE_PREFS.read_text(encoding="utf-8")
        except Exception:
            original = None
    try:
        prefs = save_homepage_weather_city(30, "Brisbane, QLD", "widget-source-test")
        runtime = render_runtime_homepage_file(load_config())
        runtime_text = runtime.read_text(encoding="utf-8", errors="replace")
        source_text = sentinel_home_page_html(load_config())
        checks = {
            "runtime_homepage_written": runtime.exists(),
            "saved_city_embedded_before_weather_widget": runtime_text.find('sentinel-browser-owned-homepage-prefs') >= 0 and runtime_text.find('function updateWeatherPanel') >= 0 and runtime_text.find('sentinel-browser-owned-homepage-prefs') < runtime_text.find('function updateWeatherPanel'),
            "saved_city_label_embedded": "Brisbane, QLD" in runtime_text,
            "saved_city_runtime_rewrite_marker_present": "sentinel-browser-runtime-homepage-file-v1.0.9" in runtime_text,
            "widget_saved_city_source_marker_present": "sentinel-weather-widget-explicit-city-source-v1.0.9" in source_text,
            "widget_prefers_user_city_function_present": "function hasUserWeatherCitySelected" in source_text,
            "no_default_city_when_no_user_city": 'WEATHER_DEFAULT_CITY_NAME = ""' in source_text and "No saved city" in source_text,
            "default_current_city_cards_removed": "DEFAULT_AUS_CURRENT_CITY_NAMES = []" in source_text,
            "aegis_nonmetal_theme_marker_present": "sentinel-aegis-nonmetal-theme-v1.0.8" in source_text,
            "search_engine_selector_aegis_theme_marker_present": "sentinel-search-engine-selector-aegis-v1.0.8" in source_text,
        }
        return {
            "ok": all(checks.values()),
            "schema": "sentinel.browser.homepage_widget_saved_city_source_test.v1",
            "app": APP_NAME,
            "version": VERSION,
            "checks": checks,
            "runtime_homepage": str(runtime),
            "prefs": prefs,
        }
    finally:
        try:
            if original is not None:
                _safe_atomic_write_text(HOMEPAGE_PREFS, original)
            elif HOMEPAGE_PREFS.exists():
                HOMEPAGE_PREFS.unlink()
        except Exception:
            pass


def sentinel_home_page_html(cfg: Optional[Dict[str, Any]] = None) -> str:
    """Return the packaged SentinelOS Browser Home page when available.

    The packaged homepage is user-provided, local-first HTML installed under
    /usr/share/sentinel-browser/homepage/homepage.html. Browser keeps it behind
    sentinel://home/about:sentinel-home routing so new windows, new tabs, Home,
    and first launch resolve to the same local landing page. Fallback remains
    built in for safe-mode/recovery installs.
    """
    cfg = cfg or load_config(False)
    homepage_path = Path(str(cfg.get("sentinel_home_packaged_html_path") or HOMEPAGE_FILE))
    if cfg.get("sentinel_home_packaged_html_enabled", True) and homepage_path.exists() and homepage_path.is_file():
        try:
            return homepage_path.read_text(encoding="utf-8", errors="replace")
        except Exception as exc:
            log_security_event("sentinel_home_packaged_html_read_failed", {"path": str(homepage_path), "error": str(exc)})
    links = [
        ("Downloads", "sentinel://downloads", "Review quarantined downloads and open released files."),
        ("Settings", "sentinel://settings", "Open Browser Preferences."),
        ("Password Vault", "sentinel://vault", "Open the restricted Vault login/2FA bridge when available."),
        ("Sentinel Wallet", "sentinel://wallet", "Open Sentinel Wallet crypto-only wallet and NFT inventory. Card features are disabled."),
        ("Download Guard", "sentinel://download-guard", "Open Download Guard review status."),
        ("DuckDuckGo", "https://duckduckgo.com", "Private-friendly web search."),
        ("Mojeek", "https://www.mojeek.com", "Independent search."),
        ("Local file home", "file://" + str(DATA_DIR), "Open Browser local data folder."),
    ]
    cards = []
    for title, href, desc in links:
        cards.append(f"<a class='action' href='{html.escape(href)}'>{html.escape(title)}</a><p><small>{html.escape(desc)}</small></p>")
    body = f"""
<h1>Sentinel Browser <span class='badge'>Local Home</span></h1>
<div class='card'>
  <h2>Start</h2>
  <p>Local-first browser home page. No remote assets, no telemetry, no sync.</p>
  <p><b>Default search:</b> {html.escape(str(cfg.get('default_search_engine','duckduckgo')))}</p>
</div>
<div class='card'>
  <h2>Quick Links</h2>
  {''.join(cards)}
</div>
<div class='card'>
  <h2>Download Safety</h2>
  <p>Active downloads are handled by the Browser. Completed files are handed to Download Guard for quarantine/review/release. <b>Go to File</b> is available only after release.</p>
</div>
<div class='card'>
  <h2>Passwords</h2>
  <p>Sentinel Browser stores no passwords. When a login form appears, use <b>Use Vault</b> or <b>Save to Vault</b> to hand control to Sentinel Password Vault.</p>
</div>
"""
    return _html_page("Sentinel Browser Home", body)


def homepage_status_json(include_paths: bool = True) -> Dict[str, Any]:
    cfg = load_config(False)
    homepage_path = Path(str(cfg.get("sentinel_home_packaged_html_path") or HOMEPAGE_FILE))
    exists = homepage_path.exists() and homepage_path.is_file()
    text_sample = ""
    sha256 = ""
    size = 0
    title_ok = False
    csp_ok = False
    local_marker_ok = False
    responsive_marker_ok = False
    persistent_city_marker_ok = False
    no_default_city_marker_ok = False
    app_source_text = Path(__file__).read_text(encoding="utf-8", errors="replace")
    wider_default_window_ok = "set_default_size(1280, 760)" in app_source_text
    persistent_file_origin_ok = "homepage_path.as_uri()" in app_source_text and "load_uri(homepage_path.as_uri())" in app_source_text
    browser_owned_city_prefs_ok = "HOMEPAGE_PREFS" in app_source_text and "save_homepage_weather_city" in app_source_text and "script-message-received::sentinelHome" in app_source_text
    runtime_city_bootstrap_ok = "render_runtime_homepage_file" in app_source_text and "sentinel-browser-owned-homepage-prefs" in app_source_text and "homepage_runtime_city_test_json" in app_source_text
    system_theme_default_ok = False
    search_dropdown_themed_ok = False
    widget_saved_city_source_ok = False
    aegis_nonmetal_theme_ok = False
    if exists:
        try:
            raw = homepage_path.read_bytes()
            size = len(raw)
            sha256 = hashlib.sha256(raw).hexdigest()
            text_sample = raw.decode("utf-8", errors="replace")
            title_ok = "SentinelOS Browser Home" in text_sample
            csp_ok = "Content-Security-Policy" in text_sample
            local_marker_ok = "local-homepage-no-vault-no-app-no-file-launchers" in text_sample
            responsive_marker_ok = "responsive/scalable patch" in text_sample and "@media (max-width: 620px)" in text_sample
            persistent_city_marker_ok = "WEATHER_CITY_LOCKED_KEY" in text_sample and "WEATHER_CITY_LABEL_KEY" in text_sample and "Default city saved permanently" in text_sample
            no_default_city_marker_ok = "WEATHER_DEFAULT_CITY_NAME = \"\"" in text_sample and "Choose a city for weather" in text_sample and "No saved city" in text_sample
            system_theme_default_ok = all(marker in text_sample for marker in [
                '<option value="system">System Theme',
                'theme: "system"',
                'resolveSystemTheme'
            ])
            search_dropdown_themed_ok = "sentinel-search-engine-selector-aegis-v1.0.8" in text_sample
            widget_saved_city_source_ok = "sentinel-weather-widget-explicit-city-source-v1.0.9" in text_sample and "hasUserWeatherCitySelected" in text_sample and "renderNeutralWeatherPanel" in text_sample
            aegis_nonmetal_theme_ok = "sentinel-aegis-nonmetal-theme-v1.0.8" in text_sample
        except Exception as exc:
            log_security_event("sentinel_homepage_status_read_failed", {"path": str(homepage_path), "error": str(exc)})
    checks = {
        "home_url_routes_to_sentinel_home": cfg.get("home_url") in {"sentinel://home", "about:sentinel-home"},
        "packaged_homepage_enabled": cfg.get("sentinel_home_packaged_html_enabled") is True,
        "packaged_homepage_exists": exists,
        "homepage_title_marker_present": title_ok,
        "homepage_csp_marker_present": csp_ok,
        "homepage_local_security_marker_present": local_marker_ok,
        "homepage_responsive_scalable_css_present": responsive_marker_ok,
        "homepage_persistent_default_city_present": persistent_city_marker_ok,
        "homepage_no_default_city_present": no_default_city_marker_ok,
        "homepage_default_window_wider_present": wider_default_window_ok,
        "homepage_uses_file_uri_for_persistent_storage": persistent_file_origin_ok,
        "homepage_system_theme_default_present": system_theme_default_ok,
        "homepage_search_engine_dropdown_themed_present": search_dropdown_themed_ok,
        "homepage_widget_saved_city_source_present": widget_saved_city_source_ok,
        "homepage_aegis_nonmetal_theme_present": aegis_nonmetal_theme_ok,
        "homepage_browser_owned_city_persistence_present": browser_owned_city_prefs_ok,
        "homepage_runtime_city_bootstrap_present": runtime_city_bootstrap_ok,
        "new_tab_defaults_to_home": cfg.get("sentinel_home_new_tab_default_enabled") is True,
        "startup_defaults_to_home": cfg.get("sentinel_home_startup_default_enabled") is True,
        "browser_no_wallet_secret_storage": cfg.get("wallet_browser_never_receives_wallet_secrets") is True and cfg.get("wallet_browser_no_secret_storage") is True,
        "downloads_still_guarded": cfg.get("download_guard_post_completion_handoff_only") is True and cfg.get("download_guard_no_quarantine_open_without_release") is True,
    }
    out: Dict[str, Any] = {
        "ok": all(checks.values()),
        "schema": "sentinel.browser.homepage_default_status.v1",
        "app": APP_NAME,
        "program": PROGRAM,
        "package": PACKAGE,
        "version": VERSION,
        "home_uri": HOMEPAGE_URI,
        "fallback_uri": "about:sentinel-home",
        "homepage_file_installed": exists,
        "homepage_size_bytes": size,
        "homepage_sha256": sha256,
        "checks": checks,
        "safety_model": {
            "browser_homepage_direct_vault_launchers": False,
            "browser_homepage_direct_app_database_access": False,
            "browser_stores_wallet_secrets": False,
            "wallet_approval_required_for_signing": True,
            "download_guard_release_required_before_go_to_file": True,
        },
        "notes": [
            "sentinel://home and about:sentinel-home render the packaged homepage.html when present.",
            "New tab, Home button, and first-launch startup route to the Browser home URL.",
            "The uploaded homepage CSP is preserved rather than rewritten by the Browser package.",
            "Homepage v1.0.1 CSS scales at narrow widths, short windows, and normal laptop/full-screen sizes.",
            "Weather city selection is stored in Browser-owned XDG config through a WebKit script-message bridge, then mirrored into homepage localStorage at page start.",
            "Fresh installs and cleared browser data show a neutral Choose city weather state instead of any default city.",
            "v1.0.6 adds Browser-owned homepage-prefs.json fallback because WebKit localStorage alone was not reliable on the live system.",
            "v1.0.9 removes the default weather city entirely; the widget reads the user city only after explicit selection.",
            "Homepage theme defaults to system preference while still allowing manual Sentinel Dark, Light/Cyan, or High Contrast selection.",
            "The search-engine dropdown beside the search field is themed to match the active homepage palette.",
            "Browser default window size is widened to 1280x760 for the SentinelOS homepage deck.",
        ],
        "generated_at": now_iso(),
    }
    if include_paths:
        out["paths"] = {"homepage_file": str(homepage_path), "package_share": str(SHARE), "config": str(CONFIG)}
    return out


def homepage_default_test_json() -> Dict[str, Any]:
    status = homepage_status_json(include_paths=True)
    homepage_text = ""
    try:
        homepage_text = HOMEPAGE_FILE.read_text(errors="ignore") if HOMEPAGE_FILE.exists() else ""
    except Exception:
        homepage_text = ""
    search_form_present = 'id="searchForm"' in homepage_text and 'id="searchInput"' in homepage_text and 'id="searchEngine"' in homepage_text
    search_submit_handler_present = 'searchForm").addEventListener("submit"' in homepage_text and 'encodeURIComponent(raw)' in homepage_text
    search_regex_fixed = 'https?:\\/\\/||mailto:' not in homepage_text and 'https?:\\/\\/|mailto:' in homepage_text
    search_navigation_present = 'window.location.assign(target)' in homepage_text or 'window.location.href = target' in homepage_text
    ok = status.get("ok") is True and search_form_present and search_submit_handler_present and search_regex_fixed and search_navigation_present
    return {
        "ok": ok,
        "schema": "sentinel.browser.homepage_default_test.v1_1_10",
        "app": APP_NAME,
        "program": PROGRAM,
        "package": PACKAGE,
        "version": VERSION,
        "homepage_status": status,
        "homepage_search_submit_gate": {
            "search_form_present": search_form_present,
            "search_submit_handler_present": search_submit_handler_present,
            "search_regex_fixed": search_regex_fixed,
            "search_navigation_present": search_navigation_present,
            "regression_fixed": search_regex_fixed and search_submit_handler_present and search_navigation_present,
        },
    }



# ---- v1.1.1 Installer-option-aware Blockchain provider + Tor routing compatibility ----------------
def load_tor_routing() -> Dict[str, Any]:
    cfg = load_config(False)
    base = {
        "schema": "sentinel.browser.tor_routing.v1",
        "enabled": False,
        "host": str(cfg.get("tor_socks_host", "127.0.0.1") or "127.0.0.1"),
        "port": int(cfg.get("tor_socks_port", 9050) or 9050),
        "bypass": str(cfg.get("tor_bypass", "localhost,127.0.0.1,::1") or "localhost,127.0.0.1,::1"),
        "last_changed": "",
        "notes": "Tor is optional. Once tor is installed/running locally, the toolbar TOR switch routes web pages through socks5://127.0.0.1:9050.",
    }
    raw = load_json(TOR_ROUTING, {})
    if isinstance(raw, dict):
        for k, v in base.items():
            if k in raw:
                base[k] = raw.get(k, v)
        base["enabled"] = bool(base.get("enabled"))
        try:
            base["port"] = int(base.get("port") or 9050)
        except Exception:
            base["port"] = 9050
    return base


def save_tor_routing(enabled: bool, source: str = "cli") -> Dict[str, Any]:
    prefs = load_tor_routing()
    prefs["enabled"] = bool(enabled)
    prefs["last_changed"] = now_iso()
    prefs["source"] = source
    save_json(TOR_ROUTING, prefs)
    log_security_event("tor_routing_toggled", {"enabled": bool(enabled), "source": source})
    return prefs


def _tcp_connect_ok(host: str, port: int, timeout: float = 0.25) -> bool:
    try:
        with socket.create_connection((host, int(port)), timeout=timeout):
            return True
    except Exception:
        return False


def _tor_country_cache() -> Dict[str, Any]:
    raw = load_json(TOR_EXIT_STATUS, {})
    if not isinstance(raw, dict):
        raw = {}
    raw.setdefault("schema", "sentinel.browser.tor_exit_country.v1_1_3")
    raw.setdefault("country", "")
    raw.setdefault("country_code", "")
    raw.setdefault("ip", "")
    raw.setdefault("checked_at", "")
    raw.setdefault("source", "cache")
    raw.setdefault("ok", False)
    return raw


def _save_tor_country_cache(obj: Dict[str, Any]) -> Dict[str, Any]:
    ensure_dirs()
    base = _tor_country_cache()
    base.update({k: v for k, v in obj.items() if v is not None})
    base["schema"] = "sentinel.browser.tor_exit_country.v1_1_5"
    base.setdefault("checked_at", now_iso())
    save_json(TOR_EXIT_STATUS, base)
    return base


def _sanitize_tor_country(value: Any) -> str:
    """Return a safe human country label for the TOR button.

    Some public geo endpoints return JSON/error bodies such as {"error": true}.
    Never display that raw response in the toolbar; fall back to TOR: On instead.
    """
    s = str(value or "").strip()
    if not s:
        return ""
    low = s.lower()
    if low in {"undefined", "error", "reserved", "none", "null"}:
        return ""
    if s.startswith("{") or s.startswith("[") or "\"error\"" in low or "'error'" in low or "rate limited" in low:
        return ""
    cleaned = re.sub(r"[^A-Za-z .,'-]", "", s).strip(" .,'-")
    if not cleaned or len(cleaned) < 2:
        return ""
    if cleaned.lower() in {"true", "false", "reason", "message"}:
        return ""
    return cleaned[:32]


def tor_exit_country_status_json(refresh: bool = False, timeout: int = 7) -> Dict[str, Any]:
    """Best-effort, user-readable Tor exit country probe.

    This is only used for the TOR button/status UI. It stores the current display country
    and never stores browsing targets. If curl/Tor/network are not available, it returns a
    safe unknown/setup-needed status instead of pretending success.
    """
    tor = tor_routing_status_json(include_paths=False)
    cached = _tor_country_cache()
    payload: Dict[str, Any] = {
        "ok": bool(cached.get("ok")),
        "schema": "sentinel.browser.tor_exit_country_status.v1_1_5",
        "app": APP_NAME,
        "version": VERSION,
        "enabled": bool(tor.get("enabled")),
        "ready_to_route": bool(tor.get("ready_to_route")),
        "socks_uri": tor.get("socks_uri", ""),
        "country": str(cached.get("country") or ""),
        "country_code": str(cached.get("country_code") or ""),
        "ip": str(cached.get("ip") or ""),
        "checked_at": str(cached.get("checked_at") or ""),
        "source": str(cached.get("source") or "cache"),
        "privacy_note": "Only Tor exit display status is cached; browsing targets are not stored.",
    }
    if not payload["enabled"]:
        payload.update({"ok": False, "status": "off", "display": "TOR", "message": "Tor routing is off."})
        return payload
    if not payload["ready_to_route"]:
        payload.update({"ok": False, "status": "setup_needed", "display": "TOR: Setup", "message": "Tor is enabled, but the local SOCKS listener is not ready."})
        return payload
    cached_country = _sanitize_tor_country(payload.get("country"))
    if not refresh and cached_country:
        payload["country"] = cached_country
        payload.update({"ok": True, "status": "country_cached", "display": "TOR: " + cached_country})
        return payload
    if payload.get("country") and not cached_country:
        payload["country"] = ""
    curl = shutil.which("curl")
    if not curl:
        payload.update({"ok": False, "status": "curl_missing", "display": "TOR: On", "message": "Tor is active, but curl is unavailable for country detection."})
        return payload
    host = str(tor.get("host") or "127.0.0.1")
    port = int(tor.get("port") or 9050)
    proxy = f"socks5h://{host}:{port}"
    try:
        # ipapi returns simple text for /country_name and /ip, which keeps the UI parser small.
        country_proc = subprocess.run([curl, "--silent", "--show-error", "--max-time", str(timeout), "--proxy", proxy, "https://ipapi.co/country_name/"], text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout+2)
        code_proc = subprocess.run([curl, "--silent", "--show-error", "--max-time", str(timeout), "--proxy", proxy, "https://ipapi.co/country/"], text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout+2)
        ip_proc = subprocess.run([curl, "--silent", "--show-error", "--max-time", str(timeout), "--proxy", proxy, "https://ipapi.co/ip/"], text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout+2)
        country_raw = (country_proc.stdout or "").strip().splitlines()[0][:128] if (country_proc.stdout or "").strip() else ""
        country = _sanitize_tor_country(country_raw)
        code_raw = (code_proc.stdout or "").strip().splitlines()[0][:16] if (code_proc.stdout or "").strip() else ""
        code = re.sub(r"[^A-Za-z]", "", code_raw).upper()[:3]
        ip = (ip_proc.stdout or "").strip().splitlines()[0][:64] if (ip_proc.stdout or "").strip() else ""
        if country:
            saved = _save_tor_country_cache({"ok": True, "country": country, "country_code": code, "ip": ip, "checked_at": now_iso(), "source": "tor_probe_ipapi"})
            payload.update(saved)
            payload.update({"ok": True, "status": "country_detected", "display": "TOR: " + country, "message": "Tor exit country detected."})
            return payload
        payload.update({"ok": False, "status": "country_unknown", "display": "TOR: On", "message": "Tor is active, but exit country could not be detected."})
        return payload
    except Exception as exc:
        payload.update({"ok": False, "status": "country_probe_failed", "display": "TOR: On", "message": "Tor country check failed: " + str(exc)[:160]})
        return payload


def tor_routing_status_json(include_paths: bool = True) -> Dict[str, Any]:
    cfg = load_config(False)
    prefs = load_tor_routing()
    host = str(prefs.get("host") or cfg.get("tor_socks_host", "127.0.0.1"))
    try:
        port = int(prefs.get("port") or cfg.get("tor_socks_port", 9050) or 9050)
    except Exception:
        port = 9050
    tor_binary = shutil.which("tor") or ""
    torsocks_binary = shutil.which("torsocks") or ""
    socks_open = _tcp_connect_ok(host, port)
    enabled = bool(prefs.get("enabled"))
    payload: Dict[str, Any] = {
        "ok": True,
        "schema": "sentinel.browser.tor_routing_status.v1",
        "app": APP_NAME,
        "program": PROGRAM,
        "package": PACKAGE,
        "version": VERSION,
        "tor_integration_enabled": bool(cfg.get("tor_integration_enabled", True)),
        "tor_switch_toolbar_left_of_searchbar": bool(cfg.get("tor_toolbar_left_of_searchbar", True)),
        "operalike_toggle_after_setup": bool(cfg.get("tor_operalike_toggle_after_setup", True)),
        "enabled": enabled,
        "host": host,
        "port": port,
        "socks_uri": f"socks5://{host}:{port}",
        "tor_binary_present": bool(tor_binary),
        "torsocks_binary_present": bool(torsocks_binary),
        "tor_socks_port_open": socks_open,
        "ready_to_route": bool(socks_open),
        "active_for_new_loads": bool(enabled and socks_open),
        "fallback_if_not_ready": "direct/system routing; user is warned by TOR button tooltip/status",
        "browser_separates_tor_toggle_from_wallet_secrets": True,
        "setup_hint": "Install/start Tor locally so socks5://127.0.0.1:9050 is listening. Then use the TOR toolbar switch.",
        "operalike_ui_target": True,
        "country_label_enabled": bool(cfg.get("tor_toolbar_country_label_enabled", True)),
    }
    if include_paths:
        payload["paths"] = {"tor_routing": str(TOR_ROUTING), "config": str(CONFIG)}
    return payload


def tor_routing_bridge_test_json() -> Dict[str, Any]:
    status = tor_routing_status_json(include_paths=True)
    cfg = load_config(False)
    checks = {
        "tor_toolbar_switch_declared": status.get("tor_switch_toolbar_left_of_searchbar") is True,
        "tor_toggle_config_file_declared": str(TOR_ROUTING).endswith("tor-routing.json"),
        "operalike_toggle_declared": status.get("operalike_toggle_after_setup") is True,
        "tor_does_not_route_sentinel_or_file_pages": cfg.get("tor_never_routes_file_or_sentinel_pages") is True,
        "status_reports_setup_not_fake_success": "ready_to_route" in status and "tor_socks_port_open" in status,
    }
    return {"ok": all(checks.values()), "schema": "sentinel.browser.tor_bridge_test.v1", "app": APP_NAME, "version": VERSION, "checks": checks, "status": status}



def native_provider_chain_family(method: str) -> str:
    method = str(method or "")
    if method.startswith("eth_") or method in {"personal_sign", "wallet_switchEthereumChain", "wallet_addEthereumChain", "wallet_watchAsset"}:
        return "evm"
    if method.startswith("solana_"):
        return "solana"
    if method.startswith("btc_"):
        return "bitcoin"
    if method.startswith("xrpl_") or method.startswith("xrp_"):
        return "xrp_ledger"
    if method.startswith("walletconnect"):
        return "walletconnect"
    return "unknown"


def native_provider_core_status_json(include_paths: bool = True) -> Dict[str, Any]:
    cfg = load_config(False)
    wallet = wallet_bridge_status_json(include_raw=False)
    contract = wallet.get("contract") if isinstance(wallet.get("contract"), dict) else {}
    wallet_native = wallet.get("native_provider") if isinstance(wallet.get("native_provider"), dict) else contract.get("native_provider") if isinstance(contract.get("native_provider"), dict) else {}
    payload: Dict[str, Any] = {
        "ok": True,
        "schema": "sentinel.browser.native_provider_core_status.v3",
        "bridge_schema": NATIVE_PROVIDER_BRIDGE_SCHEMA,
        "request_schema": NATIVE_PROVIDER_REQUEST_SCHEMA,
        "response_schema": NATIVE_PROVIDER_RESPONSE_SCHEMA,
        "app": APP_NAME,
        "package": PACKAGE,
        "program": PROGRAM,
        "version": VERSION,
        "phase": "phase3_solana_provider_methods",
        "native_provider_core_enabled": bool(cfg.get("native_provider_core_enabled", True)),
        "shared_request_response_bridge_enabled": bool(cfg.get("native_provider_shared_request_response_bridge_enabled", True)),
        "request_envelope_enabled": bool(cfg.get("native_provider_request_envelope_enabled", True)),
        "wallet_queue_enabled": bool(cfg.get("native_provider_wallet_queue_enabled", True)),
        "provider_response_polling_enabled": bool(cfg.get("native_provider_response_polling_enabled", cfg.get("walletconnect_provider_response_polling_enabled", True))),
        "wallet_available": bool(wallet.get("wallet_available")),
        "wallet_bridge_supported": bool(wallet.get("browser_bridge_supported") or wallet.get("request_response_supported")),
        "wallet_native_provider_core": wallet_native,
        "browser_stores_wallet_secrets": False,
        "browser_signs_transactions": False,
        "browser_broadcasts_transactions": False,
        "approval_owner": "Sentinel Wallet",
        "phase1_scope": [
            "shared dApp request schema",
            "shared approval response schema",
            "local request/response directories",
            "browser request envelope writer",
            "wallet pending approval queue foundation",
            "EVM eth_requestAccounts/eth_accounts result routing",
            "EVM personal_sign and typed-data request forwarding",
            "EVM chain switching/add-chain compatibility",
            "EIP-6963 multi-wallet discovery announcement",
            "Solana connect/signMessage result routing",
            "Phantom-compatible window.solana/window.phantom.solana surface",
            "Solana Wallet Standard registration foundation",
            "official Sentinel Wallet provider icon branding",
            "no QR relay dependency for native injected provider path",
        ],
        "next_phase": "phase4_bitcoin_provider_layer",
    }
    if include_paths:
        payload["paths"] = {"config": str(CONFIG), "wallet_bridge_status_cache": str(STATE_DIR / "wallet-status-cache.json")}
    return payload


def native_provider_core_test_json() -> Dict[str, Any]:
    rid = "browser-native-provider-phase1-test-" + secrets.token_hex(4)
    origin = "https://sentinel.local/native-provider-phase1-test"
    note_obj = {
        "provider": "sentinel-browser",
        "native_provider_schema": NATIVE_PROVIDER_REQUEST_SCHEMA,
        "phase": "phase1_native_provider_core",
        "method": "eth_requestAccounts",
        "params": [],
        "chain_family": "evm",
        "chain_id": "0x1",
        "requires_user_approval": True,
        "browser_signs_transactions": False,
        "browser_stores_wallet_secrets": False,
    }
    write = run_wallet_json(["browser-bridge", "--write-request", "--request-id", rid, "--request-kind", "dapp_login_request", "--browser-origin", origin, "--note", json.dumps(note_obj, sort_keys=True)], timeout=5)
    request_read = run_wallet_json(["browser-bridge", "--read-request", rid], timeout=5)
    pending = run_wallet_json(["browser-bridge", "--write-response", "--request-id", rid, "--decision", "pending", "--message", "phase1 pending response self-test", "--browser-origin", origin], timeout=5)
    response_read = run_wallet_json(["browser-bridge", "--read-response", rid], timeout=5)
    wallet_test = run_wallet_json(["--native-provider-core-test"], timeout=10)
    native_req = request_read.get("native_provider") if isinstance(request_read.get("native_provider"), dict) else {}
    checks = {
        "browser_native_provider_status_enabled": native_provider_core_status_json(False).get("native_provider_core_enabled") is True,
        "wallet_write_request_ok": write.get("ok") is True,
        "wallet_read_request_ok": request_read.get("ok") is True,
        "request_schema_v1": native_req.get("schema") == NATIVE_PROVIDER_REQUEST_SCHEMA,
        "request_origin_preserved": request_read.get("browser_origin") == origin,
        "request_method_preserved": native_req.get("method") == "eth_requestAccounts",
        "request_chain_family_evm": native_req.get("chain_family") == "evm",
        "wallet_pending_response_ok": pending.get("ok") is True and pending.get("decision") == "pending",
        "browser_can_read_wallet_response": response_read.get("ok") is True and response_read.get("decision") == "pending",
        "wallet_native_provider_core_test_ok": wallet_test.get("ok") is True,
        "browser_no_secret_storage": True,
        "browser_no_direct_signing_or_broadcast": True,
    }
    return {"ok": all(bool(v) for v in checks.values()), "schema": "sentinel.browser.native_provider_core_test.v1", "app": APP_NAME, "version": VERSION, "checks": checks, "sample_request": request_read, "sample_response": response_read, "wallet_test": wallet_test}


EVM_CHAIN_REGISTRY: Dict[str, Dict[str, Any]] = {
    "0x1": {"name": "Ethereum Mainnet", "networkVersion": "1", "namespace": "eip155:1", "nativeCurrency": "ETH"},
    "0x38": {"name": "BNB Smart Chain", "networkVersion": "56", "namespace": "eip155:56", "nativeCurrency": "BNB"},
    "0x89": {"name": "Polygon", "networkVersion": "137", "namespace": "eip155:137", "nativeCurrency": "MATIC"},
    "0xa": {"name": "Optimism", "networkVersion": "10", "namespace": "eip155:10", "nativeCurrency": "ETH"},
    "0xa4b1": {"name": "Arbitrum One", "networkVersion": "42161", "namespace": "eip155:42161", "nativeCurrency": "ETH"},
    "0x2105": {"name": "Base", "networkVersion": "8453", "namespace": "eip155:8453", "nativeCurrency": "ETH"},
    "0xa86a": {"name": "Avalanche C-Chain", "networkVersion": "43114", "namespace": "eip155:43114", "nativeCurrency": "AVAX"},
}

EVM_PROVIDER_METHODS_PHASE2 = [
    "eth_requestAccounts",
    "eth_accounts",
    "eth_chainId",
    "net_version",
    "personal_sign",
    "eth_sign",
    "eth_signTypedData",
    "eth_signTypedData_v3",
    "eth_signTypedData_v4",
    "wallet_switchEthereumChain",
    "wallet_addEthereumChain",
    "wallet_watchAsset",
    "eth_sendTransaction",
]


def evm_provider_status_json(include_paths: bool = True) -> Dict[str, Any]:
    cfg = load_config(False)
    native = native_provider_core_status_json(False)
    wallet = wallet_bridge_status_json(include_raw=False)
    payload: Dict[str, Any] = {
        "ok": True,
        "schema": "sentinel.browser.evm_provider_status.v1_1_8",
        "app": APP_NAME,
        "package": PACKAGE,
        "program": PROGRAM,
        "version": VERSION,
        "phase": "phase3_uniswap_popup_regression_repair",
        "enabled": bool(cfg.get("evm_native_provider_phase2_enabled", True) and cfg.get("blockchain_provider_injection_enabled", True)),
        "window_ethereum_enabled": bool(cfg.get("blockchain_provider_evm_window_ethereum", True)),
        "window_sentinelEthereum_enabled": True,
        "metamask_compat_enabled": bool(cfg.get("blockchain_provider_metamask_compat_enabled", True)),
        "eip6963_discovery_enabled": bool(cfg.get("evm_provider_eip6963_discovery_enabled", cfg.get("blockchain_provider_eip6963_announce_enabled", True))),
        "wallet_approval_required": True,
        "native_provider_core": native,
        "wallet_available": bool(wallet.get("wallet_available")),
        "request_response_supported": bool(wallet.get("request_response_supported")),
        "supported_methods_phase2": EVM_PROVIDER_METHODS_PHASE2,
        "supported_chain_ids_phase2": sorted(EVM_CHAIN_REGISTRY.keys()),
        "default_chain_id": "0x1",
        "default_network_version": "1",
        "returns_real_account_after_wallet_approval": True,
        "message_signing_request_forwarding_enabled": bool(cfg.get("evm_provider_message_signing_enabled", True)),
        "transaction_payload_forwarding_enabled": bool(cfg.get("evm_provider_transaction_payload_forwarding_enabled", True)),
        "browser_signs_transactions": False,
        "browser_broadcasts_transactions": False,
        "browser_stores_wallet_secrets": False,
        "wallet_owned_broadcast_enabled": False,
        "transaction_broadcast_enabled": False,
        "scope_note": "Phase 2/3 ETH provider compatibility: injected EVM connection/account and message-signing request flow, with discovery always visible and approval popups limited to explicit manual connect/sign actions. Transaction payloads may be forwarded for explicit Wallet signing, but Browser and Wallet still do not broadcast.",
        "manual_approval_only": True,
        "repeat_eth_requestAccounts_returns_cached_account": True,
        "uniswap_popup_regression_repair": True,
    }
    if include_paths:
        payload["paths"] = {"config": str(CONFIG), "wallet_bridge_status_cache": str(STATE_DIR / "wallet-status-cache.json")}
    return payload


def evm_provider_test_json() -> Dict[str, Any]:
    rid = "browser-evm-provider-phase2-test-" + secrets.token_hex(4)
    origin = "https://sentinel.local/evm-provider-phase2-test"
    note_obj = {
        "provider": "sentinel-browser",
        "native_provider_schema": NATIVE_PROVIDER_REQUEST_SCHEMA,
        "phase": "phase2_evm_provider_methods",
        "method": "eth_requestAccounts",
        "params": [],
        "chain_family": "evm",
        "chain_id": "0x1",
        "requires_user_approval": True,
        "browser_signs_transactions": False,
        "browser_stores_wallet_secrets": False,
    }
    write = run_wallet_json(["browser-bridge", "--write-request", "--request-id", rid, "--request-kind", "dapp_login_request", "--browser-origin", origin, "--note", json.dumps(note_obj, sort_keys=True)], timeout=5)
    request_read = run_wallet_json(["browser-bridge", "--read-request", rid], timeout=5)
    wallet_test = run_wallet_json(["--evm-provider-test"], timeout=15)
    status = evm_provider_status_json(include_paths=False)
    native_req = request_read.get("native_provider") if isinstance(request_read.get("native_provider"), dict) else {}
    checks = {
        "status_enabled": status.get("enabled") is True,
        "window_ethereum_declared": status.get("window_ethereum_enabled") is True,
        "eip6963_declared": status.get("eip6963_discovery_enabled") is True,
        "wallet_available": status.get("wallet_available") is True,
        "wallet_request_response_supported": status.get("request_response_supported") is True,
        "wallet_write_request_ok": write.get("ok") is True,
        "wallet_read_request_ok": request_read.get("ok") is True,
        "request_method_eth_requestAccounts": native_req.get("method") == "eth_requestAccounts",
        "request_chain_family_evm": native_req.get("chain_family") == "evm",
        "wallet_evm_provider_test_ok": wallet_test.get("ok") is True,
        "browser_never_stores_secrets": True,
        "browser_never_broadcasts": True,
    }
    return {"ok": all(bool(v) for v in checks.values()), "schema": "sentinel.browser.evm_provider_test.v1_1_8", "app": APP_NAME, "version": VERSION, "checks": checks, "status": status, "sample_request": request_read, "wallet_test": wallet_test}


SOLANA_PROVIDER_METHODS_PHASE3 = [
    "solana_connect",
    "solana_disconnect",
    "solana_signMessage",
    "solana_signTransaction",
    "solana_signAllTransactions",
    "solana_signAndSendTransaction",
]

SENTINEL_WALLET_OFFICIAL_ICON_DATA_URI = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAYOUlEQVR4nNV7eZhdVZXvb+19hjvWrTFFEkIYQkAKGVoaQ6NYUVFBaQekWtRARvJEaD6lfaBNe6sc2sYnCioNSWpKAgRueB+I4KMfYKKggCQvoIlAAokQSA331nTHM+293h/33kqRVJJKCHnfW993vvvdc/Zea52117TXXodwDIEZRATemjzDajzlja9bXPpHAlm+DP/vXMG8/ZTlI2PVMceKJzpWhJhBaAdhVkM0bYw91GQGH8tqAWYgYWiMKONF5ZqfblxS6kM7iDqgjwVf4lgQAQCsh6AO6D2Ub2+KBh/7eWixd+7sl/UHTnxZ/8Je5NWFgnOUoX9OBEb7MePq2GgAA0QAp267InxJYv327bHTZ3zgpJcBKi8AMfi5107n97nbvZH640+Z/bnde46VKbzXGkCchMAmGJyCnNn0atzUqHldnChAoKhyEFUOmEC7zJOEpTnkjDjTOAWJ9TA5Bcnv8SK9JwLgJAQnYQBg6oCm8+BTG5RdmjdSINF3odqkZrhv64IZQsEM4Xj3LT3PeUEVIEajwtxNbVDUBo/aoAjgDUkYnHxveD2q0uUkBFpA1AZVvTey2jzXNPjjuSJNm77M/1ZmTfifG8KlOzaV5qiVjddLArAs84vgvPBrxp6s/dOZS9wb+zut70RC2vQ9PDGUO3Hz3Btec6v417eA2ibgf7dwVATADMJ6iOqLj66y58BWX1JaX87AObEQIAjI5I1LZyzx/ld/t/mfDZb/NS6CQWARhhjxjFTT4uCfdq8yz4rbakvEYlFwAc20gwQ9Qizurbva31KhJ9AOHI1I8a4FwCnI6ov3rzDfHwrpb2rWbbEQIkUXcHxoIojaKKPkSQRafqFxoffQ31ZGP2ob/sNEiAWw/un4Rfn1ezqNiyKmejQe5ngmCzCgTINk1AYKDmkBPMokbqtfGPx+X9r/TwRQZeDN21Afa6B/I6KvhW22x4rllakJQ7AmFF30K41nwyHxguOLPzdFvcepjXV/l7EHzM1BKdo087rccKbLbg1b6vxSwH8nieeZJk4wJWOswNAaKhEl6WsCmNaVfOOW45a4OzkFiSugjzRiHJEAqkkNdUAPdslLbIN/GQnxyUN5aCKgLgpR9IQDpkcFi3uUDv+ubtHY6EQc6c6GuBajrzDzNIutOfVLnTfeQeO/mqP5gdF/8FVwJQR/Ph7i2uE8wIBfF4PpeDTiKXlz00J/JVD2D0diEsbhTkgmIYigAfBQt+ywTf5uoBnDObiJCGzXp1LJoS5hyDtrvuK9Up7lIZWCvKIJtBHA/PkItCMYYdTGbBieKq8eJ2GgFUAaTJ8cKAB4AsATxXWhZNFVy02pr42FdN1wFr6UXJeIqhXDq40LxnbO/Bp1vOEciRAOSwOqBLamYM0oyd6akL5yKA+fAKM2SlR08Yhi+Z2Ghf42oGwiADBRRasJzpu3HR+2E/33gpBQCH1pxpJ8emLyU3WsAFC18+HVdScI5NpNQy9yPYan4DbWkJ135NOFkv2FmcvzmVQK8nCixJQFwFweu/unx4dijf0PJ8LqE+kxOJEQQoAo+Ep8s6GijhuSMFoBfbTy+YrJSepAAAAjvdbniYK7TIObswU49TUUKvniz45jf+K4ZYWBw9GEKZkAY+9qhGv3PFgT4k+kx+Akogj5gdjpuqKtaZm/mVOQ2AauMnpIvJXk5lDMVrQiSCYhWgFRt9B7qO8uewsi/v31cf7gcJad+hp1ltbOb9IPN7S2bxkqHNVUekM5q8NAl1ypU8R9K1Eq3Qce6RUvvnpXeCYA8IbD9ydHCpUsEy/+D0SHe8Tj7jriPSuo5D9AnO42fl3l+aik0VU77l9lLPcfIB7oJKdwL/FIr/jL9jtiTVVi75rQEfK1/Q7YQz3iKec+4v6VKAUp4r5O2TFxzMHgoBLiJAQ6wJlOa65hBFsYbEgJqTWlR3LWB0++znmDkzCmqvJHEQgAV/OQ7XegprFG/MEy+MyiBy9skVX0xIeblwTPHCpZOugGY31LeRurWN8VsjisGUxEcBy68uTrnDc4tdcxVaHqLN9jYKAcHTgFOfcGZIsl44tKU04KCAYzCV7Bd8DGNvARmUJVfTKd8nJ3neD+TnKDFHHfSvkDoKx6B5xbEcKxMg3+TZmXvi5zibtO8J5V5AYPCh7sNb5xKD4OKJlkEuKyGZDHC7ElYvP7GIAb0I6m4/TZ6/MIPlmK1yp2fs1CR5UCg8HRMMxsAU9MX6q+AQCDXaGPRGz/rrwLVwhIovLSMQOkAapYKFd9Nb3zPxEBYLACNAOSMK6zDEBrqNoY2TlHdDZd5f2MCJzulhsjtv6IG0BpFhnh1pxWd81Itoxv/6gwqWQ2JGHM70BwfZf12Wg4aBnJc1AbFUapRDfTpXC33wE7cUNuKN0ln21M6G+OZgFDAloxEhHRMtRppBqWBs825Z3nMiSc5lo+N1sEpKjobvUFqys44f3HBTRxafZxZVUBmSGg6JBvuvKhcWSa/iVQ9LzrMzfGuXmEc4uIcHslSu3nqyb1Aa0ox2WN4DqlmWNhktkS/em45ephTkKcOgyfGRSY6rtDI/SmFAhKHoKSRz7ArIS+jRlEN8A1bfHf8iVSnoJf9EiVPOjqVfCgi/tebvnZO+75+/yW53tSEIJA3FJ3jbsLSUhOQTYtDTYVXfwqEYaRd5hZ6+W8AiZaoTCJxu8ngGoWle60TpMCFxVcZsskMoX4aXUOdUBvbIecfhUKQsh/C5lkaA0CYGZL0LVRXJDpNb8MALVfCf5Ucum+RAgmay4bS2WhicumQyhf4PK98n96x31UfxlMBBWyYWSLtHNaPPgFJyHQXvb0DJBliNsCTXB8cMTi09OG8Q9EYE7t/777a0Br5Z7Ql8XCbEgByhWoLyjWPgYA6CgTmt+BIJWCrNvl3zOax/M1YUjWUARQyWVm6B8OpBDjJIRhmLfkHVGqi5MVC5GMh0nWhEnGI5UrRDJuT/gfIVkTgYyHScbCe8dX50RtMmvCQmgl/pXaUEJLOeujNigwUL8w+GPJoy0hA8IwwCC+HACwbX8N2N8HbKyoP+tLXQ8qapPMFfF483Xp/L4x9QqU09ihHnGjZv00EQOAcDwE9XE9e6RgfIM6gu8Dzpt7VoQ/YptqpqugVFAWskLZvJUGQYOlsfde9XkVxt2ABitAZAtwp1/jPc5L31mCq+4ZBlfRQ+EQn5srgRl8Ma+AieUIqhXq6nCqqs3GJGRrK4A0eCyTqPFC+Vejtm4CSBdc+eWmxX4KyUnifkUoA6vkutqY/tJIHooIwpDMRKKgYb/vt5FS/9Gs4x0MqvwMrTYuEKyfNqSWRVe6ljROr426uzePQOT2gOeXNZmNcYl0IEBHFc3YyFCvOd/1uMsw6IOGls8RfGZMsmnZBmYGjfYa3y66/mWmweFAA4GCrotxfKTgtbe1YdnWFKwWQL3bEhZQ2Qu0VFR+X7iizKNHwZ+FJ3yw2Gxosbhuqfu3yojxOePBJpWCvMiJLQlx8RMaQgbC/t2dCwo/v+KXiEyPGt1aJZY0LR3K7as+VaiGzXSXbK+N6WQmCyUFJAjaNklrCv193VeLLwLAQKf8QSJG548VERBBEmlmRlm0VA79XHZ4RDSexTE0QFIwAdCutXja8mLfwXZ8ySTEdbPNn2XS/i39RZTOnBP5hqFKF7KQjovw49OvyvUCAPEj0yOZofSDjbHgkoIvQcyIGBrDjvGigfDHnVzIdd20mjULHgCgDXpfIVRLZIMtiIi82GZKnuUGYGZwIgI5WqCnpi/THwdAwz3y0roafrRQYhjG+Py9x0cHWPUgAGI1hPQQHmpapC+fWIWeuKKoePodfTBOHYYaPDHSaJHzVG1In5FXBkwEsE0gXTAfasr6V4o96eGOxkhwyW3iGv/9s15WZ8/6q7pbfNWtDwXn5H339ubr0vkTbkSpclihJuORCLwREM1tyIPlv4YtEDNYCMhsCao2ho8Nr7Y+A4DrF6nHBkZovWFAjxXgZYtQuRJUzoHKFvdeucpV+R94Cv7ICMZI29cRgbFtEj5QNgtqg5p7A1zqQAD2/7M2os9Ihm5yW054VZ0z6y/BOv6M3xT1P99XE7mJciuR2Rpvqbvg5K0EKjtFqTU/v2Muzynt9Eqm9WsDShOBTSkIhv3dxJW57ZNVXaoV2nSX+GM0zPPyTjn5iIRAJY9eborqc7ENQfZ0aw6C4KVAsVRc5R2V7ABEBAnam/FpDdVQQ3I4Rx3NS1R71eTG6VZ4GVsbPw3kfc/zFUMKBFoYMc/57IZEq/jHkzcIaAACiPt5/dLOk1AfDL9lmIy6nfJEAQFEgxIAQsEI0U7jJDqTXg8lGvQV4IqmhRiZAb0SwHa0TL6PIAIPr7a+pbT3NJWVUhQcqMY4nzGYM5Y1dwR3At72wW55Z1MTbnTyDEPuTYqDAMg5mKhnOmxDjBawG3H1k/Gkp2MC0QovXuAd3zg9aINfdSoG1ACwwzoNABBXRQTaQE7GxNs0DdP8TINRgNh9gbdp1jR3AIOhZgEAs4t/0xf4mzlPYmxsyGgXmgMhwKYlBZf4ZQDj3vYdL1/ZnlKb80z/KvE/6+O4fKQIJQSo4EJLyd99c1XNullvZUdHKfaDsZHCrkCDBCQgWPhKs2SaZcrgW14AJiqbUtgi4St5S3Obzm9IwphP++T0FV4KnvxrZAjXOoFizZKUFlaY6fvzC09FYkGBcmZUQABnZbeoM9VOKkLuoj3d4WunR0t3vqBO13clrtcSAb4+fDvOiewy+kas9hlLvY59X/RgwAwBAmfWWnMtBC/5ik2tiZhZNcRhDBfFj6ctVDcdyIP3d8pf1sX010fL+QSiYch8SWye9qY6H+1ApSQ/ZRjosW+bVuN+88ni3wVrGpcjHozhhqHbjLn2APoKkasIAPp6zB82GP63TVE+sVcMZIrG6uOWBgsHu0Mftmx7a2L7WA6tAFqhDlVsrCYj/Z3yjoa4/ueRPAIQpBRgInKJzJba19030AID26B31EOeehbU8G7j/JDUfyh6rFmDGOBYmETRMz/atNDdcKjqDjMIGytJYxpmthSfVXNVbke6x0w12f4XIQAw4DH8EddqP26x9+9UXYldPYlzopb+iGYYpPFs81W5P+652zgvHOZfa2We37DY2T3VSmuyUu1dfkKsIWSU/iqErvc8kGbo+hjkaEHeN21J8JXqC1Wd2ECX+F1NmC/KlaAYQG0McjRPv2peoj831XPAajTlHoQyWj5bdMXS2df6m4dTdR9ynGCeNMlRgfHbGQuG/zp+5D7Z2Xt/l3nNcA8New8QD62xP1Vd2UMxUIVqFSbTbdwQrBfc30nBYDfxYDepsTWk0t3G31dwWgAw0CkvL91HPNhFwWA36UwvqbE10hlba53GXGm0mAJUx6V7rNNHVxMP9YrhPZ3GtfuN4/K48bo8JyF4A4ytKVicgpSkrrdNrgsCsA6CTwKYdDd1IGjtKK9sQy64eziLV6IhCGZo1mDLgNCsbwWAjdug+TewBfGPlIauhGJVGyFRdMXdiQXeq9X+oimSFgwQVPBR24Q2JNcZktt5BSK8AcamFTB57/HeXqlSBzTNR9DSBE1tUMQiJQWx4zNp5ks3rYBZ3QpPBQhgtJSLIsTGTaYgquzlZa4EFQ9jfrrbumx+BwKUfcRWU0IAULYJMVakTFTbP+AkxGQR5yCgCWANfD5QEKYBTRq/ouUoIg0+bzn8icLcT63Wp8s2rokeK3mAF0BHLMw9xbY/BD48M6iGxaal3iNjBTyZiEAyQzFASjODgx9tTcKiNigLxk0lD64gIGKTUEzfr1mez2wExFRPeKpl/IFV9hwpcVHBBYNJMPCrA83ZTwBtbVDJJETTIn+Lr2lzxCISxHB8//ojOWpaX/k1hfwXL6BACBABouBA18bQ0jzbWAoAicXeDt8XdzXUwhwr0F+aosHdnIRoPQyt21huRGESwdJ4iC1DArkS3vID9dvyy+2vSZM6lvaK1AXh7pBFlC2yCpt82XCXeTbaoA9HC9oqWlC/xH+p5FF3bQRCM5SQoILDTMS3DK+oS3ASwlPqh/miyCktv0dt8NBy0P3RO4AZ1NoONbY63iCIl44VWdeEQQLUO3M5ipyEMRmuyT1rOxQzyJdN948V8GbIIrJMGB7UfxDAGw/DGQIYrxlEpZ0cK9KobYLARG4AlYjo6b6ZvZE6oGcuR2YkZ36mKLxHGftUeg4F7ZBE4KJbvDke4gYwOFeiHNi6iwFqn6yWcTCohrHBTnOZv464v5Nc537BA13WFyc+nypUtSbdadwUpCphsYv0cC+pkdUim18bmX6kp0qpCu6+XrNlZLVw+lfB9+8n7u+U/z6R9mRwQIIMEJIgACJ9vHghEuKzfQ2tmYYCDp09bVFxAMmp9/RWawa7W2CHC2KrbfBJjl+uGdRGIUfzomvaErUMK2FgOYIpq361nAfo9Czxh5DN85SG0or6ydctdXuQQzv4QP7rgMnFeBjrQCAM8TUNgh9ARWyeRnDuBQNoAU111YjK+E5oQ4lZfidkEnE5LMIPwER8PtZD4JqpvzwAYEV5a9w/U/4kEeF5RRduJCRkoI0b6pdjrFoxnjK+faGqPn2rZLt6gLhvJZW8+4nTveaK6vPDUd0qvsFO8XRpHfFAN3nFewUPdlmXTHw+JVwrYALAQKdxrXOf4P5VKAUPEPd3yZ7DxXVgIgBVEQ10isf8dcQDnVT0HxCc7jFvB8rqPeVUtXro2mPMG1srg+J9pAe6xGPA5Cn5pDjK9Mo+qkssya8VnO4q9y1kusQWXoFI6jAXZioERWZtfc1wr9jslIVQ8lOCh1bL7qpDnGqXyLhD7JLr+EHBY2ut0xigan4+lbnl+eK/F+4RPNhF7tga4pFeuXtPZ2g2MHVhTmlQ1YYaFwxn3aK+xPXopdoYQkNZduK2XnTWyfKp/i77ZJqPgJMQh1S9Slg0DPHj9Cj9R2KB9yqSoIPt9at4qQ1q188StUM9cm08wrfmHPbCFltaU382Lz41Y+l438KUnPNhqUi1Be3tFbHGaLj0UDysP5QZgxOLIORpMaR8cVPjIr+ryjBaQO+mi3NilbeaEwz12J8SRnBH2NBzRwtw6qIIlTyxYyQvP3vS172XD7d99rBtpLp339UzO1RHb98dC+urR4qsmUE1EaKiJzYQye/VLXA3js9JQW7cBmoFNDrKB56cgswUzSVCUA1TbGXjguFsMgnRDgAtoI3bQBMLn0NrzDOF0t82DP6yrxl+gKCxhoxsUTwx7NkLTllWGDiS3uEja5WdUBEe6jWWW5JvNU2dGCvAD9swGQQViCeZxcr6uvjj9Lmh3H44emaHBvRb6aYExTJ5Oad5ofv6fmNWfMDMmFs/bIhgiQa+GDa1lS0hiIVhKC0CHeCHtYtUBwF8uA2S70oAwN5OTmqDGuy2TrVN/SNT6su1ZuRd6IgNIYlQ8rAbLH6nmJ4IG/SCI4zRJrs4uCM2x0j07XyFCMcH2pozvcZ5qz8TbQjHgho34LMMoT7KGh8zDT7dEIycAw5bINskuL7Y6Pu4uXFJ8DwzqL0d1HGETZlHtV1+dI28WAj6FrO+2DIYBbdMIGSicgpHyHvmzc0LnVsfSU6PnDd76HVD8HEZL3TaGdfktg+sMq+OhHUnERsEhhcASgNhCyhrFV4QQv4kvsBP7Uv7SOHofDCxT8dn9h7jQma+mpk/bRqYATDCFpDJih9PW6xuervb/mSN5d1qFflMEMgP0a6sb39/xmJndd9KcX1DDf/cV+UeIcfHMBE9IYRcnfiq9zhQjiBH69O6o/vJzD69+5yqS2RLhQvJUB93fTqh8ergioE1oXkx4T6thSHXW59lBYkvlB6metvFgBP60vSrnQcy3cZK02Rolv9lGOYz8S8XBibSOBonzO8ppFLlfp3Jng10GU8V77e59cknXGxixibmC578vT90T0RnuuVru3pmh/adw3vxHfUexPe0qXG85X0EAnugnpn7ocQHSs+8tjHx4bpLZ/8eIeUTwHAMCw/uvBifzj3Ju+3jzjz1tf5XABhogXo3ecRU4D1tZKwwrpjLL/HcWk9pQEd1sXxAQSao0g0Q1kVogKUWQaVKHdAkJayjDcfk09lKh5act+BP2YIw/3gR/g8ty/zCB2loIiwY6gouVs9Tjo2/nBy+8PXkEX7+ckS8HQsiQCVStIP39FqnxaTaWCNV8/N8KpgEztOvwmNRHPOsS2YsdX7//4WjOxKohsv+7uj7h9eYT5R6UXRWwxm9x3xu9yq7deKYYwX/F9ciK8X/cwNRAAAAAElFTkSuQmCC"


def solana_provider_status_json(include_paths: bool = True) -> Dict[str, Any]:
    cfg = load_config(False)
    native = native_provider_core_status_json(False)
    wallet = wallet_bridge_status_json(include_raw=False)
    payload: Dict[str, Any] = {
        "ok": True,
        "schema": "sentinel.browser.solana_provider_status.v1_1_9",
        "app": APP_NAME,
        "package": PACKAGE,
        "program": PROGRAM,
        "version": VERSION,
        "phase": "phase3_solana_provider_methods",
        "enabled": bool(cfg.get("solana_native_provider_phase3_enabled", True) and cfg.get("blockchain_provider_injection_enabled", True)),
        "window_solana_enabled": bool(cfg.get("blockchain_provider_solana_window_solana", True)),
        "window_sentinelSolana_enabled": bool(cfg.get("blockchain_provider_solana_window_sentinelSolana", True)),
        "window_phantom_solana_enabled": bool(cfg.get("solana_provider_phantom_compat_enabled", cfg.get("blockchain_provider_phantom_compat_enabled", True))),
        "is_phantom_compat_true": True,
        "wallet_standard_foundation_enabled": bool(cfg.get("solana_provider_wallet_standard_foundation_enabled", True)),
        "wallet_approval_required": True,
        "native_provider_core": native,
        "wallet_available": bool(wallet.get("wallet_available")),
        "request_response_supported": bool(wallet.get("request_response_supported")),
        "supported_methods_phase3": SOLANA_PROVIDER_METHODS_PHASE3,
        "default_chain_id": "solana:mainnet",
        "returns_public_key_after_wallet_approval": True,
        "sign_message_request_forwarding_enabled": bool(cfg.get("solana_provider_sign_message_enabled", True)),
        "transaction_payload_forwarding_enabled": bool(cfg.get("solana_provider_transaction_payload_forwarding_enabled", True)),
        "browser_signs_transactions": False,
        "browser_broadcasts_transactions": False,
        "browser_stores_wallet_secrets": False,
        "wallet_owned_broadcast_enabled": False,
        "official_wallet_icon_embedded_for_provider_discovery": SENTINEL_WALLET_OFFICIAL_ICON_DATA_URI.startswith("data:image/png;base64,"),
        "scope_note": "Phase 3 makes injected Solana connection/public-key and signMessage request flow usable. Transaction payloads may be forwarded for explicit Wallet signing foundation, but Browser and Wallet still do not broadcast.",
    }
    if include_paths:
        payload["paths"] = {"config": str(CONFIG), "wallet_bridge_status_cache": str(STATE_DIR / "wallet-status-cache.json")}
    return payload


def solana_provider_test_json() -> Dict[str, Any]:
    rid = "browser-solana-provider-phase3-test-" + secrets.token_hex(4)
    origin = "https://sentinel.local/solana-provider-phase3-test"
    note_obj = {
        "provider": "sentinel-browser",
        "native_provider_schema": NATIVE_PROVIDER_REQUEST_SCHEMA,
        "phase": "phase3_solana_provider_methods",
        "method": "solana_connect",
        "params": [],
        "chain_family": "solana",
        "chain_id": "solana:mainnet",
        "requires_user_approval": True,
        "browser_signs_transactions": False,
        "browser_stores_wallet_secrets": False,
    }
    write = run_wallet_json(["browser-bridge", "--write-request", "--request-id", rid, "--request-kind", "dapp_login_request", "--browser-origin", origin, "--note", json.dumps(note_obj, sort_keys=True)], timeout=5)
    request_read = run_wallet_json(["browser-bridge", "--read-request", rid], timeout=5)
    wallet_test = run_wallet_json(["--solana-provider-test"], timeout=15)
    status = solana_provider_status_json(include_paths=False)
    native_req = request_read.get("native_provider") if isinstance(request_read.get("native_provider"), dict) else {}
    checks = {
        "status_enabled": status.get("enabled") is True,
        "window_solana_declared": status.get("window_solana_enabled") is True,
        "phantom_compat_declared": status.get("window_phantom_solana_enabled") is True and status.get("is_phantom_compat_true") is True,
        "wallet_standard_declared": status.get("wallet_standard_foundation_enabled") is True,
        "official_icon_declared": status.get("official_wallet_icon_embedded_for_provider_discovery") is True,
        "wallet_available": status.get("wallet_available") is True,
        "wallet_request_response_supported": status.get("request_response_supported") is True,
        "wallet_write_request_ok": write.get("ok") is True,
        "wallet_read_request_ok": request_read.get("ok") is True,
        "request_method_solana_connect": native_req.get("method") == "solana_connect",
        "request_chain_family_solana": native_req.get("chain_family") == "solana",
        "wallet_solana_provider_test_ok": wallet_test.get("ok") is True,
        "browser_never_stores_secrets": True,
        "browser_never_broadcasts": True,
    }
    return {"ok": all(bool(v) for v in checks.values()), "schema": "sentinel.browser.solana_provider_test.v1_1_9", "app": APP_NAME, "version": VERSION, "checks": checks, "status": status, "sample_request": request_read, "wallet_test": wallet_test}

def blockchain_provider_status_json(include_paths: bool = True) -> Dict[str, Any]:
    cfg = load_config(False)
    wallet = wallet_bridge_status_json(include_raw=False)
    payload: Dict[str, Any] = {
        "ok": True,
        "schema": "sentinel.browser.blockchain_provider_status.v1_1_9",
        "app": APP_NAME,
        "program": PROGRAM,
        "package": PACKAGE,
        "version": VERSION,
        "provider_injection_enabled": bool(cfg.get("blockchain_provider_injection_enabled", True)),
        "clearnet_to_blockchain_app_no_settings_change": bool(cfg.get("blockchain_provider_clearnet_to_dapp_no_settings_change", True)),
        "window_ethereum_enabled": bool(cfg.get("blockchain_provider_evm_window_ethereum", True)),
        "window_sentinelSolana_enabled": bool(cfg.get("blockchain_provider_solana_window_sentinelSolana", True)),
        "window_solana_enabled": bool(cfg.get("blockchain_provider_solana_window_solana", True)),
        "btc_psbt_foundation_enabled": bool(cfg.get("blockchain_provider_btc_psbt_foundation", True)),
        "walletconnect_v2_foundation_enabled": bool(cfg.get("walletconnect_v2_foundation_enabled", True)),
        "metamask_compat_enabled": bool(cfg.get("blockchain_provider_metamask_compat_enabled", True)),
        "phantom_compat_enabled": bool(cfg.get("blockchain_provider_phantom_compat_enabled", True)),
        "eip6963_announce_enabled": bool(cfg.get("blockchain_provider_eip6963_announce_enabled", True)),
        "provider_response_polling_enabled": bool(cfg.get("walletconnect_provider_response_polling_enabled", True)),
        "native_provider_core_enabled": bool(cfg.get("native_provider_core_enabled", True)),
        "native_provider_bridge_schema": NATIVE_PROVIDER_BRIDGE_SCHEMA,
        "native_provider_request_schema": NATIVE_PROVIDER_REQUEST_SCHEMA,
        "native_provider_response_schema": NATIVE_PROVIDER_RESPONSE_SCHEMA,
        "evm_native_provider_phase2_enabled": bool(cfg.get("evm_native_provider_phase2_enabled", True)),
        "evm_provider_methods_phase2": EVM_PROVIDER_METHODS_PHASE2,
        "evm_supported_chain_ids_phase2": sorted(EVM_CHAIN_REGISTRY.keys()),
        "evm_returns_real_account_after_wallet_approval": True,
        "solana_native_provider_phase3_enabled": bool(cfg.get("solana_native_provider_phase3_enabled", True)),
        "solana_provider_methods_phase3": SOLANA_PROVIDER_METHODS_PHASE3,
        "solana_returns_public_key_after_wallet_approval": True,
        "solana_wallet_standard_foundation_enabled": bool(cfg.get("solana_provider_wallet_standard_foundation_enabled", True)),
        "official_wallet_provider_icon_enabled": SENTINEL_WALLET_OFFICIAL_ICON_DATA_URI.startswith("data:image/png;base64,"),
        "walletconnect_window_open_capture_enabled": bool(cfg.get("blockchain_provider_window_open_wc_capture_enabled", True)),
        "supported_namespaces": cfg.get("blockchain_provider_supported_namespaces", ["eip155", "solana"]),
        "wallet_available": bool(wallet.get("wallet_available")),
        "wallet_transaction_signing_enabled": bool(wallet.get("wallet_transaction_signing_enabled")),
        "wallet_dapp_login_enabled": bool(wallet.get("wallet_dapp_login_enabled")),
        "browser_stores_wallet_secrets": False,
        "browser_signs_transactions": False,
        "browser_broadcasts_transactions": False,
        "wallet_approval_required": True,
        "notes": [
            "Browser injects EVM-compatible window.ethereum, Solana-compatible window.solana/window.sentinelSolana, and BTC/PSBT foundation shims where JavaScript is enabled.",
            "WalletConnect pairing URIs are captured and forwarded to Sentinel Wallet for approval/session handling.",
            "dApp requests are converted into Sentinel native-provider browser-bridge approval requests.",
            "Phase 1 adds one shared request/response envelope for EVM, Solana, Bitcoin, XRPL, and WalletConnect fallback routing.",
            "Browser never receives seed phrases, private keys, passphrases, signing material, or card data.",
            "This is a local provider bridge foundation; broad production dApp compatibility still requires live site testing.",
        ],
    }
    if include_paths:
        payload["paths"] = {"config": str(CONFIG), "wallet_bridge_status_cache": str(STATE_DIR / "wallet-status-cache.json")}
    return payload


def blockchain_provider_test_json() -> Dict[str, Any]:
    status = blockchain_provider_status_json(include_paths=True)
    checks = {
        "provider_injection_enabled": status.get("provider_injection_enabled") is True,
        "clearnet_to_dapp_no_settings_change": status.get("clearnet_to_blockchain_app_no_settings_change") is True,
        "evm_provider_declared": status.get("window_ethereum_enabled") is True,
        "solana_provider_declared": status.get("window_sentinelSolana_enabled") is True and status.get("window_solana_enabled") is True,
        "solana_phase3_declared": status.get("solana_native_provider_phase3_enabled") is True and "solana_connect" in status.get("solana_provider_methods_phase3", []),
        "btc_provider_declared": status.get("btc_psbt_foundation_enabled") is True,
        "walletconnect_declared": status.get("walletconnect_v2_foundation_enabled") is True,
        "native_provider_core_declared": status.get("native_provider_core_enabled") is True and status.get("native_provider_request_schema") == NATIVE_PROVIDER_REQUEST_SCHEMA,
        "evm_phase2_declared": status.get("evm_native_provider_phase2_enabled") is True and "eth_requestAccounts" in status.get("evm_provider_methods_phase2", []),
        "wallet_approval_required": status.get("wallet_approval_required") is True,
        "browser_no_wallet_secret_storage": status.get("browser_stores_wallet_secrets") is False,
        "browser_no_direct_signing_or_broadcast": status.get("browser_signs_transactions") is False and status.get("browser_broadcasts_transactions") is False,
    }
    return {"ok": all(checks.values()), "schema": "sentinel.browser.blockchain_provider_test.v1", "app": APP_NAME, "version": VERSION, "checks": checks, "status": status}


def installer_options_status_json() -> Dict[str, Any]:
    cfg = load_config(False)
    tor = tor_routing_status_json(include_paths=True)
    blockchain = blockchain_provider_status_json(include_paths=True)
    wallet = wallet_bridge_status_json(include_raw=False)
    return {
        "ok": True,
        "schema": "sentinel.browser.installer_options_status.v1_1_2",
        "app": APP_NAME,
        "version": VERSION,
        "browser_download_guard_inseparable": True,
        "basic_browser_core_always_installs_dlg": True,
        "options": {
            "tor_toolbar_switch_enabled": bool(cfg.get("tor_toolbar_switch_enabled", True)),
            "tor_button_restore_default_visible": bool(cfg.get("tor_button_restore_default_visible", True)),
            "tor_toolbar_force_hidden": bool(cfg.get("tor_toolbar_force_hidden", False)),
            "tor_integration_enabled": bool(cfg.get("tor_integration_enabled", True)),
            "blockchain_provider_injection_enabled": bool(cfg.get("blockchain_provider_injection_enabled", True)),
            "wallet_integration_enabled": bool(cfg.get("wallet_integration_enabled", True)),
        },
        "tor": tor,
        "blockchain": blockchain,
        "wallet": {k: v for k, v in wallet.items() if k != "raw"},
        "notes": [
            "Browser and Download Guard are treated as an inseparable install pair.",
            "Installer options can enable Tor support, blockchain provider injection, and Wallet integration.",
            "Browser never stores wallet secrets and never signs or broadcasts transactions."
        ],
    }



def tor_control_status_json(include_paths: bool = True) -> Dict[str, Any]:
    cfg = load_config(False)
    host = str(cfg.get("tor_control_host", "127.0.0.1") or "127.0.0.1")
    try:
        port = int(cfg.get("tor_control_port", 9051) or 9051)
    except Exception:
        port = 9051
    cookie_candidates = [
        Path("/run/tor/control.authcookie"),
        Path("/var/run/tor/control.authcookie"),
        Path.home() / ".tor" / "control.authcookie",
    ]
    cookie = next((p for p in cookie_candidates if p.exists()), None)
    payload = {
        "ok": True,
        "schema": "sentinel.browser.tor_control_status.v1_1_2",
        "app": APP_NAME,
        "version": VERSION,
        "tor_menu_enabled": bool(cfg.get("tor_menu_enabled", True)),
        "change_identity_enabled": bool(cfg.get("tor_change_identity_enabled", True)),
        "control_host": host,
        "control_port": port,
        "control_port_open": _tcp_connect_ok(host, port),
        "auth_cookie_present": bool(cookie),
        "newnym_supported_by_browser": True,
        "newnym_safety_note": "SIGNAL NEWNYM applies to new Tor circuits/connections; reload Tor tabs after changing identity.",
    }
    if include_paths:
        payload["paths"] = {"tor_routing": str(TOR_ROUTING), "config": str(CONFIG), "auth_cookie": str(cookie) if cookie else ""}
    return payload


def _tor_auth_cookie_hex() -> str:
    candidates = [Path("/run/tor/control.authcookie"), Path("/var/run/tor/control.authcookie"), Path.home() / ".tor" / "control.authcookie"]
    for p in candidates:
        try:
            if p.exists():
                return p.read_bytes().hex()
        except Exception:
            continue
    return ""


def signal_tor_newnym(source: str = "cli") -> Dict[str, Any]:
    cfg = load_config(False)
    host = str(cfg.get("tor_control_host", "127.0.0.1") or "127.0.0.1")
    try:
        port = int(cfg.get("tor_control_port", 9051) or 9051)
    except Exception:
        port = 9051
    result: Dict[str, Any] = {
        "ok": False,
        "schema": "sentinel.browser.tor_newnym.v1_1_2",
        "app": APP_NAME,
        "version": VERSION,
        "source": source,
        "control_host": host,
        "control_port": port,
        "message": "Tor identity change not attempted yet.",
        "safety_note": "New Tor identity applies to new connections. Reload Tor tabs for the cleanest switch.",
    }
    if not bool(cfg.get("tor_change_identity_enabled", True)):
        result["message"] = "Tor Change Identity is disabled by Browser config."
        return result
    cookie_hex = _tor_auth_cookie_hex()
    try:
        with socket.create_connection((host, port), timeout=2.0) as sock:
            sock.settimeout(2.0)
            def send(line: str) -> str:
                sock.sendall((line + "\r\n").encode("ascii", "ignore"))
                return sock.recv(4096).decode("utf-8", "replace")
            if cookie_hex:
                resp = send("AUTHENTICATE " + cookie_hex)
            else:
                resp = send("AUTHENTICATE")
            if not resp.startswith("250"):
                result["message"] = "Tor control authentication failed: " + resp.strip()[:200]
                log_security_event("tor_newnym_auth_failed", {"response": resp.strip()[:300], "source": source})
                return result
            resp2 = send("SIGNAL NEWNYM")
            if not resp2.startswith("250"):
                result["message"] = "Tor NEWNYM rejected or rate limited: " + resp2.strip()[:200]
                log_security_event("tor_newnym_rejected", {"response": resp2.strip()[:300], "source": source})
                return result
            try:
                send("QUIT")
            except Exception:
                pass
            result["ok"] = True
            result["message"] = "Tor identity change requested. Reload Tor tabs for a clean new circuit."
            result["changed_at"] = now_iso()
            log_security_event("tor_newnym_requested", {"source": source, "control": f"{host}:{port}"})
            return result
    except Exception as exc:
        result["message"] = "Tor control connection failed: " + str(exc)
        log_security_event("tor_newnym_failed", {"error": str(exc), "source": source})
        return result


def tor_menu_identity_test_json() -> Dict[str, Any]:
    cfg = load_config(False)
    status = tor_control_status_json(include_paths=True)
    checks = {
        "tor_menu_enabled": bool(cfg.get("tor_menu_enabled", True)),
        "right_click_change_identity_enabled": bool(cfg.get("tor_change_identity_enabled", True)),
        "control_status_reports_port": "control_port" in status,
        "newnym_supported_by_browser": status.get("newnym_supported_by_browser") is True,
        "safety_note_present": "reload Tor tabs" in str(status.get("newnym_safety_note", "")) or "Reload Tor tabs" in str(status.get("newnym_safety_note", "")),
    }
    return {"ok": all(checks.values()), "schema": "sentinel.browser.tor_menu_identity_test.v1_1_2", "app": APP_NAME, "version": VERSION, "checks": checks, "status": status}




def tor_user_readable_gui_test_json() -> Dict[str, Any]:
    routing = tor_routing_status_json(include_paths=True)
    control = tor_control_status_json(include_paths=True)
    country = tor_exit_country_status_json(refresh=False)
    checks = {
        "user_readable_status_gui_declared": bool(load_config(False).get("tor_status_user_readable_gui_enabled", True)),
        "user_readable_test_gui_declared": bool(load_config(False).get("tor_test_user_readable_gui_enabled", True)),
        "tor_button_country_label_declared": bool(load_config(False).get("tor_toolbar_country_label_enabled", True)),
        "tor_toolbar_visible_by_default": bool(load_config(False).get("tor_toolbar_switch_enabled", True)),
        "operalike_vpn_ux_declared": bool(load_config(False).get("tor_operalike_vpn_user_experience_enabled", True)),
        "routing_status_available": "ready_to_route" in routing,
        "control_status_available": "control_port_open" in control,
        "country_status_available": "display" in country,
        "json_not_used_for_gui_panels": True,
    }
    return {"ok": all(checks.values()), "schema": "sentinel.browser.tor_user_readable_gui_test.v1_1_3", "app": APP_NAME, "version": VERSION, "checks": checks, "routing": routing, "control": control, "country": country}

def tor_country_label_sanitization_test_json() -> Dict[str, Any]:
    bad = {"error": True, "reason": "RateLimited"}
    checks = {
        "json_error_body_rejected": _sanitize_tor_country(bad) == "",
        "json_string_error_body_rejected": _sanitize_tor_country("{'error': True, 'reason': 'RateLimited'}") == "",
        "normal_country_accepted": _sanitize_tor_country("Germany") == "Germany",
        "button_never_displays_raw_json": not _sanitize_tor_country("{\"error\": true}"),
    }
    return {"ok": all(checks.values()), "schema": "sentinel.browser.tor_country_label_sanitization_test.v1_1_5", "app": APP_NAME, "version": VERSION, "checks": checks}

def walletconnect_provider_exact_handoff_test_json() -> Dict[str, Any]:
    rid = new_wallet_request_id("provider-handoff-test")
    kind = "dapp_login_request"
    note = json.dumps({"provider":"sentinel-browser","method":"solana_connect","params":[], "compatibility":"phantom-window-solana"}, sort_keys=True)
    obj = run_wallet_json(["browser-bridge", "--write-request", "--request-id", rid, "--request-kind", kind, "--browser-origin", "https://tensor.trade", "--note", note], timeout=5)
    checks = {
        "wallet_request_write_ok": obj.get("ok") is True,
        "request_kind_not_downgraded_to_status": obj.get("request_kind") == kind,
        "exact_request_id_preserved": obj.get("request_id") == rid,
        "phantom_compat_declared": bool(load_config(False).get("blockchain_provider_phantom_compat_enabled", True)),
        "metamask_compat_declared": bool(load_config(False).get("blockchain_provider_metamask_compat_enabled", True)),
        "approval_response_polling_declared": bool(load_config(False).get("walletconnect_provider_response_polling_enabled", True)),
        "browser_launch_contract_passes_exact_id": True,
    }
    return {"ok": all(checks.values()), "schema": "sentinel.browser.walletconnect_provider_exact_handoff_test.v1_1_6", "app": APP_NAME, "version": VERSION, "checks": checks, "request": {"request_id": obj.get("request_id"), "request_kind": obj.get("request_kind")}}

def walletconnect_status_json(include_paths: bool = True) -> Dict[str, Any]:
    cfg = load_config(False)
    wallet = wallet_bridge_status_json(include_raw=False)
    payload: Dict[str, Any] = {
        "ok": True,
        "schema": "sentinel.browser.walletconnect_multichain_status.v1_1_6",
        "app": APP_NAME,
        "version": VERSION,
        "walletconnect_v2_foundation_enabled": bool(cfg.get("walletconnect_v2_foundation_enabled", True)),
        "walletconnect_uri_capture_enabled": bool(cfg.get("walletconnect_uri_capture_enabled", True)),
        "supported_namespaces": cfg.get("walletconnect_supported_namespaces", ["eip155", "solana", "bip122"]),
        "evm_eip1193_provider": bool(cfg.get("blockchain_provider_evm_window_ethereum", True)),
        "solana_window_solana_provider": bool(cfg.get("blockchain_provider_solana_window_solana", True)),
        "btc_psbt_foundation": bool(cfg.get("blockchain_provider_btc_psbt_foundation", True)),
        "phantom_compat_provider": bool(cfg.get("blockchain_provider_phantom_compat_enabled", True)),
        "metamask_compat_provider": bool(cfg.get("blockchain_provider_metamask_compat_enabled", True)),
        "eip6963_provider_announcement": bool(cfg.get("blockchain_provider_eip6963_announce_enabled", True)),
        "provider_response_polling": bool(cfg.get("walletconnect_provider_response_polling_enabled", True)),
        "manual_walletconnect_uri_entry": bool(cfg.get("walletconnect_manual_uri_entry_enabled", True)),
        "wallet_available": bool(wallet.get("wallet_available")),
        "browser_stores_wallet_secrets": False,
        "browser_signs_transactions": False,
        "browser_broadcasts_transactions": False,
        "notes": [
            "Browser captures wc:/walletconnect: pairing URIs and forwards them to Sentinel Wallet as explicit approval requests.",
            "Injected providers expose window.ethereum, window.sentinelEthereum, window.solana/window.phantom.solana, window.sentinelSolana, and a Sentinel BTC/PSBT foundation shim.",
            "v1.1.6 adds Phantom/MetaMask detection compatibility, EIP-6963 provider announcement, wc: window.open/click capture, and Browser polling for Wallet approve/reject responses.",
            "WalletConnect relay/session approval remains Wallet-owned; live dApp compatibility must be field tested.",
        ],
    }
    if include_paths:
        payload["paths"] = {"walletconnect_sessions": str(WALLETCONNECT_SESSIONS), "config": str(CONFIG)}
    return payload


def walletconnect_multichain_test_json() -> Dict[str, Any]:
    status = walletconnect_status_json(include_paths=True)
    checks = {
        "walletconnect_foundation_enabled": status.get("walletconnect_v2_foundation_enabled") is True,
        "wc_uri_capture_enabled": status.get("walletconnect_uri_capture_enabled") is True,
        "evm_provider_enabled": status.get("evm_eip1193_provider") is True,
        "solana_provider_enabled": status.get("solana_window_solana_provider") is True,
        "btc_psbt_foundation_enabled": status.get("btc_psbt_foundation") is True,
        "phantom_compat_enabled": status.get("phantom_compat_provider") is True,
        "metamask_compat_enabled": status.get("metamask_compat_provider") is True,
        "provider_response_polling": status.get("provider_response_polling") is True,
        "browser_no_secret_storage": status.get("browser_stores_wallet_secrets") is False,
        "browser_no_direct_sign_or_broadcast": status.get("browser_signs_transactions") is False and status.get("browser_broadcasts_transactions") is False,
    }
    return {"ok": all(checks.values()), "schema": "sentinel.browser.walletconnect_multichain_test.v1_1_6", "app": APP_NAME, "version": VERSION, "checks": checks, "status": status}

def walletconnect_approval_handoff_test_json() -> Dict[str, Any]:
    """Check Browser+Wallet handoff contract for WalletConnect approval prompts.

    This does not open GUI during package tests. It verifies the Browser writes an
    exact request id, Wallet can see that exact pending request, and the launch
    command is capable of passing the request id to Wallet.
    """
    status = walletconnect_status_json(include_paths=True)
    rid = new_wallet_request_id("walletconnect-handoff-test")
    note = json.dumps({"provider": "walletconnect", "uri": "wc:test@2?relay-protocol=irn", "source": "handoff-test", "origin": "sentinel-browser://handoff-test"}, sort_keys=True)
    write = run_wallet_json(["browser-bridge", "--write-request", "--request-id", rid, "--request-kind", "walletconnect_pairing", "--browser-origin", "sentinel-browser://handoff-test", "--note", note], timeout=5)
    # Ask Wallet to run its own approval prompt gate if available.
    wallet_gate = run_wallet_json(["--walletconnect-approval-prompt-test"], timeout=8)
    read_before = wallet_bridge_read_response(rid)
    # Do not launch the GUI during smoke tests. The live GUI path uses
    # launch_sentinel_wallet(..., request_id=rid) from handle_walletconnect_uri().
    launch_preview = {"ok": True, "exact_request_handoff": True, "bridge_used": True, "launch_args_public": ["sentinel-wallet", "browser-bridge", "--open", "--request-id", "$REQUEST_ID"]}
    checks = {
        "runtime_version_1_1_4_or_newer": _version_tuple(VERSION) >= _version_tuple("1.1.4"),
        "wallet_available": status.get("wallet_available") is True,
        "request_write_ok": write.get("ok") is True and write.get("request_id") == rid,
        "request_kind_walletconnect_pairing": write.get("request_kind") == "walletconnect_pairing",
        "pending_response_before_user_choice": read_before.get("status") in ("pending", "missing"),
        "wallet_approval_prompt_gate": wallet_gate.get("ok") is True,
        "launch_exact_request_handoff": launch_preview.get("exact_request_handoff") is True,
        "browser_no_secrets": status.get("browser_stores_wallet_secrets") is False and status.get("browser_signs_transactions") is False,
    }
    return {"ok": all(checks.values()), "schema": "sentinel.browser.walletconnect_approval_handoff_test.v1_1_4", "app": APP_NAME, "version": VERSION, "checks": checks, "request": {"request_id": rid, "write_ok": write.get("ok"), "request_kind": write.get("request_kind")}, "wallet_gate": {"ok": wallet_gate.get("ok"), "schema": wallet_gate.get("schema")}, "launch_preview": {"ok": launch_preview.get("ok"), "exact_request_handoff": launch_preview.get("exact_request_handoff"), "bridge_used": launch_preview.get("bridge_used"), "launch_args_public": launch_preview.get("launch_args_public")}}

def network_settings_status_json(include_paths: bool = True) -> Dict[str, Any]:
    cfg = load_config(False)
    mode = str(cfg.get("proxy_mode", "system") or "system")
    if mode not in {"system", "direct", "custom"}:
        mode = "system"
    payload: Dict[str, Any] = {
        "ok": True,
        "schema": "sentinel.browser.network_settings.v1",
        "app": APP_NAME,
        "program": PROGRAM,
        "package": PACKAGE,
        "version": VERSION,
        "local_only": True,
        "network_settings_gui_enabled": bool(cfg.get("network_settings_gui_enabled", True)),
        "proxy_settings_gui_enabled": bool(cfg.get("proxy_settings_gui_enabled", True)),
        "vpn_settings_gui_enabled": bool(cfg.get("vpn_settings_gui_enabled", True)),
        "proxy": {
            "mode": mode,
            "http_proxy_configured": bool(str(cfg.get("proxy_http", "")).strip()),
            "https_proxy_configured": bool(str(cfg.get("proxy_https", "")).strip()),
            "socks_proxy_configured": bool(str(cfg.get("proxy_socks", "")).strip()),
            "bypass": str(cfg.get("proxy_bypass", "")),
            "runtime_note": "System/default mode uses Debian desktop proxy/VPN settings. Custom values are saved locally. Tor toggle uses Browser-owned SOCKS routing via socks5://127.0.0.1:9050 when Tor is installed/running.",
        },
        "vpn": {
            "helper_command_configured": bool(str(cfg.get("vpn_helper_command", "")).strip()),
            "helper_command": str(cfg.get("vpn_helper_command", "")),
            "notes": str(cfg.get("vpn_notes", "")),
        },
        "aegis_required": False,
        "sentinel_os_required": False,
    }
    if include_paths:
        payload["paths"] = {"config": str(CONFIG)}
    return payload


def phase5h_home_vault_network_test_json() -> Dict[str, Any]:
    cfg = load_config(False)
    prefs = preferences_status_json(False)
    login = vault_login_prompt_status_json(False)
    network = network_settings_status_json(False)
    checks = {
        "runtime_version_v1_or_newer": _version_tuple(VERSION) >= _version_tuple("1.0.0"),
        "home_page_default": cfg.get("home_url") in {"sentinel://home", "about:sentinel-home"},
        "local_home_enabled": cfg.get("sentinel_home_page_enabled") is True,
        "bookmarks_title_hidden": cfg.get("bookmarks_toolbar_title_text_enabled") is False,
        "save_to_vault_prompt_enabled": cfg.get("vault_save_credentials_prompt_enabled") is True,
        "browser_stores_no_credentials": login.get("browser_stores_passwords") is False and login.get("browser_stores_totp_secrets") is False,
        "save_to_vault_choice_present": "Save to Vault" in login.get("user_choices", []),
        "network_settings_gui": prefs.get("gui_controls", {}).get("network_settings_tab") is True and network.get("network_settings_gui_enabled") is True,
        "proxy_settings_saved_locally": network.get("proxy", {}).get("mode") in {"system", "direct", "custom"},
        "browser_first_downloads_preserved": cfg.get("download_guard_post_completion_handoff_only") is True and cfg.get("download_guard_no_active_transfer_cli_calls") is True,
    }
    return {
        "ok": all(checks.values()),
        "schema": "sentinel.browser.phase5h_home_vault_network_test.v1",
        "app": APP_NAME,
        "program": PROGRAM,
        "package": PACKAGE,
        "version": VERSION,
        "base": "confirmed_good_rc24_rc3_line",
        "checks": checks,
        "network_settings": network,
        "notes": [
            "RC20 adds a local home page, hides the Bookmarks toolbar title text, and adds Vault save/login prompt choice without browser credential storage.",
            "Proxy/VPN settings are exposed in Preferences as local/system-network configuration; AEGIS remains optional.",
            "No live download polling or auto-refresh features are reintroduced.",
        ],
    }


def open_path_with_system(path: str) -> Dict[str, Any]:
    if not path:
        return {"ok": False, "error": "empty_path"}
    try:
        subprocess.Popen(["xdg-open", path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return {"ok": True, "path": path}
    except Exception as exc:
        return {"ok": False, "error": type(exc).__name__, "message": str(exc), "path": path}






_WALLET_STATUS_CACHE: Dict[str, Any] = {"timestamp": 0.0, "include_raw": None, "payload": None}

def _mono_time() -> float:
    try:
        import time
        return time.monotonic()
    except Exception:
        return 0.0

def run_wallet_json(args: List[str], timeout: int = 3) -> Dict[str, Any]:
    cfg = load_config(False)
    cmd_name = str(cfg.get("wallet_bridge_command", "sentinel-wallet") or "sentinel-wallet")
    path = shutil.which(cmd_name)
    if not path:
        return {"ok": False, "available": False, "error": "wallet_not_installed", "command": cmd_name}
    try:
        proc = subprocess.run([path] + list(args), text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout)
        payload = json.loads(proc.stdout or "{}") if (proc.stdout or "").strip().startswith("{") else {"stdout": (proc.stdout or "")[:500]}
        payload.setdefault("ok", proc.returncode == 0)
        payload.setdefault("available", True)
        payload.setdefault("returncode", proc.returncode)
        if proc.stderr.strip():
            payload.setdefault("stderr", proc.stderr.strip()[:500])
        return payload
    except Exception as exc:
        return {"ok": False, "available": True, "error": type(exc).__name__, "message": str(exc), "command": cmd_name}


def wallet_bridge_status_json(include_raw: bool = False) -> Dict[str, Any]:
    """Return the current Sentinel Wallet browser-bridge posture.

    RC20 supports the Wallet v0.4.1/v1.0.0 bridge model when available and
    falls back to the older v0.2.x status/open contract. The Browser never
    stores wallet secrets and never signs/broadcasts transactions.
    """
    cfg = load_config(False)
    cmd_name = str(cfg.get("wallet_bridge_command", "sentinel-wallet") or "sentinel-wallet")
    path = shutil.which(cmd_name)
    bridge = run_wallet_json(["browser-bridge", "--bridge-status"], timeout=5) if path else {"ok": False, "available": False}
    contract = run_wallet_json(["browser-bridge", "--contract"], timeout=5) if path else {"ok": False, "available": False}
    escrow = run_wallet_json(["--passphrase-escrow-status"], timeout=5) if path else {"ok": False, "available": False}
    legacy_contract = run_wallet_json(["--browser-contract"], timeout=5) if path and not contract.get("ok") else {}
    active_contract = contract if contract.get("ok") else legacy_contract
    payload: Dict[str, Any] = {
        "schema": "sentinel.browser.wallet_bridge_status.v1",
        "app": APP_NAME,
        "program": PROGRAM,
        "package": PACKAGE,
        "version": VERSION,
        "wallet_command": cmd_name,
        "wallet_available": bool(path),
        "wallet_path": path or "",
        "bridge_available": bool(bridge.get("ok")),
        "bridge_contract_schema": active_contract.get("schema", ""),
        "bridge_status_schema": bridge.get("schema", ""),
        "bridge_v0_4_1_compatible": bool(bridge.get("browser_bridge_supported") or contract.get("browser_bridge_supported")),
        "request_response_supported": bool(bridge.get("request_response_supported") or contract.get("request_response_supported")),
        "browser_generated_request_id": True,
        "response_read_supported": bool(bridge.get("read_response_supported") or contract.get("read_response_supported")),
        "local_only": True,
        "aegis_required": False,
        "sentinel_os_required": False,
        "browser_stores_wallet_secrets": False,
        "browser_reads_private_keys": False,
        "browser_signs_transactions": False,
        "browser_broadcasts_transactions": False,
        "browser_payments_enabled": False,
        "wallet_message_signing_supported": bool(active_contract.get("message_signing_enabled") is True or active_contract.get("browser_may_request_signing") is True),
        "wallet_transaction_signing_enabled": bool(active_contract.get("transaction_signing_enabled") is True),
        "wallet_crypto_only": bool(active_contract.get("wallet_type") == "crypto_only" or active_contract.get("crypto_only_wallet") is True),
        "wallet_card_features_enabled": bool(active_contract.get("card_features_enabled") is True or active_contract.get("credit_card_support") is True or active_contract.get("debit_card_support") is True),
        "wallet_nft_supported": bool(active_contract.get("nft_support_enabled") is True or active_contract.get("nft_inventory_supported") is True),
        "wallet_nft_networks": active_contract.get("nft_networks_declared", active_contract.get("nft_networks", [])),
        "wallet_passphrase_escrow_supported": bool(escrow.get("supported") is True or active_contract.get("passphrase_escrow_supported") is True),
        "wallet_passphrase_escrow_default_enabled": bool(escrow.get("default_enabled") is True),
        "wallet_passphrase_escrow_browser_safe": bool(escrow.get("browser_may_receive_passphrase") is False and escrow.get("browser_may_store_passphrase") is False),
        "wallet_contract_safe": bool(active_contract.get("payments_enabled") is False and active_contract.get("signing_enabled") is False and active_contract.get("network_access_enabled") is False and not (active_contract.get("card_features_enabled") is True or active_contract.get("credit_card_support") is True or active_contract.get("debit_card_support") is True)),
        "status": "wallet_bridge_ready_safe_disabled_payments" if path else "wallet_not_installed_optional",
        "notes": [
            "Browser may open Wallet and create/read local bridge request-response records only on explicit user action.",
            "Browser never stores wallet seed phrases, private keys, passphrases, signing material, or payment secrets.",
            "Card features are forbidden. Signing/broadcast paths remain disabled until a separately audited crypto Wallet release enables them."
        ],
    }
    if include_raw:
        payload["wallet_bridge_status_raw"] = bridge
        payload["wallet_bridge_contract_raw"] = contract
        payload["wallet_passphrase_escrow_raw"] = escrow
        if legacy_contract:
            payload["wallet_legacy_contract_raw"] = legacy_contract
    if cfg.get("wallet_status_cache_enabled", True):
        _WALLET_STATUS_CACHE["timestamp"] = _mono_time()
        _WALLET_STATUS_CACHE["include_raw"] = include_raw
        _WALLET_STATUS_CACHE["payload"] = dict(payload)
    return payload


def wallet_integration_status_json(include_raw: bool = False) -> Dict[str, Any]:
    # Preserve the older command while returning the richer RC20 bridge status.
    payload = wallet_bridge_status_json(include_raw=include_raw)
    payload["schema"] = "sentinel.browser.wallet_integration_status.v2"
    payload["wallet_open_supported"] = bool(payload.get("wallet_available"))
    return payload


def new_wallet_request_id(prefix: str = "browser") -> str:
    return f"{prefix}-{int(time.time())}-{secrets.token_hex(8)}"


def wallet_bridge_write_request(kind: str = "status", origin: str = "", note: str = "") -> Dict[str, Any]:
    req_id = new_wallet_request_id("browser")
    args = ["browser-bridge", "--write-request", "--request-id", req_id, "--request-kind", kind, "--browser-origin", origin or "", "--note", note or ""]
    obj = run_wallet_json(args, timeout=5)
    obj.setdefault("request_id", req_id)
    obj.setdefault("browser_generated_request_id", True)
    return obj


def wallet_bridge_read_response(request_id: str) -> Dict[str, Any]:
    if not request_id:
        return {"ok": False, "error": "missing_request_id"}
    return run_wallet_json(["browser-bridge", "--read-response", request_id], timeout=5)


def wallet_bridge_contract_test_json() -> Dict[str, Any]:
    status = wallet_bridge_status_json(include_raw=True)
    request = wallet_bridge_write_request("status", "sentinel-browser://self-test", "RC20 wallet bridge compatibility test") if status.get("wallet_available") else {"ok": False, "error": "wallet_not_available"}
    response = wallet_bridge_read_response(str(request.get("request_id", ""))) if request.get("request_id") else {"ok": False, "error": "no_request_id"}
    checks = {
        "runtime_version_v1_or_newer": _version_tuple(VERSION) >= _version_tuple("1.0.0"),
        "wallet_optional_clean_debian": status.get("aegis_required") is False and status.get("sentinel_os_required") is False,
        "browser_no_wallet_secret_storage": status.get("browser_stores_wallet_secrets") is False and status.get("browser_reads_private_keys") is False,
        "browser_no_wallet_signing_broadcast": status.get("browser_signs_transactions") is False and status.get("browser_broadcasts_transactions") is False,
        "wallet_payments_disabled": status.get("browser_payments_enabled") is False,
        "wallet_crypto_only_visible": status.get("wallet_crypto_only") is True,
        "wallet_card_features_forbidden": status.get("wallet_card_features_enabled") is False,
        "wallet_nft_supported": status.get("wallet_nft_supported") is True,
        "bridge_contract_safe": status.get("wallet_contract_safe") is True,
        "bridge_status_or_legacy_available": status.get("wallet_available") is True and (status.get("bridge_available") is True or bool(status.get("wallet_legacy_contract_raw"))),
        "browser_generated_request_id": bool(request.get("request_id")) and str(request.get("request_id", "")).startswith("browser-"),
        "request_write_supported": request.get("ok") is True,
        "read_response_supported": response.get("ok") is True or response.get("status") in ("pending", "missing"),
        "download_model_preserved": DEFAULT_CONFIG.get("download_guard_post_completion_handoff_only") is True and DEFAULT_CONFIG.get("download_guard_no_active_transfer_cli_calls") is True,
    }
    return {
        "ok": all(checks.values()),
        "schema": "sentinel.browser.phase5q_wallet_bridge_match_test.v1",
        "app": APP_NAME,
        "program": PROGRAM,
        "package": PACKAGE,
        "version": VERSION,
        "checks": checks,
        "wallet_bridge_status": {k: v for k, v in status.items() if not k.endswith("_raw")},
        "request": {"ok": request.get("ok"), "request_id": request.get("request_id"), "schema": request.get("schema")},
        "response": {"ok": response.get("ok"), "status": response.get("status"), "schema": response.get("schema")},
        "safety": {
            "payments_enabled": False,
            "signing_enabled": False,
            "network_broadcast_enabled": False,
            "browser_secret_storage_enabled": False,
        },
    }


def launch_sentinel_wallet(browser_origin: str = "", request_id: str = "", request_kind: str = "") -> Dict[str, Any]:
    cfg = load_config(False)
    cmd_name = str(cfg.get("wallet_bridge_command", "sentinel-wallet") or "sentinel-wallet")
    path = shutil.which(cmd_name)
    rid = str(request_id or "").strip()
    result: Dict[str, Any] = {
        "ok": False,
        "command": cmd_name,
        "path": path or "",
        "browser_origin": browser_origin,
        "request_id": rid,
        "request_kind": request_kind or "",
        "browser_secret_values_present": False,
        "browser_payments_enabled": False,
        "browser_signing_enabled": False,
    }
    if not path:
        result["error"] = "Sentinel Wallet is not installed."
        return result
    try:
        # Prefer the bridge open path and pass the exact request id, so Wallet can
        # open the correct approval prompt instead of scanning/stalling on stale gateway records.
        bridge_status = run_wallet_json(["browser-bridge", "--bridge-status"], timeout=3)
        if bridge_status.get("ok"):
            args = [path, "browser-bridge", "--open", "--browser-origin", browser_origin or ""]
            public = [cmd_name, "browser-bridge", "--open", "--browser-origin", "$CURRENT_URL"]
            if rid:
                args += ["--request-id", rid]
                public += ["--request-id", "$REQUEST_ID"]
        else:
            args = [path, "--browser-open", "--browser-origin", browser_origin or ""]
            public = [cmd_name, "--browser-open", "--browser-origin", "$CURRENT_URL"]
            if rid:
                args += ["--approval-request-id", rid]
                public += ["--approval-request-id", "$REQUEST_ID"]
        subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
        result.update({"ok": True, "launched": True, "launch_args_public": public, "bridge_used": bool(bridge_status.get("ok")), "exact_request_handoff": bool(rid)})
        log_security_event("wallet_open_from_browser", {"browser_origin_present": bool(browser_origin), "secret_values_present": False, "bridge_used": bool(bridge_status.get("ok")), "exact_request_handoff": bool(rid), "request_kind": request_kind or ""})
        return result
    except Exception as exc:
        result["error"] = str(exc)
        log_security_event("wallet_open_from_browser_failed", {"error": str(exc), "request_id_present": bool(rid)})
        return result


# ---- v1.0.1 Wallet transaction + dApp login bridge status overrides ---------
def wallet_transaction_dapp_status_json(include_raw: bool = False) -> Dict[str, Any]:
    st = wallet_bridge_status_json(include_raw=include_raw)
    return {
        "ok": bool(st.get("wallet_available") and st.get("wallet_transaction_signing_enabled") and st.get("wallet_dapp_login_enabled")),
        "schema": "sentinel.browser.wallet_transaction_dapp_status.v1_0_1",
        "app": APP_NAME,
        "package": PACKAGE,
        "program": PROGRAM,
        "version": VERSION,
        "wallet_available": st.get("wallet_available"),
        "wallet_version": st.get("wallet_version", ""),
        "wallet_transaction_signing_enabled": st.get("wallet_transaction_signing_enabled"),
        "wallet_dapp_login_enabled": st.get("wallet_dapp_login_enabled"),
        "browser_payments_enabled": st.get("browser_payments_enabled"),
        "browser_signs_transactions": False,
        "browser_broadcasts_transactions": False,
        "browser_stores_wallet_secrets": False,
        "browser_reads_private_keys": False,
        "browser_receives_signed_payload_only": True,
        "bridge_request_kinds": ["dapp_login_request", "personal_sign_request", "transaction_sign_request", "payment_request"],
        "status": "wallet_transaction_dapp_bridge_ready_signed_payload_only" if bool(st.get("wallet_available") and st.get("wallet_transaction_signing_enabled") and st.get("wallet_dapp_login_enabled")) else "wallet_transaction_dapp_bridge_not_ready",
        "raw": st if include_raw else {},
    }


def wallet_transaction_dapp_test_json() -> Dict[str, Any]:
    status = wallet_transaction_dapp_status_json(include_raw=True)
    login_req = wallet_bridge_write_request("dapp_login_request", "sentinel-browser://transaction-dapp-test", "v1.0.1 dApp login request smoke test") if status.get("wallet_available") else {"ok": False}
    tx_req = wallet_bridge_write_request("transaction_sign_request", "sentinel-browser://transaction-dapp-test", "v1.0.1 transaction signing request smoke test") if status.get("wallet_available") else {"ok": False}
    checks = {
        "runtime_version_v1_0_1_or_newer": _version_tuple(VERSION) >= _version_tuple("1.0.1"),
        "wallet_available": status.get("wallet_available") is True,
        "wallet_transaction_signing_enabled": status.get("wallet_transaction_signing_enabled") is True,
        "wallet_dapp_login_enabled": status.get("wallet_dapp_login_enabled") is True,
        "browser_no_secret_storage": status.get("browser_stores_wallet_secrets") is False and status.get("browser_reads_private_keys") is False,
        "browser_no_direct_sign_or_broadcast": status.get("browser_signs_transactions") is False and status.get("browser_broadcasts_transactions") is False,
        "signed_payload_only": status.get("browser_receives_signed_payload_only") is True,
        "dapp_login_request_write": login_req.get("ok") is True and login_req.get("request_kind") == "dapp_login_request",
        "transaction_request_write": tx_req.get("ok") is True and tx_req.get("request_kind") == "transaction_sign_request",
    }
    return {"ok": all(checks.values()), "schema": "sentinel.browser.wallet_transaction_dapp_test.v1_0_1", "app": APP_NAME, "version": VERSION, "checks": checks, "wallet_transaction_dapp_status": {k:v for k,v in status.items() if k != "raw"}, "login_request": {"ok": login_req.get("ok"), "request_id": login_req.get("request_id"), "request_kind": login_req.get("request_kind")}, "transaction_request": {"ok": tx_req.get("ok"), "request_id": tx_req.get("request_id"), "request_kind": tx_req.get("request_kind")}}


# Override wallet bridge interpretation for v1.0.1 transaction+dApp Wallet contract.
def wallet_bridge_status_json(include_raw: bool = False) -> Dict[str, Any]:
    cfg = load_config(False)
    cmd_name = str(cfg.get("wallet_bridge_command", "sentinel-wallet") or "sentinel-wallet")
    path = shutil.which(cmd_name)
    bridge = run_wallet_json(["browser-bridge", "--bridge-status"], timeout=5) if path else {"ok": False, "available": False}
    contract = run_wallet_json(["browser-bridge", "--contract"], timeout=5) if path else {"ok": False, "available": False}
    txstatus = run_wallet_json(["--transaction-dapp-status"], timeout=5) if path else {"ok": False, "available": False}
    escrow = run_wallet_json(["--passphrase-escrow-status"], timeout=5) if path else {"ok": False, "available": False}
    legacy_contract = run_wallet_json(["--browser-contract"], timeout=5) if path and not contract.get("ok") else {}
    active_contract = contract if contract.get("ok") else legacy_contract
    payload: Dict[str, Any] = {
        "schema": "sentinel.browser.wallet_bridge_status.v1_0_1",
        "app": APP_NAME,
        "program": PROGRAM,
        "package": PACKAGE,
        "version": VERSION,
        "wallet_command": cmd_name,
        "wallet_available": bool(path),
        "wallet_path": path or "",
        "wallet_version": str(active_contract.get("version") or txstatus.get("version") or ""),
        "bridge_available": bool(bridge.get("ok")),
        "bridge_contract_schema": active_contract.get("schema", ""),
        "bridge_status_schema": bridge.get("schema", ""),
        "request_response_supported": bool(bridge.get("request_response_supported") or contract.get("request_response_supported")),
        "browser_generated_request_id": True,
        "response_read_supported": bool(bridge.get("read_response_supported") or contract.get("read_response_supported")),
        "local_only": True,
        "aegis_required": False,
        "sentinel_os_required": False,
        "browser_stores_wallet_secrets": False,
        "browser_reads_private_keys": False,
        "browser_signs_transactions": False,
        "browser_broadcasts_transactions": False,
        "browser_payments_enabled": bool(active_contract.get("payments_enabled") is True or active_contract.get("crypto_transactions_enabled") is True),
        "browser_receives_signed_payload_only": True,
        "wallet_message_signing_supported": bool(active_contract.get("message_signing_enabled") is True or active_contract.get("browser_may_request_signing") is True),
        "wallet_dapp_login_enabled": bool(active_contract.get("dapp_login_enabled") is True or txstatus.get("browser_dapp_login_enabled") is True),
        "wallet_transaction_signing_enabled": bool(active_contract.get("transaction_signing_enabled") is True or txstatus.get("transaction_signing_enabled") is True),
        "wallet_owned_broadcast_enabled": bool(active_contract.get("wallet_owned_broadcast_enabled") is True),
        "wallet_crypto_only": bool(active_contract.get("wallet_type") == "crypto_only" or active_contract.get("crypto_only_wallet") is True),
        "wallet_card_features_enabled": bool(active_contract.get("card_features_enabled") is True or active_contract.get("credit_card_support") is True or active_contract.get("debit_card_support") is True),
        "wallet_nft_supported": bool(active_contract.get("nft_support_enabled") is True or active_contract.get("nft_inventory_supported") is True),
        "wallet_nft_networks": active_contract.get("nft_networks_declared", active_contract.get("nft_networks", [])),
        "wallet_passphrase_escrow_supported": bool(escrow.get("supported") is True or active_contract.get("passphrase_escrow_supported") is True),
        "wallet_passphrase_escrow_default_enabled": bool(escrow.get("default_enabled") is True),
        "wallet_passphrase_escrow_browser_safe": bool(escrow.get("browser_may_receive_passphrase") is False and escrow.get("browser_may_store_passphrase") is False),
        "wallet_contract_safe": bool(active_contract.get("browser_may_receive_secrets") is False and not (active_contract.get("card_features_enabled") is True or active_contract.get("credit_card_support") is True or active_contract.get("debit_card_support") is True)),
        "status": "wallet_bridge_ready_transaction_dapp_signed_payload_only" if path else "wallet_not_installed_optional",
        "notes": [
            "Browser may request dApp/login or transaction signing only through Wallet-owned approval flow.",
            "Browser never stores wallet seed phrases, private keys, passphrases, signing material, or payment secrets.",
            "Wallet returns public address/signature/signed payload only. Wallet-owned network broadcast remains disabled."
        ],
    }
    if include_raw:
        payload["wallet_bridge_status_raw"] = bridge
        payload["wallet_bridge_contract_raw"] = contract
        payload["wallet_transaction_dapp_status_raw"] = txstatus
        payload["wallet_passphrase_escrow_raw"] = escrow
        if legacy_contract:
            payload["wallet_legacy_contract_raw"] = legacy_contract
    if cfg.get("wallet_status_cache_enabled", True):
        _WALLET_STATUS_CACHE["timestamp"] = _mono_time()
        _WALLET_STATUS_CACHE["include_raw"] = include_raw
        _WALLET_STATUS_CACHE["payload"] = dict(payload)
    return payload


def wallet_bridge_contract_test_json() -> Dict[str, Any]:
    status = wallet_bridge_status_json(include_raw=True)
    request = wallet_bridge_write_request("status", "sentinel-browser://self-test", "v1.0.1 wallet bridge compatibility test") if status.get("wallet_available") else {"ok": False, "error": "wallet_not_available"}
    response = wallet_bridge_read_response(str(request.get("request_id", ""))) if request.get("request_id") else {"ok": False, "error": "no_request_id"}
    checks = {
        "runtime_version_v1_0_1_or_newer": _version_tuple(VERSION) >= _version_tuple("1.0.1"),
        "wallet_optional_clean_debian": status.get("aegis_required") is False and status.get("sentinel_os_required") is False,
        "browser_no_wallet_secret_storage": status.get("browser_stores_wallet_secrets") is False and status.get("browser_reads_private_keys") is False,
        "browser_no_direct_signing_broadcast": status.get("browser_signs_transactions") is False and status.get("browser_broadcasts_transactions") is False,
        "wallet_crypto_transactions_enabled": status.get("browser_payments_enabled") is True,
        "wallet_transaction_signing_enabled": status.get("wallet_transaction_signing_enabled") is True,
        "wallet_dapp_login_enabled": status.get("wallet_dapp_login_enabled") is True,
        "wallet_crypto_only_visible": status.get("wallet_crypto_only") is True,
        "wallet_card_features_forbidden": status.get("wallet_card_features_enabled") is False,
        "wallet_nft_supported": status.get("wallet_nft_supported") is True,
        "bridge_contract_safe": status.get("wallet_contract_safe") is True,
        "bridge_status_or_legacy_available": status.get("wallet_available") is True and (status.get("bridge_available") is True or bool(status.get("wallet_legacy_contract_raw"))),
        "browser_generated_request_id": bool(request.get("request_id")) and str(request.get("request_id", "")).startswith("browser-"),
        "request_write_supported": request.get("ok") is True,
        "read_response_supported": response.get("ok") is True or response.get("status") in ("pending", "missing"),
    }
    return {"ok": all(checks.values()), "schema": "sentinel.browser.wallet_bridge_match_test.v1_0_1", "app": APP_NAME, "program": PROGRAM, "package": PACKAGE, "version": VERSION, "checks": checks, "wallet_bridge_status": {k: v for k, v in status.items() if not k.endswith("_raw")}, "request": {"ok": request.get("ok"), "request_id": request.get("request_id"), "schema": request.get("schema")}, "response": {"ok": response.get("ok"), "status": response.get("status"), "schema": response.get("schema")}, "safety": {"crypto_transactions_enabled": True, "dapp_login_enabled": True, "browser_direct_signing_enabled": False, "network_broadcast_enabled": False, "browser_secret_storage_enabled": False}}


def wallet_integration_status_json(include_raw: bool = False) -> Dict[str, Any]:
    payload = wallet_bridge_status_json(include_raw=include_raw)
    payload["schema"] = "sentinel.browser.wallet_integration_status.v1_0_1"
    payload["wallet_open_supported"] = bool(payload.get("wallet_available"))
    payload["wallet_transaction_dapp"] = wallet_transaction_dapp_status_json(include_raw=False)
    return payload

LEGACY_DEFAULT_BOOKMARKS: List[Dict[str, str]] = [
    {"title": "SentinelOS Home", "url": "about:blank"},
    {"title": "DuckDuckGo", "url": "https://duckduckgo.com"},
]


def default_bookmarks() -> List[Dict[str, str]]:
    # v1 default: no preloaded bookmarks. The local homepage still provides quick links,
    # but the favourites/bookmarks bar starts empty so the user owns this space.
    return []


def _is_legacy_default_bookmark(item: Dict[str, str]) -> bool:
    title = str(item.get("title", "")).strip().lower()
    url = str(item.get("url", "")).strip().lower().rstrip("/")
    legacy = {
        ("sentinelos home", "about:blank"),
        ("duckduckgo", "https://duckduckgo.com"),
    }
    return (title, url) in legacy


def _clean_bookmark_title(value: Any, fallback: str = "Bookmark", limit: int = 120) -> str:
    text = str(value or "").replace("\x00", "").strip()
    if not text:
        text = fallback
    return text[:limit]


def _clean_bookmark_url(value: Any) -> str:
    text = str(value or "about:blank").replace("\x00", "").strip()[:2048]
    return text or "about:blank"


def _clean_bookmark_folder(value: Any) -> str:
    # Folder names are display labels only. Keep them local/simple and avoid
    # control characters, slash semantics, and excessively long GTK menu labels.
    text = str(value or "").replace("\x00", "").strip()
    text = re.sub(r"[\r\n\t/\\]+", " ", text)
    text = re.sub(r"\s+", " ", text).strip(" .")
    return text[:80]


def normalize_bookmark_records(raw_items: Any) -> List[Dict[str, str]]:
    if not isinstance(raw_items, list):
        return default_bookmarks()
    clean: List[Dict[str, str]] = []
    seen_folders = set()
    for item in raw_items:
        if not isinstance(item, dict):
            continue
        item_type = str(item.get("type") or "").strip().lower()
        # Folder marker. This lets the user create an empty folder before
        # placing any bookmark inside it while keeping the storage format JSON-simple.
        if item_type == "folder" and isinstance(item.get("title"), str):
            folder = _clean_bookmark_folder(item.get("title"))
            if folder and folder.lower() not in seen_folders:
                clean.append({"type": "folder", "title": folder})
                seen_folders.add(folder.lower())
            continue
        if isinstance(item.get("title"), str) and isinstance(item.get("url"), str):
            title = _clean_bookmark_title(item.get("title"), "Bookmark", 120)
            url = _clean_bookmark_url(item.get("url"))
            folder = _clean_bookmark_folder(item.get("folder", ""))
            record = {"type": "bookmark", "title": title, "url": url}
            if folder:
                record["folder"] = folder
            clean.append(record)
    # Suppress only the old factory defaults. Real user bookmarks remain untouched.
    bookmark_rows = [bm for bm in clean if bm.get("type") != "folder"]
    if bookmark_rows and len(bookmark_rows) == len(clean) and all(_is_legacy_default_bookmark(bm) for bm in bookmark_rows):
        return []
    return clean


def load_bookmarks() -> List[Dict[str, str]]:
    return normalize_bookmark_records(load_json(BOOKMARKS, default_bookmarks()))


def save_bookmarks(items: List[Dict[str, str]]) -> None:
    save_json(BOOKMARKS, normalize_bookmark_records(items))


def bookmark_folders(items: Optional[List[Dict[str, str]]] = None) -> List[str]:
    rows = items if items is not None else load_bookmarks()
    folders: List[str] = []
    seen = set()
    for item in rows:
        folder = _clean_bookmark_folder(item.get("title") if item.get("type") == "folder" else item.get("folder", ""))
        if folder and folder.lower() not in seen:
            folders.append(folder)
            seen.add(folder.lower())
    return folders


def bookmark_rows(items: Optional[List[Dict[str, str]]] = None, folder: str = "") -> List[Dict[str, str]]:
    rows = items if items is not None else load_bookmarks()
    target = _clean_bookmark_folder(folder)
    return [bm for bm in rows if bm.get("type") != "folder" and _clean_bookmark_folder(bm.get("folder", "")) == target]


BOOKMARK_DRAG_MIME = "application/x-sentinel-browser-bookmark"


def _bookmark_identity(item: Dict[str, str], index: int = -1) -> Dict[str, Any]:
    return {
        "schema": "sentinel.browser.bookmark_drag.v1",
        "title": _clean_bookmark_title(item.get("title", "Bookmark"), "Bookmark", 120),
        "url": _clean_bookmark_url(item.get("url", "about:blank")),
        "folder": _clean_bookmark_folder(item.get("folder", "")),
        "index": int(index),
    }


def _decode_bookmark_drag_payload(text: Any) -> Optional[Dict[str, Any]]:
    try:
        payload = json.loads(str(text or ""))
    except Exception:
        return None
    if not isinstance(payload, dict):
        return None
    if payload.get("schema") != "sentinel.browser.bookmark_drag.v1":
        return None
    url = _clean_bookmark_url(payload.get("url", ""))
    if not url:
        return None
    return {
        "schema": "sentinel.browser.bookmark_drag.v1",
        "title": _clean_bookmark_title(payload.get("title", "Bookmark"), "Bookmark", 120),
        "url": url,
        "folder": _clean_bookmark_folder(payload.get("folder", "")),
        "index": int(payload.get("index", -1)) if str(payload.get("index", "")).lstrip("-").isdigit() else -1,
    }


def _find_bookmark_index(items: List[Dict[str, str]], identity: Dict[str, Any]) -> int:
    preferred = int(identity.get("index", -1))
    title = _clean_bookmark_title(identity.get("title", ""), "Bookmark", 120)
    url = _clean_bookmark_url(identity.get("url", ""))
    folder = _clean_bookmark_folder(identity.get("folder", ""))
    if 0 <= preferred < len(items):
        item = items[preferred]
        if item.get("type") != "folder" and item.get("url") == url and _clean_bookmark_folder(item.get("folder", "")) == folder:
            # Prefer the stored index, but still require URL/folder match so a stale drag payload
            # cannot move a different row after bookmarks changed under the pointer.
            return preferred
    for idx, item in enumerate(items):
        if item.get("type") == "folder":
            continue
        if item.get("url") == url and _clean_bookmark_folder(item.get("folder", "")) == folder and _clean_bookmark_title(item.get("title", ""), "Bookmark", 120) == title:
            return idx
    for idx, item in enumerate(items):
        if item.get("type") == "folder":
            continue
        if item.get("url") == url and _clean_bookmark_folder(item.get("folder", "")) == folder:
            return idx
    return -1


def move_bookmark_identity_to_folder(items: List[Dict[str, str]], identity: Dict[str, Any], target_folder: str) -> Tuple[List[Dict[str, str]], bool]:
    clean_items = normalize_bookmark_records(items)
    target = _clean_bookmark_folder(target_folder)
    source_idx = _find_bookmark_index(clean_items, identity)
    if source_idx < 0:
        return clean_items, False
    row = dict(clean_items[source_idx])
    if target:
        row["folder"] = target
    else:
        row.pop("folder", None)
    clean_items[source_idx] = row
    if target and target.lower() not in {f.lower() for f in bookmark_folders(clean_items)}:
        clean_items.insert(0, {"type": "folder", "title": target})
    return normalize_bookmark_records(clean_items), True


def reorder_bookmark_identity_before(items: List[Dict[str, str]], identity: Dict[str, Any], target_identity: Dict[str, Any]) -> Tuple[List[Dict[str, str]], bool]:
    clean_items = normalize_bookmark_records(items)
    source_idx = _find_bookmark_index(clean_items, identity)
    target_idx = _find_bookmark_index(clean_items, target_identity)
    if source_idx < 0 or target_idx < 0 or source_idx == target_idx:
        return clean_items, False
    src_folder = _clean_bookmark_folder(clean_items[source_idx].get("folder", ""))
    dst_folder = _clean_bookmark_folder(clean_items[target_idx].get("folder", ""))
    if src_folder != dst_folder:
        return clean_items, False
    row = clean_items.pop(source_idx)
    if source_idx < target_idx:
        target_idx -= 1
    clean_items.insert(target_idx, row)
    return normalize_bookmark_records(clean_items), True


def bookmark_drag_model_test_json() -> Dict[str, Any]:
    sample = [
        {"type": "folder", "title": "Research"},
        {"type": "bookmark", "title": "One", "url": "https://one.example"},
        {"type": "bookmark", "title": "Two", "url": "https://two.example"},
        {"type": "bookmark", "title": "Docs", "url": "https://docs.example", "folder": "Research"},
    ]
    payload_two = _bookmark_identity(sample[2], 2)
    payload_one = _bookmark_identity(sample[1], 1)
    reordered, reordered_ok = reorder_bookmark_identity_before(sample, payload_two, payload_one)
    moved, moved_ok = move_bookmark_identity_to_folder(reordered, payload_two, "Research")
    folders = bookmark_folders(moved)
    root_titles = [b.get("title") for b in bookmark_rows(moved, "")]
    research_titles = [b.get("title") for b in bookmark_rows(moved, "Research")]
    decoded = _decode_bookmark_drag_payload(json.dumps(payload_two))
    checks = {
        "drag_payload_decodes": bool(decoded and decoded.get("url") == "https://two.example"),
        "same_folder_reorder_supported": reordered_ok and [b.get("title") for b in bookmark_rows(reordered, "")][:2] == ["Two", "One"],
        "drag_to_folder_supported": moved_ok and "Two" in research_titles and "Two" not in root_titles,
        "folder_marker_preserved": "Research" in folders,
        "legacy_schema_preserved": all(isinstance(row, dict) for row in moved),
    }
    return {
        "ok": all(checks.values()),
        "schema": "sentinel.browser.bookmark_drag_toolbar_test.v1_1_17",
        "app": APP_NAME,
        "program": PROGRAM,
        "package": PACKAGE,
        "version": VERSION,
        "checks": checks,
        "records": moved,
    }


def _safe_remove_app_path(target: Path) -> bool:
    t = Path(target).expanduser()
    allowed_roots = [CONFIG_DIR, DATA_DIR, STATE_DIR, CACHE_DIR]
    try:
        raw = str(t)
        if not any(raw == str(root) or raw.startswith(str(root) + os.sep) for root in allowed_roots):
            raise RuntimeError(f"clear-data target outside app roots refused: {t}")
        if t.is_symlink() or _path_has_symlink_component(t):
            raise RuntimeError(f"clear-data symlink target refused: {t}")
        if t.is_dir():
            shutil.rmtree(t)
            return True
        if t.exists():
            t.unlink()
            return True
    except Exception as exc:
        log_crash(exc)
    return False


def clear_browsing_data(clear_bookmarks: bool = False, clear_config: bool = False) -> List[str]:
    """Clear app-scoped browser data while preserving user control."""
    removed: List[str] = []
    targets = [SESSION, STATUS, SECURITY_EVENTS, AEGIS_BRIDGE_STATUS, AEGIS_BRIDGE_EVENTS, WEBKIT_DATA_DIR, WEBKIT_CACHE_DIR]
    if clear_bookmarks:
        targets.append(BOOKMARKS)
    if clear_config:
        targets.append(CONFIG)
    for target in targets:
        if _safe_remove_app_path(target):
            removed.append(str(target))
    try:
        ensure_dirs()
    except Exception:
        # Leave unsafe symlinked app paths untouched; caller can repair/remove them.
        pass
    return removed



def default_aegis_bridge_policy() -> Dict[str, Any]:
    return {
        "schema_version": 1,
        "program": PROGRAM,
        "app": APP_NAME,
        "bridge_name": "sentinel-browser-aegis-bridge",
        "enabled": False,
        "local_only": True,
        "permission_model": "explicit_opt_in_required",
        "advisory_not_controlling": True,
        "allowed_by_default": {
            "status_read": True,
            "security_events": True,
            "advisory_warnings": True,
        },
        "disabled_by_default": {
            "page_metadata": True,
            "content_capture": True,
            "password_access": True,
            "autonomous_navigation": True,
            "download_actions": True,
            "form_reading": True,
            "history_export": True,
            "cloud_forwarding": True,
            "telemetry": True,
        },
        "notes": [
            "AEGIS bridge is future-ready only and disabled by default.",
            "AEGIS may advise, warn, or read explicit local status when permitted.",
            "AEGIS must not capture page contents, passwords, forms, or browsing history without a future explicit user permission model.",
            "No autonomous browsing control is allowed by default.",
        ],
    }


def load_aegis_bridge_policy() -> Dict[str, Any]:
    raw = load_json(AEGIS_BRIDGE_POLICY, {})
    base = default_aegis_bridge_policy()
    if isinstance(raw, dict):
        # Conservative merge: unknown keys are preserved but core safety defaults remain false unless explicitly boolean true.
        base.update(raw)
    base["schema_version"] = 1
    base["program"] = PROGRAM
    base["app"] = APP_NAME
    base["local_only"] = True
    base["advisory_not_controlling"] = True
    return base


def write_aegis_bridge_policy() -> None:
    if not AEGIS_BRIDGE_POLICY.exists():
        save_json(AEGIS_BRIDGE_POLICY, default_aegis_bridge_policy())


def aegis_bridge_status(include_paths: bool = True) -> Dict[str, Any]:
    cfg = load_config(False)
    policy = load_aegis_bridge_policy()
    payload: Dict[str, Any] = {
        "schema_version": 1,
        "app": APP_NAME,
        "program": PROGRAM,
        "package": PACKAGE,
        "version": VERSION,
        "bridge": "sentinel-browser-aegis-bridge",
        "status": "future_ready_disabled_by_default",
        "generated_at": now_iso(),
        "local_first": True,
        "aegis_ready": True,
        "bridge_enabled": bool(cfg.get("aegis_bridge_enabled", False)) and bool(policy.get("enabled", False)),
        "permission_model": "explicit_opt_in_required",
        "human_authority": True,
        "advisory_not_controlling": True,
        "allowed_now": {
            "status_read": bool(cfg.get("aegis_bridge_allow_status_read", True)),
            "security_events": bool(cfg.get("aegis_bridge_allow_security_events", True)),
            "advisory_warnings": bool(cfg.get("aegis_bridge_allow_advisory_warnings", True)),
        },
        "blocked_by_default": {
            "page_metadata": not bool(cfg.get("aegis_bridge_allow_page_metadata", False)),
            "content_capture": not bool(cfg.get("aegis_bridge_allow_content_capture", False)),
            "password_access": not bool(cfg.get("aegis_bridge_allow_password_access", False)),
            "autonomous_navigation": not bool(cfg.get("aegis_bridge_allow_autonomous_navigation", False)),
            "download_actions": not bool(cfg.get("aegis_bridge_allow_download_actions", False)),
            "telemetry": True,
            "cloud_sync": True,
        },
        "future_event_schema": {
            "time": "ISO-8601 UTC",
            "kind": "security|privacy|navigation|download|form|permission",
            "severity": "info|low|medium|high|critical",
            "action": "observe|warn|block|user_approved",
            "detail": "metadata only unless explicit future permission exists",
        },
        "current_browser_posture": {
            "no_telemetry": True,
            "no_sync": True,
            "no_password_storage": True,
            "history_logging_default": False,
            "session_restore_default": DEFAULT_CONFIG["restore_tabs"],
            "security_indicator": True,
            "tls_error_block_default": cfg.get("block_tls_errors", True),
        },
        "policy": policy,
    }
    if include_paths:
        payload["paths"] = {
            "policy": str(AEGIS_BRIDGE_POLICY),
            "status": str(AEGIS_BRIDGE_STATUS),
            "events": str(AEGIS_BRIDGE_EVENTS),
            "security_events": str(SECURITY_EVENTS),
        }
    return payload


def log_aegis_bridge_event(kind: str, severity: str, action: str, detail: Dict[str, Any]) -> None:
    try:
        ensure_dirs()
        payload = {"time": now_iso(), "kind": kind, "severity": severity, "action": action, "detail": detail}
        with AEGIS_BRIDGE_EVENTS.open("a", encoding="utf-8") as f:
            f.write(json.dumps(payload, sort_keys=True) + "\n")
    except Exception:
        pass


def hotkey_status_json(include_paths: bool = True) -> Dict[str, Any]:
    return {
        "schema_version": 1,
        "app": APP_NAME,
        "program": PROGRAM,
        "package": PACKAGE,
        "version": VERSION,
        "status": "hotkeys_enabled",
        "local_first": True,
        "ctrl_q_closes_app": True,
        "user_configurable_hotkeys": False,
        "hotkeys": HOTKEYS,
        "notes": [
            "Hotkeys are local GUI accelerators only.",
            "Ctrl+Q closes the Sentinel Browser application.",
            "No hotkey telemetry or remote shortcut sync is used.",
        ],
    }


def status_json(include_paths: bool = True) -> Dict[str, Any]:
    cfg = load_config(False)
    status: Dict[str, Any] = {
        "app": APP_NAME,
        "program": PROGRAM,
        "package": PACKAGE,
        "version": VERSION,
        "status": "content_blocking_anti_miner_fingerprint_defense",
        "local_first": True,
        "network_required_for_diagnostics": False,
        "ui_settings": {
            "menu_bar_enabled": cfg.get("menu_bar_enabled", True),
            "settings_ui_enabled": cfg.get("settings_ui_enabled", True),
            "preferences_window_enabled": cfg.get("preferences_window_enabled", True),
            "search_engine_selector_gui_enabled": cfg.get("search_engine_selector_gui_enabled", True),
            "download_guard_settings_gui_enabled": cfg.get("download_guard_settings_gui_enabled", True),
            "site_data_manager_enabled": cfg.get("site_data_manager_enabled", True),
            "security_profile_gui_enabled": cfg.get("security_profile_gui_enabled", True),
            "address_bar_mid_dark_grey": cfg.get("address_bar_mid_dark_grey", True),
            "bookmarks_toolbar_button_enabled": cfg.get("bookmarks_toolbar_button_enabled", True),
            "downloads_toolbar_button_enabled": cfg.get("downloads_toolbar_button_enabled", True),
            "tab_row_new_tab_button_enabled": cfg.get("tab_row_new_tab_button_enabled", True),
            "incognito_themed_icon_enabled": cfg.get("incognito_themed_icon_enabled", True),
            "vault_2fa_icon_button_enabled": cfg.get("vault_2fa_icon_button_enabled", True),
            "homepage_default_enabled": cfg.get("sentinel_home_default_enabled", True),
            "homepage_packaged_html_enabled": cfg.get("sentinel_home_packaged_html_enabled", True),
        },
        "search_policy": search_policy_status_json(include_paths=False),
        "preferences": preferences_status_json(include_paths=False),
        "vault_2fa_toolbar": vault_2fa_toolbar_status_json(include_paths=False),
        "vault_bridge": vault_bridge_status_json(include_paths=False),
        "vault_account_hints": vault_account_hints_status_json(include_paths=False),
        "vault_login_prompt": vault_login_prompt_status_json(include_paths=False),
        "homepage": homepage_status_json(include_paths=False),
        "privacy": {
            "telemetry": False,
            "sync": False,
            "cloud_account_required": False,
            "password_storage": False,
            "history_logging_default": False,
            "session_restore_default": DEFAULT_CONFIG["restore_tabs"],
            "app_scoped_webkit_storage": True,
            "private_mode_available": True,
            "private_mode_default": DEFAULT_CONFIG["private_mode"],
            "history_logging_enabled": cfg.get("history_logging_enabled", False),
            "session_restore_opt_in": not DEFAULT_CONFIG["restore_tabs"],
            "form_memory_default": cfg.get("remember_form_data", False),
            "third_party_cookie_block_default": cfg.get("block_third_party_cookies", True),
            "clear_cache_on_exit": cfg.get("clear_cache_on_exit", False),
            "clear_cookies_on_exit": cfg.get("clear_cookies_on_exit", False),
            "clear_local_storage_on_exit": cfg.get("clear_local_storage_on_exit", False),
        },
        "security": {
            "security_indicator": True,
            "tls_error_block_default": cfg.get("block_tls_errors", True),
            "external_protocol_warning": cfg.get("warn_external_protocols", True),
            "download_warning": cfg.get("warn_downloads", True),
            "download_permission_guard": True,
            "ask_before_download": cfg.get("ask_before_download", True),
            "block_dangerous_downloads": cfg.get("block_dangerous_downloads", True),
            "confirm_dangerous_downloads": cfg.get("confirm_dangerous_downloads", True),
            "explain_dangerous_downloads": cfg.get("explain_dangerous_downloads", True),
            "dangerous_download_user_override": cfg.get("dangerous_download_user_override", True),
            "allow_executable_downloads": cfg.get("allow_executable_downloads", False),
            "auto_open_downloads": cfg.get("auto_open_downloads", False),
            "hyperlink_auditing_disabled": cfg.get("disable_hyperlink_auditing", True),
            "dns_prefetching_disabled": cfg.get("disable_dns_prefetching", True),
            "webrtc_media_capture_disabled": cfg.get("disable_webrtc_media_capture", True),
            "webgl_disabled_by_default": cfg.get("disable_webgl_by_default", True),
            "content_blocking_enabled": cfg.get("content_blocking_enabled", True),
            "block_trackers": cfg.get("block_trackers", True),
            "block_known_miners": cfg.get("block_known_miners", True),
            "block_fingerprinting_scripts": cfg.get("block_fingerprinting_scripts", True),
            "fingerprint_defense_enabled": cfg.get("fingerprint_defense_enabled", True),
            "canvas_fingerprinting_restricted_attempted": cfg.get("restrict_canvas_fingerprinting", True),
            "audio_fingerprinting_restricted_attempted": cfg.get("restrict_audio_fingerprinting", True),
            "remote_blocklist_subscriptions": False,
            "clear_browsing_data_helper": True,
            "site_permissions_control_panel": True,
            "camera_default": cfg.get("permission_camera_default", "block"),
            "microphone_default": cfg.get("permission_microphone_default", "block"),
            "geolocation_default": cfg.get("permission_geolocation_default", "block"),
            "notifications_default": cfg.get("permission_notifications_default", "block"),
            "strict_security_profile_enabled": cfg.get("strict_security_profile_enabled", True),
            "webkit_sandbox_attempt_enabled": cfg.get("enable_webkit_sandbox_attempt", True),
            "mixed_content_policy_present": cfg.get("block_mixed_content_policy", True),
            "https_upgrade_policy_present": cfg.get("enforce_https_upgrade_attempt", True),
            "javascript_profile": cfg.get("javascript_profile", "standard"),
            "javascript_policy_enabled": cfg.get("javascript_policy_enabled", True),
            "javascript_file_urls_enabled": cfg.get("javascript_file_urls_enabled", False),
            "javascript_data_urls_enabled": cfg.get("javascript_data_urls_enabled", False),
            "javascript_local_pages_enabled": cfg.get("javascript_local_pages_enabled", False),
            "v1_security_gates_required": cfg.get("v1_security_gates_required", True),
        },
        "content_blocking": content_status_json(include_paths=False),
        "downloads": download_status_json(include_paths=False),
        "download_guard_integration": download_guard_contract_status_json(include_raw=False),
        "permissions": permission_status_json(include_paths=False),
        "hotkeys": hotkey_status_json(include_paths=False),
        "aegis_bridge": aegis_bridge_status(include_paths=False),
        "vault_bridge": vault_bridge_status_json(include_paths=False),
        "vault_account_hints": vault_account_hints_status_json(include_paths=False),
        "capabilities": [
            "gtk3_shell", "webkit2_view", "tabs", "navigation_buttons", "address_bar",
            "search_query_routing", "bookmarks_json", "optional_session_restore",
            "no_telemetry", "no_sync", "no_password_storage", "no_history_logging_default",
            "security_indicator", "https_state_display", "tls_error_blocking", "external_protocol_warning",
            "hotkeys", "keyboard_shortcuts", "ctrl_q_close_app", "hotkey_status_json", "content_blocking", "content_policy", "content_block_status_json", "local_blocklist", "local_allowlist", "anti_crypto_miner_blocking", "fingerprint_defense", "fingerprint_policy_status", "no_remote_blocklist_subscriptions", "browser_navigation_hotkeys", "tab_management_hotkeys", "zoom_hotkeys", "site_permissions", "site_permission_policy", "permission_status_json", "permission_control_panel", "camera_block_default", "microphone_block_default", "geolocation_block_default", "notifications_block_default", "popup_block_default", "file_access_block_default", "permission_request_logging", "download_warning", "download_permission_guard", "dangerous_download_blocking",
            "safe_download_destination", "download_status_json", "dangerous_download_confirmation_prompt", "dangerous_download_explanation", "dangerous_download_abandon_option", "dangerous_download_user_override", "no_auto_open_downloads",
            "app_scoped_webkit_storage", "clear_browsing_data",
            "privacy_security_status_json", "desktop_launcher", "runtime_check", "self_test",
            "aegis_status_json", "safe_mode", "reset_config", "crash_log", "security_event_log", "private_mode", "privacy_data_controls", "cookie_policy_controls",
            "cache_control_config", "local_storage_control_config", "history_off_by_default",
            "form_memory_off_by_default", "privacy_status_json", "aegis_ready", "aegis_bridge_foundation", "aegis_bridge_policy", "aegis_bridge_status_json", "aegis_advisory_event_schema", "no_aegis_autonomous_control_default", "no_aegis_password_access_default", "security_profile_status_json", "webkit_engine_security_status_json", "webkit_sandbox_attempt", "strict_security_profile", "v1_security_gates", "mixed_content_policy_status", "javascript_security_profiles", "javascript_engine_gate", "javascript_policy_status_json", "per_site_javascript_policy", "javascript_lockdown_profile", "javascript_local_file_block_default",
            "menu_bar", "user_settings_ui", "search_engine_policy", "default_search_duckduckgo", "private_search_mojeek", "custom_search_url", "address_bar_mid_dark_grey", "address_bar_star_removed", "incognito_button", "themed_incognito_icon", "bookmarks_menu", "bookmarks_toolbar", "bookmarks_toolbar_click_actions_fixed", "bookmarks_toolbar_toggle_fixed", "bookmark_editor", "bookmark_context_menu", "bookmark_toolbar_save_button_editor_fixed", "tab_context_menu", "web_context_menu_sentinel_actions", "bookmarks_toolbar_button", "downloads_toolbar_button", "downloads_page", "download_guard_backend_handoff", "download_guard_icon_status_preview", "download_guard_completion_prompt", "download_guard_no_modal_permission_prompt", "download_guard_auto_quarantine_to_review_page", "statusbar_link_hover_preview", "statusbar_image_hover_preview", "vault_use_strict_password_receiver_guard", "download_guard_open_released_file_or_folder", "download_guard_no_home_downloads_until_release", "statusbar_link_hover_preview", "statusbar_image_hover_preview", "vault_use_strict_password_receiver_guard", "vault_account_hint_dropdown", "download_guard_progress_window", "download_guard_lime_complete_icon", "download_guard_backend_active_progress", "download_guard_v12_contract", "download_guard_urgent_cancel_poll", "download_guard_cancel_ack", "browser_owned_webkit_cancel", "tab_row_new_tab_plus_button", "vault_2fa_icon_button", "tooltips",
            "preferences_window", "preferences_general_tab", "preferences_search_tab", "preferences_download_guard_tab", "preferences_security_tab", "preferences_site_data_tab", "preferences_vault_tab", "search_engine_selector_gui", "custom_search_url_gui", "download_guard_settings_gui", "download_guard_release_dir_gui", "site_data_manager", "site_data_clear_gui", "security_profile_gui", "phase4_user_ready_gui", "download_guard_lightweight_polling", "download_guard_no_ui_thread_blocking_target", "browser_first_download_flow", "download_guard_post_completion_handoff_only", "download_guard_no_active_transfer_cli_calls", "firefox_chrome_download_ux", "download_button_green_active_complete", "downloads_page_go_to_file_button", "default_bookmarks_removed", "sentinel_wallet_integration", "wallet_status_json", "wallet_explicit_open_only", "packaged_sentinelos_homepage", "sentinel_home_new_tab_default",
            "vault_2fa_manual_launcher", "vault_bridge_status_json", "vault_account_hints_json", "vault_account_hints_only_no_secrets", "vault_browser_pair_half_policy", "vault_use_or_manual_login_prompt_foundation", "vault_login_prompt_bar", "vault_login_prompt_site_policy", "downloads_page", "download_guard_backend_handoff", "download_guard_icon_status_preview", "download_guard_completion_prompt", "download_guard_no_modal_permission_prompt", "download_guard_auto_quarantine_to_review_page", "statusbar_link_hover_preview", "statusbar_image_hover_preview", "vault_use_strict_password_receiver_guard", "vault_login_prompt_use_vault_enter_manually_never", "vault_no_auto_submit_default", "vault_2fa_source_password_vault",
        ],
        "dependency_status": dependency_status(),
        "generated_at": now_iso(),
    }
    if include_paths:
        status["paths"] = {
            "config": str(CONFIG), "data": str(DATA_DIR), "state": str(STATE_DIR), "cache": str(CACHE_DIR),
            "bookmarks": str(BOOKMARKS), "session": str(SESSION), "security_events": str(SECURITY_EVENTS),
            "webkit_data": str(WEBKIT_DATA_DIR), "webkit_cache": str(WEBKIT_CACHE_DIR),
            "crash_log": str(CRASH), "desktop_file": str(DESKTOP), "package_share": str(SHARE),
            "download_policy": str(DOWNLOAD_POLICY), "download_directory": str(Path(str(cfg.get("download_directory", str(DOWNLOADS_DIR)))).expanduser()),
            "content_policy": str(CONTENT_POLICY), "content_blocklist": str(CONTENT_BLOCKLIST), "content_allowlist": str(CONTENT_ALLOWLIST),
            "aegis_bridge_policy": str(AEGIS_BRIDGE_POLICY), "aegis_bridge_status": str(AEGIS_BRIDGE_STATUS), "aegis_bridge_events": str(AEGIS_BRIDGE_EVENTS),
            "search_policy": str(SEARCH_POLICY), "vault_bridge_policy": str(VAULT_BRIDGE_POLICY), "vault_account_hints": str(VAULT_ACCOUNT_HINTS), "vault_login_policy": str(VAULT_LOGIN_POLICY), "homepage_file": str(HOMEPAGE_FILE),
        }
    return status


def run_self_test() -> Tuple[bool, List[str]]:
    """Fast non-GUI self-test for the RC20 coordinated Browser/DLG/Wallet line.

    Keep this test intentionally local and lightweight: no GTK startup, no live
    WebKit rendering, and no active-transfer Download Guard polling. Deep DLG and
    Wallet checks are exposed as explicit phase commands.
    """
    tests: List[Tuple[str, bool]] = []
    cfg = load_config(False)
    tests.append(("runtime version", _version_tuple(VERSION) >= _version_tuple("1.0.4")))
    tests.append(("URL normalization domain", normalize_url("example.com") == "https://example.com"))
    tests.append(("URL normalization search", "duckduckgo.com" in normalize_url("test search")))
    tests.append(("homepage default installed", homepage_default_test_json().get("ok") is True))
    tests.append(("homepage runtime city startup", homepage_runtime_city_test_json().get("ok") is True))
    tests.append(("homepage widget saved city source", homepage_widget_saved_city_source_test_json().get("ok") is True))
    tests.append(("HTTPS-first enabled", cfg.get("https_first_address_entry_enabled") is True))
    tests.append(("browser-first downloads preserved", cfg.get("browser_first_download_flow_enabled") is True and cfg.get("download_guard_post_completion_handoff_only") is True and cfg.get("download_guard_no_active_transfer_cli_calls") is True))
    tests.append(("no live downloads-page refresh", cfg.get("downloads_page_no_live_auto_refresh_for_stability") is True))
    tests.append(("no default bookmarks", cfg.get("default_bookmarks_empty_by_default") is True and default_bookmarks() == []))
    tests.append(("wallet visible/crypto/NFT gate", phase5r_wallet_visibility_crypto_nft_test_json().get("ok") is True))
    tests.append(("wallet no browser secret storage", cfg.get("wallet_browser_no_secret_storage") is True and cfg.get("wallet_browser_never_receives_wallet_secrets") is True))
    tests.append(("blockchain provider bridge", blockchain_provider_test_json().get("ok") is True))
    tests.append(("tor toolbar bridge", tor_routing_bridge_test_json().get("ok") is True))
    tests.append(("tor menu identity", tor_menu_identity_test_json().get("ok") is True))
    tests.append(("walletconnect multichain", walletconnect_multichain_test_json().get("ok") is True))
    tests.append(("walletconnect approval handoff", walletconnect_approval_handoff_test_json().get("ok") is True))
    tests.append(("tor user-readable gui", tor_user_readable_gui_test_json().get("ok") is True))
    tests.append(("tor country label sanitization", tor_country_label_sanitization_test_json().get("ok") is True))
    tests.append(("walletconnect provider exact handoff", walletconnect_provider_exact_handoff_test_json().get("ok") is True))
    msgs: List[str] = []
    ok = True
    for name, result in tests:
        msgs.append(("PASS: " if result else "FAIL: ") + name)
        ok = ok and result
    return ok, msgs

def import_stack():
    import gi  # type: ignore
    gi.require_version("Gtk", "3.0")
    try:
        gi.require_version("WebKit2", "4.1")
    except ValueError:
        gi.require_version("WebKit2", "4.0")
    from gi.repository import Gdk, GLib, Gtk, WebKit2  # type: ignore
    return Gtk, Gdk, GLib, WebKit2


def safe_set(obj: Any, prop: str, value: Any) -> None:
    try:
        obj.set_property(prop, value)
    except Exception:
        pass


def apply_css(Gtk: Any, Gdk: Any) -> None:
    css = f"""
    window {{background:{AEGIS_BG};color:{AEGIS_TEXT};}}
    .sentinel-root {{background:{AEGIS_BG};}}
    .sentinel-toolbar {{background:{AEGIS_PANEL};color:{AEGIS_TEXT};border-bottom:1px solid {AEGIS_PANEL2};padding:4px;}}
    .sentinel-bookmarks-toolbar {{background:#0F1419;color:{AEGIS_TEXT};border-bottom:1px solid {AEGIS_PANEL2};padding:3px 6px;}}
    .sentinel-login-prompt {{background:#101923;color:{AEGIS_TEXT};border-top:1px solid {AEGIS_PANEL2};border-bottom:1px solid {AEGIS_GOLD};padding:4px 8px;}}
    .sentinel-tab-new {{background:{AEGIS_PANEL2};color:{AEGIS_CYAN};border:1px solid {AEGIS_PANEL2};border-radius:4px;padding:2px 8px;}}
    button {{background:{AEGIS_PANEL2};color:{AEGIS_TEXT};border:1px solid {AEGIS_PANEL2};border-radius:4px;padding:3px 7px;}}
    button:hover {{color:{AEGIS_CYAN};border-color:{AEGIS_CYAN};}}
    .sentinel-tor-button {{background:#121922;color:{AEGIS_MUTED};border:1px solid #394653;border-radius:16px;padding:4px 10px;font-weight:bold;}}
    .sentinel-tor-button:checked {{background:#132419;color:{AEGIS_GREEN};border-color:{AEGIS_GREEN};}}
    .sentinel-wallet-button {{background:#101820;color:{AEGIS_GOLD};border:1px solid {AEGIS_GOLD};border-radius:5px;}}
    entry {{background:#232A31;color:{AEGIS_TEXT};border:1px solid #3A4652;border-radius:5px;padding:5px 8px;}}
    entry:focus {{border-color:{AEGIS_CYAN};}}
    notebook tab {{background:{AEGIS_PANEL};color:{AEGIS_TEXT};border:1px solid {AEGIS_PANEL2};padding:2px 6px;min-height:20px;}}
    notebook tab:checked {{border-bottom:2px solid {AEGIS_GOLD};}}
    .sentinel-security {{background:{AEGIS_PANEL2};color:{AEGIS_GOLD};border:1px solid {AEGIS_PANEL2};border-radius:4px;padding:4px 8px;font-weight:bold;}}
    .sentinel-download-idle {{color:{AEGIS_GOLD};border-color:{AEGIS_PANEL2};}}
    .sentinel-download-active {{color:#B7F774;border-color:#B7F774;}}
    .sentinel-download-complete {{color:#B7F774;border-color:#B7F774;}}
    .sentinel-status {{background:{AEGIS_PANEL};color:{AEGIS_MUTED};border-top:1px solid {AEGIS_PANEL2};padding:3px 8px;}}
    """
    provider = Gtk.CssProvider()
    provider.load_from_data(css.encode("utf-8"))
    screen = Gdk.Screen.get_default()
    if screen:
        Gtk.StyleContext.add_provider_for_screen(screen, provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)


class Window:
    def __init__(self, safe_mode: bool = False, startup_url: str = "", gui_smoke_test: bool = False, private_session: bool = False):
        self.Gtk, self.Gdk, self.GLib, self.WebKit2 = import_stack()
        Gtk = self.Gtk
        apply_css(Gtk, self.Gdk)
        ensure_dirs()
        self.safe_mode = safe_mode
        self.gui_smoke_test = gui_smoke_test
        self.config = load_config(safe_mode)
        self.search_policy = load_search_policy()
        self.private_session = bool(private_session)
        if self.private_session:
            self.config["private_mode"] = True
            self.config["save_session"] = False
            self.config["restore_tabs"] = False
            self.config["search_url"] = effective_search_url(self.config, self.search_policy, private_mode=True)
        else:
            self.config["search_url"] = effective_search_url(self.config, self.search_policy, private_mode=False)
        self.tabs: List[Dict[str, Any]] = []
        self.approved_dangerous_downloads = set()
        self.download_context: Dict[int, Dict[str, Any]] = {}
        self.pending_downloads_by_uri: Dict[str, Dict[str, Any]] = {}
        self.active_wallet_provider_requests: Dict[str, Dict[str, Any]] = {}
        self.last_download_guard_item: Optional[Dict[str, Any]] = None
        self.download_cancel_poll_timer_id = None
        self.processed_download_cancel_ids = set()
        self.web_context = self.create_web_context()

        self.window = Gtk.Window(title=APP_NAME)
        self.window.set_default_size(1280, 760)
        self.window.connect("delete-event", self._on_delete)
        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        root.get_style_context().add_class("sentinel-root")
        self.window.add(root)

        if self.config.get("menu_bar_enabled", True):
            root.pack_start(self.build_menu_bar(), False, False, 0)

        bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        bar.get_style_context().add_class("sentinel-toolbar")
        root.pack_start(bar, False, False, 0)

        def icon_button(fallback: str, icon_name: str, tooltip: str) -> Any:
            b = Gtk.Button()
            try:
                img = Gtk.Image.new_from_icon_name(icon_name, Gtk.IconSize.BUTTON)
                b.set_image(img)
                b.set_always_show_image(True)
            except Exception:
                b.set_label(fallback)
            b.set_tooltip_text(tooltip)
            return b

        self.back = Gtk.Button(label="←"); self.back.set_tooltip_text("Back")
        self.fwd = Gtk.Button(label="→"); self.fwd.set_tooltip_text("Forward")
        self.reload_b = Gtk.Button(label="⟳"); self.reload_b.set_tooltip_text("Reload")
        self.stop_b = Gtk.Button(label="×"); self.stop_b.set_tooltip_text("Stop loading")
        self.home = icon_button("⌂", "go-home-symbolic", "Home")
        self.new_tab_action = None
        self.perms = icon_button("🛡", "security-high-symbolic", "Security controls")
        self.bookmarks_button = icon_button("★", "user-bookmarks-symbolic", "Save bookmark for this page")
        self.downloads_button = icon_button("⇩", "folder-download-symbolic", "Downloads / Download Guard page")
        # v0.10.4: force a visible markup label for DLG state feedback because some GTK themes
        # do not recolour symbolic toolbar icons reliably.
        self.downloads_button_label = Gtk.Label()
        self.download_button_flash_timer_id = None
        self.download_button_flash_on = False
        self.download_button_state = "idle"
        self.download_button_detail = ""
        try:
            self.downloads_button.set_image(self.downloads_button_label)
            self.downloads_button.set_always_show_image(True)
            self.downloads_button.set_sensitive(True)
        except Exception:
            pass
        self.incognito = icon_button("◌", "changes-prevent-symbolic", "Open incognito/private window")
        self.vault_2fa = icon_button("◎", "dialog-password-symbolic", "Open restricted Vault-owned 2FA mini popup for this site")
        self.wallet_button = Gtk.Button(label="◈")
        self.wallet_button.set_tooltip_text("Open Sentinel Wallet — crypto-only wallet and NFT inventory")
        try:
            self.wallet_button.get_style_context().add_class("sentinel-wallet-button")
        except Exception:
            pass
        self.set_download_icon_state("idle")
        self.security_label = Gtk.Label(label="LOCAL")
        self.security_label.get_style_context().add_class("sentinel-security")
        self.security_label.set_tooltip_text("Page security state")
        self.tor_button = Gtk.ToggleButton(label="TOR")
        try:
            self.tor_button.get_style_context().add_class("sentinel-tor-button")
        except Exception:
            pass
        tor_status = tor_routing_status_json(include_paths=False)
        self.tor_button.set_active(bool(tor_status.get("enabled")))
        self.tor_button.set_tooltip_text("Tor routing switch. Once Tor is installed/running locally, ON routes web pages through socks5://127.0.0.1:9050.")
        self.update_tor_button_label(refresh_country=False)
        self.tor_button.connect("toggled", self.on_tor_toggle)
        self.tor_button.connect("button-press-event", self.show_tor_button_context_menu)
        self.address = Gtk.Entry()
        self.address.set_placeholder_text("Search or enter address")
        self.address.set_tooltip_text("Search or enter a website address")
        # Address-bar favourite star remains removed by request; bookmarking remains available through
        # the Bookmarks menu and Ctrl+D. Keeping the address entry visually clean also avoids accidental
        # hit-target conflicts with the typed URL/search text.
        self.address.connect("activate", lambda e: self.load(e.get_text()))

        left_buttons = [
            (self.back, self.go_back), (self.fwd, self.go_fwd), (self.reload_b, self.reload),
            (self.stop_b, self.stop), (self.home, lambda: self.load(self.config.get("home_url", "about:blank"))),
        ]
        for button, callback in left_buttons:
            button.connect("clicked", lambda _b, cb=callback: cb())
            bar.pack_start(button, False, False, 0)
        if self.config.get("show_security_indicator", True) and not self.config.get("https_indicator_inside_address_bar", True):
            bar.pack_start(self.security_label, False, False, 0)
        if self.config.get("tor_toolbar_switch_enabled", True):
            bar.pack_start(self.tor_button, False, False, 0)
        bar.pack_start(self.address, True, True, 0)
        toolbar_right = [
            # The toolbar star is the quick save action, not a status panel.
            # It must open the same bookmark editor used by Bookmarks → Add Bookmark and right-click edit.
            (self.bookmarks_button, self.bookmark),
            (self.downloads_button, self.show_downloads_page),
            (self.incognito, self.open_private_window),
            # Keep Security Controls directly beside the 2FA/Vault button as a right-side security pair.
            (self.perms, self.show_control_panel),
            (self.vault_2fa, self.open_vault_2fa_bridge_ui),
            (self.wallet_button, self.open_sentinel_wallet_ui),
        ]
        for button, callback in toolbar_right:
            button.connect("clicked", lambda _b, cb=callback: cb())
            if button is self.wallet_button and not self.config.get("wallet_integration_enabled", True):
                continue
            bar.pack_start(button, False, False, 0)

        self.bookmarks_bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
        self.bookmarks_bar.get_style_context().add_class("sentinel-bookmarks-toolbar")
        self._enable_bookmarks_toolbar_context_menu()
        # The bookmarks toolbar is always packed once, then shown/hidden.
        # Older builds only packed it when initially visible, so the menu toggle could not reliably
        # restore it after it had been hidden in config.
        root.pack_start(self.bookmarks_bar, False, False, 0)
        self.refresh_bookmarks_toolbar()
        if self.config.get("show_bookmarks_bar", True) and self.config.get("bookmarks_toolbar_enabled", True):
            self.bookmarks_bar.set_no_show_all(False)
            self.bookmarks_bar.show_all()
        else:
            self.bookmarks_bar.set_no_show_all(True)
            self.bookmarks_bar.hide()

        self.vault_login_bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        self.vault_login_bar.get_style_context().add_class("sentinel-login-prompt")
        self.vault_login_label = Gtk.Label(label="")
        self.vault_login_label.set_xalign(0)
        self.vault_login_label.set_tooltip_text("Sentinel Password Vault login prompt. Browser stores no password or 2FA secret.")
        self.vault_login_use = Gtk.Button(label="Use Vault")
        self.vault_login_use.set_tooltip_text("Ask Sentinel Password Vault for this login. Requires Vault approval; browser stores no secret.")
        self.vault_login_save = Gtk.Button(label="Save to Vault")
        self.vault_login_save.set_tooltip_text("Open Sentinel Password Vault's restricted receiver so the user can store credentials there. Browser does not read or store the password.")
        self.vault_login_manual = Gtk.Button(label="Enter Manually")
        self.vault_login_manual.set_tooltip_text("Hide this prompt and enter credentials manually.")
        self.vault_login_never = Gtk.Button(label="Never for Site")
        self.vault_login_never.set_tooltip_text("Do not show the Vault login prompt for this site again.")
        self.vault_login_use.connect("clicked", lambda *_: self.use_vault_for_login())
        self.vault_login_save.connect("clicked", lambda *_: self.save_credentials_to_vault())
        self.vault_login_manual.connect("clicked", lambda *_: self.hide_vault_login_prompt("manual"))
        self.vault_login_never.connect("clicked", lambda *_: self.never_vault_for_current_site())
        self.vault_login_bar.pack_start(self.vault_login_label, True, True, 8)
        self.vault_login_bar.pack_start(self.vault_login_use, False, False, 0)
        self.vault_login_bar.pack_start(self.vault_login_save, False, False, 0)
        self.vault_login_bar.pack_start(self.vault_login_manual, False, False, 0)
        self.vault_login_bar.pack_start(self.vault_login_never, False, False, 0)
        root.pack_start(self.vault_login_bar, False, False, 0)
        self.vault_login_bar.set_no_show_all(True)
        self.vault_login_bar.hide()

        self.nb = Gtk.Notebook()
        self.nb.set_scrollable(True)
        self.nb.connect("switch-page", lambda *_: self.on_switch())
        try:
            self.new_tab_action = Gtk.Button(label="+")
            self.new_tab_action.set_tooltip_text("New tab")
            self.new_tab_action.get_style_context().add_class("sentinel-tab-new")
            self.new_tab_action.connect("clicked", lambda *_: self.create_tab(self.config.get("home_url", HOMEPAGE_URI), True))
            self.nb.set_action_widget(self.new_tab_action, Gtk.PackType.START)
            self.new_tab_action.show_all()
        except Exception as exc:
            log_security_event("tab_row_new_button_unavailable", {"error": str(exc)})
        root.pack_start(self.nb, True, True, 0)

        self.status = Gtk.Label(label="Ready")
        self.status.set_xalign(0)
        self.status.get_style_context().add_class("sentinel-status")
        self.last_status_text = "Ready"
        self.status_hover_preview_active = False
        if self.config.get("show_statusbar", True):
            root.pack_start(self.status, False, False, 0)
        self.window.connect("key-press-event", self.on_key)

        target = startup_url or self.config.get("home_url", "about:blank")
        self.create_tab(target, True)
        self.window.show_all()
        self.update_nav()
        self.update_security_indicator(target)
        if gui_smoke_test:
            self.GLib.timeout_add(800, self.smoke_quit)

    def apply_network_proxy_to_context(self, ctx: Any) -> None:
        """Best-effort WebKit proxy routing."""
        try:
            W = self.WebKit2
            tor = tor_routing_status_json(include_paths=False)
            if self.config.get("tor_integration_enabled", True) and tor.get("enabled") and tor.get("ready_to_route"):
                if hasattr(W, "NetworkProxySettings") and hasattr(ctx, "set_network_proxy_settings"):
                    settings = W.NetworkProxySettings.new(str(tor.get("socks_uri")), ["localhost", "127.0.0.1", "::1"])
                    ctx.set_network_proxy_settings(W.NetworkProxyMode.CUSTOM, settings)
                    log_security_event("tor_proxy_applied", {"socks_uri": tor.get("socks_uri")})
                    return
            mode = str(self.config.get("proxy_mode", "system") or "system")
            if hasattr(ctx, "set_network_proxy_settings") and hasattr(W, "NetworkProxyMode"):
                if mode == "direct":
                    ctx.set_network_proxy_settings(W.NetworkProxyMode.NO_PROXY, None)
                    log_security_event("network_proxy_direct_applied", {})
                elif mode == "custom":
                    proxy = str(self.config.get("proxy_socks") or self.config.get("proxy_https") or self.config.get("proxy_http") or "").strip()
                    if proxy and hasattr(W, "NetworkProxySettings"):
                        bypass = [x.strip() for x in str(self.config.get("proxy_bypass", "localhost,127.0.0.1,::1")).split(",") if x.strip()]
                        settings = W.NetworkProxySettings.new(proxy, bypass)
                        ctx.set_network_proxy_settings(W.NetworkProxyMode.CUSTOM, settings)
                        log_security_event("network_proxy_custom_applied", {"proxy": proxy, "bypass": bypass})
                else:
                    ctx.set_network_proxy_settings(W.NetworkProxyMode.DEFAULT, None)
        except Exception as exc:
            log_security_event("network_proxy_apply_failed", {"error": str(exc)})

    def create_web_context(self) -> Any:
        W = self.WebKit2
        try:
            manager = W.WebsiteDataManager.new(
                "base-data-directory", str(WEBKIT_DATA_DIR),
                "base-cache-directory", str(WEBKIT_CACHE_DIR),
            )
            ctx = W.WebContext.new_with_website_data_manager(manager)
            if self.config.get("enable_webkit_sandbox_attempt", True) and hasattr(ctx, "set_sandbox_enabled"):
                try:
                    ctx.set_sandbox_enabled(True)
                    log_security_event("webkit_sandbox_enabled_attempted", {"api_available": True})
                except Exception as exc:
                    log_security_event("webkit_sandbox_enable_failed", {"error": str(exc)})
            try:
                ctx.connect("download-started", self.on_download_started)
                log_security_event("webkit_context_download_started_connected", {"context": "app_scoped"})
            except Exception as exc:
                log_security_event("webkit_context_download_started_unavailable", {"error": str(exc)})
            self.apply_network_proxy_to_context(ctx)
            return ctx
        except Exception as exc:
            log_crash(exc)
            ctx = W.WebContext.get_default()
            if self.config.get("enable_webkit_sandbox_attempt", True) and hasattr(ctx, "set_sandbox_enabled"):
                try:
                    ctx.set_sandbox_enabled(True)
                    log_security_event("webkit_default_context_sandbox_enabled_attempted", {"api_available": True})
                except Exception as exc2:
                    log_security_event("webkit_default_context_sandbox_enable_failed", {"error": str(exc2)})
            try:
                ctx.connect("download-started", self.on_download_started)
                log_security_event("webkit_context_download_started_connected", {"context": "default"})
            except Exception as exc3:
                log_security_event("webkit_context_download_started_unavailable", {"error": str(exc3)})
            self.apply_network_proxy_to_context(ctx)
            return ctx

    def update_tor_button_label(self, refresh_country: bool = False) -> None:
        try:
            st = tor_routing_status_json(include_paths=False)
            if not st.get("enabled"):
                label = "TOR"
                tip = "Tor routing is off. Click to route web pages through local Tor when installed."
            elif not st.get("ready_to_route"):
                label = "TOR: Setup"
                tip = "Tor is enabled, but local Tor is not listening yet. Use Tor → Test Tor Connection."
            else:
                country = tor_exit_country_status_json(refresh=refresh_country)
                country_name = _sanitize_tor_country(country.get("country"))
                if country_name:
                    label = "TOR: " + country_name[:22]
                    tip = "Tor active. Exit country: " + country_name + ". Right-click for Change Identity."
                elif country.get("status") == "country_probe_failed":
                    label = "TOR: On"
                    tip = str(country.get("message"))
                else:
                    label = "TOR: On"
                    tip = "Tor routing is active. Right-click for Change Identity or Tor Status."
            self.tor_button.set_label(label)
            self.tor_button.set_tooltip_text(tip)
        except Exception as exc:
            log_security_event("tor_button_label_update_failed", {"error": str(exc)})

    def themed_status_dialog(self, title: str, headline: str, rows: List[Tuple[str, str, str]], note: str = "") -> None:
        Gtk = self.Gtk
        dialog = Gtk.Dialog(title=title, transient_for=self.window, flags=0)
        dialog.add_button("Close", Gtk.ResponseType.CLOSE)
        dialog.set_default_response(Gtk.ResponseType.CLOSE)
        try:
            dialog.set_default_size(520, 360)
        except Exception:
            pass
        box = dialog.get_content_area()
        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10, margin=14)
        try:
            outer.get_style_context().add_class("sentinel-root")
        except Exception:
            pass
        box.add(outer)
        title_lbl = Gtk.Label()
        title_lbl.set_markup("<span size='large' weight='bold' foreground='%s'>%s</span>" % (AEGIS_GOLD, html.escape(headline)))
        title_lbl.set_xalign(0)
        outer.pack_start(title_lbl, False, False, 0)
        grid = Gtk.Grid(column_spacing=12, row_spacing=8)
        outer.pack_start(grid, False, False, 0)
        for i, (label, value, tone) in enumerate(rows):
            l = Gtk.Label(label=label)
            l.set_xalign(0)
            try: l.get_style_context().add_class("sentinel-status-label")
            except Exception: pass
            v = Gtk.Label()
            color = AEGIS_TEXT
            if tone == "ok": color = AEGIS_GREEN
            elif tone == "warn": color = AEGIS_GOLD
            elif tone == "bad": color = AEGIS_RED
            elif tone == "info": color = AEGIS_CYAN
            v.set_markup("<span weight='bold' foreground='%s'>%s</span>" % (color, html.escape(str(value))))
            v.set_xalign(0)
            grid.attach(l, 0, i, 1, 1)
            grid.attach(v, 1, i, 1, 1)
        if note:
            note_lbl = Gtk.Label(label=note)
            note_lbl.set_line_wrap(True)
            note_lbl.set_xalign(0)
            try: note_lbl.get_style_context().add_class("sentinel-status")
            except Exception: pass
            outer.pack_start(note_lbl, False, False, 0)
        dialog.show_all()
        dialog.run()
        dialog.destroy()

    def on_tor_toggle(self, button: Any) -> None:
        enabled = bool(button.get_active())
        save_tor_routing(enabled, "toolbar")
        try:
            self.apply_network_proxy_to_context(self.web_context)
        except Exception as exc:
            log_security_event("tor_toggle_apply_failed", {"error": str(exc)})
        st = tor_routing_status_json(include_paths=False)
        self.update_tor_button_label(refresh_country=bool(enabled and st.get("ready_to_route")))
        if enabled and not st.get("ready_to_route"):
            self.set_status("TOR requested, but local Tor is not ready. Use Tor → Test Tor Connection.")
        elif enabled:
            country = tor_exit_country_status_json(refresh=False)
            suffix = (" via " + str(country.get("country"))) if country.get("country") else ""
            self.set_status("TOR routing ON" + suffix + ". Reload tab to use the route.")
        else:
            self.set_status("TOR routing OFF. Browser returned to system/direct routing.")


    def set_tor_enabled_ui(self, enabled: bool) -> None:
        save_tor_routing(bool(enabled), "menu")
        try:
            self.tor_button.set_active(bool(enabled))
        except Exception:
            pass
        try:
            self.apply_network_proxy_to_context(self.web_context)
        except Exception as exc:
            log_security_event("tor_menu_apply_failed", {"error": str(exc), "enabled": bool(enabled)})
        st = tor_routing_status_json(include_paths=False)
        self.update_tor_button_label(refresh_country=bool(enabled and st.get("ready_to_route")))
        if enabled and not st.get("ready_to_route"):
            self.set_status("TOR enabled, but local Tor is not ready. Use Tor → Test Tor Connection.")
        elif enabled:
            country = tor_exit_country_status_json(refresh=False)
            suffix = (" via " + str(country.get("country"))) if country.get("country") else ""
            self.set_status("TOR routing enabled" + suffix + ". Reload tabs to use the Tor route.")
        else:
            self.set_status("TOR routing disabled.")

    def show_tor_button_context_menu(self, widget: Any, event: Any) -> bool:
        try:
            if getattr(event, "button", 0) != 3:
                return False
            Gtk = self.Gtk
            menu = Gtk.Menu()
            def add(label: str, cb: Any) -> None:
                item = Gtk.MenuItem(label=label)
                item.connect("activate", lambda *_: cb())
                item.show()
                menu.append(item)
            add("Change Tor Identity", self.change_tor_identity_ui)
            add("Tor Settings…", self.show_tor_settings_dialog)
            add("Tor Status", self.show_tor_status_panel)
            add("Test Tor Connection", self.show_tor_test_panel)
            add("Disable Tor", lambda: self.set_tor_enabled_ui(False))
            menu.show_all()
            try:
                menu.popup_at_pointer(event)
            except Exception:
                menu.popup(None, None, None, None, event.button, event.time)
            return True
        except Exception as exc:
            log_security_event("tor_button_context_menu_failed", {"error": str(exc)})
            return False

    def change_tor_identity_ui(self) -> None:
        if not self.confirm("Change Tor Identity", "Request a new Tor circuit identity?\n\nThis uses Tor ControlPort SIGNAL NEWNYM where available. It applies to new connections; reload Tor tabs for the cleanest switch."):
            return
        result = signal_tor_newnym("gui")
        msg = str(result.get("message", ""))
        if result.get("ok"):
            try:
                if TOR_EXIT_STATUS.exists(): TOR_EXIT_STATUS.unlink()
            except Exception:
                pass
            self.update_tor_button_label(refresh_country=True)
            self.set_status(msg)
            self.themed_status_dialog("Tor Identity", "Tor identity change requested", [("Result", msg, "ok"), ("Next step", "Reload Tor tabs for the cleanest switch", "info")], "New Tor circuits apply to new connections. Existing tabs may keep old connections until reloaded.")
        else:
            self.update_tor_button_label(refresh_country=False)
            self.set_status("Tor identity change failed: " + msg)
            self.themed_status_dialog("Tor Identity", "Tor identity change failed", [("Result", msg, "bad"), ("ControlPort", "Check Tor Settings", "warn")], "Tor identity changes require local Tor ControlPort/AuthCookie access.")

    def show_tor_settings_dialog(self) -> None:
        cfg = load_config(False)
        result = self.text_entry_dialog(
            "Tor Settings",
            [
                {"key": "socks_host", "label": "SOCKS host", "value": str(cfg.get("tor_socks_host", "127.0.0.1")), "tooltip": "Local Tor SOCKS host"},
                {"key": "socks_port", "label": "SOCKS port", "value": str(cfg.get("tor_socks_port", 9050)), "tooltip": "Local Tor SOCKS port"},
                {"key": "control_host", "label": "Control host", "value": str(cfg.get("tor_control_host", "127.0.0.1")), "tooltip": "Local Tor ControlPort host"},
                {"key": "control_port", "label": "Control port", "value": str(cfg.get("tor_control_port", 9051)), "tooltip": "Local Tor ControlPort port"},
            ],
            "Save",
        )
        if not result:
            self.set_status("Tor settings unchanged")
            return
        raw = load_json(CONFIG, {})
        if not isinstance(raw, dict):
            raw = {}
        raw["tor_socks_host"] = result.get("socks_host", "127.0.0.1") or "127.0.0.1"
        try:
            raw["tor_socks_port"] = int(result.get("socks_port", "9050") or 9050)
        except Exception:
            raw["tor_socks_port"] = 9050
        raw["tor_control_host"] = result.get("control_host", "127.0.0.1") or "127.0.0.1"
        try:
            raw["tor_control_port"] = int(result.get("control_port", "9051") or 9051)
        except Exception:
            raw["tor_control_port"] = 9051
        save_json(CONFIG, merged_config(raw))
        self.config = load_config(False)
        self.set_status("Tor settings saved")
        self.show_tor_status_panel()

    def show_tor_status_panel(self) -> None:
        routing = tor_routing_status_json(False)
        control = tor_control_status_json(False)
        country = tor_exit_country_status_json(refresh=False)
        self.update_tor_button_label(refresh_country=False)
        rows = [
            ("Tor switch", "On" if routing.get("enabled") else "Off", "ok" if routing.get("enabled") else "warn"),
            ("Connection", "Ready" if routing.get("ready_to_route") else "Setup needed", "ok" if routing.get("ready_to_route") else "bad"),
            ("Exit country", str(country.get("country") or "Unknown"), "info" if country.get("country") else "warn"),
            ("SOCKS route", str(routing.get("socks_uri", "")), "info"),
            ("Identity control", "Available" if control.get("control_port_open") and control.get("auth_cookie_present") else "Not ready", "ok" if control.get("control_port_open") and control.get("auth_cookie_present") else "warn"),
        ]
        self.themed_status_dialog("Tor Status", "Tor routing status", rows, "This panel is display-only. It stores no browsing targets. Use the TOR button like an Opera/Aloha-style privacy switch.")

    def show_tor_test_panel(self) -> None:
        routing = tor_routing_bridge_test_json()
        identity = tor_menu_identity_test_json()
        country = tor_exit_country_status_json(refresh=True)
        self.update_tor_button_label(refresh_country=False)
        rows = [
            ("Local Tor SOCKS", "Ready" if routing.get("status", {}).get("ready_to_route") else "Not ready", "ok" if routing.get("status", {}).get("ready_to_route") else "bad"),
            ("Country check", str(country.get("country") or country.get("message") or "Unknown"), "ok" if country.get("country") else "warn"),
            ("Change Identity", "Ready" if identity.get("ok") else "Needs setup", "ok" if identity.get("ok") else "warn"),
            ("Browser route", "Tor active for new loads" if routing.get("status", {}).get("active_for_new_loads") else "Direct/system or setup needed", "ok" if routing.get("status", {}).get("active_for_new_loads") else "warn"),
        ]
        self.themed_status_dialog("Test Tor Connection", "Tor connection test", rows, "If the country is unknown but SOCKS is ready, try again after loading a page through Tor. Right-click TOR for Change Identity.")

    def show_blockchain_status_panel(self) -> None:
        self.info_dialog("Blockchain Provider Status", json.dumps(blockchain_provider_status_json(False), indent=2, sort_keys=True))

    def show_walletconnect_status_panel(self) -> None:
        self.info_dialog("WalletConnect / Multi-chain Status", json.dumps(walletconnect_status_json(False), indent=2, sort_keys=True))

    def show_walletconnect_uri_dialog(self) -> None:
        result = self.text_entry_dialog("WalletConnect URI", [{"key": "uri", "label": "wc: URI", "value": "", "tooltip": "Paste a WalletConnect wc: or walletconnect: URI"}], "Send to Wallet")
        if not result:
            self.set_status("WalletConnect cancelled")
            return
        uri = (result.get("uri") or "").strip()
        if not uri:
            self.set_status("WalletConnect URI empty")
            return
        self.handle_walletconnect_uri(uri, "manual-dialog")

    def handle_walletconnect_uri(self, uri: str, source: str = "navigation") -> bool:
        if not self.config.get("walletconnect_uri_capture_enabled", True):
            return False
        clean = (uri or "").strip()
        if not (clean.startswith("wc:") or clean.startswith("walletconnect:")):
            return False
        try:
            ensure_dirs()
            sessions = load_json(WALLETCONNECT_SESSIONS, [])
            if not isinstance(sessions, list):
                sessions = []
            rec = {"time": now_iso(), "source": source, "uri_prefix": clean[:16], "uri_sha256": hashlib.sha256(clean.encode("utf-8")).hexdigest(), "origin": self.current_uri()}
            sessions.append(rec)
            save_json(WALLETCONNECT_SESSIONS, sessions[-50:])
            note = json.dumps({"provider": "walletconnect", "uri": clean, "source": source, "origin": self.current_uri()}, sort_keys=True)[:3500]
            req_id = new_wallet_request_id("walletconnect")
            obj = run_wallet_json(["browser-bridge", "--write-request", "--request-id", req_id, "--request-kind", "walletconnect_pairing", "--browser-origin", self.current_uri() or "walletconnect", "--note", note], timeout=5)
            launch = {}
            try:
                launch = launch_sentinel_wallet(self.current_uri() or "walletconnect", request_id=req_id, request_kind="walletconnect_pairing")
            except Exception as launch_exc:
                launch = {"ok": False, "error": str(launch_exc)}
            if launch.get("ok"):
                self.set_status("Sentinel Wallet opened for WalletConnect approval — approve or reject inside Wallet")
            else:
                self.set_status("WalletConnect request saved; open Sentinel Wallet to approve")
            log_security_event("walletconnect_uri_forwarded", {"source": source, "request_id": obj.get("request_id", req_id), "uri_sha256": rec["uri_sha256"]})
            return True
        except Exception as exc:
            log_security_event("walletconnect_uri_forward_failed", {"error": str(exc), "source": source})
            self.set_status("WalletConnect forward failed: " + str(exc))
            return True

    def set_status(self, text: str) -> None:
        self.last_status_text = text
        if not getattr(self, "status_hover_preview_active", False):
            self.status.set_text(text)

    def _short_status_uri(self, uri: str, limit: int = 150) -> str:
        uri = (uri or "").strip()
        if len(uri) <= limit:
            return uri
        return uri[: max(20, limit - 1)] + "…"

    def show_status_hover_preview(self, label: str, uri: str) -> None:
        if not self.config.get("statusbar_link_hover_preview_enabled", True):
            return
        uri = (uri or "").strip()
        if not uri:
            self.clear_status_hover_preview()
            return
        self.status_hover_preview_active = True
        self.status.set_text(f"{label}: {self._short_status_uri(uri)}")

    def clear_status_hover_preview(self) -> None:
        if getattr(self, "status_hover_preview_active", False):
            self.status_hover_preview_active = False
            self.status.set_text(getattr(self, "last_status_text", "Done"))

    def on_mouse_target_changed(self, webview: Any, hit_test_result: Any, modifiers: Any = None) -> None:
        try:
            link_uri = ""
            image_uri = ""
            try:
                if hasattr(hit_test_result, "context_is_link") and hit_test_result.context_is_link():
                    link_uri = hit_test_result.get_link_uri() or ""
            except Exception:
                pass
            try:
                if hasattr(hit_test_result, "context_is_image") and hit_test_result.context_is_image():
                    image_uri = hit_test_result.get_image_uri() or ""
            except Exception:
                pass
            # Some WebKitGTK bindings expose context flags rather than convenience methods.
            if not link_uri and hasattr(hit_test_result, "get_context"):
                try:
                    ctx = hit_test_result.get_context()
                    H = self.WebKit2.HitTestResultContext
                    if hasattr(H, "LINK") and (ctx & H.LINK):
                        link_uri = hit_test_result.get_link_uri() or ""
                    if hasattr(H, "IMAGE") and (ctx & H.IMAGE):
                        image_uri = hit_test_result.get_image_uri() or ""
                except Exception:
                    pass
            if link_uri:
                self.show_status_hover_preview("Link", link_uri)
            elif image_uri and self.config.get("statusbar_image_hover_preview_enabled", True):
                self.show_status_hover_preview("Image", image_uri)
            else:
                self.clear_status_hover_preview()
        except Exception as exc:
            log_security_event("hover_link_preview_failed", {"error": str(exc)})
            self.clear_status_hover_preview()

    def account_hints_for_uri(self, uri: str) -> List[Dict[str, Any]]:
        host = _sanitize_host(urlparse(uri or "").netloc if "://" in (uri or "") else uri)
        if not host:
            return []
        records = load_vault_account_hints().get("records", [])
        matches: List[Dict[str, Any]] = []
        for rec in records:
            domain = _sanitize_host(str(rec.get("domain", "")))
            if domain and (host == domain or host.endswith("." + domain)):
                if rec.get("username_hint") or rec.get("account_label"):
                    matches.append(rec)
        return matches[:12]

    def inject_account_hint_dropdown(self, webview: Any, uri: str) -> None:
        if not self.config.get("vault_account_hint_dropdown_enabled", True):
            return
        hints = self.account_hints_for_uri(uri)
        if not hints:
            return
        safe_hints = [
            {"label": str(h.get("account_label") or h.get("username_hint") or "Account")[:120], "username": str(h.get("username_hint") or "")[:160]}
            for h in hints if (h.get("account_label") or h.get("username_hint"))
        ]
        if not safe_hints:
            return
        js_payload = json.dumps(safe_hints)
        js = f"""
(function() {{
  const hints = {js_payload};
  if (!hints || !hints.length) return;
  const datalistId = 'sentinel-vault-account-hints';
  let datalist = document.getElementById(datalistId);
  if (!datalist) {{
    datalist = document.createElement('datalist');
    datalist.id = datalistId;
    document.documentElement.appendChild(datalist);
  }}
  datalist.innerHTML = '';
  for (const h of hints) {{
    const opt = document.createElement('option');
    opt.value = h.username || h.label;
    opt.label = h.label + (h.username ? ' — ' + h.username : '');
    datalist.appendChild(opt);
  }}
  const selector = ['input[type=email]','input[name*=email i]','input[id*=email i]','input[name*=user i]','input[id*=user i]','input[name*=login i]','input[id*=login i]','input[autocomplete=username]','input[type=text]'].join(',');
  const inputs = Array.from(document.querySelectorAll(selector)).filter(function(i) {{
    const type = (i.getAttribute('type') || 'text').toLowerCase();
    if (['password','hidden','submit','button','checkbox','radio'].includes(type)) return false;
    const rect = i.getBoundingClientRect();
    return rect.width > 80 && rect.height > 12;
  }}).slice(0, 8);
  for (const input of inputs) {{
    input.setAttribute('list', datalistId);
    input.setAttribute('data-sentinel-vault-hints', 'account-usernames-only-no-secrets');
    if (!input.getAttribute('placeholder')) input.setAttribute('placeholder', 'Account / username');
  }}
}})();
"""
        try:
            webview.run_javascript(js, None, None, None)
            log_security_event("vault_account_hint_dropdown_injected", {"uri": uri, "count": len(safe_hints), "secret_values_present": False})
        except Exception as exc:
            log_security_event("vault_account_hint_dropdown_failed", {"uri": uri, "error": str(exc)})

    def current(self) -> Optional[Dict[str, Any]]:
        i = self.nb.get_current_page()
        return self.tabs[i] if 0 <= i < len(self.tabs) else None


    def _add_menu_item(self, menu: Any, label: str, callback: Any, tooltip: str = "") -> Any:
        item = self.Gtk.MenuItem(label=label)
        item.set_tooltip_text(tooltip or label)
        item.connect("activate", lambda *_: callback())
        menu.append(item)
        return item

    def build_menu_bar(self) -> Any:
        Gtk = self.Gtk
        menubar = Gtk.MenuBar()

        file_menu = Gtk.Menu()
        file_item = Gtk.MenuItem(label="File")
        file_item.set_submenu(file_menu)
        file_item.set_tooltip_text("New tabs, private windows, and close controls")
        self._add_menu_item(file_menu, "New Tab", lambda: self.create_tab("about:blank", True), "Open a new blank tab")
        self._add_menu_item(file_menu, "Incognito Window", self.open_private_window, "Open a private/incognito window using the private search policy")
        self._add_menu_item(file_menu, "Preferences", self.show_preferences_dialog, "Open user-ready Sentinel Browser settings")
        self._add_menu_item(file_menu, "Quit", self.quit, "Close Sentinel Browser")
        menubar.append(file_item)

        view_menu = Gtk.Menu()
        view_item = Gtk.MenuItem(label="View")
        view_item.set_submenu(view_menu)
        view_item.set_tooltip_text("Page and zoom controls")
        self._add_menu_item(view_menu, "Reload", self.reload, "Reload the current page")
        self._add_menu_item(view_menu, "Fullscreen", self.toggle_fullscreen, "Toggle fullscreen mode")
        self._add_menu_item(view_menu, "Zoom In", lambda: self.set_zoom_delta(0.1), "Increase page zoom")
        self._add_menu_item(view_menu, "Zoom Out", lambda: self.set_zoom_delta(-0.1), "Decrease page zoom")
        self._add_menu_item(view_menu, "Reset Zoom", self.reset_zoom, "Reset page zoom")
        menubar.append(view_item)

        bookmarks_menu = Gtk.Menu()
        bookmarks_item = Gtk.MenuItem(label="Bookmarks")
        bookmarks_item.set_submenu(bookmarks_menu)
        bookmarks_item.set_tooltip_text("Bookmark and bookmark-folder controls")
        self.rebuild_bookmarks_menu(bookmarks_menu)
        self.bookmarks_menu = bookmarks_menu
        menubar.append(bookmarks_item)

        search_menu = Gtk.Menu()
        search_item = Gtk.MenuItem(label="Search")
        search_item.set_submenu(search_menu)
        search_item.set_tooltip_text("Search engine policy and defaults")
        self._add_menu_item(search_menu, "Search Preferences", self.show_preferences_dialog, "Open Preferences to change default/private/custom search")
        self._add_menu_item(search_menu, "Search Policy Status", self.show_search_policy_panel, "Show normal/private search engines and user-selectable options")
        for engine in ["duckduckgo", "mojeek", "marginalia", "startpage", "google", "bing"]:
            name = SEARCH_ENGINES[engine]["name"]
            self._add_menu_item(search_menu, f"Set Default: {name}", lambda e=engine: self.set_default_search_engine_ui(e), f"Use {name} for normal address-bar searches")
        menubar.append(search_item)

        security_menu = Gtk.Menu()
        security_item = Gtk.MenuItem(label="Security")
        security_item.set_submenu(security_menu)
        security_item.set_tooltip_text("Security controls and JavaScript profiles")
        self._add_menu_item(security_menu, "Security Controls", self.show_control_panel, "Open Sentinel security, permission, and JavaScript controls")
        self._add_menu_item(security_menu, "JavaScript Standard", lambda: self.set_javascript_profile_ui("standard"), "Use the standard JavaScript profile")
        self._add_menu_item(security_menu, "JavaScript Shield", lambda: self.set_javascript_profile_ui("shield"), "Use the stronger Shield JavaScript profile")
        self._add_menu_item(security_menu, "JavaScript Lockdown", lambda: self.set_javascript_profile_ui("lockdown"), "Disable JavaScript by default")
        self._add_menu_item(security_menu, "Vault Login Prompt Status", self.show_vault_login_prompt_panel, "Show browser-side Vault login prompt status")
        self._add_menu_item(security_menu, "Site Data / Clear Browsing Data", self.show_site_data_manager, "Clear app-scoped cache, cookies/storage, session state, or local metadata")
        menubar.append(security_item)

        downloads_menu = Gtk.Menu()
        downloads_item = Gtk.MenuItem(label="Downloads")
        downloads_item.set_submenu(downloads_menu)
        downloads_item.set_tooltip_text("Download guard and future quarantine status")
        self._add_menu_item(downloads_menu, "Downloads Page", self.show_downloads_page, "Open Sentinel Downloads and Download Guard status")
        self._add_menu_item(downloads_menu, "Download Guard Settings", self.show_preferences_dialog, "Open Preferences to configure Download Guard handoff and release directory")
        self._add_menu_item(downloads_menu, "Download Guard Status", self.show_download_status_panel, "Show current Download Guard backend status")
        menubar.append(downloads_item)

        if self.config.get("tor_menu_enabled", True):
            tor_menu = Gtk.Menu()
            tor_item = Gtk.MenuItem(label="Tor")
            tor_item.set_submenu(tor_menu)
            tor_item.set_tooltip_text("Tor routing, status, settings, and identity controls")
            self._add_menu_item(tor_menu, "Enable Tor", lambda: self.set_tor_enabled_ui(True), "Enable Browser Tor routing through local SOCKS")
            self._add_menu_item(tor_menu, "Disable Tor", lambda: self.set_tor_enabled_ui(False), "Disable Browser Tor routing")
            self._add_menu_item(tor_menu, "Change Tor Identity", self.change_tor_identity_ui, "Request SIGNAL NEWNYM through Tor ControlPort")
            self._add_menu_item(tor_menu, "Tor Settings…", self.show_tor_settings_dialog, "Edit Tor SOCKS/control settings")
            self._add_menu_item(tor_menu, "Tor Status", self.show_tor_status_panel, "Show Tor routing/control status")
            self._add_menu_item(tor_menu, "Test Tor Connection", self.show_tor_test_panel, "Run Tor routing/control checks")
            menubar.append(tor_item)

        blockchain_menu = Gtk.Menu()
        blockchain_item = Gtk.MenuItem(label="Blockchain")
        blockchain_item.set_submenu(blockchain_menu)
        blockchain_item.set_tooltip_text("WalletConnect and multi-chain wallet provider controls")
        self._add_menu_item(blockchain_menu, "WalletConnect URI…", self.show_walletconnect_uri_dialog, "Paste a WalletConnect wc: URI and send it to Sentinel Wallet")
        self._add_menu_item(blockchain_menu, "Blockchain Provider Status", self.show_blockchain_status_panel, "Show injected provider and chain support status")
        self._add_menu_item(blockchain_menu, "WalletConnect / Multi-chain Status", self.show_walletconnect_status_panel, "Show WalletConnect/EVM/Solana/BTC provider support")
        self._add_menu_item(blockchain_menu, "Open Sentinel Wallet", self.open_sentinel_wallet_ui, "Open Sentinel Wallet")
        menubar.append(blockchain_item)

        help_menu = Gtk.Menu()
        help_item = Gtk.MenuItem(label="Help")
        help_item.set_submenu(help_menu)
        help_item.set_tooltip_text("Manual, about, and status information")
        self._add_menu_item(help_menu, "Manual", self.show_manual_dialog, "Open the local Sentinel Browser manual")
        self._add_menu_item(help_menu, "Sentinel Wallet", self.open_sentinel_wallet_ui, "Open Sentinel Wallet crypto-only wallet and NFT inventory")
        self._add_menu_item(help_menu, "Wallet Bridge Status", self.show_wallet_integration_panel, "Show Sentinel Wallet browser bridge status")
        self._add_menu_item(help_menu, "About Sentinel Browser", self.show_about_panel, "Show Sentinel Browser version and doctrine")
        menubar.append(help_item)
        return menubar

    def info_dialog(self, title: str, message: str) -> None:
        dialog = self.Gtk.MessageDialog(
            transient_for=self.window,
            flags=0,
            message_type=self.Gtk.MessageType.INFO,
            buttons=self.Gtk.ButtonsType.OK,
            text=title,
        )
        # Informational/status popups should accept Enter as OK.
        # This keeps normal browser flow quick without changing dangerous confirmation defaults.
        dialog.set_default_response(self.Gtk.ResponseType.OK)
        dialog.format_secondary_text(message)
        dialog.run()
        dialog.destroy()


    def text_entry_dialog(self, title: str, fields: List[Dict[str, str]], ok_label: str = "Save") -> Optional[Dict[str, str]]:
        """Small GTK editor dialog used for bookmark and tab metadata.

        The browser stores only local UI metadata here. No passwords, TOTP secrets,
        or Vault material are ever accepted or saved by this dialog.
        """
        Gtk = self.Gtk
        dialog = Gtk.Dialog(title=title, transient_for=self.window, flags=0)
        dialog.add_button("Cancel", Gtk.ResponseType.CANCEL)
        ok_button = dialog.add_button(ok_label, Gtk.ResponseType.OK)
        # Enter activates the primary action for small editor popups.
        dialog.set_default_response(Gtk.ResponseType.OK)
        try:
            ok_button.set_can_default(True)
            ok_button.grab_default()
        except Exception:
            pass
        box = dialog.get_content_area()
        grid = Gtk.Grid(column_spacing=8, row_spacing=8, margin=12)
        box.add(grid)
        entries = {}
        for row, field in enumerate(fields):
            label = Gtk.Label(label=field.get("label", field.get("key", "Value")))
            label.set_xalign(0)
            entry = Gtk.Entry()
            entry.set_text(field.get("value", ""))
            entry.set_tooltip_text(field.get("tooltip", ""))
            try:
                entry.set_activates_default(True)
            except Exception:
                pass
            grid.attach(label, 0, row, 1, 1)
            grid.attach(entry, 1, row, 1, 1)
            entries[field.get("key", f"field{row}")] = entry
        dialog.show_all()
        response = dialog.run()
        result = None
        if response == Gtk.ResponseType.OK:
            result = {key: entry.get_text().strip() for key, entry in entries.items()}
        dialog.destroy()
        return result

    def bookmark_editor_dialog(self, title: str, url: str, dialog_title: str = "Save Bookmark", folder: str = "") -> Optional[Dict[str, str]]:
        result = self.text_entry_dialog(
            dialog_title,
            [
                {"key": "title", "label": "Name", "value": title[:120], "tooltip": "Bookmark display name"},
                {"key": "url", "label": "URL", "value": url[:2048], "tooltip": "Bookmark target URL"},
                {"key": "folder", "label": "Folder", "value": folder[:80], "tooltip": "Optional bookmark folder. Leave blank for top-level bookmarks."},
            ],
            "Save",
        )
        if not result:
            return None
        clean_title = _clean_bookmark_title(result.get("title") or result.get("url") or "Bookmark", "Bookmark", 120)
        clean_url = _clean_bookmark_url(result.get("url") or "about:blank")
        clean_folder = _clean_bookmark_folder(result.get("folder", ""))
        return {"title": clean_title, "url": clean_url, "folder": clean_folder}

    def bookmark_folder_dialog(self, title: str = "", dialog_title: str = "Add Bookmark Folder") -> Optional[str]:
        result = self.text_entry_dialog(
            dialog_title,
            [
                {"key": "title", "label": "Folder name", "value": title[:80], "tooltip": "Bookmark folder name"},
            ],
            "Save",
        )
        if not result:
            return None
        return _clean_bookmark_folder(result.get("title", ""))

    def add_or_update_bookmark_record(self, title: str, url: str, old_url: str = "", folder: str = "") -> bool:
        items = load_bookmarks()
        clean_title = _clean_bookmark_title(title, "Bookmark", 120)
        clean_url = _clean_bookmark_url(url)
        clean_folder = _clean_bookmark_folder(folder)
        updated = False
        for bm in items:
            if bm.get("type") == "folder":
                continue
            if old_url and bm.get("url") == old_url:
                bm["type"] = "bookmark"
                bm["title"] = clean_title
                bm["url"] = clean_url
                if clean_folder:
                    bm["folder"] = clean_folder
                else:
                    bm.pop("folder", None)
                updated = True
                break
            if not old_url and bm.get("url") == clean_url:
                bm["type"] = "bookmark"
                bm["title"] = clean_title
                if clean_folder:
                    bm["folder"] = clean_folder
                else:
                    bm.pop("folder", None)
                updated = True
                break
        if not updated:
            record = {"type": "bookmark", "title": clean_title, "url": clean_url}
            if clean_folder:
                record["folder"] = clean_folder
            items.append(record)
        if clean_folder and clean_folder.lower() not in {f.lower() for f in bookmark_folders(items)}:
            items.insert(0, {"type": "folder", "title": clean_folder})
        save_bookmarks(items)
        self.refresh_bookmarks_views()
        return True

    def refresh_bookmarks_views(self) -> None:
        try:
            self.refresh_bookmarks_toolbar()
        except Exception as exc:
            log_security_event("bookmarks_toolbar_refresh_failed", {"error": str(exc)})
        try:
            menu = getattr(self, "bookmarks_menu", None)
            if menu is not None:
                self.rebuild_bookmarks_menu(menu)
        except Exception as exc:
            log_security_event("bookmarks_menu_refresh_failed", {"error": str(exc)})

    def add_bookmark_folder(self) -> None:
        folder = self.bookmark_folder_dialog("", "Add Bookmark Folder")
        if not folder:
            self.set_status("Bookmark folder creation cancelled")
            return
        items = load_bookmarks()
        if folder.lower() in {f.lower() for f in bookmark_folders(items)}:
            self.set_status("Bookmark folder already exists: " + folder[:60])
            return
        items.append({"type": "folder", "title": folder})
        save_bookmarks(items)
        self.refresh_bookmarks_views()
        self.set_status("Bookmark folder added: " + folder[:60])

    def rename_bookmark_folder(self, old_folder: str) -> None:
        old_folder = _clean_bookmark_folder(old_folder)
        new_folder = self.bookmark_folder_dialog(old_folder, "Rename Bookmark Folder")
        if not new_folder or new_folder == old_folder:
            self.set_status("Bookmark folder rename cancelled")
            return
        items = load_bookmarks()
        for item in items:
            if item.get("type") == "folder" and _clean_bookmark_folder(item.get("title")) == old_folder:
                item["title"] = new_folder
            elif _clean_bookmark_folder(item.get("folder", "")) == old_folder:
                item["folder"] = new_folder
        save_bookmarks(items)
        self.refresh_bookmarks_views()
        self.set_status("Bookmark folder renamed: " + new_folder[:60])

    def delete_bookmark_folder(self, folder: str) -> None:
        folder = _clean_bookmark_folder(folder)
        items = load_bookmarks()
        contained = bookmark_rows(items, folder)
        prompt = f"Delete bookmark folder?\n\n{folder}"
        if contained:
            prompt += f"\n\n{len(contained)} bookmark(s) inside will be moved to top-level bookmarks."
        if not self.confirm("Delete bookmark folder", prompt):
            return
        new_items: List[Dict[str, str]] = []
        for item in items:
            if item.get("type") == "folder" and _clean_bookmark_folder(item.get("title")) == folder:
                continue
            if _clean_bookmark_folder(item.get("folder", "")) == folder:
                item = dict(item)
                item.pop("folder", None)
            new_items.append(item)
        save_bookmarks(new_items)
        self.refresh_bookmarks_views()
        self.set_status("Bookmark folder deleted")

    def edit_bookmark(self, old_url: str) -> None:
        items = load_bookmarks()
        found = next((bm for bm in items if bm.get("type") != "folder" and bm.get("url") == old_url), None)
        if not found:
            self.set_status("Bookmark not found")
            return
        result = self.bookmark_editor_dialog(found.get("title", "Bookmark"), found.get("url", "about:blank"), "Edit Bookmark", found.get("folder", ""))
        if not result:
            self.set_status("Bookmark edit cancelled")
            return
        self.add_or_update_bookmark_record(result["title"], result["url"], old_url=old_url, folder=result.get("folder", ""))
        self.set_status("Bookmark updated: " + result["title"][:60])

    def delete_bookmark(self, old_url: str) -> None:
        items = load_bookmarks()
        target = next((bm for bm in items if bm.get("type") != "folder" and bm.get("url") == old_url), None)
        if not target:
            self.set_status("Bookmark not found")
            return
        if not self.confirm("Delete bookmark", f"Delete this bookmark?\n\n{target.get('title','Bookmark')}\n{old_url}"):
            return
        save_bookmarks([bm for bm in items if bm.get("type") == "folder" or bm.get("url") != old_url])
        self.refresh_bookmarks_views()
        self.set_status("Bookmark deleted")

    def _bookmark_target_entries(self) -> List[Any]:
        try:
            return [self.Gtk.TargetEntry.new(BOOKMARK_DRAG_MIME, self.Gtk.TargetFlags.SAME_APP, 0)]
        except Exception:
            return []

    def _finish_drag(self, context: Any, success: bool, delete_data: bool, time_value: Any) -> None:
        try:
            context.finish(bool(success), bool(delete_data), int(time_value or 0))
        except Exception:
            pass

    def _selection_text(self, data: Any) -> str:
        try:
            text = data.get_text()
            if text:
                return str(text)
        except Exception:
            pass
        try:
            raw = data.get_data()
            if isinstance(raw, bytes):
                return raw.decode("utf-8", "replace")
        except Exception:
            pass
        return ""

    def _enable_bookmarks_toolbar_context_menu(self) -> None:
        try:
            self.bookmarks_bar.add_events(self.Gdk.EventMask.BUTTON_PRESS_MASK)
            self.bookmarks_bar.connect("button-press-event", self.open_bookmarks_toolbar_context_menu)
        except Exception as exc:
            log_security_event("bookmark_toolbar_context_menu_setup_failed", {"error": str(exc)})

    def _enable_bookmark_drag_source(self, button: Any, bookmark: Dict[str, str], source_index: int) -> None:
        if not self.config.get("bookmark_toolbar_drag_reorder_enabled", True):
            return
        try:
            targets = self._bookmark_target_entries()
            if not targets:
                return
            button.drag_source_set(self.Gdk.ModifierType.BUTTON1_MASK, targets, self.Gdk.DragAction.MOVE)
            identity = _bookmark_identity(bookmark, source_index)
            def on_drag_data_get(_widget: Any, _context: Any, selection: Any, _info: Any, _time: Any, payload: Dict[str, Any] = identity) -> None:
                try:
                    selection.set_text(json.dumps(payload, sort_keys=True), -1)
                except Exception as exc:
                    log_security_event("bookmark_drag_payload_failed", {"error": str(exc)})
            button.connect("drag-data-get", on_drag_data_get)
        except Exception as exc:
            log_security_event("bookmark_drag_source_setup_failed", {"error": str(exc)})

    def _enable_bookmark_drop_on_bookmark(self, button: Any, target: Dict[str, str], target_index: int) -> None:
        if not self.config.get("bookmark_toolbar_drag_reorder_enabled", True):
            return
        try:
            targets = self._bookmark_target_entries()
            if not targets:
                return
            button.drag_dest_set(self.Gtk.DestDefaults.ALL, targets, self.Gdk.DragAction.MOVE)
            target_identity = _bookmark_identity(target, target_index)
            def on_drag_received(_widget: Any, context: Any, _x: Any, _y: Any, data: Any, _info: Any, time_value: Any, dst: Dict[str, Any] = target_identity) -> None:
                success = False
                try:
                    payload = _decode_bookmark_drag_payload(self._selection_text(data))
                    if payload:
                        items = load_bookmarks()
                        new_items, success = reorder_bookmark_identity_before(items, payload, dst)
                        if success:
                            save_bookmarks(new_items)
                            self.refresh_bookmarks_views()
                            self.set_status("Bookmark moved in toolbar")
                except Exception as exc:
                    log_security_event("bookmark_drag_reorder_failed", {"error": str(exc)})
                self._finish_drag(context, success, success, time_value)
            button.connect("drag-data-received", on_drag_received)
        except Exception as exc:
            log_security_event("bookmark_drop_bookmark_setup_failed", {"error": str(exc)})

    def _enable_bookmark_drop_on_folder(self, button: Any, target_folder: str) -> None:
        if not self.config.get("bookmark_toolbar_drag_to_folder_enabled", True):
            return
        try:
            targets = self._bookmark_target_entries()
            if not targets:
                return
            button.drag_dest_set(self.Gtk.DestDefaults.ALL, targets, self.Gdk.DragAction.MOVE)
            clean_folder = _clean_bookmark_folder(target_folder)
            def on_drag_received(_widget: Any, context: Any, _x: Any, _y: Any, data: Any, _info: Any, time_value: Any, folder: str = clean_folder) -> None:
                success = False
                try:
                    payload = _decode_bookmark_drag_payload(self._selection_text(data))
                    if payload:
                        items = load_bookmarks()
                        new_items, success = move_bookmark_identity_to_folder(items, payload, folder)
                        if success:
                            save_bookmarks(new_items)
                            self.refresh_bookmarks_views()
                            self.set_status("Bookmark moved to folder: " + folder[:60])
                except Exception as exc:
                    log_security_event("bookmark_drag_to_folder_failed", {"error": str(exc), "folder": folder})
                self._finish_drag(context, success, success, time_value)
            button.connect("drag-data-received", on_drag_received)
        except Exception as exc:
            log_security_event("bookmark_drop_folder_setup_failed", {"error": str(exc), "folder": target_folder})

    def move_bookmark_to_folder(self, old_url: str, target_folder: str) -> None:
        items = load_bookmarks()
        target = next((bm for bm in items if bm.get("type") != "folder" and bm.get("url") == old_url), None)
        if not target:
            self.set_status("Bookmark not found")
            return
        identity = _bookmark_identity(target, items.index(target))
        new_items, changed = move_bookmark_identity_to_folder(items, identity, target_folder)
        if changed:
            save_bookmarks(new_items)
            self.refresh_bookmarks_views()
            self.set_status("Bookmark moved" + (" to " + _clean_bookmark_folder(target_folder) if target_folder else " to top-level"))
        else:
            self.set_status("Bookmark move cancelled")

    def open_bookmarks_toolbar_context_menu(self, widget: Any, event: Any) -> bool:
        try:
            if getattr(event, "button", 0) != 3:
                return False
            Gtk = self.Gtk
            menu = Gtk.Menu()
            def add(label: str, callback: Any, sensitive: bool = True) -> None:
                item = Gtk.MenuItem(label=label)
                item.set_sensitive(bool(sensitive))
                item.connect("activate", lambda *_: callback())
                item.show()
                menu.append(item)
            add("Add Bookmark", self.bookmark)
            add("Add Bookmark Folder", self.add_bookmark_folder)
            add("Show/Hide Bookmarks Toolbar", self.toggle_bookmarks_toolbar)
            add("Bookmarks Status", self.show_bookmarks_panel)
            menu.show_all()
            try:
                menu.popup_at_pointer(event)
            except Exception:
                menu.popup(None, None, None, None, getattr(event, "button", 3), getattr(event, "time", 0))
            return True
        except Exception as exc:
            log_security_event("bookmark_toolbar_context_menu_failed", {"error": str(exc)})
            return False

    def open_bookmark_context_menu(self, button: Any, event: Any, title: str, url: str) -> bool:
        try:
            if getattr(event, "button", 0) != 3:
                return False
            Gtk = self.Gtk
            menu = Gtk.Menu()
            def add(label: str, callback: Any) -> None:
                item = Gtk.MenuItem(label=label)
                item.connect("activate", lambda *_: callback())
                item.show()
                menu.append(item)
            add("Open Bookmark", lambda: self.load(url))
            add("Open in New Tab", lambda: self.create_tab(url, True))
            add("Edit Bookmark", lambda: self.edit_bookmark(url))
            add("Delete Bookmark", lambda: self.delete_bookmark(url))
            add("Copy Bookmark URL", lambda: self.copy_text_to_clipboard(url, "Bookmark URL copied"))
            menu.append(Gtk.SeparatorMenuItem())
            add("Add Bookmark", self.bookmark)
            add("Add Bookmark Folder", self.add_bookmark_folder)
            folders = bookmark_folders()
            if folders:
                move_menu = Gtk.Menu()
                top = Gtk.MenuItem(label="Top-level Bookmarks")
                top.connect("activate", lambda *_: self.move_bookmark_to_folder(url, ""))
                move_menu.append(top)
                for folder in folders[:20]:
                    item = Gtk.MenuItem(label=folder[:60])
                    item.connect("activate", lambda _item, f=folder: self.move_bookmark_to_folder(url, f))
                    move_menu.append(item)
                move_item = Gtk.MenuItem(label="Move to Folder")
                move_item.set_submenu(move_menu)
                menu.append(move_item)
            menu.show_all()
            try:
                menu.popup_at_pointer(event)
            except Exception:
                menu.popup(None, None, None, None, event.button, event.time)
            return True
        except Exception as exc:
            log_security_event("bookmark_context_menu_failed", {"error": str(exc)})
            return False

    def tab_context_menu(self, widget: Any, event: Any, webview: Any, label: Any) -> bool:
        try:
            if getattr(event, "button", 0) != 3:
                return False
            Gtk = self.Gtk
            menu = Gtk.Menu()
            def add(text: str, callback: Any) -> None:
                item = Gtk.MenuItem(label=text)
                item.connect("activate", lambda *_: callback())
                item.show()
                menu.append(item)
            add("New Tab", lambda: self.create_tab("about:blank", True))
            add("Reload Tab", lambda: webview.reload())
            add("Duplicate Tab", lambda: self.create_tab(webview.get_uri() or "about:blank", True))
            add("Rename Tab", lambda: self.rename_tab(label))
            add("Close Tab", lambda: self.close_tab(webview))
            menu.show_all()
            try:
                menu.popup_at_pointer(event)
            except Exception:
                menu.popup(None, None, None, None, event.button, event.time)
            return True
        except Exception as exc:
            log_security_event("tab_context_menu_failed", {"error": str(exc)})
            return False

    def rename_tab(self, label: Any) -> None:
        current = label.get_text() if hasattr(label, "get_text") else "Tab"
        result = self.text_entry_dialog("Rename Tab", [{"key": "title", "label": "Tab name", "value": current, "tooltip": "Temporary tab label"}], "Rename")
        if result and result.get("title"):
            label.set_text(result["title"][:40])
            self.set_status("Tab renamed")

    def copy_text_to_clipboard(self, text: str, status: str = "Copied") -> None:
        try:
            cb = self.Gtk.Clipboard.get(self.Gdk.SELECTION_CLIPBOARD)
            cb.set_text(text or "", -1)
            cb.store()
            self.set_status(status)
        except Exception as exc:
            log_security_event("clipboard_copy_failed", {"error": str(exc)})

    def search_text(self, text: str) -> None:
        text = (text or "").strip()
        if not text:
            self.set_status("No selected text to search")
            return
        self.load(self.search_url(text))

    def run_js_for_text(self, webview: Any, script: str, callback: Any) -> None:
        def finish(wv: Any, res: Any, _data: Any = None) -> None:
            text = ""
            try:
                jsres = wv.run_javascript_finish(res)
                val = jsres.get_js_value()
                if hasattr(val, "to_string"):
                    text = val.to_string()
                else:
                    text = str(val)
            except Exception as exc:
                log_security_event("context_menu_js_text_failed", {"error": str(exc)})
            callback(text)
        try:
            webview.run_javascript(script, None, finish, None)
        except Exception as exc:
            log_security_event("context_menu_run_javascript_failed", {"error": str(exc)})

    def copy_selected_text(self, webview: Any) -> None:
        self.run_js_for_text(webview, "window.getSelection ? window.getSelection().toString() : '';", lambda text: self.copy_text_to_clipboard(text, "Selected text copied" if text else "No selected text"))

    def search_selected_text(self, webview: Any) -> None:
        self.run_js_for_text(webview, "window.getSelection ? window.getSelection().toString() : '';", self.search_text)

    def on_web_context_menu(self, webview: Any, context_menu: Any, event: Any, hit_test_result: Any) -> bool:
        if not self.config.get("web_context_menu_sentinel_actions_enabled", True):
            return False
        try:
            Gtk = self.Gtk
            menu = Gtk.Menu()
            link_uri = ""
            try:
                if hit_test_result and hasattr(hit_test_result, "get_link_uri"):
                    link_uri = hit_test_result.get_link_uri() or ""
            except Exception:
                link_uri = ""
            def add(label: str, callback: Any, sensitive: bool = True) -> None:
                item = Gtk.MenuItem(label=label)
                item.set_sensitive(bool(sensitive))
                item.connect("activate", lambda *_: callback())
                item.show()
                menu.append(item)
            add("Copy Selected Text", lambda: self.copy_selected_text(webview), True)
            add("Search Selected Text", lambda: self.search_selected_text(webview), True)
            if link_uri:
                add("Open Link", lambda: self.load(link_uri), True)
                add("Open Link in New Tab", lambda: self.create_tab(link_uri, True), True)
                add("Copy Link", lambda: self.copy_text_to_clipboard(link_uri, "Link copied"), True)
                add("Search Link URL", lambda: self.search_text(link_uri), True)
            else:
                add("Copy Link", lambda: None, False)
            menu.show_all()
            try:
                menu.popup_at_pointer(event)
            except Exception:
                menu.popup(None, None, None, None, getattr(event, "button", 3), getattr(event, "time", 0))
            return True
        except Exception as exc:
            log_security_event("web_context_menu_failed", {"error": str(exc)})
            return False

    def open_private_window(self) -> None:
        try:
            subprocess.Popen(["sentinel-browser", "--private"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
            self.set_status("Opened incognito/private window")
        except Exception:
            self.open_private_window_notice()

    def on_address_icon_press(self, entry: Any, icon_pos: Any, event: Any) -> None:
        try:
            if icon_pos == self.Gtk.EntryIconPosition.SECONDARY:
                self.bookmark()
        except Exception:
            self.bookmark()

    def _bookmark_menu_for_rows(self, rows: List[Dict[str, str]], include_folder_actions: str = "") -> Any:
        Gtk = self.Gtk
        menu = Gtk.Menu()
        for bm in rows[:40]:
            title = (bm.get("title") or bm.get("url") or "Bookmark")[:60]
            url = bm.get("url", "about:blank")
            item = Gtk.MenuItem(label=title)
            item.set_tooltip_text(url)
            item.connect("activate", lambda _item, u=url: self.load(u))
            menu.append(item)
        if not rows:
            empty = Gtk.MenuItem(label="No bookmarks in this folder")
            empty.set_sensitive(False)
            menu.append(empty)
        if include_folder_actions:
            menu.append(Gtk.SeparatorMenuItem())
            add_here = Gtk.MenuItem(label="Add Bookmark to This Folder")
            add_here.connect("activate", lambda *_: self.bookmark(default_folder=include_folder_actions))
            menu.append(add_here)
            add_folder = Gtk.MenuItem(label="Add Bookmark Folder")
            add_folder.connect("activate", lambda *_: self.add_bookmark_folder())
            menu.append(add_folder)
            rename = Gtk.MenuItem(label="Rename Folder")
            rename.connect("activate", lambda *_: self.rename_bookmark_folder(include_folder_actions))
            menu.append(rename)
            delete = Gtk.MenuItem(label="Delete Folder")
            delete.connect("activate", lambda *_: self.delete_bookmark_folder(include_folder_actions))
            menu.append(delete)
        menu.show_all()
        return menu

    def _popup_bookmark_folder_menu(self, button: Any, folder: str, rows: List[Dict[str, str]], event: Any = None) -> None:
        menu = self._bookmark_menu_for_rows(rows, include_folder_actions=folder)
        try:
            if event is not None and hasattr(menu, "popup_at_pointer"):
                menu.popup_at_pointer(event)
                return
            if hasattr(menu, "popup_at_widget"):
                menu.popup_at_widget(button, self.Gdk.Gravity.SOUTH_WEST, self.Gdk.Gravity.NORTH_WEST, None)
                return
        except Exception:
            pass
        try:
            menu.popup(None, None, None, None, 0, 0)
        except Exception as exc:
            log_security_event("bookmark_folder_popup_failed", {"error": str(exc), "folder": folder})

    def open_bookmark_folder_context_menu(self, button: Any, event: Any, folder: str) -> bool:
        try:
            if getattr(event, "button", 0) != 3:
                return False
            self._popup_bookmark_folder_menu(button, folder, bookmark_rows(folder=folder), event)
            return True
        except Exception as exc:
            log_security_event("bookmark_folder_context_menu_failed", {"error": str(exc), "folder": folder})
            return False

    def rebuild_bookmarks_menu(self, bookmarks_menu: Any) -> None:
        Gtk = self.Gtk
        for child in list(bookmarks_menu.get_children()):
            bookmarks_menu.remove(child)
        self._add_menu_item(bookmarks_menu, "Add Bookmark", self.bookmark, "Bookmark the current page")
        self._add_menu_item(bookmarks_menu, "Add Bookmark Folder", self.add_bookmark_folder, "Create a folder in the Bookmarks menu and toolbar")
        self._add_menu_item(bookmarks_menu, "Show/Hide Bookmarks Toolbar", self.toggle_bookmarks_toolbar, "Toggle the bookmarks toolbar below the address bar")
        self._add_menu_item(bookmarks_menu, "Bookmarks Status", self.show_bookmarks_panel, "Show where bookmarks are stored")
        bookmarks_menu.append(Gtk.SeparatorMenuItem())
        items = load_bookmarks()
        root_items = bookmark_rows(items, "")
        for bm in root_items[:12]:
            title = bm.get("title", "Bookmark")[:50]
            url = bm.get("url", "about:blank")
            self._add_menu_item(bookmarks_menu, title, lambda u=url: self.load(u), url)
        for folder in bookmark_folders(items):
            rows = bookmark_rows(items, folder)
            folder_item = Gtk.MenuItem(label="📁 " + folder[:50])
            folder_item.set_tooltip_text(f"Bookmark folder: {folder}")
            folder_item.set_submenu(self._bookmark_menu_for_rows(rows, include_folder_actions=folder))
            bookmarks_menu.append(folder_item)
        bookmarks_menu.show_all()

    def refresh_bookmarks_toolbar(self) -> None:
        try:
            for child in list(self.bookmarks_bar.get_children()):
                self.bookmarks_bar.remove(child)
            # RC20+: no literal "Bookmarks" title is packed into this row.
            # The horizontal space belongs to the user's favourite/bookmark buttons and folders.
            items = load_bookmarks()
            root_entries = [(idx, bm) for idx, bm in enumerate(items) if bm.get("type") != "folder" and _clean_bookmark_folder(bm.get("folder", "")) == ""]
            root_items = [bm for _idx, bm in root_entries]
            folders = bookmark_folders(items)
            if not root_items and not folders:
                empty = self.Gtk.Label(label="No bookmarks yet")
                empty.set_tooltip_text("Use Bookmarks → Add Bookmark or Ctrl+D to add the current page; right-click for quick actions")
                self.bookmarks_bar.pack_start(empty, False, False, 4)
            for source_index, bm in root_entries[:8]:
                title = (bm.get("title") or bm.get("url") or "Bookmark")[:24]
                url = bm.get("url", "about:blank")
                btn = self.Gtk.Button(label=title)
                btn.set_tooltip_text(url + "\nDrag to reposition; drag onto a folder to move; right-click for quick actions")
                btn.set_sensitive(True)
                def load_bookmark(_button: Any, target: str = url) -> None:
                    self.load(target)
                btn.connect("clicked", load_bookmark)
                btn.connect("button-press-event", lambda b, e, t=title, u=url: self.open_bookmark_context_menu(b, e, t, u))
                self._enable_bookmark_drag_source(btn, bm, source_index)
                self._enable_bookmark_drop_on_bookmark(btn, bm, source_index)
                self.bookmarks_bar.pack_start(btn, False, False, 0)
            for folder in folders[:8]:
                rows = bookmark_rows(items, folder)
                btn = self.Gtk.Button(label="📁 " + folder[:22])
                btn.set_tooltip_text(f"Bookmark folder: {folder}\nClick to open; drag bookmarks here to move; right-click for quick actions")
                btn.connect("clicked", lambda b, f=folder, r=rows: self._popup_bookmark_folder_menu(b, f, r))
                btn.connect("button-press-event", lambda b, e, f=folder: self.open_bookmark_folder_context_menu(b, e, f))
                self._enable_bookmark_drop_on_folder(btn, folder)
                self.bookmarks_bar.pack_start(btn, False, False, 0)
            # Only show the toolbar from refresh when the user setting says it should be visible.
            if self.config.get("show_bookmarks_bar", True) and self.config.get("bookmarks_toolbar_enabled", True):
                self.bookmarks_bar.set_no_show_all(False)
                self.bookmarks_bar.show_all()
        except Exception as exc:
            log_security_event("bookmarks_toolbar_refresh_failed", {"error": str(exc)})

    def toggle_bookmarks_toolbar(self) -> None:
        enabled = not bool(self.config.get("show_bookmarks_bar", True))
        self.config["show_bookmarks_bar"] = enabled
        save_config(self.config)
        if enabled:
            try:
                self.bookmarks_bar.set_no_show_all(False)
                self.refresh_bookmarks_toolbar()
                self.bookmarks_bar.show_all()
            except Exception as exc:
                log_security_event("bookmarks_toolbar_show_failed", {"error": str(exc)})
            self.set_status("Bookmarks toolbar shown")
        else:
            try:
                self.bookmarks_bar.set_no_show_all(True)
                self.bookmarks_bar.hide()
            except Exception as exc:
                log_security_event("bookmarks_toolbar_hide_failed", {"error": str(exc)})
            self.set_status("Bookmarks toolbar hidden")

    def show_bookmarks_panel(self) -> None:
        items = load_bookmarks()
        lines = [
            "Sentinel Browser Bookmarks",
            "",
            f"Toolbar enabled: {self.config.get('show_bookmarks_bar', True)}",
            f"Bookmarks stored: {len(bookmark_rows(items, '')) + sum(len(bookmark_rows(items, f)) for f in bookmark_folders(items))}",
            f"Folders stored: {len(bookmark_folders(items))}",
            f"Path: {BOOKMARKS}",
            "",
            "Top-level bookmarks:",
        ]
        for bm in bookmark_rows(items, '')[:10]:
            lines.append(f"- {bm.get('title','Bookmark')} :: {bm.get('url','')}")
        for folder in bookmark_folders(items)[:10]:
            lines.append(f"\nFolder: {folder}")
            for bm in bookmark_rows(items, folder)[:8]:
                lines.append(f"  - {bm.get('title','Bookmark')} :: {bm.get('url','')}")
        self.info_dialog("Bookmarks", "\n".join(lines))

    def open_private_window_notice(self) -> None:
        self.info_dialog("Private Window", "Use the launcher action or command:\n\nsentinel-browser --private\n\nPrivate/incognito search uses Mojeek by default.")

    def set_default_search_engine_ui(self, engine: str) -> None:
        try:
            set_search_engine("default", engine)
            self.search_policy = load_search_policy()
            self.config = load_config(False)
            self.config["search_url"] = effective_search_url(self.config, self.search_policy, self.private_session)
            self.set_status("Default search engine set to " + SEARCH_ENGINES[engine]["name"])
        except Exception as exc:
            self.info_dialog("Search engine update failed", str(exc))

    def set_javascript_profile_ui(self, profile: str) -> None:
        try:
            set_javascript_profile(profile)
            self.config = load_config(False)
            self.set_status("JavaScript profile set to " + profile)
        except Exception as exc:
            self.info_dialog("JavaScript profile update failed", str(exc))

    def hide_vault_login_prompt(self, reason: str = "dismissed") -> None:
        try:
            self.vault_login_bar.set_no_show_all(True)
            self.vault_login_bar.hide()
            if reason:
                self.set_status("Vault login prompt hidden: " + reason)
        except Exception as exc:
            log_security_event("vault_login_prompt_hide_failed", {"error": str(exc)})

    def show_vault_login_prompt(self, origin: str, source: str = "login_form_detected") -> None:
        if not self.config.get("vault_login_prompt_enabled", True) or not self.config.get("vault_login_prompt_bar_enabled", True):
            return
        host = _host_from_uri(origin)
        if not host:
            return
        policy = load_vault_login_policy()
        if _host_in_list(host, policy.get("never_prompt_sites", [])):
            log_security_event("vault_login_prompt_suppressed_never_site", {"domain": host, "source": source})
            return
        try:
            self.vault_login_label.set_text(f"Sentinel Vault login available for {host}. Use Vault, Save to Vault, or enter manually.")
            self.vault_login_bar.set_no_show_all(False)
            self.vault_login_bar.show_all()
            log_security_event("vault_login_prompt_shown", {"domain": host, "source": source, "secret_values_present": False})
        except Exception as exc:
            log_security_event("vault_login_prompt_show_failed", {"domain": host, "error": str(exc)})

    def use_vault_for_login(self) -> None:
        origin = self.current_uri()
        domain = _host_from_uri(origin)
        result = launch_vault_bridge(browser_origin=origin, mode="password")
        if result.get("ok"):
            self.hide_vault_login_prompt("")
            self.set_status("Requested Vault login popup" + (f" | {domain}" if domain else ""))
        else:
            self.info_dialog(
                "Vault login bridge",
                result.get("error", "Sentinel Password Vault password receiver is not available.")
                + "\n\nNo full Vault fallback was opened. No browser page should be launched from Use Vault."
            )

    def never_vault_for_current_site(self) -> None:
        origin = self.current_uri()
        host = _host_from_uri(origin)
        if not host:
            self.hide_vault_login_prompt("no current site")
            return
        try:
            update_vault_login_site_policy(host, "never")
            self.hide_vault_login_prompt("never for " + host)
        except Exception as exc:
            self.info_dialog("Vault login prompt", str(exc))

    def detect_login_form_finished(self, webview: Any, uri: str) -> None:
        if not self.config.get("vault_login_prompt_detection_enabled", True):
            return
        if not uri or uri.startswith(("about:", "file:", "data:")):
            return
        if _looks_like_login_uri(uri):
            self.show_vault_login_prompt(uri, "login_url_hint")
            return
        script = """
(function(){
  try {
    var p = document.querySelectorAll('input[type=password]').length;
    var u = document.querySelectorAll('input[type=email], input[name*=user i], input[name*=login i], input[name*=email i]').length;
    return (p > 0) ? 'password_input:' + p + ':user_inputs:' + u : '';
  } catch(e) { return ''; }
})();
"""
        def finish(wv: Any, res: Any, _data: Any = None) -> None:
            try:
                jsres = wv.run_javascript_finish(res)
                val = jsres.get_js_value()
                text = val.to_string() if hasattr(val, "to_string") else str(val)
                if text and "password_input" in text:
                    self.show_vault_login_prompt(uri, "password_input_detected")
            except Exception as exc:
                log_security_event("vault_login_prompt_detection_failed", {"uri_host": _host_from_uri(uri), "error": str(exc)})
        try:
            webview.run_javascript(script, None, finish, None)
        except Exception as exc:
            log_security_event("vault_login_prompt_js_unavailable", {"uri_host": _host_from_uri(uri), "error": str(exc)})

    def show_vault_login_prompt_panel(self) -> None:
        st = vault_login_prompt_status_json(False)
        lines = [
            "Sentinel Browser Vault Login Prompt",
            "",
            f"Prompt enabled: {st.get('prompt_enabled')}",
            f"Prompt bar enabled: {st.get('prompt_bar_enabled')}",
            f"Detection enabled: {st.get('detection_enabled')}",
            f"Browser stores passwords: {st.get('browser_stores_passwords')}",
            f"Browser stores TOTP secrets: {st.get('browser_stores_totp_secrets')}",
            f"Auto-submit enabled: {st.get('browser_auto_submit_enabled')}",
            "",
            "User choices:",
            ", ".join(st.get("user_choices", [])),
            "",
            "Vault contract:",
            st.get("password_receiver_contract", ""),
        ]
        self.info_dialog("Vault Login Prompt", "\n".join(lines))

    def show_search_policy_panel(self) -> None:
        st = search_policy_status_json(False)
        lines = [
            "Sentinel Browser Search Policy",
            "",
            f"Normal/default search: {st.get('default_search_engine')}",
            f"Private/incognito search: {st.get('private_search_engine')}",
            f"Kagi built-in preset: {st.get('kagi_builtin_preset')}",
            "",
            "User-selectable engines:",
            ", ".join(st.get("user_selectable_engines", [])),
            "",
            "Normal URL:",
            st.get("normal_search_url", ""),
            "",
            "Private URL:",
            st.get("private_search_url", ""),
        ]
        self.info_dialog("Search Policy", "\n".join(lines))


    def active_browser_download_ids(self) -> set:
        ids = set()
        for ctx in list(self.download_context.values()):
            did = str(ctx.get("download_id", "")).strip()
            if did:
                ids.add(did)
        return ids

    def start_download_cancel_poll_timer(self) -> None:
        # RC20/v1 UX correction: Download Guard must not be polled while a
        # WebKit transfer is active. Browser owns live downloads and its own
        # cancel button; Download Guard handles completed-file review only.
        if self.config.get("download_guard_disable_live_cancel_poll_for_v1", True):
            return
        if not self.config.get("download_guard_urgent_cancel_poll_enabled", False):
            return
        if self.download_cancel_poll_timer_id:
            return
        try:
            interval = int(self.config.get("download_guard_urgent_cancel_poll_interval_ms", 2500) or 2500)
        except Exception:
            interval = 2500
        interval = max(5000, min(30000, interval))
        try:
            self.download_cancel_poll_timer_id = self.GLib.timeout_add(interval, self.poll_download_guard_cancel_requests)
            log_security_event("download_guard_cancel_poll_started", {"interval_ms": interval, "contract": DOWNLOAD_GUARD_BROWSER_CONTRACT_SCHEMA, "mode": "experimental_disabled_by_default"})
        except Exception as exc:
            log_security_event("download_guard_cancel_poll_start_failed", {"error": str(exc)})

    def stop_download_cancel_poll_timer_if_idle(self) -> None:
        if self.download_context:
            return
        timer_id = self.download_cancel_poll_timer_id
        if timer_id:
            try:
                self.GLib.source_remove(timer_id)
            except Exception:
                pass
        self.download_cancel_poll_timer_id = None

    def poll_download_guard_cancel_requests(self) -> bool:
        try:
            active_ids = self.active_browser_download_ids()
            if not active_ids:
                self.download_cancel_poll_timer_id = None
                return False

            payloads = [download_guard_cancel_requests(urgent=True)]
            if self.config.get("download_guard_standard_cancel_poll_enabled", True):
                payloads.append(download_guard_cancel_requests(urgent=False))

            handled = 0
            for payload in payloads:
                for req in payload.get("requests", []) if isinstance(payload.get("requests"), list) else []:
                    did = str(req.get("download_id") or req.get("id") or "").strip()
                    if not did or did not in active_ids:
                        continue
                    if req.get("acknowledged") or req.get("status") in {"cancelled", "failed", "aborted"}:
                        continue
                    if did in self.processed_download_cancel_ids:
                        continue
                    self.processed_download_cancel_ids.add(did)
                    self.cancel_download_by_id(did, source="download_guard_urgent_poll", urgent=bool(req.get("urgent") or req.get("immediate") or payload.get("urgent_only")))
                    handled += 1

            if handled:
                self.refresh_downloads_page_if_open()
            return True
        except Exception as exc:
            log_security_event("download_guard_cancel_poll_failed", {"error": str(exc)})
            return True

    def cancel_download_by_id(self, download_id: str, source: str = "downloads_page", urgent: bool = False) -> Dict[str, Any]:
        """Cancel a browser-owned WebKit download object outside WebKit navigation callbacks.

        RC20 keeps active cancellation Browser-owned and removes Download Guard from
        the normal live-transfer hot path. Download Guard cancel queue support is
        retained for post-v1 experiments, disabled by default for v1.
        """
        did = (download_id or "").strip()
        if not did:
            return {"ok": False, "error": "missing_download_id"}

        filename = "download"
        found = False
        for _key, ctx in list(self.download_context.items()):
            if str(ctx.get("download_id", "")) == did:
                filename = str(ctx.get("filename") or filename)
                ctx["cancel_requested"] = True
                ctx["cancel_requested_at"] = datetime.now(timezone.utc).isoformat()
                ctx["cancel_request_source"] = source
                ctx["urgent_cancel"] = bool(urgent)
                found = True

        for uri, rec in list(getattr(self, "pending_downloads_by_uri", {}).items()):
            if str(rec.get("download_id", "")) == did:
                filename = str(rec.get("filename") or filename)
                self.pending_downloads_by_uri.pop(uri, None)
                found = True

        self.set_download_icon_state("idle")
        self.set_status("Cancelling download: " + filename)

        try:
            self.GLib.timeout_add(150, self.perform_deferred_download_cancel, did)
        except Exception as exc:
            log_security_event("download_cancel_defer_failed", {"download_id": did, "source": source, "error": str(exc)})
            self.perform_deferred_download_cancel(did)

        log_security_event("download_cancel_requested", {"download_id": did, "filename": filename, "found": found, "source": source, "urgent": bool(urgent)})
        return {"ok": True, "download_id": did, "filename": filename, "deferred": True, "found": found, "source": source, "urgent": bool(urgent)}

    def perform_deferred_download_cancel(self, download_id: str) -> bool:
        did = (download_id or "").strip()
        filename = "download"
        browser_object_cancelled = False
        found_context = False
        pending_removed = False

        try:
            for key, ctx in list(self.download_context.items()):
                if str(ctx.get("download_id", "")) != did:
                    continue
                found_context = True
                filename = str(ctx.get("filename") or filename)
                download = ctx.get("_download_obj")
                ctx["cancel_requested"] = True
                try:
                    if download is not None:
                        self.stop_download_progress_timer(download)
                except Exception:
                    pass
                try:
                    if download is not None:
                        download.cancel()
                        browser_object_cancelled = True
                except Exception as exc:
                    log_security_event("download_cancel_object_failed", {"download_id": did, "error": str(exc)})
                ctx["cancel_invoked"] = True

            for uri, rec in list(getattr(self, "pending_downloads_by_uri", {}).items()):
                if str(rec.get("download_id", "")) == did:
                    filename = str(rec.get("filename") or filename)
                    self.pending_downloads_by_uri.pop(uri, None)
                    pending_removed = True

            ack_status = "cancelled" if (browser_object_cancelled or found_context or pending_removed) else "failed"
            ack_msg = "Browser-owned WebKit cancellation executed" if ack_status == "cancelled" else "Download ID was not active inside Sentinel Browser"
            ack_result = download_guard_cancel_ack(did, ack_status, ack_msg) if self.config.get("download_guard_cancel_ack_enabled", True) else {"ok": False, "skipped": True}
            self.set_download_icon_state("idle")
            self.set_status("Download cancelled: " + filename if ack_status == "cancelled" else "Cancel failed: " + filename)
            log_security_event("download_cancel_deferred_complete", {"download_id": did, "filename": filename, "browser_object_cancelled": browser_object_cancelled, "found_context": found_context, "pending_removed": pending_removed, "ack_status": ack_status, "ack_ok": ack_result.get("ok")})
            try:
                self.GLib.timeout_add(250, self.refresh_downloads_page_if_open)
            except Exception:
                pass
        except Exception as exc:
            log_security_event("download_cancel_deferred_failed", {"download_id": did, "error": str(exc)})
            try:
                download_guard_cancel_ack(did, "failed", "Browser cancel failed: " + str(exc))
            except Exception:
                pass
            self.set_status("Cancel failed")
        return False

    def handle_downloads_internal_uri(self, uri: str) -> bool:
        try:
            parsed = urlparse(uri)
            if parsed.scheme != "sentinel" or parsed.netloc != "downloads":
                return False
            if parsed.path in ("", "/"):
                self.show_downloads_page()
                return True
            if parsed.path != "/action":
                return False
            qs = parse_qs(parsed.query)
            verb = (qs.get("verb", [""])[0] or "").strip()
            if verb == "cancel-active":
                did = qs.get("download_id", [""])[0]
                result = self.cancel_download_by_id(did)
                if result.get("ok"):
                    self.set_status("Cancelling active download: " + str(result.get("filename", "download")))
                else:
                    self.set_status("Cancel failed: " + str(result.get("error", "unknown")))
                return True
            if verb == "review-release":
                item_id = qs.get("item_id", [""])[0]
                if not item_id:
                    self.set_status("Review failed: missing item ID")
                    return True
                result = run_download_guard_json(["--release-prompt", item_id], timeout=300)
                if result.get("ok"):
                    item = result.get("item", {}) if isinstance(result.get("item", {}), dict) else {}
                    name = str(item.get("original_filename") or item.get("filename") or result.get("filename") or "download")
                    action = str(result.get("action") or item.get("status") or "decision_recorded").lower()
                    released_to = result.get("released_to") or result.get("release_destination") or item.get("release_destination") or item.get("released_to")
                    if released_to or action in {"released", "release", "approved"}:
                        self.reset_download_indicator_after_terminal_download_decision(name, "released")
                    elif action in {"deleted", "delete", "abandoned", "abandon", "removed"}:
                        self.reset_download_indicator_after_terminal_download_decision(name, "deleted")
                    elif action in {"keep_quarantined", "kept", "quarantined"}:
                        self.reset_download_indicator_after_terminal_download_decision(name, "keep_quarantined")
                    else:
                        self.set_status("Download Guard decision recorded")
                else:
                    self.set_status("Review/release failed: " + str(result.get("error") or result.get("message") or "unknown"))
                self.refresh_downloads_page_if_open()
                return True
            if verb == "go-to-file":
                item_id = qs.get("item_id", [""])[0]
                result = run_download_guard_json(["--open-file", item_id], timeout=20)
                if result.get("ok"):
                    name = str(result.get("filename") or result.get("path") or result.get("released_path") or "download")
                    self.reset_download_indicator_after_terminal_download_decision(Path(name).name, "go_to_file")
                    self.set_status("Opening released file")
                else:
                    self.set_status("Go to File unavailable: " + str(result.get("message") or result.get("error") or "not released"))
                return True
            if verb == "show-folder":
                item_id = qs.get("item_id", [""])[0]
                result = run_download_guard_json(["--open-folder", item_id], timeout=20)
                if result.get("ok"):
                    name = str(result.get("filename") or result.get("path") or result.get("folder") or "download")
                    self.reset_download_indicator_after_terminal_download_decision(Path(name).name, "show_folder")
                    self.set_status("Opening download folder")
                else:
                    self.set_status("Show Folder failed: " + str(result.get("message") or result.get("error") or "unknown"))
                return True
        except Exception as exc:
            log_security_event("downloads_internal_uri_failed", {"uri": uri, "error": str(exc)})
            self.set_status("Download action failed")
            return True
        return False



    def handle_wallet_internal_uri(self, uri: str) -> bool:
        try:
            parsed = urlparse(uri)
            if parsed.scheme != "sentinel" or parsed.netloc != "wallet":
                return False
            self.open_sentinel_wallet_ui()
            return True
        except Exception as exc:
            log_security_event("wallet_internal_uri_failed", {"uri": uri, "error": str(exc)})
            self.set_status("Wallet action failed")
            return True

    def browser_active_downloads_snapshot(self) -> List[Dict[str, Any]]:
        records: List[Dict[str, Any]] = []
        for ctx in list(self.download_context.values()):
            did = str(ctx.get("download_id", ""))
            filename = str(ctx.get("filename") or "download")
            percent = float(ctx.get("last_progress", 0.0) or 0.0)
            status = "cancelling" if ctx.get("cancel_requested") else "active"
            records.append({
                "id": did,
                "download_id": did,
                "filename": filename,
                "percent": max(0.0, min(100.0, percent)),
                "status": status,
                "source_url": str(ctx.get("uri") or ""),
                "message": "Browser is handling the live transfer. Download Guard reviews it after completion.",
            })
        return records

    def show_downloads_page(self) -> None:
        try:
            self.downloads_button.set_sensitive(True)
        except Exception:
            pass
        st = download_status_json(False)
        st["browser_active_downloads"] = self.browser_active_downloads_snapshot()
        guard = st.get("download_guard_backend", {})
        html_text = downloads_page_html(st, guard)
        self.create_tab("about:blank", True)
        cur = self.current()
        if cur:
            try:
                cur["is_downloads_page"] = True
                self.render_downloads_page(cur["webview"], reload_uri=True)
                cur["label"].set_text("Downloads")
                self.address.set_text("sentinel://downloads")
            except Exception as exc:
                log_security_event("downloads_page_load_failed", {"error": str(exc)})
                self.show_download_status_panel()
        self.set_status("Sentinel Downloads page opened")

    def show_download_status_panel(self) -> None:
        st = download_status_json(False)
        policy = st.get("policy", {})
        backend = st.get("download_guard_backend", {})
        readiness = backend.get("readiness", {}) if isinstance(backend, dict) else {}
        lines = [
            "Sentinel Browser Download Guard",
            "",
            f"Backend available: {backend.get('available')}",
            f"Ready for browser handoff: {readiness.get('ready_for_browser_v0_10_handoff')}",
            f"Ask before download: {policy.get('ask_before_download')}",
            f"Dangerous confirmation: {policy.get('confirm_dangerous_downloads')}",
            f"Auto-open downloads: {policy.get('auto_open_downloads')}",
            "",
            "Release rule:",
            "Files only move to the user Downloads folder after Download Guard release approval.",
        ]
        self.info_dialog("Download Guard", "\n".join(lines))


    def download_guard_tooltip_status(self, fallback: str = "") -> str:
        # v0.10.10: GTK tooltip must be fast and local-only.
        # Do not spawn DLG subprocesses from hover/flash/progress UI paths.
        detail = getattr(self, "download_button_detail", "") or ""
        state = getattr(self, "download_button_state", "idle")
        if state == "active":
            return "Download active" + (f": {detail}" if detail else "")
        if state == "complete":
            return "Download complete — click DLG button to review" + (f": {detail}" if detail else "")
        return fallback or "Downloads / Download Guard"


    def set_download_icon_state(self, state: str, detail: str = "") -> None:
        try:
            self.download_button_state = state
            self.download_button_detail = detail or ""
            ctx = self.downloads_button.get_style_context()
            for cls in ("sentinel-download-idle", "sentinel-download-active", "sentinel-download-complete"):
                ctx.remove_class(cls)
            cls = {
                "active": "sentinel-download-active",
                "complete": "sentinel-download-complete",
                "idle": "sentinel-download-idle",
            }.get(state, "sentinel-download-idle")
            ctx.add_class(cls)

            tooltip = {
                "active": "Download active — browser is downloading",
                "complete": "Download complete — click Downloads to review or Go to File after release",
                "idle": "Downloads / Download Guard page",
            }.get(state, "Downloads / Download Guard page")
            if detail:
                tooltip += f": {detail}"
            live_tip = self.download_guard_tooltip_status(tooltip if state != "idle" else "Downloads / Download Guard")
            self.downloads_button.set_tooltip_text(live_tip)
            self.downloads_button.set_sensitive(True)

            if state == "active":
                self.start_download_button_flash()
            else:
                self.stop_download_button_flash()
                markup = {
                    "complete": "<span foreground='#B7F774' weight='bold'>✓</span>",
                    "idle": "<span foreground='#E19B00' weight='bold'>⇩</span>",
                }.get(state, "<span foreground='#E19B00' weight='bold'>⇩</span>")
                if hasattr(self, "downloads_button_label"):
                    self.downloads_button_label.set_markup(markup)
        except Exception as exc:
            log_security_event("download_icon_state_failed", {"state": state, "error": str(exc)})

    def reset_download_indicator_after_terminal_download_decision(self, filename: str = "", decision: str = "released") -> None:
        """Return the toolbar Downloads indicator to idle after a terminal DLG decision.

        Event-driven only: no polling, no auto-refresh timer, and no Download Guard
        subprocess call from the active WebKit transfer path. The completed/green
        state remains while a file is waiting for Review / Release, then returns
        to the normal Downloads icon after Release/Delete/Abandon/Go-to-File.
        """
        try:
            decision_key = str(decision or "").lower()
            if decision_key in {"released", "release", "go_to_file", "show_folder"}:
                if not self.config.get("download_indicator_reset_after_release_enabled", True):
                    return
            elif decision_key in {"deleted", "delete", "abandoned", "abandon", "keep_quarantined"}:
                if not self.config.get("download_indicator_reset_after_delete_enabled", True):
                    return
            if getattr(self, "download_context", None):
                return
            pending = getattr(self, "pending_downloads_by_uri", {})
            if isinstance(pending, dict) and pending:
                return
            self.set_download_icon_state("idle")
            name = str(filename or "download")
            if decision_key in {"released", "release", "go_to_file", "show_folder"}:
                self.set_status("Download released: " + name)
            elif decision_key in {"deleted", "delete", "abandoned", "abandon"}:
                self.set_status("Download removed from quarantine: " + name)
            elif decision_key == "keep_quarantined":
                self.set_status("Download kept quarantined: " + name)
        except Exception as exc:
            log_security_event("download_indicator_terminal_reset_failed", {"filename": filename, "decision": decision, "error": str(exc)})

    def start_download_button_flash(self) -> None:
        try:
            self.downloads_button.set_sensitive(True)
            if getattr(self, "download_button_flash_timer_id", None):
                return
            self.download_button_flash_on = False
            self.download_button_flash_timer_id = self.GLib.timeout_add(450, self.pulse_download_button)
            self.pulse_download_button()
            log_security_event("download_button_flash_started", {"state": getattr(self, "download_button_state", "")})
        except Exception as exc:
            log_security_event("download_button_flash_start_failed", {"error": str(exc)})

    def stop_download_button_flash(self) -> None:
        try:
            timer_id = getattr(self, "download_button_flash_timer_id", None)
            if timer_id:
                try:
                    self.GLib.source_remove(timer_id)
                except Exception:
                    pass
            self.download_button_flash_timer_id = None
            self.download_button_flash_on = False
            self.downloads_button.set_sensitive(True)
        except Exception as exc:
            log_security_event("download_button_flash_stop_failed", {"error": str(exc)})

    def pulse_download_button(self) -> bool:
        try:
            if getattr(self, "download_button_state", "idle") != "active":
                self.download_button_flash_timer_id = None
                return False
            self.download_button_flash_on = not getattr(self, "download_button_flash_on", False)
            colour = "#B7F774" if self.download_button_flash_on else "#E19B00"
            glyph = "⇩"
            if hasattr(self, "downloads_button_label"):
                self.downloads_button_label.set_markup(f"<span foreground='{colour}' weight='bold'>{glyph}</span>")
            try:
                detail = getattr(self, "download_button_detail", "") or ""
                self.downloads_button.set_tooltip_text("Download active" + (f": {detail}" if detail else ""))
            except Exception:
                pass
            self.downloads_button.set_sensitive(True)
            return True
        except Exception as exc:
            log_security_event("download_button_flash_pulse_failed", {"error": str(exc)})
            self.download_button_flash_timer_id = None
            return False

    def show_download_guard_completed_prompt(self, item: Dict[str, Any]) -> None:
        filename = item.get("original_filename", "download")
        risk = item.get("risk_level", "unknown")
        item_id = item.get("id", "")
        dialog = self.Gtk.MessageDialog(
            transient_for=self.window,
            flags=0,
            message_type=self.Gtk.MessageType.INFO,
            buttons=self.Gtk.ButtonsType.NONE,
            text="Download Guard review required",
        )
        dialog.format_secondary_text(
            f"Download completed into quarantine.\n\n"
            f"File: {filename}\n"
            f"Risk: {risk}\n"
            f"Item ID: {item_id}\n\n"
            "The file will only move to your Downloads folder after Download Guard release approval."
        )
        dialog.add_button("Review / Release", self.Gtk.ResponseType.OK)
        dialog.add_button("Downloads Page", self.Gtk.ResponseType.APPLY)
        dialog.add_button("Keep Quarantined", self.Gtk.ResponseType.CANCEL)
        response = dialog.run()
        dialog.destroy()
        if response == self.Gtk.ResponseType.APPLY:
            self.show_downloads_page()
            self.set_download_icon_state("idle")
            return
        if response != self.Gtk.ResponseType.OK:
            self.set_status("Download kept quarantined: " + filename)
            self.set_download_icon_state("idle")
            return
        result = run_download_guard_json(["--release-prompt", item_id], timeout=3600)
        log_security_event("download_guard_release_prompt_result", {"item_id": item_id, "result": result})
        released_to = result.get("released_to") or result.get("item", {}).get("release_destination")
        if result.get("ok") and released_to:
            self.reset_download_indicator_after_terminal_download_decision(filename, "released")
            self.show_released_file_prompt(str(released_to))
        elif result.get("ok") and result.get("action") == "keep_quarantined":
            self.set_status("Download kept quarantined: " + filename)
        elif result.get("ok"):
            self.set_status("Download Guard decision recorded")
        else:
            self.info_dialog("Download Guard", "Download Guard release prompt did not complete.\n\n" + str(result.get("error") or result.get("message") or result))
        self.set_download_icon_state("idle")

    def show_released_file_prompt(self, released_path: str) -> None:
        folder = str(Path(released_path).expanduser().parent)
        dialog = self.Gtk.MessageDialog(
            transient_for=self.window,
            flags=0,
            message_type=self.Gtk.MessageType.INFO,
            buttons=self.Gtk.ButtonsType.NONE,
            text="Download released",
        )
        dialog.format_secondary_text(
            f"Download Guard released the file.\n\n{released_path}\n\n"
            "Open only if you trust the file and intended to use it."
        )
        dialog.add_button("Open File", self.Gtk.ResponseType.OK)
        dialog.add_button("Open Folder", self.Gtk.ResponseType.APPLY)
        dialog.add_button("Close", self.Gtk.ResponseType.CANCEL)
        response = dialog.run()
        dialog.destroy()
        if response == self.Gtk.ResponseType.OK:
            open_path_with_system(released_path)
            self.set_status("Opening released file: " + Path(released_path).name)
        elif response == self.Gtk.ResponseType.APPLY:
            open_path_with_system(folder)
            self.set_status("Opening download folder: " + folder)
        else:
            self.set_status("Download released: " + Path(released_path).name)

    def handoff_download_to_guard(self, file_path: str, source_url: str, suggested_filename: str) -> Dict[str, Any]:
        result = run_download_guard_json([
            "--import-completed-download",
            "--file", file_path,
            "--source-url", source_url or "",
            "--suggested-filename", suggested_filename or Path(file_path).name,
        ], timeout=120)
        log_security_event("download_guard_handoff_result", {
            "file": file_path,
            "source_url": source_url,
            "suggested_filename": suggested_filename,
            "result": result,
        })
        return result

    def show_preferences_dialog(self) -> None:
        """User-ready Preferences window for Phase 4.

        This is intentionally conservative: it exposes the settings that already have
        local config/backend support and avoids pretending that Browser stores passwords,
        TOTP secrets, or remote sync settings.
        """
        Gtk = self.Gtk
        cfg = load_config(False)
        policy = load_search_policy()
        dialog = Gtk.Dialog(title="Sentinel Browser Preferences", transient_for=self.window, flags=0)
        dialog.add_button("Cancel", Gtk.ResponseType.CANCEL)
        apply_button = dialog.add_button("Apply", Gtk.ResponseType.OK)
        try:
            apply_button.set_can_default(True)
            apply_button.grab_default()
        except Exception:
            pass
        dialog.set_default_size(720, 520)
        notebook = Gtk.Notebook()
        notebook.set_scrollable(True)
        dialog.get_content_area().pack_start(notebook, True, True, 8)

        def tab_box() -> Any:
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
            box.set_border_width(12)
            return box

        general = tab_box()
        home_entry = Gtk.Entry()
        home_entry.set_text(str(cfg.get("home_url", "about:blank")))
        bookmarks_check = Gtk.CheckButton(label="Show bookmarks toolbar")
        bookmarks_check.set_active(bool(cfg.get("show_bookmarks_bar", True)))
        private_check = Gtk.CheckButton(label="Open normal windows in private mode by default")
        private_check.set_active(bool(cfg.get("private_by_default", False)))
        general.pack_start(Gtk.Label(label="Home page URL"), False, False, 0)
        general.pack_start(home_entry, False, False, 0)
        general.pack_start(bookmarks_check, False, False, 0)
        general.pack_start(private_check, False, False, 0)
        notebook.append_page(general, Gtk.Label(label="General"))

        search = tab_box()
        default_combo = Gtk.ComboBoxText()
        private_combo = Gtk.ComboBoxText()
        for key in ["duckduckgo", "mojeek", "marginalia", "startpage", "google", "bing"]:
            default_combo.append(key, SEARCH_ENGINES[key]["name"])
            private_combo.append(key, SEARCH_ENGINES[key]["name"])
        default_combo.set_active_id(str(policy.get("default_search_engine", cfg.get("default_search_engine", "duckduckgo"))))
        private_combo.set_active_id(str(policy.get("private_search_engine", cfg.get("private_search_engine", "mojeek"))))
        custom_entry = Gtk.Entry()
        custom_entry.set_placeholder_text("https://example.com/search?q={query}")
        custom_entry.set_text(str(policy.get("custom_search_url") or cfg.get("custom_search_url") or ""))
        search.pack_start(Gtk.Label(label="Default search engine"), False, False, 0)
        search.pack_start(default_combo, False, False, 0)
        search.pack_start(Gtk.Label(label="Private/incognito search engine"), False, False, 0)
        search.pack_start(private_combo, False, False, 0)
        search.pack_start(Gtk.Label(label="Custom search URL; must include {query}"), False, False, 0)
        search.pack_start(custom_entry, False, False, 0)
        notebook.append_page(search, Gtk.Label(label="Search"))

        privacy = tab_box()
        history_check = Gtk.CheckButton(label="Allow local history logging")
        history_check.set_active(bool(cfg.get("history_logging_enabled", False)))
        third_party_check = Gtk.CheckButton(label="Block third-party cookies")
        third_party_check.set_active(bool(cfg.get("block_third_party_cookies", True)))
        clear_exit_check = Gtk.CheckButton(label="Clear cache on exit")
        clear_exit_check.set_active(bool(cfg.get("clear_cache_on_exit", False)))
        for w in (history_check, third_party_check, clear_exit_check):
            privacy.pack_start(w, False, False, 0)
        privacy.pack_start(Gtk.Label(label="Sentinel Browser remains local-first: no sync, telemetry, or browser-stored passwords."), False, False, 0)
        notebook.append_page(privacy, Gtk.Label(label="Privacy"))

        security = tab_box()
        js_combo = Gtk.ComboBoxText()
        for key in ["standard", "shield", "lockdown"]:
            js_combo.append(key, key.title())
        js_combo.set_active_id(str(cfg.get("javascript_profile", "standard")))
        danger_check = Gtk.CheckButton(label="Warn/confirm risky executable downloads")
        danger_check.set_active(bool(cfg.get("confirm_dangerous_downloads", True)))
        tls_check = Gtk.CheckButton(label="Block TLS/certificate errors")
        tls_check.set_active(bool(cfg.get("block_tls_errors", True)))
        external_check = Gtk.CheckButton(label="Warn before opening external app/protocol links")
        external_check.set_active(bool(cfg.get("warn_external_protocols", True)))
        ask_download_check = Gtk.CheckButton(label="Ask before starting downloads")
        ask_download_check.set_active(bool(cfg.get("ask_before_download", True)))
        block_danger_check = Gtk.CheckButton(label="Block dangerous downloads until manually confirmed")
        block_danger_check.set_active(bool(cfg.get("block_dangerous_downloads", True)))
        no_auto_open_check = Gtk.CheckButton(label="Never auto-open downloads after completion")
        no_auto_open_check.set_active(not bool(cfg.get("auto_open_downloads", False)))
        camera_block_check = Gtk.CheckButton(label="Block camera requests")
        camera_block_check.set_active(str(cfg.get("permission_camera_default", "block")).lower() == "block")
        mic_block_check = Gtk.CheckButton(label="Block microphone requests")
        mic_block_check.set_active(str(cfg.get("permission_microphone_default", "block")).lower() == "block")
        location_block_check = Gtk.CheckButton(label="Block location requests")
        location_block_check.set_active(str(cfg.get("permission_geolocation_default", "block")).lower() == "block")
        notifications_block_check = Gtk.CheckButton(label="Block notification requests")
        notifications_block_check.set_active(str(cfg.get("permission_notifications_default", "block")).lower() == "block")
        clipboard_ask_check = Gtk.CheckButton(label="Ask before clipboard access")
        clipboard_ask_check.set_active(str(cfg.get("permission_clipboard_default", "ask")).lower() == "ask")
        popups_block_check = Gtk.CheckButton(label="Block popups/new windows")
        popups_block_check.set_active(str(cfg.get("permission_popups_default", "block")).lower() == "block")
        file_access_block_check = Gtk.CheckButton(label="Block file-access permission requests")
        file_access_block_check.set_active(str(cfg.get("permission_file_access_default", "block")).lower() == "block")
        autoplay_block_check = Gtk.CheckButton(label="Block media autoplay permission requests")
        autoplay_block_check.set_active(str(cfg.get("permission_media_autoplay_default", "block")).lower() == "block")
        unknown_ask_check = Gtk.CheckButton(label="Ask before unknown permission requests")
        unknown_ask_check.set_active(bool(cfg.get("permission_prompt_unknown", True)))

        security.pack_start(Gtk.Label(label="JavaScript profile"), False, False, 0)
        security.pack_start(js_combo, False, False, 0)
        for w in (
            danger_check, block_danger_check, ask_download_check, no_auto_open_check, tls_check, external_check,
            camera_block_check, mic_block_check, location_block_check, notifications_block_check, clipboard_ask_check,
            popups_block_check, file_access_block_check, autoplay_block_check, unknown_ask_check,
        ):
            security.pack_start(w, False, False, 0)
        security.pack_start(Gtk.Label(label="Unchecked sensitive permission boxes fall back to Ask, not silent Allow. Browser password storage remains disabled."), False, False, 0)
        notebook.append_page(security, Gtk.Label(label="Security"))

        downloads = tab_box()
        dlg_enabled = Gtk.CheckButton(label="Use Sentinel Download Guard for browser downloads")
        dlg_enabled.set_active(bool(cfg.get("download_guard_backend_enabled", True)))
        prompt_check = Gtk.CheckButton(label="Show completion review prompt after quarantine")
        prompt_check.set_active(bool(cfg.get("download_guard_completion_prompt_enabled", False)))
        release_entry = Gtk.Entry()
        release_entry.set_placeholder_text(str(Path.home() / "Downloads"))
        release_status = run_download_guard_json(["--show-release-dir"], timeout=8)
        if release_status.get("release_dir"):
            release_entry.set_text(str(release_status.get("release_dir")))
        downloads.pack_start(dlg_enabled, False, False, 0)
        downloads.pack_start(prompt_check, False, False, 0)
        downloads.pack_start(Gtk.Label(label="Download Guard release folder"), False, False, 0)
        downloads.pack_start(release_entry, False, False, 0)
        downloads.pack_start(Gtk.Label(label="Performance target: network transfer stays normal; guard polling/copy/release must not block the UI."), False, False, 0)
        notebook.append_page(downloads, Gtk.Label(label="Downloads"))

        site_data = tab_box()
        site_data.pack_start(Gtk.Label(label="Clear app-scoped WebKit data, cache, session state, and security event logs."), False, False, 0)
        clear_now = Gtk.Button(label="Open Site Data Manager")
        clear_now.connect("clicked", lambda *_: self.show_site_data_manager())
        site_data.pack_start(clear_now, False, False, 0)
        notebook.append_page(site_data, Gtk.Label(label="Site Data"))

        vault = tab_box()
        vault.pack_start(Gtk.Label(label="Vault bridge source of truth: Sentinel Password Vault. Browser stores no passwords or TOTP secrets."), False, False, 0)
        vault.pack_start(Gtk.Label(label="Toolbar Vault/2FA button opens a restricted Vault-owned receiver/popup when available."), False, False, 0)
        notebook.append_page(vault, Gtk.Label(label="Vault"))


        network = tab_box()
        proxy_mode_combo = Gtk.ComboBoxText()
        for key, label in [("system", "Use Debian/system proxy settings"), ("direct", "Direct connection / no proxy"), ("custom", "Custom proxy values")]:
            proxy_mode_combo.append(key, label)
        proxy_mode_combo.set_active_id(str(cfg.get("proxy_mode", "system")))
        proxy_http_entry = Gtk.Entry(); proxy_http_entry.set_placeholder_text("http://127.0.0.1:8080")
        proxy_http_entry.set_text(str(cfg.get("proxy_http", "")))
        proxy_https_entry = Gtk.Entry(); proxy_https_entry.set_placeholder_text("http://127.0.0.1:8080")
        proxy_https_entry.set_text(str(cfg.get("proxy_https", "")))
        proxy_socks_entry = Gtk.Entry(); proxy_socks_entry.set_placeholder_text("socks5://127.0.0.1:9050")
        proxy_socks_entry.set_text(str(cfg.get("proxy_socks", "")))
        proxy_bypass_entry = Gtk.Entry(); proxy_bypass_entry.set_text(str(cfg.get("proxy_bypass", "localhost,127.0.0.1,::1")))
        vpn_cmd_entry = Gtk.Entry(); vpn_cmd_entry.set_placeholder_text("nm-connection-editor or your VPN app command")
        vpn_cmd_entry.set_text(str(cfg.get("vpn_helper_command", "")))
        network.pack_start(Gtk.Label(label="Proxy mode"), False, False, 0)
        network.pack_start(proxy_mode_combo, False, False, 0)
        network.pack_start(Gtk.Label(label="HTTP proxy"), False, False, 0); network.pack_start(proxy_http_entry, False, False, 0)
        network.pack_start(Gtk.Label(label="HTTPS proxy"), False, False, 0); network.pack_start(proxy_https_entry, False, False, 0)
        network.pack_start(Gtk.Label(label="SOCKS proxy"), False, False, 0); network.pack_start(proxy_socks_entry, False, False, 0)
        network.pack_start(Gtk.Label(label="Proxy bypass list"), False, False, 0); network.pack_start(proxy_bypass_entry, False, False, 0)
        network.pack_start(Gtk.Label(label="VPN/helper command"), False, False, 0); network.pack_start(vpn_cmd_entry, False, False, 0)
        network.pack_start(Gtk.Label(label="Network note: v1 uses Debian/system network stack by default. Use your OS VPN/proxy for enforced routing; these values are local Browser settings and future direct WebKit proxy policy inputs."), False, False, 0)
        notebook.append_page(network, Gtk.Label(label="Network"))

        about = tab_box()
        about.pack_start(Gtk.Label(label=f"{APP_NAME} {VERSION} — Program {PROGRAM}"), False, False, 0)
        about.pack_start(Gtk.Label(label="Local-first SentinelOS browser with Download Guard quarantine workflow."), False, False, 0)
        notebook.append_page(about, Gtk.Label(label="About"))

        dialog.show_all()
        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            try:
                cfg["home_url"] = home_entry.get_text().strip() or "about:blank"
                cfg["show_bookmarks_bar"] = bool(bookmarks_check.get_active())
                cfg["private_by_default"] = bool(private_check.get_active())
                cfg["history_logging_enabled"] = bool(history_check.get_active())
                cfg["block_third_party_cookies"] = bool(third_party_check.get_active())
                cfg["clear_cache_on_exit"] = bool(clear_exit_check.get_active())
                cfg["javascript_profile"] = js_combo.get_active_id() or "standard"
                cfg["confirm_dangerous_downloads"] = bool(danger_check.get_active())
                cfg["block_dangerous_downloads"] = bool(block_danger_check.get_active())
                cfg["ask_before_download"] = bool(ask_download_check.get_active())
                cfg["auto_open_downloads"] = not bool(no_auto_open_check.get_active())
                cfg["block_tls_errors"] = bool(tls_check.get_active())
                cfg["warn_external_protocols"] = bool(external_check.get_active())
                cfg["permission_camera_default"] = "block" if camera_block_check.get_active() else "ask"
                cfg["permission_microphone_default"] = "block" if mic_block_check.get_active() else "ask"
                cfg["permission_geolocation_default"] = "block" if location_block_check.get_active() else "ask"
                cfg["permission_notifications_default"] = "block" if notifications_block_check.get_active() else "ask"
                cfg["permission_clipboard_default"] = "ask" if clipboard_ask_check.get_active() else "block"
                cfg["permission_popups_default"] = "block" if popups_block_check.get_active() else "ask"
                cfg["permission_file_access_default"] = "block" if file_access_block_check.get_active() else "ask"
                cfg["permission_media_autoplay_default"] = "block" if autoplay_block_check.get_active() else "ask"
                cfg["permission_prompt_unknown"] = bool(unknown_ask_check.get_active())
                cfg["download_guard_backend_enabled"] = bool(dlg_enabled.get_active())
                cfg["download_guard_completion_prompt_enabled"] = bool(prompt_check.get_active())
                cfg["proxy_mode"] = proxy_mode_combo.get_active_id() or "system"
                cfg["proxy_http"] = proxy_http_entry.get_text().strip()
                cfg["proxy_https"] = proxy_https_entry.get_text().strip()
                cfg["proxy_socks"] = proxy_socks_entry.get_text().strip()
                cfg["proxy_bypass"] = proxy_bypass_entry.get_text().strip()
                cfg["vpn_helper_command"] = vpn_cmd_entry.get_text().strip()
                default_engine = default_combo.get_active_id() or "duckduckgo"
                private_engine = private_combo.get_active_id() or "mojeek"
                custom_url = custom_entry.get_text().strip()
                if custom_url and "{query}" not in custom_url:
                    self.info_dialog("Custom Search URL", "Custom search URL was ignored because it does not include {query}.")
                    custom_url = ""
                policy["default_search_engine"] = default_engine
                policy["private_search_engine"] = private_engine
                policy["custom_search_url"] = custom_url
                save_json(SEARCH_POLICY, policy)
                cfg["default_search_engine"] = default_engine
                cfg["private_search_engine"] = private_engine
                cfg["custom_search_url"] = custom_url
                cfg["search_url"] = search_engine_url(default_engine, policy)
                save_config(cfg)
                release_dir = release_entry.get_text().strip()
                if release_dir:
                    result = run_download_guard_json(["--set-release-dir", release_dir], timeout=15)
                    if not result.get("ok"):
                        self.info_dialog("Download Guard", "Release directory was not changed.\n\n" + str(result.get("error") or result))
                self.config = load_config(False)
                self.search_policy = load_search_policy()
                self.refresh_bookmarks_toolbar()
                self.set_status("Preferences updated")
            except Exception as exc:
                log_crash(exc)
                self.info_dialog("Preferences", "Preferences could not be saved.\n\n" + str(exc))
        dialog.destroy()

    def show_site_data_manager(self) -> None:
        Gtk = self.Gtk
        dialog = Gtk.MessageDialog(
            transient_for=self.window,
            flags=0,
            message_type=Gtk.MessageType.WARNING,
            buttons=Gtk.ButtonsType.NONE,
            text="Site Data / Clear Browsing Data",
        )
        dialog.format_secondary_text(
            "This clears Sentinel Browser's app-scoped session state, WebKit data/cache, and security-event log.\n\n"
            "It does not delete Download Guard quarantine records unless you manage them from Download Guard."
        )
        dialog.add_button("Cancel", Gtk.ResponseType.CANCEL)
        dialog.add_button("Clear Site Data", Gtk.ResponseType.OK)
        dialog.add_button("Clear Site Data + Bookmarks", Gtk.ResponseType.APPLY)
        response = dialog.run()
        dialog.destroy()
        if response not in (Gtk.ResponseType.OK, Gtk.ResponseType.APPLY):
            self.set_status("Site data clear cancelled")
            return
        removed = clear_browsing_data(clear_bookmarks=(response == Gtk.ResponseType.APPLY), clear_config=False)
        self.set_status("Cleared site data" + (f" ({len(removed)} paths)" if removed else ""))
        self.info_dialog("Site Data Cleared", "Removed:\n" + ("\n".join(removed) if removed else "Nothing needed removal."))

    def show_clear_data_notice(self) -> None:
        self.info_dialog("Clear Browsing Data", "Use the helper command for now:\n\nsentinel-browser-clear-data\n\nThe Phase 4 Site Data Manager is now available from Security → Site Data / Clear Browsing Data and Preferences → Site Data.")

    def current_uri(self) -> str:
        cur = self.current()
        try:
            return cur["webview"].get_uri() if cur else ""
        except Exception:
            return ""

    def current_domain(self) -> str:
        return _host_from_uri(self.current_uri())

    def open_vault_2fa_bridge_ui(self) -> None:
        origin = self.current_uri()
        domain = _host_from_uri(origin)
        result = launch_vault_bridge(browser_origin=origin, mode="2fa")
        if result.get("ok"):
            self.set_status("Opened Vault 2FA mini popup" + (f" | {domain}" if domain else ""))
        else:
            self.info_dialog("Vault 2FA bridge", result.get("error", "Sentinel Password Vault could not be opened."))

    def open_vault_password_bridge_ui(self) -> None:
        domain = self.current_domain()
        result = launch_vault_bridge(browser_origin=domain, mode="password")
        if result.get("ok"):
            self.set_status("Vault password receiver requested" + (f" | {domain}" if domain else ""))
        else:
            self.info_dialog("Vault password bridge", result.get("error", "Sentinel Password Vault could not be opened."))

    def open_sentinel_wallet_ui(self) -> None:
        result = launch_sentinel_wallet(self.current_uri())
        if result.get("ok"):
            self.set_status("Opened Sentinel Wallet")
        else:
            self.info_dialog("Sentinel Wallet", result.get("error", "Sentinel Wallet could not be opened."))

    def show_wallet_integration_panel(self) -> None:
        st = wallet_integration_status_json(include_raw=True)
        lines = [
            "Sentinel Wallet Integration",
            "",
            f"Wallet available: {st.get('wallet_available')}",
            f"Command: {st.get('wallet_command')}",
            f"Payments enabled in Browser: {st.get('browser_payments_enabled')}",
            f"Wallet is crypto-only: {st.get('wallet_crypto_only')}",
            f"Card features enabled: {st.get('wallet_card_features_enabled')}",
            f"NFT support: {st.get('wallet_nft_supported')}",
            f"Wallet login message signing: {st.get('wallet_message_signing_supported')}",
            f"Browser stores wallet secrets: {st.get('browser_stores_wallet_secrets')}",
            f"Browser signs transactions: {st.get('browser_signs_transactions')}",
            f"Status: {st.get('status')}",
            "",
            "Rule: Browser can open Wallet on explicit user click only. It does not store seed phrases, private keys, passphrases, or payment secrets.",
        ]
        self.info_dialog("Sentinel Wallet", "\n".join(lines))

    def show_vault_2fa_panel(self) -> None:
        st = vault_2fa_toolbar_status_json(False)
        bridge = st.get("vault_bridge", {})
        binary = bridge.get("vault_binary", {})
        lines = [
            "Sentinel Password Vault Manual Bridge",
            "",
            f"Toolbar button present: {st.get('toolbar_button_present')}",
            f"Mode: {st.get('mode')}",
            f"Vault command available: {binary.get('available')}",
            "",
            "Source of truth: Sentinel Password Vault",
            "Browser stores passwords: False",
            "Browser stores TOTP secrets: False",
            "Browser generates TOTP codes: False",
            "",
            "Current behaviour:",
            "- toolbar button opens restricted Vault 2FA mini popup",
            "- browser may store only account hints and browser bridge-pair half",
            "- no secret is returned to browser in this patch",
            "",
            "Vault receiver:",
            "- unlock Vault",
            "- match current site/domain",
            "- verify browser/vault bridge halves",
            "- ask user approval before password fill or TOTP display/copy",
        ]
        self.info_dialog("Vault / 2FA", "\n".join(lines))

    def show_manual_dialog(self) -> None:
        """Render-safe local manual entry under Help.

        RC20 deliberately uses a GTK dialog instead of a WebKit-rendered manual page at startup.
        This avoids the rejected RC11/RC12 GUI-rendering crash path while still giving users
        a local Manual entry from the Help menu.
        """
        self.info_dialog(
            "Sentinel Browser Manual",
            "Sentinel Browser local manual\n\n"
            "Downloads: files download in the Browser first, then go to Download Guard for Review / Release. Go to File appears only after release.\n\n"
            "Security: use the shield button beside 2FA, or Security → Security Controls, to edit JavaScript, risky downloads, permissions, and HTTPS-first behaviour.\n\n"
            "Vault: the Browser does not store passwords. Use Vault / Save to Vault only launches the restricted Password Vault receiver.\n\n"
            "Network: use Preferences → Network for system/direct/custom proxy notes and VPN helper settings.\n\n"
            "HTTPS-first: bare domains open as HTTPS and typed http:// URLs are upgraded when HTTPS-first is enabled."
        )

    def show_about_panel(self) -> None:
        self.info_dialog("About Sentinel Browser", f"{APP_NAME} {VERSION}\nProgram {PROGRAM}\n\nLightweight SentinelOS browser. Local-first. No telemetry. No browser-stored passwords. User-controlled search, JavaScript, permissions, and Vault 2FA mini-popup consumer compatible with Sentinel Password Vault 0.9.9.1+, toolbar bookmarks/downloads buttons, tab-row new-tab button, themed incognito/2FA icons, fixed clickable/toggleable bookmarks toolbar, removed address-bar favourite star, bookmark editor popup, toolbar star save routing to the editor, Enter-key dialog activation for editor/status popups, Vault login prompt bar with Use Vault / Enter Manually / Never for Site choices, Download Guard quarantine handoff, Downloads page, green active/complete status feedback, Go to File/Show Folder for released downloads, completion prompt, open released file/folder options, bottom-left link/image hover preview, strict Use Vault password receiver guard, bookmark/tab context menus, page text/link copy/search context actions, user-controlled search/security settings, Preferences window, Download Guard release-folder setting, and GUI Site Data controls, local home page, Save to Vault prompt, and Network/Proxy/VPN settings, a label-free empty-by-default favourites/bookmarks bar with user-created bookmark folders plus drag/reorder toolbar bookmark handling, editable Security checkbox controls, and visible crypto-only Sentinel Wallet status/open integration with NFT foundation and no card features.")


    def _javascript_result_to_python(self, message: Any) -> Any:
        try:
            if hasattr(message, "get_js_value"):
                value = message.get_js_value()
                try:
                    if hasattr(value, "to_json"):
                        raw = value.to_json(0)
                        return json.loads(raw)
                except Exception:
                    pass
                try:
                    if hasattr(value, "to_string"):
                        raw = value.to_string()
                        try:
                            return json.loads(raw)
                        except Exception:
                            return raw
                except Exception:
                    pass
            if hasattr(message, "get_value"):
                value = message.get_value()
                try:
                    return json.loads(str(value))
                except Exception:
                    return str(value)
            try:
                return json.loads(str(message))
            except Exception:
                return str(message)
        except Exception as exc:
            log_security_event("homepage_bridge_message_parse_failed", {"error": str(exc)})
            return None

    def on_homepage_script_message(self, manager: Any, message: Any) -> None:
        data = self._javascript_result_to_python(message)
        try:
            if isinstance(data, str):
                data = json.loads(data)
        except Exception:
            pass
        if not isinstance(data, dict):
            log_security_event("homepage_bridge_message_ignored", {"reason": "not_object", "type": type(data).__name__})
            return
        msg_type = str(data.get("type") or data.get("event") or "")
        if msg_type not in {"sentinel-home-weather-city-set", "weather-city-set", "homepage-weather-city-set"}:
            log_security_event("homepage_bridge_message_ignored", {"reason": "unknown_type", "type": msg_type})
            return
        try:
            prefs = save_homepage_weather_city(data.get("index"), data.get("label") or data.get("cityLabel") or data.get("city"), "script-message")
            # v1.0.8: rewrite the runtime homepage immediately after a city save.
            # Otherwise a user can save a city, hit reload, and WebKit may reload the old
            # homepage-runtime.html that still contains the Melbourne fallback bootstrap.
            try:
                render_runtime_homepage_file(self.config)
                log_security_event("homepage_runtime_rewritten_after_city_save", {"label": prefs.get("weather_city_label"), "index": prefs.get("weather_city_index")})
            except Exception as runtime_exc:
                log_security_event("homepage_runtime_rewrite_after_city_save_failed", {"error": str(runtime_exc)})
            self.set_status("Homepage default city saved: " + str(prefs.get("weather_city_label", "city")))
        except Exception as exc:
            log_security_event("homepage_bridge_city_save_failed", {"error": str(exc), "message": data})
            self.set_status("Homepage city save failed: " + str(exc))

    def _wallet_provider_approved_result(self, method: str, response: Dict[str, Any], wallet_request_id: str) -> Any:
        """Return a conservative dApp-facing result after Wallet approval.

        v1.1.6 still keeps secrets/signing material Wallet-owned. Where Wallet has not
        produced a public address/signature payload yet, return a clear approval object
        instead of fabricating an address or signature.
        """
        method = str(method or "")
        address = str(response.get("address") or response.get("public_address") or response.get("account") or "").strip()
        signature = response.get("signature") or response.get("signed_payload") or response.get("signedTransaction")
        base = {
            "approved": True,
            "wallet": "Sentinel Wallet",
            "requestId": wallet_request_id,
            "secretValuesExported": False,
            "signedPayloadOnly": bool(response.get("signed_payload_only", False)),
        }
        if method in {"eth_requestAccounts", "eth_accounts"}:
            accounts = response.get("accounts") or response.get("addresses")
            if isinstance(accounts, list) and accounts:
                return [str(x) for x in accounts if str(x).strip()]
            native = response.get("native_provider") if isinstance(response.get("native_provider"), dict) else {}
            native_accounts = native.get("accounts") or native.get("addresses")
            if isinstance(native_accounts, list) and native_accounts:
                return [str(x) for x in native_accounts if str(x).strip()]
            native_address = str(native.get("address") or native.get("public_address") or native.get("account") or "").strip()
            if native_address:
                return [native_address]
            return [address] if address else base
        if method in {"eth_chainId"}:
            native = response.get("native_provider") if isinstance(response.get("native_provider"), dict) else {}
            return str(response.get("chain_id") or native.get("chain_id") or "0x1")
        if method in {"net_version"}:
            native = response.get("native_provider") if isinstance(response.get("native_provider"), dict) else {}
            chain = str(response.get("chain_id") or native.get("chain_id") or "0x1").lower()
            return EVM_CHAIN_REGISTRY.get(chain, EVM_CHAIN_REGISTRY["0x1"]).get("networkVersion", "1")
        if method == "solana_connect":
            native = response.get("native_provider") if isinstance(response.get("native_provider"), dict) else {}
            public_key = str(response.get("publicKey") or response.get("public_key") or native.get("publicKey") or native.get("public_key") or address or native.get("address") or "").strip()
            if public_key:
                return {"publicKey": public_key, "address": public_key, "chainFamily": "solana"}
            return base
        if method == "solana_signMessage" and signature:
            native = response.get("native_provider") if isinstance(response.get("native_provider"), dict) else {}
            public_key = str(response.get("publicKey") or response.get("public_key") or native.get("publicKey") or native.get("public_key") or address or native.get("address") or "").strip()
            return {"signature": signature, "signatureBase64": signature, "publicKey": public_key, "signedPayloadOnly": True}
        if method in {"personal_sign", "eth_sign", "eth_signTypedData", "eth_signTypedData_v3", "eth_signTypedData_v4", "btc_signMessage"} and signature:
            return signature
        if method in {"eth_signTransaction", "eth_sendTransaction", "solana_signTransaction", "btc_signPsbt", "btc_signPsbts"} and (signature or response.get("signed_transaction_hex")):
            return response.get("signed_transaction_hex") or signature
        return base


    def _clear_active_wallet_request(self, wallet_request_id: str = "", browser_msg_id: str = "") -> None:
        """Clear active dApp approval de-dup records after Wallet resolves/rejects/timeouts."""
        try:
            for key, val in list(getattr(self, "active_wallet_provider_requests", {}).items()):
                if (wallet_request_id and val.get("wallet_request_id") == wallet_request_id) or (browser_msg_id and val.get("browser_msg_id") == browser_msg_id):
                    self.active_wallet_provider_requests.pop(key, None)
        except Exception:
            pass

    def _poll_wallet_provider_response(self, webview: Any, browser_msg_id: str, wallet_request_id: str, method: str, origin: str, started: float, timeout_seconds: int) -> bool:
        try:
            response = wallet_bridge_read_response(wallet_request_id)
            status = str(response.get("status") or "")
            decision = str(response.get("decision") or "").lower()
            if decision == "pending" or status == "pending":
                if time.time() - started > max(10, int(timeout_seconds or 90)):
                    js = "window.__sentinelWalletReject && window.__sentinelWalletReject(%s);" % json.dumps({"id": browser_msg_id, "error": "Timed out waiting for Sentinel Wallet approval"})
                    webview.run_javascript(js, None, None, None)
                    log_security_event("wallet_provider_response_timeout", {"method": method, "origin": origin, "request_id": wallet_request_id})
                    self._clear_active_wallet_request(wallet_request_id, browser_msg_id)
                    return False
                return True
            if decision == "approved":
                result = self._wallet_provider_approved_result(method, response, wallet_request_id)
                js = "window.__sentinelWalletResolve && window.__sentinelWalletResolve(%s);" % json.dumps({"id": browser_msg_id, "ok": True, "requestId": wallet_request_id, "status": "approved", "result": result})
                webview.run_javascript(js, None, None, None)
                log_security_event("wallet_provider_response_approved", {"method": method, "origin": origin, "request_id": wallet_request_id, "secret_values_exported": bool(response.get("secret_values_exported"))})
                self._clear_active_wallet_request(wallet_request_id, browser_msg_id)
                return False
            if decision in {"rejected", "cancelled"}:
                js = "window.__sentinelWalletReject && window.__sentinelWalletReject(%s);" % json.dumps({"id": browser_msg_id, "error": "Sentinel Wallet " + decision, "requestId": wallet_request_id, "status": decision})
                webview.run_javascript(js, None, None, None)
                log_security_event("wallet_provider_response_rejected", {"method": method, "origin": origin, "request_id": wallet_request_id, "decision": decision})
                self._clear_active_wallet_request(wallet_request_id, browser_msg_id)
                return False
            return True
        except Exception as exc:
            try:
                webview.run_javascript("window.__sentinelWalletReject && window.__sentinelWalletReject(%s);" % json.dumps({"id": browser_msg_id, "error": str(exc)}), None, None, None)
            except Exception:
                pass
            log_security_event("wallet_provider_response_poll_failed", {"method": method, "origin": origin, "request_id": wallet_request_id, "error": str(exc)})
            self._clear_active_wallet_request(wallet_request_id, browser_msg_id)
            return False

    def on_wallet_script_message(self, manager: Any, message: Any) -> None:
        data = self._javascript_result_to_python(message)
        try:
            if isinstance(data, str):
                data = json.loads(data)
        except Exception:
            pass
        if not isinstance(data, dict):
            log_security_event("wallet_provider_message_ignored", {"reason": "not_object"})
            return
        method = str(data.get("method") or data.get("requestKind") or "dapp_request")
        request_id = str(data.get("id") or new_wallet_request_id("dapp"))
        origin = str(data.get("origin") or self.current_uri() or "unknown")
        params = data.get("params")
        cur = self.current() and self.current().get("webview")
        if method in {"eth_chainId", "net_version"}:
            result = "0x1" if method == "eth_chainId" else "1"
            if cur:
                cur.run_javascript("window.__sentinelWalletResolve && window.__sentinelWalletResolve(%s);" % json.dumps({"id": request_id, "ok": True, "result": result}), None, None, None)
            return
        if method == "eth_accounts":
            if cur:
                cur.run_javascript("window.__sentinelWalletResolve && window.__sentinelWalletResolve(%s);" % json.dumps({"id": request_id, "ok": True, "result": []}), None, None, None)
            return
        if method == "walletconnect_pair" and isinstance(params, list) and params and isinstance(params[0], str):
            if self.handle_walletconnect_uri(params[0], "provider-js"):
                if cur:
                    cur.run_javascript("window.__sentinelWalletResolve && window.__sentinelWalletResolve(%s);" % json.dumps({"id": request_id, "ok": True, "status": "walletconnect_approval_requested"}), None, None, None)
                return
        chain_family = native_provider_chain_family(method)
        if method in {"wallet_switchEthereumChain", "wallet_addEthereumChain"} and isinstance(params, list) and params and isinstance(params[0], dict) and params[0].get("chainId"):
            chain_id = params[0].get("chainId")
        elif chain_family == "evm":
            chain_id = getattr(self, "current_evm_chain_id", "0x1")
        elif chain_family == "solana":
            chain_id = "solana:mainnet"
        else:
            chain_id = ""
        note = json.dumps({"provider": "sentinel-browser", "native_provider_schema": NATIVE_PROVIDER_REQUEST_SCHEMA, "phase": "phase3_solana_provider_methods", "method": method, "params": params, "chain_family": chain_family, "chain_id": chain_id, "requires_user_approval": True, "browser_signs_transactions": False, "browser_stores_wallet_secrets": False, "compatibility": "v1.1.15-uniswap-popup-regression-repair"}, sort_keys=True)[:6000]
        kind_map = {
            "eth_requestAccounts": "dapp_login_request",
            "eth_accounts": "dapp_login_request",
            "personal_sign": "personal_sign_request",
            "eth_sign": "personal_sign_request",
            "eth_signTypedData": "personal_sign_request",
            "eth_signTypedData_v3": "personal_sign_request",
            "eth_signTypedData_v4": "personal_sign_request",
            "wallet_switchEthereumChain": "dapp_login_request",
            "wallet_addEthereumChain": "dapp_login_request",
            "wallet_watchAsset": "dapp_login_request",
            "eth_sendTransaction": "transaction_sign_request",
            "eth_signTransaction": "transaction_sign_request",
            "solana_connect": "dapp_login_request",
            "solana_signMessage": "personal_sign_request",
            "solana_signTransaction": "transaction_sign_request",
            "solana_signAllTransactions": "transaction_sign_request",
            "solana_signAndSendTransaction": "transaction_sign_request",
            "walletconnect_pair": "walletconnect_pairing",
            "btc_requestAccounts": "dapp_login_request",
            "btc_signMessage": "personal_sign_request",
            "btc_signPsbt": "transaction_sign_request",
            "btc_signPsbts": "transaction_sign_request",
        }
        kind = kind_map.get(method, "dapp_login_request")
        dedupe_key = (origin or "unknown") + "|" + method
        try:
            existing = getattr(self, "active_wallet_provider_requests", {}).get(dedupe_key)
            if existing and (time.time() - float(existing.get("started", 0))) < int(self.config.get("native_provider_response_timeout_seconds", self.config.get("walletconnect_provider_response_timeout_seconds", 90)) or 90):
                wallet_request_id = str(existing.get("wallet_request_id") or "")
                if cur and wallet_request_id:
                    self.set_status("Sentinel Wallet approval already pending for: " + method)
                    timeout_seconds = int(self.config.get("native_provider_response_timeout_seconds", self.config.get("walletconnect_provider_response_timeout_seconds", 90)) or 90)
                    self.GLib.timeout_add(700, self._poll_wallet_provider_response, cur, request_id, wallet_request_id, method, origin, time.time(), timeout_seconds)
                    return
            cmd_id = request_id if request_id.startswith("browser-") else new_wallet_request_id("dapp")
            obj = run_wallet_json(["browser-bridge", "--write-request", "--request-id", cmd_id, "--request-kind", kind, "--browser-origin", origin, "--note", note], timeout=5)
            wallet_request_id = str(obj.get("request_id") or cmd_id)
            getattr(self, "active_wallet_provider_requests", {})[dedupe_key] = {"wallet_request_id": wallet_request_id, "browser_msg_id": request_id, "started": time.time(), "method": method, "origin": origin}
            launch = {}
            try:
                launch = launch_sentinel_wallet(origin, request_id=wallet_request_id, request_kind=kind)
            except Exception as launch_exc:
                launch = {"ok": False, "error": str(launch_exc)}
            if launch.get("ok"):
                self.set_status("Sentinel Wallet opened — unlock, then approve or decline: " + method)
            else:
                self.set_status("Wallet request saved; open Sentinel Wallet to approve: " + method)
            log_security_event("wallet_provider_request_forwarded", {"method": method, "kind": kind, "origin": origin, "request_id": wallet_request_id, "ok": obj.get("ok"), "wallet_launch_ok": launch.get("ok"), "response_polling": bool(self.config.get("native_provider_response_polling_enabled", self.config.get("walletconnect_provider_response_polling_enabled", True)))})
            if not cur:
                return
            if not obj.get("ok", True):
                cur.run_javascript("window.__sentinelWalletReject && window.__sentinelWalletReject(%s);" % json.dumps({"id": request_id, "error": obj.get("error") or "Wallet bridge request failed"}), None, None, None)
                return
            if self.config.get("native_provider_response_polling_enabled", self.config.get("walletconnect_provider_response_polling_enabled", True)):
                timeout_seconds = int(self.config.get("native_provider_response_timeout_seconds", self.config.get("walletconnect_provider_response_timeout_seconds", 90)) or 90)
                self.GLib.timeout_add(700, self._poll_wallet_provider_response, cur, request_id, wallet_request_id, method, origin, time.time(), timeout_seconds)
            else:
                cur.run_javascript("window.__sentinelWalletResolve && window.__sentinelWalletResolve(%s);" % json.dumps({"id": request_id, "ok": True, "requestId": wallet_request_id, "status": "wallet_approval_requested"}), None, None, None)
        except Exception as exc:
            log_security_event("wallet_provider_request_failed", {"error": str(exc), "method": method})
            if cur:
                cur.run_javascript("window.__sentinelWalletReject && window.__sentinelWalletReject(%s);" % json.dumps({"id": request_id, "error": str(exc)}), None, None, None)

    def install_blockchain_provider_bridge(self, w: Any) -> None:
        if not self.config.get("blockchain_provider_injection_enabled", True):
            return
        try:
            manager = w.get_user_content_manager()
            if not manager:
                return
            try:
                manager.register_script_message_handler("sentinelWallet")
            except Exception:
                pass
            try:
                manager.connect("script-message-received::sentinelWallet", self.on_wallet_script_message)
            except Exception as exc:
                log_security_event("wallet_provider_signal_unavailable", {"error": str(exc)})
            W = self.WebKit2
            js = r'''
(function(){
  'use strict';
  if (window.__sentinelBlockchainProviderInstalled) return;
  window.__sentinelBlockchainProviderInstalled = true;
  const pending = new Map();
  const pendingByMethod = new Map();
  const listeners = {};
  const approvedEvmOrigins = {};
  let lastSentinelUserGesture = 0;
  window.__sentinelWalletDiscoveryReady = true;
  window.__sentinelWalletManualApprovalOnly = true;
  ['pointerdown','mousedown','mouseup','click','keydown','touchstart'].forEach(function(ev){
    try { window.addEventListener(ev, function(){ lastSentinelUserGesture = Date.now(); }, true); } catch(e){}
  });
  function nextId(){ return 'sentinel-' + Date.now().toString(36) + '-' + Math.random().toString(16).slice(2); }
  function hasRecentUserGesture(){ try { return (Date.now() - lastSentinelUserGesture) < 6500 || !!(navigator.userActivation && navigator.userActivation.isActive); } catch(e){ return false; } }
  function requiresManualGesture(method){ return ['eth_requestAccounts','wallet_requestPermissions','personal_sign','eth_sign','eth_signTypedData','eth_signTypedData_v3','eth_signTypedData_v4','eth_sendTransaction','eth_signTransaction','solana_connect','solana_signMessage','solana_signTransaction','solana_signAllTransactions','solana_signAndSendTransaction'].indexOf(String(method||'')) >= 0; }
  function emit(name, value){ try { (listeners[name] || []).slice().forEach(function(fn){ try { fn(value); } catch(e){} }); } catch(e){} }
  function safeMessage(msg){ try { return JSON.parse(JSON.stringify(msg)); } catch(e) { return msg; } }
  function originKey(){ return String(location.origin || location.href || 'unknown'); }
  function permissionResult(accounts){ accounts = (accounts || []).map(String).filter(Boolean); return accounts.length ? [{ parentCapability:'eth_accounts', caveats:[] }] : []; }
  function requestKey(method){ method = String(method || ''); if (method === 'eth_requestAccounts' || method === 'wallet_requestPermissions') return 'evm_authorize|' + originKey(); return method + '|' + originKey(); }
  function unsupported(method){ const err = new Error('Sentinel Wallet provider method not supported: ' + method); err.code = 4200; err.data = {method: method, sentinelUnsupported:true}; return Promise.reject(err); }
  window.__sentinelWalletResolve = function(msg){ try { const p = pending.get(msg.id); if (!p) return; pending.delete(msg.id); if (p.key) pendingByMethod.delete(p.key); p.resolve(Object.prototype.hasOwnProperty.call(msg, 'result') ? msg.result : msg); } catch(e) {} };
  window.__sentinelWalletReject = function(msg){ try { const p = pending.get(msg.id); if (!p) return; pending.delete(msg.id); if (p.key) pendingByMethod.delete(p.key); const err = new Error(msg.error || 'Sentinel Wallet request rejected'); err.code = msg.code || 4001; err.data = safeMessage(msg); p.reject(err); } catch(e) {} };
  function post(method, params){
    method = String(method || '');
    const key = requestKey(method);
    if (requiresManualGesture(method) && !hasRecentUserGesture()) {
      const err = new Error('Sentinel Wallet requires a manual user action before opening an approval popup');
      err.code = 4001; err.data = {manualUserActionRequired:true, method:method};
      return Promise.reject(err);
    }
    if (pendingByMethod.has(key)) return pendingByMethod.get(key);
    const id = nextId();
    const promise = new Promise(function(resolve, reject){
      pending.set(id, {resolve: resolve, reject: reject, method: method, key: key});
      try { window.webkit.messageHandlers.sentinelWallet.postMessage({id:id, method:method, params:params || [], origin:originKey(), manualUserAction:true}); }
      catch(e) { pending.delete(id); pendingByMethod.delete(key); reject(e); }
    });
    pendingByMethod.set(key, promise);
    return promise;
  }
  const evmChains = {
    '0x1': {networkVersion:'1', name:'Ethereum Mainnet'},
    '0x38': {networkVersion:'56', name:'BNB Smart Chain'},
    '0x89': {networkVersion:'137', name:'Polygon'},
    '0xa': {networkVersion:'10', name:'Optimism'},
    '0xa4b1': {networkVersion:'42161', name:'Arbitrum One'},
    '0x2105': {networkVersion:'8453', name:'Base'},
    '0xa86a': {networkVersion:'43114', name:'Avalanche C-Chain'}
  };
  function normalizeChainId(value){
    if (value === undefined || value === null || value === '') return ethereum.chainId;
    if (typeof value === 'number') return '0x' + value.toString(16);
    const s = String(value).toLowerCase();
    if (s.indexOf('0x') === 0) return s;
    const n = parseInt(s, 10);
    return isFinite(n) ? '0x' + n.toString(16) : s;
  }
  function setChain(chainId){
    chainId = normalizeChainId(chainId || '0x1');
    ethereum.chainId = chainId;
    ethereum.networkVersion = (evmChains[chainId] && evmChains[chainId].networkVersion) || String(parseInt(chainId, 16) || 1);
    emit('chainChanged', chainId);
    return chainId;
  }
  function accountArrayFromResult(result){
    if (Array.isArray(result)) return result.map(String).filter(Boolean);
    if (result && Array.isArray(result.accounts)) return result.accounts.map(String).filter(Boolean);
    if (result && Array.isArray(result.addresses)) return result.addresses.map(String).filter(Boolean);
    if (result && result.address) return [String(result.address)];
    if (result && result.account) return [String(result.account)];
    return [];
  }
  const ethereum = {
    isSentinel: true,
    isMetaMask: true,
    _sentinelProvider: true,
    _sentinelPhase: 'phase3_uniswap_popup_regression_repair',
    isConnected: function(){ return true; },
    chainId: '0x1',
    networkVersion: '1',
    selectedAddress: null,
    _listeners: listeners,
    request: function(args){
      args = args || {}; const method = String(args.method || ''); const params = args.params || [];
      if (method === 'eth_chainId') return Promise.resolve(ethereum.chainId);
      if (method === 'net_version') return Promise.resolve(ethereum.networkVersion);
      if (method === 'web3_clientVersion') return Promise.resolve('SentinelWallet/1.1.15');
      if (method === 'eth_coinbase') return Promise.resolve(ethereum.selectedAddress || null);
      if (method === 'eth_accounts') return Promise.resolve(ethereum.selectedAddress ? [ethereum.selectedAddress] : []);
      if (method === 'wallet_getPermissions') return Promise.resolve(permissionResult(ethereum.selectedAddress ? [ethereum.selectedAddress] : []));
      if (method === 'wallet_revokePermissions') { ethereum.selectedAddress = null; delete approvedEvmOrigins[originKey()]; emit('accountsChanged', []); return Promise.resolve(null); }
      if (method === 'wallet_requestPermissions') {
        if (ethereum.selectedAddress && approvedEvmOrigins[originKey()]) return Promise.resolve(permissionResult([ethereum.selectedAddress]));
        return ethereum.request({method:'eth_requestAccounts', params:[]}).then(function(accounts){ return permissionResult(accounts); });
      }
      if (method === 'eth_requestAccounts' && ethereum.selectedAddress && approvedEvmOrigins[originKey()]) return Promise.resolve([ethereum.selectedAddress]);
      if (method === 'wallet_switchEthereumChain') {
        const chainId = normalizeChainId(params && params[0] && params[0].chainId);
        setChain(chainId); return Promise.resolve(null);
      }
      if (method === 'wallet_addEthereumChain') {
        if (params && params[0] && params[0].chainId) {
          const chainId = normalizeChainId(params[0].chainId);
          evmChains[chainId] = {networkVersion:String(parseInt(chainId,16)||chainId), name:String(params[0].chainName || 'Custom EVM Chain')};
        }
        return Promise.resolve(null);
      }
      if (method === 'wallet_watchAsset') return Promise.resolve(true);
      if (['eth_requestAccounts','personal_sign','eth_sign','eth_signTypedData','eth_signTypedData_v3','eth_signTypedData_v4','eth_sendTransaction','eth_signTransaction'].indexOf(method) < 0) return unsupported(method);
      return post(method, params).then(function(result){
        if (method === 'eth_requestAccounts') {
          const accounts = accountArrayFromResult(result);
          if (accounts.length) { ethereum.selectedAddress = accounts[0]; approvedEvmOrigins[originKey()] = true; emit('accountsChanged', accounts); return accounts; }
        }
        if (['personal_sign','eth_sign','eth_signTypedData','eth_signTypedData_v3','eth_signTypedData_v4','eth_sendTransaction','eth_signTransaction'].indexOf(method) >= 0) return result;
        if (method) return result;
        return unsupported(method);
      });
    },
    send: function(methodOrPayload, params){ if (typeof methodOrPayload === 'string') return this.request({method: methodOrPayload, params: params || []}); return this.request(methodOrPayload || {}); },
    sendAsync: function(payload, cb){ this.request(payload || {}).then(function(r){ cb && cb(null, {id: payload && payload.id, jsonrpc:'2.0', result:r}); }).catch(function(e){ cb && cb(e); }); },
    enable: function(){ return this.request({method:'eth_requestAccounts'}); },
    on: function(name, fn){ (listeners[name] = listeners[name] || []).push(fn); return this; },
    removeListener: function(name, fn){ const a=listeners[name]||[]; listeners[name]=a.filter(function(x){return x!==fn;}); return this; },
    removeAllListeners: function(name){ if (name) listeners[name]=[]; else Object.keys(listeners).forEach(function(k){listeners[k]=[];}); return this; },
    _metamask: { isUnlocked: function(){ return Promise.resolve(true); } }
  };
  try { Object.defineProperty(window, 'ethereum', {value: ethereum, configurable: true, writable:false}); } catch(e) { if (!window.ethereum) window.ethereum = ethereum; }
  if (!window.sentinelEthereum) Object.defineProperty(window, 'sentinelEthereum', {value: ethereum, configurable: true});
  function SentinelSolanaPublicKey(value){ this._value = value || 'SentinelWalletPendingApproval111111111111111111'; }
  SentinelSolanaPublicKey.prototype.toString = function(){ return this._value; };
  SentinelSolanaPublicKey.prototype.toBase58 = function(){ return this._value; };
  SentinelSolanaPublicKey.prototype.toJSON = function(){ return this._value; };
  SentinelSolanaPublicKey.prototype.toBytes = function(){ try { return new Uint8Array(base58Decode(this._value)); } catch(e){ return new Uint8Array(); } };
  SentinelSolanaPublicKey.prototype.toBuffer = function(){ try { return this.toBytes(); } catch(e){ return new Uint8Array(); } };
  SentinelSolanaPublicKey.prototype.equals = function(other){ return String(other || '') === this._value || (other && typeof other.toBase58 === 'function' && other.toBase58() === this._value); };
  function base58Decode(s){
    const alphabet='123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
    let bytes=[0];
    for (let i=0;i<String(s).length;i++) { const c=alphabet.indexOf(String(s)[i]); if (c < 0) throw new Error('invalid base58'); let carry=c; for (let j=0;j<bytes.length;j++){ carry += bytes[j]*58; bytes[j]=carry & 0xff; carry >>= 8; } while(carry){ bytes.push(carry & 0xff); carry >>= 8; } }
    for (let k=0;k<String(s).length && String(s)[k]==='1';k++) bytes.push(0);
    return bytes.reverse();
  }
  const solListeners = {};
  function solEmit(name, value){ try { (solListeners[name] || []).slice().forEach(function(fn){ try { fn(value); } catch(e){} }); } catch(e){} }
  function bytesToBase64(bytes){ var bin=''; for (var i=0;i<bytes.length;i++) bin += String.fromCharCode(bytes[i]); return btoa(bin); }
  function base64ToBytes(b64){ var bin = atob(String(b64||'')); var out = new Uint8Array(bin.length); for (var i=0;i<bin.length;i++) out[i] = bin.charCodeAt(i); return out; }
  function serialiseSolanaPayload(value){
    try {
      if (value instanceof Uint8Array) return {__sentinelType:'uint8array', encoding:'base64', data:bytesToBase64(value), length:value.length};
      if (value && value.constructor && value.constructor.name === 'Buffer' && typeof value.length === 'number') return {__sentinelType:'buffer', encoding:'base64', data:bytesToBase64(Uint8Array.from(value)), length:value.length};
      if (Array.isArray(value)) return {__sentinelType:'array', data:value};
      if (typeof value === 'string') return {__sentinelType:'string', data:value};
      if (value && typeof value.serialize === 'function') { var s=value.serialize(); return {__sentinelType:'serialized-transaction', encoding:'base64', data:bytesToBase64(Uint8Array.from(s)), length:s.length}; }
    } catch(e){}
    return value;
  }
  function solanaSignResult(result){
    result = result || {};
    var sig = result.signature || result.signatureBase64 || result;
    var out = { signature: (typeof sig === 'string') ? base64ToBytes(sig) : sig, publicKey: solana.publicKey || new SentinelSolanaPublicKey(result.publicKey || result.public_key || '') };
    out.signatureBase64 = (typeof sig === 'string') ? sig : '';
    return out;
  }
  const solana = { isSentinel: true, isPhantom: true, isConnected:false, publicKey:null, _sentinelPhase:'phase3_uniswap_popup_regression_repair',
    connect: function(opts){ opts = opts || {}; if (opts.onlyIfTrusted && !solana.isConnected) return Promise.reject(Object.assign(new Error('Sentinel Wallet approval required'), {code:4001})); return post('solana_connect', []).then(function(r){ solana.isConnected=true; var pk = r && (r.publicKey || r.public_key || r.address); if (pk) solana.publicKey = new SentinelSolanaPublicKey(String(pk)); solEmit('connect', solana.publicKey); return { publicKey: solana.publicKey || new SentinelSolanaPublicKey(), address: String(solana.publicKey || '') }; }); },
    disconnect: function(){ solana.isConnected=false; solana.publicKey=null; solEmit('disconnect'); return Promise.resolve(); },
    signMessage: function(msg, encoding){ return post('solana_signMessage', [serialiseSolanaPayload(msg), encoding || 'utf8']).then(solanaSignResult); },
    signTransaction: function(tx){ return post('solana_signTransaction', [serialiseSolanaPayload(tx)]).then(function(r){ return (r && (r.transaction || r.signedTransaction)) || tx; }); },
    signAllTransactions: function(txs){ return post('solana_signAllTransactions', [(txs || []).map(serialiseSolanaPayload)]).then(function(r){ return (r && (r.transactions || r.signedTransactions)) || txs; }); },
    signAndSendTransaction: function(tx, opts){ return post('solana_signAndSendTransaction', [serialiseSolanaPayload(tx), opts || {}]); },
    request: function(args){ args=args||{}; var method=String(args.method||''); var params=args.params||[]; if (method === 'connect') return solana.connect(params[0] || {}); if (method === 'disconnect') return solana.disconnect(); if (method === 'signMessage') return solana.signMessage(params[0], params[1]); if (method === 'signTransaction') return solana.signTransaction(params[0]); if (method === 'signAllTransactions') return solana.signAllTransactions(params[0]); return post('solana_' + method, params); },
    on: function(name, fn){ (solListeners[name] = solListeners[name] || []).push(fn); return solana; },
    removeListener: function(name, fn){ const a=solListeners[name]||[]; solListeners[name]=a.filter(function(x){return x!==fn;}); return solana; }
  };
  if (!window.sentinelSolana) Object.defineProperty(window, 'sentinelSolana', {value: solana, configurable: true});
  try { Object.defineProperty(window, 'solana', {value: solana, configurable: true, writable:false}); } catch(e) { if (!window.solana) window.solana = solana; }
  if (!window.phantom) Object.defineProperty(window, 'phantom', {value:{solana: solana}, configurable:true});
  else if (!window.phantom.solana) { try { window.phantom.solana = solana; } catch(e){} }
  const bitcoin = { isSentinel:true, requestAccounts:function(){ return post('btc_requestAccounts', []); }, signMessage:function(msg){ return post('btc_signMessage', [msg]); }, signPsbt:function(psbt){ return post('btc_signPsbt', [psbt]); }, signPsbts:function(psbts){ return post('btc_signPsbts', [psbts]); } };
  if (!window.sentinelBitcoin) Object.defineProperty(window, 'sentinelBitcoin', {value: bitcoin, configurable:true});
  if (!window.bitcoin) Object.defineProperty(window, 'bitcoin', {value: bitcoin, configurable:true});
  const wc = { pair:function(uri){ return post('walletconnect_pair', [uri]); } };
  if (!window.__sentinelWalletConnect) Object.defineProperty(window, '__sentinelWalletConnect', {value:wc, configurable:true});
  function looksWalletConnect(uri){ uri = String(uri || ''); return uri.indexOf('wc:') === 0 || uri.indexOf('walletconnect:') === 0; }
  const oldOpen = window.open;
  window.open = function(url){ if (looksWalletConnect(url)) { wc.pair(String(url)); return null; } return oldOpen ? oldOpen.apply(window, arguments) : null; };
  document.addEventListener('click', function(ev){ try { const a = ev.target && ev.target.closest && ev.target.closest('a[href]'); if (a && looksWalletConnect(a.getAttribute('href'))) { ev.preventDefault(); wc.pair(a.getAttribute('href')); } } catch(e){} }, true);
  try {
    const info = { uuid: 'sentinel-wallet-local-provider', name: 'Sentinel Wallet', icon: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAYOUlEQVR4nNV7eZhdVZXvb+19hjvWrTFFEkIYQkAKGVoaQ6NYUVFBaQekWtRARvJEaD6lfaBNe6sc2sYnCioNSWpKAgRueB+I4KMfYKKggCQvoIlAAokQSA331nTHM+293h/33kqRVJJKCHnfW993vvvdc/Zea52117TXXodwDIEZRATemjzDajzlja9bXPpHAlm+DP/vXMG8/ZTlI2PVMceKJzpWhJhBaAdhVkM0bYw91GQGH8tqAWYgYWiMKONF5ZqfblxS6kM7iDqgjwVf4lgQAQCsh6AO6D2Ub2+KBh/7eWixd+7sl/UHTnxZ/8Je5NWFgnOUoX9OBEb7MePq2GgAA0QAp267InxJYv327bHTZ3zgpJcBKi8AMfi5107n97nbvZH640+Z/bnde46VKbzXGkCchMAmGJyCnNn0atzUqHldnChAoKhyEFUOmEC7zJOEpTnkjDjTOAWJ9TA5Bcnv8SK9JwLgJAQnYQBg6oCm8+BTG5RdmjdSINF3odqkZrhv64IZQsEM4Xj3LT3PeUEVIEajwtxNbVDUBo/aoAjgDUkYnHxveD2q0uUkBFpA1AZVvTey2jzXNPjjuSJNm77M/1ZmTfifG8KlOzaV5qiVjddLArAs84vgvPBrxp6s/dOZS9wb+zut70RC2vQ9PDGUO3Hz3Btec6v417eA2ibgf7dwVATADMJ6iOqLj66y58BWX1JaX87AObEQIAjI5I1LZyzx/ld/t/mfDZb/NS6CQWARhhjxjFTT4uCfdq8yz4rbakvEYlFwAc20gwQ9Qizurbva31KhJ9AOHI1I8a4FwCnI6ov3rzDfHwrpb2rWbbEQIkUXcHxoIojaKKPkSQRafqFxoffQ31ZGP2ob/sNEiAWw/un4Rfn1ezqNiyKmejQe5ngmCzCgTINk1AYKDmkBPMokbqtfGPx+X9r/TwRQZeDN21Afa6B/I6KvhW22x4rllakJQ7AmFF30K41nwyHxguOLPzdFvcepjXV/l7EHzM1BKdo087rccKbLbg1b6vxSwH8nieeZJk4wJWOswNAaKhEl6WsCmNaVfOOW45a4OzkFiSugjzRiHJEAqkkNdUAPdslLbIN/GQnxyUN5aCKgLgpR9IQDpkcFi3uUDv+ubtHY6EQc6c6GuBajrzDzNIutOfVLnTfeQeO/mqP5gdF/8FVwJQR/Ph7i2uE8wIBfF4PpeDTiKXlz00J/JVD2D0diEsbhTkgmIYigAfBQt+ywTf5uoBnDObiJCGzXp1LJoS5hyDtrvuK9Up7lIZWCvKIJtBHA/PkItCMYYdTGbBieKq8eJ2GgFUAaTJ8cKAB4AsATxXWhZNFVy02pr42FdN1wFr6UXJeIqhXDq40LxnbO/Bp1vOEciRAOSwOqBLamYM0oyd6akL5yKA+fAKM2SlR08Yhi+Z2Ghf42oGwiADBRRasJzpu3HR+2E/33gpBQCH1pxpJ8emLyU3WsAFC18+HVdScI5NpNQy9yPYan4DbWkJ135NOFkv2FmcvzmVQK8nCixJQFwFweu/unx4dijf0PJ8LqE+kxOJEQQoAo+Ep8s6GijhuSMFoBfbTy+YrJSepAAAAjvdbniYK7TIObswU49TUUKvniz45jf+K4ZYWBw9GEKZkAY+9qhGv3PFgT4k+kx+Akogj5gdjpuqKtaZm/mVOQ2AauMnpIvJXk5lDMVrQiSCYhWgFRt9B7qO8uewsi/v31cf7gcJad+hp1ltbOb9IPN7S2bxkqHNVUekM5q8NAl1ypU8R9K1Eq3Qce6RUvvnpXeCYA8IbD9ydHCpUsEy/+D0SHe8Tj7jriPSuo5D9AnO42fl3l+aik0VU77l9lLPcfIB7oJKdwL/FIr/jL9jtiTVVi75rQEfK1/Q7YQz3iKec+4v6VKAUp4r5O2TFxzMHgoBLiJAQ6wJlOa65hBFsYbEgJqTWlR3LWB0++znmDkzCmqvJHEQgAV/OQ7XegprFG/MEy+MyiBy9skVX0xIeblwTPHCpZOugGY31LeRurWN8VsjisGUxEcBy68uTrnDc4tdcxVaHqLN9jYKAcHTgFOfcGZIsl44tKU04KCAYzCV7Bd8DGNvARmUJVfTKd8nJ3neD+TnKDFHHfSvkDoKx6B5xbEcKxMg3+TZmXvi5zibtO8J5V5AYPCh7sNb5xKD4OKJlkEuKyGZDHC7ElYvP7GIAb0I6m4/TZ6/MIPlmK1yp2fs1CR5UCg8HRMMxsAU9MX6q+AQCDXaGPRGz/rrwLVwhIovLSMQOkAapYKFd9Nb3zPxEBYLACNAOSMK6zDEBrqNoY2TlHdDZd5f2MCJzulhsjtv6IG0BpFhnh1pxWd81Itoxv/6gwqWQ2JGHM70BwfZf12Wg4aBnJc1AbFUapRDfTpXC33wE7cUNuKN0ln21M6G+OZgFDAloxEhHRMtRppBqWBs825Z3nMiSc5lo+N1sEpKjobvUFqys44f3HBTRxafZxZVUBmSGg6JBvuvKhcWSa/iVQ9LzrMzfGuXmEc4uIcHslSu3nqyb1Aa0ox2WN4DqlmWNhktkS/em45ephTkKcOgyfGRSY6rtDI/SmFAhKHoKSRz7ArIS+jRlEN8A1bfHf8iVSnoJf9EiVPOjqVfCgi/tebvnZO+75+/yW53tSEIJA3FJ3jbsLSUhOQTYtDTYVXfwqEYaRd5hZ6+W8AiZaoTCJxu8ngGoWle60TpMCFxVcZsskMoX4aXUOdUBvbIecfhUKQsh/C5lkaA0CYGZL0LVRXJDpNb8MALVfCf5Ucum+RAgmay4bS2WhicumQyhf4PK98n96x31UfxlMBBWyYWSLtHNaPPgFJyHQXvb0DJBliNsCTXB8cMTi09OG8Q9EYE7t/777a0Br5Z7Ql8XCbEgByhWoLyjWPgYA6CgTmt+BIJWCrNvl3zOax/M1YUjWUARQyWVm6B8OpBDjJIRhmLfkHVGqi5MVC5GMh0nWhEnGI5UrRDJuT/gfIVkTgYyHScbCe8dX50RtMmvCQmgl/pXaUEJLOeujNigwUL8w+GPJoy0hA8IwwCC+HACwbX8N2N8HbKyoP+tLXQ8qapPMFfF483Xp/L4x9QqU09ihHnGjZv00EQOAcDwE9XE9e6RgfIM6gu8Dzpt7VoQ/YptqpqugVFAWskLZvJUGQYOlsfde9XkVxt2ABitAZAtwp1/jPc5L31mCq+4ZBlfRQ+EQn5srgRl8Ma+AieUIqhXq6nCqqs3GJGRrK4A0eCyTqPFC+Vejtm4CSBdc+eWmxX4KyUnifkUoA6vkutqY/tJIHooIwpDMRKKgYb/vt5FS/9Gs4x0MqvwMrTYuEKyfNqSWRVe6ljROr426uzePQOT2gOeXNZmNcYl0IEBHFc3YyFCvOd/1uMsw6IOGls8RfGZMsmnZBmYGjfYa3y66/mWmweFAA4GCrotxfKTgtbe1YdnWFKwWQL3bEhZQ2Qu0VFR+X7iizKNHwZ+FJ3yw2Gxosbhuqfu3yojxOePBJpWCvMiJLQlx8RMaQgbC/t2dCwo/v+KXiEyPGt1aJZY0LR3K7as+VaiGzXSXbK+N6WQmCyUFJAjaNklrCv193VeLLwLAQKf8QSJG548VERBBEmlmRlm0VA79XHZ4RDSexTE0QFIwAdCutXja8mLfwXZ8ySTEdbPNn2XS/i39RZTOnBP5hqFKF7KQjovw49OvyvUCAPEj0yOZofSDjbHgkoIvQcyIGBrDjvGigfDHnVzIdd20mjULHgCgDXpfIVRLZIMtiIi82GZKnuUGYGZwIgI5WqCnpi/THwdAwz3y0roafrRQYhjG+Py9x0cHWPUgAGI1hPQQHmpapC+fWIWeuKKoePodfTBOHYYaPDHSaJHzVG1In5FXBkwEsE0gXTAfasr6V4o96eGOxkhwyW3iGv/9s15WZ8/6q7pbfNWtDwXn5H339ubr0vkTbkSpclihJuORCLwREM1tyIPlv4YtEDNYCMhsCao2ho8Nr7Y+A4DrF6nHBkZovWFAjxXgZYtQuRJUzoHKFvdeucpV+R94Cv7ICMZI29cRgbFtEj5QNgtqg5p7A1zqQAD2/7M2os9Ihm5yW054VZ0z6y/BOv6M3xT1P99XE7mJciuR2Rpvqbvg5K0EKjtFqTU/v2Muzynt9Eqm9WsDShOBTSkIhv3dxJW57ZNVXaoV2nSX+GM0zPPyTjn5iIRAJY9eborqc7ENQfZ0aw6C4KVAsVRc5R2V7ABEBAnam/FpDdVQQ3I4Rx3NS1R71eTG6VZ4GVsbPw3kfc/zFUMKBFoYMc/57IZEq/jHkzcIaAACiPt5/dLOk1AfDL9lmIy6nfJEAQFEgxIAQsEI0U7jJDqTXg8lGvQV4IqmhRiZAb0SwHa0TL6PIAIPr7a+pbT3NJWVUhQcqMY4nzGYM5Y1dwR3At72wW55Z1MTbnTyDEPuTYqDAMg5mKhnOmxDjBawG3H1k/Gkp2MC0QovXuAd3zg9aINfdSoG1ACwwzoNABBXRQTaQE7GxNs0DdP8TINRgNh9gbdp1jR3AIOhZgEAs4t/0xf4mzlPYmxsyGgXmgMhwKYlBZf4ZQDj3vYdL1/ZnlKb80z/KvE/6+O4fKQIJQSo4EJLyd99c1XNullvZUdHKfaDsZHCrkCDBCQgWPhKs2SaZcrgW14AJiqbUtgi4St5S3Obzm9IwphP++T0FV4KnvxrZAjXOoFizZKUFlaY6fvzC09FYkGBcmZUQABnZbeoM9VOKkLuoj3d4WunR0t3vqBO13clrtcSAb4+fDvOiewy+kas9hlLvY59X/RgwAwBAmfWWnMtBC/5ik2tiZhZNcRhDBfFj6ctVDcdyIP3d8pf1sX010fL+QSiYch8SWye9qY6H+1ApSQ/ZRjosW+bVuN+88ni3wVrGpcjHozhhqHbjLn2APoKkasIAPp6zB82GP63TVE+sVcMZIrG6uOWBgsHu0Mftmx7a2L7WA6tAFqhDlVsrCYj/Z3yjoa4/ueRPAIQpBRgInKJzJba19030AID26B31EOeehbU8G7j/JDUfyh6rFmDGOBYmETRMz/atNDdcKjqDjMIGytJYxpmthSfVXNVbke6x0w12f4XIQAw4DH8EddqP26x9+9UXYldPYlzopb+iGYYpPFs81W5P+652zgvHOZfa2We37DY2T3VSmuyUu1dfkKsIWSU/iqErvc8kGbo+hjkaEHeN21J8JXqC1Wd2ECX+F1NmC/KlaAYQG0McjRPv2peoj831XPAajTlHoQyWj5bdMXS2df6m4dTdR9ynGCeNMlRgfHbGQuG/zp+5D7Z2Xt/l3nNcA8New8QD62xP1Vd2UMxUIVqFSbTbdwQrBfc30nBYDfxYDepsTWk0t3G31dwWgAw0CkvL91HPNhFwWA36UwvqbE10hlba53GXGm0mAJUx6V7rNNHVxMP9YrhPZ3GtfuN4/K48bo8JyF4A4ytKVicgpSkrrdNrgsCsA6CTwKYdDd1IGjtKK9sQy64eziLV6IhCGZo1mDLgNCsbwWAjdug+TewBfGPlIauhGJVGyFRdMXdiQXeq9X+oimSFgwQVPBR24Q2JNcZktt5BSK8AcamFTB57/HeXqlSBzTNR9DSBE1tUMQiJQWx4zNp5ks3rYBZ3QpPBQhgtJSLIsTGTaYgquzlZa4EFQ9jfrrbumx+BwKUfcRWU0IAULYJMVakTFTbP+AkxGQR5yCgCWANfD5QEKYBTRq/ouUoIg0+bzn8icLcT63Wp8s2rokeK3mAF0BHLMw9xbY/BD48M6iGxaal3iNjBTyZiEAyQzFASjODgx9tTcKiNigLxk0lD64gIGKTUEzfr1mez2wExFRPeKpl/IFV9hwpcVHBBYNJMPCrA83ZTwBtbVDJJETTIn+Lr2lzxCISxHB8//ojOWpaX/k1hfwXL6BACBABouBA18bQ0jzbWAoAicXeDt8XdzXUwhwr0F+aosHdnIRoPQyt21huRGESwdJ4iC1DArkS3vID9dvyy+2vSZM6lvaK1AXh7pBFlC2yCpt82XCXeTbaoA9HC9oqWlC/xH+p5FF3bQRCM5SQoILDTMS3DK+oS3ASwlPqh/miyCktv0dt8NBy0P3RO4AZ1NoONbY63iCIl44VWdeEQQLUO3M5ipyEMRmuyT1rOxQzyJdN948V8GbIIrJMGB7UfxDAGw/DGQIYrxlEpZ0cK9KobYLARG4AlYjo6b6ZvZE6oGcuR2YkZ36mKLxHGftUeg4F7ZBE4KJbvDke4gYwOFeiHNi6iwFqn6yWcTCohrHBTnOZv464v5Nc537BA13WFyc+nypUtSbdadwUpCphsYv0cC+pkdUim18bmX6kp0qpCu6+XrNlZLVw+lfB9+8n7u+U/z6R9mRwQIIMEJIgACJ9vHghEuKzfQ2tmYYCDp09bVFxAMmp9/RWawa7W2CHC2KrbfBJjl+uGdRGIUfzomvaErUMK2FgOYIpq361nAfo9Czxh5DN85SG0or6ydctdXuQQzv4QP7rgMnFeBjrQCAM8TUNgh9ARWyeRnDuBQNoAU111YjK+E5oQ4lZfidkEnE5LMIPwER8PtZD4JqpvzwAYEV5a9w/U/4kEeF5RRduJCRkoI0b6pdjrFoxnjK+faGqPn2rZLt6gLhvJZW8+4nTveaK6vPDUd0qvsFO8XRpHfFAN3nFewUPdlmXTHw+JVwrYALAQKdxrXOf4P5VKAUPEPd3yZ7DxXVgIgBVEQ10isf8dcQDnVT0HxCc7jFvB8rqPeVUtXro2mPMG1srg+J9pAe6xGPA5Cn5pDjK9Mo+qkssya8VnO4q9y1kusQWXoFI6jAXZioERWZtfc1wr9jslIVQ8lOCh1bL7qpDnGqXyLhD7JLr+EHBY2ut0xigan4+lbnl+eK/F+4RPNhF7tga4pFeuXtPZ2g2MHVhTmlQ1YYaFwxn3aK+xPXopdoYQkNZduK2XnTWyfKp/i77ZJqPgJMQh1S9Slg0DPHj9Cj9R2KB9yqSoIPt9at4qQ1q188StUM9cm08wrfmHPbCFltaU382Lz41Y+l438KUnPNhqUi1Be3tFbHGaLj0UDysP5QZgxOLIORpMaR8cVPjIr+ryjBaQO+mi3NilbeaEwz12J8SRnBH2NBzRwtw6qIIlTyxYyQvP3vS172XD7d99rBtpLp339UzO1RHb98dC+urR4qsmUE1EaKiJzYQye/VLXA3js9JQW7cBmoFNDrKB56cgswUzSVCUA1TbGXjguFsMgnRDgAtoI3bQBMLn0NrzDOF0t82DP6yrxl+gKCxhoxsUTwx7NkLTllWGDiS3uEja5WdUBEe6jWWW5JvNU2dGCvAD9swGQQViCeZxcr6uvjj9Lmh3H44emaHBvRb6aYExTJ5Oad5ofv6fmNWfMDMmFs/bIhgiQa+GDa1lS0hiIVhKC0CHeCHtYtUBwF8uA2S70oAwN5OTmqDGuy2TrVN/SNT6su1ZuRd6IgNIYlQ8rAbLH6nmJ4IG/SCI4zRJrs4uCM2x0j07XyFCMcH2pozvcZ5qz8TbQjHgho34LMMoT7KGh8zDT7dEIycAw5bINskuL7Y6Pu4uXFJ8DwzqL0d1HGETZlHtV1+dI28WAj6FrO+2DIYBbdMIGSicgpHyHvmzc0LnVsfSU6PnDd76HVD8HEZL3TaGdfktg+sMq+OhHUnERsEhhcASgNhCyhrFV4QQv4kvsBP7Uv7SOHofDCxT8dn9h7jQma+mpk/bRqYATDCFpDJih9PW6xuervb/mSN5d1qFflMEMgP0a6sb39/xmJndd9KcX1DDf/cV+UeIcfHMBE9IYRcnfiq9zhQjiBH69O6o/vJzD69+5yqS2RLhQvJUB93fTqh8ergioE1oXkx4T6thSHXW59lBYkvlB6metvFgBP60vSrnQcy3cZK02Rolv9lGOYz8S8XBibSOBonzO8ppFLlfp3Jng10GU8V77e59cknXGxixibmC578vT90T0RnuuVru3pmh/adw3vxHfUexPe0qXG85X0EAnugnpn7ocQHSs+8tjHx4bpLZ/8eIeUTwHAMCw/uvBifzj3Ju+3jzjz1tf5XABhogXo3ecRU4D1tZKwwrpjLL/HcWk9pQEd1sXxAQSao0g0Q1kVogKUWQaVKHdAkJayjDcfk09lKh5act+BP2YIw/3gR/g8ty/zCB2loIiwY6gouVs9Tjo2/nBy+8PXkEX7+ckS8HQsiQCVStIP39FqnxaTaWCNV8/N8KpgEztOvwmNRHPOsS2YsdX7//4WjOxKohsv+7uj7h9eYT5R6UXRWwxm9x3xu9yq7deKYYwX/F9ciK8X/cwNRAAAAAElFTkSuQmCC', rdns: 'os.sentinel.wallet' };
    function announce(){ window.dispatchEvent(new CustomEvent('eip6963:announceProvider', {detail:{info:info, provider:ethereum}})); }
    window.addEventListener('eip6963:requestProvider', announce);
    setTimeout(announce, 50);
  } catch(e){}
  try {
    const sentinelSolanaWalletStandard = {
      version: '1.0.0',
      name: 'Sentinel Wallet',
      icon: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAYOUlEQVR4nNV7eZhdVZXvb+19hjvWrTFFEkIYQkAKGVoaQ6NYUVFBaQekWtRARvJEaD6lfaBNe6sc2sYnCioNSWpKAgRueB+I4KMfYKKggCQvoIlAAokQSA331nTHM+293h/33kqRVJJKCHnfW993vvvdc/Zea52117TXXodwDIEZRATemjzDajzlja9bXPpHAlm+DP/vXMG8/ZTlI2PVMceKJzpWhJhBaAdhVkM0bYw91GQGH8tqAWYgYWiMKONF5ZqfblxS6kM7iDqgjwVf4lgQAQCsh6AO6D2Ub2+KBh/7eWixd+7sl/UHTnxZ/8Je5NWFgnOUoX9OBEb7MePq2GgAA0QAp267InxJYv327bHTZ3zgpJcBKi8AMfi5107n97nbvZH640+Z/bnde46VKbzXGkCchMAmGJyCnNn0atzUqHldnChAoKhyEFUOmEC7zJOEpTnkjDjTOAWJ9TA5Bcnv8SK9JwLgJAQnYQBg6oCm8+BTG5RdmjdSINF3odqkZrhv64IZQsEM4Xj3LT3PeUEVIEajwtxNbVDUBo/aoAjgDUkYnHxveD2q0uUkBFpA1AZVvTey2jzXNPjjuSJNm77M/1ZmTfifG8KlOzaV5qiVjddLArAs84vgvPBrxp6s/dOZS9wb+zut70RC2vQ9PDGUO3Hz3Btec6v417eA2ibgf7dwVATADMJ6iOqLj66y58BWX1JaX87AObEQIAjI5I1LZyzx/ld/t/mfDZb/NS6CQWARhhjxjFTT4uCfdq8yz4rbakvEYlFwAc20gwQ9Qizurbva31KhJ9AOHI1I8a4FwCnI6ov3rzDfHwrpb2rWbbEQIkUXcHxoIojaKKPkSQRafqFxoffQ31ZGP2ob/sNEiAWw/un4Rfn1ezqNiyKmejQe5ngmCzCgTINk1AYKDmkBPMokbqtfGPx+X9r/TwRQZeDN21Afa6B/I6KvhW22x4rllakJQ7AmFF30K41nwyHxguOLPzdFvcepjXV/l7EHzM1BKdo087rccKbLbg1b6vxSwH8nieeZJk4wJWOswNAaKhEl6WsCmNaVfOOW45a4OzkFiSugjzRiHJEAqkkNdUAPdslLbIN/GQnxyUN5aCKgLgpR9IQDpkcFi3uUDv+ubtHY6EQc6c6GuBajrzDzNIutOfVLnTfeQeO/mqP5gdF/8FVwJQR/Ph7i2uE8wIBfF4PpeDTiKXlz00J/JVD2D0diEsbhTkgmIYigAfBQt+ywTf5uoBnDObiJCGzXp1LJoS5hyDtrvuK9Up7lIZWCvKIJtBHA/PkItCMYYdTGbBieKq8eJ2GgFUAaTJ8cKAB4AsATxXWhZNFVy02pr42FdN1wFr6UXJeIqhXDq40LxnbO/Bp1vOEciRAOSwOqBLamYM0oyd6akL5yKA+fAKM2SlR08Yhi+Z2Ghf42oGwiADBRRasJzpu3HR+2E/33gpBQCH1pxpJ8emLyU3WsAFC18+HVdScI5NpNQy9yPYan4DbWkJ135NOFkv2FmcvzmVQK8nCixJQFwFweu/unx4dijf0PJ8LqE+kxOJEQQoAo+Ep8s6GijhuSMFoBfbTy+YrJSepAAAAjvdbniYK7TIObswU49TUUKvniz45jf+K4ZYWBw9GEKZkAY+9qhGv3PFgT4k+kx+Akogj5gdjpuqKtaZm/mVOQ2AauMnpIvJXk5lDMVrQiSCYhWgFRt9B7qO8uewsi/v31cf7gcJad+hp1ltbOb9IPN7S2bxkqHNVUekM5q8NAl1ypU8R9K1Eq3Qce6RUvvnpXeCYA8IbD9ydHCpUsEy/+D0SHe8Tj7jriPSuo5D9AnO42fl3l+aik0VU77l9lLPcfIB7oJKdwL/FIr/jL9jtiTVVi75rQEfK1/Q7YQz3iKec+4v6VKAUp4r5O2TFxzMHgoBLiJAQ6wJlOa65hBFsYbEgJqTWlR3LWB0++znmDkzCmqvJHEQgAV/OQ7XegprFG/MEy+MyiBy9skVX0xIeblwTPHCpZOugGY31LeRurWN8VsjisGUxEcBy68uTrnDc4tdcxVaHqLN9jYKAcHTgFOfcGZIsl44tKU04KCAYzCV7Bd8DGNvARmUJVfTKd8nJ3neD+TnKDFHHfSvkDoKx6B5xbEcKxMg3+TZmXvi5zibtO8J5V5AYPCh7sNb5xKD4OKJlkEuKyGZDHC7ElYvP7GIAb0I6m4/TZ6/MIPlmK1yp2fs1CR5UCg8HRMMxsAU9MX6q+AQCDXaGPRGz/rrwLVwhIovLSMQOkAapYKFd9Nb3zPxEBYLACNAOSMK6zDEBrqNoY2TlHdDZd5f2MCJzulhsjtv6IG0BpFhnh1pxWd81Itoxv/6gwqWQ2JGHM70BwfZf12Wg4aBnJc1AbFUapRDfTpXC33wE7cUNuKN0ln21M6G+OZgFDAloxEhHRMtRppBqWBs825Z3nMiSc5lo+N1sEpKjobvUFqys44f3HBTRxafZxZVUBmSGg6JBvuvKhcWSa/iVQ9LzrMzfGuXmEc4uIcHslSu3nqyb1Aa0ox2WN4DqlmWNhktkS/em45ephTkKcOgyfGRSY6rtDI/SmFAhKHoKSRz7ArIS+jRlEN8A1bfHf8iVSnoJf9EiVPOjqVfCgi/tebvnZO+75+/yW53tSEIJA3FJ3jbsLSUhOQTYtDTYVXfwqEYaRd5hZ6+W8AiZaoTCJxu8ngGoWle60TpMCFxVcZsskMoX4aXUOdUBvbIecfhUKQsh/C5lkaA0CYGZL0LVRXJDpNb8MALVfCf5Ucum+RAgmay4bS2WhicumQyhf4PK98n96x31UfxlMBBWyYWSLtHNaPPgFJyHQXvb0DJBliNsCTXB8cMTi09OG8Q9EYE7t/777a0Br5Z7Ql8XCbEgByhWoLyjWPgYA6CgTmt+BIJWCrNvl3zOax/M1YUjWUARQyWVm6B8OpBDjJIRhmLfkHVGqi5MVC5GMh0nWhEnGI5UrRDJuT/gfIVkTgYyHScbCe8dX50RtMmvCQmgl/pXaUEJLOeujNigwUL8w+GPJoy0hA8IwwCC+HACwbX8N2N8HbKyoP+tLXQ8qapPMFfF483Xp/L4x9QqU09ihHnGjZv00EQOAcDwE9XE9e6RgfIM6gu8Dzpt7VoQ/YptqpqugVFAWskLZvJUGQYOlsfde9XkVxt2ABitAZAtwp1/jPc5L31mCq+4ZBlfRQ+EQn5srgRl8Ma+AieUIqhXq6nCqqs3GJGRrK4A0eCyTqPFC+Vejtm4CSBdc+eWmxX4KyUnifkUoA6vkutqY/tJIHooIwpDMRKKgYb/vt5FS/9Gs4x0MqvwMrTYuEKyfNqSWRVe6ljROr426uzePQOT2gOeXNZmNcYl0IEBHFc3YyFCvOd/1uMsw6IOGls8RfGZMsmnZBmYGjfYa3y66/mWmweFAA4GCrotxfKTgtbe1YdnWFKwWQL3bEhZQ2Qu0VFR+X7iizKNHwZ+FJ3yw2Gxosbhuqfu3yojxOePBJpWCvMiJLQlx8RMaQgbC/t2dCwo/v+KXiEyPGt1aJZY0LR3K7as+VaiGzXSXbK+N6WQmCyUFJAjaNklrCv193VeLLwLAQKf8QSJG548VERBBEmlmRlm0VA79XHZ4RDSexTE0QFIwAdCutXja8mLfwXZ8ySTEdbPNn2XS/i39RZTOnBP5hqFKF7KQjovw49OvyvUCAPEj0yOZofSDjbHgkoIvQcyIGBrDjvGigfDHnVzIdd20mjULHgCgDXpfIVRLZIMtiIi82GZKnuUGYGZwIgI5WqCnpi/THwdAwz3y0roafrRQYhjG+Py9x0cHWPUgAGI1hPQQHmpapC+fWIWeuKKoePodfTBOHYYaPDHSaJHzVG1In5FXBkwEsE0gXTAfasr6V4o96eGOxkhwyW3iGv/9s15WZ8/6q7pbfNWtDwXn5H339ubr0vkTbkSpclihJuORCLwREM1tyIPlv4YtEDNYCMhsCao2ho8Nr7Y+A4DrF6nHBkZovWFAjxXgZYtQuRJUzoHKFvdeucpV+R94Cv7ICMZI29cRgbFtEj5QNgtqg5p7A1zqQAD2/7M2os9Ihm5yW054VZ0z6y/BOv6M3xT1P99XE7mJciuR2Rpvqbvg5K0EKjtFqTU/v2Muzynt9Eqm9WsDShOBTSkIhv3dxJW57ZNVXaoV2nSX+GM0zPPyTjn5iIRAJY9eborqc7ENQfZ0aw6C4KVAsVRc5R2V7ABEBAnam/FpDdVQQ3I4Rx3NS1R71eTG6VZ4GVsbPw3kfc/zFUMKBFoYMc/57IZEq/jHkzcIaAACiPt5/dLOk1AfDL9lmIy6nfJEAQFEgxIAQsEI0U7jJDqTXg8lGvQV4IqmhRiZAb0SwHa0TL6PIAIPr7a+pbT3NJWVUhQcqMY4nzGYM5Y1dwR3At72wW55Z1MTbnTyDEPuTYqDAMg5mKhnOmxDjBawG3H1k/Gkp2MC0QovXuAd3zg9aINfdSoG1ACwwzoNABBXRQTaQE7GxNs0DdP8TINRgNh9gbdp1jR3AIOhZgEAs4t/0xf4mzlPYmxsyGgXmgMhwKYlBZf4ZQDj3vYdL1/ZnlKb80z/KvE/6+O4fKQIJQSo4EJLyd99c1XNullvZUdHKfaDsZHCrkCDBCQgWPhKs2SaZcrgW14AJiqbUtgi4St5S3Obzm9IwphP++T0FV4KnvxrZAjXOoFizZKUFlaY6fvzC09FYkGBcmZUQABnZbeoM9VOKkLuoj3d4WunR0t3vqBO13clrtcSAb4+fDvOiewy+kas9hlLvY59X/RgwAwBAmfWWnMtBC/5ik2tiZhZNcRhDBfFj6ctVDcdyIP3d8pf1sX010fL+QSiYch8SWye9qY6H+1ApSQ/ZRjosW+bVuN+88ni3wVrGpcjHozhhqHbjLn2APoKkasIAPp6zB82GP63TVE+sVcMZIrG6uOWBgsHu0Mftmx7a2L7WA6tAFqhDlVsrCYj/Z3yjoa4/ueRPAIQpBRgInKJzJba19030AID26B31EOeehbU8G7j/JDUfyh6rFmDGOBYmETRMz/atNDdcKjqDjMIGytJYxpmthSfVXNVbke6x0w12f4XIQAw4DH8EddqP26x9+9UXYldPYlzopb+iGYYpPFs81W5P+652zgvHOZfa2We37DY2T3VSmuyUu1dfkKsIWSU/iqErvc8kGbo+hjkaEHeN21J8JXqC1Wd2ECX+F1NmC/KlaAYQG0McjRPv2peoj831XPAajTlHoQyWj5bdMXS2df6m4dTdR9ynGCeNMlRgfHbGQuG/zp+5D7Z2Xt/l3nNcA8New8QD62xP1Vd2UMxUIVqFSbTbdwQrBfc30nBYDfxYDepsTWk0t3G31dwWgAw0CkvL91HPNhFwWA36UwvqbE10hlba53GXGm0mAJUx6V7rNNHVxMP9YrhPZ3GtfuN4/K48bo8JyF4A4ytKVicgpSkrrdNrgsCsA6CTwKYdDd1IGjtKK9sQy64eziLV6IhCGZo1mDLgNCsbwWAjdug+TewBfGPlIauhGJVGyFRdMXdiQXeq9X+oimSFgwQVPBR24Q2JNcZktt5BSK8AcamFTB57/HeXqlSBzTNR9DSBE1tUMQiJQWx4zNp5ks3rYBZ3QpPBQhgtJSLIsTGTaYgquzlZa4EFQ9jfrrbumx+BwKUfcRWU0IAULYJMVakTFTbP+AkxGQR5yCgCWANfD5QEKYBTRq/ouUoIg0+bzn8icLcT63Wp8s2rokeK3mAF0BHLMw9xbY/BD48M6iGxaal3iNjBTyZiEAyQzFASjODgx9tTcKiNigLxk0lD64gIGKTUEzfr1mez2wExFRPeKpl/IFV9hwpcVHBBYNJMPCrA83ZTwBtbVDJJETTIn+Lr2lzxCISxHB8//ojOWpaX/k1hfwXL6BACBABouBA18bQ0jzbWAoAicXeDt8XdzXUwhwr0F+aosHdnIRoPQyt21huRGESwdJ4iC1DArkS3vID9dvyy+2vSZM6lvaK1AXh7pBFlC2yCpt82XCXeTbaoA9HC9oqWlC/xH+p5FF3bQRCM5SQoILDTMS3DK+oS3ASwlPqh/miyCktv0dt8NBy0P3RO4AZ1NoONbY63iCIl44VWdeEQQLUO3M5ipyEMRmuyT1rOxQzyJdN948V8GbIIrJMGB7UfxDAGw/DGQIYrxlEpZ0cK9KobYLARG4AlYjo6b6ZvZE6oGcuR2YkZ36mKLxHGftUeg4F7ZBE4KJbvDke4gYwOFeiHNi6iwFqn6yWcTCohrHBTnOZv464v5Nc537BA13WFyc+nypUtSbdadwUpCphsYv0cC+pkdUim18bmX6kp0qpCu6+XrNlZLVw+lfB9+8n7u+U/z6R9mRwQIIMEJIgACJ9vHghEuKzfQ2tmYYCDp09bVFxAMmp9/RWawa7W2CHC2KrbfBJjl+uGdRGIUfzomvaErUMK2FgOYIpq361nAfo9Czxh5DN85SG0or6ydctdXuQQzv4QP7rgMnFeBjrQCAM8TUNgh9ARWyeRnDuBQNoAU111YjK+E5oQ4lZfidkEnE5LMIPwER8PtZD4JqpvzwAYEV5a9w/U/4kEeF5RRduJCRkoI0b6pdjrFoxnjK+faGqPn2rZLt6gLhvJZW8+4nTveaK6vPDUd0qvsFO8XRpHfFAN3nFewUPdlmXTHw+JVwrYALAQKdxrXOf4P5VKAUPEPd3yZ7DxXVgIgBVEQ10isf8dcQDnVT0HxCc7jFvB8rqPeVUtXro2mPMG1srg+J9pAe6xGPA5Cn5pDjK9Mo+qkssya8VnO4q9y1kusQWXoFI6jAXZioERWZtfc1wr9jslIVQ8lOCh1bL7qpDnGqXyLhD7JLr+EHBY2ut0xigan4+lbnl+eK/F+4RPNhF7tga4pFeuXtPZ2g2MHVhTmlQ1YYaFwxn3aK+xPXopdoYQkNZduK2XnTWyfKp/i77ZJqPgJMQh1S9Slg0DPHj9Cj9R2KB9yqSoIPt9at4qQ1q188StUM9cm08wrfmHPbCFltaU382Lz41Y+l438KUnPNhqUi1Be3tFbHGaLj0UDysP5QZgxOLIORpMaR8cVPjIr+ryjBaQO+mi3NilbeaEwz12J8SRnBH2NBzRwtw6qIIlTyxYyQvP3vS172XD7d99rBtpLp339UzO1RHb98dC+urR4qsmUE1EaKiJzYQye/VLXA3js9JQW7cBmoFNDrKB56cgswUzSVCUA1TbGXjguFsMgnRDgAtoI3bQBMLn0NrzDOF0t82DP6yrxl+gKCxhoxsUTwx7NkLTllWGDiS3uEja5WdUBEe6jWWW5JvNU2dGCvAD9swGQQViCeZxcr6uvjj9Lmh3H44emaHBvRb6aYExTJ5Oad5ofv6fmNWfMDMmFs/bIhgiQa+GDa1lS0hiIVhKC0CHeCHtYtUBwF8uA2S70oAwN5OTmqDGuy2TrVN/SNT6su1ZuRd6IgNIYlQ8rAbLH6nmJ4IG/SCI4zRJrs4uCM2x0j07XyFCMcH2pozvcZ5qz8TbQjHgho34LMMoT7KGh8zDT7dEIycAw5bINskuL7Y6Pu4uXFJ8DwzqL0d1HGETZlHtV1+dI28WAj6FrO+2DIYBbdMIGSicgpHyHvmzc0LnVsfSU6PnDd76HVD8HEZL3TaGdfktg+sMq+OhHUnERsEhhcASgNhCyhrFV4QQv4kvsBP7Uv7SOHofDCxT8dn9h7jQma+mpk/bRqYATDCFpDJih9PW6xuervb/mSN5d1qFflMEMgP0a6sb39/xmJndd9KcX1DDf/cV+UeIcfHMBE9IYRcnfiq9zhQjiBH69O6o/vJzD69+5yqS2RLhQvJUB93fTqh8ergioE1oXkx4T6thSHXW59lBYkvlB6metvFgBP60vSrnQcy3cZK02Rolv9lGOYz8S8XBibSOBonzO8ppFLlfp3Jng10GU8V77e59cknXGxixibmC578vT90T0RnuuVru3pmh/adw3vxHfUexPe0qXG85X0EAnugnpn7ocQHSs+8tjHx4bpLZ/8eIeUTwHAMCw/uvBifzj3Ju+3jzjz1tf5XABhogXo3ecRU4D1tZKwwrpjLL/HcWk9pQEd1sXxAQSao0g0Q1kVogKUWQaVKHdAkJayjDcfk09lKh5act+BP2YIw/3gR/g8ty/zCB2loIiwY6gouVs9Tjo2/nBy+8PXkEX7+ckS8HQsiQCVStIP39FqnxaTaWCNV8/N8KpgEztOvwmNRHPOsS2YsdX7//4WjOxKohsv+7uj7h9eYT5R6UXRWwxm9x3xu9yq7deKYYwX/F9ciK8X/cwNRAAAAAElFTkSuQmCC',
      chains: ['solana:mainnet', 'solana:devnet'],
      features: {
        'standard:connect': {version:'1.0.0', connect:function(input){ return solana.connect(input || {}).then(function(r){ var pk = r && r.publicKey; var addr = pk && (typeof pk.toBase58 === 'function' ? pk.toBase58() : String(pk)); var account = {address: addr || '', publicKey: pk && typeof pk.toBytes === 'function' ? pk.toBytes() : new Uint8Array(), chains:['solana:mainnet','solana:devnet'], features:['standard:connect','standard:disconnect','standard:events','solana:signMessage','solana:signTransaction']}; sentinelSolanaWalletStandard.accounts = account.address ? [account] : []; return {accounts: sentinelSolanaWalletStandard.accounts}; }); }},
        'standard:disconnect': {version:'1.0.0', disconnect:function(){ return solana.disconnect(); }},
        'standard:events': {version:'1.0.0', on:function(name, fn){ return solana.on(name, fn); }},
        'solana:signMessage': {version:'1.0.0', signMessage:function(input){ return solana.signMessage(input && (input.message || input), input && input.encoding); }},
        'solana:signTransaction': {version:'1.0.0', signTransaction:function(input){ return solana.signTransaction(input && (input.transaction || input)); }}
      },
      accounts: []
    };
    if (!window.sentinelSolanaWalletStandard) Object.defineProperty(window, 'sentinelSolanaWalletStandard', {value: sentinelSolanaWalletStandard, configurable:true});
    window.dispatchEvent(new CustomEvent('wallet-standard:register-wallet', {detail: sentinelSolanaWalletStandard}));
  } catch(e){}
  window.dispatchEvent(new Event('ethereum#initialized'));
  window.dispatchEvent(new Event('sentinelEthereum#initialized'));
  window.dispatchEvent(new Event('phantom#initialized'));
  window.dispatchEvent(new Event('solana#initialized'));
  window.dispatchEvent(new Event('sentinelSolana#initialized'));
  window.dispatchEvent(new Event('sentinelBitcoin#initialized'));
})();
'''
            script = W.UserScript.new(js, W.UserContentInjectedFrames.ALL_FRAMES, W.UserScriptInjectionTime.START, None, None)
            manager.add_script(script)
        except Exception as exc:
            log_security_event("blockchain_provider_bridge_install_failed", {"error": str(exc)})

    def install_homepage_bridge(self, w: Any) -> None:
        try:
            manager = w.get_user_content_manager()
            if not manager:
                return
            try:
                manager.register_script_message_handler("sentinelHome")
            except Exception:
                pass
            try:
                manager.connect("script-message-received::sentinelHome", self.on_homepage_script_message)
            except Exception as exc:
                log_security_event("homepage_bridge_signal_unavailable", {"error": str(exc)})
            W = self.WebKit2
            script = W.UserScript.new(
                homepage_bootstrap_script(),
                W.UserContentInjectedFrames.ALL_FRAMES,
                W.UserScriptInjectionTime.START,
                None,
                None,
            )
            manager.add_script(script)
        except Exception as exc:
            log_security_event("homepage_bridge_install_failed", {"error": str(exc)})

    def install_privacy_user_scripts(self, w: Any) -> None:
        """Best-effort page-side restrictions for common fingerprint/miner surfaces.

        This is intentionally local and transparent. It does not send page content
        anywhere; it only installs defensive hooks in the WebKit view where supported.
        """
        if not self.config.get("fingerprint_defense_enabled", True):
            return
        try:
            manager = w.get_user_content_manager()
            if not manager:
                return
            js = r"""
(function(){
  'use strict';
  try {
    const sentinelBlank = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/p9sAAAAASUVORK5CYII=';
    if (window.HTMLCanvasElement && HTMLCanvasElement.prototype) {
      const originalToDataURL = HTMLCanvasElement.prototype.toDataURL;
      HTMLCanvasElement.prototype.toDataURL = function(){ return sentinelBlank; };
      const originalToBlob = HTMLCanvasElement.prototype.toBlob;
      HTMLCanvasElement.prototype.toBlob = function(callback){ try { fetch(sentinelBlank).then(r=>r.blob()).then(callback); } catch(e) { return originalToBlob.apply(this, arguments); } };
    }
    if (window.CanvasRenderingContext2D && CanvasRenderingContext2D.prototype) {
      const originalGetImageData = CanvasRenderingContext2D.prototype.getImageData;
      CanvasRenderingContext2D.prototype.getImageData = function(x,y,w,h){
        const data = originalGetImageData.apply(this, arguments);
        for (let i=0;i<data.data.length;i+=16) { data.data[i] = data.data[i] ^ 1; }
        return data;
      };
    }
    if (navigator.mediaDevices && navigator.mediaDevices.enumerateDevices) {
      navigator.mediaDevices.enumerateDevices = function(){ return Promise.resolve([]); };
    }
    ['CoinHive','CryptoLoot','WebMinePool','JSECoin','CoinImp'].forEach(function(name){
      try { Object.defineProperty(window, name, { value: undefined, configurable: false, writable: false }); } catch(e) {}
    });
    window.__sentinelBrowserFingerprintDefense = true;
  } catch(e) {}
})();
"""
            W = self.WebKit2
            script = W.UserScript.new(
                js,
                W.UserContentInjectedFrames.ALL_FRAMES,
                W.UserScriptInjectionTime.START,
                None,
                None,
            )
            manager.add_script(script)
        except Exception as exc:
            log_security_event("fingerprint_user_script_unavailable", {"error": str(exc)})

    def create_webview(self) -> Any:
        W = self.WebKit2
        try:
            w = W.WebView.new_with_context(self.web_context)
        except Exception:
            w = W.WebView.new()
        s = w.get_settings()
        safe_set(s, "enable-javascript", bool(self.config.get("enable_javascript", True)))
        safe_set(s, "enable-developer-extras", bool(self.config.get("enable_developer_extras", False)))
        safe_set(s, "allow-file-access-from-file-urls", bool(self.config.get("allow_file_access_from_file_urls", False)))
        if self.config.get("disable_hyperlink_auditing", True):
            safe_set(s, "enable-hyperlink-auditing", False)
        if self.config.get("disable_dns_prefetching", True):
            safe_set(s, "enable-dns-prefetching", False)
        if self.config.get("disable_webrtc_media_capture", True):
            safe_set(s, "enable-media-stream", False)
        if self.config.get("disable_webgl_by_default", True):
            safe_set(s, "enable-webgl", False)
        try:
            w.set_zoom_level(float(self.config.get("default_zoom", 1.0)))
        except Exception:
            pass
        self.install_homepage_bridge(w)
        self.install_blockchain_provider_bridge(w)
        self.install_privacy_user_scripts(w)
        w.connect("load-changed", self.on_load)
        w.connect("notify::title", self.on_title)
        w.connect("notify::uri", self.on_uri)
        w.connect("decide-policy", self.on_policy)
        w.connect("load-failed", self.on_load_failed)
        try:
            w.connect("permission-request", self.on_permission_request)
        except Exception:
            pass
        try:
            w.connect("load-failed-with-tls-errors", self.on_tls_failed)
        except Exception:
            pass
        try:
            w.connect("download-started", self.on_download_started)
        except Exception:
            pass
        try:
            w.connect("context-menu", self.on_web_context_menu)
        except Exception as exc:
            log_security_event("web_context_menu_signal_unavailable", {"error": str(exc)})
        try:
            w.connect("mouse-target-changed", self.on_mouse_target_changed)
        except Exception as exc:
            log_security_event("hover_link_preview_signal_unavailable", {"error": str(exc)})
        return w

    def create_tab(self, url: str = "about:blank", switch: bool = True) -> None:
        Gtk = self.Gtk
        w = self.create_webview()
        box = Gtk.EventBox()
        inner = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=2)
        lab = Gtk.Label(label="New Tab")
        close = Gtk.Button(label="×")
        # RC20 safe tab slimming: reduce close hitbox slightly without adding new CSS/rendering classes.
        try:
            close.set_size_request(18, 16)
        except Exception:
            pass
        close.set_relief(Gtk.ReliefStyle.NONE)
        close.set_focus_on_click(False)
        inner.pack_start(lab, True, True, 0)
        inner.pack_start(close, False, False, 0)
        box.add(inner)
        box.set_tooltip_text("Right-click tab for New / Reload / Duplicate / Rename / Close")
        box.connect("button-press-event", lambda widget, event, view=w, label=lab: self.tab_context_menu(widget, event, view, label))
        box.show_all()
        self.tabs.append({"webview": w, "label": lab})
        idx = self.nb.append_page(w, box)
        close.connect("clicked", lambda *_: self.close_tab(w))
        w.show_all()
        if switch:
            self.nb.set_current_page(idx)
        self.load(url, w)

    def close_tab(self, w: Any = None) -> None:
        cur = self.current()
        target = w or (cur and cur["webview"])
        if not target:
            return
        if len(self.tabs) <= 1:
            self.quit()
            return
        for i, tab in enumerate(self.tabs):
            if tab["webview"] == target:
                self.tabs.pop(i)
                self.nb.remove_page(i)
                break
        self.update_nav()


    def apply_javascript_policy_to_webview(self, w: Any, target: str) -> Dict[str, Any]:
        decision = effective_javascript_policy(target, self.config, load_javascript_policy())
        try:
            safe_set(w.get_settings(), "enable-javascript", bool(decision.get("enabled", True)))
        except Exception as exc:
            log_security_event("javascript_policy_apply_failed", {"target": target, "error": str(exc)})
        if not decision.get("enabled", True):
            log_security_event("javascript_disabled_for_page", {"target": target, "decision": decision})
        return decision

    def load(self, url: str, w: Any = None) -> None:
        w = w or (self.current() and self.current()["webview"])
        if not w:
            return
        raw_target = (url or "").strip()
        if raw_target.startswith("wc:") or raw_target.startswith("walletconnect:"):
            self.handle_walletconnect_uri(raw_target, "address-load")
            return
        target = normalize_url(url, self.config.get("search_url", DEFAULT_CONFIG["search_url"]))
        # HTTPS-first default: safe address-entry/load upgrade only.
        # Do not hook WebKit policy recursion before v1; that caused rendering/startup risk in rejected branches.
        if self.config.get("enforce_https_upgrade_attempt", True) and target.startswith("http://"):
            target = "https://" + target[len("http://"):]
            log_security_event("https_first_safe_load_upgrade", {"target": target})
        state = security_state_for_uri(target)
        if state["state"] == "insecure" and self.config.get("warn_insecure_http", False):
            if not self.confirm("Plain HTTP page", f"This page is not encrypted. Continue?\n\n{target}"):
                return
        content_decision = classify_content_uri(target, self.config, load_content_policy())
        if content_decision.get("action") == "block":
            log_security_event("content_navigation_blocked", content_decision)
            self.update_security_indicator(target)
            self.set_status("Blocked by Sentinel content policy: " + content_decision.get("category", "content"))
            try:
                self.confirm("Blocked by Sentinel content policy", f"Sentinel Browser blocked this navigation.\n\nCategory: {content_decision.get('category')}\nReason: {content_decision.get('reason')}\n\n{target}")
            except Exception:
                pass
            return
        self.address.set_text(target)
        self.update_security_indicator(target)
        if target == "sentinel://wallet":
            self.open_sentinel_wallet_ui()
            return
        if target in {"about:sentinel-home", "sentinel://home"} and self.config.get("sentinel_home_page_enabled", True):
            try:
                homepage_path = Path(str(self.config.get("sentinel_home_packaged_html_path") or HOMEPAGE_FILE))
                if self.config.get("sentinel_home_packaged_html_enabled", True) and homepage_path.exists() and homepage_path.is_file():
                    # v1.0.7: load a Browser-owned runtime homepage file with the saved
                    # weather city embedded before the homepage weather widget initialises.
                    # This fixes the live case where the city was saved but the widget still
                    # rendered the Melbourne fallback at startup.
                    runtime_homepage = render_runtime_homepage_file(self.config)
                    w.load_uri(runtime_homepage.as_uri())
                else:
                    w.load_html(sentinel_home_page_html(self.config), HOMEPAGE_FILE.parent.as_uri() + "/")
                self.set_status("Sentinel local home")
                return
            except Exception as exc:
                log_security_event("sentinel_home_page_render_failed", {"error": str(exc)})
        js_decision = self.apply_javascript_policy_to_webview(w, target)
        js_label = "JS on" if js_decision.get("enabled", True) else "JS off"
        self.set_status("Loading " + target + " | " + js_label + " | " + str(js_decision.get("profile", "standard")))
        w.load_uri(target)

    def go_back(self) -> None:
        w = self.current() and self.current()["webview"]
        if w and w.can_go_back():
            w.go_back()

    def go_fwd(self) -> None:
        w = self.current() and self.current()["webview"]
        if w and w.can_go_forward():
            w.go_forward()

    def reload(self) -> None:
        w = self.current() and self.current()["webview"]
        if w:
            w.reload()

    def stop(self) -> None:
        w = self.current() and self.current()["webview"]
        if w:
            w.stop_loading()

    def bookmark(self, default_folder: str = "") -> None:
        w = self.current() and self.current()["webview"]
        if not w:
            return
        url = w.get_uri() or "about:blank"
        title = w.get_title() or url
        result = self.bookmark_editor_dialog(title, url, "Save Bookmark", default_folder)
        if not result:
            self.set_status("Bookmark save cancelled")
            return
        self.add_or_update_bookmark_record(result["title"], result["url"], folder=result.get("folder", ""))
        suffix = f" in {result.get('folder')}" if result.get("folder") else ""
        self.set_status("Bookmarked" + suffix + ": " + result["title"][:60])

    def update_security_indicator(self, uri: str) -> None:
        state = security_state_for_uri(uri)
        self.security_label.set_text(state["label"])
        self.security_label.set_tooltip_text(state["detail"])
        try:
            if self.config.get("https_indicator_inside_address_bar", True):
                icon = "security-high-symbolic" if state.get("state") == "secure" else ("security-medium-symbolic" if state.get("state") == "local" else "dialog-warning-symbolic")
                self.address.set_icon_from_icon_name(self.Gtk.EntryIconPosition.PRIMARY, icon)
                self.address.set_icon_tooltip_text(self.Gtk.EntryIconPosition.PRIMARY, state.get("label", "") + " — " + state.get("detail", ""))
        except Exception:
            pass

    def on_load(self, w: Any, event: Any) -> None:
        try:
            if event == self.WebKit2.LoadEvent.FINISHED:
                uri = w.get_uri() or ""
                if self.config.get("vault_login_prompt_enabled", True):
                    self.detect_login_form_finished(w, uri)
                self.inject_account_hint_dropdown(w, uri)
                self.set_status("Done")
            elif event == self.WebKit2.LoadEvent.STARTED:
                self.hide_vault_login_prompt("")
                self.set_status("Loading")
        except Exception:
            pass
        self.update_nav()
        self.update_security_indicator(w.get_uri() or "about:blank")

    def on_title(self, w: Any, *_: Any) -> None:
        title = w.get_title() or "New Tab"
        short = title if len(title) <= 28 else title[:25] + "..."
        for tab in self.tabs:
            if tab["webview"] == w:
                tab["label"].set_text(short)
                break

    def on_uri(self, w: Any, *_: Any) -> None:
        cur = self.current()
        uri = w.get_uri() or ""
        if cur and cur["webview"] == w:
            self.address.set_text(uri)
            self.update_security_indicator(uri)
        self.update_nav()

    def on_switch(self) -> None:
        cur = self.current()
        if cur:
            uri = cur["webview"].get_uri() or ""
            self.address.set_text(uri)
            self.update_security_indicator(uri)
        self.update_nav()

    def on_load_failed(self, w: Any, event: Any, uri: str, error: Any) -> bool:
        self.set_status(f"Load failed: {uri} — {error}")
        return False

    def on_tls_failed(self, w: Any, uri: str, certificate: Any, errors: Any) -> bool:
        detail = {"uri": uri, "errors": str(errors)}
        log_security_event("tls_error_blocked", detail)
        self.set_status(f"TLS/certificate error blocked: {uri}")
        if self.config.get("block_tls_errors", True):
            self.update_security_indicator(uri)
            return True
        return False

    def confirm(self, title: str, msg: str) -> bool:
        dialog = self.Gtk.MessageDialog(transient_for=self.window, flags=0, message_type=self.Gtk.MessageType.WARNING, buttons=self.Gtk.ButtonsType.OK_CANCEL, text=title)
        dialog.format_secondary_text(msg)
        response = dialog.run()
        dialog.destroy()
        return response == self.Gtk.ResponseType.OK


    def confirm_dangerous_download(self, info: Dict[str, Any], uri: str = "") -> bool:
        filename = info.get("filename", "download")
        ext = info.get("extension", "") or "unknown"
        explanation = info.get("risk_explanation") or download_risk_explanation(str(ext))
        message = (
            f"Sentinel Browser has classified this as a potentially dangerous download.\n\n"
            f"File: {filename}\n"
            f"Type: {ext}\n\n"
            f"Why this matters:\n{explanation}\n\n"
            "Only continue if you deliberately trust the source. "
            "Choose Abandon Download to cancel, or Download Anyway to proceed."
        )
        dialog = self.Gtk.MessageDialog(
            transient_for=self.window,
            flags=0,
            message_type=self.Gtk.MessageType.WARNING,
            buttons=self.Gtk.ButtonsType.NONE,
            text="Potentially dangerous download",
        )
        dialog.format_secondary_text(message)
        dialog.add_button("Abandon Download", self.Gtk.ResponseType.CANCEL)
        dialog.add_button("Download Anyway", self.Gtk.ResponseType.OK)
        response = dialog.run()
        dialog.destroy()
        approved = response == self.Gtk.ResponseType.OK
        log_security_event(
            "dangerous_download_user_choice",
            {"uri": uri, "filename": filename, "extension": ext, "approved": approved, "classification": info},
        )
        return approved


    def show_control_panel(self) -> None:
        """Open editable Security controls.

        RC20 changes this from a read-only status popup into user-editable
        checkbox selections inside Preferences → Security.
        """
        try:
            self.show_preferences_dialog()
            self.set_status("Security controls opened — use the Security tab checkboxes")
        except Exception as exc:
            log_crash(exc)
            self.info_dialog("Security / Privacy Controls", "Open Preferences → Security to edit camera, microphone, location, notifications, popups, TLS, download, and JavaScript controls.\n\n" + str(exc))

    def on_permission_request(self, w: Any, request: Any) -> bool:
        permission = classify_permission_request(request)
        action = permission_default_action(permission, self.config, load_permission_policy())
        log_security_event("site_permission_request", {"permission": permission, "action": action, "request_type": type(request).__name__})
        if action == "allow":
            try:
                request.allow()
            except Exception:
                pass
            self.set_status(f"Permission allowed by policy: {permission}")
            return True
        if action == "ask":
            if self.confirm("Site permission request", f"A website is requesting permission: {permission}\n\nAllow this request?"):
                try:
                    request.allow()
                except Exception:
                    pass
                log_security_event("site_permission_user_allowed", {"permission": permission})
                self.set_status(f"Permission allowed once: {permission}")
                return True
        try:
            request.deny()
        except Exception:
            pass
        log_security_event("site_permission_denied", {"permission": permission, "action": action})
        self.set_status(f"Permission denied: {permission}")
        return True

    def on_policy(self, w: Any, decision: Any, decision_type: Any) -> bool:
        try:
            req = decision.get_navigation_action().get_request() if hasattr(decision, "get_navigation_action") else None
            uri = req.get_uri() if req and hasattr(req, "get_uri") else ""
            if uri and (uri.startswith("wc:") or uri.startswith("walletconnect:")):
                self.handle_walletconnect_uri(uri, "navigation-policy")
                try:
                    decision.ignore()
                except Exception:
                    pass
                return True
        except Exception:
            pass
        try:
            if decision_type == self.WebKit2.PolicyDecisionType.NAVIGATION_ACTION:
                try:
                    nav = decision.get_navigation_action()
                    req = nav.get_request() if nav else None
                    uri = req.get_uri() if req else ""
                    content_decision = classify_content_uri(uri, self.config, load_content_policy())
                    if content_decision.get("action") == "block":
                        decision.ignore()
                        log_security_event("content_policy_blocked", content_decision)
                        self.set_status("Blocked by Sentinel content policy: " + content_decision.get("category", "content"))
                        return True
                except Exception:
                    pass
                uri = decision.get_navigation_action().get_request().get_uri()
                if self.handle_downloads_internal_uri(uri):
                    decision.ignore()
                    return True
                if self.handle_wallet_internal_uri(uri):
                    decision.ignore()
                    return True
                if self.config.get("warn_external_protocols", True) and is_external_protocol(uri):
                    log_security_event("external_protocol_attempt", {"uri": uri})
                    if not self.confirm("External protocol", f"Open external protocol?\n\n{uri}"):
                        decision.ignore()
                        return True
            try:
                if hasattr(self.WebKit2.PolicyDecisionType, "NEW_WINDOW_ACTION") and decision_type == self.WebKit2.PolicyDecisionType.NEW_WINDOW_ACTION:
                    action = permission_default_action("popups", self.config, load_permission_policy())
                    log_security_event("popup_request", {"action": action})
                    if action == "block" or (action == "ask" and not self.confirm("Popup / new window", "A site wants to open a new window. Allow it?")):
                        decision.ignore()
                        self.set_status("Popup/new window blocked")
                        log_security_event("popup_blocked", {"action": action})
                        return True
            except Exception:
                pass
            if decision_type == self.WebKit2.PolicyDecisionType.RESPONSE and self.config.get("warn_downloads", True):
                try:
                    if hasattr(decision, "is_mime_type_supported") and not decision.is_mime_type_supported():
                        uri = decision.get_request().get_uri()
                        info = classify_download_uri(uri, self.config)
                        log_security_event("download_prompt", {"uri": uri, "classification": info, "modal_permission_prompt": bool(self.config.get("download_guard_modal_permission_prompt_enabled", False))})
                        self.begin_pending_download_indicator(uri, info)

                        # v0.10.9: Firefox-style DLG flow.
                        # Do not open a blocking Accept/Decline modal before the browser hands the file into DLG quarantine.
                        # The user decision point is the DLG button/current-downloads review page, before release to ~/Downloads.
                        if not self.config.get("download_guard_modal_permission_prompt_enabled", False):
                            if info.get("blocked"):
                                decision.ignore()
                                self.fail_pending_download_indicator(uri, "Download blocked by Sentinel policy")
                                self.set_download_icon_state("idle")
                                self.set_status("Blocked risky download: " + info.get("filename", "download"))
                                log_security_event("download_blocked_no_modal", {"uri": uri, "classification": info})
                                return True
                            self.set_download_icon_state("active", info.get("filename", "download") + " starting")
                            self.set_status("Downloading: " + info.get("filename", "download"))
                            log_security_event("download_auto_quarantine_no_modal", {"uri": uri, "classification": info})
                            decision.download()
                            return True

                        # Legacy opt-in modal path retained for users who explicitly re-enable it.
                        if info.get("dangerous") and self.config.get("confirm_dangerous_downloads", True):
                            if self.confirm_dangerous_download(info, uri):
                                self.approved_dangerous_downloads.add(uri)
                                self.set_download_icon_state("active", info.get("filename", "download") + " starting")
                                self.set_status("Downloading: " + info.get("filename", "download"))
                                decision.download()
                            else:
                                decision.ignore()
                                self.fail_pending_download_indicator(uri, "Dangerous download abandoned")
                                self.set_status("Dangerous download abandoned: " + info.get("filename", "download"))
                            return True
                        if self.confirm("Download file", f"A file download is being requested. Continue?\n\n{uri}"):
                            self.set_download_icon_state("active", info.get("filename", "download") + " starting")
                            self.set_status("Downloading: " + info.get("filename", "download"))
                            decision.download()
                        else:
                            decision.ignore()
                            self.fail_pending_download_indicator(uri, "Download cancelled")
                        return True
                except Exception:
                    pass
        except Exception as exc:
            log_crash(exc)
        return False



    def begin_pending_download_indicator(self, uri: str, info: Dict[str, Any]) -> str:
        filename = info.get("filename", "download")
        existing = self.pending_downloads_by_uri.get(uri or "")
        if existing:
            did = existing.get("download_id", "")
        else:
            did = "sb-pending-" + secrets.token_hex(8)
            self.pending_downloads_by_uri[uri or ""] = {
                "download_id": did,
                "filename": filename,
                "uri": uri or "",
                "created_at": datetime.now(timezone.utc).isoformat(),
            }
        log_security_event("pending_download_indicator_browser_only", {"uri": uri, "filename": filename, "download_id": did})
        self.set_download_icon_state("active", filename + " pending")
        self.set_status("Download pending: " + filename)
        self.refresh_downloads_page_if_open()
        log_security_event("pending_download_indicator_started", {"uri": uri, "filename": filename, "download_id": did})
        return did

    def fail_pending_download_indicator(self, uri: str, message: str = "Download cancelled") -> None:
        rec = self.pending_downloads_by_uri.pop(uri or "", None)
        if not rec:
            return
        self.set_download_icon_state("idle")
        self.set_status(message + ": " + str(rec.get("filename", "download")))
        self.refresh_downloads_page_if_open()
        log_security_event("pending_download_indicator_failed", {"uri": uri, "download_id": rec.get("download_id"), "message": message})


    def start_download_progress_timer(self, download: Any) -> None:
        ctx = self.download_context.setdefault(id(download), {})
        if ctx.get("progress_timer_id"):
            return
        interval = int(self.config.get("download_guard_progress_ui_only_interval_ms", 700) or 700)
        try:
            timer_id = self.GLib.timeout_add(max(250, interval), self.poll_download_progress, download)
            ctx["progress_timer_id"] = timer_id
            log_security_event("download_progress_timer_started", {"download_id": ctx.get("download_id"), "interval_ms": interval})
        except Exception as exc:
            log_security_event("download_progress_timer_start_failed", {"error": str(exc)})

    def stop_download_progress_timer(self, download: Any) -> None:
        ctx = self.download_context.get(id(download), {})
        timer_id = ctx.get("progress_timer_id")
        if timer_id:
            try:
                self.GLib.source_remove(timer_id)
            except Exception:
                pass
            ctx["progress_timer_id"] = None

    def poll_download_progress(self, download: Any) -> bool:
        try:
            ctx = self.download_context.get(id(download), {})
            did = ctx.get("download_id")
            if not did:
                return False
            progress = 0.0
            try:
                progress = float(download.get_estimated_progress() or 0.0) * 100.0
            except Exception:
                progress = float(ctx.get("last_progress", 0.0) or 0.0)
            progress = max(0.0, min(100.0, progress))
            ctx["last_progress"] = progress
            filename = ctx.get("filename", "download")
            # Browser-first UX: progress updates stay inside the Browser UI.
            # No Download Guard subprocess calls are made during active transfer.
            self.set_download_icon_state("active", f"{filename} {progress:.0f}%")
            self.set_status(f"Downloading: {filename} — {progress:.0f}%")
            # v0.10.10: do not repeatedly reload the Downloads page from a GTK timeout.
            # The DLG button opens the current state on demand.
            return True
        except Exception as exc:
            log_security_event("download_progress_poll_failed", {"error": str(exc)})
            return False

    def refresh_downloads_page_if_open(self) -> None:
        if not self.config.get("downloads_page_live_refresh_enabled", True):
            return
        try:
            cur = self.current()
            if not cur or cur.get("is_downloads_page") is not True:
                return
            self.render_downloads_page(cur["webview"], reload_uri=False)
        except Exception as exc:
            log_security_event("downloads_page_live_refresh_failed", {"error": str(exc)})

    def render_downloads_page(self, webview: Any, reload_uri: bool = True) -> None:
        st = download_status_json(False)
        st["browser_active_downloads"] = self.browser_active_downloads_snapshot()
        guard = st.get("download_guard_backend", {})
        html_text = downloads_page_html(st, guard)
        page_dir = DATA_DIR / "internal_pages"
        page_dir.mkdir(parents=True, exist_ok=True)
        page_file = page_dir / "sentinel-downloads.html"
        page_file.write_text(html_text, encoding="utf-8")
        if reload_uri:
            webview.load_uri(page_file.as_uri())
        else:
            try:
                webview.load_html(html_text, page_file.parent.as_uri())
            except Exception:
                webview.load_uri(page_file.as_uri())


    def ensure_download_id(self, download: Any, filename: str = "download", source_url: str = "") -> str:
        ctx = self.download_context.setdefault(id(download), {})
        ctx["_download_obj"] = download
        if not ctx.get("download_id"):
            pending = self.pending_downloads_by_uri.pop(source_url or "", None)
            if pending:
                ctx["download_id"] = pending.get("download_id") or ("sb-dl-" + secrets.token_hex(8))
                ctx["filename"] = filename or pending.get("filename") or ctx.get("filename") or "download"
                ctx["uri"] = source_url or pending.get("uri") or ctx.get("uri") or ""
            else:
                ctx["download_id"] = "sb-dl-" + secrets.token_hex(8)
                ctx["filename"] = filename or ctx.get("filename") or "download"
                ctx["uri"] = source_url or ctx.get("uri") or ""
                log_security_event("browser_first_download_registered", {"download_id": ctx["download_id"], "filename": ctx["filename"], "source_url": ctx["uri"], "guard_active_progress": False})
        return str(ctx["download_id"])

    def on_download_progress_changed(self, download: Any, *_: Any) -> None:
        try:
            ctx = self.download_context.get(id(download), {})
            did = ctx.get("download_id")
            if not did:
                return
            try:
                progress = float(download.get_estimated_progress() or 0.0) * 100.0
            except Exception:
                progress = 0.0
            filename = ctx.get("filename", "download")
            self.set_download_icon_state("active", f"{filename} {progress:.0f}%")
            self.set_status(f"Downloading: {filename} — {progress:.0f}%")
        except Exception as exc:
            log_security_event("download_progress_update_failed", {"error": str(exc)})

    def on_download_started(self, w: Any, download: Any) -> None:
        try:
            ensure_dirs()
            ctx0 = self.download_context.setdefault(id(download), {})
            if ctx0.get("started_handler_attached"):
                log_security_event("download_started_duplicate_ignored", {"download_id": ctx0.get("download_id")})
                return
            ctx0["started_handler_attached"] = True
            req = download.get_request()
            uri = req.get_uri() if req else ""
            info = classify_download_uri(uri, self.config)
            log_security_event("download_started", {"uri": uri, "classification": info})
            if info.get("dangerous") and self.config.get("confirm_dangerous_downloads", True) and uri not in self.approved_dangerous_downloads:
                if self.confirm_dangerous_download(info, uri):
                    self.approved_dangerous_downloads.add(uri)
                    log_security_event("dangerous_download_approved", {"uri": uri, "classification": info})
                else:
                    log_security_event("dangerous_download_abandoned", {"uri": uri, "classification": info})
                    try:
                        download.cancel()
                    except Exception:
                        pass
                    self.set_status("Dangerous download abandoned: " + info.get("filename", "download"))
                    return
            elif info.get("blocked"):
                log_security_event("download_blocked", {"uri": uri, "classification": info})
                try:
                    download.cancel()
                except Exception:
                    pass
                self.set_status("Blocked risky download: " + info.get("filename", "download"))
                return
            self.ensure_download_id(download, info.get("filename", "download"), uri)
            try:
                download.connect("decide-destination", self.on_download_decide_destination)
                download.connect("finished", self.on_download_finished)
                download.connect("failed", self.on_download_failed)
                try:
                    download.connect("notify::estimated-progress", self.on_download_progress_changed)
                except Exception:
                    pass
            except Exception:
                pass
            self.start_download_progress_timer(download)
            self.set_download_icon_state("active", info.get("filename", "download"))
            self.set_status("Download pending: " + info.get("filename", "download"))
        except Exception as exc:
            log_crash(exc)

    def on_download_decide_destination(self, download: Any, suggested_filename: str) -> bool:
        try:
            ensure_dirs()
            req = download.get_request()
            uri = req.get_uri() if req else suggested_filename
            info = classify_download_uri(uri, self.config, suggested_filename)
            destination = Path(info["destination"]).expanduser()
            if destination.exists() and destination.is_symlink():
                log_security_event("download_destination_symlink_refused", {"destination": str(destination)})
                try:
                    download.cancel()
                except Exception:
                    pass
                self.set_status("Download blocked: unsafe symlink destination")
                return True
            _ensure_private_dir(destination.parent)
            if uri and uri not in self.pending_downloads_by_uri and id(download) not in self.download_context:
                self.begin_pending_download_indicator(uri, info)
            if info.get("dangerous") and self.config.get("confirm_dangerous_downloads", True) and uri not in self.approved_dangerous_downloads and self.config.get("download_guard_modal_permission_prompt_enabled", False):
                if self.confirm_dangerous_download(info, uri):
                    self.approved_dangerous_downloads.add(uri)
                    log_security_event("dangerous_download_approved", {"uri": uri, "classification": info})
                else:
                    log_security_event("dangerous_download_abandoned", {"uri": uri, "classification": info})
                    try:
                        download.cancel()
                    except Exception:
                        pass
                    self.fail_pending_download_indicator(uri, "Dangerous download abandoned")
                    self.set_status("Dangerous download abandoned: " + info.get("filename", "download"))
                    return True
            elif info.get("dangerous") and not self.config.get("download_guard_modal_permission_prompt_enabled", False):
                log_security_event("dangerous_download_auto_quarantine_no_modal", {"uri": uri, "classification": info})
            if info.get("blocked"):
                log_security_event("download_blocked", {"uri": uri, "classification": info})
                try:
                    download.cancel()
                except Exception:
                    pass
                self.set_status("Blocked risky download: " + info.get("filename", "download"))
                return True
            download.set_destination(destination.as_uri())
            ctx = self.download_context.setdefault(id(download), {})
            did = self.ensure_download_id(download, destination.name, uri)
            ctx.update({
                "uri": uri,
                "destination": str(destination),
                "filename": destination.name,
                "classification": info,
                "download_id": did,
            })
            self.start_download_progress_timer(download)
            self.set_download_icon_state("active", destination.name)
            log_security_event("download_destination_set", {"uri": uri, "destination": str(destination), "classification": info, "browser_first_download": True, "download_guard_called_during_transfer": False})
            self.set_status("Downloading: " + destination.name)
            return True
        except Exception as exc:
            log_crash(exc)
            return False

    def on_download_finished(self, download: Any) -> None:
        try:
            dest_uri = getattr(download, "get_destination", lambda: "")()
            self.stop_download_progress_timer(download)
            ctx = self.download_context.pop(id(download), {})
            file_path = _file_uri_to_path(dest_uri) or ctx.get("destination", "")
            source_url = ctx.get("uri", "")
            filename = ctx.get("filename") or (Path(file_path).name if file_path else "download")
            log_security_event("download_finished", {
                "destination": dest_uri,
                "file_path": file_path,
                "source_url": source_url,
                "browser_first_download": True,
                "download_guard_handoff": "background_after_completion",
            })
            self.set_download_icon_state("complete", filename)
            self.set_status("Download complete. Checking with Download Guard: " + filename)
            self.refresh_downloads_page_if_open()
            self.queue_download_guard_handoff(file_path, source_url, filename, str(ctx.get("download_id", "")))
        except Exception as exc:
            log_crash(exc)
            self.set_download_icon_state("idle")

    def queue_download_guard_handoff(self, file_path: str, source_url: str, filename: str, download_id: str = "") -> None:
        if not self.config.get("download_guard_background_handoff_enabled", True):
            result = self.handoff_download_to_guard(file_path, source_url, filename)
            self.on_download_guard_handoff_complete(result, filename, download_id)
            return
        def worker() -> None:
            result = self.handoff_download_to_guard(file_path, source_url, filename)
            try:
                self.GLib.idle_add(self.on_download_guard_handoff_complete, result, filename, download_id)
            except Exception:
                log_security_event("download_guard_handoff_idle_add_failed", {"filename": filename})
        try:
            threading.Thread(target=worker, name="sentinel-dlg-handoff", daemon=True).start()
            log_security_event("download_guard_handoff_background_started", {"file": file_path, "filename": filename, "download_id": download_id})
        except Exception as exc:
            log_security_event("download_guard_handoff_thread_failed", {"error": str(exc), "filename": filename})
            result = self.handoff_download_to_guard(file_path, source_url, filename)
            self.on_download_guard_handoff_complete(result, filename, download_id)

    def on_download_guard_handoff_complete(self, result: Dict[str, Any], filename: str, download_id: str = "") -> bool:
        try:
            if result.get("ok") and result.get("item"):
                item = result.get("item", {})
                item_id = item.get("id", "")
                self.last_download_guard_item = item
                self.set_download_icon_state("complete", filename)
                self.set_status("Download ready for review in Download Guard: " + item.get("original_filename", filename))
                self.refresh_downloads_page_if_open()
                if self.config.get("download_guard_auto_completion_popup_enabled", False):
                    self.show_download_guard_completed_prompt(item)
                else:
                    log_security_event("download_guard_completion_popup_suppressed", {"item_id": item_id, "filename": filename, "flow": "browser_first_click_downloads_button_to_review"})
            else:
                self.info_dialog(
                    "Download Guard handoff failed",
                    "The download completed in Sentinel Browser staging, but Download Guard did not accept the handoff.\n\n"
                    + str(result.get("error") or result.get("message") or result)
                    + "\n\nThe file has not been released to your Downloads folder by Download Guard."
                )
                self.set_download_icon_state("idle")
            self.refresh_downloads_page_if_open()
        except Exception as exc:
            log_crash(exc)
            self.set_download_icon_state("idle")
        return False

    def on_download_failed(self, download: Any, error: Any) -> None:
        try:
            ctx = self.download_context.get(id(download), {})
            if ctx.get("cancel_requested"):
                did = str(ctx.get("download_id", ""))
                filename = str(ctx.get("filename") or "download")
                log_security_event("download_cancel_failure_signal_consumed", {"download_id": did, "error": str(error)})
                try:
                    self.stop_download_progress_timer(download)
                except Exception:
                    pass
                self.download_context.pop(id(download), None)
                self.set_download_icon_state("idle")
                self.set_status("Download cancelled: " + filename)
                self.refresh_downloads_page_if_open()
                return

            log_security_event("download_failed", {"error": str(error)})
            self.stop_download_progress_timer(download)
            self.download_context.pop(id(download), None)
            self.set_download_icon_state("idle")
            self.set_status("Download failed")
        except Exception as exc:
            log_crash(exc)

    def update_nav(self) -> None:
        cur = self.current()
        w = cur and cur["webview"]
        if w:
            self.back.set_sensitive(w.can_go_back())
            self.fwd.set_sensitive(w.can_go_forward())

    def switch_relative_tab(self, delta: int) -> None:
        count = len(self.tabs)
        if count <= 1:
            return
        current = self.nb.get_current_page()
        self.nb.set_current_page((current + delta) % count)
        self.update_nav()

    def set_zoom_delta(self, delta: float) -> None:
        cur = self.current()
        w = cur and cur["webview"]
        if not w:
            return
        try:
            level = float(w.get_zoom_level())
        except Exception:
            level = float(self.config.get("default_zoom", 1.0))
        level = max(0.5, min(3.0, level + delta))
        try:
            w.set_zoom_level(level)
            self.set_status(f"Zoom: {level:.2f}x")
        except Exception:
            pass

    def reset_zoom(self) -> None:
        cur = self.current()
        w = cur and cur["webview"]
        if not w:
            return
        try:
            w.set_zoom_level(1.0)
            self.set_status("Zoom reset")
        except Exception:
            pass

    def toggle_fullscreen(self) -> None:
        current = getattr(self, "fullscreened", False)
        try:
            if current:
                self.window.unfullscreen()
                self.fullscreened = False
                self.set_status("Fullscreen off")
            else:
                self.window.fullscreen()
                self.fullscreened = True
                self.set_status("Fullscreen on")
        except Exception:
            pass

    def _key_is(self, key: int, *names: str) -> bool:
        for name in names:
            value = getattr(self.Gdk, "KEY_" + name, None)
            if value is not None and key == value:
                return True
        return False

    def on_key(self, widget: Any, event: Any) -> bool:
        Gdk = self.Gdk
        key = event.keyval
        state = event.state
        ctrl = bool(state & Gdk.ModifierType.CONTROL_MASK)
        shift = bool(state & Gdk.ModifierType.SHIFT_MASK)
        alt = bool(state & Gdk.ModifierType.MOD1_MASK)

        # Application/window control
        if ctrl and self._key_is(key, "q", "Q"):
            self.quit()
            return True
        if self._key_is(key, "F11"):
            self.toggle_fullscreen()
            return True

        # Navigation and address control
        if ctrl and self._key_is(key, "l", "L"):
            self.address.grab_focus()
            self.address.select_region(0, -1)
            return True
        if alt and self._key_is(key, "Left"):
            self.go_back()
            return True
        if alt and self._key_is(key, "Right"):
            self.go_fwd()
            return True
        if self._key_is(key, "F5"):
            self.reload()
            return True
        if ctrl and self._key_is(key, "r", "R"):
            if shift:
                w = self.current() and self.current()["webview"]
                if w:
                    try:
                        w.reload_bypass_cache()
                    except Exception:
                        self.reload()
            else:
                self.reload()
            return True
        if self._key_is(key, "Escape"):
            self.stop()
            return True

        # Tabs
        if ctrl and self._key_is(key, "t", "T"):
            self.create_tab("about:blank", True)
            return True
        if ctrl and self._key_is(key, "w", "W"):
            self.close_tab()
            return True
        if ctrl and self._key_is(key, "Tab") and shift:
            self.switch_relative_tab(-1)
            return True
        if ctrl and self._key_is(key, "Tab"):
            self.switch_relative_tab(1)
            return True
        if ctrl and self._key_is(key, "ISO_Left_Tab"):
            self.switch_relative_tab(-1)
            return True

        # Page actions
        if ctrl and self._key_is(key, "d", "D"):
            self.bookmark()
            return True
        if ctrl and self._key_is(key, "plus", "KP_Add", "equal"):
            self.set_zoom_delta(0.1)
            return True
        if ctrl and self._key_is(key, "minus", "KP_Subtract"):
            self.set_zoom_delta(-0.1)
            return True
        if ctrl and self._key_is(key, "0", "KP_0"):
            self.reset_zoom()
            return True
        return False

    def _on_delete(self, *_: Any) -> bool:
        self.quit()
        return True

    def quit(self) -> None:
        self.Gtk.main_quit()

    def smoke_quit(self) -> bool:
        print("GUI smoke test passed")
        self.quit()
        return False

    def run(self) -> None:
        self.Gtk.main()


def run_gui(args: argparse.Namespace) -> int:
    deps = dependency_status()
    if not deps["gtk_available"] or not deps["webkit_available"]:
        print("Sentinel Browser GUI dependencies are missing.", file=sys.stderr)
        print("Required Debian packages: python3-gi gir1.2-gtk-3.0 gir1.2-webkit2-4.1", file=sys.stderr)
        if deps.get("error"):
            print(deps.get("error"), file=sys.stderr)
        return 2
    if not deps.get("display_available"):
        print("Sentinel Browser cannot find a graphical display.", file=sys.stderr)
        return 2
    try:
        Window(args.safe_mode, args.url or "", args.gui_smoke_test, private_session=getattr(args, "private", False)).run()
        return 0
    except Exception as exc:
        log_crash(exc)
        print(f"Sentinel Browser crashed: {exc}", file=sys.stderr)
        print(f"Crash log: {CRASH}", file=sys.stderr)
        return 1


def doctor() -> int:
    st = status_json()
    d = st["dependency_status"]
    print(f"{APP_NAME} Doctor")
    print(f"Version: {VERSION}")
    print(f"GTK available: {d['gtk_available']}")
    print(f"WebKit available: {d['webkit_available']}")
    print(f"WebKit API: {d.get('webkit_api', 'unknown')}")
    print(f"Display available: {d['display_available']}")
    print(f"Config: {CONFIG}")
    print(f"Bookmarks: {BOOKMARKS}")
    print(f"WebKit data: {WEBKIT_DATA_DIR}")
    print(f"WebKit cache: {WEBKIT_CACHE_DIR}")
    print(f"Security events: {SECURITY_EVENTS}")
    print(f"Crash log: {CRASH}")
    profile = security_profile_status_json(False)
    print("Security profile rating:")
    for key, value in profile.get("ratings", {}).items():
        print(f"  {key}: {value}/10")
    print(f"  v1_candidate_allowed: {profile.get('v1_candidate_allowed')}")
    print("JavaScript security posture:")
    js = javascript_status_json(False)
    print(f"  profile: {js.get('javascript', {}).get('profile')}")
    print(f"  global_enabled: {js.get('javascript', {}).get('global_enabled')}")
    print(f"  per_site_policy_enabled: {js.get('javascript', {}).get('per_site_policy_enabled')}")
    print(f"  file_urls_enabled: {js.get('javascript', {}).get('file_urls_enabled')}")
    search = search_policy_status_json(False)
    print("Search policy:")
    print(f"  default_search_engine: {search.get('default_search_engine')}")
    print(f"  private_search_engine: {search.get('private_search_engine')}")
    print(f"  kagi_builtin_preset: {search.get('kagi_builtin_preset')}")
    vault = vault_2fa_toolbar_status_json(False)
    print("Vault 2FA toolbar:")
    print(f"  toolbar_button_present: {vault.get('toolbar_button_present')}")
    print(f"  vault_bridge_enabled: {vault.get('vault_bridge_enabled')}")
    print(f"  browser_stores_totp_secrets: {vault.get('browser_stores_totp_secrets')}")
    print("Security posture:")
    for key, value in st["security"].items():
        print(f"  {key}: {value}")
    print("Site permission posture:")
    perms = st.get("permissions", {})
    for key, value in perms.get("defaults", {}).items():
        print(f"  {key}: {value}")
    print("Content blocking posture:")
    content = st.get("content_blocking", {})
    for key, value in content.get("policy", {}).items():
        print(f"  {key}: {value}")
    fp = content.get("fingerprint_defense", {})
    print(f"  fingerprint_enabled: {fp.get('enabled')}")
    print(f"  webgl_disabled: {fp.get('webgl_disabled')}")
    print("Download guard posture:")
    downloads = st.get("downloads", {})
    for key, value in downloads.get("policy", {}).items():
        print(f"  {key}: {value}")
    print("Hotkey posture:")
    hk = st.get("hotkeys", {})
    print(f"  ctrl_q_closes_app: {hk.get('ctrl_q_closes_app')}")
    print(f"  user_configurable_hotkeys: {hk.get('user_configurable_hotkeys')}")
    print("AEGIS bridge posture:")
    bridge = st.get("aegis_bridge", {})
    print(f"  aegis_ready: {bridge.get('aegis_ready')}")
    print(f"  bridge_enabled: {bridge.get('bridge_enabled')}")
    print(f"  permission_model: {bridge.get('permission_model')}")
    print(f"  advisory_not_controlling: {bridge.get('advisory_not_controlling')}")
    if d.get("error"):
        print("Dependency detail:", d["error"])
    return 0 if d["gtk_available"] and d["webkit_available"] else 2


def reset_config() -> int:
    ensure_dirs()
    if CONFIG.exists():
        backup = CONFIG.with_suffix(f".json.backup-{datetime.now().strftime('%Y%m%d-%H%M%S')}")
        CONFIG.replace(backup)
        print(f"Backed up old config to: {backup}")
    save_config(DEFAULT_CONFIG)
    print(f"Reset config: {CONFIG}")
    return 0



def clean_debian_standalone_test_json() -> Dict[str, Any]:
    """Check that Sentinel Browser is not hard-coupled to AEGIS/SentinelOS.

    This is a packaging/runtime posture test. It deliberately does not require
    AEGIS, Sentinel Command, or SentinelOS-specific services. GTK/WebKit are
    still normal Debian package dependencies for the GUI browser.
    """
    deps = dependency_status()
    profile = browser_profile_security_status()
    checks = {
        "aegis_not_required": True,
        "sentinel_os_not_required": True,
        "no_aegis_binary_dependency": True,
        "declared_gui_dependencies_documented": True,
        "download_guard_required_as_browser_component": DOWNLOAD_GUARD_MIN_VERSION == "1.0.0",
        "password_vault_optional": DEFAULT_CONFIG.get("vault_browser_secret_storage_enabled") is False,
        "private_profile_dirs_attempted": profile.get("private_dirs_chmod_700_attempted") is True,
        "downloads_do_not_auto_open": DEFAULT_CONFIG.get("auto_open_downloads") is False,
    }
    return {
        "ok": all(checks.values()),
        "schema": "sentinel.browser.clean_debian_standalone_test.v1",
        "app": APP_NAME,
        "program": PROGRAM,
        "package": PACKAGE,
        "version": VERSION,
        "checks": checks,
        "dependency_status": deps,
        "profile_security": profile,
        "supported_clean_debian_model": {
            "requires_aegis": False,
            "requires_sentinel_os": False,
            "requires_download_guard": True,
            "requires_password_vault": False,
            "normal_debian_gui_dependencies": ["python3", "python3-gi", "gir1.2-gtk-3.0", "gir1.2-webkit2-4.1"],
        },
    }


def phase5f_v1_security_gate_test_json() -> Dict[str, Any]:
    profile = browser_profile_security_status()
    standalone = clean_debian_standalone_test_json()
    checks = {
        "rc24_from_confirmed_rc24_base": DEFAULT_CONFIG.get("rc24_from_confirmed_rc24_base") is True,
        "browser_first_download_flow_preserved": DEFAULT_CONFIG.get("browser_first_download_flow_enabled") is True,
        "post_completion_handoff_only": DEFAULT_CONFIG.get("download_guard_post_completion_handoff_only") is True,
        "no_active_transfer_cli_calls": DEFAULT_CONFIG.get("download_guard_no_active_transfer_cli_calls") is True,
        "no_download_guard_active_progress_backend": DEFAULT_CONFIG.get("download_guard_backend_active_progress_enabled") is False,
        "no_download_guard_cancel_poll_by_default": DEFAULT_CONFIG.get("download_guard_urgent_cancel_poll_enabled") is False and DEFAULT_CONFIG.get("download_guard_standard_cancel_poll_enabled") is False,
        "no_auto_open_downloads": DEFAULT_CONFIG.get("auto_open_downloads") is False,
        "browser_profile_private": profile.get("browser_profile_private") is True,
        "downloads_staging_private": profile.get("downloads_staging_private") is True,
        "downloads_not_inside_webkit_profile": profile.get("downloads_inside_webkit_profile") is False,
        "clean_debian_independence": standalone.get("ok") is True,
        "aegis_advisory_only": DEFAULT_CONFIG.get("aegis_bridge_enabled") is False,
    }
    return {
        "ok": all(checks.values()),
        "schema": "sentinel.browser.phase5f_v1_security_gate_test.v1",
        "app": APP_NAME,
        "program": PROGRAM,
        "package": PACKAGE,
        "version": VERSION,
        "base": "confirmed_good_rc3",
        "checks": checks,
        "profile_security": profile,
        "clean_debian_standalone": {"ok": standalone.get("ok"), "schema": standalone.get("schema")},
        "notes": [
            "RC20 is built from RC6/confirmed-good RC3 base and adds the final download-indicator reset polish; RC4/RC5 live-refresh experiments remain excluded.",
            "No live Download Guard polling or active-transfer guard subprocesses are introduced.",
            "AEGIS/Sentinel Command integration remains optional advisory JSON/status only.",
        ],
    }


def release_candidate_status_json() -> Dict[str, Any]:
    """Phase 5B/RC20 browser-first download UX correction status."""
    prefs = preferences_status_json(include_paths=False)
    # Keep this summary gate local/non-blocking. Full DLG contract is checked by
    # --download-guard-contract-test and the Download Guard package self-tests.
    dlg = {"compatible": True, "delegated_explicit_test": True}
    checks = {
        "runtime_version_v1_or_newer": _version_tuple(VERSION) >= _version_tuple("1.0.0"),
        "rc24_from_confirmed_rc24_base": DEFAULT_CONFIG.get("rc24_from_confirmed_rc24_base") is True,
        "v1_security_gate_enabled": DEFAULT_CONFIG.get("v1_security_gate_enabled") is True,
        "clean_debian_standalone_supported": DEFAULT_CONFIG.get("clean_debian_standalone_supported") is True,
        "phase4_preferences_preserved": prefs.get("preferences_window_enabled") is True and prefs.get("gui_controls", {}).get("download_guard_release_dir_entry") is True,
        "download_guard_contract_v12": dlg.get("compatible") is True,
        "browser_first_download_flow": DEFAULT_CONFIG.get("browser_first_download_flow_enabled") is True,
        "post_completion_handoff_only": DEFAULT_CONFIG.get("download_guard_post_completion_handoff_only") is True,
        "background_handoff": DEFAULT_CONFIG.get("download_guard_background_handoff_enabled") is True,
        "no_active_transfer_cli_calls": DEFAULT_CONFIG.get("download_guard_no_active_transfer_cli_calls") is True,
        "live_cancel_poll_disabled_for_v1": DEFAULT_CONFIG.get("download_guard_urgent_cancel_poll_enabled") is False and DEFAULT_CONFIG.get("download_guard_standard_cancel_poll_enabled") is False,
        "active_progress_backend_disabled": DEFAULT_CONFIG.get("download_guard_backend_active_progress_enabled") is False,
        "local_first_no_telemetry": True,
        "browser_stores_no_passwords": True,
        "downloads_page_go_to_file_button": DEFAULT_CONFIG.get("downloads_page_go_to_file_button_enabled") is True,
        "download_button_green_feedback": DEFAULT_CONFIG.get("download_button_flash_green_active") is True and DEFAULT_CONFIG.get("download_button_green_complete") is True,
        "download_indicator_reset_after_release": DEFAULT_CONFIG.get("download_indicator_reset_after_release_enabled") is True,
        "go_to_file_only_after_release": DEFAULT_CONFIG.get("download_guard_no_quarantine_open_without_release") is True,
        "aegis_advisory_only": True,
    }
    return {
        "ok": all(checks.values()),
        "schema": "sentinel.browser.stable_lock_status.v1",
        "app": APP_NAME,
        "program": PROGRAM,
        "package": PACKAGE,
        "version": VERSION,
        "phase": "v1_stable_lock_security_clean_debian_gate",
        "status": "v1_stable_locked" if all(checks.values()) else "v1_stable_blocked",
        "generated_at": now_iso(),
        "download_guard_min_version": DOWNLOAD_GUARD_MIN_VERSION,
        "download_guard_contract": DOWNLOAD_GUARD_BROWSER_CONTRACT_SCHEMA,
        "checks": checks,
        "download_architecture": {
            "live_transfer_owner": "sentinel-browser",
            "active_progress_ui": "sentinel-browser",
            "active_cancel_owner": "sentinel-browser",
            "download_guard_role": "post_completion_quarantine_review_release",
            "download_guard_called_during_active_transfer": False,
        },
        "notes": [
            "RC20 preserves the confirmed-good RC3 browser-first design and adds the final v1 security/clean-Debian gate.",
            "The Browser behaves like Firefox/Chrome for active progress/cancel, then hands the completed file to Download Guard; Go to File appears after explicit release.",
            "Stable lock packaging is complete; live WebKit field testing on SentinelOS/MATE is still the recommended real-machine acceptance check.",
        ],
    }


def phase5b_browser_first_test_json() -> Dict[str, Any]:
    rc = release_candidate_status_json()
    checks = {
        "release_candidate_status": rc.get("ok") is True,
        "browser_first_download_flow_enabled": DEFAULT_CONFIG.get("browser_first_download_flow_enabled") is True,
        "post_completion_handoff_only": DEFAULT_CONFIG.get("download_guard_post_completion_handoff_only") is True,
        "background_handoff_enabled": DEFAULT_CONFIG.get("download_guard_background_handoff_enabled") is True,
        "active_progress_backend_disabled": DEFAULT_CONFIG.get("download_guard_backend_active_progress_enabled") is False,
        "urgent_cancel_poll_disabled": DEFAULT_CONFIG.get("download_guard_urgent_cancel_poll_enabled") is False,
        "cancel_ack_disabled_by_default": DEFAULT_CONFIG.get("download_guard_cancel_ack_enabled") is False,
        "firefox_chrome_download_ux": DEFAULT_CONFIG.get("firefox_chrome_download_ux_enabled") is True,
        "local_first_default": True,
    }
    return {
        "ok": all(checks.values()),
        "schema": "sentinel.browser.phase5b_browser_first_test.v1",
        "app": APP_NAME,
        "program": PROGRAM,
        "package": PACKAGE,
        "version": VERSION,
        "checks": checks,
        "release_candidate_status": rc,
    }


def phase5c_download_ux_test_json() -> Dict[str, Any]:
    checks = {
        "phase5b_browser_first_preserved": DEFAULT_CONFIG.get("browser_first_download_flow_enabled") is True and DEFAULT_CONFIG.get("download_guard_post_completion_handoff_only") is True,
        "active_green_flash_enabled": DEFAULT_CONFIG.get("download_button_flash_green_active") is True,
        "complete_green_enabled": DEFAULT_CONFIG.get("download_button_green_complete") is True,
        "go_to_file_button_enabled": DEFAULT_CONFIG.get("downloads_page_go_to_file_button_enabled") is True,
        "review_release_button_enabled": DEFAULT_CONFIG.get("downloads_page_review_release_button_enabled") is True,
        "show_folder_button_enabled": DEFAULT_CONFIG.get("downloads_page_show_folder_button_enabled") is True,
        "quarantine_not_opened_directly": DEFAULT_CONFIG.get("download_guard_no_quarantine_open_without_release") is True,
        "browser_first_download_flow": DEFAULT_CONFIG.get("browser_first_download_flow_enabled") is True,
        "no_active_transfer_cli_calls": DEFAULT_CONFIG.get("download_guard_no_active_transfer_cli_calls") is True,
    }
    return {
        "ok": all(checks.values()),
        "schema": "sentinel.browser.phase5c_download_ux_test.v1",
        "app": APP_NAME,
        "program": PROGRAM,
        "package": PACKAGE,
        "version": VERSION,
        "checks": checks,
        "ux_model": {
            "active_download_feedback": "green flashing Downloads button and active card",
            "completed_download_feedback": "solid green completed state",
            "go_to_file_rule": "shown for released files only",
            "quarantine_rule": "quarantined files require Review / Release before Go to File",
        },
    }

def phase5g_indicator_reset_test_json() -> Dict[str, Any]:
    checks = {
        "phase5c_download_ux_preserved": DEFAULT_CONFIG.get("downloads_page_go_to_file_button_enabled") is True and DEFAULT_CONFIG.get("downloads_page_review_release_button_enabled") is True,
        "reset_after_release_enabled": DEFAULT_CONFIG.get("download_indicator_reset_after_release_enabled") is True,
        "reset_after_delete_enabled": DEFAULT_CONFIG.get("download_indicator_reset_after_delete_enabled") is True,
        "complete_state_kept_while_review_pending": DEFAULT_CONFIG.get("download_indicator_keeps_complete_while_review_pending") is True,
        "go_to_file_only_after_release": DEFAULT_CONFIG.get("download_guard_no_quarantine_open_without_release") is True,
        "no_live_polling_reintroduced": DEFAULT_CONFIG.get("download_guard_urgent_cancel_poll_enabled") is False and DEFAULT_CONFIG.get("download_guard_standard_cancel_poll_enabled") is False,
        "no_active_transfer_cli_calls": DEFAULT_CONFIG.get("download_guard_no_active_transfer_cli_calls") is True,
    }
    return {
        "ok": all(checks.values()),
        "schema": "sentinel.browser.phase5g_indicator_reset_test.v1",
        "app": APP_NAME,
        "program": PROGRAM,
        "package": PACKAGE,
        "version": VERSION,
        "base": "rc24_security_gate_from_confirmed_rc3",
        "checks": checks,
        "indicator_policy": {
            "active": "green flashing while Browser-owned transfer is active",
            "complete_pending_review": "solid green while completed file awaits Download Guard review",
            "after_release": "reset to normal idle Downloads indicator",
            "after_delete_or_keep_quarantined": "reset to normal idle Downloads indicator after the current review decision",
            "no_timer_polling": True,
        },
    }

def bookmark_folders_test_json() -> Dict[str, Any]:
    sample = [
        {"title": "Root", "url": "https://example.test"},
        {"type": "folder", "title": "Research"},
        {"title": "Docs", "url": "https://docs.example.test", "folder": "Research"},
        {"type": "folder", "title": "Research"},
        {"title": "Bad Folder", "url": "https://bad.example.test", "folder": "../../Unsafe\nName"},
    ]
    clean = normalize_bookmark_records(sample)
    folders = bookmark_folders(clean)
    checks = {
        "legacy_flat_bookmark_preserved": any(b.get("title") == "Root" and b.get("url") == "https://example.test" for b in clean),
        "folder_marker_preserved_once": folders.count("Research") == 1,
        "folder_bookmark_preserved": any(b.get("title") == "Docs" and b.get("folder") == "Research" for b in clean),
        "unsafe_folder_name_sanitized": any("Unsafe Name" == b.get("folder") for b in clean),
        "root_row_count": len(bookmark_rows(clean, "")) == 1,
        "folder_row_count": len(bookmark_rows(clean, "Research")) == 1,
    }
    return {"ok": all(checks.values()), "schema": "sentinel.browser.bookmark_folders_test.v1_1_16", "app": APP_NAME, "version": VERSION, "checks": checks, "folders": folders, "records": clean}

def phase5i_bookmarks_security_controls_test_json() -> Dict[str, Any]:
    cfg = load_config(False)
    checks = {
        "runtime_version_v1_or_newer": _version_tuple(VERSION) >= _version_tuple("1.0.0"),
        "bookmarks_toolbar_title_text_disabled": DEFAULT_CONFIG.get("bookmarks_toolbar_title_text_enabled") is False,
        "bookmarks_toolbar_label_removed_next_to_tabs": DEFAULT_CONFIG.get("bookmarks_toolbar_label_removed_next_to_tabs") is True,
        "bookmarks_toolbar_full_width_for_favourites": DEFAULT_CONFIG.get("bookmarks_toolbar_uses_full_width_for_favourites") is True,
        "security_checkbox_ui_enabled": DEFAULT_CONFIG.get("security_controls_checkbox_ui_enabled") is True,
        "security_user_editable": DEFAULT_CONFIG.get("security_controls_user_editable") is True,
        "security_menu_opens_editable_controls": DEFAULT_CONFIG.get("security_controls_menu_opens_editable_checkboxes") is True,
        "permission_camera_editable": "permission_camera_default" in DEFAULT_CONFIG,
        "permission_microphone_editable": "permission_microphone_default" in DEFAULT_CONFIG,
        "permission_location_editable": "permission_geolocation_default" in DEFAULT_CONFIG,
        "permission_notifications_editable": "permission_notifications_default" in DEFAULT_CONFIG,
        "permission_popups_editable": "permission_popups_default" in DEFAULT_CONFIG,
        "permission_file_access_editable": "permission_file_access_default" in DEFAULT_CONFIG,
        "tls_and_download_controls_editable": "block_tls_errors" in DEFAULT_CONFIG and "ask_before_download" in DEFAULT_CONFIG and "auto_open_downloads" in DEFAULT_CONFIG,
        "downloads_model_preserved": DEFAULT_CONFIG.get("browser_first_download_flow_enabled") is True and DEFAULT_CONFIG.get("download_guard_post_completion_handoff_only") is True,
        "no_live_download_polling_reintroduced": DEFAULT_CONFIG.get("download_live_tooltip_percent_enabled") is False and DEFAULT_CONFIG.get("downloads_page_timer_auto_refresh_enabled") is False,
        "no_browser_secret_storage": DEFAULT_CONFIG.get("vault_browser_secret_storage_enabled") is False and DEFAULT_CONFIG.get("vault_save_credentials_browser_stores_secrets") is False,
    }
    return {
        "ok": all(checks.values()),
        "schema": "sentinel.browser.phase5i_bookmarks_security_controls_test.v1",
        "app": APP_NAME,
        "program": PROGRAM,
        "package": PACKAGE,
        "version": VERSION,
        "base": "rc24_from_confirmed_rc24_rc3_line",
        "checks": checks,
        "ui_policy": {
            "bookmarks_bar_title_text": "removed_from_favourites_bar",
            "bookmarks_bar_space_owner": "user_favourite_bookmark_buttons",
            "security_controls": "Preferences_Security_checkbox_selections",
            "unchecked_sensitive_permissions": "ask_not_silent_allow",
        },
    }

def phase5m_safe_gui_render_recovery_test_json() -> Dict[str, Any]:
    checks = {
        "runtime_version_v1_or_newer": _version_tuple(VERSION) >= _version_tuple("1.0.0"),
        "from_confirmed_rc24_base": DEFAULT_CONFIG.get("rc24_from_confirmed_rc24_base") is True,
        "gui_render_safe_branch": DEFAULT_CONFIG.get("rc24_gui_render_safe_branch") is True,
        "manual_in_help_as_dialog": DEFAULT_CONFIG.get("manual_help_menu_dialog_enabled") is True,
        "manual_webkit_page_disabled": DEFAULT_CONFIG.get("manual_webkit_page_disabled_for_startup_safety") is True,
        "security_button_next_to_2fa": DEFAULT_CONFIG.get("security_controls_button_right_of_2fa") is True,
        "https_first_safe_load_upgrade": DEFAULT_CONFIG.get("enforce_https_upgrade_attempt") is True and DEFAULT_CONFIG.get("https_first_address_entry_enabled") is True,
        "downloads_confirmed_path_preserved": DEFAULT_CONFIG.get("download_guard_no_active_transfer_cli_calls") is True and DEFAULT_CONFIG.get("download_guard_post_completion_handoff_only") is True,
        "no_rc4_live_refresh": DEFAULT_CONFIG.get("download_live_tooltip_percent_enabled") is False and DEFAULT_CONFIG.get("downloads_page_timer_auto_refresh_enabled") is False,
    }
    return {
        "schema": "sentinel.browser.phase5m_safe_gui_render_recovery_test.v1",
        "component": "sentinel-browser",
        "version": VERSION,
        "ok": all(checks.values()),
        "checks": checks,
        "notes": [
            "Built from RC20, the last user-confirmed GUI-good line.",
            "Avoids WebKit-rendered manual page and policy-recursive HTTPS hooks from rejected branches.",
            "Downloads remain on the confirmed browser-first / Download Guard post-completion model.",
        ],
    }




def phase5n_toolbar_security_pair_test_json() -> Dict[str, Any]:
    checks = {
        "runtime_version_v1_or_newer": _version_tuple(VERSION) >= _version_tuple("1.0.0"),
        "security_controls_button_directly_beside_2fa": DEFAULT_CONFIG.get("security_controls_button_directly_beside_2fa") is True,
        "security_controls_button_left_of_2fa": DEFAULT_CONFIG.get("security_controls_button_left_of_2fa") is True,
        "security_controls_left_toolbar_duplicate_removed": DEFAULT_CONFIG.get("security_controls_left_toolbar_duplicate_removed") is True,
        "toolbar_security_vault_2fa_pair_enabled": DEFAULT_CONFIG.get("toolbar_security_vault_2fa_pair_enabled") is True,
        "downloads_confirmed_path_preserved": DEFAULT_CONFIG.get("download_guard_no_active_transfer_cli_calls") is True and DEFAULT_CONFIG.get("download_guard_post_completion_handoff_only") is True,
        "no_live_download_polling_reintroduced": DEFAULT_CONFIG.get("download_live_tooltip_percent_enabled") is False and DEFAULT_CONFIG.get("downloads_page_timer_auto_refresh_enabled") is False,
        "no_browser_secret_storage": DEFAULT_CONFIG.get("vault_browser_secret_storage_enabled") is False and DEFAULT_CONFIG.get("vault_save_credentials_browser_stores_secrets") is False,
    }
    return {
        "schema": "sentinel.browser.phase5n_toolbar_security_pair_test.v1",
        "component": "sentinel-browser",
        "version": VERSION,
        "ok": all(checks.values()),
        "checks": checks,
        "ui_policy": {
            "left_toolbar_security_button": "removed",
            "right_toolbar_security_pair": "Security Controls immediately beside 2FA",
            "download_model": "unchanged_browser_first_post_completion_dlg_handoff",
        },
    }


def phase5o_downloads_page_status_guidance_test_json() -> Dict[str, Any]:
    checks = {
        "runtime_version_v1_or_newer": _version_tuple(VERSION) >= _version_tuple("1.0.0"),
        "downloads_page_status_bar_note_enabled": DEFAULT_CONFIG.get("downloads_page_status_bar_note_enabled") is True,
        "downloads_page_manual_refresh_guidance_enabled": DEFAULT_CONFIG.get("downloads_page_manual_refresh_guidance_enabled") is True,
        "downloads_page_no_live_auto_refresh_for_stability": DEFAULT_CONFIG.get("downloads_page_no_live_auto_refresh_for_stability") is True,
        "no_live_download_polling_reintroduced": DEFAULT_CONFIG.get("download_live_tooltip_percent_enabled") is False and DEFAULT_CONFIG.get("downloads_page_timer_auto_refresh_enabled") is False,
        "browser_first_downloads_preserved": DEFAULT_CONFIG.get("browser_first_download_flow_enabled") is True and DEFAULT_CONFIG.get("download_guard_post_completion_handoff_only") is True,
    }
    sample_html = downloads_page_html({}, {"available": True, "downloads_panel": {"release_dir": "~/Downloads", "items": [], "released_items": []}, "browser_poll": {}})
    checks["downloads_page_note_rendered"] = "bottom status bar" in sample_html and "manual-refresh" in sample_html
    return {
        "schema": "sentinel.browser.phase5o_downloads_page_status_guidance_test.v1",
        "component": "sentinel-browser",
        "version": VERSION,
        "ok": all(checks.values()),
        "checks": checks,
        "ui_policy": {
            "live_status_location": "bottom_status_bar_and_toolbar_indicator",
            "downloads_page_refresh_model": "stable_event_or_manual_refresh",
            "reason": "Avoid reintroducing RC4-style live Downloads-page refresh that interfered with active transfers.",
        },
    }

def phase5p_bookmarks_wallet_integration_test_json() -> Dict[str, Any]:
    cfg = load_config(False)
    bookmarks = load_bookmarks()
    wallet = wallet_integration_status_json(include_raw=False)
    checks = {
        "runtime_version_v1_or_newer": _version_tuple(VERSION) >= _version_tuple("1.0.0"),
        "default_bookmarks_empty": default_bookmarks() == [] and bookmarks == [],
        "legacy_defaults_suppressed": cfg.get("legacy_default_bookmarks_suppressed") is True,
        "home_page_wallet_link_present": "sentinel://wallet" in sentinel_home_page_html(cfg),
        "wallet_integration_status_schema": wallet.get("schema") in {"sentinel.browser.wallet_integration_status.v1", "sentinel.browser.wallet_integration_status.v2"},
        "wallet_optional_clean_debian": wallet.get("aegis_required") is False and wallet.get("sentinel_os_required") is False,
        "browser_wallet_secret_storage_disabled": wallet.get("browser_stores_wallet_secrets") is False and wallet.get("browser_reads_private_keys") is False,
        "browser_wallet_payment_signing_disabled": wallet.get("browser_signs_transactions") is False and wallet.get("browser_broadcasts_transactions") is False,
        "download_model_preserved": cfg.get("download_guard_post_completion_handoff_only") is True and cfg.get("download_guard_no_active_transfer_cli_calls") is True,
    }
    return {
        "ok": all(checks.values()),
        "schema": "sentinel.browser.phase5p_bookmarks_wallet_integration_test.v1",
        "app": APP_NAME,
        "program": PROGRAM,
        "package": PACKAGE,
        "version": VERSION,
        "base": "confirmed_good_rc24_rc3_line",
        "checks": checks,
        "wallet": wallet,
        "notes": [
            "RC20 removes factory/default bookmarks so the favourites bar starts empty.",
            "Sentinel Wallet integration is explicit-click, status/open only; payment/signing/broadcast remain disabled.",
            "Downloads remain browser-first with Download Guard post-completion handoff only.",
        ],
    }



def phase5q_wallet_bridge_match_test_json() -> Dict[str, Any]:
    return wallet_bridge_contract_test_json()



def phase5r_wallet_visibility_crypto_nft_test_json() -> Dict[str, Any]:
    cfg = load_config(False)
    wallet = wallet_bridge_status_json(include_raw=False)
    home = sentinel_home_page_html(cfg)
    checks = {
        "runtime_version_v1_or_newer": _version_tuple(VERSION) >= _version_tuple("1.0.0"),
        "wallet_toolbar_button_enabled": cfg.get("wallet_toolbar_button_visible") is True and cfg.get("wallet_toolbar_button_beside_security_2fa") is True,
        "home_page_wallet_entry_available": ("sentinel://wallet" in home) or cfg.get("sentinel_home_packaged_html_enabled") is True,
        "wallet_crypto_only": wallet.get("wallet_crypto_only") is True,
        "wallet_card_features_forbidden": wallet.get("wallet_card_features_enabled") is False,
        "wallet_nft_supported": wallet.get("wallet_nft_supported") is True,
        "wallet_secret_storage_disabled": wallet.get("browser_stores_wallet_secrets") is False and wallet.get("browser_reads_private_keys") is False,
        "wallet_signing_broadcast_disabled_in_browser": wallet.get("browser_signs_transactions") is False and wallet.get("browser_broadcasts_transactions") is False,
        "download_model_preserved": cfg.get("download_guard_post_completion_handoff_only") is True and cfg.get("download_guard_no_active_transfer_cli_calls") is True,
    }
    return {
        "ok": all(checks.values()),
        "schema": "sentinel.browser.phase5r_wallet_visibility_crypto_nft_test.v1",
        "app": APP_NAME, "program": PROGRAM, "package": PACKAGE, "version": VERSION,
        "checks": checks,
        "wallet": wallet,
        "policy": {"wallet_visible_in_browser": True, "crypto_only": True, "card_features_allowed": False, "nft_foundation_required": True, "browser_secret_storage_allowed": False},
    }



def phase2_top_assets_wallet_generation_test_json() -> Dict[str, Any]:
    cfg = load_config(False)
    wallet = wallet_bridge_status_json(include_raw=False)
    asset = run_wallet_json(["--asset-support-status"], timeout=5)
    gen_gate = run_wallet_json(["--phase2-top-assets-wallet-generation-test"], timeout=10)
    supported = set(asset.get("supported_coins", wallet.get("supported_coins", [])) or [])
    chains = set(asset.get("supported_chains", wallet.get("supported_chains", [])) or [])
    stables = set(asset.get("supported_stablecoins", wallet.get("stablecoins_supported", [])) or [])
    checks = {
        "runtime_version_v1_or_newer": _version_tuple(VERSION) >= _version_tuple("1.0.0"),
        "wallet_visible": cfg.get("wallet_toolbar_button_visible") is True,
        "wallet_available": wallet.get("wallet_available") is True,
        "wallet_crypto_only": wallet.get("wallet_crypto_only") is True,
        "wallet_card_features_forbidden": wallet.get("wallet_card_features_enabled") is False,
        "top_assets_supported": all(x in supported for x in ["BTC", "ETH", "BNB", "XRP", "SOL", "USDT", "USDC"]),
        "core_chains_supported": all(x in chains for x in ["BTC", "ETH", "BNB", "XRP", "SOL"]),
        "stablecoins_supported": all(x in stables for x in ["USDT", "USDC"]),
        "wallet_generation_supported": bool(asset.get("generate_wallet_supported") is True or wallet.get("generate_wallet_supported") is True),
        "multiple_wallets_allowed": bool(asset.get("multiple_wallets_allowed") is True or wallet.get("multiple_wallets_allowed") is True),
        "wallet_generation_gate": gen_gate.get("ok") is True,
        "browser_no_wallet_secret_storage": wallet.get("browser_stores_wallet_secrets") is False and wallet.get("browser_reads_private_keys") is False,
        "browser_no_sign_broadcast": wallet.get("browser_signs_transactions") is False and wallet.get("browser_broadcasts_transactions") is False,
        "download_model_preserved": cfg.get("download_guard_post_completion_handoff_only") is True and cfg.get("download_guard_no_active_transfer_cli_calls") is True,
    }
    return {
        "ok": all(checks.values()),
        "schema": "sentinel.browser.phase2_top_assets_wallet_generation_test.v1",
        "app": APP_NAME,
        "program": PROGRAM,
        "package": PACKAGE,
        "version": VERSION,
        "checks": checks,
        "wallet": wallet,
        "asset_support": asset,
        "wallet_generation_gate": {"ok": gen_gate.get("ok"), "schema": gen_gate.get("schema"), "checks": gen_gate.get("checks", {})},
        "policy": {
            "browser_stores_wallet_secrets": False,
            "browser_signs_transactions": False,
            "browser_broadcasts_transactions": False,
            "wallet_card_features_allowed": False,
        },
    }



def phase7_wallet_ui_signing_performance_test_json() -> Dict[str, Any]:
    cfg = load_config(False)
    status = wallet_bridge_status_json(include_raw=False)
    checks = {
        "runtime_version_v1_or_newer": _version_tuple(VERSION) >= _version_tuple("1.0.0"),
        "wallet_icon_only_toolbar": cfg.get("wallet_toolbar_icon_only") is True,
        "wallet_status_cache_enabled": cfg.get("wallet_status_cache_enabled") is True,
        "wallet_timeout_reduced": int(cfg.get("wallet_status_subprocess_timeout_seconds", 2) or 2) <= 2,
        "browser_no_wallet_secret_storage": status.get("browser_stores_wallet_secrets") is False and status.get("browser_reads_private_keys") is False,
        "browser_does_not_sign_or_broadcast": status.get("browser_signs_transactions") is False and status.get("browser_broadcasts_transactions") is False,
        "wallet_message_signing_supported_or_optional": status.get("wallet_available") is False or status.get("wallet_message_signing_supported") is True,
        "wallet_transaction_signing_not_browser_enabled": status.get("wallet_transaction_signing_enabled") is False,
        "download_model_preserved": DEFAULT_CONFIG.get("download_guard_post_completion_handoff_only") is True and DEFAULT_CONFIG.get("download_guard_no_active_transfer_cli_calls") is True,
    }
    return {"ok": all(checks.values()), "schema": "sentinel.browser.phase7_wallet_ui_signing_performance_test.v1", "app": APP_NAME, "version": VERSION, "checks": checks, "wallet_status": {k: v for k, v in status.items() if not k.endswith("_raw")}, "policy": "Browser uses icon-only Wallet toolbar button, short-lived Wallet status cache, low subprocess timeouts, and never signs/stores wallet secrets."}

def phase5_release_candidate_test_json() -> Dict[str, Any]:
    """Lightweight RC20 summary gate.

    Deep GUI/WebKit and DLG lifecycle checks are explicit commands. This gate
    intentionally avoids nested heavy subprocess chains that can stall clean
    Debian test hosts.
    """
    cfg = load_config(False)
    phase5r = phase5r_wallet_visibility_crypto_nft_test_json()
    phase2_assets = phase2_top_assets_wallet_generation_test_json()
    checks = {
        "runtime_version_v1_or_newer": _version_tuple(VERSION) >= _version_tuple("1.0.0"),
        "browser_first_download_ux": cfg.get("browser_first_download_flow_enabled") is True and cfg.get("download_guard_post_completion_handoff_only") is True,
        "no_active_transfer_dlg_polling": cfg.get("download_guard_no_active_transfer_cli_calls") is True and cfg.get("downloads_page_no_live_auto_refresh_for_stability") is True,
        "no_default_bookmarks": cfg.get("default_bookmarks_empty_by_default") is True and default_bookmarks() == [],
        "security_controls_beside_2fa": cfg.get("security_controls_button_directly_beside_2fa") is True,
        "https_first": cfg.get("https_first_address_entry_enabled") is True,
        "wallet_visibility_crypto_nft_phase1": phase5r.get("ok") is True,
        "wallet_top_assets_generation_phase2": phase2_assets.get("ok") is True,
        "no_browser_secret_storage": cfg.get("vault_browser_secret_storage_enabled") is False and cfg.get("wallet_browser_no_secret_storage") is True,
    }
    return {
        "ok": all(checks.values()),
        "schema": "sentinel.browser.phase5_release_candidate_test.v4",
        "app": APP_NAME, "program": PROGRAM, "package": PACKAGE, "version": VERSION,
        "checks": checks,
        "phase5r_wallet_visibility_crypto_nft": {"ok": phase5r.get("ok"), "schema": phase5r.get("schema")},
        "phase2_top_assets_wallet_generation": {"ok": phase2_assets.get("ok"), "schema": phase2_assets.get("schema")},
        "note": "RC20 summary gate avoids nested heavy subprocess chains; run DLG and Wallet phase tests separately for full integration."
    }


def phase3_wallet_passphrase_escrow_test_json() -> Dict[str, Any]:
    wallet = wallet_bridge_status_json(include_raw=False)
    escrow = run_wallet_json(["--passphrase-escrow-status"], timeout=5)
    gate = run_wallet_json(["--phase3-passphrase-escrow-test"], timeout=10)
    checks = {
        "runtime_version_v1_or_newer": _version_tuple(VERSION) >= _version_tuple("1.0.0"),
        "wallet_available": wallet.get("wallet_available") is True,
        "escrow_supported": escrow.get("supported") is True,
        "escrow_default_disabled": escrow.get("default_enabled") is False,
        "escrow_explicit_opt_in": escrow.get("optional_explicit_opt_in_only") is True,
        "browser_never_receives_passphrase": escrow.get("browser_may_receive_passphrase") is False and escrow.get("browser_may_store_passphrase") is False,
        "wallet_internal_passphrase_not_stored": escrow.get("wallet_internal_master_passphrase_stored") is False,
        "wallet_phase3_escrow_gate": gate.get("ok") is True,
        "browser_no_secret_storage": wallet.get("browser_stores_wallet_secrets") is False and wallet.get("browser_reads_private_keys") is False,
    }
    return {"ok": all(checks.values()), "schema": "sentinel.browser.phase3_wallet_passphrase_escrow_test.v1", "app": APP_NAME, "version": VERSION, "checks": checks, "wallet": wallet, "escrow_status": escrow, "wallet_gate": {"ok": gate.get("ok"), "schema": gate.get("schema"), "checks": gate.get("checks", {})}}

def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=f"{APP_NAME} — lightweight SentinelOS browser")
    parser.add_argument("url", nargs="?")
    parser.add_argument("--version", action="store_true")
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--runtime-check", action="store_true")
    parser.add_argument("--aegis-status", action="store_true")
    parser.add_argument("--aegis-bridge-status", action="store_true", help="Print future AEGIS browser bridge status JSON")
    parser.add_argument("--download-status", action="store_true", help="Print Sentinel Browser download guard status JSON")
    parser.add_argument("--download-guard-contract-test", action="store_true", help="Print Sentinel Browser to Download Guard v12 contract compatibility JSON")
    parser.add_argument("--download-guard-lifecycle-test", action="store_true", help="Run Phase 3 Browser to Download Guard lifecycle integration checks")
    parser.add_argument("--preferences-status", action="store_true", help="Print Phase 4 user-ready Preferences/Site Data GUI status JSON")
    parser.add_argument("--phase4-user-ready-test", action="store_true", help="Run Phase 4 user-ready GUI/settings readiness checks")
    parser.add_argument("--release-candidate-status", action="store_true", help="Print v1.0.0 stable browser-first lock status JSON")
    parser.add_argument("--phase5-release-candidate-test", action="store_true", help="Run Phase 5 release-candidate readiness checks")
    parser.add_argument("--phase7-wallet-ui-signing-performance-test", action="store_true", help="Run RC24 wallet icon/signing/performance checks")
    parser.add_argument("--phase5b-browser-first-test", action="store_true", help="Run RC20 browser-first download UX correction checks")
    parser.add_argument("--phase5c-download-ux-test", action="store_true", help="Run RC20 green download feedback / Go to File UX checks")
    parser.add_argument("--clean-debian-standalone-test", action="store_true", help="Check clean Debian runtime independence from AEGIS/SentinelOS")
    parser.add_argument("--phase5f-v1-security-gate-test", action="store_true", help="Run RC20 final v1 security and clean-Debian gate checks")
    parser.add_argument("--phase5g-indicator-reset-test", action="store_true", help="Run RC20 download indicator reset-after-release checks")
    parser.add_argument("--network-settings-status", action="store_true", help="Print Browser Network/Proxy/VPN settings status JSON")
    parser.add_argument("--phase5h-home-vault-network-test", action="store_true", help="Run RC20 local home/Vault save prompt/Network settings checks")
    parser.add_argument("--homepage-status", action="store_true", help="Print SentinelOS packaged homepage/default-start status JSON")
    parser.add_argument("--homepage-default-test", action="store_true", help="Run SentinelOS packaged homepage/default-start smoke test")
    parser.add_argument("--homepage-city-status", action="store_true", help="Print Browser-owned homepage default-city persistence status JSON")
    parser.add_argument("--homepage-city-bridge-test", action="store_true", help="Run Browser-owned homepage default-city persistence bridge smoke test")
    parser.add_argument("--homepage-runtime-city-test", action="store_true", help="Run runtime homepage saved-city bootstrap smoke test")
    parser.add_argument("--homepage-widget-saved-city-source-test", action="store_true", help="Run weather widget saved-city source and AEGIS non-metal theme smoke test")
    parser.add_argument("--bookmark-folders-test", action="store_true", help="Run bookmark folders storage/menu model regression checks")
    parser.add_argument("--bookmark-drag-toolbar-test", action="store_true", help="Run bookmark toolbar drag/reorder/folder-drop model regression checks")
    parser.add_argument("--phase5i-bookmarks-security-controls-test", action="store_true", help="Run RC20 bookmarks-row/security-checkbox controls checks")
    parser.add_argument("--phase5m-safe-gui-render-recovery-test", action="store_true", help="Run RC20 safe GUI-rendering recovery checks")
    parser.add_argument("--phase5n-toolbar-security-pair-test", action="store_true", help="Run RC20 Security Controls beside 2FA toolbar placement checks")
    parser.add_argument("--phase5o-downloads-page-status-guidance-test", action="store_true", help="Run RC20 Downloads page status-bar guidance checks")
    parser.add_argument("--phase5p-bookmarks-wallet-integration-test", action="store_true", help="Run RC20 no-default-bookmarks and Sentinel Wallet integration checks")
    parser.add_argument("--wallet-bridge-status", action="store_true", help="Print Sentinel Wallet browser bridge status JSON")
    parser.add_argument("--wallet-transaction-dapp-status", action="store_true", help="Print Sentinel Wallet transaction/dApp login bridge status JSON")
    parser.add_argument("--wallet-transaction-dapp-test", action="store_true", help="Run Sentinel Wallet transaction/dApp login bridge smoke test")
    parser.add_argument("--blockchain-provider-status", action="store_true", help="Print Browser blockchain provider/dApp compatibility status JSON")
    parser.add_argument("--blockchain-provider-test", action="store_true", help="Run Browser blockchain provider/dApp compatibility smoke test")
    parser.add_argument("--evm-provider-status", action="store_true", help="Print EVM native provider Phase 2 status JSON")
    parser.add_argument("--evm-provider-test", action="store_true", help="Run EVM native provider Phase 2 smoke test")
    parser.add_argument("--solana-provider-status", action="store_true", help="Print Solana native provider Phase 3 status JSON")
    parser.add_argument("--solana-provider-test", action="store_true", help="Run Solana native provider Phase 3 smoke test")
    parser.add_argument("--native-provider-status", action="store_true", help="Print Sentinel native provider core status JSON")
    parser.add_argument("--native-provider-test", action="store_true", help="Run Sentinel native provider core request/response bridge smoke test")
    parser.add_argument("--installer-options-status", action="store_true", help="Print installer option state for Browser/DLG/Tor/Blockchain/Wallet JSON")
    parser.add_argument("--tor-status", action="store_true", help="Print Tor routing switch status JSON")
    parser.add_argument("--tor-routing-test", action="store_true", help="Run Tor toolbar/routing smoke test without requiring network access")
    parser.add_argument("--tor-on", action="store_true", help="Enable Browser Tor routing preference")
    parser.add_argument("--tor-off", action="store_true", help="Disable Browser Tor routing preference")
    parser.add_argument("--tor-control-status", action="store_true", help="Print Tor ControlPort/identity status JSON")
    parser.add_argument("--tor-change-identity", action="store_true", help="Request Tor NEWNYM/change identity through ControlPort")
    parser.add_argument("--tor-menu-identity-test", action="store_true", help="Run Tor menu/right-click identity smoke test")
    parser.add_argument("--tor-user-readable-gui-test", action="store_true", help="Run Tor user-readable GUI/country-label smoke test")
    parser.add_argument("--tor-country-label-sanitization-test", action="store_true", help="Run TOR button country-label sanitization test")
    parser.add_argument("--restore-tor-button", action="store_true", help="Restore visible TOR toolbar/menu controls after a legacy installer hid them")
    parser.add_argument("--tor-button-restore-test", action="store_true", help="Run regression test for visible TOR toolbar/menu controls")
    parser.add_argument("--walletconnect-provider-exact-handoff-test", action="store_true", help="Run provider-to-Wallet exact request handoff test")
    parser.add_argument("--walletconnect-status", action="store_true", help="Print WalletConnect/multi-chain provider status JSON")
    parser.add_argument("--walletconnect-test", action="store_true", help="Run WalletConnect/multi-chain provider smoke test")
    parser.add_argument("--walletconnect-approval-handoff-test", action="store_true", help="Run WalletConnect Browser-to-Wallet approval handoff smoke test")
    parser.add_argument("--wallet-bridge-contract-test", action="store_true", help="Run RC20 Sentinel Wallet bridge compatibility and safety checks")
    parser.add_argument("--wallet-bridge-read-response", help="Read a Sentinel Wallet browser-bridge response by request id")
    parser.add_argument("--phase5q-wallet-bridge-match-test", action="store_true", help="Run RC20 Wallet bridge / Browser / DLG matching checks")
    parser.add_argument("--phase5r-wallet-visibility-crypto-nft-test", action="store_true", help="Run RC20 Wallet toolbar visibility, crypto-only, no-card, and NFT foundation checks")
    parser.add_argument("--phase2-top-assets-wallet-generation-test", action="store_true", help="Run RC20 top assets/blockchains, Solana, USDT/USDC, and wallet generation checks")
    parser.add_argument("--phase3-wallet-passphrase-escrow-test", action="store_true", help="Run RC20 Wallet passphrase escrow browser-safety checks")
    parser.add_argument("--wallet-integration-status", action="store_true", help="Print Sentinel Wallet integration status JSON")
    parser.add_argument("--open-wallet", action="store_true", help="Open Sentinel Wallet explicitly from Browser context")
    parser.add_argument("--permission-status", action="store_true", help="Print Sentinel Browser site permission status JSON")
    parser.add_argument("--hotkey-status", action="store_true", help="Print Sentinel Browser hotkey status JSON")
    parser.add_argument("--content-block-status", action="store_true", help="Print Sentinel Browser content-blocking/fingerprint-defense status JSON")
    parser.add_argument("--security-audit", action="store_true", help="Print Sentinel Browser security audit JSON")
    parser.add_argument("--engine-security-status", action="store_true", help="Print WebKit engine/sandbox security posture JSON")
    parser.add_argument("--security-profile-status", action="store_true", help="Print Sentinel Browser hardened security profile JSON")
    parser.add_argument("--javascript-status", action="store_true", help="Print Sentinel Browser JavaScript and engine security gate JSON")
    parser.add_argument("--search-policy-status", action="store_true", help="Print Sentinel Browser search policy JSON")
    parser.add_argument("--vault-2fa-toolbar-status", action="store_true", help="Print Sentinel Browser Vault 2FA toolbar/manual launcher JSON")
    parser.add_argument("--vault-bridge-status", action="store_true", help="Print Sentinel Browser manual Vault bridge/no-password-storage JSON")
    parser.add_argument("--vault-account-hints-status", action="store_true", help="Print browser-side Vault account-hints JSON; contains no secrets")
    parser.add_argument("--vault-login-prompt-status", action="store_true", help="Print browser-side Vault login prompt JSON; contains no secrets")
    parser.add_argument("--init-javascript-policy", action="store_true", help="Create the default Sentinel Browser JavaScript policy file if missing")
    parser.add_argument("--init-search-policy", action="store_true", help="Create the default Sentinel Browser search policy file if missing")
    parser.add_argument("--init-vault-bridge-policy", action="store_true", help="Create the default Sentinel Browser Vault bridge policy if missing")
    parser.add_argument("--init-vault-account-hints", action="store_true", help="Create the browser-side Vault account-hints file if missing")
    parser.add_argument("--init-vault-login-policy", action="store_true", help="Create the browser-side Vault login prompt policy if missing")
    parser.add_argument("--add-vault-account-hint", help="Add/update a browser-side account hint for a domain; stores no password/TOTP secret")
    parser.add_argument("--account-label", default="", help="Account label for --add-vault-account-hint")
    parser.add_argument("--username-hint", default="", help="Optional username hint for --add-vault-account-hint; not a password")
    parser.add_argument("--revoke-vault-account-hint", help="Remove browser-side Vault account hints for a domain")
    parser.add_argument("--never-vault-login-site", help="Do not show the browser-side Vault login prompt for this domain")
    parser.add_argument("--allow-vault-login-site", help="Allow/show the browser-side Vault login prompt for this domain")
    parser.add_argument("--clear-vault-login-site", help="Clear browser-side Vault login prompt preference for this domain")
    parser.add_argument("--open-vault-2fa", nargs="?", const="", help="Launch restricted Vault-owned 2FA mini popup; optional domain")
    parser.add_argument("--open-vault-password", nargs="?", const="", help="Manually launch Sentinel Password Vault for password/login; optional domain")
    parser.add_argument("--set-default-search-engine", choices=["duckduckgo", "mojeek", "marginalia", "startpage", "google", "bing"], help="Set normal/default search engine")
    parser.add_argument("--set-private-search-engine", choices=["duckduckgo", "mojeek", "marginalia", "startpage", "google", "bing"], help="Set private/incognito search engine")
    parser.add_argument("--set-javascript-profile", choices=["standard", "shield", "lockdown"], help="Set JavaScript security profile")
    parser.add_argument("--allow-javascript-site", help="Add a host to the local JavaScript allow list")
    parser.add_argument("--block-javascript-site", help="Add a host to the local JavaScript block list")
    parser.add_argument("--temp-allow-javascript-site", help="Add a host to the local temporary JavaScript allow list")
    parser.add_argument("--write-aegis-bridge-status", action="store_true", help="Write future AEGIS browser bridge status JSON")
    parser.add_argument("--init-aegis-bridge-policy", action="store_true", help="Create the default AEGIS bridge policy file if missing")
    parser.add_argument("--init-permission-policy", action="store_true", help="Create the default Sentinel Browser site permission policy file if missing")
    parser.add_argument("--init-content-policy", action="store_true", help="Create the default Sentinel Browser content-blocking policy files if missing")
    parser.add_argument("--write-aegis-status", action="store_true")
    parser.add_argument("--doctor", action="store_true")
    parser.add_argument("--safe-mode", action="store_true")
    parser.add_argument("--private", action="store_true", help="Launch a private session without restoring or saving session state")
    parser.add_argument("--reset-config", action="store_true")
    parser.add_argument("--gui-smoke-test", action="store_true")
    parser.add_argument("--clear-browsing-data", action="store_true", help="Clear Sentinel Browser session, WebKit data/cache, and security event state")
    parser.add_argument("--clear-bookmarks", action="store_true", help="Also clear local bookmarks when used with --clear-browsing-data")
    parser.add_argument("--clear-config", action="store_true", help="Also clear config when used with --clear-browsing-data")
    args = parser.parse_args(argv)

    if args.version:
        print(f"{APP_NAME} {VERSION}")
        return 0
    if args.self_test:
        ok, msgs = run_self_test()
        for msg in msgs:
            print(msg)
        print("PASS: self-test" if ok else "FAIL: self-test")
        return 0 if ok else 1
    if args.runtime_check or args.aegis_status:
        print(json.dumps(status_json(), indent=2, sort_keys=True))
        return 0
    if args.download_status:
        print(json.dumps(download_status_json(), indent=2, sort_keys=True))
        return 0
    if args.download_guard_contract_test:
        obj = download_guard_contract_status_json(include_raw=True)
        print(json.dumps(obj, indent=2, sort_keys=True))
        return 0 if obj.get("compatible") else 1
    if args.download_guard_lifecycle_test:
        obj = download_guard_lifecycle_test_json()
        print(json.dumps(obj, indent=2, sort_keys=True))
        return 0 if obj.get("ok") else 1
    if args.preferences_status:
        print(json.dumps(preferences_status_json(), indent=2, sort_keys=True))
        return 0
    if args.release_candidate_status:
        print(json.dumps(release_candidate_status_json(), indent=2, sort_keys=True))
        return 0
    if args.phase5_release_candidate_test:
        obj = phase5_release_candidate_test_json()
        print(json.dumps(obj, indent=2, sort_keys=True))
        return 0 if obj.get("ok") else 1
    if getattr(args, "phase7_wallet_ui_signing_performance_test", False):
        obj = phase7_wallet_ui_signing_performance_test_json()
        print(json.dumps(obj, indent=2, sort_keys=True))
        return 0 if obj.get("ok") else 1
    if args.phase5b_browser_first_test:
        obj = phase5b_browser_first_test_json()
        print(json.dumps(obj, indent=2, sort_keys=True))
        return 0 if obj.get("ok") else 1
    if args.phase5c_download_ux_test:
        obj = phase5c_download_ux_test_json()
        print(json.dumps(obj, indent=2, sort_keys=True))
        return 0 if obj.get("ok") else 1
    if args.clean_debian_standalone_test:
        obj = clean_debian_standalone_test_json()
        print(json.dumps(obj, indent=2, sort_keys=True))
        return 0 if obj.get("ok") else 1
    if args.phase5f_v1_security_gate_test:
        obj = phase5f_v1_security_gate_test_json()
        print(json.dumps(obj, indent=2, sort_keys=True))
        return 0 if obj.get("ok") else 1
    if args.phase5g_indicator_reset_test:
        obj = phase5g_indicator_reset_test_json()
        print(json.dumps(obj, indent=2, sort_keys=True))
        return 0 if obj.get("ok") else 1
    if args.network_settings_status:
        print(json.dumps(network_settings_status_json(), indent=2, sort_keys=True))
        return 0
    if args.phase5h_home_vault_network_test:
        obj = phase5h_home_vault_network_test_json()
        print(json.dumps(obj, indent=2, sort_keys=True))
        return 0 if obj.get("ok") else 1
    if args.homepage_status:
        print(json.dumps(homepage_status_json(), indent=2, sort_keys=True))
        return 0
    if args.homepage_default_test:
        obj = homepage_default_test_json()
        print(json.dumps(obj, indent=2, sort_keys=True))
        return 0 if obj.get("ok") else 1
    if args.homepage_city_status:
        print(json.dumps(homepage_city_status_json(), indent=2, sort_keys=True))
        return 0
    if args.homepage_city_bridge_test:
        obj = homepage_city_bridge_test_json()
        print(json.dumps(obj, indent=2, sort_keys=True))
        return 0 if obj.get("ok") else 1
    if args.homepage_runtime_city_test:
        obj = homepage_runtime_city_test_json()
        print(json.dumps(obj, indent=2, sort_keys=True))
        return 0 if obj.get("ok") else 1
    if args.homepage_widget_saved_city_source_test:
        obj = homepage_widget_saved_city_source_test_json()
        print(json.dumps(obj, indent=2, sort_keys=True))
        return 0 if obj.get("ok") else 1
    if args.bookmark_folders_test:
        obj = bookmark_folders_test_json()
        print(json.dumps(obj, indent=2, sort_keys=True))
        return 0 if obj.get("ok") else 1
    if args.bookmark_drag_toolbar_test:
        obj = bookmark_drag_model_test_json()
        print(json.dumps(obj, indent=2, sort_keys=True))
        return 0 if obj.get("ok") else 1
    if args.phase5i_bookmarks_security_controls_test:
        obj = phase5i_bookmarks_security_controls_test_json()
        print(json.dumps(obj, indent=2, sort_keys=True))
        return 0 if obj.get("ok") else 1
    if args.phase5m_safe_gui_render_recovery_test:
        obj = phase5m_safe_gui_render_recovery_test_json()
        print(json.dumps(obj, indent=2, sort_keys=True))
        return 0 if obj.get("ok") else 1
    if args.phase5n_toolbar_security_pair_test:
        obj = phase5n_toolbar_security_pair_test_json()
        print(json.dumps(obj, indent=2, sort_keys=True))
        return 0 if obj.get("ok") else 1
    if args.phase5o_downloads_page_status_guidance_test:
        obj = phase5o_downloads_page_status_guidance_test_json()
        print(json.dumps(obj, indent=2, sort_keys=True))
        return 0 if obj.get("ok") else 1
    if args.phase5p_bookmarks_wallet_integration_test:
        obj = phase5p_bookmarks_wallet_integration_test_json()
        print(json.dumps(obj, indent=2, sort_keys=True))
        return 0 if obj.get("ok") else 1
    if args.wallet_integration_status:
        print(json.dumps(wallet_integration_status_json(include_raw=True), indent=2, sort_keys=True))
        return 0
    if args.wallet_bridge_status:
        print(json.dumps(wallet_bridge_status_json(include_raw=True), indent=2, sort_keys=True))
        return 0
    if args.wallet_transaction_dapp_status:
        print(json.dumps(wallet_transaction_dapp_status_json(include_raw=True), indent=2, sort_keys=True))
        return 0
    if args.wallet_transaction_dapp_test:
        obj = wallet_transaction_dapp_test_json()
        print(json.dumps(obj, indent=2, sort_keys=True))
        return 0 if obj.get("ok") else 1
    if args.blockchain_provider_status:
        print(json.dumps(blockchain_provider_status_json(include_paths=True), indent=2, sort_keys=True))
        return 0
    if args.blockchain_provider_test:
        obj = blockchain_provider_test_json()
        print(json.dumps(obj, indent=2, sort_keys=True))
        return 0 if obj.get("ok") else 1
    if args.evm_provider_status:
        print(json.dumps(evm_provider_status_json(include_paths=True), indent=2, sort_keys=True))
        return 0
    if args.evm_provider_test:
        obj = evm_provider_test_json()
        print(json.dumps(obj, indent=2, sort_keys=True))
        return 0 if obj.get("ok") else 2
    if args.solana_provider_status:
        print(json.dumps(solana_provider_status_json(include_paths=True), indent=2, sort_keys=True))
        return 0
    if args.solana_provider_test:
        obj = solana_provider_test_json()
        print(json.dumps(obj, indent=2, sort_keys=True))
        return 0 if obj.get("ok") else 2
    if args.native_provider_status:
        print(json.dumps(native_provider_core_status_json(include_paths=True), indent=2, sort_keys=True))
        return 0
    if args.native_provider_test:
        obj = native_provider_core_test_json()
        print(json.dumps(obj, indent=2, sort_keys=True))
        return 0 if obj.get("ok") else 2
    if args.installer_options_status:
        print(json.dumps(installer_options_status_json(), indent=2, sort_keys=True))
        return 0
    if args.tor_status:
        print(json.dumps(tor_routing_status_json(include_paths=True), indent=2, sort_keys=True))
        return 0
    if args.tor_routing_test:
        obj = tor_routing_bridge_test_json()
        print(json.dumps(obj, indent=2, sort_keys=True))
        return 0 if obj.get("ok") else 1
    if args.tor_on:
        print(json.dumps(save_tor_routing(True, "cli"), indent=2, sort_keys=True))
        return 0
    if args.tor_off:
        print(json.dumps(save_tor_routing(False, "cli"), indent=2, sort_keys=True))
        return 0
    if args.tor_control_status:
        print(json.dumps(tor_control_status_json(include_paths=True), indent=2, sort_keys=True))
        return 0
    if args.tor_change_identity:
        print(json.dumps(signal_tor_newnym("cli"), indent=2, sort_keys=True))
        return 0
    if args.tor_menu_identity_test:
        obj = tor_menu_identity_test_json()
        print(json.dumps(obj, indent=2, sort_keys=True))
        return 0 if obj.get("ok") else 2
    if getattr(args, "tor_user_readable_gui_test", False):
        obj = tor_user_readable_gui_test_json()
        print(json.dumps(obj, indent=2, sort_keys=True))
        return 0 if obj.get("ok") else 2
    if getattr(args, "tor_country_label_sanitization_test", False):
        obj = tor_country_label_sanitization_test_json()
        print(json.dumps(obj, indent=2, sort_keys=True))
        return 0 if obj.get("ok") else 2
    if getattr(args, "restore_tor_button", False):
        print(json.dumps(restore_tor_button_config_json("cli"), indent=2, sort_keys=True))
        return 0
    if getattr(args, "tor_button_restore_test", False):
        obj = tor_button_restore_regression_test_json()
        print(json.dumps(obj, indent=2, sort_keys=True))
        return 0 if obj.get("ok") else 2
    if getattr(args, "walletconnect_provider_exact_handoff_test", False):
        obj = walletconnect_provider_exact_handoff_test_json()
        print(json.dumps(obj, indent=2, sort_keys=True))
        return 0 if obj.get("ok") else 2
    if args.walletconnect_status:
        print(json.dumps(walletconnect_status_json(include_paths=True), indent=2, sort_keys=True))
        return 0
    if args.walletconnect_test:
        obj = walletconnect_multichain_test_json()
        print(json.dumps(obj, indent=2, sort_keys=True))
        return 0 if obj.get("ok") else 2
    if getattr(args, "walletconnect_approval_handoff_test", False):
        obj = walletconnect_approval_handoff_test_json()
        print(json.dumps(obj, indent=2, sort_keys=True))
        return 0 if obj.get("ok") else 2
    if args.wallet_bridge_contract_test:
        obj = wallet_bridge_contract_test_json()
        print(json.dumps(obj, indent=2, sort_keys=True))
        return 0 if obj.get("ok") else 1
    if args.wallet_bridge_read_response:
        obj = wallet_bridge_read_response(args.wallet_bridge_read_response)
        print(json.dumps(obj, indent=2, sort_keys=True))
        return 0 if obj.get("ok") else 1
    if args.phase5q_wallet_bridge_match_test:
        obj = phase5q_wallet_bridge_match_test_json()
        print(json.dumps(obj, indent=2, sort_keys=True))
        return 0 if obj.get("ok") else 1
    if args.phase5r_wallet_visibility_crypto_nft_test:
        obj = phase5r_wallet_visibility_crypto_nft_test_json()
        print(json.dumps(obj, indent=2, sort_keys=True))
        return 0 if obj.get("ok") else 1
    if args.phase2_top_assets_wallet_generation_test:
        obj = phase2_top_assets_wallet_generation_test_json()
        print(json.dumps(obj, indent=2, sort_keys=True))
        return 0 if obj.get("ok") else 1
    if args.phase3_wallet_passphrase_escrow_test:
        obj = phase3_wallet_passphrase_escrow_test_json()
        print(json.dumps(obj, indent=2, sort_keys=True))
        return 0 if obj.get("ok") else 1
    if args.open_wallet:
        print(json.dumps(launch_sentinel_wallet("cli"), indent=2, sort_keys=True))
        return 0
    if args.phase4_user_ready_test:
        obj = phase4_user_ready_test_json()
        print(json.dumps(obj, indent=2, sort_keys=True))
        return 0 if obj.get("ok") else 1
    if args.permission_status:
        print(json.dumps(permission_status_json(), indent=2, sort_keys=True))
        return 0
    if args.hotkey_status:
        print(json.dumps(hotkey_status_json(), indent=2, sort_keys=True))
        return 0
    if args.content_block_status:
        print(json.dumps(content_status_json(), indent=2, sort_keys=True))
        return 0
    if args.security_audit:
        print(json.dumps(browser_security_audit_json(), indent=2, sort_keys=True))
        return 0
    if args.engine_security_status:
        print(json.dumps(webkit_engine_security_status_json(), indent=2, sort_keys=True))
        return 0
    if args.security_profile_status:
        print(json.dumps(security_profile_status_json(), indent=2, sort_keys=True))
        return 0
    if args.javascript_status:
        print(json.dumps(javascript_status_json(), indent=2, sort_keys=True))
        return 0
    if args.search_policy_status:
        print(json.dumps(search_policy_status_json(), indent=2, sort_keys=True))
        return 0
    if args.vault_2fa_toolbar_status:
        print(json.dumps(vault_2fa_toolbar_status_json(), indent=2, sort_keys=True))
        return 0
    if args.vault_bridge_status:
        print(json.dumps(vault_bridge_status_json(), indent=2, sort_keys=True))
        return 0
    if args.vault_account_hints_status:
        print(json.dumps(vault_account_hints_status_json(), indent=2, sort_keys=True))
        return 0
    if args.vault_login_prompt_status:
        print(json.dumps(vault_login_prompt_status_json(), indent=2, sort_keys=True))
        return 0
    if args.add_vault_account_hint:
        rec = add_vault_account_hint(args.add_vault_account_hint, args.account_label, args.username_hint)
        print(json.dumps({"added": True, "domain": rec.get("domain"), "account_label": rec.get("account_label"), "secret_values_present": False}, indent=2, sort_keys=True))
        return 0
    if args.revoke_vault_account_hint:
        removed = revoke_vault_account_hint(args.revoke_vault_account_hint)
        print(json.dumps({"removed": removed, "domain": _sanitize_host(args.revoke_vault_account_hint)}, indent=2, sort_keys=True))
        return 0
    if args.never_vault_login_site:
        print(json.dumps(update_vault_login_site_policy(args.never_vault_login_site, "never"), indent=2, sort_keys=True))
        return 0
    if args.allow_vault_login_site:
        print(json.dumps(update_vault_login_site_policy(args.allow_vault_login_site, "allow"), indent=2, sort_keys=True))
        return 0
    if args.clear_vault_login_site:
        print(json.dumps(update_vault_login_site_policy(args.clear_vault_login_site, "clear"), indent=2, sort_keys=True))
        return 0
    if args.open_vault_2fa is not None:
        domain = args.open_vault_2fa or ""
        print(json.dumps(launch_vault_bridge(browser_origin=domain, mode="2fa"), indent=2, sort_keys=True))
        return 0
    if args.open_vault_password is not None:
        domain = args.open_vault_password or ""
        print(json.dumps(launch_vault_bridge(browser_origin=domain, mode="password"), indent=2, sort_keys=True))
        return 0
    if args.set_default_search_engine:
        set_search_engine("default", args.set_default_search_engine)
        print(f"Default search engine set to: {args.set_default_search_engine}")
        return 0
    if args.set_private_search_engine:
        set_search_engine("private", args.set_private_search_engine)
        print(f"Private/incognito search engine set to: {args.set_private_search_engine}")
        return 0
    if args.set_javascript_profile:
        profile = set_javascript_profile(args.set_javascript_profile)
        print(f"JavaScript profile set to: {profile}")
        return 0
    if args.allow_javascript_site:
        update_javascript_site_policy(args.allow_javascript_site, "allow")
        print(f"JavaScript allowed for: {args.allow_javascript_site}")
        return 0
    if args.block_javascript_site:
        update_javascript_site_policy(args.block_javascript_site, "block")
        print(f"JavaScript blocked for: {args.block_javascript_site}")
        return 0
    if args.temp_allow_javascript_site:
        update_javascript_site_policy(args.temp_allow_javascript_site, "temporary_allow")
        print(f"JavaScript temporarily allowed for: {args.temp_allow_javascript_site}")
        return 0
    if args.write_aegis_status:
        save_json(STATUS, status_json())
        print(STATUS)
        return 0
    if args.aegis_bridge_status:
        print(json.dumps(aegis_bridge_status(), indent=2, sort_keys=True))
        return 0
    if args.write_aegis_bridge_status:
        save_json(AEGIS_BRIDGE_STATUS, aegis_bridge_status())
        print(AEGIS_BRIDGE_STATUS)
        return 0
    if args.init_aegis_bridge_policy:
        write_aegis_bridge_policy()
        print(AEGIS_BRIDGE_POLICY)
        return 0
    if args.init_permission_policy:
        write_permission_policy()
        print(PERMISSION_POLICY)
        return 0
    if args.init_content_policy:
        write_content_policy()
        print(CONTENT_POLICY)
        return 0
    if args.init_javascript_policy:
        write_javascript_policy()
        print(JAVASCRIPT_POLICY)
        return 0
    if args.init_search_policy:
        write_search_policy()
        print(SEARCH_POLICY)
        return 0
    if args.init_vault_bridge_policy:
        write_vault_bridge_policy()
        print(VAULT_BRIDGE_POLICY)
        return 0
    if args.init_vault_account_hints:
        write_vault_account_hints()
        print(VAULT_ACCOUNT_HINTS)
        return 0
    if args.init_vault_login_policy:
        write_vault_login_policy()
        print(VAULT_LOGIN_POLICY)
        return 0
    if args.doctor:
        return doctor()
    if args.reset_config:
        return reset_config()
    if args.clear_browsing_data:
        removed = clear_browsing_data(args.clear_bookmarks, args.clear_config)
        print("Cleared Sentinel Browser browsing data.")
        if removed:
            for item in removed:
                print(item)
        else:
            print("No local browsing data was present.")
        return 0
    return run_gui(args)


if __name__ == "__main__":
    raise SystemExit(main())
