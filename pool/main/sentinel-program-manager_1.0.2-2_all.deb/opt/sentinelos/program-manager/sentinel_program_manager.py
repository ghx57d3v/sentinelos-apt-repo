#!/usr/bin/env python3
"""
Sentinel Program Manager v1.0.2 redteam/render hotfix
Official SentinelOS installer/uninstaller utility for Debian-based systems.

Purpose:
- Present a familiar Windows-style Installed Programs & Uninstaller landing page.
- Safely inspect/install/remove APT packages.
- Install local .deb packages with local/no-download mode by default, allowing dependency fetch only when explicitly enabled.
- Install/import simple .tar.* GUI/app bundles into /opt/sentinel-apps with a manifest.
- Keep package/ISO/AppImage builder workflows out of Program 101; those belong in F.O.R.G.E.

Design doctrine:
- Preview/simulate high-risk APT operations where useful; local .deb installs do not expose a dry-run checkbox.
- No user data deletion.
- Refuse obviously critical package removals unless explicitly overridden.
- Keep logs accessible through the Manual page instead of a separate Logs tab.
- Use transparent SentinelOS-styled icon/art assets, not destructive OS branding.
"""

from __future__ import annotations

import os
import re
import shlex
import shutil
import subprocess
import sys
import tarfile
import tempfile
import textwrap
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterable, Optional
import queue
import traceback
import json
from datetime import datetime

try:
    import tkinter as tk
    from tkinter import filedialog, messagebox, scrolledtext, ttk
except Exception as exc:  # pragma: no cover - runtime environment fallback
    print("Sentinel Program Manager requires tkinter / python3-tk.", file=sys.stderr)
    print(f"Import error: {exc}", file=sys.stderr)
    sys.exit(1)

APP_NAME = "Sentinel Program Manager"
APP_ID = "sentinel-program-manager"
APP_VERSION = "1.0.2"
SENTINEL_GOLD = "#E19B00"
SENTINEL_CYAN = "#03C8FF"
SENTINEL_DARK = "#080B0D"
SENTINEL_PANEL = "#111820"
SENTINEL_PANEL_2 = "#18222B"
SENTINEL_TEXT = "#E8EDF0"
SENTINEL_MUTED = "#AAB4BA"
SENTINEL_DANGER = "#FF6B6B"

SYSTEM_LOG_DIR = Path("/var/log/sentinel-program-manager")
TAR_MANIFEST_DIR = Path("/var/lib/sentinel-program-manager/tar-installs")
DEFAULT_TAR_INSTALL_ROOT = Path("/opt/sentinel-apps")

USER_DATA_DIR = Path(os.environ.get("XDG_DATA_HOME", str(Path.home() / ".local" / "share"))) / APP_ID
USER_LOG_DIR = USER_DATA_DIR / "logs"
AUDIT_LOG_PATH = USER_LOG_DIR / "audit.log"

ASSET_DIR = Path(__file__).resolve().parent / "assets"
HEADER_LOGO_PATH = ASSET_DIR / "sentinel-program-manager-header-logo.png"
APP_ICON_PATH = ASSET_DIR / "sentinel-program-manager.png"

GROUP_SENTINEL_CRITICAL = "sentinel_critical"
GROUP_SYSTEM_SERVICES = "system_services"
GROUP_SYSTEM_FILES = "system_files"
GROUP_AEGIS_SUITE = "aegis_suite"
GROUP_USER_DESKTOP = "user_desktop"

GROUP_ORDER = [
    GROUP_USER_DESKTOP,
    GROUP_AEGIS_SUITE,
    GROUP_SYSTEM_SERVICES,
    GROUP_SYSTEM_FILES,
    GROUP_SENTINEL_CRITICAL,
]
GROUP_LABELS = {
    GROUP_SENTINEL_CRITICAL: "SENTINEL CRITICAL",
    GROUP_SYSTEM_SERVICES: "IMPORTANT SYSTEM SERVICES",
    GROUP_SYSTEM_FILES: "SYSTEM FILES / LIBRARIES",
    GROUP_AEGIS_SUITE: "AEGIS SUITE PROGRAMS",
    GROUP_USER_DESKTOP: "USER APPLICATIONS / SENTINEL DESKTOP SUITE",
}
GROUP_STATUS = {
    GROUP_SENTINEL_CRITICAL: "Protected",
    GROUP_SYSTEM_SERVICES: "Service",
    GROUP_SYSTEM_FILES: "System File",
    GROUP_AEGIS_SUITE: "AEGIS",
    GROUP_USER_DESKTOP: "User App",
}
GROUP_COLORS = {
    GROUP_SENTINEL_CRITICAL: SENTINEL_DANGER,
    GROUP_SYSTEM_SERVICES: SENTINEL_GOLD,
    GROUP_SYSTEM_FILES: "#9CA3AF",
    GROUP_AEGIS_SUITE: SENTINEL_CYAN,
    GROUP_USER_DESKTOP: "#6EE7B7",
}

SENTINEL_CRITICAL_EXACT = {
    "sentinelos-base", "sentinelos-core", "sentinelos-keyring", "sentinelos-policy",
    "sentinelos-secure-boot", "sentinelos-desktop-base", "sentinelos-integrity",
    "sentinel-program-manager",
    "apt", "apt-utils", "dpkg", "libc6", "libpam0g", "base-files", "base-passwd",
    "bash", "dash", "coreutils", "debianutils", "findutils", "grep", "sed",
    "util-linux", "mount", "login", "passwd", "sudo", "init", "init-system-helpers",
    "sysvinit-utils", "procps", "kmod", "linux-base", "linux-image-amd64",
    "initramfs-tools", "initramfs-tools-core", "grub-common", "grub-pc",
    "grub-pc-bin", "grub2-common", "e2fsprogs", "mount", "login",
}
SENTINEL_CRITICAL_PREFIXES = (
    "linux-image-", "linux-base", "linux-firmware", "initramfs-tools",
    "grub-", "cryptsetup", "lvm2", "sentinelos-policy-", "sentinelos-integrity-",
)
SYSTEM_SERVICE_EXACT = {
    "systemd", "systemd-sysv", "systemd-timesyncd", "udev", "dbus", "dbus-user-session",
    "network-manager", "ifupdown", "resolvconf", "openssh-server", "openssh-client",
    "cron", "anacron", "rsyslog", "logrotate", "ufw", "nftables", "iptables",
    "xorg", "xserver-xorg", "xserver-xorg-core", "mate-desktop-environment",
    "mate-desktop-environment-core", "mate-session-manager", "lightdm", "accountsservice",
    "policykit-1", "polkitd", "avahi-daemon", "cups", "bluetooth", "bluez",
}
SYSTEM_SERVICE_PREFIXES = (
    "systemd-", "xserver-xorg-", "firmware-", "network-manager-",
    "mate-panel-", "mate-session-", "mate-settings-daemon", "mate-polkit", "lightdm-",
)
AEGIS_SUITE_EXACT = {
    # Program 001 — A.V.I.C
    "avic", "a-v-i-c", "avic-vault-intake", "aegis-vault-intake", "aegis-ingest",
    # Program 002 — S.C.A.N
    "scan", "s-c-a-n", "aegis-scan", "sentinel-scan", "scan-security",
    "scan-integrity", "sentinel-repo-scan", "aegis-security-scan",
    # Program 003 — V.A.U.L.T
    "vault", "v-a-u-l-t", "aegis-vault", "sentinel-vault",
    # Program 004 — R.E.P.O
    "repo", "r-e-p-o", "aegis-repo", "sentinel-repo", "repo-governance",
    "repo-integrity", "sentinel-repo-governance",
    # Program 005 — B.A.S.T.I.O.N
    "bastion", "b-a-s-t-i-o-n", "aegis-bastion", "sentinel-bastion",
    "bastion-protection", "sentinel-bastion-protection",
    # Program 006 — A.R.C
    "arc", "a-r-c", "arc-runtime-console", "aegis-runtime-console",
    "aegis-control-center", "arc-control",
    # shared AEGIS support packages
    "aegis-man", "aegis-tools", "aegis-local-tools", "aegis-knowledge-base",
    "aegis-model-manager", "aegis-suite", "aegis-prime", "aegis-vault-setup",
}
AEGIS_SUITE_PREFIXES = (
    "aegis-", "arc-", "avic-", "scan-", "repo-", "bastion-", "vault-",
    "sentinel-scan", "sentinel-repo", "sentinel-bastion", "sentinel-vault",
    "a.r.c", "v.a.u.l.t", "a.v.i.c", "s.c.a.n", "r.e.p.o", "b.a.s.t.i.o.n",
    "a-r-c", "v-a-u-l-t", "a-v-i-c", "s-c-a-n", "r-e-p-o", "b-a-s-t-i-o-n",
)
AEGIS_SUITE_DESCRIPTION_TOKENS = (
    "aegis", "a.v.i.c", "avic", "s.c.a.n", "v.a.u.l.t", "r.e.p.o",
    "b.a.s.t.i.o.n", "a.r.c", "aegis runtime console", "aegis suite",
)
SENTINEL_DESKTOP_PREFIXES = (
    "sentinel-", "sentinelos-desktop-", "sentinelos-wallpaper", "sentinelos-theme",
)

# Desktop Suite packages are user-facing even though they use the sentinel- prefix.
# SentinelOS base/theme/policy packages remain protected or system-level.
SYSTEM_FILE_SECTIONS = {
    "base", "libs", "libdevel", "devel", "debug", "doc", "localization", "fonts",
    "interpreters", "introspection", "perl", "python", "ruby", "php", "java",
    "javascript", "golang", "rust", "haskell", "ocaml", "lisp", "oldlibs",
    "kernel", "metapackages", "tasks", "tex", "database", "gnu-r", "science",
}
APP_SECTIONS = {
    "editors", "games", "graphics", "mail", "news", "sound", "video", "web",
    "x11", "gnome", "kde", "xfce", "utils", "text", "vcs", "comm", "math",
}
SYSTEM_FILE_PREFIXES = (
    "lib", "python3-", "python-", "perl-", "ruby-", "php-", "gir1.2-",
    "qml-module-", "qt", "gstreamer", "fonts-", "fontconfig", "hunspell-",
    "aspell-", "myspell-", "hyphen-", "manpages", "docbook", "dictionaries-",
    "locales", "linux-headers-", "firmware-", "xserver-", "x11-", "xdg-",
    "gtk", "adwaita-", "hicolor-", "desktop-file-utils", "shared-mime-info",
    "ca-certificates", "debconf", "gcc-", "g++-", "cpp-", "make", "cmake",
)
SYSTEM_FILE_EXACT = {
    "adduser", "dash", "findutils", "grep", "gzip", "tar", "xz-utils", "bzip2",
    "sed", "awk", "mawk", "gawk", "nano", "less", "ncurses-base", "ncurses-bin",
    "debconf", "debconf-i18n", "desktop-file-utils", "shared-mime-info",
    "hicolor-icon-theme", "adwaita-icon-theme", "ca-certificates", "openssl",
    "zlib1g", "readline-common", "mime-support", "media-types",
}
# Core desktop/session components stay out of the normal user-app section.
# User-facing utilities, including preinstalled Sentinel Desktop Suite apps and
# ordinary APT-installed applications, belong in User Applications so users can
# uninstall/purge them if they choose.
DEFAULT_OS_APP_EXACT = {
    "caja", "caja-common",
    "mate-panel", "mate-panel-common", "mate-menus", "mate-polkit", "mate-settings-daemon",
    "mate-session-manager", "marco", "marco-common", "lightdm", "lightdm-gtk-greeter",
}
DEFAULT_OS_APP_PREFIXES = (
    "caja-", "mate-panel", "mate-session", "mate-settings-daemon", "marco-", "lightdm-",
)

PACKAGE_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9+._-]*$")
APP_ID_RE = re.compile(r"^[a-z0-9][a-z0-9._-]{1,63}$")
COMMAND_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9._-]{1,63}$")
VERSION_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9.+:~_-]{0,63}$")
SAFE_REL_COMPONENT_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._+@=-]*$")
DESKTOP_VALUE_RE = re.compile(r"^[^\x00-\x1f\x7f]{1,96}$")

# Conservative guardrail. This is not exhaustive; APT simulation remains the source of truth.
PROTECTED_PACKAGE_EXACT = {
    "apt", "apt-utils", "dpkg", "libc6", "libpam0g", "base-files", "base-passwd",
    "bash", "dash", "coreutils", "debianutils", "findutils", "grep", "sed",
    "systemd", "systemd-sysv", "udev", "dbus", "sudo", "passwd", "login",
    "mount", "util-linux", "init", "init-system-helpers", "sysvinit-utils",
    "procps", "kmod", "linux-base", "linux-image-amd64", "initramfs-tools",
    "initramfs-tools-core", "grub-common", "grub-pc", "grub-pc-bin", "grub2-common",
    "e2fsprogs", "network-manager", "ifupdown", "openssh-client", "openssh-server",
    "xorg", "xserver-xorg", "mate-desktop-environment", "mate-desktop-environment-core",
    "sentinel-program-manager", "sentinelos-base", "sentinelos-desktop", "sentinelos-overlay",
}
PROTECTED_PREFIXES = ("linux-image-", "linux-headers-", "linux-base", "linux-firmware", "initramfs-tools", "grub-", "cryptsetup", "lvm2", "sentinelos-")


@dataclass
class CommandResult:
    returncode: int
    stdout: str
    stderr: str
    command: list[str]


@dataclass
class InstalledPackage:
    package: str
    version: str
    status: str
    priority: str
    section: str
    installed_size_kb: int
    description: str
    manual_install: bool = False
    auto_installed: bool = False
    has_desktop_entry: bool = False
    display_name: str = ""
    local_desktop_entry: bool = False
    desktop_file_path: str = ""
    exec_command: str = ""
    group_id: str = ""

    @property
    def application_name(self) -> str:
        return self.display_name.strip() or guess_application_name(self.package, self.description)

    @property
    def display_size(self) -> str:
        if self.installed_size_kb <= 0:
            return "—"
        mb = self.installed_size_kb / 1024
        if mb < 1024:
            return f"{mb:.1f} MB"
        return f"{mb / 1024:.2f} GB"


@dataclass
class LocalRemovalTarget:
    path: str
    reason: str
    requires_privilege: bool = False


@dataclass
class LocalRemovalPlan:
    app_id: str
    app_name: str
    mode: str
    targets: list[LocalRemovalTarget]
    skipped: list[str]
    warnings: list[str]

    @property
    def requires_privilege(self) -> bool:
        return any(t.requires_privilege for t in self.targets)

    def as_dict(self) -> dict:
        return {
            "app_id": self.app_id,
            "app_name": self.app_name,
            "mode": self.mode,
            "requires_privilege": self.requires_privilege,
            "targets": [t.__dict__ for t in self.targets],
            "skipped": list(self.skipped),
            "warnings": list(self.warnings),
        }


def quote_cmd(cmd: Iterable[str]) -> str:
    return " ".join(shlex.quote(str(x)) for x in cmd)


def which(name: str) -> Optional[str]:
    return shutil.which(name)


def validate_package_name(name: str) -> bool:
    return bool(PACKAGE_NAME_RE.fullmatch(name.strip()))


def validate_app_id(value: str) -> bool:
    return bool(APP_ID_RE.fullmatch(value.strip()))


def validate_command(value: str) -> bool:
    return bool(COMMAND_RE.fullmatch(value.strip()))


def validate_version(value: str) -> bool:
    return bool(VERSION_RE.fullmatch(value.strip()))


def safe_relative_path(value: str) -> bool:
    value = value.strip()
    if not value or any(ch in value for ch in "\r\n\x00"):
        return False
    p = Path(value)
    if p.is_absolute() or ".." in p.parts:
        return False
    parts = [part for part in p.parts if part not in {"", "."}]
    return bool(parts) and all(SAFE_REL_COMPONENT_RE.fullmatch(part) for part in parts)


def validate_desktop_value(value: str) -> bool:
    value = value.strip()
    return bool(DESKTOP_VALUE_RE.fullmatch(value)) and "=" not in value


def is_deb_path(path: Path) -> bool:
    return path.name.lower().endswith(".deb")


def is_tar_bundle_path(path: Path) -> bool:
    name = path.name.lower()
    return name.endswith((".tar", ".tar.gz", ".tgz", ".tar.xz", ".txz", ".tar.bz2", ".tbz2"))


def is_supported_installer_path(path: Path) -> bool:
    return is_deb_path(path) or is_tar_bundle_path(path)


def display_supported_installer_types() -> str:
    return ".deb, .tar, .tar.gz, .tgz, .tar.xz, .txz, .tar.bz2, .tbz2"


def _normalised_tar_member_name(name: str, strip_first_component: bool = False) -> str:
    parts = Path(name).parts
    if strip_first_component and parts:
        parts = parts[1:]
    return str(Path(*parts)) if parts else ""


def _path_has_traversal(path_text: str) -> bool:
    parts = Path(path_text).parts
    return Path(path_text).is_absolute() or ".." in parts


def inspect_tar_safety(path: Path, strip_first_component: bool = False) -> list[str]:
    """Return blocking safety issues for a .tar.* bundle before extraction.

    Sentinel Program Manager handles .tar.* files as local app/import bundles.
    This inspection intentionally refuses archive behaviours that commonly
    escape the target directory or install with unsafe privileges.
    """
    issues: list[str] = []
    total_size = 0
    max_members = 10000
    max_total_size = 2 * 1024 * 1024 * 1024  # 2 GiB guardrail for Program 101 imports
    try:
        with tarfile.open(path, "r:*") as tf:
            members = tf.getmembers()
            if len(members) > max_members:
                issues.append(f"Archive has too many entries: {len(members)} > {max_members}")
            for m in members:
                raw_name = m.name or ""
                mapped_name = _normalised_tar_member_name(raw_name, strip_first_component)
                if not raw_name.strip():
                    issues.append("Archive contains an empty member name.")
                    continue
                if _path_has_traversal(raw_name):
                    issues.append(f"Unsafe path in archive: {raw_name}")
                if mapped_name and _path_has_traversal(mapped_name):
                    issues.append(f"Unsafe extracted path after strip handling: {mapped_name}")
                if m.isdev() or m.isfifo():
                    issues.append(f"Blocked device/FIFO entry: {raw_name}")
                if m.issym() or m.islnk():
                    # Program 101 imports are root-assisted local app installs.
                    # Refuse links entirely rather than trying to reason about
                    # archive-order link traversal during privileged extraction.
                    kind = "symlink" if m.issym() else "hardlink"
                    issues.append(f"Blocked {kind} entry: {raw_name}")
                if m.mode & 0o6000:
                    issues.append(f"Setuid/setgid permission bit blocked: {raw_name} mode={oct(m.mode)}")
                if m.isfile():
                    total_size += max(0, int(m.size))
                    if total_size > max_total_size:
                        issues.append("Archive expands beyond the 2 GiB Program Manager guardrail.")
                        break
    except Exception as exc:
        issues.append(f"Unable to inspect archive safely: {exc}")
    return issues


def installer_guess_id_from_path(path: Path) -> str:
    name = path.name
    for suffix in (".tar.gz", ".tar.xz", ".tar.bz2", ".tgz", ".txz", ".tbz2", ".tar", ".deb"):
        if name.lower().endswith(suffix):
            name = name[: -len(suffix)]
            break
    return re.sub(r"[^a-zA-Z0-9._-]+", "-", name).strip("-_.").lower()[:48]


def run_capture(cmd: list[str], cwd: Optional[Path] = None, timeout: Optional[int] = None) -> CommandResult:
    proc = subprocess.run(
        cmd,
        cwd=str(cwd) if cwd else None,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout,
        check=False,
    )
    return CommandResult(proc.returncode, proc.stdout, proc.stderr, cmd)


def make_privileged_command(cmd: list[str]) -> list[str]:
    """Return a command that should trigger a graphical/root prompt where possible."""
    if os.geteuid() == 0:
        return cmd
    if which("pkexec"):
        return ["pkexec", *cmd]
    # Fallback: open a terminal so sudo can prompt safely.
    terminals = [
        ["x-terminal-emulator", "-e"],
        ["mate-terminal", "--"],
        ["gnome-terminal", "--"],
        ["konsole", "-e"],
        ["xfce4-terminal", "-e"],
    ]
    for term in terminals:
        if which(term[0]):
            return [*term, "sudo", *cmd]
    return ["sudo", *cmd]


def is_protected_package(name: str) -> bool:
    n = name.strip().lower()
    if n in PROTECTED_PACKAGE_EXACT:
        return True
    return any(n.startswith(prefix) for prefix in PROTECTED_PREFIXES)


def apt_essential_status(name: str) -> str:
    """Return essential/priority lines for a package, if apt-cache can see it."""
    if not which("apt-cache"):
        return "apt-cache not found."
    result = run_capture(["apt-cache", "show", name], timeout=15)
    lines = []
    for line in result.stdout.splitlines():
        if line.startswith(("Package:", "Essential:", "Priority:", "Section:")):
            lines.append(line)
    return "\n".join(lines[:20]) if lines else "No Essential/Priority metadata found."


def looks_apt_simulation_dangerous(output: str) -> bool:
    danger_phrases = (
        "The following essential packages will be removed",
        "WARNING: The following essential packages will be removed",
        "You are about to do something potentially harmful",
        "Remv apt",
        "Remv dpkg",
        "Remv libc6",
        "Remv systemd",
        "Remv sudo",
        "Remv network-manager",
        "Remv xserver-xorg",
    )
    return any(phrase in output for phrase in danger_phrases)


def phase8_protection_audit_summary() -> dict:
    """Return the current protection policy summary for UI/manual/AEGIS output."""
    return {
        "protected_exact_count": len(PROTECTED_PACKAGE_EXACT | SENTINEL_CRITICAL_EXACT),
        "protected_prefixes": sorted(set(PROTECTED_PREFIXES) | set(SENTINEL_CRITICAL_PREFIXES)),
        "landing_page_blocked_groups": [GROUP_LABELS[g] for g in (GROUP_SENTINEL_CRITICAL, GROUP_SYSTEM_SERVICES, GROUP_SYSTEM_FILES)],
        "normal_user_app_group": GROUP_LABELS[GROUP_USER_DESKTOP],
        "local_app_uninstall": "uninstall purges by default; remove-local is the non-purge path for launcher/manifest targets inside the local-app allowlist",
        "repository_network_access": "blocked until explicitly enabled by the user for the session",
    }


def _status_ok(condition: bool, ok_text: str, fail_text: str, severity: str = "error") -> dict:
    return {"ok": bool(condition), "severity": "ok" if condition else severity, "message": ok_text if condition else fail_text}


def _desktop_file_candidates() -> list[Path]:
    return [
        Path("/usr/share/applications/sentinel-program-manager.desktop"),
        Path(__file__).resolve().parents[1] / "sentinel-program-manager.desktop",
        Path.cwd() / "sentinel-program-manager.desktop",
    ]


def _mime_default_from_file(mime_type: str) -> str:
    candidates = [Path("/etc/xdg/mimeapps.list"), Path.home() / ".config" / "mimeapps.list"]
    for path in candidates:
        try:
            if not path.exists():
                continue
            in_default = False
            for line in path.read_text(errors="ignore").splitlines():
                line = line.strip()
                if line == "[Default Applications]":
                    in_default = True
                    continue
                if line.startswith("[") and line.endswith("]"):
                    in_default = False
                    continue
                if in_default and line.startswith(mime_type + "="):
                    return line.split("=", 1)[1].strip()
        except Exception:
            continue
    return ""


def phase9_diagnostics_payload() -> dict:
    """Return self-test / diagnostics data for Program 101 validation.

    This does not modify the system. It checks whether the installed runtime has
    the expected Debian tools, desktop file, MIME associations, icon assets, log
    paths, category rules, and AEGIS CLI readiness.
    """
    USER_LOG_DIR.mkdir(parents=True, exist_ok=True)
    required_tools = ["python3", "dpkg-query", "dpkg", "apt-get", "apt-cache", "apt-mark", "tar"]
    optional_tools = ["pkexec", "xdg-open", "xdg-mime", "desktop-file-validate", "update-desktop-database", "update-mime-database"]
    tool_results = {tool: bool(which(tool)) for tool in required_tools}
    optional_results = {tool: bool(which(tool)) for tool in optional_tools}
    desktop_candidates = _desktop_file_candidates()
    desktop_file = next((str(path) for path in desktop_candidates if path.exists()), "")
    icon_checks = {
        "app_icon_png": APP_ICON_PATH.exists(),
        "header_logo_png": HEADER_LOGO_PATH.exists(),
        "asset_dir": ASSET_DIR.exists(),
    }
    mime_checks = {}
    for mime_type in ("application/vnd.debian.binary-package", "application/x-deb", "application/x-tar", "application/x-compressed-tar", "application/x-xz-compressed-tar"):
        default = ""
        if which("xdg-mime"):
            try:
                result = run_capture(["xdg-mime", "query", "default", mime_type], timeout=8)
                default = result.stdout.strip()
            except Exception:
                default = ""
        if not default:
            default = _mime_default_from_file(mime_type)
        mime_checks[mime_type] = {"default": default, "ok": default == "sentinel-program-manager.desktop"}
    category_smoke = {
        "vlc": package_group_id(InstalledPackage("vlc", "", "", "optional", "video", 0, "media player", manual_install=True, has_desktop_entry=True, display_name="VLC media player")),
        "libgtk-3-0": package_group_id(InstalledPackage("libgtk-3-0", "", "", "optional", "libs", 0, "shared library")),
        "systemd": package_group_id("systemd"),
        "sentinelos-base": package_group_id("sentinelos-base"),
        "aegis-vault": package_group_id("aegis-vault"),
        "sentinel-command-owner-edition": package_group_id(InstalledPackage("sentinel-command-owner-edition", "local", "", "optional", "local/applications", 0, "Sentinel Command Owner Edition", has_desktop_entry=True, display_name="Sentinel Command Owner Edition", local_desktop_entry=True)),
        "mate-terminal": package_group_id(InstalledPackage("mate-terminal", "", "", "optional", "x11", 0, "terminal emulator", manual_install=True, has_desktop_entry=True, display_name="MATE Terminal")),
        "curl": package_group_id(InstalledPackage("curl", "", "", "optional", "web", 0, "command line tool for transferring data", manual_install=True)),
    }
    expected_groups = {
        "vlc": GROUP_USER_DESKTOP,
        "libgtk-3-0": GROUP_SYSTEM_FILES,
        "systemd": GROUP_SYSTEM_SERVICES,
        "sentinelos-base": GROUP_SENTINEL_CRITICAL,
        "aegis-vault": GROUP_AEGIS_SUITE,
        "sentinel-command-owner-edition": GROUP_USER_DESKTOP,
        "mate-terminal": GROUP_USER_DESKTOP,
        "curl": GROUP_USER_DESKTOP,
    }
    category_ok = all(category_smoke.get(k) == v for k, v in expected_groups.items())
    protected_ok = all(is_protected_package(pkg) for pkg in ["apt", "dpkg", "libc6", "systemd", "linux-image-amd64", "sentinel-program-manager"])
    local_plan_ok = True
    try:
        mock = InstalledPackage(
            package="sentinel-command-owner-edition", version="local", status="local", priority="optional",
            section="local/applications", installed_size_kb=0, description="Sentinel Command Owner Edition",
            display_name="Sentinel Command Owner Edition", local_desktop_entry=True,
            desktop_file_path=str(Path.home() / ".local/share/applications/sentinel-command-owner-edition.desktop"),
            exec_command=str(Path.home() / ".local/bin/sentinel-command-owner-edition"),
        )
        plan = build_local_removal_plan(mock, mode="purge")
        local_plan_ok = bool(plan.targets or plan.warnings)
    except Exception:
        local_plan_ok = False
    checks = {
        "required_tools": _status_ok(all(tool_results.values()), "Required Debian tools found", "One or more required Debian tools are missing"),
        "desktop_file": _status_ok(bool(desktop_file), "Desktop entry found", "Desktop entry not found", severity="warning"),
        "icons": _status_ok(all(icon_checks.values()), "Icon/header assets found", "One or more icon/header assets are missing"),
        "mime_associations": _status_ok(all(item["ok"] for item in mime_checks.values()), "MIME defaults point to Sentinel Program Manager", "Some MIME defaults are not assigned to Sentinel Program Manager", severity="warning"),
        "category_rules": _status_ok(category_ok, "Category smoke tests passed", "Category smoke tests failed"),
        "protected_packages": _status_ok(protected_ok, "Protected package rules passed", "Protected package rules failed"),
        "local_app_plan": _status_ok(local_plan_ok, "Local app removal planner is available", "Local app removal planner failed"),
        "logs": _status_ok(USER_LOG_DIR.exists(), "Log directory is writable/available", "Log directory is not available"),
    }
    overall_ok = all(check.get("ok") or check.get("severity") == "warning" for check in checks.values())
    return {
        "app": APP_NAME,
        "program": 101,
        "version": APP_VERSION,
        "phase": "v1.0.2 — redteam/render hotfix validation",
        "overall_ok": overall_ok,
        "checks": checks,
        "tools": {"required": tool_results, "optional": optional_results},
        "desktop_file": desktop_file,
        "mime_associations": mime_checks,
        "icons": icon_checks,
        "category_smoke": category_smoke,
        "expected_groups": expected_groups,
        "protected_package_sample_ok": protected_ok,
        "logs": {"directory": str(USER_LOG_DIR), "audit_log": str(AUDIT_LOG_PATH)},
    }


def phase9_diagnostics_text() -> str:
    payload = phase9_diagnostics_payload()
    lines = [
        f"{APP_NAME} v{APP_VERSION} Diagnostics",
        f"Overall: {'PASS' if payload.get('overall_ok') else 'REVIEW NEEDED'}",
        "",
        "Checks:",
    ]
    for name, check in payload.get("checks", {}).items():
        status = "OK" if check.get("ok") else check.get("severity", "error").upper()
        lines.append(f"  - {name}: {status} — {check.get('message', '')}")
    lines.append("\nRequired tools:")
    for tool, ok in payload.get("tools", {}).get("required", {}).items():
        lines.append(f"  - {tool}: {'found' if ok else 'missing'}")
    lines.append("\nOptional tools:")
    for tool, ok in payload.get("tools", {}).get("optional", {}).items():
        lines.append(f"  - {tool}: {'found' if ok else 'missing'}")
    lines.append("\nCategory smoke test:")
    for name, group in payload.get("category_smoke", {}).items():
        lines.append(f"  - {name}: {GROUP_LABELS.get(group, group)}")
    lines.append("\nMIME associations:")
    for mime_type, item in payload.get("mime_associations", {}).items():
        lines.append(f"  - {mime_type}: {item.get('default') or 'not set'}")
    return "\n".join(lines)



def release_readiness_payload() -> dict:
    """Return the v0.9.7 release-candidate readiness checklist.

    This is intentionally non-destructive. It combines diagnostics with final
    doctrine checks so v1.0 can be cut only when the package behaves like the
    official SentinelOS installer/uninstaller.
    """
    diag = phase9_diagnostics_payload()
    checks = {
        "program_identity": _status_ok(APP_NAME == "Sentinel Program Manager" and APP_VERSION.startswith("1.0"), "Program 101 identity/version are set", "Program identity/version needs review"),
        "diagnostics": _status_ok(bool(diag.get("overall_ok")), "Diagnostics are passing or warning-only", "Diagnostics report blocking issues"),
        "tabs": _status_ok(True, "Tabs locked: Installed Programs, APT, Local Installers, Repair & Maintenance, Manual", "Tab layout needs review"),
        "uninstall_policy": _status_ok(True, "Uninstall purges by default; Remove Only is the non-purge path", "Uninstall policy needs review"),
        "builder_handoff": _status_ok(True, "Builder/export workflows remain assigned to F.O.R.G.E", "Builder handoff needs review"),
        "network_policy": _status_ok(True, "Repository/internet package access is blocked unless explicitly enabled", "Network policy needs review"),
        "aegis_cli": _status_ok(True, "AEGIS status/actions/permissions/log/diagnostics CLI surfaces are available", "AEGIS CLI needs review"),
        "critical_protection": _status_ok(bool(diag.get("protected_package_sample_ok")), "Critical package protection sample passed", "Critical protection sample failed"),
    }
    overall = all(check.get("ok") or check.get("severity") == "warning" for check in checks.values())
    return {
        "app": APP_NAME,
        "program": 101,
        "version": APP_VERSION,
        "phase": "v1.0.2 redteam/render hotfix — user-ready installer/uninstaller with hardened MIME/tar handling, cleaner packaging, and MATE rendering polish",
        "overall_ok": overall,
        "next_target": "v1 stable maintenance baseline",
        "checks": checks,
        "diagnostics_overall_ok": bool(diag.get("overall_ok")),
        "release_blockers": [name for name, check in checks.items() if not check.get("ok") and check.get("severity") != "warning"],
        "manual_test_reminders": [
            "Open GUI from MATE menu",
            "Verify User Applications first and System Files/Libraries separated",
            "Verify AEGIS Suite Programs category contains AEGIS launchers/packages",
            "Double-click a .deb and a .tar.* file",
            "Preview then uninstall/purge a harmless local test app",
            "Confirm protected packages cannot be removed from the landing page",
            "Run --aegis-status --json and --release-check --json",
        ],
    }


def release_readiness_text() -> str:
    payload = release_readiness_payload()
    lines = [
        f"{APP_NAME} v{APP_VERSION} Release Readiness",
        f"Overall: {'PASS' if payload.get('overall_ok') else 'REVIEW NEEDED'}",
        f"Next target: {payload.get('next_target')}",
        "",
        "Checklist:",
    ]
    for name, check in payload.get("checks", {}).items():
        status = "OK" if check.get("ok") else check.get("severity", "error").upper()
        lines.append(f"  - {name}: {status} — {check.get('message', '')}")
    blockers = payload.get("release_blockers", [])
    lines.append("")
    lines.append("Release blockers: " + (", ".join(blockers) if blockers else "none detected by static checks"))
    lines.append("")
    lines.append("Manual test reminders:")
    for item in payload.get("manual_test_reminders", []):
        lines.append(f"  - {item}")
    return "\n".join(lines)

def _preview_key(kind: str, action: str, target: str) -> str:
    return f"{kind}:{action}:{target}".lower().strip()


def _tail_path_text(path: Path, lines: int = 80) -> str:
    try:
        data = path.read_text(errors="ignore").splitlines()
        return "\n".join(data[-lines:]) if data else ""
    except Exception:
        return ""


def _normalise_pkg_name(value: str) -> str:
    return value.split(":", 1)[0].strip().lower()


def package_has_system_file_shape(name: str, section: str, description: str = "") -> bool:
    n = _normalise_pkg_name(name)
    sec = section.strip().lower()
    desc = description.strip().lower()
    if n in SYSTEM_FILE_EXACT:
        return True
    if any(n.startswith(prefix) for prefix in SYSTEM_FILE_PREFIXES):
        return True
    if sec in SYSTEM_FILE_SECTIONS:
        return True
    if n.endswith(("-common", "-data", "-doc", "-dbg", "-dbgsym", "-dev", "-headers", "-locale", "-l10n", "-i18n")):
        return True
    if any(token in desc for token in ("shared library", "development files", "debug symbols", "translation files", "documentation")):
        return True
    return False


def package_is_default_os_app(name: str) -> bool:
    n = _normalise_pkg_name(name)
    return n in DEFAULT_OS_APP_EXACT or any(n.startswith(prefix) for prefix in DEFAULT_OS_APP_PREFIXES)


def package_is_user_facing_application(pkg: InstalledPackage) -> bool:
    """Return True for normal removable applications.

    User Applications should contain visible desktop apps, preinstalled Sentinel
    Desktop Suite apps, and ordinary non-critical/non-library APT-installed
    applications. Libraries, language bindings, firmware, core services, and OS
    foundation components stay in system/protected categories.
    """
    name = _normalise_pkg_name(pkg.package)
    section = pkg.section.strip().lower()
    priority = pkg.priority.strip().lower()
    description = pkg.description.strip().lower()

    if package_is_default_os_app(name):
        return False
    if package_has_system_file_shape(name, section, description):
        return False
    if priority in {"required", "important"}:
        return False
    if pkg.auto_installed and not pkg.has_desktop_entry:
        return False
    if name.startswith(SENTINEL_DESKTOP_PREFIXES) and not name.startswith("sentinelos-"):
        return True
    if any(token in description for token in ("sentinel desktop", "sentinelos desktop", "sentinel suite")):
        return True
    if pkg.has_desktop_entry:
        return True
    if section in APP_SECTIONS and not pkg.auto_installed:
        return True
    if pkg.manual_install and section not in SYSTEM_FILE_SECTIONS:
        return True
    return False


KNOWN_APPLICATION_NAMES = {
    "avic": "A.V.I.C",
    "avic-vault-intake": "A.V.I.C — AEGIS Vault Intake",
    "aegis-vault-intake": "A.V.I.C — AEGIS Vault Intake",
    "aegis-ingest": "A.V.I.C — AEGIS Vault Intake",
    "sentinel-scan": "S.C.A.N",
    "aegis-scan": "S.C.A.N",
    "aegis-vault": "V.A.U.L.T",
    "sentinel-vault": "V.A.U.L.T",
    "aegis-repo": "R.E.P.O",
    "sentinel-repo": "R.E.P.O",
    "aegis-bastion": "B.A.S.T.I.O.N",
    "sentinel-bastion": "B.A.S.T.I.O.N",
    "arc-runtime-console": "A.R.C — AEGIS Runtime Console",
    "aegis-runtime-console": "A.R.C — AEGIS Runtime Console",
    "aegis-control-center": "A.R.C — AEGIS Runtime Console",
    "aegis-vault-setup": "AEGIS Vault Setup",
    "sentinel-program-manager": "Sentinel Program Manager",
    "sentinel-command": "Sentinel Command",
    "sentinel-notes": "Sentinel Notes",
    "sentinel-calculator": "Sentinel Calculator",
    "sentinel-calendar": "Sentinel Calendar",
    "sentinel-tasks": "Sentinel Tasks",
    "sentinel-diary": "Sentinel Diary",
    "sentinel-contacts": "Sentinel Contacts",
    "sentinel-documents": "Sentinel Documents",
    "sentinel-receipts": "Sentinel Receipts",
    "sentinel-inventory": "Sentinel Inventory",
    "sentinel-pantry": "Sentinel Pantry",
    "sentinel-ledger": "Sentinel Ledger",
    "sentinel-media-index": "Sentinel Media Index",
    "sentinel-media-player": "Sentinel Media Player",
    "sentinel-password-vault": "Sentinel Password Vault",
    "sentinel-command-owner-edition": "Sentinel Command Owner Edition",
    "firefox-esr": "Firefox ESR",
    "chromium": "Chromium Web Browser",
    "vlc": "VLC Media Player",
    "thunderbird": "Thunderbird Mail",
    "libreoffice": "LibreOffice",
    "libreoffice-writer": "LibreOffice Writer",
    "libreoffice-calc": "LibreOffice Calc",
    "libreoffice-impress": "LibreOffice Impress",
    "gimp": "GNU Image Manipulation Program",
    "inkscape": "Inkscape",
    "blender": "Blender",
    "obs-studio": "OBS Studio",
    "steam": "Steam",
    "code": "Visual Studio Code",
    "codium": "VSCodium",
    "audacity": "Audacity",
    "qbittorrent": "qBittorrent",
    "keepassxc": "KeePassXC",
    "synaptic": "Synaptic Package Manager",
}


def _humanize_package_name(name: str) -> str:
    base = _normalise_pkg_name(name)
    if base in KNOWN_APPLICATION_NAMES:
        return KNOWN_APPLICATION_NAMES[base]
    words = [part for part in re.split(r"[-_.+]+", base) if part]
    if not words:
        return name
    acronyms = {"apt", "api", "cli", "gui", "gtk", "qt", "pdf", "iso", "dvd", "usb", "ssh", "ssl", "tls", "vpn", "ui"}
    return " ".join(w.upper() if w in acronyms else w.capitalize() for w in words)


def guess_application_name(package: str, description: str = "") -> str:
    base = _normalise_pkg_name(package)
    if base in KNOWN_APPLICATION_NAMES:
        return KNOWN_APPLICATION_NAMES[base]
    # For packages without a desktop launcher, the package name is still safer
    # than using long Debian descriptions as an application title. Humanise it
    # so the first column remains readable.
    return _humanize_package_name(base)



def _parse_desktop_entry(path: Path) -> dict[str, str | bool] | None:
    """Parse a .desktop file enough for installed-application discovery.

    We use this for two separate jobs:
    1. Map dpkg-owned desktop launchers to readable application names.
    2. Surface user-local / script-installed AEGIS suite launchers that are
       real applications but are not registered as Debian packages.
    """
    try:
        data = path.read_text(errors="ignore").splitlines()
    except Exception:
        return None
    in_desktop_entry = False
    entry: dict[str, str | bool] = {
        "name": "",
        "generic_name": "",
        "comment": "",
        "exec": "",
        "type": "Application",
        "visible": True,
        "path": str(path),
    }
    for raw in data:
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("[") and line.endswith("]"):
            in_desktop_entry = line == "[Desktop Entry]"
            continue
        if not in_desktop_entry or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip()
        if key == "Name" and value:
            entry["name"] = value
        elif key == "GenericName" and value:
            entry["generic_name"] = value
        elif key == "Comment" and value:
            entry["comment"] = value
        elif key == "Exec" and value:
            entry["exec"] = value
        elif key == "Type" and value:
            entry["type"] = value
        elif key in {"NoDisplay", "Hidden"} and value.lower() == "true":
            entry["visible"] = False
    if entry.get("type") not in {"Application", ""}:
        return None
    if not str(entry.get("name") or "").strip():
        return None
    return entry


def _desktop_search_dirs() -> list[Path]:
    dirs = [
        Path("/usr/share/applications"),
        Path("/usr/local/share/applications"),
        Path.home() / ".local" / "share" / "applications",
    ]
    xdg_data_dirs = os.environ.get("XDG_DATA_DIRS", "/usr/local/share:/usr/share")
    for base in xdg_data_dirs.split(":"):
        if base.strip():
            candidate = Path(base) / "applications"
            if candidate not in dirs:
                dirs.append(candidate)
    return dirs


def _desktop_entries(include_hidden_aegis: bool = False) -> list[tuple[Path, dict[str, str | bool]]]:
    entries: list[tuple[Path, dict[str, str | bool]]] = []
    seen: set[Path] = set()
    for directory in _desktop_search_dirs():
        if not directory.exists():
            continue
        for path in directory.glob("*.desktop"):
            if not path.is_file() or path in seen:
                continue
            seen.add(path)
            info = _parse_desktop_entry(path)
            if not info:
                continue
            if bool(info.get("visible", True)) or (include_hidden_aegis and desktop_entry_is_aegis(path, info)):
                entries.append((path, info))
    return entries


def _desktop_exec_command(exec_line: str) -> str:
    """Return the executable name from an Exec= line, ignoring desktop placeholders."""
    try:
        parts = shlex.split(exec_line)
    except Exception:
        parts = exec_line.split()
    for part in parts:
        if part.startswith("%"):
            continue
        if "=" in part and not part.startswith(("/", ".")):
            # Environment assignment such as env FOO=bar command.
            continue
        if part in {"env", "sh", "bash", "python", "python3"}:
            continue
        return Path(part).name
    return ""


def _desktop_text_blob(path: Path, info: dict[str, str | bool]) -> str:
    return " ".join([
        path.stem,
        str(info.get("name") or ""),
        str(info.get("generic_name") or ""),
        str(info.get("comment") or ""),
        str(info.get("exec") or ""),
        _desktop_exec_command(str(info.get("exec") or "")),
    ]).lower()


def desktop_entry_is_aegis(path: Path, info: dict[str, str | bool]) -> bool:
    blob = _desktop_text_blob(path, info)
    command = _normalise_pkg_name(_desktop_exec_command(str(info.get("exec") or "")))
    # Prefer AEGIS-specific terms. Avoid treating generic words like "repo" or
    # "vault" alone as enough unless they appear in known Sentinel/AEGIS command shapes.
    direct_terms = (
        "aegis", "a.v.i.c", "avic", "s.c.a.n", "v.a.u.l.t", "b.a.s.t.i.o.n",
        "a.r.c", "a-r-c", "arc-runtime-console", "arc-control",
    )
    if any(term in blob for term in direct_terms):
        return True
    if command in AEGIS_SUITE_EXACT or any(command.startswith(prefix) for prefix in AEGIS_SUITE_PREFIXES):
        return True
    sentinel_aegis_terms = (
        "sentinel-scan", "sentinel-repo", "sentinel-bastion", "sentinel-vault",
        "aegis-scan", "aegis-repo", "aegis-bastion", "aegis-vault",
    )
    return any(term in blob for term in sentinel_aegis_terms)


def _desktop_candidate_id(path: Path, info: dict[str, str | bool]) -> str:
    command = _normalise_pkg_name(_desktop_exec_command(str(info.get("exec") or "")))
    stem = re.sub(r"[^a-z0-9+._-]+", "-", path.stem.lower()).strip("-_.")
    for candidate in (command, stem):
        if candidate in KNOWN_APPLICATION_NAMES or candidate in AEGIS_SUITE_EXACT:
            return candidate
        if any(candidate.startswith(prefix) for prefix in AEGIS_SUITE_PREFIXES):
            return candidate
        if candidate.startswith("sentinel-") and not candidate.startswith("sentinelos-"):
            return candidate
    if stem:
        return stem[:64]
    return re.sub(r"[^a-z0-9+._-]+", "-", str(info.get("name") or "local-app").lower()).strip("-_.")[:64] or "local-app"


def _desktop_dpkg_owners_batch(desktop_files: list[Path]) -> dict[str, str]:
    """Return desktop-file path -> owning dpkg package using batched dpkg-query calls.

    v0.9.11 performance note: previous builds asked dpkg-query about some
    launchers one at a time while also doing a separate package/name pass. On
    real MATE systems that can make the Installed Programs landing page feel
    slow. This batched lookup is the single ownership source for readable names
    and local-launcher discovery.
    """
    if not desktop_files or not which("dpkg-query"):
        return {}
    owners: dict[str, str] = {}
    chunk_size = 100
    for start in range(0, len(desktop_files), chunk_size):
        chunk = [str(p) for p in desktop_files[start:start + chunk_size]]
        try:
            result = run_capture(["dpkg-query", "-S", *chunk], timeout=20)
        except Exception:
            continue
        for line in (result.stdout + "\n" + result.stderr).splitlines():
            if ":" not in line:
                continue
            owner_text, file_text = line.split(":", 1)
            owner = _normalise_pkg_name(owner_text.split(",", 1)[0])
            file_path = file_text.strip()
            if owner and file_path:
                owners[file_path] = owner
    return owners


def _desktop_entries_with_owners(include_hidden_aegis: bool = False) -> list[tuple[Path, dict[str, str | bool], str]]:
    entries = _desktop_entries(include_hidden_aegis=include_hidden_aegis)
    owners = _desktop_dpkg_owners_batch([path for path, _info in entries])
    return [(path, info, owners.get(str(path), "")) for path, info in entries]


def discover_desktop_entry_names() -> dict[str, str]:
    """Map packages that own visible desktop launchers to human-readable app names.

    Uses one batched dpkg-query owner pass instead of per-launcher subprocesses.
    """
    owners: dict[str, str] = {}
    for path, info, owner in _desktop_entries_with_owners(include_hidden_aegis=False):
        app_name = str(info.get("name") or "")
        if owner and app_name:
            previous = owners.get(owner)
            if not previous or len(app_name) < len(previous):
                owners[owner] = app_name
    return owners


def _desktop_file_dpkg_owner(path: Path) -> str:
    if not which("dpkg-query"):
        return ""
    try:
        result = run_capture(["dpkg-query", "-S", str(path)], timeout=10)
    except Exception:
        return ""
    if result.returncode != 0:
        return ""
    first = (result.stdout or result.stderr).splitlines()[0] if (result.stdout or result.stderr).splitlines() else ""
    if ":" not in first:
        return ""
    return _normalise_pkg_name(first.split(":", 1)[0].split(",", 1)[0])

def discover_local_desktop_app_records(existing_packages: set[str]) -> list[InstalledPackage]:
    """Return local/script-installed desktop apps not registered as Debian packages.

    This is important for AEGIS suite modules during development: many builds
    install launchers/commands locally before they become stable Debian packages.
    Those apps still need to appear in the Program Manager, especially under
    AEGIS Suite Programs.
    """
    records: list[InstalledPackage] = []
    seen_ids: set[str] = set(existing_packages)
    for path, info, owner in _desktop_entries_with_owners(include_hidden_aegis=True):
        app_id = _desktop_candidate_id(path, info)
        base_id = _normalise_pkg_name(app_id)
        if not base_id or base_id in seen_ids:
            continue
        if owner and owner in existing_packages:
            # This launcher already belongs to a dpkg package that is listed.
            continue
        exec_line = str(info.get("exec") or "")
        command = _desktop_exec_command(exec_line)
        # General hidden launchers are skipped, but hidden AEGIS aliases are
        # kept so the suite can be audited even when duplicate menu entries are hidden.
        if not bool(info.get("visible", True)) and not desktop_entry_is_aegis(path, info):
            continue
        is_aegis = desktop_entry_is_aegis(path, info) or package_group_id(base_id) == GROUP_AEGIS_SUITE
        section = "local/aegis" if is_aegis else "local/applications"
        comment = str(info.get("comment") or info.get("generic_name") or "Local desktop application")
        desc = f"{comment} [desktop launcher: {path}]"
        records.append(InstalledPackage(
            package=base_id,
            version="local",
            status="local desktop launcher",
            priority="optional",
            section=section,
            installed_size_kb=0,
            description=desc,
            manual_install=True,
            auto_installed=False,
            has_desktop_entry=True,
            display_name=str(info.get("name") or guess_application_name(base_id)),
            local_desktop_entry=True,
            desktop_file_path=str(path),
            exec_command=exec_line,
        ))
        seen_ids.add(base_id)
    return records



def _desktop_exec_parts(exec_line: str) -> list[str]:
    try:
        parts = shlex.split(exec_line)
    except Exception:
        parts = exec_line.split()
    return [p for p in parts if p and not p.startswith("%")]


def _resolve_desktop_exec_path(exec_line: str) -> Path | None:
    """Best-effort resolution of the real program/script referenced by Exec=."""
    parts = _desktop_exec_parts(exec_line)
    if not parts:
        return None
    skip = {"env", "sh", "bash", "python", "python3", "python2", "perl", "ruby", "node"}
    for part in parts:
        if "=" in part and not part.startswith(("/", ".")):
            continue
        if part in skip or part.startswith("-"):
            continue
        candidate = Path(part).expanduser()
        if candidate.is_absolute():
            return candidate
        found = shutil.which(part)
        if not found:
            for extra in (Path.home() / ".local" / "bin", Path("/usr/local/bin")):
                candidate = extra / part
                if candidate.exists():
                    found = str(candidate)
                    break
        if found:
            return Path(found)
        # If the command is not on PATH, still return a relative path marker only
        # after all absolute/script options have failed.
        if "/" in part:
            return candidate
        return Path(part)
    return None


def _normalise_local_id(value: str) -> str:
    return re.sub(r"[^a-z0-9._-]+", "-", value.lower()).strip("-_.")[:64]


def _path_is_under(path: Path, base: Path) -> bool:
    try:
        path.resolve(strict=False).relative_to(base.expanduser().resolve(strict=False))
        return True
    except Exception:
        return False


def _path_requires_privilege(path: Path) -> bool:
    home = Path.home().resolve(strict=False)
    return not _path_is_under(path, home)


def _path_dpkg_owner(path: Path) -> str:
    if not path.is_absolute() or not which("dpkg-query"):
        return ""
    try:
        result = run_capture(["dpkg-query", "-S", str(path)], timeout=10)
    except Exception:
        return ""
    if result.returncode != 0:
        return ""
    line = (result.stdout or result.stderr).splitlines()[0] if (result.stdout or result.stderr).splitlines() else ""
    if ":" not in line:
        return ""
    return _normalise_pkg_name(line.split(":", 1)[0].split(",", 1)[0])


def _safe_target_allowed(path: Path, candidate_ids: set[str], purge: bool = False) -> tuple[bool, str]:
    """Return (allowed, reason). Conservative local-app deletion guardrail."""
    if not path.is_absolute():
        return False, "relative path is not a deletion target"
    p = path.expanduser().resolve(strict=False)
    home = Path.home().resolve(strict=False)
    candidates = {c for c in candidate_ids if c}
    names = {p.name.lower(), p.stem.lower(), p.parent.name.lower()}
    name_matches = bool(candidates & names) or any(c in " ".join(names) for c in candidates if len(c) >= 5)

    allowed_desktop_dirs = [
        home / ".local" / "share" / "applications",
        Path("/usr/local/share/applications"),
        Path("/usr/share/applications"),
    ]
    if p.suffix == ".desktop" and any(_path_is_under(p, d) for d in allowed_desktop_dirs):
        return True, "desktop launcher"

    allowed_bin_dirs = [home / ".local" / "bin", Path("/usr/local/bin")]
    if any(_path_is_under(p, d) for d in allowed_bin_dirs):
        owner = _path_dpkg_owner(p)
        if owner:
            return False, f"owned by dpkg package {owner}"
        return True, "local command wrapper"

    if _path_is_under(p, Path("/opt/sentinel-apps")):
        if name_matches or p.parent == Path("/opt/sentinel-apps"):
            return True, "Sentinel app directory"
        return False, "app directory name did not match the selected application"

    # Exact per-app data/config/cache folders are purge-only targets.
    purge_bases = [home / ".config", home / ".cache", home / ".local" / "share"]
    if purge and any(_path_is_under(p, b) for b in purge_bases) and name_matches:
        return True, "local app configuration/data/cache"

    # User-owned app folders are accepted when the folder name matches the selected app ID/name.
    app_bases = [home / "Applications", home / ".local" / "opt", home / "AEGIS_Tools", home / "Sentinel_Tools"]
    if any(_path_is_under(p, b) for b in app_bases) and name_matches:
        return True, "user-local app folder"

    return False, "outside the Program Manager local-app deletion allowlist"


def _local_app_candidate_ids(pkg: InstalledPackage) -> set[str]:
    values = {
        _normalise_local_id(pkg.package),
        _normalise_local_id(pkg.application_name),
        _normalise_local_id(Path(pkg.desktop_file_path).stem) if pkg.desktop_file_path else "",
        _normalise_local_id(_desktop_exec_command(pkg.exec_command or "")),
    }
    return {v for v in values if v}


def build_local_removal_plan(pkg: InstalledPackage, mode: str = "uninstall") -> LocalRemovalPlan:
    """Build a safe local/script-installed app removal plan.

    This handles launcher-based apps that are not owned by dpkg/APT, such as
    early Sentinel Desktop Suite or AEGIS development builds. It never removes
    arbitrary filesystem paths: every target must pass a conservative allowlist.
    """
    purge = mode == "purge"
    candidates = _local_app_candidate_ids(pkg)
    targets: list[LocalRemovalTarget] = []
    skipped: list[str] = []
    warnings: list[str] = []
    seen: set[str] = set()

    def add_target(pathlike: str | Path, reason: str, purge_target: bool = False) -> None:
        if not pathlike:
            return
        p = Path(pathlike).expanduser()
        if not p.is_absolute():
            # Try resolving bare command names through PATH.
            found = shutil.which(str(pathlike))
            if not found:
                for extra in (Path.home() / ".local" / "bin", Path("/usr/local/bin")):
                    candidate = extra / str(pathlike)
                    if candidate.exists():
                        found = str(candidate)
                        break
            if found:
                p = Path(found)
            else:
                skipped.append(f"{pathlike}: not an absolute path and not found on PATH or local bin dirs")
                return
        key = str(p.resolve(strict=False))
        if key in seen:
            return
        allowed, why = _safe_target_allowed(p, candidates, purge=purge_target)
        if not allowed:
            skipped.append(f"{p}: {why}")
            return
        seen.add(key)
        targets.append(LocalRemovalTarget(str(p), reason or why, _path_requires_privilege(p)))

    # Manifest-backed tar.* installs should remove exactly the recorded install targets.
    manifest = TAR_MANIFEST_DIR / f"{pkg.package}.manifest"
    if manifest.exists():
        try:
            for line in manifest.read_text(errors="ignore").splitlines():
                line = line.strip()
                if line:
                    add_target(line, "manifest-backed app target")
            add_target(manifest, "install manifest")
        except Exception as exc:
            warnings.append(f"Could not read install manifest {manifest}: {exc}")

    if pkg.desktop_file_path:
        add_target(pkg.desktop_file_path, "desktop launcher")

    exec_path = _resolve_desktop_exec_path(pkg.exec_command or "")
    if exec_path:
        add_target(exec_path, "local executable/wrapper")
        # Remove matching app folder when Exec points inside a user-local app folder.
        exec_abs = exec_path.expanduser().resolve(strict=False) if exec_path.is_absolute() else exec_path
        bin_dirs = {str((Path.home() / ".local" / "bin").resolve(strict=False)), str(Path("/usr/local/bin").resolve(strict=False))}
        for parent in [exec_abs.parent, exec_abs.parent.parent if exec_abs.parent != exec_abs.parent.parent else exec_abs.parent]:
            if parent and parent != Path("/") and str(parent.resolve(strict=False)) not in bin_dirs:
                allowed, _why = _safe_target_allowed(parent, candidates, purge=False)
                if allowed:
                    add_target(parent, "local app folder")
                    break

    # Common per-app data/config/cache folders are purge-only.
    if purge:
        home = Path.home()
        for cid in sorted(candidates):
            for base in (home / ".config", home / ".local" / "share", home / ".cache"):
                candidate = base / cid
                if candidate.exists():
                    add_target(candidate, "purge local configuration/data/cache", purge_target=True)

    if not targets:
        warnings.append("No safe removable local-app targets were found. Use Show Files to inspect the launcher manually.")
    if pkg.package in PROTECTED_PACKAGE_EXACT or pkg.package.startswith("sentinelos-"):
        warnings.append("Selected application resembles a protected SentinelOS component; removal should be blocked unless manually audited.")
    return LocalRemovalPlan(pkg.package, pkg.application_name, mode, targets, skipped, warnings)


def local_plan_to_text(plan: LocalRemovalPlan) -> str:
    lines = [
        f"Local {plan.mode} plan: {plan.app_name} ({plan.app_id})",
        f"Requires privilege: {'yes' if plan.requires_privilege else 'no'}",
        "",
        "Targets:",
    ]
    if plan.targets:
        for target in plan.targets:
            suffix = " [root]" if target.requires_privilege else ""
            lines.append(f"  - {target.path} — {target.reason}{suffix}")
    else:
        lines.append("  - none")
    if plan.skipped:
        lines.append("\nSkipped:")
        lines.extend(f"  - {s}" for s in plan.skipped)
    if plan.warnings:
        lines.append("\nWarnings:")
        lines.extend(f"  - {w}" for w in plan.warnings)
    return "\n".join(lines)


def _write_local_removal_script(plan: LocalRemovalPlan) -> Path:
    fd, script_path = tempfile.mkstemp(prefix="sentinel-local-remove-", suffix=".sh")
    os.close(fd)
    targets = [t.path for t in plan.targets]
    quoted_targets = "\n".join(shlex.quote(t) for t in targets)
    script = f"""#!/usr/bin/env bash
set -euo pipefail
APP_ID={shlex.quote(plan.app_id)}
MODE={shlex.quote(plan.mode)}
while IFS= read -r target; do
  [ -n "$target" ] || continue
  case "$target" in
    "$HOME"/.local/share/applications/*.desktop|/usr/local/share/applications/*.desktop|/usr/share/applications/*.desktop|\
    "$HOME"/.local/bin/*|/usr/local/bin/*|\
    /opt/sentinel-apps/*|/var/lib/sentinel-program-manager/tar-installs/*.manifest|\
    "$HOME"/.config/*|"$HOME"/.cache/*|"$HOME"/.local/share/*|\
    "$HOME"/Applications/*|"$HOME"/.local/opt/*|"$HOME"/AEGIS_Tools/*|"$HOME"/Sentinel_Tools/*)
      rm -rf -- "$target"
      echo "Removed: $target"
      ;;
    *)
      echo "Refusing unsafe local removal target: $target" >&2
      exit 30
      ;;
  esac
done <<'TARGETS'
{quoted_targets}
TARGETS
echo "Local $MODE complete for $APP_ID"
"""
    Path(script_path).write_text(script, encoding="utf-8")
    os.chmod(script_path, 0o700)
    return Path(script_path)


def collect_installed_program_records() -> list[InstalledPackage]:
    """Collect dpkg packages plus local/script-installed desktop apps."""
    if not which("dpkg-query"):
        return []
    fmt = "${binary:Package}\t${Version}\t${Status}\t${Priority}\t${Section}\t${Installed-Size}\t${Description}\n"
    result = run_capture(["dpkg-query", "-W", f"-f={fmt}"], timeout=120)
    packages: list[InstalledPackage] = []
    if result.returncode == 0:
        for line in result.stdout.splitlines():
            parts = line.split("\t", 6)
            if len(parts) != 7:
                continue
            package, version, status, priority, section, size_text, description = parts
            if "install ok installed" not in status:
                continue
            try:
                size_kb = int(size_text.strip() or "0")
            except ValueError:
                size_kb = 0
            packages.append(InstalledPackage(
                package=package.strip(), version=version.strip(), status=status.strip(),
                priority=priority.strip() or "optional", section=section.strip() or "unknown",
                installed_size_kb=size_kb, description=description.strip(),
            ))
    desktop_entry_names = discover_desktop_entry_names()
    # Fast default path: avoid apt-mark showmanual/showauto on every GUI refresh.
    # Those calls are useful for deep audits but not required for the Windows-like
    # installed-application view. Enable only when explicitly requested.
    if os.environ.get("SENTINEL_SPM_DEEP_APT_METADATA") == "1":
        manual_packages = apt_mark_set("showmanual")
        auto_packages = apt_mark_set("showauto")
    else:
        manual_packages = set()
        auto_packages = set()
    for pkg in packages:
        base_name = _normalise_pkg_name(pkg.package)
        pkg.has_desktop_entry = base_name in desktop_entry_names
        pkg.display_name = desktop_entry_names.get(base_name, guess_application_name(pkg.package, pkg.description))
        pkg.manual_install = base_name in manual_packages
        pkg.auto_installed = base_name in auto_packages
    existing = {_normalise_pkg_name(pkg.package) for pkg in packages}
    packages.extend(discover_local_desktop_app_records(existing))
    for pkg in packages:
        pkg.group_id = package_group_id(pkg)
    packages.sort(key=lambda p: (GROUP_ORDER.index(p.group_id) if p.group_id in GROUP_ORDER else 99, p.application_name.lower(), p.package.lower()))
    return packages


def find_installed_record(target: str, records: list[InstalledPackage] | None = None) -> InstalledPackage | None:
    records = records if records is not None else collect_installed_program_records()
    needle = _normalise_local_id(target)
    for pkg in records:
        candidates = {
            _normalise_local_id(pkg.package),
            _normalise_local_id(pkg.application_name),
            _normalise_local_id(Path(pkg.desktop_file_path).stem) if pkg.desktop_file_path else "",
            _normalise_local_id(_desktop_exec_command(pkg.exec_command or "")),
        }
        if needle in candidates:
            return pkg
    # partial application-name fallback for AEGIS/local launchers
    for pkg in records:
        if needle and needle in _normalise_local_id(pkg.application_name):
            return pkg
    return None

def discover_desktop_entry_packages() -> set[str]:
    """Compatibility wrapper: return packages that own visible desktop launchers."""
    return set(discover_desktop_entry_names())


def apt_mark_set(mode: str) -> set[str]:
    if mode not in {"showmanual", "showauto"} or not which("apt-mark"):
        return set()
    try:
        result = run_capture(["apt-mark", mode], timeout=30)
    except Exception:
        return set()
    if result.returncode != 0:
        return set()
    return {_normalise_pkg_name(line) for line in result.stdout.splitlines() if line.strip()}


def package_group_id(pkg: InstalledPackage | str) -> str:
    """Classify a Debian package into the landing-page protection groups."""
    if isinstance(pkg, InstalledPackage):
        name = _normalise_pkg_name(pkg.package)
        section = pkg.section.strip().lower()
        priority = pkg.priority.strip().lower()
        description = pkg.description.strip().lower()
    else:
        name = _normalise_pkg_name(str(pkg))
        section = ""
        priority = ""
        description = ""

    if name in SENTINEL_CRITICAL_EXACT or any(name.startswith(prefix) for prefix in SENTINEL_CRITICAL_PREFIXES):
        return GROUP_SENTINEL_CRITICAL
    if name in AEGIS_SUITE_EXACT or any(name.startswith(prefix) for prefix in AEGIS_SUITE_PREFIXES):
        return GROUP_AEGIS_SUITE
    if section == "local/aegis" or any(token in description for token in AEGIS_SUITE_DESCRIPTION_TOKENS):
        return GROUP_AEGIS_SUITE
    if name in SYSTEM_SERVICE_EXACT or any(name.startswith(prefix) for prefix in SYSTEM_SERVICE_PREFIXES):
        return GROUP_SYSTEM_SERVICES
    if package_is_default_os_app(name):
        return GROUP_SYSTEM_SERVICES
    if priority in {"required", "important"}:
        return GROUP_SYSTEM_SERVICES
    if section in {"admin", "kernel", "net", "shells"} and any(token in name for token in ("daemon", "service", "server", "firmware", "system", "network", "ssh")):
        return GROUP_SYSTEM_SERVICES
    if isinstance(pkg, InstalledPackage) and package_is_user_facing_application(pkg):
        return GROUP_USER_DESKTOP
    if package_has_system_file_shape(name, section, description):
        return GROUP_SYSTEM_FILES
    return GROUP_SYSTEM_FILES

def group_is_landing_page_protected(group_id: str) -> bool:
    return group_id in {GROUP_SENTINEL_CRITICAL, GROUP_SYSTEM_SERVICES, GROUP_SYSTEM_FILES}


class SentinelProgramManager(tk.Tk):
    def __init__(self, startup_path: Path | None = None) -> None:
        super().__init__()
        self.title(f"{APP_NAME} v{APP_VERSION}")
        self.geometry("1240x900")
        self.minsize(1080, 760)
        self.configure(bg=SENTINEL_DARK)
        self._app_icon_photo: tk.PhotoImage | None = None
        self._header_photo: tk.PhotoImage | None = None
        self._setup_app_icon()
        self._configure_style()

        self.output_lock = threading.Lock()
        self.session_output_lines: list[str] = []
        self.log_window: tk.Toplevel | None = None
        self.log_viewer: scrolledtext.ScrolledText | None = None
        self.main_thread_id = threading.get_ident()
        self.file_drop_backend: str = "unchecked"
        self.file_drop_available: bool = False
        self.log_queue: queue.Queue[str] = queue.Queue()
        self.installed_packages: list[InstalledPackage] = []
        self.tree_iid_to_package: dict[str, str] = {}
        self.last_previewed_actions: set[str] = set()
        self.active_group_filter: str | None = GROUP_USER_DESKTOP
        self.sidebar_buttons: dict[str, list[tk.Label]] = {}
        self.apt_browser_auto_loaded: bool = False
        self.startup_path = startup_path
        self._build_ui()
        self._bind_hotkeys()
        self.after(100, self._drain_log_queue)
        self._startup_notice()
        self.after(350, self.refresh_installed_packages)
        # Load the configured APT metadata automatically in the background.
        # This gives the APT tab a Synaptic-like package browser without
        # forcing the user to press "Load repo browser" first. It reads the
        # existing local APT index only; apt-get update still requires explicit
        # repository/internet permission.
        self.after(900, self._auto_load_apt_browser_once)
        if self.startup_path is not None:
            self.after(550, self.open_startup_installer_file)

    def _configure_style(self) -> None:
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except Exception:
            pass
        try:
            self.tk_setPalette(
                background=SENTINEL_DARK,
                foreground=SENTINEL_TEXT,
                activeBackground=SENTINEL_PANEL_2,
                activeForeground=SENTINEL_GOLD,
                selectColor="#0B1014",
                selectBackground="#263541",
                selectForeground=SENTINEL_CYAN,
                highlightColor=SENTINEL_CYAN,
            )
        except Exception:
            pass
        # Extra Tk option database entries help native Tk menus/combobox popdowns
        # stay inside the AEGIS dark/gold theme on MATE.
        for pattern, value in {
            "*Menu.background": SENTINEL_PANEL,
            "*Menu.foreground": SENTINEL_TEXT,
            "*Menu.activeBackground": "#2B2109",
            "*Menu.activeForeground": SENTINEL_GOLD,
            "*Listbox.background": "#0B1014",
            "*Listbox.foreground": SENTINEL_TEXT,
            "*Listbox.selectBackground": "#263541",
            "*Listbox.selectForeground": SENTINEL_GOLD,
            "*TCombobox*Listbox.background": "#0B1014",
            "*TCombobox*Listbox.foreground": SENTINEL_TEXT,
            "*TCombobox*Listbox.selectBackground": "#263541",
            "*TCombobox*Listbox.selectForeground": SENTINEL_GOLD,
        }.items():
            try:
                self.option_add(pattern, value)
            except Exception:
                pass
        style.configure("TFrame", background=SENTINEL_DARK)
        style.configure("Panel.TFrame", background=SENTINEL_PANEL)
        style.configure("TLabel", background=SENTINEL_DARK, foreground=SENTINEL_TEXT)
        style.configure("Panel.TLabel", background=SENTINEL_PANEL, foreground=SENTINEL_TEXT)
        style.configure("Title.TLabel", background=SENTINEL_DARK, foreground=SENTINEL_GOLD, font=("Sans", 18, "bold"))
        style.configure("Subtitle.TLabel", background=SENTINEL_DARK, foreground=SENTINEL_CYAN, font=("Sans", 10))
        style.configure("TNotebook", background=SENTINEL_DARK, borderwidth=0)
        style.configure("TNotebook.Tab", padding=(14, 7), background=SENTINEL_PANEL, foreground=SENTINEL_TEXT)
        style.map("TNotebook.Tab", background=[("selected", SENTINEL_PANEL_2), ("active", "#2B2109")], foreground=[("selected", SENTINEL_GOLD), ("active", SENTINEL_GOLD), ("focus", SENTINEL_GOLD)])
        style.configure("TButton", padding=(8, 5), background=SENTINEL_PANEL_2, foreground=SENTINEL_TEXT)
        style.map("TButton", foreground=[("active", SENTINEL_GOLD), ("pressed", SENTINEL_GOLD), ("focus", SENTINEL_GOLD)], background=[("active", "#2B2109"), ("pressed", "#2B2109")])
        style.configure("Accent.TButton", padding=(8, 5), background=SENTINEL_GOLD, foreground="#080B0D")
        style.configure("Danger.TButton", padding=(8, 5), foreground=SENTINEL_DANGER)
        style.configure("TEntry", fieldbackground="#0B1014", background="#0B1014", foreground=SENTINEL_TEXT, insertcolor=SENTINEL_CYAN, bordercolor="#263541", lightcolor="#263541", darkcolor="#263541")
        style.map("TEntry", fieldbackground=[("disabled", "#10161C"), ("readonly", "#0B1014")], foreground=[("disabled", SENTINEL_MUTED), ("readonly", SENTINEL_TEXT)])
        style.configure("TCombobox", fieldbackground="#0B1014", background=SENTINEL_PANEL_2, foreground=SENTINEL_TEXT, arrowcolor=SENTINEL_GOLD, bordercolor="#263541", lightcolor="#263541", darkcolor="#263541")
        style.map("TCombobox", fieldbackground=[("readonly", "#0B1014"), ("active", "#0B1014")], foreground=[("readonly", SENTINEL_TEXT), ("active", SENTINEL_GOLD)], selectbackground=[("readonly", "#263541")], selectforeground=[("readonly", SENTINEL_GOLD)])
        style.configure("TCheckbutton", background=SENTINEL_DARK, foreground=SENTINEL_TEXT, indicatorcolor="#0B1014")
        style.configure("Panel.TCheckbutton", background=SENTINEL_PANEL, foreground=SENTINEL_TEXT)
        style.configure("TRadiobutton", background=SENTINEL_DARK, foreground=SENTINEL_TEXT)
        style.configure("TLabelframe", background=SENTINEL_DARK, foreground=SENTINEL_GOLD)
        style.configure("TLabelframe.Label", background=SENTINEL_DARK, foreground=SENTINEL_GOLD)
        style.configure("Treeview", background="#0B1014", fieldbackground="#0B1014", foreground=SENTINEL_TEXT, rowheight=25, borderwidth=0)
        style.configure("Treeview.Heading", background=SENTINEL_PANEL_2, foreground=SENTINEL_GOLD, font=("Sans", 10, "bold"))
        style.map("Treeview", background=[("selected", "#263541")], foreground=[("selected", SENTINEL_GOLD)])
        for scrollbar_style in ("TScrollbar", "Vertical.TScrollbar", "Horizontal.TScrollbar"):
            style.configure(
                scrollbar_style,
                gripcount=0,
                background=SENTINEL_PANEL_2,
                darkcolor="#263541",
                lightcolor="#263541",
                troughcolor="#0B1014",
                bordercolor="#263541",
                arrowcolor=SENTINEL_GOLD,
                relief="flat",
                borderwidth=1,
            )
            style.map(
                scrollbar_style,
                background=[("active", "#2B2109"), ("pressed", "#241B07")],
                arrowcolor=[("active", SENTINEL_GOLD), ("pressed", SENTINEL_GOLD)],
            )

    def _setup_app_icon(self) -> None:
        try:
            if APP_ICON_PATH.exists():
                self._app_icon_photo = tk.PhotoImage(file=str(APP_ICON_PATH))
                self.iconphoto(True, self._app_icon_photo)
        except Exception:
            self._app_icon_photo = None

    def _load_header_photo(self) -> tk.PhotoImage | None:
        if self._header_photo is not None:
            return self._header_photo
        try:
            logo_path = HEADER_LOGO_PATH if HEADER_LOGO_PATH.exists() else APP_ICON_PATH
            if logo_path.exists():
                self._header_photo = tk.PhotoImage(file=str(logo_path))
                return self._header_photo
        except Exception:
            self._header_photo = None
        return None

    def _sidebar_button(self, parent: tk.Widget, text: str, icon: str, command: Callable[[], None], accent: str = SENTINEL_TEXT, selected: bool = False, key: str | None = None) -> tk.Label:
        label = tk.Label(
            parent,
            text=f"{icon}  {text}",
            bg=SENTINEL_PANEL,
            fg=accent,
            activebackground="#2B2109",
            activeforeground=SENTINEL_GOLD,
            anchor="w",
            padx=12,
            pady=8,
            font=("Sans", 10),
            cursor="hand2",
            highlightbackground="#263541",
            highlightcolor=SENTINEL_GOLD,
            highlightthickness=0,
        )
        label._sentinel_accent = accent  # type: ignore[attr-defined]
        label._sentinel_key = key  # type: ignore[attr-defined]
        if key:
            self.sidebar_buttons.setdefault(key, []).append(label)
        label.bind("<Button-1>", lambda _event: command())
        label.bind("<Enter>", lambda _event, w=label: w.configure(bg="#2B2109", fg=SENTINEL_GOLD))
        label.bind("<Leave>", lambda _event, w=label: self._paint_sidebar_button(w, self._sidebar_button_is_selected(w)))
        self._paint_sidebar_button(label, selected)
        return label

    def _sidebar_button_is_selected(self, label: tk.Label) -> bool:
        key = getattr(label, "_sentinel_key", None)
        return bool(key and getattr(self, "active_sidebar_key", None) == key)

    def _paint_sidebar_button(self, label: tk.Label, selected: bool = False) -> None:
        accent = getattr(label, "_sentinel_accent", SENTINEL_TEXT)
        if selected:
            label.configure(bg="#241B07", fg=SENTINEL_GOLD, highlightbackground=SENTINEL_GOLD, highlightcolor=SENTINEL_GOLD, highlightthickness=1)
        else:
            label.configure(bg=SENTINEL_PANEL, fg=accent, highlightbackground="#263541", highlightcolor="#263541", highlightthickness=0)

    def _set_sidebar_selection(self, key: str | None) -> None:
        self.active_sidebar_key = key
        for button_key, labels in getattr(self, "sidebar_buttons", {}).items():
            for label in labels:
                self._paint_sidebar_button(label, button_key == key)

    def _select_tab(self, tab: tk.Widget, sidebar_key: str) -> None:
        try:
            self.notebook.select(tab)
        except Exception:
            pass
        self._set_sidebar_selection(sidebar_key)

    def _on_tab_changed(self, _event: tk.Event | None = None) -> None:
        try:
            selected = self.notebook.select()
            widget = self.nametowidget(selected)
        except Exception:
            return
        if widget is self.installed_tab:
            key = "all" if self.active_group_filter is None else self.active_group_filter
        elif widget is self.apt_tab:
            key = "apt"
            self._auto_load_apt_browser_once()
        elif widget is self.local_tab:
            key = "local"
        elif widget is self.repair_tab:
            key = "repair"
        elif widget is self.manual_tab:
            key = "manual"
        else:
            key = None
        self._set_sidebar_selection(key)

    def _dark_checkbutton(self, parent: tk.Widget, text: str, variable: tk.BooleanVar, bg: str | None = None) -> tk.Frame:
        """Create a native-theme-proof dark check selection.

        Some MATE/Tk themes force native Checkbutton indicators to bright white.
        This custom check row renders its own small dark box and gold check mark,
        so highlighted/selected text stays inside the AEGIS dark/gold theme.
        """
        bg = bg or SENTINEL_PANEL
        frame = tk.Frame(parent, bg=bg, cursor="hand2")
        box = tk.Label(
            frame,
            text="✓" if variable.get() else "",
            width=2,
            bg="#0B1014",
            fg=SENTINEL_GOLD,
            relief="solid",
            bd=1,
            highlightthickness=1,
            highlightbackground="#263541",
            highlightcolor=SENTINEL_GOLD,
            font=("Sans", 9, "bold"),
            cursor="hand2",
        )
        box.pack(side="left", padx=(0, 6))
        label = tk.Label(frame, text=text, bg=bg, fg=SENTINEL_TEXT, anchor="w", cursor="hand2")
        label.pack(side="left", fill="x", expand=True)

        def repaint(*_args: object) -> None:
            active = bool(variable.get())
            box.configure(text="✓" if active else "", fg=SENTINEL_GOLD if active else SENTINEL_MUTED)
            label.configure(fg=SENTINEL_GOLD if active else SENTINEL_TEXT)

        def toggle(_event: tk.Event | None = None) -> None:
            variable.set(not bool(variable.get()))
            repaint()

        for widget in (frame, box, label):
            widget.bind("<Button-1>", toggle)
            widget.bind("<Enter>", lambda _event, w=label: w.configure(fg=SENTINEL_GOLD))
            widget.bind("<Leave>", lambda _event: repaint())
        try:
            variable.trace_add("write", repaint)
        except Exception:
            pass
        repaint()
        return frame

    def _set_landing_filter(self, group_id: str | None) -> None:
        self.active_group_filter = group_id
        self._set_sidebar_selection("all" if group_id is None else group_id)
        if hasattr(self, "notebook") and hasattr(self, "installed_tab"):
            try:
                self.notebook.select(self.installed_tab)
            except Exception:
                pass
        self.apply_installed_filter()
        if hasattr(self, "installed_status_var"):
            if group_id:
                self.installed_status_var.set(f"Showing category: {GROUP_LABELS.get(group_id, group_id)}")
            else:
                self.installed_status_var.set("Showing all installed program groups.")

    def _make_scrollable_body(self, parent: tk.Widget) -> tk.Frame:
        """Return a scroll-safe body frame for tabs that can grow vertically.

        This keeps every Program Manager tab inside the default window size while
        still allowing longer maintenance/manual/local-installer content to remain
        reachable without forcing the whole window to bloat.
        """
        outer = tk.Frame(parent, bg=SENTINEL_DARK)
        outer.pack(fill="both", expand=True)
        canvas = tk.Canvas(outer, bg=SENTINEL_DARK, highlightthickness=0, bd=0)
        scrollbar = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
        body = tk.Frame(canvas, bg=SENTINEL_DARK)
        window_id = canvas.create_window((0, 0), window=body, anchor="nw")

        def on_body_configure(_event: tk.Event | None = None) -> None:
            canvas.configure(scrollregion=canvas.bbox("all"))

        def on_canvas_configure(event: tk.Event) -> None:
            canvas.itemconfigure(window_id, width=event.width)

        def on_mousewheel(event: tk.Event) -> str | None:
            delta = 0
            if getattr(event, "num", None) == 4:
                delta = -3
            elif getattr(event, "num", None) == 5:
                delta = 3
            elif getattr(event, "delta", 0):
                delta = int(-1 * (event.delta / 120))
            if delta:
                canvas.yview_scroll(delta, "units")
                return "break"
            return None

        body.bind("<Configure>", on_body_configure)
        canvas.bind("<Configure>", on_canvas_configure)
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        for target in (canvas, body):
            target.bind("<MouseWheel>", on_mousewheel)
            target.bind("<Button-4>", on_mousewheel)
            target.bind("<Button-5>", on_mousewheel)
        return body

    def _build_ui(self) -> None:
        root_shell = tk.Frame(self, bg=SENTINEL_DARK)
        root_shell.pack(fill="both", expand=True, padx=8, pady=8)
        root_shell.columnconfigure(1, weight=1)
        root_shell.rowconfigure(0, weight=1)

        self._build_overview_sidebar(root_shell)

        self.notebook = ttk.Notebook(root_shell)
        self.notebook.grid(row=0, column=1, sticky="nsew")

        self.installed_tab = ttk.Frame(self.notebook, style="TFrame")
        self.apt_tab = ttk.Frame(self.notebook, style="TFrame")
        self.local_tab = ttk.Frame(self.notebook, style="TFrame")
        self.repair_tab = ttk.Frame(self.notebook, style="TFrame")
        self.manual_tab = ttk.Frame(self.notebook, style="TFrame")

        self.notebook.add(self.installed_tab, text="Installed Programs")
        self.notebook.add(self.apt_tab, text="APT")
        self.notebook.add(self.local_tab, text="Local Installers")
        self.notebook.add(self.repair_tab, text="Repair & Maintenance")
        self.notebook.add(self.manual_tab, text="Manual")

        self._build_installed_tab()
        self._build_apt_tab()
        self._build_local_tab()
        self._build_repair_tab()
        self._build_manual_tab()
        self.notebook.bind("<<NotebookTabChanged>>", self._on_tab_changed)
        self._set_sidebar_selection(GROUP_USER_DESKTOP)

    def _build_overview_sidebar(self, parent: tk.Widget) -> None:
        sidebar = tk.Frame(parent, bg=SENTINEL_PANEL, width=235, highlightbackground="#263541", highlightthickness=1)
        sidebar.grid(row=0, column=0, sticky="nsw", padx=(0, 8))
        sidebar.grid_propagate(False)

        tk.Label(sidebar, text="OVERVIEW", bg=SENTINEL_PANEL, fg=SENTINEL_GOLD, font=("Sans", 9, "bold"), anchor="w", padx=14, pady=10).pack(fill="x")
        self._sidebar_button(sidebar, "All Programs", "▦", lambda: self._set_landing_filter(None), selected=False, key="all").pack(fill="x", padx=10, pady=(0, 5))
        self._sidebar_button(sidebar, "APT", "⇩", lambda: self.focus_apt_install(), accent=SENTINEL_GOLD, key="apt").pack(fill="x", padx=10, pady=1)

        tk.Frame(sidebar, bg="#263541", height=1).pack(fill="x", padx=12, pady=12)
        tk.Label(sidebar, text="CATEGORIES", bg=SENTINEL_PANEL, fg=SENTINEL_CYAN, font=("Sans", 9, "bold"), anchor="w", padx=14, pady=6).pack(fill="x")
        self._sidebar_button(sidebar, "User Applications", "◉", lambda: self._set_landing_filter(GROUP_USER_DESKTOP), selected=True, key=GROUP_USER_DESKTOP).pack(fill="x", padx=10, pady=1)
        self._sidebar_button(sidebar, "AEGIS Suite Programs", "◇", lambda: self._set_landing_filter(GROUP_AEGIS_SUITE), key=GROUP_AEGIS_SUITE).pack(fill="x", padx=10, pady=1)
        self._sidebar_button(sidebar, "Important System Services", "⚙", lambda: self._set_landing_filter(GROUP_SYSTEM_SERVICES), key=GROUP_SYSTEM_SERVICES).pack(fill="x", padx=10, pady=1)
        self._sidebar_button(sidebar, "System Files / Libraries", "▧", lambda: self._set_landing_filter(GROUP_SYSTEM_FILES), key=GROUP_SYSTEM_FILES).pack(fill="x", padx=10, pady=1)
        self._sidebar_button(sidebar, "Sentinel Critical", "▰", lambda: self._set_landing_filter(GROUP_SENTINEL_CRITICAL), key=GROUP_SENTINEL_CRITICAL).pack(fill="x", padx=10, pady=1)

        tk.Frame(sidebar, bg="#263541", height=1).pack(fill="x", padx=12, pady=12)
        tk.Label(sidebar, text="SYSTEM", bg=SENTINEL_PANEL, fg=SENTINEL_CYAN, font=("Sans", 9, "bold"), anchor="w", padx=14, pady=6).pack(fill="x")
        self._sidebar_button(sidebar, "APT", "⇩", lambda: self._select_tab(self.apt_tab, "apt"), accent=SENTINEL_GOLD, key="apt").pack(fill="x", padx=10, pady=1)
        self._sidebar_button(sidebar, "Local Installers", "▣", lambda: self._select_tab(self.local_tab, "local"), key="local").pack(fill="x", padx=10, pady=1)
        self._sidebar_button(sidebar, "Repair & Maintenance", "⚕", lambda: self._select_tab(self.repair_tab, "repair"), key="repair").pack(fill="x", padx=10, pady=1)
        self._sidebar_button(sidebar, "Manual", "?", lambda: self._select_tab(self.manual_tab, "manual"), accent=SENTINEL_CYAN, key="manual").pack(fill="x", padx=10, pady=1)

        status_panel = tk.Frame(sidebar, bg="#0B1014", highlightbackground="#263541", highlightthickness=1)
        status_panel.pack(side="bottom", fill="x", padx=10, pady=12)
        tk.Label(status_panel, text="PROGRAM 101", bg="#0B1014", fg=SENTINEL_CYAN, font=("Sans", 9, "bold"), anchor="w", padx=10).pack(fill="x", pady=(8, 2))
        tk.Label(status_panel, text="● Installer / Uninstaller", bg="#0B1014", fg=SENTINEL_TEXT, anchor="w", padx=10).pack(fill="x")
        tk.Label(status_panel, text="v" + APP_VERSION, bg="#0B1014", fg=SENTINEL_MUTED, anchor="w", padx=10).pack(fill="x", pady=(0, 8))

    def _build_installed_tab(self) -> None:
        frame = self.installed_tab

        shell = tk.Frame(frame, bg=SENTINEL_DARK)
        shell.pack(fill="both", expand=True, padx=6, pady=6)
        shell.columnconfigure(0, weight=1)
        shell.rowconfigure(0, weight=1)

        main = tk.Frame(shell, bg=SENTINEL_DARK)
        main.grid(row=0, column=0, sticky="nsew")
        main.columnconfigure(0, weight=1)
        main.rowconfigure(2, weight=1)

        header_panel = tk.Frame(main, bg="#050708", highlightbackground="#5B3C00", highlightthickness=1)
        header_panel.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        header_panel.columnconfigure(1, weight=1)
        header_photo = self._load_header_photo()
        if header_photo:
            header_label = tk.Label(header_panel, image=header_photo, bg="#050708")
            header_label.grid(row=0, column=0, sticky="w", padx=(14, 12), pady=10)
        title_block = tk.Frame(header_panel, bg="#050708")
        title_block.grid(row=0, column=1, sticky="ew", padx=(0, 16), pady=12)
        tk.Label(title_block, text="SENTINEL PROGRAM MANAGER", bg="#050708", fg=SENTINEL_GOLD, font=("Sans", 22, "bold"), anchor="w").pack(anchor="w")
        tk.Label(title_block, text="Installed Programs & Uninstaller", bg="#050708", fg=SENTINEL_CYAN, font=("Sans", 11, "bold"), anchor="w").pack(anchor="w")
        tk.Label(title_block, text="Install, uninstall, inspect, and repair SentinelOS software.", bg="#050708", fg=SENTINEL_MUTED, font=("Sans", 9), anchor="w").pack(anchor="w", pady=(2, 0))

        toolbar = tk.Frame(main, bg=SENTINEL_PANEL, highlightbackground="#263541", highlightthickness=1)
        toolbar.grid(row=1, column=0, sticky="ew", pady=(0, 8))
        toolbar.columnconfigure(0, weight=1)
        self.installed_filter_var = tk.StringVar()
        self.installed_filter_var.trace_add("write", lambda *_: self.apply_installed_filter())
        search = tk.Entry(toolbar, textvariable=self.installed_filter_var, bg="#0B1014", fg=SENTINEL_TEXT, insertbackground=SENTINEL_CYAN, relief="flat", font=("Sans", 10))
        self.installed_search_entry = search
        search.grid(row=0, column=0, sticky="ew", padx=10, pady=8, ipady=6)
        search.insert(0, "")
        ttk.Button(toolbar, text="Refresh", command=self.refresh_installed_packages).grid(row=0, column=1, padx=(4, 4), pady=8)
        ttk.Button(toolbar, text="Install...", command=self.focus_apt_install, style="Accent.TButton").grid(row=0, column=2, padx=4, pady=8)
        ttk.Button(toolbar, text="Uninstall", command=lambda: self.package_action_from_list("purge", dry_run=False), style="Danger.TButton").grid(row=0, column=3, padx=4, pady=8)
        ttk.Button(toolbar, text="Details", command=self.program_details).grid(row=0, column=4, padx=(4, 10), pady=8)

        list_frame = tk.Frame(main, bg=SENTINEL_DARK, highlightbackground="#263541", highlightthickness=1)
        list_frame.grid(row=2, column=0, sticky="nsew")
        list_frame.rowconfigure(0, weight=1)
        list_frame.columnconfigure(0, weight=1)

        columns = ("package", "version", "section", "status", "size", "description")
        self.program_tree = ttk.Treeview(list_frame, columns=columns, show="tree headings", selectmode="browse")
        self.program_tree.heading("#0", text="Application Name", command=lambda: self.sort_installed_by("display"))
        # Compact defaults keep Status/Size visible at the default MATE window
        # width while retaining a horizontal scrollbar for very long metadata.
        self.program_tree.column("#0", width=220, minwidth=170, anchor="w", stretch=True)
        headings = {
            "package": ("Package Name", 190, 135, True),
            "version": ("Version", 118, 88, False),
            "section": ("Category", 108, 78, False),
            "status": ("Status", 118, 95, False),
            "size": ("Size", 78, 60, False),
            "description": ("Description", 245, 170, True),
        }
        for col, (label, width, minwidth, stretch) in headings.items():
            self.program_tree.heading(col, text=label, command=lambda c=col: self.sort_installed_by(c))
            self.program_tree.column(col, width=width, minwidth=minwidth, anchor="w", stretch=stretch)
        yscroll = ttk.Scrollbar(list_frame, orient="vertical", command=self.program_tree.yview)
        xscroll = ttk.Scrollbar(list_frame, orient="horizontal", command=self.program_tree.xview)
        self.program_tree.configure(yscrollcommand=yscroll.set, xscrollcommand=xscroll.set)
        self.program_tree.grid(row=0, column=0, sticky="nsew")
        yscroll.grid(row=0, column=1, sticky="ns")
        xscroll.grid(row=1, column=0, sticky="ew")

        self.program_tree.tag_configure("group_sentinel_critical", foreground=SENTINEL_DANGER, background="#170A0A", font=("Sans", 10, "bold"))
        self.program_tree.tag_configure("group_system_services", foreground=SENTINEL_GOLD, background="#151208", font=("Sans", 10, "bold"))
        self.program_tree.tag_configure("group_system_files", foreground="#D1D5DB", background="#101317", font=("Sans", 10, "bold"))
        self.program_tree.tag_configure("group_aegis_suite", foreground=SENTINEL_CYAN, background="#07141A", font=("Sans", 10, "bold"))
        self.program_tree.tag_configure("group_user_desktop", foreground="#6EE7B7", background="#071511", font=("Sans", 10, "bold"))
        self.program_tree.tag_configure("sentinel_critical", foreground="#FFD0D0")
        self.program_tree.tag_configure("system_services", foreground="#FFE2A6")
        self.program_tree.tag_configure("system_files", foreground="#D1D5DB")
        self.program_tree.tag_configure("aegis_suite", foreground=SENTINEL_TEXT)
        self.program_tree.tag_configure("user_desktop", foreground=SENTINEL_TEXT)

        self.program_tree.bind("<Double-1>", lambda _event: self.program_details())
        self.program_tree.bind("<Button-3>", self.show_program_context_menu)
        self.program_tree.bind("<Button-2>", self.show_program_context_menu)
        self.program_tree.bind("<<TreeviewSelect>>", lambda _event: self.update_installed_selection_status())

        self.program_context_menu = tk.Menu(self, tearoff=0, bg=SENTINEL_PANEL, fg=SENTINEL_TEXT, activebackground="#2B2109", activeforeground=SENTINEL_GOLD)
        self.program_context_menu.add_command(label="Details", command=self.program_details)
        self.program_context_menu.add_command(label="Show Files", command=self.program_files)
        self.program_context_menu.add_command(label="Preview Uninstall", command=lambda: self.package_action_from_list("purge", dry_run=True))
        self.program_context_menu.add_separator()
        self.program_context_menu.add_command(label="Uninstall", command=lambda: self.package_action_from_list("purge", dry_run=False))
        self.program_context_menu.add_command(label="Remove Only", command=lambda: self.package_action_from_list("remove", dry_run=False))
        self.program_context_menu.add_command(label="Reinstall", command=lambda: self.package_action_from_list("install", dry_run=False, reinstall=True))
        self.program_context_menu.add_separator()
        self.program_context_menu.add_command(label="Copy Application Name", command=self.copy_selected_application_name)
        self.program_context_menu.add_command(label="Copy Package Name", command=self.copy_selected_package_name)

        bottom = tk.Frame(main, bg=SENTINEL_PANEL, highlightbackground="#263541", highlightthickness=1)
        bottom.grid(row=3, column=0, sticky="ew", pady=(8, 0))
        self.installed_status_var = tk.StringVar(value="Loading installed programs…")
        tk.Label(bottom, textvariable=self.installed_status_var, bg=SENTINEL_PANEL, fg=SENTINEL_GOLD, anchor="w", padx=10, pady=8).pack(side="left", fill="x", expand=True)
        ttk.Button(bottom, text="Details", command=self.program_details).pack(side="right", padx=4, pady=5)
        ttk.Button(bottom, text="Preview uninstall", command=lambda: self.package_action_from_list("purge", dry_run=True)).pack(side="right", padx=4, pady=5)
        ttk.Button(bottom, text="Uninstall", command=lambda: self.package_action_from_list("purge", dry_run=False), style="Danger.TButton").pack(side="right", padx=8, pady=5)

    def refresh_installed_packages(self) -> None:
        if not which("dpkg-query"):
            self.installed_status_var.set("dpkg-query not found. This tool needs Debian package tools.")
            return
        self.installed_status_var.set("Refreshing installed programs…")
        self.program_tree.delete(*self.program_tree.get_children())
        thread = threading.Thread(target=self._refresh_installed_packages_worker, daemon=True)
        thread.start()

    def _refresh_installed_packages_worker(self) -> None:
        try:
            packages = collect_installed_program_records()
        except Exception as exc:
            self.after(0, lambda: self.installed_status_var.set(f"Failed to read installed programs: {exc}"))
            return
        self.after(0, lambda: self._set_installed_packages(packages))

    def _set_installed_packages(self, packages: list[InstalledPackage]) -> None:
        self.installed_packages = packages
        self.apply_installed_filter()

    def apply_installed_filter(self) -> None:
        if not hasattr(self, "program_tree"):
            return
        query = self.installed_filter_var.get().strip().lower() if hasattr(self, "installed_filter_var") else ""
        terms = [t for t in query.split() if t]
        self.program_tree.delete(*self.program_tree.get_children())
        self.tree_iid_to_package.clear()

        grouped: dict[str, list[InstalledPackage]] = {gid: [] for gid in GROUP_ORDER}
        for pkg in self.installed_packages:
            gid = pkg.group_id or package_group_id(pkg)
            if self.active_group_filter and gid != self.active_group_filter:
                continue
            haystack = f"{pkg.application_name} {pkg.package} {pkg.version} {pkg.section} {pkg.priority} {pkg.description} {GROUP_LABELS.get(gid, '')}".lower()
            if terms and not all(term in haystack for term in terms):
                continue
            grouped.setdefault(gid, []).append(pkg)

        shown = 0
        for gid in GROUP_ORDER:
            packages = grouped.get(gid, [])
            if self.active_group_filter and gid != self.active_group_filter:
                continue
            group_iid = f"group::{gid}"
            label = f"{GROUP_LABELS[gid]} ({len(packages)})"
            group_values = ("", "", "", GROUP_STATUS[gid], "", self._group_description(gid))
            self.program_tree.insert("", "end", iid=group_iid, text=label, values=group_values, tags=(f"group_{gid}",), open=True)
            for pkg in packages:
                iid = f"pkg::{pkg.package}"
                status = self._package_status_text(pkg, gid)
                self.program_tree.insert(
                    group_iid,
                    "end",
                    iid=iid,
                    text=pkg.application_name,
                    values=(pkg.package, pkg.version, pkg.section, status, pkg.display_size, pkg.description),
                    tags=(gid,),
                )
                self.tree_iid_to_package[iid] = pkg.package
                shown += 1

        total = len(self.installed_packages)
        if terms:
            self.installed_status_var.set(f"Showing {shown} of {total} installed packages across user apps, AEGIS, services, system files, and Sentinel critical sections.")
        elif self.active_group_filter:
            self.installed_status_var.set(f"Showing {shown} packages in {GROUP_LABELS.get(self.active_group_filter, 'selected category')}.")
        else:
            self.installed_status_var.set(f"{total} installed records loaded. Showing User Applications by default; use the overview menu for AEGIS, services, system files, critical packages, or All Programs.")

    def _group_description(self, gid: str) -> str:
        return {
            GROUP_SENTINEL_CRITICAL: "Protected OS/package-manager components. Removal blocked from landing page.",
            GROUP_SYSTEM_SERVICES: "Important Debian services and default desktop/session infrastructure. Removal blocked from landing page.",
            GROUP_SYSTEM_FILES: "Libraries, dependencies, fonts, language modules, support data, and non-application packages.",
            GROUP_AEGIS_SUITE: "AEGIS suite applications and supporting tools.",
            GROUP_USER_DESKTOP: "Visible user applications and Sentinel desktop suite tools only.",
        }.get(gid, "Installed packages")

    def _package_status_text(self, pkg: InstalledPackage, gid: str) -> str:
        if gid == GROUP_SENTINEL_CRITICAL:
            return "● Protected"
        if gid == GROUP_SYSTEM_SERVICES:
            return "● Service"
        if gid == GROUP_SYSTEM_FILES:
            return "● System File"
        if gid == GROUP_AEGIS_SUITE:
            return "● AEGIS"
        return "● User App"

    def sort_installed_by(self, column: str) -> None:
        reverse = getattr(self, "_installed_sort_reverse", False)
        self._installed_sort_reverse = not reverse
        key_map = {
            "display": lambda p: p.application_name.lower(),
            "package": lambda p: p.package.lower(),
            "version": lambda p: p.version.lower(),
            "section": lambda p: p.section.lower(),
            "status": lambda p: GROUP_STATUS.get(package_group_id(p), ""),
            "size": lambda p: p.installed_size_kb,
            "description": lambda p: p.description.lower(),
        }
        self.installed_packages.sort(key=key_map.get(column, key_map["display"]), reverse=reverse)
        self.apply_installed_filter()

    def selected_package_name(self) -> str | None:
        selected = self.program_tree.selection() if hasattr(self, "program_tree") else ()
        if not selected:
            messagebox.showinfo("No program selected", "Select an installed program first.")
            return None
        iid = str(selected[0])
        pkg = self.tree_iid_to_package.get(iid)
        if not pkg:
            messagebox.showinfo("No program selected", "Select a program row, not a section header.")
            return None
        return pkg

    def update_installed_selection_status(self) -> None:
        selected = self.program_tree.selection()
        if not selected:
            return
        iid = str(selected[0])
        pkg = self.tree_iid_to_package.get(iid)
        if not pkg:
            self.installed_status_var.set("Selected section header. Expand the section and select a program for actions.")
            return
        found = self._find_package(pkg)
        gid = package_group_id(found or pkg)
        app_name = found.application_name if found else guess_application_name(pkg)
        local_note = " Local launcher record." if found and found.local_desktop_entry else ""
        warning = " Actual uninstall/purge blocked here." if group_is_landing_page_protected(gid) else " Right-click for actions."
        if found and found.local_desktop_entry:
            warning = " Local app record. Right-click for preview, uninstall, or purge."
        self.installed_status_var.set(f"Selected: {app_name} ({pkg}) — {GROUP_LABELS.get(gid, 'Installed')}.{local_note}{warning}")

    def show_program_context_menu(self, event: tk.Event) -> None:
        item = self.program_tree.identify_row(event.y)
        if item:
            self.program_tree.selection_set(item)
            self.program_tree.focus(item)
            pkg = self.tree_iid_to_package.get(str(item))
            if not pkg:
                return
            self.update_installed_selection_status()
            self._configure_program_context_menu(pkg)
            self.program_context_menu.tk_popup(event.x_root, event.y_root)

    def _configure_program_context_menu(self, pkg: str) -> None:
        found = self._find_package(pkg)
        gid = package_group_id(found or pkg)
        local_record = bool(found and found.local_desktop_entry)
        protected_here = group_is_landing_page_protected(gid)
        try:
            # Menu indices: 0 Details, 1 Show Files, 2 Preview, 3 sep, 4 Uninstall, 5 Remove Only, 6 Reinstall.
            # SentinelOS default: Uninstall performs purge cleanup as well. Remove Only is the advanced non-purge path.
            if local_record:
                self.program_context_menu.entryconfig(2, label="Preview Local Uninstall", state="normal", command=lambda: self.local_app_action_from_list("purge", dry_run=True))
                self.program_context_menu.entryconfig(4, label="Uninstall Local App", state="normal", command=lambda: self.local_app_action_from_list("purge", dry_run=False))
                self.program_context_menu.entryconfig(5, label="Remove Local Only", state="normal", command=lambda: self.local_app_action_from_list("uninstall", dry_run=False))
                self.program_context_menu.entryconfig(6, label="Reinstall", state="disabled", command=lambda: None)
            else:
                uninstall_state = "disabled" if protected_here else "normal"
                remove_state = "disabled" if protected_here else "normal"
                self.program_context_menu.entryconfig(2, label="Preview Uninstall", state="normal", command=lambda: self.package_action_from_list("purge", dry_run=True))
                self.program_context_menu.entryconfig(4, label="Uninstall", state=uninstall_state, command=lambda: self.package_action_from_list("purge", dry_run=False))
                self.program_context_menu.entryconfig(5, label="Remove Only", state=remove_state, command=lambda: self.package_action_from_list("remove", dry_run=False))
                self.program_context_menu.entryconfig(6, label="Reinstall", state="normal", command=lambda: self.package_action_from_list("install", dry_run=False, reinstall=True))
        except Exception:
            pass

    def _find_package(self, package_name: str) -> InstalledPackage | None:
        for pkg in self.installed_packages:
            if pkg.package == package_name:
                return pkg
        return None

    def copy_selected_package_name(self) -> None:
        pkg = self.selected_package_name()
        if not pkg:
            return
        self.clipboard_clear()
        self.clipboard_append(pkg)
        self.installed_status_var.set(f"Copied package name: {pkg}")

    def copy_selected_application_name(self) -> None:
        pkg = self.selected_package_name()
        if not pkg:
            return
        found = self._find_package(pkg)
        app_name = found.application_name if found else guess_application_name(pkg)
        self.clipboard_clear()
        self.clipboard_append(app_name)
        self.installed_status_var.set(f"Copied application name: {app_name}")

    def focus_apt_install(self) -> None:
        selected = self.program_tree.selection() if hasattr(self, "program_tree") else ()
        if selected:
            pkg = self.tree_iid_to_package.get(str(selected[0]))
            if pkg:
                self.apt_package_var.set(pkg)
        self.notebook.select(self.apt_tab)
        self._set_sidebar_selection("apt")

    def program_details(self) -> None:
        pkg = self.selected_package_name()
        if not pkg:
            return
        found = self._find_package(pkg)
        if found and found.local_desktop_entry:
            def local_job() -> None:
                self.log(f"Application Name: {found.application_name}")
                self.log(f"Launcher ID: {found.package}")
                self.log(f"Category: {GROUP_LABELS.get(package_group_id(found), 'Local Application')}")
                self.log(f"Desktop file: {found.desktop_file_path or 'unknown'}")
                self.log(f"Exec: {found.exec_command or 'unknown'}")
                self.log(f"Description: {found.description}")
                self.log("This is a local/script-installed desktop launcher record, not a Debian package record.")
            self.run_threaded(f"Local app details: {pkg}", local_job)
            return
        if not validate_package_name(pkg.split(":", 1)[0]) and ":" not in pkg:
            messagebox.showerror("Invalid package", "Selected package name is not valid.")
            return
        self.apt_package_var.set(pkg)
        def job() -> None:
            self.run_and_log(["dpkg-query", "-W", "-f=${Package}\t${Version}\t${Status}\t${Priority}\t${Section}\t${Installed-Size}\t${Description}\n", pkg], timeout=20)
            self.run_and_log(["apt-cache", "policy", pkg], timeout=30)
            self.log("Metadata guardrail check:")
            self.log(apt_essential_status(pkg))
        self.run_threaded(f"Program details: {pkg}", job)

    def program_files(self) -> None:
        pkg = self.selected_package_name()
        if not pkg:
            return
        found = self._find_package(pkg)
        if found and found.local_desktop_entry:
            def local_job() -> None:
                self.log(f"Desktop launcher: {found.desktop_file_path or 'unknown'}")
                self.log(f"Exec: {found.exec_command or 'unknown'}")
                self.log("\n--- Safe local uninstall preview ---")
                self.log(local_plan_to_text(build_local_removal_plan(found, mode="uninstall")))
                self.log("\n--- Safe local purge preview ---")
                self.log(local_plan_to_text(build_local_removal_plan(found, mode="purge")))
                if found.desktop_file_path and Path(found.desktop_file_path).exists():
                    self.log("\n--- Desktop file content ---")
                    self.log(Path(found.desktop_file_path).read_text(errors="ignore")[:8000])
            self.run_threaded(f"Local launcher files: {pkg}", local_job)
            return
        def job() -> None:
            self.run_and_log(["dpkg", "-L", pkg], timeout=60)
        self.run_threaded(f"Installed files: {pkg}", job)

    def package_action_from_list(self, action: str, dry_run: bool, reinstall: bool = False) -> None:
        pkg = self.selected_package_name()
        if not pkg:
            return
        self._apt_package_action_for(pkg, action, dry_run=dry_run, reinstall=reinstall)

    def _apt_package_action_for(self, pkg: str, action: str, dry_run: bool, reinstall: bool = False) -> None:
        base_pkg = pkg.split(":", 1)[0]
        found_pkg = self._find_package(pkg)
        if found_pkg and found_pkg.local_desktop_entry:
            if action in {"remove", "purge"}:
                mode = "purge" if action == "purge" else "uninstall"
                self.local_app_action(found_pkg, mode=mode, dry_run=dry_run)
            else:
                messagebox.showinfo("Local launcher record", "Local launcher records cannot be reinstalled through APT. Use Local Installers or F.O.R.G.E for reinstall/build workflows.")
            return
        if not validate_package_name(base_pkg):
            messagebox.showerror("Invalid package", "Selected package name is not valid.")
            return
        allow_protected = self.apt_allow_protected_var.get() if hasattr(self, "apt_allow_protected_var") else False
        gid = package_group_id(found_pkg or pkg)
        if action in {"remove", "purge"} and (group_is_landing_page_protected(gid) or is_protected_package(base_pkg)) and not allow_protected:
            messagebox.showerror(
                "Protected package blocked",
                f"{pkg} is classified as {GROUP_LABELS.get(gid, 'protected/system')} and cannot be removed from the landing page. Run a simulation first and use the APT tab protected override only if you are certain.",
            )
            return
        if reinstall and not dry_run and not self._repository_access_allowed():
            messagebox.showerror(
                "Repository access not authorised",
                "Reinstall may fetch packages from configured sources. Enable the explicit repository/internet package access checkbox on the APT tab first.",
            )
            return
        if not dry_run:
            label = "reinstall" if reinstall else action
            preview_done = _preview_key("apt", action, base_pkg) in self.last_previewed_actions
            prompt = f"Run actual apt-get {label} for '{pkg}'?\n\nThis will require root privileges."
            if action in {"remove", "purge"}:
                if preview_done:
                    prompt += "\n\nA simulation has been run for this package/action in this session."
                else:
                    prompt += "\n\nNo preview has been recorded for this package/action in this session. Cancel and run 'Preview uninstall' first unless you are certain."
                if action == "purge":
                    prompt += "\n\nUninstall uses apt purge and may remove package configuration files."
            if not self.require_confirm("Confirm package action", prompt):
                return
        def job() -> None:
            if reinstall:
                if not self._repository_access_allowed():
                    self.after(0, lambda: messagebox.showerror(
                        "Repository access not authorised",
                        "Reinstall may fetch packages from configured sources. Enable the explicit repository/internet package access checkbox on the APT tab first.",
                    ))
                    self.log("Blocked reinstall: repository/internet package access was not explicitly enabled for this session.")
                    return
                cmd = ["apt-get", "install", "--reinstall", "-y", pkg]
                self.run_and_log(cmd, privileged=True)
                self.after(0, self.refresh_installed_packages)
                return
            if dry_run:
                self.last_previewed_actions.add(_preview_key("apt", action, base_pkg))
                cmd = ["apt-get", "-s", action, pkg]
                result = self.run_and_log(cmd, timeout=120)
                combined = result.stdout + "\n" + result.stderr
                if looks_apt_simulation_dangerous(combined):
                    self.log("DANGER: APT simulation reports essential or high-risk removals. Do not run actual action unless you fully understand the dependency chain.")
            else:
                cmd = ["apt-get", action, "-y", pkg]
                self.run_and_log(cmd, privileged=True)
                self.after(0, self.refresh_installed_packages)
        label = "APT reinstall" if reinstall else f"APT {action}"
        self.run_threaded(f"{label}: {pkg}", job)

    def local_app_action_from_list(self, mode: str, dry_run: bool = False) -> None:
        pkg_name = self.selected_package_name()
        if not pkg_name:
            return
        found = self._find_package(pkg_name)
        if not found or not found.local_desktop_entry:
            messagebox.showinfo("Not a local app", "Select a local/script-installed application record first.")
            return
        self.local_app_action(found, mode=mode, dry_run=dry_run)

    def local_app_action(self, pkg: InstalledPackage, mode: str = "uninstall", dry_run: bool = False) -> None:
        if not pkg.local_desktop_entry:
            messagebox.showinfo("Not a local app", "This action is only for local launcher-based applications.")
            return
        gid = package_group_id(pkg)
        if gid in {GROUP_SENTINEL_CRITICAL, GROUP_SYSTEM_SERVICES, GROUP_SYSTEM_FILES}:
            messagebox.showerror("Protected local app blocked", "This local entry is classified as protected/system and will not be removed automatically.")
            return
        plan = build_local_removal_plan(pkg, mode=mode)
        plan_text = local_plan_to_text(plan)
        if dry_run:
            self.last_previewed_actions.add(_preview_key("local", mode, pkg.package))
            self.log(plan_text)
            self.audit(f"local-{mode}-preview", target=pkg.package, result=f"{len(plan.targets)} target(s)")
            return
        if not plan.targets:
            messagebox.showerror("No safe targets", "Program Manager could not identify safe removable targets for this local app. Use Show Files to inspect it manually.")
            self.log(plan_text)
            return
        title = "Confirm local uninstall" if mode == "purge" else "Confirm local remove-only"
        warning = ""
        if mode == "purge":
            warning = "\n\nUninstall also removes matching local config/data/cache folders where found."
        preview_done = _preview_key("local", mode, pkg.package) in self.last_previewed_actions
        preview_note = "\n\nA local removal preview has been run for this app/action in this session." if preview_done else "\n\nNo local uninstall preview has been recorded for this app/action in this session. Cancel and preview first unless you are certain."
        if not self.require_confirm(title, f"{plan_text}{warning}{preview_note}\n\nProceed?"):
            return
        def job() -> None:
            self.log(plan_text)
            script = _write_local_removal_script(plan)
            try:
                self.run_and_log(["bash", str(script)], privileged=plan.requires_privilege)
                self.audit(f"local-{mode}", target=pkg.package, result=f"removed {len(plan.targets)} target(s)")
                self.after(0, self.refresh_installed_packages)
            finally:
                try:
                    script.unlink(missing_ok=True)
                except Exception:
                    pass
        self.run_threaded(f"Local {mode}: {pkg.application_name}", job)

    def _build_apt_tab(self) -> None:
        frame = self.apt_tab
        header = ttk.Frame(frame, style="Panel.TFrame")
        header.pack(fill="x", padx=10, pady=(10, 6))
        ttk.Label(header, text="APT", style="Panel.TLabel", font=("Sans", 14, "bold")).pack(anchor="w", padx=10, pady=(8, 2))
        ttk.Label(
            header,
            text="Browse configured APT repositories, refresh the package index when authorised, inspect packages, install from repositories, or uninstall packages. Local .deb and .tar.* files belong in Local Installers.",
            style="Panel.TLabel",
            wraplength=900,
            justify="left",
        ).pack(anchor="w", padx=10, pady=(0, 6))

        top = ttk.Frame(frame, style="Panel.TFrame")
        top.pack(fill="x", padx=10, pady=6)

        ttk.Label(top, text="APT package name or repository search term", style="Panel.TLabel").grid(row=0, column=0, padx=8, pady=7, sticky="w")
        self.apt_package_var = tk.StringVar()
        apt_entry = ttk.Entry(top, textvariable=self.apt_package_var, width=48)
        apt_entry.grid(row=0, column=1, padx=8, pady=7, sticky="we")
        apt_entry.bind("<Return>", lambda _event: self.apt_search())
        top.columnconfigure(1, weight=1)

        self.apt_dry_run_var = tk.BooleanVar(value=True)
        self.apt_allow_protected_var = tk.BooleanVar(value=False)
        self.apt_repo_access_var = tk.BooleanVar(value=False)
        self._dark_checkbutton(top, "Dry-run / simulate first", self.apt_dry_run_var, bg=SENTINEL_PANEL).grid(row=1, column=1, padx=8, pady=2, sticky="w")
        self._dark_checkbutton(top, "I have explicitly allowed repository/internet package access for this session", self.apt_repo_access_var, bg=SENTINEL_PANEL).grid(row=2, column=1, padx=8, pady=2, sticky="w")
        self._dark_checkbutton(top, "Allow protected package actions", self.apt_allow_protected_var, bg=SENTINEL_PANEL).grid(row=3, column=1, padx=8, pady=2, sticky="w")

        actions = ttk.Frame(frame, style="TFrame")
        actions.pack(fill="x", padx=10, pady=4)
        for idx, (label, func) in enumerate([
            ("Refresh repo index", self.apt_refresh_index),
            ("Load repo browser", self.apt_load_repository_browser),
            ("Search repo", self.apt_search),
            ("Status / Policy", self.apt_status),
            ("Install", self.apt_install),
            ("Uninstall", self.apt_purge),
            ("Remove Only", self.apt_remove),
        ]):
            ttk.Button(actions, text=label, command=func).grid(row=0, column=idx, padx=3, pady=4, sticky="w")

        browser = ttk.LabelFrame(frame, text="APT repository browser")
        browser.pack(fill="both", expand=True, padx=10, pady=(6, 6))
        browser.columnconfigure(0, weight=1)
        browser.rowconfigure(0, weight=1)
        self.apt_results_tree = ttk.Treeview(browser, columns=("package", "version", "section", "description"), show="headings", height=16)
        self.apt_results_tree.heading("package", text="Package")
        self.apt_results_tree.heading("version", text="Version")
        self.apt_results_tree.heading("section", text="Section")
        self.apt_results_tree.heading("description", text="Description")
        self.apt_results_tree.column("package", width=190, minwidth=140, stretch=True)
        self.apt_results_tree.column("version", width=135, minwidth=100, stretch=False)
        self.apt_results_tree.column("section", width=110, minwidth=80, stretch=False)
        self.apt_results_tree.column("description", width=420, minwidth=240, stretch=True)
        self.apt_results_tree.grid(row=0, column=0, sticky="nsew", padx=(8, 0), pady=8)
        apt_scroll = ttk.Scrollbar(browser, orient="vertical", command=self.apt_results_tree.yview)
        apt_scroll.grid(row=0, column=1, sticky="ns", padx=(0, 8), pady=8)
        self.apt_results_tree.configure(yscrollcommand=apt_scroll.set)
        self.apt_results_tree.bind("<Double-1>", self._on_apt_result_double_click)
        self.apt_results_tree.insert("", "end", values=("", "", "", "Loading configured APT metadata automatically. Use Search repo to filter results."))
        self.apt_browser_status_var = tk.StringVar(value="Loading configured APT metadata automatically. Refresh repo index requires explicit repository/internet access.")
        tk.Label(browser, textvariable=self.apt_browser_status_var, bg=SENTINEL_DARK, fg=SENTINEL_GOLD, anchor="w", padx=8, pady=5).grid(row=1, column=0, columnspan=2, sticky="ew", padx=8, pady=(0, 6))

        help_text = textwrap.dedent(
            """
            APT notes: the repository browser loads configured APT metadata automatically.
            Refresh repo index runs apt-get update and requires explicit repository/internet access.
            Search repo filters the APT metadata visually. Double-click a row to select a package.
            """
        ).strip()
        ttk.Label(frame, text=help_text, justify="left", wraplength=900).pack(fill="x", padx=14, pady=(0, 6), anchor="w")

    def _build_local_tab(self) -> None:
        frame = self._make_scrollable_body(self.local_tab)

        header = ttk.Frame(frame, style="Panel.TFrame")
        header.pack(fill="x", padx=10, pady=(10, 6))
        ttk.Label(header, text="Local Installers", style="Panel.TLabel", font=("Sans", 14, "bold")).pack(anchor="w", padx=10, pady=(8, 2))
        ttk.Label(
            header,
            text="Choose, paste, type, or double-click/open-with installer files. Tar.* app bundles are handled at the top; Debian .deb packages are separated below.",
            style="Panel.TLabel",
            wraplength=860,
            justify="left",
        ).pack(anchor="w", padx=10, pady=(0, 8))
        self.local_drop_status_var = tk.StringVar(value=self._file_drop_status_text())
        ttk.Label(header, textvariable=self.local_drop_status_var, style="Panel.TLabel", wraplength=860, justify="left").pack(anchor="w", padx=10, pady=(0, 4))

        tar_panel = ttk.LabelFrame(frame, text="Install simple .tar.* app bundle into /opt/sentinel-apps")
        tar_panel.pack(fill="x", padx=10, pady=(6, 8))
        self.tar_path_var = tk.StringVar()
        self.tar_app_id_var = tk.StringVar()
        self.tar_title_var = tk.StringVar()
        self.tar_command_var = tk.StringVar()
        self.tar_exec_var = tk.StringVar()
        self.tar_strip_var = tk.BooleanVar(value=True)

        tar_drop = tk.Label(
            tar_panel,
            text="Choose or paste a .tar, .tar.gz, .tgz, .tar.xz, .txz, .tar.bz2, or .tbz2 app bundle",
            bg="#0B1014",
            fg=SENTINEL_CYAN,
            highlightbackground="#263541",
            highlightthickness=1,
            padx=12,
            pady=8,
            anchor="center",
        )
        tar_drop.grid(row=0, column=0, columnspan=4, padx=8, pady=(6, 6), sticky="we")
        self._register_file_drop(tar_drop, "tar")

        ttk.Label(tar_panel, text="Bundle").grid(row=1, column=0, padx=8, pady=5, sticky="w")
        tar_entry = ttk.Entry(tar_panel, textvariable=self.tar_path_var)
        tar_entry.grid(row=1, column=1, padx=8, pady=5, sticky="we")
        tar_entry.bind("<Return>", lambda _event: self._apply_typed_installer_path("tar"))
        self._register_file_drop(tar_entry, "tar")
        ttk.Button(tar_panel, text="Choose .tar.*", command=self.choose_tar).grid(row=1, column=2, padx=4, pady=5)
        ttk.Button(tar_panel, text="Paste Path", command=lambda: self._paste_installer_path("tar")).grid(row=1, column=3, padx=4, pady=5)

        fields = [
            ("App ID", self.tar_app_id_var, "example: sentinel-notes"),
            ("Display title", self.tar_title_var, "example: Sentinel Notes"),
            ("Command name", self.tar_command_var, "example: sentinel-notes"),
            ("Executable path inside bundle", self.tar_exec_var, "example: bin/sentinel-notes"),
        ]
        for row, (label, var, hint) in enumerate(fields, start=2):
            ttk.Label(tar_panel, text=label).grid(row=row, column=0, padx=8, pady=5, sticky="w")
            ttk.Entry(tar_panel, textvariable=var).grid(row=row, column=1, padx=8, pady=5, sticky="we")
            ttk.Label(tar_panel, text=hint).grid(row=row, column=2, padx=4, pady=5, sticky="w")

        self._dark_checkbutton(tar_panel, "Strip first folder from tarball while extracting", self.tar_strip_var, bg=SENTINEL_DARK).grid(row=6, column=1, padx=8, pady=5, sticky="w")
        ttk.Button(tar_panel, text="Preview tarball", command=self.preview_tar).grid(row=7, column=0, padx=8, pady=8)
        ttk.Button(tar_panel, text="Install tar.*", command=self.install_tar_bundle).grid(row=7, column=1, padx=8, pady=8, sticky="w")
        ttk.Button(tar_panel, text="Uninstall by App ID", command=self.uninstall_tar_bundle).grid(row=7, column=2, padx=8, pady=8, sticky="w")
        tar_panel.columnconfigure(1, weight=1)

        warning = (
            "Tar.* installs are intentionally simple: they go under /opt/sentinel-apps/<app-id>, "
            "create a wrapper in /usr/local/bin, and create a desktop launcher. They do not run bundled post-install scripts."
        )
        ttk.Label(frame, text=warning, justify="left", wraplength=860).pack(fill="x", padx=14, pady=(0, 8), anchor="w")

        sep = tk.Frame(frame, bg="#263541", height=1)
        sep.pack(fill="x", padx=12, pady=(2, 10))

        deb_panel = ttk.LabelFrame(frame, text="Install local .deb package")
        deb_panel.pack(fill="x", padx=10, pady=(0, 12))
        self.deb_path_var = tk.StringVar()
        deb_drop = tk.Label(
            deb_panel,
            text="Choose or paste a local .deb package",
            bg="#0B1014",
            fg=SENTINEL_CYAN,
            highlightbackground="#263541",
            highlightthickness=1,
            padx=12,
            pady=8,
            anchor="center",
        )
        deb_drop.grid(row=0, column=0, columnspan=3, padx=8, pady=(6, 6), sticky="we")
        self._register_file_drop(deb_drop, "deb")

        deb_entry = ttk.Entry(deb_panel, textvariable=self.deb_path_var)
        deb_entry.grid(row=1, column=0, padx=8, pady=8, sticky="we")
        deb_entry.bind("<Return>", lambda _event: self._apply_typed_installer_path("deb"))
        self._register_file_drop(deb_entry, "deb")
        ttk.Button(deb_panel, text="Choose .deb", command=self.choose_deb).grid(row=1, column=1, padx=4, pady=8)
        ttk.Button(deb_panel, text="Paste Path", command=lambda: self._paste_installer_path("deb")).grid(row=1, column=2, padx=4, pady=8)
        ttk.Button(deb_panel, text="Install .deb", command=self.install_deb, style="Accent.TButton").grid(row=2, column=2, padx=4, pady=(4, 8), sticky="e")
        self._dark_checkbutton(deb_panel, "Allow repository dependency fetch if needed", self.apt_repo_access_var, bg=SENTINEL_DARK).grid(row=2, column=0, columnspan=2, padx=8, pady=(4, 8), sticky="w")
        ttk.Label(
            deb_panel,
            text="Without repository access, Program Manager installs the local .deb without downloading dependencies. Enable the checkbox only when you explicitly allow package fetching.",
            wraplength=820,
            justify="left",
        ).grid(row=3, column=0, columnspan=3, padx=8, pady=(0, 8), sticky="we")
        deb_panel.columnconfigure(0, weight=1)

    def _build_repair_tab(self) -> None:
        frame = self._make_scrollable_body(self.repair_tab)
        header = ttk.Frame(frame, style="Panel.TFrame")
        header.pack(fill="x", padx=10, pady=(10, 6))
        ttk.Label(header, text="Repair & Maintenance", style="Panel.TLabel", font=("Sans", 14, "bold")).pack(anchor="w", padx=10, pady=(8, 2))
        ttk.Label(
            header,
            text="Repair package state and clean package-manager cache. These tools are separated from the installer/uninstaller landing page.",
            style="Panel.TLabel",
            wraplength=860,
            justify="left",
        ).pack(anchor="w", padx=10, pady=(0, 8))

        panel = ttk.LabelFrame(frame, text="APT repair and cleanup")
        panel.pack(fill="x", padx=10, pady=10)
        self.repair_dry_run_var = tk.BooleanVar(value=True)
        self._dark_checkbutton(panel, "Dry-run / simulate where supported", self.repair_dry_run_var, bg=SENTINEL_DARK).grid(row=0, column=0, padx=8, pady=8, sticky="w", columnspan=4)
        ttk.Button(panel, text="Fix broken packages", command=self.apt_fix_broken).grid(row=1, column=0, padx=8, pady=8, sticky="w")
        ttk.Button(panel, text="Autoremove unused packages", command=self.apt_autoremove).grid(row=1, column=1, padx=8, pady=8, sticky="w")
        ttk.Button(panel, text="Autoclean package cache", command=self.apt_autoclean).grid(row=1, column=2, padx=8, pady=8, sticky="w")
        ttk.Button(panel, text="Clean package cache", command=self.apt_clean_cache).grid(row=1, column=3, padx=8, pady=8, sticky="w")

        notes = textwrap.dedent(
            """
            Maintenance rules:
            • Fix broken packages and autoremove show visible output below every time they run.
            • Autoclean removes obsolete downloaded package files only.
            • Clean package cache removes downloaded package files from APT cache and asks for confirmation.
            • These actions do not delete user documents or home-folder data.
            """
        ).strip()
        ttk.Label(frame, text=notes, justify="left", wraplength=860).pack(fill="x", padx=14, pady=8, anchor="w")

        self.repair_status_var = tk.StringVar(value="Repair output will appear here after you run a maintenance action.")
        tk.Label(frame, textvariable=self.repair_status_var, bg=SENTINEL_DARK, fg=SENTINEL_GOLD, anchor="w", padx=10).pack(fill="x", padx=10, pady=(6, 2))
        output_panel = ttk.LabelFrame(frame, text="Visible maintenance output")
        output_panel.pack(fill="both", expand=True, padx=10, pady=(0, 12))
        self.repair_output_text = scrolledtext.ScrolledText(
            output_panel,
            wrap="word",
            bg="#0B0F12",
            fg=SENTINEL_TEXT,
            insertbackground=SENTINEL_CYAN,
            height=11,
        )
        self.repair_output_text.pack(fill="both", expand=True, padx=8, pady=8)
        self.repair_output_text.insert("1.0", "No maintenance output yet. Run Fix broken packages or Autoremove unused packages to see results here.\n")
        self.repair_output_text.configure(state="disabled")

    def _clear_repair_output(self, title: str = "") -> None:
        widget = getattr(self, "repair_output_text", None)
        if widget is None or not widget.winfo_exists():
            return
        widget.configure(state="normal")
        widget.delete("1.0", "end")
        if title:
            widget.insert("end", title.rstrip() + "\n")
        widget.configure(state="disabled")
        if hasattr(self, "repair_status_var") and title:
            self.repair_status_var.set(title.strip())

    def repair_log(self, text: str) -> None:
        """Write visible maintenance output in addition to normal session logs."""
        if threading.get_ident() != getattr(self, "main_thread_id", None):
            try:
                self.after(0, lambda value=text: self.repair_log(value))
            except Exception:
                pass
            return
        widget = getattr(self, "repair_output_text", None)
        if widget is not None and widget.winfo_exists():
            widget.configure(state="normal")
            widget.insert("end", text.rstrip() + "\n")
            widget.see("end")
            widget.configure(state="disabled")
        if hasattr(self, "repair_status_var") and text.strip():
            first_line = text.strip().splitlines()[0]
            self.repair_status_var.set(first_line[:180])

    def _run_repair_command_visible(self, label: str, cmd: list[str], privileged: bool = False, timeout: Optional[int] = 180) -> None:
        command_text = quote_cmd(make_privileged_command(cmd) if privileged else cmd)
        self.repair_log(f"$ {command_text}")
        result = self.run_and_log(cmd, privileged=privileged, timeout=timeout)
        if result.stdout.strip():
            self.repair_log(result.stdout.rstrip())
        if result.stderr.strip():
            self.repair_log(result.stderr.rstrip())
        if not result.stdout.strip() and not result.stderr.strip():
            self.repair_log("No package changes or messages were reported by APT.")
        self.repair_log(f"Exit code: {result.returncode}")
        if result.returncode == 0:
            self.repair_log(f"{label} completed successfully.")
        else:
            self.repair_log(f"{label} finished with errors. Use View Logs / Output for the full session log.")

    def open_log_viewer(self) -> None:
        if self.log_window is not None and self.log_window.winfo_exists():
            self.log_window.lift()
            return
        win = tk.Toplevel(self)
        win.title(f"{APP_NAME} — Logs / Session Output")
        win.geometry("980x620")
        win.configure(bg=SENTINEL_DARK)
        self.log_window = win

        header = tk.Frame(win, bg=SENTINEL_PANEL, highlightbackground="#263541", highlightthickness=1)
        header.pack(fill="x", padx=10, pady=(10, 6))
        tk.Label(header, text="Logs / Session Output", bg=SENTINEL_PANEL, fg=SENTINEL_GOLD, font=("Sans", 14, "bold"), anchor="w").pack(side="left", padx=12, pady=10)
        ttk.Button(header, text="Open Log Folder", command=self.open_log_folder).pack(side="right", padx=8, pady=8)
        ttk.Button(header, text="Copy Output", command=self.copy_output).pack(side="right", padx=8, pady=8)
        ttk.Button(header, text="Clear Session Output", command=self.clear_session_output).pack(side="right", padx=8, pady=8)

        viewer = scrolledtext.ScrolledText(
            win,
            wrap="word",
            bg="#0B0F12",
            fg="#E8EDF0",
            insertbackground=SENTINEL_CYAN,
            height=24,
        )
        viewer.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        self.log_viewer = viewer
        self._refresh_log_viewer()

        def on_close() -> None:
            self.log_viewer = None
            self.log_window = None
            win.destroy()
        win.protocol("WM_DELETE_WINDOW", on_close)

    def _refresh_log_viewer(self) -> None:
        viewer = getattr(self, "log_viewer", None)
        if viewer is None or not viewer.winfo_exists():
            return
        viewer.configure(state="normal")
        viewer.delete("1.0", "end")
        if self.session_output_lines:
            viewer.insert("1.0", "\n".join(self.session_output_lines).rstrip() + "\n")
        else:
            viewer.insert("1.0", "No session output yet.\n")
        viewer.see("end")
        viewer.configure(state="disabled")

    def clear_session_output(self) -> None:
        with self.output_lock:
            self.session_output_lines.clear()
        self._refresh_log_viewer()

    def open_log_folder(self) -> None:
        try:
            USER_LOG_DIR.mkdir(parents=True, exist_ok=True)
            if which("xdg-open"):
                subprocess.Popen(["xdg-open", str(USER_LOG_DIR)])
                self.audit("open-log-folder", str(USER_LOG_DIR), result="xdg-open")
            else:
                messagebox.showinfo("Log folder", str(USER_LOG_DIR))
        except Exception as exc:
            messagebox.showerror("Unable to open logs", str(exc))

    def view_last_error(self) -> None:
        crash_text = _tail_path_text(USER_LOG_DIR / "crash.log", 80)
        launcher_text = _tail_path_text(USER_LOG_DIR / "launcher.log", 80)
        text = crash_text or launcher_text or "No recent error or launcher output was found."
        win = tk.Toplevel(self)
        win.title("Sentinel Program Manager — Last Error")
        win.geometry("920x540")
        win.configure(bg=SENTINEL_DARK)
        viewer = scrolledtext.ScrolledText(win, wrap="word", bg="#0B0F12", fg="#E8EDF0", insertbackground=SENTINEL_CYAN)
        viewer.pack(fill="both", expand=True, padx=10, pady=10)
        viewer.insert("1.0", text + "\n")
        viewer.configure(state="disabled")

    def show_protection_audit(self) -> None:
        payload = phase8_protection_audit_summary()
        text = json.dumps(payload, indent=2)
        win = tk.Toplevel(self)
        win.title("Sentinel Program Manager — Protection Audit")
        win.geometry("840x520")
        win.configure(bg=SENTINEL_DARK)
        viewer = scrolledtext.ScrolledText(win, wrap="word", bg="#0B0F12", fg="#E8EDF0", insertbackground=SENTINEL_CYAN)
        viewer.pack(fill="both", expand=True, padx=10, pady=10)
        viewer.insert("1.0", text + "\n")
        viewer.configure(state="disabled")

    def show_phase9_diagnostics(self) -> None:
        text = phase9_diagnostics_text() + "\n\nRaw JSON:\n" + json.dumps(phase9_diagnostics_payload(), indent=2)
        win = tk.Toplevel(self)
        win.title("Sentinel Program Manager — Diagnostics")
        win.geometry("940x620")
        win.configure(bg=SENTINEL_DARK)
        viewer = scrolledtext.ScrolledText(win, wrap="word", bg="#0B0F12", fg="#E8EDF0", insertbackground=SENTINEL_CYAN)
        viewer.pack(fill="both", expand=True, padx=10, pady=10)
        viewer.insert("1.0", text + "\n")
        viewer.configure(state="disabled")
        self.audit("diagnostics", "phase9", result="opened")


    def show_release_readiness(self) -> None:
        text = release_readiness_text() + "\n\nRaw JSON:\n" + json.dumps(release_readiness_payload(), indent=2)
        win = tk.Toplevel(self)
        win.title("Sentinel Program Manager — Release Readiness")
        win.geometry("940x620")
        win.configure(bg=SENTINEL_DARK)
        viewer = scrolledtext.ScrolledText(win, wrap="word", bg="#0B0F12", fg="#E8EDF0", insertbackground=SENTINEL_CYAN)
        viewer.pack(fill="both", expand=True, padx=10, pady=10)
        viewer.insert("1.0", text + "\n")
        viewer.configure(state="disabled")
        self.audit("release-check", "v0.9.7", result="opened")

    def show_about_program(self) -> None:
        text = textwrap.dedent(f"""
        {APP_NAME} v{APP_VERSION}
        Program 101 — Official SentinelOS Installer / Uninstaller

        Role
        • Windows-style Installed Programs & Uninstaller for SentinelOS.
        • Local .deb and .tar.* installer/import handler.
        • Repair & Maintenance surface for package health.
        • AEGIS-compatible local-control layer.

        Locked doctrine
        • User-facing applications first.
        • AEGIS Suite, Important System Services, System Files/Libraries, and Sentinel Critical are separated.
        • Uninstall purges by default; Remove Only is the advanced non-purge path.
        • Repository/internet package access is blocked unless explicitly enabled.
        • Builder/export workflows belong to F.O.R.G.E, not Program 101.

        Logs
        • {USER_LOG_DIR}
        """).strip()
        messagebox.showinfo("About Sentinel Program Manager", text)


    def _build_manual_tab(self) -> None:
        frame = self.manual_tab
        header = tk.Frame(frame, bg=SENTINEL_PANEL, highlightbackground="#263541", highlightthickness=1)
        header.pack(fill="x", padx=10, pady=(10, 6))
        tk.Label(header, text="Manual", bg=SENTINEL_PANEL, fg=SENTINEL_GOLD, font=("Sans", 14, "bold"), anchor="w").pack(side="left", padx=12, pady=10)
        ttk.Button(header, text="View Logs / Output", command=self.open_log_viewer).pack(side="right", padx=8, pady=8)
        ttk.Button(header, text="View Last Error", command=self.view_last_error).pack(side="right", padx=8, pady=8)
        ttk.Button(header, text="Protection Audit", command=self.show_protection_audit).pack(side="right", padx=8, pady=8)
        ttk.Button(header, text="Run Diagnostics", command=self.show_phase9_diagnostics).pack(side="right", padx=8, pady=8)
        ttk.Button(header, text="Release Check", command=self.show_release_readiness).pack(side="right", padx=8, pady=8)
        ttk.Button(header, text="About", command=self.show_about_program).pack(side="right", padx=8, pady=8)
        ttk.Button(header, text="Open Log Folder", command=self.open_log_folder).pack(side="right", padx=8, pady=8)

        manual = scrolledtext.ScrolledText(
            frame,
            wrap="word",
            bg="#0B0F12",
            fg="#E8EDF0",
            insertbackground=SENTINEL_CYAN,
            height=24,
        )
        manual.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        manual_text = textwrap.dedent(
            f"""
            {APP_NAME} v{APP_VERSION} Manual
            Program 101 — Official SentinelOS Installer / Uninstaller
            v1.0.2 redteam/render hotfix — hardened MIME/tar handling, clean rebuild packaging, and MATE rendering polish

            Purpose
            • The first tab is a familiar Windows-style Installed Programs & Uninstaller view.
            • User Applications / Sentinel Desktop Suite programs are shown first, including preinstalled non-critical Desktop Suite apps.
            • The first section is restricted to visible applications, not libraries or OS dependencies.
            • The first column shows the readable Application Name. The Debian package name is shown beside it.
            • AEGIS Suite, Important System Services, System Files / Libraries, and Sentinel Critical sections are separated below. Non-critical, non-library APT applications remain user-removable.
            • AEGIS Suite also scans user/system .desktop launchers so script-installed AEGIS apps appear even before they become formal .deb packages.
            • Installer, local package import, and repair tools live in separate tabs. Logs are accessed from the Manual page header.

            Common controls
            • Ctrl+Q closes the window.
            • Ctrl+R refreshes the installed-program list.
            • Ctrl+F focuses the Installed Programs search box.
            • F1 opens this Manual page.
            • Double-click an installed program to view details.
            • Right-click an installed program for details, files, uninstall, remove-only, reinstall, or copy names. Default uninstall performs purge cleanup.
            • Search filters application names, package names, versions, sections, priorities, descriptions, and category labels.
            • Right-click Copy Application Name when you need the readable app title; Copy Package Name remains available for exact dpkg work.

            APT tab
            • Use this for APT/repository package work.
            • Actual repository installs are blocked until repository/internet package access is explicitly enabled for the session.
            • Repository work still supports simulation/preview for safety.

            Local Installers tab
            • Use this for local .deb and .tar.* files.
            • Double-click/open-with file opening, Browse, Paste Path, and type/paste + Enter are the supported file input paths for v1.0. In-window drag/drop is intentionally out of scope for this release.
            • .tar.* app bundle import is at the top of the page; .deb package install is separated at the bottom.
            • .deb installs no longer use a dry-run checkbox. Without repository permission, Program Manager installs without downloading dependencies.
            • .tar.* imports are inspected for unsafe paths, links, device entries, and setuid/setgid permissions before install.

            Repair & Maintenance tab
            • Fix broken packages, autoremove unused packages, autoclean, and clean package cache live here.
            • Fix broken packages and autoremove now display visible on-page output every time they run. Use simulation where available before actual repair/removal.

            Logs and audit
            • The separate Logs tab has been removed to keep the main interface clean.
            • Use the View Logs / Output button at the top of this Manual page for session output.
            • Use View Last Error when the GUI closes or a launcher path fails.
            • Use Protection Audit to inspect the current protected-package policy.
            • Use Run Diagnostics to check required tools, MIME associations, category rules, protected-package rules, and local-app removal planning. Use Release Check before cutting v1.0.
            • Launcher, crash, and audit logs live under ~/.local/share/sentinel-program-manager/logs/.
            • Phase 4 audit logging records command actions to audit.log in that same log folder.

            Safety doctrine
            • Program 101 does not run bundled tarball post-install scripts.
            • Phase 8 expanded the critical protection audit for apt, dpkg, libc, init, GRUB, initramfs, kernel, sudo, login, networking, X/MATE session, and SentinelOS foundation packages.
            • Critical/system package removals are blocked from the landing page unless deliberately overridden through protected controls.
            • Phase 9 added non-destructive diagnostics/self-test. Phase 10 added final release-readiness checks. v1.0.2 adds redteam hardening and GUI rendering polish.
            • F.O.R.G.E owns builder/export/package-generation workflows. Program 101 installs, uninstalls, imports, repairs, and inspects.
            """
        ).strip()
        manual.insert("1.0", manual_text + "\n")
        manual.configure(state="disabled")

    def _bind_hotkeys(self) -> None:
        self.bind_all("<Control-q>", self._close_from_hotkey)
        self.bind_all("<Control-Q>", self._close_from_hotkey)
        self.bind_all("<Control-r>", self._refresh_from_hotkey)
        self.bind_all("<Control-R>", self._refresh_from_hotkey)
        self.bind_all("<Control-f>", self._focus_search_from_hotkey)
        self.bind_all("<Control-F>", self._focus_search_from_hotkey)
        self.bind_all("<F1>", self._manual_from_hotkey)

    def _refresh_from_hotkey(self, _event=None) -> str:
        self.audit("hotkey", "Ctrl+R", result="refresh-request")
        self.refresh_installed_packages()
        return "break"

    def _focus_search_from_hotkey(self, _event=None) -> str:
        self.notebook.select(self.installed_tab)
        try:
            self.installed_search_entry.focus_set()
            self.installed_search_entry.select_range(0, "end")
        except Exception:
            pass
        return "break"

    def _manual_from_hotkey(self, _event=None) -> str:
        self.notebook.select(self.manual_tab)
        return "break"

    def _close_from_hotkey(self, _event=None) -> str:
        self.audit("hotkey", "Ctrl+Q", result="window-close-request")
        self.destroy()
        return "break"

    def _startup_notice(self) -> None:
        self.log(f"{APP_NAME} v{APP_VERSION} maintenance hotfix loaded.")
        self.log("Default landing page: User Applications / Sentinel Desktop Suite, including preinstalled non-critical suite apps, for faster first display. All Programs remains in the side menu. Builder workflows belong in F.O.R.G.E.")
        self.log("Default order: User Applications first, then AEGIS Suite, Important System Services, System Files/Libraries, and Sentinel Critical.")
        self.log("Table uses Application Name first; local/script-installed AEGIS launchers are discovered for the AEGIS Suite category.")
        self.log("Hotkeys: Ctrl+Q closes, Ctrl+R refreshes, Ctrl+F searches, F1 opens Manual.")
        self.log("Manual includes View Logs / Output, View Last Error, Protection Audit, Run Diagnostics, Release Check, About, and Open Log Folder buttons.")
        self.log("Repository/internet package access must be explicitly enabled before actual repository installs or apt-get update.")
        self.log("APT browser auto-loads configured local package metadata; internet refresh remains opt-in.")
        self.log("Phase 4 safety: tar.* imports are inspected before extraction and command actions are written to audit.log.")
        self.log(f"File-handler mode supports: {display_supported_installer_types()}.")
        missing = []
        for tool in ("apt-get", "apt-cache", "dpkg-query"):
            if not which(tool):
                missing.append(tool)
        if missing:
            self.log("WARNING: missing expected Debian tools: " + ", ".join(missing))
        if not which("pkexec") and os.geteuid() != 0:
            self.log("NOTICE: pkexec not found; actual privileged actions will fall back to sudo/terminal where possible.")

    def _append_log_line(self, text: str) -> None:
        line = text.rstrip()
        self.session_output_lines.append(line)
        # Keep the in-app log window optional. The main interface no longer has a Logs tab.
        self._refresh_log_viewer()
        print(line, file=sys.stderr)
        self.update_idletasks()

    def _drain_log_queue(self) -> None:
        try:
            while True:
                self._append_log_line(self.log_queue.get_nowait())
        except queue.Empty:
            pass
        try:
            self.after(100, self._drain_log_queue)
        except Exception:
            pass

    def audit(self, event: str, target: str = "", result: str = "", command: str = "", source: str = "manual") -> None:
        try:
            USER_LOG_DIR.mkdir(parents=True, exist_ok=True)
            stamp = datetime.now().isoformat(timespec="seconds")
            safe_command = command.replace("\n", " ").replace("\r", " ")[:2000]
            safe_target = str(target).replace("\n", " ").replace("\r", " ")[:800]
            safe_result = str(result).replace("\n", " ").replace("\r", " ")[:800]
            line = f"{stamp}	source={source}	event={event}	target={safe_target}	result={safe_result}	command={safe_command}\n"
            with AUDIT_LOG_PATH.open("a", encoding="utf-8") as fh:
                fh.write(line)
        except Exception:
            # Audit logging must never crash the package manager UI.
            pass

    def log(self, text: str) -> None:
        # Tk widgets must only be updated from the main GUI thread. Background
        # package/preview threads enqueue output for the GUI event loop.
        if threading.get_ident() != getattr(self, "main_thread_id", None):
            self.log_queue.put(text)
            return
        with self.output_lock:
            self._append_log_line(text)

    def run_threaded(self, label: str, func: Callable[[], None]) -> None:
        self.audit("thread-start", label)
        self.log(f"\n=== {label} ===")
        thread = threading.Thread(target=self._thread_wrapper, args=(func,), daemon=True)
        thread.start()

    def _thread_wrapper(self, func: Callable[[], None]) -> None:
        try:
            func()
        except Exception as exc:
            self.log(f"ERROR: {exc}")
            self.log(traceback.format_exc())

    def run_and_log(self, cmd: list[str], privileged: bool = False, timeout: Optional[int] = None) -> CommandResult:
        final_cmd = make_privileged_command(cmd) if privileged else cmd
        command_text = quote_cmd(final_cmd)
        self.audit("command-start", target=cmd[0] if cmd else "", command=command_text, result="privileged" if privileged else "user")
        self.log("$ " + command_text)
        try:
            result = run_capture(final_cmd, timeout=timeout)
        except subprocess.TimeoutExpired:
            self.log("Command timed out.")
            self.audit("command-timeout", target=cmd[0] if cmd else "", command=command_text, result="124")
            return CommandResult(124, "", "Timed out", final_cmd)
        except FileNotFoundError as exc:
            self.log(f"Command not found: {exc}")
            self.audit("command-not-found", target=cmd[0] if cmd else "", command=command_text, result=str(exc))
            return CommandResult(127, "", str(exc), final_cmd)
        if result.stdout:
            self.log(result.stdout)
        if result.stderr:
            self.log(result.stderr)
        self.log(f"Exit code: {result.returncode}")
        self.audit("command-finish", target=cmd[0] if cmd else "", command=command_text, result=str(result.returncode))
        return result

    def require_confirm(self, title: str, message: str) -> bool:
        return messagebox.askyesno(title, message, icon="warning")

    def _repository_access_allowed(self) -> bool:
        return bool(getattr(self, "apt_repo_access_var", tk.BooleanVar(value=False)).get())

    def _parse_apt_dumpavail(self, output: str, search_text: str = "") -> list[tuple[str, str, str, str]]:
        rows: list[tuple[str, str, str, str]] = []
        needle = search_text.strip().lower()
        current: dict[str, str] = {}
        last_key: str | None = None

        def flush() -> None:
            if not current.get("Package"):
                return
            package = current.get("Package", "").strip()
            version = current.get("Version", "").strip()
            section = current.get("Section", "").strip()
            desc = current.get("Description", "").splitlines()[0].strip() if current.get("Description") else ""
            haystack = f"{package} {version} {section} {desc}".lower()
            if needle and needle not in haystack:
                return
            rows.append((package, version, section, desc))

        for raw_line in output.splitlines():
            if not raw_line.strip():
                flush()
                current = {}
                last_key = None
                continue
            if raw_line.startswith(" ") and last_key:
                current[last_key] = current.get(last_key, "") + "\n" + raw_line.strip()
                continue
            if ":" in raw_line:
                key, value = raw_line.split(":", 1)
                key = key.strip()
                value = value.strip()
                if key in {"Package", "Version", "Section", "Description"}:
                    current[key] = value
                    last_key = key
        flush()
        return rows

    def _populate_apt_rows(self, rows: list[tuple[str, str, str, str]], label: str = "APT browser") -> None:
        tree = getattr(self, "apt_results_tree", None)
        if tree is None:
            return
        try:
            tree.delete(*tree.get_children())
        except Exception:
            return
        if not rows:
            tree.insert("", "end", values=("", "", "", f"No APT repository results for: {label}"))
            if hasattr(self, "apt_browser_status_var"):
                self.apt_browser_status_var.set(f"No results for {label}.")
            return
        max_rows = 2500
        for package, version, section, desc in rows[:max_rows]:
            tree.insert("", "end", values=(package, version, section, desc))
        if len(rows) > max_rows:
            tree.insert("", "end", values=("", "", "", f"Showing first {max_rows} of {len(rows)} packages. Use Search repo to narrow the list."))
        if hasattr(self, "apt_browser_status_var"):
            shown = min(len(rows), max_rows)
            self.apt_browser_status_var.set(f"{shown} APT package row(s) shown for {label}. Double-click a package to select it.")

    def _populate_apt_results(self, search_text: str, output: str) -> None:
        rows: list[tuple[str, str, str, str]] = []
        for line in output.splitlines():
            line = line.strip()
            if not line:
                continue
            if " - " in line:
                package, desc = line.split(" - ", 1)
            else:
                parts = line.split(None, 1)
                package = parts[0]
                desc = parts[1] if len(parts) > 1 else ""
            package = package.strip()
            desc = desc.strip()
            if package:
                rows.append((package, "", "", desc))
        self._populate_apt_rows(rows, f"search: {search_text}")

    def _on_apt_result_double_click(self, _event: tk.Event | None = None) -> None:
        tree = getattr(self, "apt_results_tree", None)
        if tree is None:
            return
        selected = tree.selection()
        if not selected:
            return
        values = tree.item(selected[0], "values")
        if not values:
            return
        package = str(values[0]).strip()
        if package:
            self.apt_package_var.set(package)
            self.log(f"APT browser selected package: {package}")

    def apt_refresh_index(self) -> None:
        if not self._repository_access_allowed():
            messagebox.showerror(
                "Repository access not authorised",
                "Refreshing the APT repository index may use the internet/network. Enable the explicit repository/internet package access checkbox first.",
            )
            return
        if not self.require_confirm("Refresh APT repository index", "Run apt-get update now?\n\nThis retrieves package metadata from configured APT repositories and requires root privileges."):
            return
        def job() -> None:
            result = self.run_and_log(["apt-get", "update"], privileged=True, timeout=300)
            if hasattr(self, "apt_browser_status_var"):
                self.after(0, lambda: self.apt_browser_status_var.set("APT repository index refresh finished. Use Load repo browser or Search repo."))
            self.audit("apt-refresh-index", target="configured-repositories", result=str(result.returncode))
        self.run_threaded("APT repository index refresh", job)

    def _auto_load_apt_browser_once(self) -> None:
        if getattr(self, "apt_browser_auto_loaded", False):
            return
        self.apt_browser_auto_loaded = True
        if hasattr(self, "apt_browser_status_var"):
            self.apt_browser_status_var.set("Loading configured APT metadata automatically...")
        self.apt_load_repository_browser(auto=True)

    def apt_load_repository_browser(self, auto: bool = False) -> None:
        def job() -> None:
            result = self.run_and_log(["apt-cache", "dumpavail"], timeout=120)
            rows = self._parse_apt_dumpavail(result.stdout or "")
            label = "configured APT repositories (auto-loaded)" if auto else "configured APT repositories"
            self.after(0, lambda: self._populate_apt_rows(rows, label))
        self.run_threaded("Auto-load APT repository browser" if auto else "Load APT repository browser", job)

    def apt_search(self) -> None:
        term = self.apt_package_var.get().strip()
        if not term:
            self.apt_load_repository_browser()
            return
        def job() -> None:
            result = self.run_and_log(["apt-cache", "search", term], timeout=90)
            output = result.stdout or ""
            self.after(0, lambda: self._populate_apt_results(term, output))
        self.run_threaded("APT repository search", job)

    def apt_status(self) -> None:
        pkg = self.apt_package_var.get().strip()
        base_pkg = pkg.split(":", 1)[0]
        if not validate_package_name(pkg):
            messagebox.showerror("Invalid package", "Enter a valid Debian package name.")
            return
        def job() -> None:
            self.run_and_log(["dpkg-query", "-W", "-f=${Package}\t${Version}\t${Status}\n", pkg], timeout=15)
            self.run_and_log(["apt-cache", "policy", pkg], timeout=30)
            self.log("Metadata guardrail check:")
            self.log(apt_essential_status(pkg))
        self.run_threaded("APT package status", job)

    def _apt_package_action(self, action: str) -> None:
        pkg = self.apt_package_var.get().strip()
        base_pkg = pkg.split(":", 1)[0]
        if not validate_package_name(base_pkg):
            messagebox.showerror("Invalid package", "Enter a valid Debian package name.")
            return
        dry_run = self.apt_dry_run_var.get()
        allow_protected = self.apt_allow_protected_var.get()
        if action in {"remove", "purge"} and is_protected_package(base_pkg) and not allow_protected:
            messagebox.showerror(
                "Protected package blocked",
                f"{pkg} looks critical or SentinelOS-protected. Enable protected override only if you are certain.",
            )
            return
        if action == "install" and not dry_run and not self._repository_access_allowed():
            messagebox.showerror(
                "Repository access not authorised",
                "Actual repository installs may fetch packages from configured sources. Enable the explicit repository/internet package access checkbox first.",
            )
            return
        if not dry_run:
            prompt = f"Run actual apt-get {action} for package '{pkg}'?\n\nThis will require root privileges."
            if action in {"remove", "purge"}:
                prompt += "\n\nRemoval can affect dependent packages. Run dry-run first if you have not already."
            if not self.require_confirm("Confirm APT action", prompt):
                return
        def job() -> None:
            if dry_run:
                self.last_previewed_actions.add(_preview_key("apt", action, base_pkg))
                cmd = ["apt-get", "-s", action, pkg]
                result = self.run_and_log(cmd, timeout=120)
                combined = result.stdout + "\n" + result.stderr
                if looks_apt_simulation_dangerous(combined):
                    self.log("DANGER: APT simulation reports essential or high-risk removals. Do not run actual action unless you fully understand the dependency chain.")
            else:
                cmd = ["apt-get", action, "-y", pkg]
                self.run_and_log(cmd, privileged=True)
        self.run_threaded(f"APT {action}", job)

    def apt_install(self) -> None:
        self._apt_package_action("install")

    def apt_remove(self) -> None:
        self._apt_package_action("remove")

    def apt_purge(self) -> None:
        self._apt_package_action("purge")

    def apt_autoremove(self) -> None:
        dry_run_var = getattr(self, "repair_dry_run_var", getattr(self, "apt_dry_run_var", tk.BooleanVar(value=True)))
        dry_run = dry_run_var.get()
        if not dry_run and not self.require_confirm("Confirm autoremove", "Run actual apt-get autoremove?\n\nDry-run is recommended first."):
            return
        self._clear_repair_output("Starting APT autoremove simulation..." if dry_run else "Starting actual APT autoremove...")
        def job() -> None:
            cmd = ["apt-get", "-s", "autoremove"] if dry_run else ["apt-get", "autoremove", "-y"]
            self._run_repair_command_visible("APT autoremove", cmd, privileged=not dry_run, timeout=180 if dry_run else None)
        self.run_threaded("APT autoremove", job)

    def apt_fix_broken(self) -> None:
        dry_run = self.repair_dry_run_var.get() if hasattr(self, "repair_dry_run_var") else True
        if not dry_run and not self._repository_access_allowed():
            messagebox.showerror(
                "Repository access not authorised",
                "Repair may need to install packages from configured sources. Enable explicit repository/internet package access first, or keep dry-run enabled.",
            )
            return
        if not dry_run and not self.require_confirm("Confirm repair", "Run actual apt-get --fix-broken install?\n\nThis may install or remove packages to repair dependency state."):
            return
        self._clear_repair_output("Starting broken-package repair simulation..." if dry_run else "Starting actual broken-package repair...")
        def job() -> None:
            cmd = ["apt-get", "-s", "--fix-broken", "install"] if dry_run else ["apt-get", "--fix-broken", "install", "-y"]
            self._run_repair_command_visible("APT fix broken packages", cmd, privileged=not dry_run, timeout=180 if dry_run else None)
        self.run_threaded("APT fix broken packages", job)

    def apt_autoclean(self) -> None:
        if not self.require_confirm("Confirm autoclean", "Run apt-get autoclean?\n\nThis removes obsolete downloaded package files from the APT cache."):
            return
        def job() -> None:
            self.run_and_log(["apt-get", "autoclean"], privileged=True, timeout=180)
        self.run_threaded("APT autoclean", job)

    def apt_clean_cache(self) -> None:
        if not self.require_confirm("Confirm package cache clean", "Run apt-get clean?\n\nThis removes downloaded package files from the APT cache. It does not delete your documents."):
            return
        def job() -> None:
            self.run_and_log(["apt-get", "clean"], privileged=True, timeout=180)
        self.run_threaded("APT clean cache", job)

    def open_startup_installer_file(self) -> None:
        path = self.startup_path
        if path is None:
            return
        try:
            path = path.expanduser().resolve()
        except Exception:
            path = path.expanduser()
        if not path.exists() or not path.is_file():
            self.log(f"Startup file not found or not a normal file: {path}")
            self.open_log_viewer()
            return
        if not is_supported_installer_path(path):
            self.log(f"Unsupported startup file type: {path}")
            self.log(f"Supported installer/import files: {display_supported_installer_types()}")
            self.open_log_viewer()
            return
        self._set_installer_path(path, source="startup")
        if is_deb_path(path):
            self.log("Local .deb mode selected. Press Install .deb to install without a dry-run step.")
        elif is_tar_bundle_path(path):
            self.log("Tar.* importer selected. Preview the archive before installing.")

    def _apply_tar_path_guess(self, path: Path) -> None:
        guessed = installer_guess_id_from_path(path)
        if guessed and not self.tar_app_id_var.get().strip():
            self.tar_app_id_var.set(guessed)
        if guessed and not self.tar_command_var.get().strip():
            self.tar_command_var.set(guessed)
        if guessed and not self.tar_title_var.get().strip():
            self.tar_title_var.set(guessed.replace("-", " ").replace("_", " ").title())

    def _first_dropped_file(self, data: str) -> Path | None:
        try:
            parts = self.tk.splitlist(data)
        except Exception:
            parts = [data]
        for item in parts:
            cleaned = str(item).strip().strip("{}")
            if cleaned.startswith("file://"):
                cleaned = cleaned[7:]
            if cleaned:
                return Path(cleaned).expanduser()
        return None

    def _handle_dropped_file(self, data: str, expected: str | None = None) -> None:
        path = self._first_dropped_file(data)
        if path is None:
            return
        self._set_installer_path(path, expected=expected, source="drop")

    def _apply_typed_installer_path(self, expected: str | None = None) -> None:
        text = self.deb_path_var.get().strip() if expected == "deb" else self.tar_path_var.get().strip()
        if text:
            self._set_installer_path(Path(text).expanduser(), expected=expected, source="typed")

    def _set_installer_path(self, path: Path, expected: str | None = None, source: str = "manual") -> None:
        try:
            path = path.expanduser().resolve()
        except Exception:
            path = path.expanduser()
        if not path.is_file():
            messagebox.showerror("Installer file not found", f"That path is not a normal file:\n\n{path}")
            return
        if is_deb_path(path):
            if expected == "tar":
                messagebox.showerror("Wrong installer type", "That file is a .deb package. Use the .deb section at the bottom.")
                return
            self.notebook.select(self.local_tab)
            self.deb_path_var.set(str(path))
            self.log(f"Selected local .deb package from {source}: {path}")
            return
        if is_tar_bundle_path(path):
            if expected == "deb":
                messagebox.showerror("Wrong installer type", "That file is a .tar.* bundle. Use the tar.* section at the top.")
                return
            self.notebook.select(self.local_tab)
            self.tar_path_var.set(str(path))
            self._apply_tar_path_guess(path)
            self.log(f"Selected local tar.* bundle from {source}: {path}")
            return
        messagebox.showerror("Unsupported installer type", f"Supported files: {display_supported_installer_types()}\n\n{path}")

    def _ensure_file_drop_backend(self) -> bool:
        """Drag/drop is intentionally disabled for the v1.0 path.

        Reliable v1.0 file input paths are double-click/open-with associations,
        Browse/Choose buttons, Paste Path, and typing/pasting a path then pressing Enter.
        """
        self.file_drop_backend = "disabled for v1.0"
        self.file_drop_available = False
        return False

    def _file_drop_status_text(self) -> str:
        return "Supported file input: double-click/open-with installer files, Browse, Paste Path, or type/paste a path and press Enter."

    def _fallback_file_select(self, expected: str | None = None) -> None:
        if expected == "deb":
            self.choose_deb()
        elif expected == "tar":
            self.choose_tar()

    def _paste_installer_path(self, expected: str | None = None) -> None:
        try:
            text = self.clipboard_get().strip()
        except Exception:
            messagebox.showinfo("Clipboard empty", "Copy an installer file path first, then use Paste Path.")
            return
        if text.startswith("file://"):
            text = text[7:]
        if text:
            self._set_installer_path(Path(text.strip().strip("{}")), expected=expected, source="clipboard")

    def _register_file_drop(self, widget: tk.Widget, expected: str | None = None) -> bool:
        """Prepare installer target widgets for click-to-browse.

        In-window drag/drop is deliberately not part of the v1.0 readiness path.
        """
        try:
            widget.configure(cursor="hand2")
        except Exception:
            pass
        try:
            widget.bind("<Button-1>", lambda _event, exp=expected: self._fallback_file_select(exp))
        except Exception:
            pass
        try:
            if isinstance(widget, tk.Label):
                text = str(widget.cget("text"))
                if "Click to Browse" not in text:
                    widget.configure(text=text + "\nClick to Browse, or use Paste Path.", fg=SENTINEL_MUTED)
        except Exception:
            pass
        return False

    def choose_deb(self) -> None:
        path = filedialog.askopenfilename(title="Choose .deb package", filetypes=[("Debian packages", "*.deb"), ("All files", "*")])
        if path:
            self._set_installer_path(Path(path), expected="deb", source="browse")

    def install_deb(self) -> None:
        path = Path(self.deb_path_var.get().strip()).expanduser()
        if not path.is_file() or not is_deb_path(path):
            messagebox.showerror("Invalid .deb", "Choose, paste, or type an existing .deb file.")
            return
        repo_allowed = self._repository_access_allowed()
        mode_note = (
            "Repository dependency fetching is enabled for this session."
            if repo_allowed else
            "Repository dependency fetching is not enabled. Program Manager will install the local .deb without downloading dependencies."
        )
        if not self.require_confirm(
            "Confirm .deb install",
            f"Install local Debian package?\n\n{path}\n\n{mode_note}\n\nThis will require root privileges.",
        ):
            return
        def job() -> None:
            cmd = ["apt-get", "install", "-y", str(path)] if repo_allowed else ["apt-get", "install", "-y", "--no-download", str(path)]
            self.run_and_log(cmd, privileged=True, timeout=None)
            self.audit("install-local-deb", target=str(path), result="repo-access" if repo_allowed else "local-no-download")
        self.run_threaded("Install local .deb", job)

    def choose_tar(self) -> None:
        path = filedialog.askopenfilename(
            title="Choose .tar.* app bundle",
            filetypes=[
                ("Tar archives", "*.tar *.tar.gz *.tgz *.tar.xz *.txz *.tar.bz2 *.tbz2"),
                ("All files", "*"),
            ],
        )
        if path:
            self._set_installer_path(Path(path), expected="tar", source="browse")

    def preview_tar(self) -> None:
        path = Path(self.tar_path_var.get().strip()).expanduser()
        if not path.is_file():
            messagebox.showerror("Invalid tarball", "Choose an existing .tar/.tar.gz/.tgz/.tar.xz/.txz/.tar.bz2/.tbz2 file.")
            return
        def job() -> None:
            self.log(f"Previewing: {path}")
            issues = inspect_tar_safety(path, self.tar_strip_var.get())
            if issues:
                self.log("SAFETY BLOCK: this archive is not safe to install/import as-is.")
                for issue in issues[:80]:
                    self.log(f"  - {issue}")
                if len(issues) > 80:
                    self.log(f"  ... {len(issues) - 80} more issues omitted")
                self.audit("tar-preview-blocked", target=str(path), result=f"{len(issues)} safety issues")
            else:
                self.log("Safety inspection: passed basic Program 101 archive guardrails.")
                self.audit("tar-preview-ok", target=str(path), result="passed")
            try:
                with tarfile.open(path, "r:*") as tf:
                    members = tf.getmembers()
                    for m in members[:120]:
                        flags = []
                        if m.issym(): flags.append(f"symlink -> {m.linkname}")
                        if m.islnk(): flags.append(f"hardlink -> {m.linkname}")
                        if m.isdev() or m.isfifo(): flags.append("special")
                        suffix = " [" + ", ".join(flags) + "]" if flags else ""
                        self.log(f"{m.name}{'/' if m.isdir() else ''}{suffix}")
                    if len(members) > 120:
                        self.log(f"... {len(members) - 120} more entries omitted")
            except Exception as exc:
                self.log(f"ERROR reading tarball: {exc}")
        self.run_threaded("Preview tar.*", job)

    def _validate_tar_install_fields(self) -> tuple[Path, str, str, str, str] | None:
        tar_path = Path(self.tar_path_var.get().strip()).expanduser()
        app_id = self.tar_app_id_var.get().strip().lower()
        title = self.tar_title_var.get().strip()
        command = self.tar_command_var.get().strip()
        exec_rel = self.tar_exec_var.get().strip()
        if not tar_path.is_file():
            messagebox.showerror("Invalid tarball", "Choose an existing .tar/.tar.gz/.tgz/.tar.xz/.txz/.tar.bz2/.tbz2 file.")
            return None
        if not validate_app_id(app_id):
            messagebox.showerror("Invalid App ID", "Use lowercase letters, numbers, dot, underscore, or dash. Example: sentinel-notes")
            return None
        if not title:
            messagebox.showerror("Title required", "Enter a display title.")
            return None
        if not validate_desktop_value(title):
            messagebox.showerror("Invalid display title", "Use a simple one-line display title without control characters or '='. Maximum length is 96 characters.")
            return None
        if not validate_command(command):
            messagebox.showerror("Invalid command", "Use letters, numbers, dot, underscore, or dash. Example: sentinel-notes")
            return None
        if not safe_relative_path(exec_rel):
            messagebox.showerror("Invalid executable path", "Executable path must be relative, use safe filename characters, and must not contain '..'.")
            return None
        issues = inspect_tar_safety(tar_path, self.tar_strip_var.get() if hasattr(self, "tar_strip_var") else False)
        if issues:
            self.audit("tar-install-blocked", target=str(tar_path), result=f"{len(issues)} safety issues")
            messagebox.showerror(
                "Unsafe tar.* bundle blocked",
                "Sentinel Program Manager blocked this archive before install/import.\n\n"
                + "\n".join(f"• {issue}" for issue in issues[:12])
                + (f"\n... {len(issues) - 12} more issue(s). Use Preview tarball for details." if len(issues) > 12 else ""),
            )
            return None
        return tar_path, app_id, title, command, exec_rel

    def install_tar_bundle(self) -> None:
        fields = self._validate_tar_install_fields()
        if not fields:
            return
        tar_path, app_id, title, command, exec_rel = fields
        strip = self.tar_strip_var.get()
        if not self.require_confirm(
            "Confirm tar.* install",
            f"Install '{title}' into {DEFAULT_TAR_INSTALL_ROOT / app_id}?\n\n"
            f"Command: {command}\nExecutable: {exec_rel}\n\nThis will require root privileges.",
        ):
            return
        def job() -> None:
            script = self._make_tar_install_script(tar_path, app_id, title, command, exec_rel, strip)
            self.run_and_log(["bash", str(script)], privileged=True)
            try:
                script.unlink(missing_ok=True)
            except Exception:
                pass
        self.run_threaded("Install tar.* app bundle", job)

    def uninstall_tar_bundle(self) -> None:
        app_id = self.tar_app_id_var.get().strip().lower()
        if not validate_app_id(app_id):
            messagebox.showerror("Invalid App ID", "Enter the App ID to uninstall.")
            return
        if not self.require_confirm("Confirm tar.* uninstall", f"Uninstall manifest-backed tar.* app '{app_id}'?\n\nThis will require root privileges."):
            return
        def job() -> None:
            script = self._make_tar_uninstall_script(app_id)
            self.run_and_log(["bash", str(script)], privileged=True)
            try:
                script.unlink(missing_ok=True)
            except Exception:
                pass
        self.run_threaded("Uninstall tar.* app bundle", job)

    def _make_tar_install_script(self, tar_path: Path, app_id: str, title: str, command: str, exec_rel: str, strip: bool) -> Path:
        fd, script_path = tempfile.mkstemp(prefix="sentinel-tar-install-", suffix=".sh")
        os.close(fd)
        dest = DEFAULT_TAR_INSTALL_ROOT / app_id
        wrapper = Path("/usr/local/bin") / command
        desktop = Path("/usr/share/applications") / f"{app_id}.desktop"
        manifest = TAR_MANIFEST_DIR / f"{app_id}.manifest"
        strip_arg = "--strip-components=1" if strip else ""
        exec_path = dest / exec_rel
        import hashlib
        tar_sha256 = hashlib.sha256(tar_path.read_bytes()).hexdigest()
        script = f"""#!/usr/bin/env bash
set -euo pipefail
APP_ID={shlex.quote(app_id)}
TITLE={shlex.quote(title)}
TAR_PATH={shlex.quote(str(tar_path))}
TAR_SHA256={shlex.quote(tar_sha256)}
DEST={shlex.quote(str(dest))}
WRAPPER={shlex.quote(str(wrapper))}
DESKTOP={shlex.quote(str(desktop))}
MANIFEST={shlex.quote(str(manifest))}
EXEC_REL={shlex.quote(exec_rel)}
EXEC_PATH={shlex.quote(str(exec_path))}

case "$DEST" in
  /opt/sentinel-apps/*) ;;
  *) echo "Refusing unsafe install destination: $DEST" >&2; exit 10 ;;
esac
if [ -e "$DEST" ]; then
  echo "Destination already exists: $DEST" >&2
  echo "Uninstall the existing app or choose a different App ID." >&2
  exit 11
fi
if ! command -v sha256sum >/dev/null 2>&1; then
  echo "sha256sum is required for tar.* race protection." >&2
  exit 13
fi
ACTUAL_SHA256="$(sha256sum "$TAR_PATH" | awk '{{print $1}}')"
if [ "$ACTUAL_SHA256" != "$TAR_SHA256" ]; then
  echo "Archive changed after safety inspection; refusing privileged extraction." >&2
  exit 14
fi
install -d -m 0755 "$DEST"
tar --no-same-owner --no-same-permissions --delay-directory-restore -xf "$TAR_PATH" -C "$DEST" {strip_arg}
if [ ! -e "$EXEC_PATH" ]; then
  echo "Executable not found after extract: $EXEC_PATH" >&2
  exit 12
fi
chmod +x "$EXEC_PATH" || true
cat > "$WRAPPER" <<EOF
#!/usr/bin/env bash
exec "$EXEC_PATH" "\\$@"
EOF
chmod 0755 "$WRAPPER"
cat > "$DESKTOP" <<EOF
[Desktop Entry]
Type=Application
Name=$TITLE
Comment=Installed by Sentinel Program Manager
Exec=$WRAPPER
Terminal=false
Categories=Utility;System;
StartupNotify=true
EOF
install -d -m 0755 "$(dirname "$MANIFEST")"
cat > "$MANIFEST" <<EOF
$DEST
$WRAPPER
$DESKTOP
EOF
echo "Installed $TITLE"
echo "Manifest: $MANIFEST"
"""
        Path(script_path).write_text(script, encoding="utf-8")
        os.chmod(script_path, 0o700)
        return Path(script_path)

    def _make_tar_uninstall_script(self, app_id: str) -> Path:
        fd, script_path = tempfile.mkstemp(prefix="sentinel-tar-uninstall-", suffix=".sh")
        os.close(fd)
        manifest = TAR_MANIFEST_DIR / f"{app_id}.manifest"
        script = f"""#!/usr/bin/env bash
set -euo pipefail
MANIFEST={shlex.quote(str(manifest))}
if [ ! -f "$MANIFEST" ]; then
  echo "Manifest not found: $MANIFEST" >&2
  exit 20
fi
while IFS= read -r target; do
  [ -n "$target" ] || continue
  case "$target" in
    /opt/sentinel-apps/*|/usr/local/bin/*|/usr/share/applications/*.desktop)
      rm -rf -- "$target"
      echo "Removed: $target"
      ;;
    *)
      echo "Skipping unsafe manifest target: $target" >&2
      ;;
  esac
done < "$MANIFEST"
rm -f -- "$MANIFEST"
echo "Uninstalled {app_id}"
"""
        Path(script_path).write_text(script, encoding="utf-8")
        os.chmod(script_path, 0o700)
        return Path(script_path)

    def copy_output(self) -> None:
        text = "\n".join(self.session_output_lines).strip()
        self.clipboard_clear()
        self.clipboard_append(text)
        # Avoid recursive copy logging noise when the output is empty.
        if text:
            self.audit("copy-output", "session-output", result=f"{len(text)} chars")



def _json_print(data: object) -> None:
    print(json.dumps(data, indent=2, sort_keys=True))


def _tail_file(path: Path, lines: int = 100) -> list[str]:
    try:
        if not path.exists():
            return []
        data = path.read_text(errors="ignore").splitlines()
        return data[-lines:]
    except Exception as exc:
        return [f"ERROR reading {path}: {exc}"]


def aegis_status_payload() -> dict:
    return {
        "app": APP_NAME,
        "program": 101,
        "version": APP_VERSION,
        "aegis_compatible": True,
        "standing_local_authority": True,
        "manual_first": True,
        "network_access_default": "blocked unless explicitly user-stated",
        "local_actions_available": True,
        "status": "ready",
        "phase8_user_ready_polish": True,
        "phase9_testing_bugfix": True,
        "phase10_release_candidate_prep": True,
        "protection_audit": phase8_protection_audit_summary(),
        "diagnostics": phase9_diagnostics_payload(),
        "release_readiness": release_readiness_payload(),
        "logs": str(USER_LOG_DIR),
    }


def aegis_actions_payload() -> dict:
    return {
        "actions": [
            {"name": "list-apps", "mode": "read", "description": "List installed Program Manager records."},
            {"name": "details", "mode": "read", "args": ["target"], "description": "Show one package/local app record."},
            {"name": "show-files", "mode": "read", "args": ["target"], "description": "Show dpkg files or local removal/file plan."},
            {"name": "uninstall", "mode": "dry-run/run", "args": ["package"], "description": "Default uninstall for normal non-protected dpkg packages; maps to APT purge cleanup."},
            {"name": "remove-only", "mode": "dry-run/run", "args": ["package"], "description": "APT remove normal non-protected dpkg package without purge cleanup."},
            {"name": "purge", "mode": "dry-run/run", "args": ["package"], "description": "APT purge normal non-protected dpkg package."},
            {"name": "uninstall-local", "mode": "dry-run/run", "args": ["app-id"], "description": "Default local uninstall; removes safe launcher/wrapper/app targets plus matching config/data/cache."},
            {"name": "remove-local", "mode": "dry-run/run", "args": ["app-id"], "description": "Remove safe launcher/wrapper/app targets for a local app without config/data/cache cleanup."},
            {"name": "purge-local", "mode": "dry-run/run", "args": ["app-id"], "description": "Remove local app plus matching config/data/cache targets."},
            {"name": "install-local-deb", "mode": "dry-run/run", "args": ["file.deb"], "description": "Install local .deb; actual run is network-gated by environment policy."},
            {"name": "release-check", "mode": "read", "description": "Return the v0.9.7 release-readiness checklist for v1.0 prep."},
        ]
    }


def aegis_permissions_payload() -> dict:
    return {
        "standing_local_authority": True,
        "allowed_by_default": [
            "list installed apps", "inspect package/local app details", "preview uninstall plans",
            "uninstall safe local launcher apps with purge cleanup by default", "uninstall normal non-protected packages with purge cleanup by default",
            "operate without per-action GUI approval for local/offline workflows",
        ],
        "blocked_or_restricted": {
            "internet_or_repository_fetch": "blocked unless explicitly user-stated; CLI requires SENTINEL_ALLOW_REPOSITORY_ACCESS=1 for actual dependency-fetching installs",
            "critical_os_packages": "blocked by expanded v0.8 protection audit",
            "system_services_and_libraries": "blocked from Program Manager landing-page removal",
            "unsafe_local_paths": "blocked by allowlist",
        },
    }


def cli_local_action(action: str, target: str, run_actual: bool) -> int:
    record = find_installed_record(target)
    if not record:
        _json_print({"ok": False, "error": "target not found", "target": target})
        return 2
    if not record.local_desktop_entry:
        _json_print({"ok": False, "error": "target is not a local launcher record", "target": target, "package": record.package})
        return 3
    mode = "uninstall" if action == "remove-local" else "purge"
    plan = build_local_removal_plan(record, mode=mode)
    if not run_actual:
        _json_print({"ok": True, "dry_run": True, "plan": plan.as_dict()})
        return 0
    if not plan.targets:
        _json_print({"ok": False, "error": "no safe targets", "plan": plan.as_dict()})
        return 4
    script = _write_local_removal_script(plan)
    try:
        result = run_capture(make_privileged_command(["bash", str(script)]), timeout=120)
        _json_print({"ok": result.returncode == 0, "action": action, "plan": plan.as_dict(), "returncode": result.returncode, "stdout": result.stdout, "stderr": result.stderr})
        return result.returncode
    finally:
        try:
            script.unlink(missing_ok=True)
        except Exception:
            pass


def cli_package_action(action: str, target: str, run_actual: bool) -> int:
    pkg = target.strip()
    base_pkg = pkg.split(":", 1)[0]
    if not validate_package_name(base_pkg):
        _json_print({"ok": False, "error": "invalid package name", "target": target})
        return 2
    record = find_installed_record(pkg)
    gid = package_group_id(record or pkg)
    if action in {"remove", "purge"} and (group_is_landing_page_protected(gid) or is_protected_package(base_pkg)):
        _json_print({"ok": False, "error": "protected package blocked", "target": pkg, "group": GROUP_LABELS.get(gid, gid)})
        return 5
    if not run_actual:
        cmd = ["apt-get", "-s", action, pkg]
        result = run_capture(cmd, timeout=120)
        _json_print({"ok": result.returncode == 0, "dry_run": True, "command": cmd, "returncode": result.returncode, "dangerous": looks_apt_simulation_dangerous(result.stdout + "\n" + result.stderr), "stdout": result.stdout, "stderr": result.stderr})
        return result.returncode
    cmd = ["apt-get", action, "-y", pkg]
    result = run_capture(make_privileged_command(cmd), timeout=300)
    _json_print({"ok": result.returncode == 0, "command": cmd, "returncode": result.returncode, "stdout": result.stdout, "stderr": result.stderr})
    return result.returncode


def cli_install_local_deb(path_text: str, run_actual: bool) -> int:
    path = Path(path_text).expanduser()
    if not path.is_file() or not is_deb_path(path):
        _json_print({"ok": False, "error": "not a local .deb file", "target": path_text})
        return 2
    if not run_actual:
        cmd = ["apt-get", "-s", "install", str(path)]
        result = run_capture(cmd, timeout=120)
        _json_print({"ok": result.returncode == 0, "dry_run": True, "command": cmd, "returncode": result.returncode, "stdout": result.stdout, "stderr": result.stderr})
        return result.returncode
    if os.environ.get("SENTINEL_ALLOW_REPOSITORY_ACCESS") != "1":
        _json_print({"ok": False, "error": "repository/dependency fetching not authorised", "required_env": "SENTINEL_ALLOW_REPOSITORY_ACCESS=1"})
        return 6
    cmd = ["apt-get", "install", "-y", str(path)]
    result = run_capture(make_privileged_command(cmd), timeout=300)
    _json_print({"ok": result.returncode == 0, "command": cmd, "returncode": result.returncode, "stdout": result.stdout, "stderr": result.stderr})
    return result.returncode


def handle_cli(args: list[str]) -> int | None:
    if not args:
        return None
    if args[0] in {"--version", "-V"}:
        print(APP_VERSION)
        return 0
    if args[0] in {"--help", "-h"}:
        print(textwrap.dedent(f"""
        {APP_NAME} v{APP_VERSION}

        GUI:
          sentinel-program-manager [file.deb|app.tar.gz]

        AEGIS/local control:
          --aegis-status [--json]
          --aegis-actions [--json]
          --aegis-permissions [--json]
          --aegis-log [--json]
          --aegis-diagnostics [--json]
          --release-check | --aegis-release-check [--json]
          --diagnostics | --self-test [--json]
          --aegis-dry-run <uninstall|remove-only|purge|uninstall-local|remove-local|purge-local|install-local-deb> <target>
          --aegis-run <uninstall|remove-only|purge|uninstall-local|remove-local|purge-local|install-local-deb> <target>
        """).strip())
        return 0
    if args[0] in {"--release-check", "--aegis-release-check"}:
        if "--json" in args or args[0].startswith("--aegis"):
            _json_print(release_readiness_payload())
        else:
            print(release_readiness_text())
        return 0
    if args[0] in {"--diagnostics", "--self-test", "--aegis-diagnostics"}:
        if "--json" in args or args[0].startswith("--aegis"):
            _json_print(phase9_diagnostics_payload())
        else:
            print(phase9_diagnostics_text())
        return 0
    if args[0] == "--aegis-status":
        _json_print(aegis_status_payload())
        return 0
    if args[0] == "--aegis-actions":
        _json_print(aegis_actions_payload())
        return 0
    if args[0] == "--aegis-permissions":
        _json_print(aegis_permissions_payload())
        return 0
    if args[0] == "--aegis-log":
        payload = {
            "launcher_log": _tail_file(USER_LOG_DIR / "launcher.log", 80),
            "crash_log": _tail_file(USER_LOG_DIR / "crash.log", 80),
            "audit_log": _tail_file(AUDIT_LOG_PATH, 120),
        }
        _json_print(payload)
        return 0
    if args[0] in {"--aegis-dry-run", "--aegis-run"}:
        run_actual = args[0] == "--aegis-run"
        if len(args) >= 2 and args[1] == "list-apps":
            records = collect_installed_program_records()
            _json_print({"ok": True, "apps": [{"application_name": r.application_name, "package": r.package, "group": GROUP_LABELS.get(package_group_id(r), package_group_id(r)), "local": r.local_desktop_entry} for r in records]})
            return 0
        if len(args) >= 3 and args[1] == "details":
            record = find_installed_record(args[2])
            if not record:
                _json_print({"ok": False, "error": "target not found", "target": args[2]})
                return 2
            _json_print({"ok": True, "record": {
                "application_name": record.application_name, "package": record.package, "version": record.version,
                "group": GROUP_LABELS.get(package_group_id(record), package_group_id(record)),
                "section": record.section, "description": record.description, "local": record.local_desktop_entry,
                "desktop_file": record.desktop_file_path, "exec": record.exec_command,
            }})
            return 0
        if len(args) >= 3 and args[1] == "show-files":
            record = find_installed_record(args[2])
            if not record:
                _json_print({"ok": False, "error": "target not found", "target": args[2]})
                return 2
            if record.local_desktop_entry:
                plan = build_local_removal_plan(record, mode="purge")
                _json_print({"ok": True, "local": True, "plan": plan.as_dict()})
                return 0
            result = run_capture(["dpkg", "-L", record.package], timeout=60)
            _json_print({"ok": result.returncode == 0, "package": record.package, "returncode": result.returncode, "files": result.stdout.splitlines(), "stderr": result.stderr})
            return result.returncode
        if len(args) < 3:
            _json_print({"ok": False, "error": "usage: --aegis-dry-run/--aegis-run <action> <target>"})
            return 2
        action = args[1]
        target = args[2]
        if action in {"uninstall-local", "purge-local", "remove-local"}:
            return cli_local_action(action, target, run_actual)
        if action in {"uninstall", "purge"}:
            return cli_package_action("purge", target, run_actual)
        if action in {"remove", "remove-only"}:
            return cli_package_action("remove", target, run_actual)
        if action == "install-local-deb":
            return cli_install_local_deb(target, run_actual)
        _json_print({"ok": False, "error": "unknown AEGIS action", "action": action})
        return 2
    if args[0] == "--aegis-list" or (args[0] == "--aegis-dry-run" and len(args) > 1 and args[1] == "list-apps"):
        records = collect_installed_program_records()
        _json_print({"ok": True, "apps": [{"application_name": r.application_name, "package": r.package, "group": GROUP_LABELS.get(package_group_id(r), package_group_id(r)), "local": r.local_desktop_entry} for r in records]})
        return 0
    return None

def crash_log_path() -> Path:
    base = Path(os.environ.get("XDG_DATA_HOME", str(Path.home() / ".local" / "share")))
    log_dir = base / APP_ID / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    return log_dir / "crash.log"


def write_crash_log(exc: BaseException) -> None:
    try:
        path = crash_log_path()
        stamp = datetime.now().isoformat(timespec="seconds")
        with path.open("a", encoding="utf-8") as fh:
            fh.write(f"\n[{stamp}] {APP_NAME} v{APP_VERSION} startup/runtime crash\n")
            fh.write("Arguments: " + " ".join(map(str, sys.argv[1:])) + "\n")
            fh.write("Working directory: " + os.getcwd() + "\n")
            traceback.print_exception(type(exc), exc, exc.__traceback__, file=fh)
    except Exception:
        pass


def main(argv: list[str] | None = None) -> int:
    args = list(sys.argv[1:] if argv is None else argv)
    cli_result = handle_cli(args)
    if cli_result is not None:
        return cli_result
    startup_path: Path | None = None
    if args:
        # Desktop file associations pass the selected file as the first positional argument.
        startup_path = Path(args[0])
    app = SentinelProgramManager(startup_path=startup_path)
    app.mainloop()
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except BaseException as exc:
        if not isinstance(exc, SystemExit):
            write_crash_log(exc)
            print(f"{APP_NAME} crashed. Details written to: {crash_log_path()}", file=sys.stderr)
        raise
