# Sentinel Program Manager v0.6.3 — Application Name + AEGIS Discovery

## Purpose

v0.6.3 makes the Installed Programs table read like a normal application manager instead of a raw Debian package list.

## Changes

- Added a front **Application Name** column.
- Moved Debian package identifiers to the second **Package Name** column.
- Uses `.desktop` launcher metadata to display readable application names when available.
- Uses friendly SentinelOS/AEGIS fallback names for known suite applications.
- Search now includes application names.
- Sorting by the first column sorts by readable application title.

## AEGIS Suite Discovery Fix

Some AEGIS modules can be installed during development as local launchers or scripts before they become formal Debian packages. Those modules may not appear in `dpkg-query -W`, so the Program Manager now also scans:

- `/usr/share/applications`
- `/usr/local/share/applications`
- `~/.local/share/applications`
- XDG application directories

AEGIS-specific hidden aliases are included so A.V.I.C, S.C.A.N, V.A.U.L.T, R.E.P.O, B.A.S.T.I.O.N, A.R.C, and support launchers can appear under **AEGIS Suite Programs** even when hidden from the normal desktop menu to avoid duplicate launcher entries.

Local launcher records support **Details** and **Show Files**. APT uninstall/purge is disabled for these records because they are not dpkg-managed packages.
