# Program 101 — Sentinel Program Manager v0.9.0

## Phase 9 — Real Testing / Bugfix Build

This phase prepares Sentinel Program Manager for final v1.0 release-candidate testing.

### Goals

- Add a non-destructive diagnostics/self-test path.
- Validate required Debian tools, optional desktop helpers, icon assets, desktop entry discovery, MIME associations, package category rules, protected package rules, log paths, and local app removal planning.
- Make AEGIS/CLI uninstall behavior consistent with the GUI: **Uninstall means purge cleanup by default**.
- Preserve a remove-only path for advanced non-purge workflows.

### New user-facing controls

The Manual page now includes:

- View Logs / Output
- View Last Error
- Protection Audit
- Run Diagnostics
- Open Log Folder

### New CLI / AEGIS controls

```bash
sentinel-program-manager --diagnostics
sentinel-program-manager --self-test
sentinel-program-manager --self-test --json
sentinel-program-manager --aegis-diagnostics --json
sentinel-program-manager --aegis-dry-run uninstall <package>
sentinel-program-manager --aegis-run uninstall <package>
sentinel-program-manager --aegis-dry-run remove-only <package>
sentinel-program-manager --aegis-run remove-only <package>
sentinel-program-manager --aegis-dry-run uninstall-local <app-id>
sentinel-program-manager --aegis-run uninstall-local <app-id>
sentinel-program-manager --aegis-dry-run remove-local <app-id>
sentinel-program-manager --aegis-run remove-local <app-id>
```

### Behavior alignment

- `uninstall` maps to purge cleanup for normal dpkg/APT packages.
- `uninstall-local` maps to purge cleanup for local launcher apps.
- `remove-only` and `remove-local` preserve the older non-purge behavior.
- Critical/system packages remain blocked by protection rules.

### Diagnostics note

MIME associations can show as a warning in a source tree or container before the `.deb` is installed. After installing the package, the post-install script refreshes icon/desktop/MIME databases and registers Sentinel Program Manager as the default handler for `.deb` and supported `.tar.*` bundles.
