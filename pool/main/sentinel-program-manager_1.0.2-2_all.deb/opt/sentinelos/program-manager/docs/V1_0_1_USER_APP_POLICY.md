# v1.0.1 User Application Policy Patch

Sentinel Program Manager now treats preinstalled non-critical Sentinel Desktop Suite applications as normal user applications. The user may uninstall/purge these apps if desired.

Ordinary non-critical, non-library APT-installed applications may also appear under **User Applications / Sentinel Desktop Suite**, even when they were installed before the user first opened SentinelOS.

Still protected/separated:

- SentinelOS base/core/policy packages
- Sentinel Program Manager itself
- apt/dpkg/libc/systemd/kernel/bootloader packages
- system services and desktop session infrastructure
- libraries, development files, language bindings, firmware, fonts, documentation, and dependencies

The goal is a familiar uninstaller view: user-facing apps first, technical system components below.
