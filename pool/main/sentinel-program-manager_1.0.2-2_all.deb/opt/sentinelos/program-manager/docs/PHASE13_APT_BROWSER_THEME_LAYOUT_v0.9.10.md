# Program 101 — v0.9.10 APT Browser / Theme / Layout Hotfix

## Purpose

This build addresses late pre-v1.0 UI feedback:

- Local Installers felt too large/bloated for the default window.
- Install Software should be named **APT**.
- The APT tab needed a visible package browser/results area instead of empty space.
- Highlighted tab/button/menu text should use AEGIS gold.
- Check selections should not render as bright white boxes on the SentinelOS dark theme.

## Changes

- Default window changed to `1180x760`; minimum size changed to `1000x680`.
- Local Installers copy and spacing were compacted.
- Install Software tab/sidebar labels were renamed to **APT**.
- APT search results now populate a Treeview package browser with package and description columns.
- Double-clicking an APT result selects that package for install/status/uninstall actions.
- TNotebook/TButton/TCombobox/Treeview/Menu highlight colors were adjusted toward AEGIS gold.
- Native checkbuttons were replaced with custom dark check rows to avoid white native indicator boxes under MATE/Tk themes.
