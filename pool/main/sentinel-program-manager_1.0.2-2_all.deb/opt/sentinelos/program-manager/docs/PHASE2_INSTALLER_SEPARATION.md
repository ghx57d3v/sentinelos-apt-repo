# Program 101 Phase 2 — Installer Separation Polish

Phase 2 corrects the workflow layout for Sentinel Program Manager so the first screen remains familiar and uninstaller-focused while installer/import/maintenance tools live in their own places.

## Official layout

1. **Installed Programs**
   - Default landing page.
   - Windows-like Programs and Features / uninstaller feel.
   - Categorised installed-program list, search, details, right-click menu, simulate uninstall, uninstall, purge, reinstall.

2. **Install Software**
   - APT/repository package search and install/remove/purge actions.
   - Repository install is separated from the uninstaller landing page.
   - Actual repository installs require the explicit repository/internet access checkbox.

3. **Local Installers**
   - Local `.deb` installer.
   - Local `.tar.*` app bundle importer.
   - File-open mode from Phase 3 lands here automatically.

4. **Repair & Maintenance**
   - Fix broken packages.
   - Autoremove unused packages.
   - Autoclean obsolete package downloads.
   - Clean package cache.

5. **Manual**
   - Current-session command output and operation records.

## Builder boundary

Program 101 does not build packages, ISOs, AppImages, release bundles, checksums, or signed output artifacts.

Those workflows belong in **F.O.R.G.E**.

## Network boundary

Program 101 remains offline/local by default. APT repository installs may contact configured package sources; Phase 2 adds an explicit user-facing checkbox before actual repository installs, dependency-fetching local `.deb` installs, reinstalls, and actual broken-package repair operations. Phase 4 should harden the full network policy and audit layer.
