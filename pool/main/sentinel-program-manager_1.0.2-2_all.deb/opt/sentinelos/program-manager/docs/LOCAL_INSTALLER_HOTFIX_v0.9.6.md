# Program 101 — v0.9.6 Local Installer Hotfix

This hotfix repairs and polishes the local installer workflow after v0.9.5.

## Changes

- `.tar.*` importer moved to the top of Local Installers.
- `.deb` installer moved to the bottom with extra spacing.
- Local `.deb` dry-run checkbox removed.
- `.deb` install now performs an actual install after confirmation.
- Repository dependency fetching remains opt-in.
- When repository access is not enabled, Program Manager uses `apt-get install --no-download` for local `.deb` installs.
- In-window drag-and-drop was later abandoned for the v1.0 path; use double-click/open-with, Browse, Paste Path, or type/paste + Enter.
- Added paste/type + Enter fallback support for installer path fields.

## Doctrine

Program 101 remains the official SentinelOS Installer / Uninstaller. It may install local files, but it must not access online repositories unless the user explicitly enables repository/package-fetch access for the session.
