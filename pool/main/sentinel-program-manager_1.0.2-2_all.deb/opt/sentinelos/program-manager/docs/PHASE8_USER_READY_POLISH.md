# Program 101 v0.8.0 — Phase 8 User-Ready Polish + Protection Audit

This phase prepares Sentinel Program Manager for the v1.0 lock-candidate path.

## UX polish

- Manual page now exposes View Last Error and Protection Audit controls.
- Added Ctrl+R refresh, Ctrl+F search focus, and F1 Manual hotkeys.
- Added Copy Application Name to the installed-programs context menu.
- Show Files for local launcher apps now includes safe uninstall and purge previews.
- Confirmation dialogs now warn when no dry-run/preview has been recorded for the chosen action in the current session.

## Protection audit

The protected package policy was expanded around package-manager, libc, init, kernel, GRUB, initramfs, sudo/login, networking, X/MATE session, and SentinelOS foundation packages. Normal Sentinel Desktop Suite user apps remain removable.

## AEGIS compatibility

The AEGIS status payload now includes the v0.8 protection audit summary.
