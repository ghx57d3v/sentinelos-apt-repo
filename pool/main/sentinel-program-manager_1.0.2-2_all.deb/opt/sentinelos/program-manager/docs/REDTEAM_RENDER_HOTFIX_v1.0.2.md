# Sentinel Program Manager v1.0.2 — Redteam / Rendering Hotfix

## Purpose
This maintenance patch addresses issues found during a defensive redteam review of Program 101 v1.0.1.

## Fixes
- GUI rendering polish for MATE/Marco:
  - Compact default table widths for Installed Programs.
  - Compact default table widths for the APT browser.
  - Dark/gold ttk scrollbar styling to avoid bright native scrollbar artefacts.
- Packaging integrity:
  - `packaging/build-deb.sh` now emits `1.0.2-1` instead of stale `1.0-1` output.
  - Stale `__pycache__` bytecode is excluded from the source/package tree.
- MIME policy:
  - Default-open handling is limited to Debian package MIME types.
  - Generic tar/gzip/xz/bzip archive MIME types are associated but not default-hijacked.
  - Package removal now cleans Program Manager MIME associations on remove/purge/disappear.
- tar.* importer hardening:
  - Symlink and hardlink entries are blocked outright.
  - The archive SHA256 is pinned between safety inspection and privileged extraction.
  - Display titles reject desktop-file injection characters/control lines.
  - Executable paths require safe relative path components.
  - Wrapper generation no longer uses `sed` placeholder replacement.

## Validation
- Python compile: pass.
- CLI version: `1.0.2`.
- Diagnostics: pass, with environment-dependent MIME warning when not installed.
- Release check: pass.
- Malicious tar safety tests: traversal and symlink samples blocked.
- Xvfb GUI smoke screenshot: default window renders with compact columns and themed scrollbars.
- APT status/action validation now accepts arch-qualified package rows such as `package:amd64` by validating the base package name while preserving the full dpkg/APT target.
