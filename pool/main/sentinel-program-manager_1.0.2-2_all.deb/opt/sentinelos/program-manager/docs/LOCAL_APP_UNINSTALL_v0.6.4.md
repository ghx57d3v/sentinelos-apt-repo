# v0.6.4 Local App Uninstall/Purge

Sentinel Program Manager can now preview, uninstall, and purge local/script-installed launcher applications that are not managed by dpkg/APT.

Local removal is allowlisted and may remove only safe launcher/wrapper/app/data targets such as `.desktop` launchers, `~/.local/bin` or `/usr/local/bin` wrappers, `/opt/sentinel-apps/<app>`, and matching per-app config/data/cache folders during purge.

