# Sentinel Program Manager v0.6.1 UI / Category Fix

This patch removes the separate Logs tab and keeps logs available from the Manual page header.

## Changes

- Main notebook tabs are now: Installed Programs, Install Software, Local Installers, Repair & Maintenance, Manual.
- Manual page header includes **View Logs / Output** and **Open Log Folder**.
- Session output is kept in memory and shown only on demand.
- Persistent files remain under `~/.local/share/sentinel-program-manager/logs/`.
- AEGIS Suite package classification was expanded so A.V.I.C., S.C.A.N, V.A.U.L.T, R.E.P.O, B.A.S.T.I.O.N, A.R.C, and shared AEGIS support packages sort into the AEGIS Suite section instead of User Installed.
