# Sentinel Program Manager v0.6.2 Category Refinement

## Purpose

The Installed Programs landing page should feel like a familiar Windows-style uninstaller. That means the first category must show user-facing applications, not every Debian package that is not critical.

## Category order

1. User Applications / Sentinel Desktop Suite
2. AEGIS Suite Programs
3. Important System Services
4. System Files / Libraries
5. Sentinel Critical

## User Applications rule

The first category should contain visible applications and Sentinel Desktop Suite apps only. Libraries, dependencies, language bindings, fonts, shared data packages, development packages, docs, automatic support packages, default desktop/session components, and core OS packages should not appear here.

## System Files / Libraries

This category now catches packages such as `lib*`, `python3-*`, `gir1.2-*`, `fonts-*`, `*-common`, `*-data`, `*-dev`, documentation packages, auto-installed dependencies, and similar support packages.

## Notes

A perfect distinction between user-installed and OS-default applications requires a future SentinelOS baseline manifest. v0.6.2 uses practical Debian metadata, desktop-launcher ownership, apt-mark state, section names, and package naming heuristics to keep the first category clean.
