# Program 101 — Sentinel Program Manager v0.9.8 Final Cleanup

## Purpose

This build prepares the v1.0 lock-candidate path by cleaning up two final UX decisions:

1. The overview/navigation side menu is now persistent across every tab.
2. In-window drag-and-drop is removed from the v1.0 requirement set.

## Supported local installer input paths

- Double-click / Open With for `.deb` and `.tar.*` files.
- Browse / Choose buttons.
- Paste Path buttons.
- Type or paste a path and press Enter.

## Navigation doctrine

The side menu remains visible while the user is in Installed Programs, Install Software, Local Installers, Repair & Maintenance, or Manual. Category buttons always return the user to the Installed Programs page with the selected filter applied.
