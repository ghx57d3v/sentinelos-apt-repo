# Program 101 — v0.9.11 Final Pre-v1.0 Polish

This build addresses the last live UI feedback before the v1.0 lock candidate.

## Changes

- Increased default window height for better usable space.
- Removed duplicate Installed Programs build call to avoid unnecessary widget construction.
- Added visible overview side-menu selection highlighting across every tab and category.
- Expanded the APT tab into a lightweight repository browser:
  - `apt-get update` refreshes repository metadata only when repository/internet access is explicitly enabled.
  - `apt-cache dumpavail` loads the available configured APT metadata into the visual browser.
  - `apt-cache search` searches the available APT metadata and fills the browser results.
- APT browser columns now show Package, Version, Section, and Description.

## Network doctrine

APT repository refresh is the only APT browser operation here that may contact configured network repositories. It is blocked unless the session repository/internet access checkbox is enabled.
