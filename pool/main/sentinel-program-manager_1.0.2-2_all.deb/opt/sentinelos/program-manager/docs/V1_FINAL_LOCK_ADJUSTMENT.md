# Program 101 v1.0 Final Lock Adjustment

Final pre-lock adjustment: the APT browser now loads configured APT metadata automatically in the background.

- The user no longer needs to press **Load repo browser** before seeing package metadata.
- **Load repo browser** remains available as a manual reload button.
- Automatic loading uses `apt-cache dumpavail`, which reads the local configured APT index.
- `apt-get update` remains behind the explicit repository/internet access checkbox.

This completes the final v1.0 lock-candidate behavior requested before lock.
