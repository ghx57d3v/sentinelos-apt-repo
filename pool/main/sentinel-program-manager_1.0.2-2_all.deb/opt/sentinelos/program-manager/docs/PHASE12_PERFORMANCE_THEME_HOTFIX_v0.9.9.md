# Program 101 — v0.9.9 Performance / Theme Hotfix

## Purpose

This hotfix addresses two pre-v1.0 issues observed on the live SentinelOS/MATE desktop:

1. The installed-program list took too long to display.
2. Checkbox selections, entries, and dropdown-style controls did not fully match the AEGIS dark/gold theme.

## Performance changes

- Default landing page filter is now **User Applications / Sentinel Desktop Suite**.
- The side menu still exposes **All Programs**, AEGIS Suite, Important System Services, System Files / Libraries, and Sentinel Critical.
- Desktop launcher owner detection now uses a batched `dpkg-query -S` pass.
- Local launcher discovery reuses the same ownership map instead of querying each file one by one.
- Normal GUI refresh skips `apt-mark showmanual/showauto`. Set `SENTINEL_SPM_DEEP_APT_METADATA=1` if deep manual/auto metadata is needed.
- Collected records cache their group ID so display/filtering does not re-run full classification repeatedly.

## Theme changes

- Ttk entry and combobox styles are now dark themed.
- Tk palette is set to dark/gold/cyan values where the toolkit allows it.
- Critical checkboxes use a controlled dark `tk.Checkbutton` so selected check areas no longer show as bright white boxes on MATE/Tk themes.

## Drag/drop

Drag/drop remains intentionally out of scope for v1.0.

Supported local installer paths remain:

- double-click/open-with,
- Browse/Choose,
- Paste Path,
- type/paste path + Enter.
