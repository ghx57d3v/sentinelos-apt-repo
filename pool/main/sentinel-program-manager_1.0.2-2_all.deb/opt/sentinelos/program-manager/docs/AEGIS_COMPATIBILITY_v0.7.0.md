# v0.7.0 AEGIS Compatibility Layer

Program 101 now exposes an initial machine-readable AEGIS CLI layer.

Commands:

```bash
sentinel-program-manager --aegis-status --json
sentinel-program-manager --aegis-actions --json
sentinel-program-manager --aegis-permissions --json
sentinel-program-manager --aegis-log --json
sentinel-program-manager --aegis-dry-run remove <package>
sentinel-program-manager --aegis-run remove <package>
sentinel-program-manager --aegis-dry-run uninstall-local <app-id>
sentinel-program-manager --aegis-run uninstall-local <app-id>
sentinel-program-manager --aegis-dry-run purge-local <app-id>
sentinel-program-manager --aegis-run purge-local <app-id>
```

Network/repository access remains blocked by default. Actual local `.deb` installs through the CLI require explicit environment opt-in: `SENTINEL_ALLOW_REPOSITORY_ACCESS=1`.
