# Sentinel Program Manager v0.8.1 — Purge-by-Default Uninstall

Program 101 now treats **Uninstall** as the complete cleanup action.

## Default behavior

- Dpkg/APT applications: **Uninstall** runs `apt-get purge` rather than `apt-get remove`.
- Local launcher applications: **Uninstall Local App** uses the purge plan, removing safe launcher/wrapper/app targets plus matching per-app config/data/cache folders.
- **Remove Only** remains available as the advanced option when the user wants to preserve configuration.

## Reason

Sentinel Program Manager is intended to feel like a normal user-facing uninstaller. A user pressing Uninstall generally expects the application and its leftover application configuration to be cleaned up, not merely detached while config files remain behind.

## Safety

- Protected packages remain blocked.
- System services, system files, libraries, and Sentinel Critical categories remain protected from landing-page uninstall.
- Previews remain available and recommended.
- Actual actions still require confirmation in the GUI.
