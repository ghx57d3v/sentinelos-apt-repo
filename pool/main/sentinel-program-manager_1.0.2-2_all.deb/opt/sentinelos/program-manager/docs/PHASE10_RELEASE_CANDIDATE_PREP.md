# Program 101 — v0.9.5 Final Polish / Release-Candidate Prep

Sentinel Program Manager v0.9.5 is the final polish and release-candidate preparation build before v1.0.

## Purpose

v0.9.5 does not add large new workflows. It tightens the program for the v1.0 lock-candidate path by adding final release-readiness checks, a clearer About identity surface, and final documentation around the locked Program 101 doctrine.

## Additions

- Adds **Release Check** on the Manual page.
- Adds **About** on the Manual page.
- Adds `--release-check` and `--aegis-release-check --json`.
- AEGIS status JSON now includes `release_readiness`.
- Wrapper now preserves stdout for diagnostics/self-test/release-check CLI commands.
- Manual text now labels this build as Phase 10 / v0.9.5 release-candidate preparation.

## Locked v1.0 doctrine

- Program 101 is the official SentinelOS installer/uninstaller.
- The landing page is a Windows-style Installed Programs & Uninstaller view.
- User-facing applications appear first.
- AEGIS Suite, Important System Services, System Files/Libraries, and Sentinel Critical packages are separated.
- Uninstall purges by default.
- Remove Only is the advanced non-purge path.
- Repository/internet package access is blocked unless explicitly enabled.
- Builder/export workflows belong to F.O.R.G.E.
- AEGIS local-control interfaces remain available for standing local authority.

## Recommended pre-v1.0 checks

Run:

```bash
sentinel-program-manager --diagnostics
sentinel-program-manager --release-check
sentinel-program-manager --aegis-status --json
sentinel-program-manager --aegis-release-check --json
```

Manual desktop checks:

- Open from the MATE menu.
- Confirm the landing page opens directly to Installed Programs.
- Confirm User Applications are first and libraries are not in the first section.
- Confirm AEGIS Suite Programs are shown under the AEGIS category.
- Double-click a local `.deb` file and confirm Local Installers opens.
- Double-click a `.tar.*` test bundle and confirm Local Installers opens.
- Preview then uninstall a harmless local test application.
- Confirm protected packages are blocked from landing-page removal.
