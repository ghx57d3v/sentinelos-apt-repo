# Program 101 Phase 4 — Safety Hardening

Sentinel Program Manager v0.6 completes the Phase 4 safety pass.

## UI polish

- User-installed / Sentinel Desktop Suite programs now appear first in the Installed Programs list.
- Ctrl+Q closes the application window.
- A Manual page is available from the side menu and notebook.

## Audit logging

Command actions and major threaded operations are written to:

```text
~/.local/share/sentinel-program-manager/logs/audit.log
```

The launcher and crash logs remain in the same log folder.

## Tar.* hardening

Local tar/archive imports are inspected before installation. Program Manager blocks:

- absolute paths,
- `../` path traversal,
- unsafe symlink/hardlink targets,
- device and FIFO entries,
- setuid/setgid permission bits,
- archives over the Program 101 size guardrail,
- archives with excessive member counts.

Extraction uses `tar --no-same-owner --no-same-permissions --delay-directory-restore`.

## Scope reminder

Program 101 installs, uninstalls, imports, repairs, and inspects software. Builder/export/package generation workflows belong in F.O.R.G.E.
