# Sentinel Program Manager v0.5.2 Crashfix

This patch fixes the immediate hang/close behavior observed after v0.5.1.

## Root cause fixed

A `tk.Label` was created with tuple `pady` values directly in the widget constructor. Tk expects a single screen-distance value there, so startup failed with:

```text
_tkinter.TclError: bad screen distance "8 2"
```

The padding was moved to `.pack(...)`, which accepts tuple padding.

## Additional hardening

- GUI logging is now queued from background worker threads and drained by the main Tk event loop.
- Worker exceptions now log tracebacks instead of only a short error string.
- Launcher stdout/stderr is captured to `~/.local/share/sentinel-program-manager/logs/launcher.log`.
- Unhandled startup/runtime crashes are captured to `~/.local/share/sentinel-program-manager/logs/crash.log`.
