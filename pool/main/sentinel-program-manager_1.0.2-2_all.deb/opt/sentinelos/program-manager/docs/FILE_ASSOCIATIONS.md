# Sentinel Program Manager File Associations

Program 101 Phase 3 adds official installer/importer file handling.

## Supported files

- `.deb`
- `.tar`
- `.tar.gz`
- `.tgz`
- `.tar.xz`
- `.txz`
- `.tar.bz2`
- `.tbz2`

## Expected behaviour

Opening a supported file path with Sentinel Program Manager starts the GUI and selects the **Local Installers** tab.

Examples:

```bash
sentinel-program-manager ./package.deb
sentinel-program-manager ./bundle.tar.gz
sentinel-program-manager ./bundle.tar.xz
```

`.deb` files populate the local Debian package installer and keep dry-run enabled.

`.tar.*` files populate the tar importer, auto-guess the app ID/title/command fields, and require preview/explicit install.

## Desktop entry

The desktop entry uses:

```ini
Exec=sentinel-program-manager %f
```

and declares MIME support for Debian packages and common tar/compressed tar types.

## Default handler

The Debian package post-install script updates desktop/icon caches and attempts to register Sentinel Program Manager as the system-level default handler in `/etc/xdg/mimeapps.list`.

This is the SentinelOS official behaviour: local installer files should open in Program Manager by default.
