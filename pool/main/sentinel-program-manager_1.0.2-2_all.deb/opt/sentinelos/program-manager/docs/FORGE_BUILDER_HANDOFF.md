# F.O.R.G.E Builder Handoff

Program 101 — Sentinel Program Manager is the official SentinelOS installer/uninstaller.

As of v0.4, package generation/export workflows are no longer part of the visible Program 101 interface. The following functions belong under F.O.R.G.E:

- Debian package builder
- tar.gz installer/bundle builder
- AppDir/AppImage builder
- ISO builder/staging workflows
- release artifact generation
- checksums/manifests/signing preparation

Sentinel Program Manager may continue to install/import local `.deb` and `.tar.*` files, but F.O.R.G.E owns building and release-output generation.
