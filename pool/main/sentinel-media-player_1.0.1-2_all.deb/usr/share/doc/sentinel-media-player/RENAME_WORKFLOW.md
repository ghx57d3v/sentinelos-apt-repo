# Sentinel Media Player v0.5.11 Rename Status / Clean Catalogue Reflection Patch

Renaming is owned by Sentinel Media Index. The player only shows rename status, launches safe instructions, and reloads the fast catalogue after Media Index writes it.

Commands:

```bash
sentinel-media-index --propose-renames ~/rename_plan.json --json
sentinel-media-index --apply-renames ~/rename_plan.json --execute --confirm RENAME_MEDIA --json
sentinel-media-index --write-player-catalogue --json
sentinel-media-player --rename-profile
```
