# Sentinel Media Player v0.5.16 Validation Summary

Validated locally in the build container:

- Python syntax compile passed for app.py and cli.py.
- Full package module compileall passed before final cleanup.
- CLI version reports 0.5.16.
- CLI `--poster-database-profile` returns valid JSON.
- Static checks found left-sidebar Movies, TV Shows, Music buttons.
- Static checks confirmed no top Catalogue-page Refresh List toolbar block remains.
- Static checks confirmed Add Poster Database GUI method and settings entries.
- Static checks confirmed local poster database roots are included in artwork resolution before standard fallbacks.
- Debian package build completed.
- Final package/source no `__pycache__` or `.pyc` check passed.


## v0.5.23 - Final Polish / v1 Lock Preparation Pass

- Adds non-mutating final polish audit tooling for Program 119.
- Adds v1 stable-lock preparation profile while keeping the package below stable lock until live SentinelOS/MATE validation is recorded.
- Preserves fast-start catalogue loading, Library search, drag/drop playback, subtitle overlay safe mode, manual subtitles, and Continue Last resume.
- Pairs with Sentinel Media Index v1.0.7 as the stable Program 118 catalogue authority.

Commands:

```bash
sentinel-media-player-final-audit
sentinel-media-player-v1-lock-prep-status
sentinel-media-player-stable-lock-report /tmp/sentinel-media-player-v1-lock-prep.md
```


## v0.5.24 - Simple Player / On-Demand Catalogue Pivot

- Opens to **Now Playing** instead of the poster catalogue.
- Keeps the player responsive while Media Index metadata loads in a background worker.
- Defers GTK poster/tile construction until the user opens **Library** from the sidebar or menu.
- Keeps drag/drop, Open Files, Continue Last, subtitle safe mode, Library search, and Load More.
- Adds `sentinel-media-player-simple-mode-status` / `--simple-player-profile`.
- Does not mutate Sentinel Media Index; the catalogue remains an optional Program 118-backed view.
