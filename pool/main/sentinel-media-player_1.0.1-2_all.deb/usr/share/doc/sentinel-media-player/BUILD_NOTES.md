# Sentinel Media Player v0.5.16 Build Notes

Build target: Program 119 Sentinel Media Player v0.5.16.

Patch focus:
- Catalogue sidebar category navigation.
- Catalogue page simplification.
- Local/offline poster database support.

User-facing changes:
- Left command sidebar now includes Movies, TV Shows, and Music filters.
- Catalogue page no longer has a top Refresh List button; catalogue content is the focus.
- Refresh Catalogue stays in the sidebar as the single explicit refresh action.
- Added Add Poster Database action to configure a local folder of posters/covers.
- Added Settings menu entries for adding and viewing local poster databases.
- Local poster database artwork is checked before sidecar/thumbnail/online artwork fallback.

Offline poster database matching examples:
- PosterDB/Movie Title (Year).jpg
- PosterDB/Movie Title (Year)/poster.jpg
- PosterDB/Movies/Movie Title-poster.jpg
- PosterDB/tmdb_id/poster.jpg

CLI additions:
- sentinel-media-player --poster-database-profile
- sentinel-media-player --add-poster-database PATH
- sentinel-media-player --remove-poster-database PATH
- sentinel-media-player-poster-database-status
