# File Association

The desktop launcher uses:

```text
Exec=sentinel-media-player %U
```

The app accepts both regular paths and `file://` URI arguments from file managers.

To set Sentinel Media Player as the preferred app for common local audio/video files for the current user, run:

```bash
sentinel-media-player-set-defaults
```
