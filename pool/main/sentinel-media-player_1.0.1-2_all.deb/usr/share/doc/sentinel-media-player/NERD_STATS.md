# Nerd Stats

Nerd Stats presents a cleaner readable summary first, followed by a detailed metadata view. Local file/index metadata is always local. Online lookup remains optional, manual/user-triggered, and disabled by default.
