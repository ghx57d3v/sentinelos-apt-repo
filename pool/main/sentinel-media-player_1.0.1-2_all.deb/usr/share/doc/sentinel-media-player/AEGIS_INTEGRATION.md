# AEGIS Integration Update v0.5.1

v0.5.1 exposes header quick-category navigation and artwork discovery status for AEGIS/Sentinel Command integration.

Policy:

```text
Sentinel Media Index = scanner, catalogue, online enrichment/cache authority
Sentinel Media Player = playback, display, queue, Nerd Stats viewer
```

Useful commands:

```bash
sentinel-media-player --metadata-authority-profile
sentinel-media-player --artwork-profile
sentinel-media-player-ui-status
sentinel-media-player-artwork-status
```

Player background network fetch remains disabled. Fallback online lookup is only user-triggered.


## v0.5.1 Crash Guard / Lazy Artwork Loader

Heavy local artwork generation and broad recursive artwork scanning are disabled during startup by default. The library now renders first using Media Index artwork fields, direct sidecars, and existing Caja/MATE thumbnail cache lookups. FFmpeg/thumbnail generation is opt-in to prevent long loads or GTK crashes on large catalogues.
