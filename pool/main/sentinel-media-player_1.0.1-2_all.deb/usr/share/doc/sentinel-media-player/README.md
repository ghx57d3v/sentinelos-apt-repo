# Sentinel Media Player v1.0.0~rc1

Program 119 Sentinel Media Player is a local-first AEGIS-ready GTK/GStreamer media player. v1.0.0~rc1 is the Phase 3 v1 release-candidate package with a taller screen-clamped default window. v0.5.1 adds symmetrical header quick-category buttons and strengthens movie/album cover-art discovery.

## Core posture

- Local-first playback.
- Sentinel Media Index is the default catalogue and metadata authority.
- Player-side online Nerd Stats lookup is fallback/manual only.
- Now Playing is the default landing workspace. Library is an optional tabless catalogue board opened from the sidebar/menu.
- Header quick buttons: TV Shows, Movies, eBooks, Music.
- Queue is an explicit play queue, not a mirror of the whole catalogue.
- No telemetry and no background network metadata fetching. Catalogue tile rendering is on-demand.


## v0.5.1 Crash Guard / Lazy Artwork Loader

Heavy local artwork generation and broad recursive artwork scanning are disabled during startup by default. The library now renders first using Media Index artwork fields, direct sidecars, and existing Caja/MATE thumbnail cache lookups. FFmpeg/thumbnail generation is opt-in to prevent long loads or GTK crashes on large catalogues.


## v0.5.1 - Manual Retrieve Art Button Patch

Adds user-triggered Retrieve Art controls in the Library tile actions, Nerd Stats workspace, and top menus. Heavy artwork generation/extraction remains disabled during startup; manual recovery runs only for the selected/current item. Sentinel Media Index remains the preferred permanent artwork authority through poster_path, thumbnail_path, cover_path, and artwork_path fields.


## v0.5.17 playback runtime note

Catalogue video playback requires a working GStreamer sink and codec stack. Run `sentinel-media-player-playback-status` if Library tiles load but video does not start.


## v0.5.18 - Subtitle Controls / Playback Validation Patch

- Adds Playback menu actions: `Load External Subtitles…` and `Remove / Disable Subtitles`.
- Adds Now Playing buttons: `Subtitles` and `No Subs`.
- Adds keyboard shortcut: `S` toggles subtitles.
- Supports sidecar/manual external subtitle files: `.srt`, `.ass`, `.ssa`, `.vtt`, `.sub`.
- Auto-detects subtitle files beside the video, including `Movie.srt`, `Movie.en.srt`, `Subs/Movie.srt`, and `Subtitles/Movie.en.srt`.
- Remove/Disable hides subtitles only; it never deletes subtitle files from disk.
- Adds `sentinel-media-player-subtitle-status` / `--subtitle-profile` diagnostics.


## v0.5.21 Continue Last / v1 readiness patch

Adds local-only playback resume state, Sidebar/Playback-menu Continue Last, and Settings -> Remember playback position. Resume data is stored only in the user's Sentinel Media Player config and does not mutate Sentinel Media Index. New diagnostics: `sentinel-media-player-resume-status` and `sentinel-media-player-v1-readiness-status`.


## v0.5.23 - Final Polish / v1 Lock Preparation Pass

- Adds non-mutating final polish audit tooling for Program 119.
- Adds v1 stable-lock preparation profile while keeping the package below stable lock until live SentinelOS/MATE validation is recorded.
- Preserves fast-start catalogue loading, Library search, drag/drop playback, subtitle overlay safe mode, manual subtitles, and Continue Last resume.
- Pairs with Sentinel Media Index v1.0.7 as the stable Program 118 catalogue authority.

Commands:

```bash
sentinel-media-player-final-audit
sentinel-media-player-v1-lock-prep-status
sentinel-media-player-stable-lock-report /tmp/sentinel-media-player-v1-lock-prep.md
```


## v0.5.24 - Simple Player / On-Demand Catalogue Pivot

- Opens to **Now Playing** instead of the poster catalogue.
- Keeps the player responsive while Media Index metadata loads in a background worker.
- Defers GTK poster/tile construction until the user opens **Library** from the sidebar or menu.
- Keeps drag/drop, Open Files, Continue Last, subtitle safe mode, Library search, and Load More.
- Adds `sentinel-media-player-simple-mode-status` / `--simple-player-profile`.
- Does not mutate Sentinel Media Index; the catalogue remains an optional Program 118-backed view.
