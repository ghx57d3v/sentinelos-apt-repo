# Sentinel Media Player v1.0.0~rc1

Phase 3 v1 release-candidate promotion. This rc1 keeps the simple-player feature freeze, raises the default window height to 900x620 with screen clamping, preserves Now Playing startup, bounded file-grid Library, drag/drop playback, manual subtitles with overlay safe mode, Continue Last, and no Media Index mutation. Only blocker fixes should be accepted before stable lock.

# Sentinel Media Player 0.5.25

Simple File-Grid Library Pivot. The Player no longer opens or depends on a catalogue/poster view for normal use. Startup opens directly to Now Playing and does not auto-load the Media Index catalogue. The Library is a bounded grid file viewer over four approved user folders only: `~/Videos/Movies`, `~/Videos/TV Shows`, `~/Music`, and `~/Documents/eBooks`. The grid uses lightweight file-type icons, scans in the background only when opened/refreshed, and preserves drag/drop, Open Files/Open Folder, subtitles, Continue Last, and v1 audit commands.

# Sentinel Media Player v0.5.24

Continue Last / v1 Readiness Patch over v0.5.20.

- Adds local-only playback position saving for video/audio.
- Adds Sidebar and Playback menu Continue Last.
- Adds Settings -> Remember playback position.
- Saves resume state compactly in user config; does not mutate Sentinel Media Index.
- Preserves fast catalogue loading, drag/drop playback, and subtitle overlay safe mode.
- Adds v1 readiness diagnostics for RC validation.

# Sentinel Media Player v0.5.24

Subtitle Controls / Playback Validation Patch over v0.5.17.

- Adds first-class subtitle controls for catalogue video playback.
- Playback menu now includes `Load External Subtitles…` and `Remove / Disable Subtitles`.
- Now Playing controls include `Subtitles` and `No Subs`.
- Keyboard shortcut `S` toggles subtitles.
- Supports sidecar/manual `.srt`, `.ass`, `.ssa`, `.vtt`, and `.sub` files through GStreamer playbin `suburi`.
- Preserves embedded subtitle stream support through GStreamer playbin text flags.
- Auto-detects sidecar subtitle files next to media and in `Subs/` or `Subtitles/` subfolders.
- Remove/Disable hides subtitle streams and clears the external subtitle binding without deleting subtitle files.
- Adds `sentinel-media-player-subtitle-status` / `--subtitle-profile`.
- Green/blocky video symptom is treated as a per-file decode/encode/sink compatibility issue when other videos play correctly; v0.5.18 keeps runtime diagnostics but does not mutate media files.

# Sentinel Media Player v0.5.17

Playback Runtime / Catalogue Video Hotfix over v0.5.16.

- Promotes common local video playback dependencies from optional/recommended to package dependencies: libav, bad, ugly, x, and gl GStreamer plugins.
- Adds `sentinel-media-player-playback-status` / `--playback-runtime-status` to diagnose local GStreamer sink and codec readiness.
- Adds GTK video sink fallback handling: tries `gtksink`, then `gtkglsink`, then bounded system video sink fallbacks with a clear UI status note.
- Improves catalogue video failure messages so a missing codec/video sink no longer looks like a dead Library tile.
- Preserves Media Index fast-catalogue-only startup, lazy board rendering, local-first posture, and v0.5.16 local poster database work.

# Sentinel Media Player v0.5.16

Catalogue sidebar / local poster database patch.

- Catalogue page no longer has a top Refresh List button.
- Left command sidebar now includes Movies, TV Shows, and Music catalogue filters.
- Refresh Catalogue remains a sidebar action, not a catalogue-page toolbar button.
- Added local poster database support so users can add offline poster/cover folders instead of relying on online retrieval.
- Local poster database folders are checked after Media Index artwork fields and before sidecar/thumbnail/online artwork fallback.
- Added CLI: `--poster-database-profile`, `--add-poster-database PATH`, `--remove-poster-database PATH`.
- Added wrapper: `sentinel-media-player-poster-database-status`.


## 0.5.20 - Subtitle Overlay Safe Mode Hotfix

- Adds safe subtitle overlay mode after field report that one video rendered green/blocky when subtitles were overlaid while audio remained fine.
- Suppresses automatic sidecar/embedded subtitle overlay during normal playback by default; subtitles can still be enabled manually per video with S or Load External Subtitles.
- Adds Settings -> Safe subtitle overlay mode and diagnostic `sentinel-media-player-subtitle-overlay-status`.
- Keeps Remove / Disable Subtitles as hide-only; no subtitle files are deleted.


## v0.5.23 - Final Polish / v1 Lock Preparation Pass

- Adds non-mutating final polish audit tooling for Program 119.
- Adds v1 stable-lock preparation profile while keeping the package below stable lock until live SentinelOS/MATE validation is recorded.
- Preserves fast-start catalogue loading, Library search, drag/drop playback, subtitle overlay safe mode, manual subtitles, and Continue Last resume.
- Pairs with Sentinel Media Index v1.0.7 as the stable Program 118 catalogue authority.

Commands:

```bash
sentinel-media-player-final-audit
sentinel-media-player-v1-lock-prep-status
sentinel-media-player-stable-lock-report /tmp/sentinel-media-player-v1-lock-prep.md
```


## v0.5.24 - Simple Player / On-Demand Catalogue Pivot

- Opens to **Now Playing** instead of the poster catalogue.
- Keeps the player responsive while Media Index metadata loads in a background worker.
- Defers GTK poster/tile construction until the user opens **Library** from the sidebar or menu.
- Keeps drag/drop, Open Files, Continue Last, subtitle safe mode, Library search, and Load More.
- Adds `sentinel-media-player-simple-mode-status` / `--simple-player-profile`.
- Does not mutate Sentinel Media Index; the catalogue remains an optional Program 118-backed view.


## v0.5.29 - Phase 2 Live Validation Checkpoint

- Adds non-mutating Phase 2 live SentinelOS/MATE validation profile.
- Preserves Phase 1 feature freeze.
- No new user-facing features. This build is intended to validate the frozen v1 scope before 1.0.0~rc1.
- New wrapper: `sentinel-media-player-phase2-live-validation-status`.
