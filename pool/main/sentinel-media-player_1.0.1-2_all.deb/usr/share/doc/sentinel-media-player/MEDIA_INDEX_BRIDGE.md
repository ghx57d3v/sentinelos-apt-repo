# Media Index Bridge v0.4.8

Sentinel Media Player treats Sentinel Media Index as the catalogue and metadata authority.

The player reads enriched metadata and artwork fields from Media Index first. v0.4.8 expands artwork recovery so movie and album/single covers can be found even when the index stores relative artwork paths or common sidecar names.

Supported artwork sources include:

- poster_path / thumbnail_path / fanart_path / cover / cover_path / artwork fields
- relative paths beside the media file
- relative paths beside the Media Index/export file
- Media Index artwork roots such as artwork, covers, posters, thumbnails
- movie-folder sidecars like poster.jpg, folder.jpg, cover.jpg
- album-folder sidecars like cover.jpg, folder.jpg, front.jpg, album.jpg
- same-stem images like MovieName-poster.jpg or SongName-cover.jpg
- identifier-based artwork using imdb/tmdb/tvmaze/musicbrainz/wikidata ids
- optional embedded audio artwork through python3-mutagen

Online enrichment should be handled in Sentinel Media Index. The player reads cached/enriched results from the index and only performs Player-side online lookup when the user explicitly requests fallback Nerd Stats lookup.
