# Sentinel Media Player v0.5.6 Validation

Validation performed during package build:

- Python compile checks passed.
- CLI version reports 0.5.1.
- AEGIS status/actions JSON passed.
- UI/library/metadata/catalogue/desktop/file-association profiles passed.
- Artwork profile JSON passed.
- Self-test passed.
- Synthetic Media Index test covered video, audio, eBook rows, relative artwork fields, and filtered catalogue behaviour.
- Static checks confirmed symmetrical header quick buttons, eBooks category, artwork recovery helpers, hidden main workspace tabs, no main-window fullscreen calls, overlay hotfix preservation, and real queue preservation.
- Debian package built cleanly.
- Package content check confirms no `__pycache__` or `.pyc` files.


## v0.5.6 Crash Guard / Lazy Artwork Loader

Heavy local artwork generation and broad recursive artwork scanning are disabled during startup by default. The library now renders first using Media Index artwork fields, direct sidecars, and existing Caja/MATE thumbnail cache lookups. FFmpeg/thumbnail generation is opt-in to prevent long loads or GTK crashes on large catalogues.


## v0.5.6 - Manual Retrieve Art Button Patch

Adds user-triggered Retrieve Art controls in the Library tile actions, Nerd Stats workspace, and top menus. Heavy artwork generation/extraction remains disabled during startup; manual recovery runs only for the selected/current item. Sentinel Media Index remains the preferred permanent artwork authority through poster_path, thumbnail_path, cover_path, and artwork_path fields.
