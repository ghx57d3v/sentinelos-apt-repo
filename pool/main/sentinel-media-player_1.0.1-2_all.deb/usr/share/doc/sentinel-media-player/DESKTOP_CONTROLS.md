# Desktop Controls Update v0.4.8

Desktop controls from earlier foundation patches are preserved. v0.4.8 adds symmetrical header quick category buttons on the right side of the hero/header area.

Header quick buttons:

- TV Shows
- Movies
- eBooks
- Music

Hotkeys remain:

- Ctrl+Q close
- Space play/pause
- Left/Right ±10 seconds
- Up/Down volume
- F11 video-only fullscreen
- Escape exit fullscreen
- Double-tap video toggles video-only fullscreen
