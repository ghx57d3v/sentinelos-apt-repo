VERSION = "1.0.1"
APP_ID = "com.sentinelos.SentinelMediaPlayer"
APP_NAME = "Sentinel Media Player"
PACKAGE_NAME = "sentinel-media-player"
PROGRAM_NUMBER = 119
