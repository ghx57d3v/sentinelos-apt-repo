from __future__ import annotations

import hashlib
import json
import os
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Dict, List, Optional

from . import APP_NAME, VERSION
from .aegis import CACHE_DIR, audit, load_config
from .bridge import MediaItem, find_item_for_path, format_seconds
from .formats import classify_media_path, extension_for_path

CACHE_PATH = CACHE_DIR / "nerd_stats_cache.json"
TAG_PATTERNS = [
    r"\b(2160p|1080p|720p|480p|4k|uhd|hdr|hdr10|webrip|web[-_. ]?dl|bluray|brrip|dvdrip|x264|x265|h264|h265|hevc|aac|dts|truehd|atmos)\b",
    r"\[[^\]]+\]", r"\([^)]*(?:x264|x265|1080p|720p|webrip|bluray|aac|hdtv)[^)]*\)",
]
SEASON_EPISODE_RE = re.compile(r"(?P<title>.*?)[. _-]*[sS](?P<season>\d{1,2})[eE](?P<episode>\d{1,3})(?:[. _-]*(?P<ep_title>.*))?")


def clean_title(raw: str) -> str:
    text = Path(raw).stem if os.path.sep in raw or "." in Path(raw).name else raw
    text = text.replace("_", " ").replace(".", " ").replace("-", " ")
    for pattern in TAG_PATTERNS:
        text = re.sub(pattern, " ", text, flags=re.IGNORECASE)
    text = re.sub(r"\b(19\d{2}|20\d{2})\b", lambda m: f" {m.group(1)} ", text)
    text = re.sub(r"\s+", " ", text).strip(" ._-")
    return text or raw


def infer_item(value: str) -> MediaItem:
    found = find_item_for_path(value)
    if found:
        return found
    p = Path(os.path.expanduser(value))
    media_type = classify_media_path(str(p)) if p.suffix else "unknown"
    title = clean_title(value)
    m = SEASON_EPISODE_RE.match(Path(value).stem)
    series = ""
    season = ""
    episode = ""
    if m:
        series = clean_title(m.group("title"))
        season = str(int(m.group("season")))
        episode = str(int(m.group("episode")))
        title = series
    return MediaItem(path=str(p) if p.suffix else "", title=title, media_type=media_type, source="query", series=series, season=season, episode=episode)


def local_stats(item: MediaItem) -> Dict[str, Any]:
    p = Path(os.path.expanduser(item.path)) if item.path else None
    file_info: Dict[str, Any] = {}
    if p and p.exists():
        stat = p.stat()
        file_info = {
            "path": str(p),
            "filename": p.name,
            "extension": extension_for_path(str(p)),
            "size_bytes": stat.st_size,
            "modified_epoch": int(stat.st_mtime),
            "exists": True,
        }
    elif item.path:
        file_info = {"path": item.path, "exists": False}
    title_for_lookup = item.series or item.title or (p.stem if p else "")
    return {
        "title": item.title,
        "lookup_title": title_for_lookup,
        "media_type": item.media_type,
        "source": item.source,
        "file": file_info,
        "media_index_metadata": {
            "artist": item.artist,
            "album": item.album,
            "year": item.year,
            "series": item.series,
            "season": item.season,
            "episode": item.episode,
            "duration": item.duration,
            "duration_pretty": format_seconds(item.duration_seconds()),
            "ids": {
                "imdb_id": item.imdb_id,
                "tmdb_id": item.tmdb_id,
                "tvmaze_id": item.tvmaze_id,
                "musicbrainz_id": item.musicbrainz_id,
                "wikidata_id": item.wikidata_id,
            },
            "rating": getattr(item, "rating", ""),
            "director": getattr(item, "director", ""),
            "cast": getattr(item, "cast", ""),
            "creator": getattr(item, "creator", ""),
            "metadata_authority": "Sentinel Media Index",
            "metadata_source": getattr(item, "metadata_source", ""),
            "metadata_provider": getattr(item, "metadata_provider", ""),
            "metadata_status": getattr(item, "metadata_status", ""),
            "metadata_enriched_at": getattr(item, "metadata_enriched_at", ""),
            "metadata_cached": getattr(item, "metadata_cached", ""),
            "skip_markers": {
                "intro_start": item.intro_start,
                "intro_end": item.intro_end,
                "credits_start": item.credits_start,
                "credits_end": item.credits_end,
            },
        },
    }


def cache_key(query: str, kind: str) -> str:
    return hashlib.sha256(f"{kind}\0{query.lower().strip()}".encode("utf-8")).hexdigest()


def load_cache() -> Dict[str, Any]:
    try:
        if CACHE_PATH.exists():
            data = json.loads(CACHE_PATH.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                return data
    except Exception as exc:
        audit("nerd_stats_cache_load", str(exc), "warning")
    return {}


def _path_has_symlink_component(path: Path) -> bool:
    p = Path(path).expanduser()
    try:
        if p.is_symlink():
            return True
    except Exception:
        return True
    cur = Path(p.anchor) if p.is_absolute() else Path.cwd()
    parts = p.parts[1:] if p.is_absolute() else p.parts
    for part in parts:
        cur = cur / part
        try:
            if cur.exists() and cur.is_symlink():
                return True
        except Exception:
            return True
    return False


def save_cache(cache: Dict[str, Any]) -> None:
    try:
        if _path_has_symlink_component(CACHE_DIR) or (CACHE_PATH.exists() and CACHE_PATH.is_symlink()):
            raise RuntimeError(f"unsafe nerd stats cache path: {CACHE_PATH}")
        CACHE_DIR.mkdir(parents=True, exist_ok=True)
        tmp = CACHE_PATH.with_name(CACHE_PATH.name + f".tmp-{os.getpid()}")
        if tmp.exists() or tmp.is_symlink():
            tmp.unlink(missing_ok=True)
        fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                fh.write(json.dumps(cache, indent=2, sort_keys=True))
            os.replace(tmp, CACHE_PATH)
        finally:
            try:
                if tmp.exists() or tmp.is_symlink():
                    tmp.unlink()
            except Exception:
                pass
    except Exception as exc:
        audit("nerd_stats_cache_save", str(exc), "warning")


def fetch_json(url: str, *, timeout: int = 8) -> Dict[str, Any]:
    config = load_config()
    headers = {
        "User-Agent": str(config.get("nerd_stats_user_agent") or f"{APP_NAME}/{VERSION}"),
        "Accept": "application/json",
    }
    request = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(request, timeout=timeout) as response:  # nosec B310 - user-initiated public metadata lookup
        raw = response.read(2_000_000)
    return json.loads(raw.decode("utf-8", errors="replace"))


def fetch_musicbrainz(query: str, item: MediaItem) -> Dict[str, Any]:
    term = item.musicbrainz_id or query
    if item.musicbrainz_id:
        url = f"https://musicbrainz.org/ws/2/recording/{urllib.parse.quote(term)}?fmt=json&inc=artists+releases+genres+tags+ratings"
    else:
        q = f'recording:"{query}"'
        if item.artist:
            q += f' AND artist:"{item.artist}"'
        url = "https://musicbrainz.org/ws/2/recording/?" + urllib.parse.urlencode({"query": q, "fmt": "json", "limit": "5"})
    data = fetch_json(url)
    return {"source": "MusicBrainz", "query": query, "result": data}


def fetch_tvmaze(query: str, item: MediaItem) -> Dict[str, Any]:
    title = item.series or query
    if item.tvmaze_id:
        show_id = item.tvmaze_id
        show = fetch_json(f"https://api.tvmaze.com/shows/{urllib.parse.quote(str(show_id))}")
    else:
        url = "https://api.tvmaze.com/singlesearch/shows?" + urllib.parse.urlencode({"q": title})
        show = fetch_json(url)
    payload: Dict[str, Any] = {"source": "TVmaze", "query": title, "show": show}
    if item.season and item.episode and show.get("id"):
        try:
            ep_url = f"https://api.tvmaze.com/shows/{show['id']}/episodebynumber?" + urllib.parse.urlencode({"season": item.season, "number": item.episode})
            payload["episode"] = fetch_json(ep_url)
        except Exception as exc:
            payload["episode_error"] = str(exc)
    return payload


def fetch_wikidata(query: str, item: MediaItem) -> Dict[str, Any]:
    if item.wikidata_id:
        qid = item.wikidata_id
        entity_url = f"https://www.wikidata.org/wiki/Special:EntityData/{urllib.parse.quote(qid)}.json"
        return {"source": "Wikidata", "query": qid, "entity": fetch_json(entity_url)}
    search_url = "https://www.wikidata.org/w/api.php?" + urllib.parse.urlencode({
        "action": "wbsearchentities",
        "language": "en",
        "format": "json",
        "limit": "5",
        "search": query,
    })
    search = fetch_json(search_url)
    payload: Dict[str, Any] = {"source": "Wikidata", "query": query, "search": search}
    try:
        first = (search.get("search") or [])[0]
        qid = first.get("id")
        if qid:
            payload["entity"] = fetch_json(f"https://www.wikidata.org/wiki/Special:EntityData/{urllib.parse.quote(qid)}.json")
    except Exception:
        pass
    return payload


def fetch_tmdb_optional(query: str, item: MediaItem, kind: str) -> Optional[Dict[str, Any]]:
    token = os.environ.get("SENTINEL_MEDIA_PLAYER_TMDB_TOKEN") or os.environ.get("TMDB_BEARER_TOKEN")
    if not token:
        return None
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json",
        "User-Agent": f"{APP_NAME}/{VERSION}",
    }
    if item.tmdb_id and kind in {"movie", "tv"}:
        endpoint = "movie" if kind == "movie" else "tv"
        url = f"https://api.themoviedb.org/3/{endpoint}/{urllib.parse.quote(str(item.tmdb_id))}"
    else:
        search_type = "movie" if kind == "movie" else "tv" if kind in {"episode", "tv"} else "multi"
        url = f"https://api.themoviedb.org/3/search/{search_type}?" + urllib.parse.urlencode({"query": query})
    request = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(request, timeout=8) as response:  # nosec B310 - user-initiated optional token lookup
        raw = response.read(2_000_000)
    return {"source": "TMDb", "query": query, "result": json.loads(raw.decode("utf-8", errors="replace"))}


def infer_kind(item: MediaItem, requested: str = "auto") -> str:
    if requested and requested != "auto":
        return requested
    if item.media_type == "audio" or item.artist or item.album or item.musicbrainz_id:
        return "song"
    if item.series or item.season or item.episode or re.search(r"[sS]\d{1,2}[eE]\d{1,3}", item.path or item.title):
        return "episode"
    if item.media_type == "video":
        return "movie"
    return "auto"


def online_stats(item: MediaItem, kind: str = "auto") -> Dict[str, Any]:
    kind = infer_kind(item, kind)
    query = item.series or item.title or clean_title(item.path)
    config = load_config()
    use_cache = bool(config.get("nerd_stats_cache_enabled", True))
    key = cache_key(query, kind)
    cache = load_cache() if use_cache else {}
    if use_cache and key in cache:
        cached = dict(cache[key])
        cached["cache_hit"] = True
        return cached
    payload: Dict[str, Any] = {
        "query": query,
        "kind": kind,
        "cache_hit": False,
        "fetched_epoch": int(time.time()),
        "sources": [],
        "errors": [],
    }
    attempts: List[str]
    if kind == "song":
        attempts = ["musicbrainz", "wikidata"]
    elif kind == "episode":
        attempts = ["tvmaze", "wikidata", "tmdb"]
    elif kind == "movie":
        attempts = ["wikidata", "tmdb"]
    else:
        attempts = ["musicbrainz", "tvmaze", "wikidata", "tmdb"]
    for source in attempts:
        try:
            if source == "musicbrainz":
                payload["sources"].append(fetch_musicbrainz(query, item))
            elif source == "tvmaze":
                payload["sources"].append(fetch_tvmaze(query, item))
            elif source == "wikidata":
                payload["sources"].append(fetch_wikidata(query, item))
            elif source == "tmdb":
                result = fetch_tmdb_optional(query, item, kind)
                if result:
                    payload["sources"].append(result)
                else:
                    payload["sources"].append({"source": "TMDb", "skipped": "No SENTINEL_MEDIA_PLAYER_TMDB_TOKEN/TMDB_BEARER_TOKEN set."})
        except urllib.error.HTTPError as exc:
            payload["errors"].append({"source": source, "error": f"HTTP {exc.code}: {exc.reason}"})
        except Exception as exc:
            payload["errors"].append({"source": source, "error": str(exc)})
    if use_cache:
        cache[key] = payload
        save_cache(cache)
    audit("nerd_stats_online", f"query={query} kind={kind} sources={len(payload['sources'])} errors={len(payload['errors'])}", "ok" if not payload["errors"] else "warning")
    return payload


def nerd_stats(value: str, *, kind: str = "auto", allow_online: bool = False) -> Dict[str, Any]:
    item = infer_item(value)
    payload: Dict[str, Any] = {
        "app": APP_NAME,
        "version": VERSION,
        "mode": "online" if allow_online else "local",
        "local": local_stats(item),
        "online": None,
        "privacy": {
            "background_fetching": False,
            "online_default": False,
            "online_lookup_requires_user_action": True,
            "cache_path": str(CACHE_PATH),
        },
    }
    if allow_online:
        payload["online"] = online_stats(item, kind)
    return payload
