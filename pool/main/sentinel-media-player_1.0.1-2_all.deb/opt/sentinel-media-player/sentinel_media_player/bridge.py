from __future__ import annotations

import csv
import json
import os
import re
import sqlite3
from urllib.parse import unquote, urlparse
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

from .aegis import audit
from .formats import classify_media_path, is_media_path, is_catalogue_path

FAST_CATALOGUE_NAMES = {"player_catalogue.json", "sentinel_media_player_catalogue.json", "program119_catalogue.json"}
FAST_CATALOGUE_CONTRACTS = {"sentinel_media_player_fast_catalogue_v1", "sentinel_media_player_catalogue_v1"}
FAST_CATALOGUE_DEFAULT_PATHS = [
    "~/.local/share/sentinel-media-index/player_catalogue.json",
    "~/.local/share/sentinel-media-index/player_libraries/sentinel_media_player_catalogue.json",
    "~/.local/share/sentinel-media-index/exports/player_catalogue.json",
]
FAST_CONTRACT_ONLY_DEFAULT = True
RAW_DISCOVERY_MAX_FILES = 8

INDEX_CANDIDATES = [
    # Fast Program 119 catalogue contracts exported by Sentinel Media Index v1.0.1+.
    "~/.local/share/sentinel-media-index/player_catalogue.json",
    "~/.local/share/sentinel-media-index/player_libraries/sentinel_media_player_catalogue.json",
    "~/.local/share/sentinel-media-index/exports/player_catalogue.json",
    # Official/newer Sentinel Media Index names.
    "~/.local/share/sentinel-media-index/media_index.sqlite3",
    "~/.local/share/sentinel-media-index/media_index.sqlite",
    "~/.local/share/sentinel-media-index/sentinel_media_index.sqlite",
    "~/.local/share/sentinel-media-index/sentinel-media-index.sqlite",
    "~/.local/share/sentinel-media-index/index.sqlite",
    "~/.local/share/sentinel-media-index/library.sqlite",
    "~/.local/share/sentinel-media-index/catalogue.sqlite",
    "~/.local/share/sentinel-media-index/catalog.sqlite",
    "~/.local/share/sentinel-media-index/media.db",
    "~/.local/share/sentinel-media-index/media_index.db",
    "~/.local/share/sentinel-media-index/sentinel_media_index.db",
    "~/.local/share/sentinel-media-index/index.db",
    "~/.local/share/sentinel-media-index/library.db",
    "~/.local/share/sentinel-media-index/catalogue.db",
    "~/.local/share/sentinel-media-index/catalog.db",
    "~/.local/share/sentinel-media-index/media_player_handoff.json",
    "~/.local/share/sentinel-media-index/library.json",
    "~/.local/share/sentinel-media-index/catalogue.json",
    "~/.local/share/sentinel-media-index/media_index.json",
    "~/.local/share/sentinel-media-index/media_index.csv",
    "~/.local/share/sentinel-media-index/media_index.tsv",
    "~/.local/share/sentinel-media-index/exports/media_index.sqlite",
    "~/.local/share/sentinel-media-index/exports/media_index.db",
    "~/.local/share/sentinel-media-index/exports/media_index.json",
    "~/.local/share/sentinel-media-index/exports/media_index.csv",
    "~/.local/share/sentinel-media-index/exports/media_index.tsv",
    # Legacy/alternate Sentinel layout names.
    "~/.local/share/sentinel/media-index/media_index.sqlite",
    "~/.local/share/sentinel/media-index/index.sqlite",
    "~/.local/share/sentinel/media-index/library.sqlite",
    "~/.local/share/sentinel/media-index/media_index.db",
    "~/.local/share/sentinel/media-index/index.db",
    "~/.sentinel/media-index/media_index.sqlite",
    "~/.sentinel/media-index/index.sqlite",
    "~/.sentinel/media-index/library.sqlite",
    "~/.sentinel/media-index/media_index.db",
    "~/.sentinel/media-index/media_index.json",
    "~/.sentinel/media-index/media_index.csv",
    "~/.sentinel/media-index/media_index.tsv",
    "/var/lib/sentinel-media-index/media_index.sqlite",
    "/var/lib/sentinel-media-index/sentinel_media_index.sqlite",
    "/var/lib/sentinel-media-index/index.sqlite",
    "/var/lib/sentinel-media-index/media_index.db",
    "/var/lib/sentinel-media-index/media_index.json",
    "/var/lib/sentinel-media-index/media_index.csv",
]

PATH_KEYS = {
    "path", "file", "filepath", "file_path", "fullpath", "full_path", "absolute_path",
    "abs_path", "local_path", "canonical_path", "real_path", "resolved_path",
    "location", "file_location", "source", "source_path", "source_file", "media_path",
    "media_file", "media_file_path", "item_path", "entry_path", "content_path",
    "target", "target_path", "original_path", "uri", "file_uri", "media_uri", "url",
    "filename", "file_name", "name_on_disk",
}
TITLE_KEYS = {"title", "name", "display_name", "file_name", "filename", "label", "track_title", "episode_title", "movie_title"}
TYPE_KEYS = {"type", "kind", "media_type", "media_kind", "category", "library_category", "mime", "mimetype", "content_type", "file_type"}
DURATION_KEYS = {"duration", "duration_seconds", "length", "length_seconds", "runtime", "runtime_seconds"}
ARTIST_KEYS = {"artist", "artists", "album_artist", "creator", "performer", "composer"}
ALBUM_KEYS = {"album", "release", "record", "collection"}
YEAR_KEYS = {"year", "release_year", "date", "release_date", "first_aired", "aired"}
SERIES_KEYS = {"series", "show", "show_title", "tv_show", "program", "programme"}
SEASON_KEYS = {"season", "season_number", "s"}
EPISODE_KEYS = {"episode", "episode_number", "e"}
IDENTIFIER_KEYS = {
    "imdb_id", "tmdb_id", "tvmaze_id", "musicbrainz_id", "musicbrainz_recording_id", "mbid", "wikidata_id"
}
ARTWORK_KEYS = {"thumbnail", "thumbnail_path", "thumb", "thumb_path", "poster", "poster_path", "cover", "cover_path", "cover_art", "cover_art_path", "art", "art_path", "artwork", "artwork_path", "fanart", "fanart_path", "backdrop", "backdrop_path"}
GENRE_KEYS = {"genre", "genres", "style"}
COLLECTION_KEYS = {"collection", "collection_name", "set", "boxset", "playlist"}
DESCRIPTION_KEYS = {"description", "summary", "plot", "synopsis", "overview"}
QUALITY_KEYS = {"resolution", "quality", "video_quality", "height"}
PROGRESS_KEYS = {"progress", "watch_progress", "resume_position", "position", "played_seconds"}
WATCHED_KEYS = {"watched", "seen", "completed", "played"}
DATE_ADDED_KEYS = {"date_added", "added", "created", "indexed_at", "modified"}
LAST_PLAYED_KEYS = {"last_played", "played_at", "last_opened"}
RATING_KEYS = {"rating", "user_rating", "critic_rating", "score", "stars"}
DIRECTOR_KEYS = {"director", "directors"}
CAST_KEYS = {"cast", "actors", "actor", "performers"}
CREATOR_KEYS = {"creator", "creators", "writer", "writers", "author", "authors"}
METADATA_SOURCE_KEYS = {"metadata_source", "source_provider", "provider", "metadata_provider", "online_metadata_source", "online_metadata_provider", "enrichment_provider"}
METADATA_STATUS_KEYS = {"metadata_status", "online_metadata_status", "enrichment_status", "lookup_status"}
METADATA_ENRICHED_KEYS = {"metadata_enriched_at", "online_metadata_enriched_at", "enriched_at", "metadata_fetched_at", "lookup_at"}
METADATA_CACHE_KEYS = {"metadata_cached", "metadata_cache_path", "cache_path", "metadata_local_cache"}

DISCOVERY_ROOTS = [
    "~/.local/share/sentinel-media-index",
    "~/.local/share/sentinel/media-index",
    "~/.sentinel/media-index",
    "~/.config/sentinel-media-index",
    "~/Sentinel/MediaIndex",
    "~/SentinelOS/MediaIndex",
    "/var/lib/sentinel-media-index",
]
INDEX_PATTERNS = ("player_catalogue.json", "sentinel_media_player_catalogue.json", "*.sqlite3", "*.sqlite", "*.db", "*.json", "*.csv", "*.tsv")

# Catalogue filtering: Sentinel Media Index can contain helper media, thumbnails,
# test samples, partial downloads, and package/system assets.  The player
# catalogue should only present user media by default.  Explicit file-open still
# remains available for edge cases, but index/scan catalogue ingestion uses this
# filter.
INCOMPLETE_TOKENS = (
    ".crdownload", ".part", ".partial", ".opdownload", ".download",
    ".aria2", ".!qb", ".tmp", "unconfirmed", "incomplete", "partial~",
    "torrent downloaded",
)
SYSTEM_PATH_PREFIXES = (
    "/usr/", "/usr/local/", "/opt/", "/bin/", "/sbin/", "/lib/", "/lib64/",
    "/boot/", "/etc/", "/snap/", "/app/", "/var/cache/", "/var/tmp/",
    "/var/lib/flatpak/", "/var/lib/snapd/",
)
SYSTEM_COMPONENTS = {
    ".cache", ".thumbnails", "thumbnails", "thumbnailers", "cache", "caches",
    ".local/share/trash", "trash", "tmp", "temp", "temporary",
    "icons", "pixmaps", "themes", "applications", "metainfo", "mime",
    "doc", "docs", "man", "help", "locale", "system",
    "__pycache__", "build", "release", "tests", "test", "samples", "sample",
    "synthetic_media", "sentinel_media_player_build",
}
PACKAGE_COMPONENT_PREFIXES = (
    "sentinel_media_player_v", "sentinel-media-player_", "sentinel_media_index_v",
    "sentinelos_", "sentinelos-", "aegis_", "aegis-",
)


MARKER_ALIASES = {
    "intro_start": {
        "intro_start", "intro_start_seconds", "opening_start", "opening_start_seconds",
        "opening_theme_start", "opening_theme_start_seconds", "skip_intro_start", "intro_in",
    },
    "intro_end": {
        "intro_end", "intro_end_seconds", "opening_end", "opening_end_seconds",
        "opening_theme_end", "opening_theme_end_seconds", "skip_intro_end", "intro_out",
    },
    "credits_start": {
        "credits_start", "credits_start_seconds", "end_credits_start", "outro_start",
        "outro_start_seconds", "closing_start", "closing_start_seconds", "skip_credits_start",
    },
    "credits_end": {
        "credits_end", "credits_end_seconds", "end_credits_end", "outro_end",
        "outro_end_seconds", "closing_end", "closing_end_seconds", "skip_credits_end",
    },
}


@dataclass
class MediaItem:
    path: str
    title: str
    media_type: str
    source: str
    duration: str = ""
    album: str = ""
    artist: str = ""
    year: str = ""
    series: str = ""
    season: str = ""
    episode: str = ""
    imdb_id: str = ""
    tmdb_id: str = ""
    tvmaze_id: str = ""
    musicbrainz_id: str = ""
    wikidata_id: str = ""
    intro_start: str = ""
    intro_end: str = ""
    credits_start: str = ""
    credits_end: str = ""
    thumbnail_path: str = ""
    poster_path: str = ""
    fanart_path: str = ""
    cover_path: str = ""
    album_art_path: str = ""
    artwork_path: str = ""
    category: str = ""
    genre: str = ""
    collection: str = ""
    description: str = ""
    resolution: str = ""
    watched: str = ""
    progress: str = ""
    date_added: str = ""
    last_played: str = ""
    rating: str = ""
    director: str = ""
    cast: str = ""
    creator: str = ""
    metadata_source: str = ""
    metadata_provider: str = ""
    metadata_status: str = ""
    metadata_enriched_at: str = ""
    metadata_cached: str = ""

    def to_dict(self) -> Dict[str, str]:
        return asdict(self)

    def duration_seconds(self) -> Optional[float]:
        return parse_seconds(self.duration)

    def marker_seconds(self, name: str) -> Optional[float]:
        return parse_seconds(getattr(self, name, ""))

    def has_intro_marker(self) -> bool:
        return self.marker_seconds("intro_end") is not None

    def has_credits_marker(self) -> bool:
        return self.marker_seconds("credits_start") is not None or self.marker_seconds("credits_end") is not None


def normalize_key(key: str) -> str:
    return key.lower().strip().replace("-", "_").replace(" ", "_").replace(".", "_")


def first_value(row: Dict[str, Any], keys: Iterable[str]) -> str:
    for key in keys:
        if key in row and row[key] not in (None, ""):
            return str(row[key]).strip()
    return ""


def parse_seconds(raw: Any) -> Optional[float]:
    if raw is None:
        return None
    if isinstance(raw, (int, float)):
        value = float(raw)
        return value if value >= 0 else None
    text = str(raw).strip()
    if not text:
        return None
    # Handle HH:MM:SS(.mmm) and MM:SS(.mmm)
    if re.fullmatch(r"\d+(?::\d{1,2}){1,2}(?:\.\d+)?", text):
        parts = text.split(":")
        try:
            total = 0.0
            for part in parts:
                total = total * 60 + float(part)
            return total if total >= 0 else None
        except ValueError:
            return None
    cleaned = text.lower().replace("seconds", "").replace("second", "").replace("secs", "").replace("sec", "").replace("s", "").strip()
    try:
        value = float(cleaned)
        return value if value >= 0 else None
    except ValueError:
        return None


def format_seconds(seconds: Optional[float]) -> str:
    if seconds is None:
        return ""
    total = int(round(seconds))
    h, rem = divmod(total, 3600)
    m, s = divmod(rem, 60)
    if h:
        return f"{h}:{m:02d}:{s:02d}"
    return f"{m}:{s:02d}"


def marker_from_row(row: Dict[str, Any], canonical: str) -> str:
    for key in MARKER_ALIASES[canonical]:
        if key in row and row[key] not in (None, ""):
            return str(row[key]).strip()
    # Support nested or JSON-ish markers encoded as text/dict.
    markers = row.get("markers") or row.get("chapters") or row.get("skip_markers")
    if isinstance(markers, dict):
        lowered = {normalize_key(str(k)): v for k, v in markers.items()}
        for key in MARKER_ALIASES[canonical]:
            if key in lowered and lowered[key] not in (None, ""):
                return str(lowered[key]).strip()
    elif isinstance(markers, str):
        try:
            loaded = json.loads(markers)
            if isinstance(loaded, dict):
                return marker_from_row({"markers": loaded}, canonical)
        except Exception:
            pass
    return ""


def expand_candidate(path: str) -> Path:
    return Path(os.path.expandvars(os.path.expanduser(path)))


def candidate_index_paths() -> List[Path]:
    paths = [expand_candidate(p) for p in INDEX_CANDIDATES]
    for env_name in (
        "SENTINEL_MEDIA_INDEX",
        "SENTINEL_MEDIA_INDEX_DB",
        "SENTINEL_MEDIA_INDEX_FILE",
        "SENTINEL_MEDIA_INDEX_DIR",
        "SENTINEL_MEDIA_INDEX_HOME",
    ):
        env = os.environ.get(env_name)
        if env:
            for part in env.split(os.pathsep):
                if part.strip():
                    paths.insert(0, expand_candidate(part.strip()))
    return paths


def discovery_roots() -> List[Path]:
    roots = [expand_candidate(p) for p in DISCOVERY_ROOTS]
    for env_name in ("SENTINEL_MEDIA_INDEX_DIR", "SENTINEL_MEDIA_INDEX_HOME"):
        env = os.environ.get(env_name)
        if env:
            for part in env.split(os.pathsep):
                if part.strip():
                    roots.insert(0, expand_candidate(part.strip()))
    # If SENTINEL_MEDIA_INDEX points at a directory, search it recursively too.
    env = os.environ.get("SENTINEL_MEDIA_INDEX")
    if env:
        for part in env.split(os.pathsep):
            if part.strip():
                candidate = expand_candidate(part.strip())
                if candidate.is_dir():
                    roots.insert(0, candidate)
    out: List[Path] = []
    for root in roots:
        if root not in out:
            out.append(root)
    return out



def discover_fast_catalogue_files() -> List[Path]:
    """Return only exact fast player-catalogue paths without recursive scanning.

    v0.5.3 still called discover_index_files() before using the fast contract,
    which meant rglob() could walk the whole Media Index tree and raw exports.
    v0.5.4 checks exact player catalogue paths first and returns immediately.
    """
    out: List[Path] = []
    def add(candidate: Path) -> None:
        try:
            if candidate.is_file() and candidate.suffix.lower() == ".json" and candidate not in out:
                out.append(candidate)
        except Exception:
            pass
    for env_name in ("SENTINEL_MEDIA_PLAYER_CATALOGUE", "SENTINEL_MEDIA_INDEX_PLAYER_CATALOGUE"):
        env = os.environ.get(env_name)
        if env:
            for part in env.split(os.pathsep):
                if part.strip():
                    add(expand_candidate(part.strip()))
    for env_name in ("SENTINEL_MEDIA_INDEX", "SENTINEL_MEDIA_INDEX_DIR", "SENTINEL_MEDIA_INDEX_HOME"):
        env = os.environ.get(env_name)
        if env:
            for part in env.split(os.pathsep):
                if not part.strip():
                    continue
                candidate = expand_candidate(part.strip())
                if candidate.is_file():
                    add(candidate)
                elif candidate.is_dir():
                    for name in FAST_CATALOGUE_NAMES:
                        add(candidate / name)
                        add(candidate / "player_libraries" / name)
                        add(candidate / "exports" / name)
    for raw in FAST_CATALOGUE_DEFAULT_PATHS:
        add(expand_candidate(raw))
    return out


def discover_raw_index_files(max_files: int = RAW_DISCOVERY_MAX_FILES) -> List[Path]:
    """Bounded legacy/raw discovery used only when explicitly requested.

    This keeps old compatibility without making normal startup pay for SQLite
    table guessing, broad JSON parsing, or large recursive index walks.
    """
    discovered: List[Path] = []
    for path in candidate_index_paths():
        if len(discovered) >= max_files:
            break
        try:
            if path.is_file() and path not in discovered:
                discovered.append(path)
            elif path.is_dir():
                for pattern in INDEX_PATTERNS:
                    for p in path.glob(pattern):
                        if p.is_file() and p not in discovered:
                            discovered.append(p)
                            if len(discovered) >= max_files:
                                break
                    if len(discovered) >= max_files:
                        break
        except Exception:
            continue
    return discovered

def discover_index_files() -> List[Path]:
    discovered: List[Path] = []
    for path in candidate_index_paths():
        if path.is_file() and path not in discovered:
            discovered.append(path)
        elif path.is_dir():
            for pattern in INDEX_PATTERNS:
                for p in path.rglob(pattern):
                    if p.is_file() and p not in discovered:
                        discovered.append(p)
    for root in discovery_roots():
        if root.exists() and root.is_dir():
            for pattern in INDEX_PATTERNS:
                for p in root.rglob(pattern):
                    if p.is_file() and p not in discovered:
                        discovered.append(p)
    # Prefer database files before flat exports, and prefer explicit media-index names.
    def score(path: Path) -> tuple[int, str]:
        name = path.name.lower()
        if name in FAST_CATALOGUE_NAMES:
            return (-100, str(path).lower())
        suffix_score = 0 if path.suffix.lower() in {".sqlite3", ".sqlite", ".db"} else 1
        explicit = 0 if any(token in name for token in ("media", "index", "library", "catalog")) else 1
        return (suffix_score + explicit, str(path).lower())
    return sorted(discovered, key=score)


def safe_local_path(raw: Any, base: Optional[Path] = None) -> Optional[str]:
    if raw is None:
        return None
    text = str(raw).strip().strip("\'\"")
    if not text:
        return None
    lowered = text.lower()
    if lowered.startswith(("http://", "https://", "ftp://", "smb://")):
        return None
    if lowered.startswith("file:"):
        parsed = urlparse(text)
        if parsed.scheme == "file":
            # File managers may pass file:///home/user/movie.mkv or file://localhost/home/user/movie.mkv.
            if parsed.netloc not in ("", "localhost"):
                return None
            text = unquote(parsed.path)
    path = expand_candidate(unquote(text))
    if not path.is_absolute() and base is not None:
        path = base / path
    return str(path)


def normalise_media_argument(raw: Any) -> Optional[str]:
    """Convert a desktop-file argument or CLI argument into a local path."""
    return safe_local_path(raw)



def _path_candidates_from_row(row: Dict[str, Any]) -> List[Any]:
    candidates: List[Any] = []
    lowered = {normalize_key(str(k)): v for k, v in row.items()}
    for key in PATH_KEYS:
        if key in lowered and lowered[key] not in (None, ""):
            candidates.append(lowered[key])
    # Some indexes store path-like values inside JSON metadata columns.
    for value in row.values():
        if isinstance(value, str):
            text = value.strip()
            if not text:
                continue
            if is_catalogue_path(text) or text.lower().startswith("file:"):
                candidates.append(text)
                continue
            if (text.startswith("{") and text.endswith("}")) or (text.startswith("[") and text.endswith("]")):
                try:
                    loaded = json.loads(text)
                except Exception:
                    continue
                if isinstance(loaded, dict):
                    candidates.extend(_path_candidates_from_row(loaded))
                elif isinstance(loaded, list):
                    for item in loaded:
                        if isinstance(item, dict):
                            candidates.extend(_path_candidates_from_row(item))
                        elif isinstance(item, str) and is_catalogue_path(item):
                            candidates.append(item)
    return candidates

def make_item(path_text: str, source: str, row: Optional[Dict[str, Any]] = None, base: Optional[Path] = None) -> Optional[MediaItem]:
    row = row or {}
    lowered = {normalize_key(str(k)): v for k, v in row.items()}
    media_type = classify_media_path(path_text)
    raw_type = str(first_value(lowered, TYPE_KEYS) or "").lower()
    if media_type == "unknown" and any(token in raw_type for token in ("ebook", "e-book", "book", "pdf", "epub", "comic")):
        media_type = "ebook"
    if media_type not in {"audio", "video", "ebook"}:
        return None
    title = first_value(lowered, TITLE_KEYS) or Path(path_text).stem
    duration = first_value(lowered, DURATION_KEYS)
    musicbrainz_id = first_value(lowered, {"musicbrainz_recording_id", "musicbrainz_id", "mbid"})
    return MediaItem(
        path=path_text,
        title=title,
        media_type=media_type,
        source=source,
        duration=duration,
        album=first_value(lowered, ALBUM_KEYS),
        artist=first_value(lowered, ARTIST_KEYS),
        year=first_value(lowered, YEAR_KEYS),
        series=first_value(lowered, SERIES_KEYS),
        season=first_value(lowered, SEASON_KEYS),
        episode=first_value(lowered, EPISODE_KEYS),
        imdb_id=first_value(lowered, {"imdb", "imdb_id"}),
        tmdb_id=first_value(lowered, {"tmdb", "tmdb_id"}),
        tvmaze_id=first_value(lowered, {"tvmaze", "tvmaze_id"}),
        musicbrainz_id=musicbrainz_id,
        wikidata_id=first_value(lowered, {"wikidata", "wikidata_id", "qid"}),
        intro_start=marker_from_row(lowered, "intro_start"),
        intro_end=marker_from_row(lowered, "intro_end"),
        credits_start=marker_from_row(lowered, "credits_start"),
        credits_end=marker_from_row(lowered, "credits_end"),
        thumbnail_path=safe_local_path(first_value(lowered, {"thumbnail", "thumbnail_path", "thumb", "thumb_path", "album_art", "albumart", "album_art_path", "cover_art", "cover_art_path"}), base) or "",
        poster_path=safe_local_path(first_value(lowered, {"poster", "poster_path", "cover", "cover_path", "art", "art_path", "artwork", "artwork_path", "front", "front_cover"}), base) or "",
        fanart_path=safe_local_path(first_value(lowered, {"fanart", "fanart_path", "backdrop", "backdrop_path"}), base) or "",
        cover_path=safe_local_path(first_value(lowered, {"cover", "cover_path", "cover_art", "cover_art_path"}), base) or "",
        album_art_path=safe_local_path(first_value(lowered, {"album_art", "albumart", "album_art_path"}), base) or "",
        artwork_path=safe_local_path(first_value(lowered, {"artwork", "artwork_path", "primary_image", "image"}), base) or "",
        category=first_value(lowered, {"category", "library_category", "library_section"}),
        genre=first_value(lowered, GENRE_KEYS),
        collection=first_value(lowered, COLLECTION_KEYS),
        description=first_value(lowered, DESCRIPTION_KEYS),
        resolution=first_value(lowered, QUALITY_KEYS),
        watched=first_value(lowered, WATCHED_KEYS),
        progress=first_value(lowered, PROGRESS_KEYS),
        date_added=first_value(lowered, DATE_ADDED_KEYS),
        last_played=first_value(lowered, LAST_PLAYED_KEYS),
        rating=first_value(lowered, RATING_KEYS),
        director=first_value(lowered, DIRECTOR_KEYS),
        cast=first_value(lowered, CAST_KEYS),
        creator=first_value(lowered, CREATOR_KEYS),
        metadata_source=first_value(lowered, METADATA_SOURCE_KEYS),
        metadata_provider=first_value(lowered, {"metadata_provider", "online_metadata_provider", "provider", "source_provider", "enrichment_provider"}),
        metadata_status=first_value(lowered, METADATA_STATUS_KEYS),
        metadata_enriched_at=first_value(lowered, METADATA_ENRICHED_KEYS),
        metadata_cached=first_value(lowered, METADATA_CACHE_KEYS),
    )


def _normalised_parts_for_filter(path_text: str) -> tuple[str, list[str]]:
    path = safe_local_path(path_text) or str(path_text)
    absolute = os.path.abspath(os.path.expanduser(path)).lower()
    parts = [p.lower() for p in Path(absolute).parts if p and p != os.sep]
    return absolute, parts


def is_incomplete_media_path(path_text: str) -> bool:
    absolute, parts = _normalised_parts_for_filter(path_text)
    name = Path(absolute).name.lower()
    if any(token in absolute for token in INCOMPLETE_TOKENS):
        return True
    if name.endswith((".part", ".partial", ".crdownload", ".opdownload", ".download", ".aria2", ".tmp")):
        return True
    return False


def is_system_media_path(path_text: str) -> bool:
    absolute, parts = _normalised_parts_for_filter(path_text)
    if absolute.startswith(SYSTEM_PATH_PREFIXES):
        return True
    joined = "/".join(parts)
    if ".local/share/trash" in joined or "/trash/" in f"/{joined}/":
        return True
    if any(part in SYSTEM_COMPONENTS for part in parts):
        return True
    if any(part.startswith(PACKAGE_COMPONENT_PREFIXES) for part in parts):
        return True
    # Exclude common app/theme asset folders without blocking a normal user Movies folder.
    if "/share/" in f"/{joined}/" and any(part in {"icons", "pixmaps", "themes", "applications", "metainfo", "mime"} for part in parts):
        return True
    return False


def catalogue_filter_reason(path_text: str) -> str:
    if not is_catalogue_path(path_text):
        return "not_catalogue_media"
    if is_incomplete_media_path(path_text):
        return "incomplete_or_partial_download"
    if is_system_media_path(path_text):
        return "system_cache_app_asset_or_build_sample"
    return "allowed"


def is_catalogue_media_path(path_text: str) -> bool:
    return catalogue_filter_reason(path_text) == "allowed"


def filter_catalogue_items(items: Iterable[MediaItem]) -> tuple[List[MediaItem], Dict[str, int]]:
    kept: List[MediaItem] = []
    rejected: Dict[str, int] = {}
    for item in items:
        reason = catalogue_filter_reason(item.path)
        if reason == "allowed":
            kept.append(item)
        else:
            rejected[reason] = rejected.get(reason, 0) + 1
            audit("catalogue_filter", f"{reason}: {item.path}", "info")
    return kept, rejected


def catalogue_filter_profile() -> Dict[str, Any]:
    return {
        "enabled": True,
        "purpose": "Keep the Media Player catalogue focused on user media, not system/app/cache/build/incomplete download files.",
        "excluded": [
            "partial/incomplete downloads",
            "browser/download-manager temporary files",
            "system folders such as /usr, /opt, /bin, /lib, /etc, /var/cache",
            "desktop/theme/icon/app asset folders",
            "Trash/cache/thumbnail folders",
            "Sentinel package/build/test/sample media",
        ],
        "manual_open_policy": "Manual Open Files can still target explicit user media. Media Index and folder-scan catalogue ingestion are filtered; eBooks can appear in the catalogue and open externally when selected.",
        "metadata_policy": "Filtering applies before display; metadata enrichment/provenance from Sentinel Media Index is preserved on kept items.",
    }


def dedupe(items: Iterable[MediaItem]) -> List[MediaItem]:
    seen = set()
    out: List[MediaItem] = []
    for item in items:
        key = os.path.abspath(os.path.expanduser(item.path))
        if key in seen:
            continue
        seen.add(key)
        out.append(item)
    out.sort(key=lambda i: (i.media_type, i.title.lower(), i.path.lower()))
    return out


def quote_ident(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


def read_sqlite_index(path: Path) -> List[MediaItem]:
    items: List[MediaItem] = []
    try:
        conn = sqlite3.connect(str(path))
        conn.row_factory = sqlite3.Row
        tables = conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
        for t in tables:
            table = str(t[0])
            if table.startswith("sqlite_"):
                continue
            try:
                columns = [r[1] for r in conn.execute(f"PRAGMA table_info({quote_ident(table)})").fetchall()]
                normalized = {normalize_key(c): c for c in columns}
                path_cols = [normalized[k] for k in PATH_KEYS if k in normalized]
                # Even without a recognised path column, scan row values and JSON metadata for media paths.
                select_cols = ", ".join(quote_ident(c) for c in columns)
                query = f"SELECT {select_cols} FROM {quote_ident(table)} LIMIT 200000"
                for row in conn.execute(query):
                    row_dict = {c: row[c] for c in columns}
                    lowered = {normalize_key(k): v for k, v in row_dict.items()}
                    merged = {**lowered, **row_dict}
                    candidate_values = []
                    for c in path_cols:
                        raw_path = row_dict.get(c)
                        if raw_path:
                            candidate_values.append(raw_path)
                    if not candidate_values:
                        candidate_values = _path_candidates_from_row(merged)
                    for raw_path in candidate_values[:5]:
                        local = safe_local_path(raw_path, base=path.parent)
                        if not local:
                            continue
                        item = make_item(local, f"sqlite:{path}::{table}", merged, base=path.parent)
                        if item:
                            items.append(item)
                            break
            except Exception as exc:
                audit("read_sqlite_table", f"{path}:{table}:{exc}", "warning")
        conn.close()
    except Exception as exc:
        audit("read_sqlite_index", f"{path}:{exc}", "error")
    return dedupe(items)


def extract_from_json_obj(obj: Any, source: str, base: Path) -> List[MediaItem]:
    items: List[MediaItem] = []
    if isinstance(obj, list):
        for part in obj:
            items.extend(extract_from_json_obj(part, source, base))
    elif isinstance(obj, dict):
        lowered = {normalize_key(str(k)): v for k, v in obj.items()}
        for raw_path in _path_candidates_from_row(lowered):
            local = safe_local_path(raw_path, base=base)
            if local:
                item = make_item(local, source, lowered, base=base)
                if item:
                    items.append(item)
                    break
        for _key, val in obj.items():
            if isinstance(val, (list, dict)):
                items.extend(extract_from_json_obj(val, source, base))
    elif isinstance(obj, str):
        local = safe_local_path(obj, base=base)
        if local and is_catalogue_path(local):
            item = make_item(local, source, {}, base=base)
            if item:
                items.append(item)
    return items




def is_fast_catalogue_json(path: Path, obj: Any) -> bool:
    if path.name.lower() in FAST_CATALOGUE_NAMES:
        return True
    if isinstance(obj, dict):
        contract = str(obj.get("handoff_type") or obj.get("contract_version") or obj.get("handoff_contract_version") or "")
        if contract in FAST_CATALOGUE_CONTRACTS:
            return True
        if obj.get("player_contract", {}).get("reader") == "fast_flat_json":
            return True
    return False


def read_fast_catalogue_json(path: Path, obj: Any) -> List[MediaItem]:
    items: List[MediaItem] = []
    if not isinstance(obj, dict):
        return items
    raw_items = obj.get("items") or []
    if not isinstance(raw_items, list):
        return items
    for raw in raw_items:
        if not isinstance(raw, dict):
            continue
        lowered = {normalize_key(str(k)): v for k, v in raw.items()}
        raw_path = first_value(lowered, PATH_KEYS)
        local = safe_local_path(raw_path, base=path.parent)
        if not local:
            continue
        # A fast catalogue has already been filtered by Media Index; still keep the local safety check.
        item = make_item(local, f"fast_catalogue:{path}", lowered, base=path.parent)
        if item:
            # Prefer flat fast-contract artwork fields exactly.
            item.thumbnail_path = safe_local_path(lowered.get("thumbnail_path"), path.parent) or item.thumbnail_path
            item.poster_path = safe_local_path(lowered.get("poster_path"), path.parent) or item.poster_path
            item.cover_path = safe_local_path(lowered.get("cover_path"), path.parent) or item.cover_path
            item.album_art_path = safe_local_path(lowered.get("album_art_path"), path.parent) or item.album_art_path
            item.artwork_path = safe_local_path(lowered.get("artwork_path") or lowered.get("primary_image") or lowered.get("image"), path.parent) or item.artwork_path
            item.category = str(lowered.get("category") or lowered.get("library_section") or item.category or "")
            item.metadata_source = str(lowered.get("metadata_source") or "Sentinel Media Index")
            item.metadata_provider = str(lowered.get("metadata_provider") or item.metadata_provider or "")
            item.metadata_status = str(lowered.get("metadata_status") or item.metadata_status or "")
            items.append(item)
    return dedupe(items)

def read_json_index(path: Path) -> List[MediaItem]:
    try:
        with path.open("r", encoding="utf-8") as fh:
            obj = json.load(fh)
        if is_fast_catalogue_json(path, obj):
            return read_fast_catalogue_json(path, obj)
        return dedupe(extract_from_json_obj(obj, f"json:{path}", path.parent))
    except Exception as exc:
        audit("read_json_index", f"{path}:{exc}", "error")
        return []


def read_csv_index(path: Path) -> List[MediaItem]:
    items: List[MediaItem] = []
    delimiter = "\t" if path.suffix.lower() == ".tsv" else ","
    try:
        with path.open("r", encoding="utf-8", newline="") as fh:
            reader = csv.DictReader(fh, delimiter=delimiter)
            for row in reader:
                lowered = {normalize_key(str(k)): v for k, v in row.items()}
                for raw_path in _path_candidates_from_row(lowered):
                    local = safe_local_path(raw_path, base=path.parent)
                    if not local:
                        continue
                    item = make_item(local, f"csv:{path}", lowered, base=path.parent)
                    if item:
                        items.append(item)
                        break
    except Exception as exc:
        audit("read_csv_index", f"{path}:{exc}", "error")
    return dedupe(items)


def read_index_file(path: Path) -> List[MediaItem]:
    suffix = path.suffix.lower()
    if suffix in {".sqlite3", ".sqlite", ".db"}:
        return read_sqlite_index(path)
    if suffix == ".json":
        return read_json_index(path)
    if suffix in {".csv", ".tsv"}:
        return read_csv_index(path)
    return []


def load_media_index(fast_only: bool = FAST_CONTRACT_ONLY_DEFAULT) -> Tuple[List[MediaItem], List[Path]]:
    """Load the Media Index catalogue using the fast contract first.

    Normal GUI startup is fast-contract-only by default.  It no longer does
    recursive index discovery or raw SQLite/JSON/CSV guessing unless explicitly
    requested by a caller.  This is the main v0.5.4 speed fix.
    """
    fast_files = discover_fast_catalogue_files()
    if fast_files:
        fast_items: List[MediaItem] = []
        used_fast: List[Path] = []
        for path in fast_files:
            part = read_json_index(path)
            if part:
                fast_items.extend(part)
                used_fast.append(path)
        kept, rejected = filter_catalogue_items(dedupe(fast_items))
        result = dedupe(kept)
        audit("load_media_index_fast_contract", f"files={len(used_fast)} items={len(result)} filtered={sum(rejected.values())}", "ok")
        return result, used_fast or fast_files
    if fast_only:
        audit("load_media_index_fast_contract_missing", "no player_catalogue.json found; raw fallback skipped for startup speed", "warning")
        return [], []
    files = discover_raw_index_files()
    items: List[MediaItem] = []
    for path in files:
        items.extend(read_index_file(path))
    kept, rejected = filter_catalogue_items(dedupe(items))
    result = dedupe(kept)
    audit("load_media_index_raw_fallback", f"files={len(files)} items={len(result)} filtered={sum(rejected.values())}", "ok")
    return result, files



def find_item_for_path(path_text: str) -> Optional[MediaItem]:
    normalized = normalise_media_argument(path_text) or path_text
    target = os.path.abspath(os.path.expanduser(normalized))
    items, _files = load_media_index()
    for item in items:
        if os.path.abspath(os.path.expanduser(item.path)) == target:
            return item
    p = Path(os.path.expanduser(normalized))
    if p.is_file() and is_catalogue_path(str(p)):
        return make_item(str(p), "file", {})
    return None


def media_index_status() -> Dict[str, Any]:
    fast_files = discover_fast_catalogue_files()
    items: List[MediaItem] = []
    used: List[Path] = []
    for p in fast_files:
        part = read_json_index(p)
        if part:
            items.extend(part)
            used.append(p)
    raw_unique = dedupe(items)
    unique, rejected = filter_catalogue_items(raw_unique)
    intro_marked = sum(1 for i in unique if i.has_intro_marker())
    credits_marked = sum(1 for i in unique if i.has_credits_marker())
    return {
        "startup_mode": "fast_contract_only",
        "slow_raw_discovery_default": False,
        "discovered_fast_catalogue_files": [str(p) for p in fast_files],
        "used_fast_catalogue_files": [str(p) for p in used],
        "discovery_roots": [str(p) for p in discovery_roots()],
        "auto_load_default": True,
        "file_count": len(used),
        "raw_playable_items_before_filter": len(raw_unique),
        "playable_items": len(unique),
        "filtered_items": sum(rejected.values()),
        "filter_reasons": rejected,
        "catalogue_filter": catalogue_filter_profile(),
        "audio_items": sum(1 for i in unique if i.media_type == "audio"),
        "video_items": sum(1 for i in unique if i.media_type == "video"),
        "ebook_items": sum(1 for i in unique if i.media_type == "ebook"),
        "intro_marker_items": intro_marked,
        "credits_marker_items": credits_marked,
        "supported_skip_marker_fields": {k: sorted(v) for k, v in MARKER_ALIASES.items()},
        "metadata_authority": "Sentinel Media Index",
        "metadata_enriched_items": sum(1 for i in unique if i.metadata_source or i.metadata_provider or i.metadata_enriched_at or i.metadata_status),
        "metadata_provenance_fields": ["metadata_source", "metadata_provider", "metadata_status", "metadata_enriched_at", "metadata_cached"],
        "errors_are_nonfatal": True,
        "fast_catalogue_contract_supported": True,
        "fast_catalogue_names": sorted(FAST_CATALOGUE_NAMES),
        "reader_priority": "exact fast player_catalogue.json only during startup; raw SQLite/JSON/CSV fallback is disabled by default for speed",
        "if_empty": "Run: sentinel-media-index --scan-defaults --json",
    }



def scan_folder(folder: str) -> List[MediaItem]:
    root = expand_candidate(folder)
    if not root.exists() or not root.is_dir():
        return []
    items: List[MediaItem] = []
    for path in root.rglob("*"):
        if path.is_file() and is_catalogue_path(str(path)) and is_catalogue_media_path(str(path)):
            item = make_item(str(path), f"folder:{root}", {})
            if item:
                items.append(item)
    result = dedupe(items)
    audit("scan_folder", f"{root} items={len(result)}", "ok")
    return result
