from __future__ import annotations

import argparse
import json
import sys
import os
import hashlib
import shutil
import subprocess
from pathlib import Path
from typing import Any

from . import APP_NAME, PACKAGE_NAME, VERSION
from .aegis import DEFAULT_CONFIG, aegis_actions, aegis_status, audit, load_config, save_config
from .bridge import MARKER_ALIASES, MediaItem, catalogue_filter_profile, load_media_index, media_index_status, normalise_media_argument, parse_seconds, scan_folder
library_filter_profile = catalogue_filter_profile
from .formats import AUDIO_EXTENSIONS, EBOOK_EXTENSIONS, SUPPORTED_FORMAT_NOTE, VIDEO_EXTENSIONS, classify_media_path, is_media_path
from .nerd_stats import nerd_stats
from .online_art import online_art_profile


def print_json(obj: Any) -> None:
    print(json.dumps(obj, indent=2, sort_keys=True))


def _path_has_symlink_component(path: Path) -> bool:
    p = Path(path).expanduser()
    try:
        if p.is_symlink():
            return True
    except Exception:
        return True
    cur = Path(p.anchor) if p.is_absolute() else Path.cwd()
    parts = p.parts[1:] if p.is_absolute() else p.parts
    for part in parts:
        cur = cur / part
        try:
            if cur.exists() and cur.is_symlink():
                return True
        except Exception:
            return True
    return False


def _safe_write_text(path: Path, text: str, *, role: str = "output") -> Path:
    out = Path(path).expanduser()
    if out.exists() and out.is_symlink():
        raise RuntimeError(f"unsafe_{role}_symlink_target:{out}")
    if _path_has_symlink_component(out.parent):
        raise RuntimeError(f"unsafe_{role}_symlink_parent:{out.parent}")
    if out.exists() and out.is_symlink():
        raise RuntimeError(f"unsafe_report_symlink_target:{out}")
    if _path_has_symlink_component(out.parent):
        raise RuntimeError(f"unsafe_report_symlink_parent:{out.parent}")
    tmp = out.with_name(out.name + f".tmp-{os.getpid()}")
    if tmp.exists() or tmp.is_symlink():
        tmp.unlink(missing_ok=True)
    fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(text)
        os.replace(tmp, out)
    finally:
        try:
            if tmp.exists() or tmp.is_symlink():
                tmp.unlink()
        except Exception:
            pass
    return out


def skip_profile() -> dict[str, Any]:
    config = load_config()
    return {
        "app": APP_NAME,
        "version": VERSION,
        "auto_skip_intro_default": bool(config.get("auto_skip_intro", True)),
        "auto_skip_intro_requires_marker": bool(config.get("auto_skip_intro_requires_marker", True)),
        "manual_intro_skip_seconds": config.get("manual_intro_skip_seconds", 85),
        "manual_credits_skip_action": config.get("manual_credits_skip_action", "next_or_end"),
        "supported_marker_aliases": {k: sorted(v) for k, v in MARKER_ALIASES.items()},
        "policy": "Auto Skip Intro is on by default, but only fires when a Media Index intro marker exists. Manual buttons remain available.",
    }


def desktop_controls_profile() -> dict[str, Any]:
    config = load_config()
    step = int(config.get("seek_step_seconds", 10) or 10)
    return {
        "app": APP_NAME,
        "version": VERSION,
        "theme": "AEGIS Dark / Sentinel Gold desktop suite fit",
        "hotkeys": {
            "Ctrl+Q": "close app",
            "Ctrl+F": "focus Library search",
            "Space": "play/pause",
            "Left": f"skip back {step} seconds",
            "Right": f"fast forward {step} seconds",
            "Up": "volume up 5%",
            "Down": "volume down 5%",
            "F11": "toggle video-only fullscreen",
            "Escape": "exit video-only fullscreen",
        },
        "fn_media_keys": {
            "XF86AudioPlay/XF86AudioPause": "play/pause",
            "XF86AudioStop": "stop",
            "XF86AudioPrev": "previous item",
            "XF86AudioNext": "next item",
            "XF86AudioRewind": f"skip back {step} seconds",
            "XF86AudioForward": f"fast forward {step} seconds",
        },
        "video_surface": {
            "double_tap": "toggle video-only fullscreen / restore normal view",
            "ten_second_seek": f"use buttons, keyboard arrows, or Fn rewind/forward for ±{step} seconds",
            "old_edge_double_tap_seek": "disabled by default to avoid conflict with fullscreen double-tap",
            "gesture_surface": "input-only / non-painting; does not overlay or obscure the GStreamer video widget",
            "overlay_hotfix": True,
        },
        "fullscreen": {
            "mode": "video_only",
            "behavior": "F11/Fullscreen/double-tap opens a dedicated borderless fullscreen video surface; double-tap/Escape/F11 restores normal video view; the main media-player window is not fullscreened",
            "style_reference": "VLC-style video fullscreen",
        },
        "timeline": "slider displays played, left, and total duration",
        "seek_hotfix": {"enabled": True, "engine": "accurate_clamped", "all_entry_points": ["GUI buttons", "keyboard arrows", "Fn rewind/forward"]},
        "subtitles": {"S": "toggle subtitles", "sidecar_auto_detect": bool(load_config().get("detect_sidecar_subtitles", True)), "remove_policy": "hide only; never delete subtitle files"},
        "resume": {"continue_last": True, "remember_playback_position": bool(load_config().get("resume_playback_enabled", True)), "storage": "local user config only"},
        "note": "Media/Fn keys are handled when the desktop environment routes them to the focused player window. Global desktop interception may require a future MPRIS integration patch.",
    }


def library_profile() -> dict[str, Any]:
    return {
        "app": APP_NAME,
        "version": VERSION,
        "default_library_source": "bounded local file-grid folders",
        "landing_page": "simple player first; Library file grid is optional/on-demand",
        "auto_load_on_startup": False,
        "startup_render_policy": "no Library startup load; Library grid scans approved user folders only when opened",
        "simple_player_startup": bool(load_config().get("simple_player_startup", True)),
        "library_render_on_demand": bool(load_config().get("library_render_on_demand", True)),
        "library_background_load": False,
        "library_lazy_render": False,
        "library_tile_batch_size": max(4, min(int(load_config().get("library_tile_batch_size", 8) or 8), 16)),
        "library_startup_display_limit": max(12, min(int(load_config().get("library_startup_display_limit", 24) or 24), 24)),
        "library_quick_search": bool(load_config().get("library_quick_search_enabled", True)),
        "library_search_shortcut": "Ctrl+F",
        "paged_board_rendering": True,
        "deferred_full_library_render": bool(load_config().get("library_deferred_full_render", True)),
        "load_more_button": True,
        "drag_drop_enabled": bool(load_config().get("drag_drop_enabled", True)),
        "continue_last": True,
        "resume_playback_enabled": bool(load_config().get("resume_playback_enabled", True)),
        "library_fast_contract_only": False,
        "slow_raw_discovery_default": False,
        "library_scan_guard": "File-grid scanning runs in a guarded background worker and only over approved user folders.",
        "manual_refresh_library_button": "rescan approved user folders only",
        "retrieve_media_index_button": "removed from the primary workflow; Player Library is a local file-grid viewer",
        "discovery_mode": "no library discovery during startup",
        "performance_mode": "simple_file_grid_only",
        "raw_file_list_is_secondary": True,
        "side_file_bar": "removed",
        "visible_tabs": False,
        "header_quick_buttons": [],
        "workspace_quick_buttons": [],
        "header_quick_buttons_removed": True,
        "library_play_switches_to_now_playing": True,
        "navigation": "Now Playing opens first; Library file grid is optional from sidebar/top menu",
        "queue_location": "Queue workspace via top menu (explicit play queue only)",
        "top_menu_bar": True,
        "real_queue_model": True,
        "theme_parity": "Sentinel Jobs command dashboard style",
        "approved_library_roots": ["~/Videos/Movies", "~/Videos/TV Shows", "~/Music", "~/Documents/eBooks"],
        "audio_playback_tile_fix": True,
        "library_tile_playback_hotfix": True,
        "artwork_sources": "disabled for file-grid first paint; simple system icons are used",
        "metadata_authority": "Media Index remains installed but is not used for Player Library startup",
        "categories": [
            "Movies",
            "TV Shows / Episodes",
            "Music",
            "eBooks",
        ],
        "tile_fields": ["system icon", "title", "media type", "path"],
        "fallback_art": "system file-type icons only in the simple grid",
        "open_files_and_open_folder": "manual fallback that also appends chosen files to the explicit play queue",
    }



def library_search_profile() -> dict[str, Any]:
    config = load_config()
    return {
        "app": APP_NAME,
        "version": VERSION,
        "library_quick_search": bool(config.get("library_quick_search_enabled", True)),
        "entry_points": ["Library search box", "Library menu: Focus Search", "Library menu: Clear Search", "keyboard: Ctrl+F", "keyboard: Escape clears active search"],
        "search_fields": ["title", "series", "artist", "album", "year", "genre", "collection", "description", "director", "cast", "creator", "media type", "path", "metadata provider/source"],
        "matching": "all typed words must appear somewhere in the item's searchable Library file list",
        "startup_policy": "search filters the already-loaded fast Library file grid; it never triggers raw discovery, recursive scanning, or Media Index mutation",
        "render_policy": "matched results use the same paged first-paint renderer as the normal Library board",
        "v1_value": "large librarys remain tolerable because the user can jump to a title/series/artist without rendering every tile first",
    }


def metadata_authority_profile() -> dict[str, Any]:
    config = load_config()
    return {
        "app": APP_NAME,
        "version": VERSION,
        "metadata_authority": "Sentinel Media Index",
        "online_metadata_default_owner": "Sentinel Media Index",
        "player_online_lookup_policy": "fallback/manual only",
        "player_background_fetch": False,
        "media_index_auto_load_on_startup": bool(config.get("media_index_auto_load_on_startup", True)),
        "nerd_stats_prefer_media_index": bool(config.get("nerd_stats_prefer_media_index_metadata", True)),
        "player_fallback_online_enabled_by_default": bool(config.get("nerd_stats_online_lookup", False)),
        "supported_index_provenance_fields": [
            "metadata_source", "metadata_provider", "online_metadata_source", "online_metadata_provider",
            "metadata_status", "online_metadata_status", "metadata_enriched_at", "metadata_cached",
            "imdb_id", "tmdb_id", "tvmaze_id", "musicbrainz_id", "wikidata_id"
        ],
        "nerd_stats_default": "Read Media Index enriched/cached metadata first; use Player-side online lookup only when the user explicitly requests fallback lookup.",
        "refresh_guidance": "Run Sentinel Media Index enrichment/scan to update Library file list, then reload the Media Player library.",
    }


def performance_profile() -> dict[str, Any]:
    config = load_config()
    return {
        "app": APP_NAME,
        "version": VERSION,
        "hotfix": "retrieve_media_index_fast_paged_board_v0_5_6",
        "startup_reader": "exact player_library.json / sentinel_media_player_library.json only",
        "startup_ui": "simple player first; file grid render deferred until Library is opened",
        "raw_sqlite_json_csv_discovery_default": False,
        "recursive_index_scan_default": False,
        "library_fast_contract_only": bool(config.get("library_fast_contract_only", True)),
        "library_tile_batch_size": max(4, min(int(config.get("library_tile_batch_size", 8) or 8), 16)),
        "library_startup_display_limit": max(12, min(int(config.get("library_startup_display_limit", 24) or 24), 24)),
        "paged_board_rendering": True,
        "deferred_full_library_render": bool(config.get("library_deferred_full_render", True)),
        "load_more_button": True,
        "library_quick_search": bool(config.get("library_quick_search_enabled", True)),
        "library_search_speed_policy": "filters already-loaded simple file grid records and renders only the matched first page; it does not rescan or mutate Media Index",
        "drag_drop_enabled": bool(config.get("drag_drop_enabled", True)),
        "continue_last": True,
        "resume_playback_enabled": bool(config.get("resume_playback_enabled", True)),
        "artwork_heavy_generation_default": False,
        "artwork_recursive_scan_default": False,
        "online_art_at_startup": False,
        "bulk_online_art": "manual background action only; not part of Library startup",
        "required_speed_contract": "Run sentinel-media-index --scan-defaults --json so the index scans only ~/Documents/eBooks, ~/Videos/Movies, ~/Videos/TV Shows, ~/Pictures and writes the flat simple file grid.",
    }


def retrieve_media_index_profile() -> dict[str, Any]:
    return {
        "app": APP_NAME,
        "version": VERSION,
        "retrieve_media_index_button": False,
        "entry_points": [],
        "command": None,
        "mode": "removed from primary Player workflow",
        "raw_index_mirroring": False,
        "player_reads": [],
        "speed_policy": "Media Player does not load Sentinel Media Index at startup. The Library grid scans only approved user folders on demand.",
    }

def fast_board_profile() -> dict[str, Any]:
    config = load_config()
    return {
        "app": APP_NAME,
        "version": VERSION,
        "fast_paged_board": True,
        "hero_header_removed": True,
        "workspace_quick_buttons_removed": True,
        "now_playing_hotkey_hint_removed": True,
        "player_control_row_library_button": True,
        "initial_visible_tiles": max(12, min(int(config.get("library_startup_display_limit", 24) or 24), 24)),
        "tile_batch_size": max(4, min(int(config.get("library_tile_batch_size", 8) or 8), 16)),
        "load_more_step": max(12, min(int(config.get("library_page_step", 48) or 48), 96)),
        "reason": "Render a small useful board first; do not create hundreds of GTK tiles during startup. v0.5.19 also fixes the previous full-library expansion path by keeping replacement renders paged.",
    }

def poster_database_profile() -> dict[str, Any]:
    config = load_config()
    roots = []
    for raw in config.get("local_poster_databases", []) or []:
        p = Path(os.path.expanduser(str(raw)))
        roots.append({"path": str(p), "exists": p.is_dir()})
    return {
        "app": APP_NAME,
        "version": VERSION,
        "local_poster_database": True,
        "configured_roots": roots,
        "priority": "after Media Index artwork fields, before sidecar/Caja thumbnails and before online retrieval",
        "accepted_extensions": [".jpg", ".jpeg", ".png", ".webp"],
        "matching_examples": [
            "PosterDB/Movie Title (Year).jpg",
            "PosterDB/Movie Title (Year)/poster.jpg",
            "PosterDB/Movies/Movie Title-poster.jpg",
            "PosterDB/tmdb_id/poster.jpg",
        ],
        "gui": "Settings or left sidebar: Add Local Poster Database",
    }


def add_poster_database(path: str) -> dict[str, Any]:
    config = load_config()
    roots = [str(Path(os.path.expanduser(str(p))).resolve()) for p in (config.get("local_poster_databases", []) or []) if Path(os.path.expanduser(str(p))).is_dir()]
    p = Path(os.path.expanduser(path)).resolve()
    if not p.is_dir():
        return {"ok": False, "error": "not_a_directory", "path": str(p)}
    if str(p) not in roots:
        roots.append(str(p))
    config["local_poster_databases"] = roots
    save_config(config)
    return {"ok": True, "configured_roots": roots}


def remove_poster_database(path: str) -> dict[str, Any]:
    config = load_config()
    target = str(Path(os.path.expanduser(path)).resolve())
    roots = [str(Path(os.path.expanduser(str(p))).resolve()) for p in (config.get("local_poster_databases", []) or [])]
    roots = [p for p in roots if p != target]
    config["local_poster_databases"] = roots
    save_config(config)
    return {"ok": True, "configured_roots": roots}


def artwork_profile() -> dict[str, Any]:
    return {
        "app": APP_NAME,
        "version": VERSION,
        "enabled": True,
        "hotfix": "bulk_manual_online_art_v7_index_backend_player_render",
        "startup_safe": True,
        "heavy_generation_default": False,
        "recursive_scan_default": False,
        "priority_order": [
            "Sentinel Media Index artwork fields when present",
            "Player-owned cached online artwork from manual Retrieve All Art",
            "user-selected local poster database folders",
            "local sidecar poster/cover/folder/front/album images",
            "freedesktop/Caja thumbnail cache",
            "existing cached generated thumbnails only unless heavy generation is explicitly enabled",
            "system fallback icon",
        ],
        "crash_guard": "No ffmpeg/ffmpegthumbnailer/totem subprocesses or broad recursive scans run during initial library rendering by default.",
        "audit_available": "sentinel-media-player --artwork-audit /path/to/media",
        "manual_retrieve_art_button": "GUI: Library Retrieve All Art button, Nerd Stats Retrieve Art button, top menus",
        "tile_art_buttons": False,
        "bulk_retrieve_all_art": True,
        "manual_retrieve_policy": "No online or heavy artwork retrieval runs at startup. Bulk retrieval is user-triggered and runs in the background.",
        "online_art_retrieval": online_art_profile(),
        "important_note": "Sentinel Media Index is the backend library source. The Media Player renders the view and owns manual online artwork retrieval/cache.",
        "supported_sidecars": ["cover.jpg", "folder.jpg", "front.jpg", "album.jpg", "poster.jpg", "thumbnail.jpg", "fanart.jpg", "MovieName-poster.jpg", "SongName-cover.jpg"],
        "local_thumbnail_recovery": {"freedesktop_cache": True, "video_generation": "disabled during startup by default", "audio_embedded": "disabled during startup by default"},
        "media_index_art_roots": ["~/.local/share/sentinel-media-index/artwork", "covers", "posters", "thumbnails", "~/.local/share/sentinel/media-index/artwork", "~/.sentinel/media-index/artwork"],
    }


def _looks_like_image(path: Path) -> bool:
    return path.suffix.lower() in {".jpg", ".jpeg", ".png", ".webp"}


def _slug_variants(*values: str) -> list[str]:
    variants: list[str] = []
    for value in values:
        text = str(value or "").strip()
        if not text:
            continue
        basic = "".join(ch if ch.isalnum() else " " for ch in text).strip()
        collapsed = " ".join(basic.split())
        for candidate in (text, collapsed, collapsed.lower(), collapsed.replace(" ", "_"), collapsed.replace(" ", "-")):
            if candidate and candidate not in variants:
                variants.append(candidate)
    return variants


def _freedesktop_thumbnail_path(media_path: Path) -> str:
    try:
        media_path = media_path.expanduser().resolve()
        if not media_path.is_file():
            return ""
        digest = hashlib.md5(media_path.as_uri().encode("utf-8")).hexdigest() + ".png"
        for root in (Path.home() / ".cache" / "thumbnails", Path.home() / ".thumbnails"):
            for size in ("xx-large", "x-large", "large", "normal"):
                candidate = root / size / digest
                if candidate.is_file():
                    return str(candidate)
    except Exception:
        return ""
    return ""


def _candidate_art_paths_for_path(media_path: Path) -> list[str]:
    parent = media_path.parent
    stem = media_path.stem
    exts = (".jpg", ".jpeg", ".png", ".webp")
    roots = [
        parent,
        parent.parent,
        parent / "artwork", parent / "covers", parent / "posters", parent / "thumbnails",
        Path.home() / ".local/share/sentinel-media-index",
        Path.home() / ".local/share/sentinel-media-index/artwork",
        Path.home() / ".local/share/sentinel-media-index/covers",
        Path.home() / ".local/share/sentinel-media-index/posters",
        Path.home() / ".local/share/sentinel-media-index/thumbnails",
        Path.home() / ".local/share/sentinel/media-index/artwork",
        Path.home() / ".sentinel/media-index/artwork",
    ]
    for raw in load_config().get("local_poster_databases", []) or []:
        p = Path(os.path.expanduser(str(raw)))
        if p.is_dir():
            roots.insert(0, p)
            roots.insert(1, p / "Movies")
            roots.insert(2, p / "TV Shows")
            roots.insert(3, p / "Music")
    names: list[str] = []
    for variant in _slug_variants(stem):
        for suffix in ("", "-poster", "_poster", "-cover", "_cover", "-front", "_front", "-thumbnail", "_thumbnail"):
            for ext in exts:
                names.append(variant + suffix + ext)
    for base in ("cover", "folder", "front", "album", "albumart", "album_art", "poster", "movie", "thumbnail", "thumb", "fanart", "backdrop"):
        for ext in exts:
            names.append(base + ext)
    out: list[str] = []
    seen: set[str] = set()
    for root in roots:
        for name in names:
            candidate = os.path.abspath(os.path.expanduser(str(root / name)))
            if candidate not in seen:
                seen.add(candidate)
                out.append(candidate)
    return out


def artwork_audit_profile(path_or_query: str) -> dict[str, Any]:
    normalized = normalise_media_argument(path_or_query) or path_or_query
    media_path = Path(os.path.expanduser(normalized))
    checked = []
    found = []
    for raw in _candidate_art_paths_for_path(media_path)[:120]:
        p = Path(raw)
        exists = p.is_file()
        image_like = _looks_like_image(p)
        checked.append({"path": str(p), "exists": exists, "image_like": image_like})
        if exists and image_like:
            found.append(str(p))
    thumb = _freedesktop_thumbnail_path(media_path)
    if thumb:
        found.append(thumb)
    index_items, index_files = load_media_index()
    index_matches = []
    target_name = media_path.name.lower()
    for item in index_items:
        if item.path == str(media_path) or Path(item.path).name.lower() == target_name or item.title.lower() in str(path_or_query).lower():
            index_matches.append({
                "title": item.title,
                "path": item.path,
                "poster_path": item.poster_path,
                "thumbnail_path": item.thumbnail_path,
                "fanart_path": item.fanart_path,
                "source": item.source,
            })
            if len(index_matches) >= 5:
                break
    return {
        "app": APP_NAME,
        "version": VERSION,
        "query": path_or_query,
        "normalised_path": str(media_path),
        "media_type": classify_media_path(str(media_path)) if is_media_path(str(media_path)) else "unknown",
        "media_exists": media_path.is_file(),
        "sentinel_media_index_files_checked": [str(p) for p in index_files],
        "matching_index_rows": index_matches,
        "found_artwork_candidates": found[:20],
        "thumbnail_cache_hit": bool(thumb),
        "checked_first_candidates": checked[:35],
        "diagnosis": "Artwork displays only if Media Index provides a valid poster/thumbnail/cover field, a local sidecar image exists, or Caja/MATE has a cached thumbnail. For proper movie/album covers, fix Media Index enrichment so it stores poster_path/cover_path/thumbnail_path beside each item.",
    }


def file_association_profile() -> dict[str, Any]:
    return {
        "app": APP_NAME,
        "version": VERSION,
        "desktop_exec": "sentinel-media-player %U",
        "uri_arguments_supported": True,
        "file_arguments_supported": True,
        "mime_defaults_helper": "sentinel-media-player-set-defaults",
        "system_mime_defaults_file": "/usr/share/applications/mimeapps.list",
        "supported_examples": ["file:///home/user/Videos/movie.mkv", "/home/user/Videos/movie.avi"],
    }


def simple_player_profile() -> dict[str, Any]:
    config = load_config()
    return {
        "app": APP_NAME,
        "version": VERSION,
        "simple_player_startup": bool(config.get("simple_player_startup", True)),
        "responsive_default_window_layout": True,
        "default_workspace": "Now Playing / simple player",
        "library_role": "optional local file-grid workspace opened from sidebar/menu",
        "library_background_metadata_only": False,
        "library_render_on_demand": True,
        "startup_policy": "The player window and controls open first. No Library file grid is loaded at startup; the Library scans only approved user folders when opened.",
        "responsiveness_goal": "playback controls, drag/drop, Open Files, and Continue Last remain responsive because Library startup loading is disabled",
        "v1_direction": "simple VLC-style local player first; Library is a bounded file grid, not a library/poster system",
        "fallback_if_library_slow": "Use File -> Open Files, drag/drop, or Continue Last; Library is optional and bounded to four user folders.",
    }


def simple_library_profile() -> dict[str, Any]:
    return {
        "app": APP_NAME,
        "version": VERSION,
        "simple_file_library": True,
        "library_view_removed": True,
        "startup_library_load": False,
        "approved_roots": [
            {"category": "Movies", "path": "~/Videos/Movies", "media_types": ["video"]},
            {"category": "TV Shows / Episodes", "path": "~/Videos/TV Shows", "media_types": ["video"]},
            {"category": "Music", "path": "~/Music", "media_types": ["audio"]},
            {"category": "eBooks", "path": "~/Documents/eBooks", "media_types": ["ebook"]},
        ],
        "render_policy": "grid file viewer with system icons; no poster/artwork lookup during first paint",
        "scan_policy": "background scan only when Library is opened or Refresh Library is pressed",
        "excluded_by_design": ["Pictures", "Downloads", "random Videos root files", "Media Index raw library", "online artwork retrieval"],
        "v1_value": "Player stays snappy and works as a simple local video/audio/eBook launcher first.",
    }


def ui_profile() -> dict[str, Any]:
    return {
        "app": APP_NAME,
        "version": VERSION,
        "layout": "simple_player_first_file_grid_library_jobs_theme_compact_responsive",
        "responsive_default_window": responsive_layout_profile(),
        "landing_page": "simple player / Now Playing workspace",
        "theme_parity": "Sentinel Jobs command dashboard style",
        "approved_library_roots": ["~/Videos/Movies", "~/Videos/TV Shows", "~/Music", "~/Documents/eBooks"],
        "side_file_bar": "removed",
        "queue_access": "Queue workspace via top menu; explicit play queue only",
        "visible_tabs": False,
        "header_quick_buttons": [],
        "workspace_quick_buttons": [],
        "header_quick_buttons_removed": True,
        "library_play_switches_to_now_playing": True,
        "library_background_load": False,
        "library_lazy_render": False,
        "library_tile_batch_size": max(4, min(int(load_config().get("library_tile_batch_size", 8) or 8), 16)),
        "library_startup_display_limit": max(12, min(int(load_config().get("library_startup_display_limit", 24) or 24), 24)),
        "library_quick_search": bool(load_config().get("library_quick_search_enabled", True)),
        "library_search_shortcut": "Ctrl+F",
        "paged_board_rendering": True,
        "load_more_button": True,
        "library_fast_contract_only": False,
        "slow_raw_discovery_default": False,
        "artwork_discovery": "disabled for simple Library grid first paint",
        "top_menu_bar": {
            "File": ["Open Files", "Open Folder", "Refresh Library Grid", "Set as Default", "Quit"],
            "DragDrop": ["Drop local media files/folders onto the player window, video surface, or Library board"],
            "Playback": ["Play/Pause", "Stop", "Previous/Next", "Skip Back/Forward", "Skip Intro/Credits", "Video Fullscreen", "Load/Remove Subtitles"],
            "Library": ["Show All Library", "Focus Search", "Clear Search", "Movies", "TV Shows / Episodes", "Music", "eBooks", "Refresh Library Grid", "Load More", "Clear"],
            "View": ["Library Workspace", "Now Playing Workspace", "Queue Workspace", "Nerd Stats Workspace", "AEGIS Workspace"],
            "Settings": ["Auto Skip Intro", "Online Nerd Stats", "Media Index Startup Load", "Double-Tap Fullscreen", "Subtitles", "Status/Formats"],
            "Nerd Stats": ["Refresh", "Audit Current Artwork", "Retrieve Art", "Online Lookup"],
            "AEGIS": ["Diagnostics", "Status", "Actions"],
        },
        "metadata_authority": "Media Index remains installed but is not used for Player Library startup",
        "online_art_retrieval": online_art_profile(),
        "policy": "The Queue workspace is a real explicit play queue. The player opens as a simple player; it does not read the Library file grid at startup. Library is a bounded file-grid scanner over approved user folders.",
    }



def responsive_layout_profile() -> dict[str, Any]:
    return {
        "app": APP_NAME,
        "version": VERSION,
        "responsive_default_window": True,
        "screen_fit_hardening": True,
        "default_size": {"width": 900, "height": 620},
        "minimum_size": {"width": 360, "height": 280},
        "startup_workspace": "Now Playing",
        "layout_policy": "use a taller comfortable default on large desktops while clamping under small SentinelOS/MATE desktops before v1 lock",
        "scaling_changes": [
            "drastically lowered forced minimum window size",
            "added screen-aware default-size guard",
            "left command sidebar is inside its own vertical scroller so it cannot force window height",
            "removed poster-database action from primary sidebar in simple-player mode",
            "reduced queue hidden-page column widths so hidden notebook pages do not force width",
            "compact hero/header/search/sidebar/control padding",
            "smaller responsive video-frame request",
            "wrapped playback controls and queue buttons with GTK FlowBox",
            "shorter status/time labels",
            "compact Library grid tiles with system icons",
        ],
        "catalogue_policy": "catalogue/poster landing remains removed; Library is a compact file grid opened on demand",
        "v1_value": "the GUI must open inside the default visible desktop and remain resizable before v1 lock",
    }


def window_fit_profile() -> dict[str, Any]:
    profile = responsive_layout_profile()
    profile["window_fit_profile"] = True
    profile["live_issue_addressed"] = "default window could extend past the visible MATE desktop and resist resizing because sidebar/page requisitions were too large"
    profile["expected_user_result"] = "Sentinel Media Player opens taller than v0.5.29 on normal desktops, still clamps for small screens, remains resizable, and keeps the sidebar scrollable if vertical space is tight"
    return profile

def normalise_args_profile(samples: list[str]) -> dict[str, Any]:
    return {
        "app": APP_NAME,
        "version": VERSION,
        "samples": {sample: normalise_media_argument(sample) for sample in samples},
    }


def drag_drop_profile() -> dict[str, Any]:
    config = load_config()
    return {
        "app": APP_NAME,
        "version": VERSION,
        "drag_drop_enabled": bool(config.get("drag_drop_enabled", True)),
        "targets": ["main player window", "Now Playing video surface", "Library board"],
        "accepted_inputs": ["local files", "local folders from Caja/file manager", "file:// URI list drops"],
        "supported_media": sorted(list(AUDIO_EXTENSIONS | VIDEO_EXTENSIONS | EBOOK_EXTENSIONS)),
        "behaviour": "Dropped playable files are appended to the explicit queue and the first dropped playable item starts immediately. Dropped folders are scanned through the same safe library filter as Open Folder.",
        "policy": "Drag/drop never mutates the Media Index; it adds temporary/local player items only unless the user later refreshes/indexes that folder through Sentinel Media Index.",
    }


def subtitle_profile() -> dict[str, Any]:
    config = load_config()
    return {
        "app": APP_NAME,
        "version": VERSION,
        "subtitle_controls": True,
        "default_enabled": bool(config.get("subtitles_enabled", True)),
        "sidecar_auto_detection": bool(config.get("detect_sidecar_subtitles", True)),
        "overlay_safe_mode": bool(config.get("subtitle_overlay_safe_mode", True)),
        "auto_apply_on_play": bool(config.get("subtitle_auto_apply_on_play", False)),
        "supported_external_extensions": [".srt", ".ass", ".ssa", ".vtt", ".sub"],
        "gui_entry_points": ["Playback menu: Load External Subtitles", "Playback menu: Remove / Disable Subtitles", "Now Playing buttons: Subtitles / No Subs", "keyboard: S toggles subtitles"],
        "sidecar_matching": ["Movie Name.srt", "Movie Name.en.srt", "Subs/Movie Name.srt", "Subtitles/Movie Name.en.srt"],
        "gstreamer_policy": "Uses playbin external suburi for manually loaded subtitle files and playbin text stream flags for embedded subtitles only when explicitly enabled or safe mode is off.",
        "overlay_safe_mode_policy": "Automatic subtitle overlay is suppressed during normal playback by default to avoid green/blocky video corruption on sensitive GStreamer sink/codec combinations. User can enable subtitles per video with S or Load External Subtitles.",
        "remove_policy": "Remove/Disable Subtitles hides subtitle streams for playback and clears external subtitle binding; it never deletes .srt/.ass/.ssa/.vtt/.sub files.",
    }


def resume_profile() -> dict[str, Any]:
    config = load_config()
    raw = config.get("resume_positions", {}) or {}
    if not isinstance(raw, dict):
        raw = {}
    last_path = str(config.get("last_played_path", "") or "")
    last = raw.get(last_path, {}) if last_path else {}
    return {
        "app": APP_NAME,
        "version": VERSION,
        "continue_last_enabled": True,
        "resume_playback_enabled": bool(config.get("resume_playback_enabled", True)),
        "resume_min_seconds": int(config.get("resume_min_seconds", 30) or 30),
        "resume_near_end_seconds": int(config.get("resume_near_end_seconds", 120) or 120),
        "saved_items": len(raw),
        "last_played_path": last_path,
        "last_played_exists": bool(last_path and Path(os.path.expanduser(last_path)).is_file()),
        "last_played_title": str(last.get("title", "")) if isinstance(last, dict) else "",
        "last_played_position": float(last.get("position", 0.0) or 0.0) if isinstance(last, dict) else 0.0,
        "policy": "Local-only resume state. The Player writes positions to ~/.config/sentinel-media-player/config.json and does not modify Sentinel Media Index.",
        "gui_entry_points": ["Sidebar: Continue Last", "Playback menu: Continue Last", "Settings: Remember playback position"],
    }



def v1_feature_freeze_profile() -> dict[str, Any]:
    """Return the Phase 1 v1 feature-freeze contract for Program 119."""
    config = load_config()
    frozen_features = {
        "startup_workspace": "Now Playing / simple player",
        "catalogue_landing_page": False,
        "library_mode": "bounded local file-grid viewer",
        "approved_library_roots": ["~/Videos/Movies", "~/Videos/TV Shows", "~/Music", "~/Documents/eBooks"],
        "library_startup_scan": False,
        "media_index_mutation_from_player": False,
        "drag_drop_playback": bool(config.get("drag_drop_enabled", True)),
        "open_file_open_folder": True,
        "manual_subtitle_controls": True,
        "subtitle_overlay_safe_mode_default": bool(config.get("subtitle_overlay_safe_mode", True)),
        "continue_last_resume": bool(config.get("resume_playback_enabled", True)),
        "scalable_window_fit": True,
        "local_first_no_telemetry": True,
        "aegis_diagnostics": True,
    }
    explicitly_deferred = [
        "Kodi-style catalogue/poster landing page",
        "automatic poster/artwork retrieval at startup",
        "full Media Index catalogue rendering inside Player startup",
        "background online metadata lookup from the Player",
        "MPRIS/global media-key daemon integration",
        "advanced playlist/library database management",
        "theme/dashboard redesign beyond window-fit and usability fixes",
    ]
    required_live = [
        "Install with apt dependency resolution together with sentinel-media-index 1.0.7",
        "Confirm startup opens inside the visible SentinelOS/MATE desktop and remains resizable",
        "Confirm Now Playing is usable immediately before opening Library",
        "Confirm Library scans only approved folders when opened or refreshed",
        "Confirm video and music playback from file grid and drag/drop",
        "Confirm external subtitles can be loaded/removed and safe mode prevents green/blocky overlay glitch",
        "Confirm Continue Last resumes after more than 30 seconds of playback",
        "Confirm Player actions do not mutate Sentinel Media Index",
    ]
    return {
        "app": APP_NAME,
        "program": 119,
        "version": VERSION,
        "phase": "phase_1_feature_freeze",
        "feature_freeze_active": True,
        "stable_lock": False,
        "paired_media_index": {
            "program": 118,
            "required_version": "1.0.7",
            "status": "unchanged v1+ catalogue/index authority; Player v1 path no longer depends on catalogue landing page",
        },
        "frozen_features": frozen_features,
        "explicitly_deferred_until_after_v1": explicitly_deferred,
        "required_live_validation_before_v1": required_live,
        "next_phase": "Phase 2 live SentinelOS/MATE validation, then Phase 3 1.0.0 promotion",
        "policy": "No new features before 1.0.0 unless a live validation blocker is found.",
    }


def phase2_live_validation_profile() -> dict[str, Any]:
    """Return the Phase 2 live SentinelOS/MATE validation contract.

    This profile is intentionally non-mutating. It records the live checks that
    must pass on the user's actual desktop before Program 119 can be promoted to
    1.0.0.
    """
    config = load_config()
    required_commands = [
        "sentinel-media-player-v1-feature-freeze-status",
        "sentinel-media-player-window-fit-status",
        "sentinel-media-player-simple-library-status",
        "sentinel-media-player-playback-status",
        "sentinel-media-player-final-audit",
        "sentinel-media-player-v1-lock-prep-status",
        "sentinel-media-player --self-test --no-gui",
        "sentinel-media-player",
    ]
    manual_checks = [
        {"gate": "startup_window_fit", "expected": "Player opens to Now Playing inside the visible SentinelOS/MATE desktop and can be resized."},
        {"gate": "snappy_controls", "expected": "Play/Pause/Stop/Open/drag-drop controls respond immediately; no Library scan blocks startup."},
        {"gate": "library_on_demand", "expected": "Library scans only approved folders when opened or Refresh Library is pressed."},
        {"gate": "approved_roots_only", "expected": "Visible Library roots are ~/Videos/Movies, ~/Videos/TV Shows, ~/Music, and ~/Documents/eBooks only."},
        {"gate": "video_playback", "expected": "At least three local videos play from Library/Open File/drag-drop without green/blocky overlay glitches."},
        {"gate": "audio_playback", "expected": "At least one music/audio file plays and queue controls remain responsive."},
        {"gate": "ebooks", "expected": "eBooks appear in the file-grid Library and open externally rather than freezing the player."},
        {"gate": "subtitle_safe_mode", "expected": "Manual subtitle load/remove works; safe overlay mode prevents the previous green-glitch sample from corrupting video."},
        {"gate": "continue_last", "expected": "After >30 seconds of playback, close/reopen and Continue Last resumes correctly."},
        {"gate": "media_index_no_mutation", "expected": "Playback/search/subtitles/drag-drop/resume do not rewrite Sentinel Media Index catalogues or metadata."},
    ]
    blockers = [
        "Window still opens larger than the usable desktop or cannot be resized.",
        "Opening the player blocks on Library/catalogue scanning.",
        "Playback controls freeze while Library is loading.",
        "Subtitle safe mode still causes green/blocky video corruption on multiple files.",
        "Library scans outside the approved v1 folders without explicit user selection.",
        "Player mutates Media Index during normal playback/search/subtitle/resume workflows.",
    ]
    return {
        "app": APP_NAME,
        "program": 119,
        "version": VERSION,
        "phase": "phase_2_live_validation",
        "stable_lock": False,
        "feature_freeze_active": bool(v1_feature_freeze_profile().get("feature_freeze_active")),
        "paired_media_index": {
            "program": 118,
            "required_version": "1.0.7",
            "status": "unchanged and treated as the stable Program 118 index authority during Player validation",
        },
        "startup_contract": {
            "default_workspace": "Now Playing",
            "library_scan_at_startup": False,
            "catalogue_poster_landing": False,
            "window_fit_required": True,
            "simple_player_startup": bool(config.get("simple_player_startup", True)),
        },
        "approved_library_roots": ["~/Videos/Movies", "~/Videos/TV Shows", "~/Music", "~/Documents/eBooks"],
        "required_command_checks": required_commands,
        "manual_live_checks": manual_checks,
        "release_candidate_blockers": blockers,
        "v1_allowed_after": "All required command checks and manual live checks pass on SentinelOS/MATE with this exact package pair.",
        "recommended_next_version_after_pass": "1.0.0",
        "policy": "Phase 2 records live validation only. No new features are accepted before v1 unless a validation blocker is found.",
    }


def phase3_rc1_profile() -> dict[str, Any]:
    """Return the Phase 3 v1 stable-lock verification contract."""
    return {
        "app": APP_NAME,
        "program": 119,
        "version": VERSION,
        "phase": "phase_3_v1_release_candidate",
        "package_version": "1.0.0-1",
        "stable_lock": False,
        "release_candidate": True,
        "paired_media_index": {
            "program": 118,
            "required_version": "1.0.7",
            "status": "unchanged v1+ Media Index authority paired with Player v1",
        },
        "v1_scope": {
            "startup_workspace": "Now Playing",
            "catalogue_poster_landing": False,
            "library_mode": "bounded lightweight file-grid viewer",
            "library_roots": ["~/Videos/Movies", "~/Videos/TV Shows", "~/Music", "~/Documents/eBooks"],
            "library_scan_at_startup": False,
            "media_index_mutation_from_player": False,
            "drag_drop_playback": True,
            "manual_subtitle_controls": True,
            "subtitle_overlay_safe_mode_default": True,
            "continue_last_resume": True,
            "window_default": {"width": 900, "height": 620, "screen_clamped": True, "minimum": {"width": 360, "height": 280}},
            "local_first_no_telemetry": True,
        },
        "phase_1_feature_freeze": v1_feature_freeze_profile(),
        "phase_2_live_validation_contract": phase2_live_validation_profile(),
        "final_live_gate_completed_before_stable": [
            "Install v1 beside Sentinel Media Index 1.0.7 with apt dependency resolution.",
            "Confirm the taller default window fits the visible SentinelOS/MATE desktop and remains resizable.",
            "Confirm Now Playing opens immediately with no Library scan at startup.",
            "Confirm Library grid opens on demand and only shows approved roots.",
            "Confirm video/audio playback, drag/drop, subtitles, Continue Last, and eBook external-open remain functional.",
            "Confirm no Player workflow mutates Media Index files.",
        ],
        "promotion_after_pass": "completed: 1.0.0 stable lock",
        "policy": "v1.0.0 is stable locked; no new features until post-v1 versions.",
    }


def v1_stable_profile() -> dict[str, Any]:
    """Return the Program 119 v1 stable-lock profile."""
    return {
        "app": APP_NAME,
        "program": 119,
        "version": VERSION,
        "package_version": "1.0.0-1",
        "phase": "v1_stable_lock",
        "stable_lock": True,
        "release_candidate": False,
        "paired_media_index": {
            "program": 118,
            "required_version": "1.0.7",
            "status": "unchanged v1+ / stable Program 118 Media Index authority paired with Player v1",
        },
        "locked_scope": {
            "startup_workspace": "Now Playing",
            "catalogue_poster_landing": False,
            "library_mode": "bounded lightweight file-grid viewer",
            "library_roots": ["~/Videos/Movies", "~/Videos/TV Shows", "~/Music", "~/Documents/eBooks"],
            "library_scan_at_startup": False,
            "media_index_mutation_from_player": False,
            "drag_drop_playback": True,
            "open_file_open_folder": True,
            "manual_subtitle_controls": True,
            "subtitle_overlay_safe_mode_default": True,
            "continue_last_resume": True,
            "window_default": {"width": 900, "height": 620, "screen_clamped": True, "minimum": {"width": 360, "height": 280}},
            "local_first_no_telemetry": True,
        },
        "post_v1_policy": "Only blocker/security/packaging fixes should change v1.0.0. Larger catalogue/poster/dashboard work belongs in post-v1 versions.",
        "validation_basis": [
            "Phase 1 feature freeze completed",
            "Phase 2 live-validation contract completed",
            "Phase 3 release-candidate package created",
            "Final static audit and self-test passed in sandbox",
            "User reported the player was working well enough after the simple-player/window-fit pivots",
        ],
    }

def v1_readiness_profile() -> dict[str, Any]:
    config = load_config()
    gates = {
        "media_index_pair_unchanged": True,
        "simple_file_grid_library": True,
        "simple_player_startup": bool(config.get("simple_player_startup", True)),
        "responsive_default_window_layout": True,
        "library_render_on_demand": True,
        "library_quick_search": bool(config.get("library_quick_search_enabled", True)),
        "library_does_not_scan_on_startup": True,
        "gstreamer_runtime_diagnostics": True,
        "manual_subtitle_controls": True,
        "subtitle_overlay_safe_mode_default": bool(config.get("subtitle_overlay_safe_mode", True)),
        "drag_drop_playback": bool(config.get("drag_drop_enabled", True)),
        "continue_last_resume": bool(config.get("resume_playback_enabled", True)),
        "local_first_no_telemetry": True,
        "aegis_status_actions": True,
        "phase_1_feature_freeze": bool(v1_feature_freeze_profile().get("feature_freeze_active")),
        "phase_2_live_validation_profile": True,
        "phase_3_rc1_profile": True,
        "v1_stable_profile": True,
    }
    pending_live = [
        "Install on SentinelOS/MATE and confirm the player opens immediately to Now Playing while Library file list loads in the background",
        "Open Library and confirm library first paint is acceptable on demand",
        "Play MP4/MKV from selected Library tiles",
        "Confirm subtitle safe mode prevents green/blocky overlay corruption",
        "Use Ctrl+F / Library search to filter a large library without a refresh",
        "Load external subtitles manually and remove/disable them",
        "Drag/drop a file and a folder from Caja",
        "Play for >30 seconds, close/reopen, then use Continue Last",
    ]
    return {
        "app": APP_NAME,
        "version": VERSION,
        "v1_candidate_status": "v1-stable-locked",
        "stable_lock": True,
        "gates": gates,
        "passed_static_gates": sorted([k for k, v in gates.items() if v]),
        "retained_live_validation_checklist": pending_live,
        "recommended_next_version_after_pass": "post-v1 patch only if a blocker is found",
    }


def v1_lock_prep_profile() -> dict[str, Any]:
    """Return the non-mutating Program 119 v1 lock preparation profile."""
    readiness = v1_readiness_profile()
    gates = dict(readiness.get("gates", {}))
    gates.update({
        "polish_audit_command": True,
        "stable_lock_report_command": True,
        "media_index_program_118_v1_plus_pairing": True,
        "phase_1_feature_freeze": bool(v1_feature_freeze_profile().get("feature_freeze_active")),
        "no_player_library_mutation": bool(load_config().get("library_fast_contract_only", True)),
    })
    required_live = [
        "Install sentinel-media-index 1.0.7 and sentinel-media-player 1.0.0 together with apt dependency resolution",
        "Run sentinel-media-player-final-audit and confirm required static gates pass",
        "Confirm the GUI opens to Now Playing / simple player and fits within the normal default window size without clipped controls",
        "Resize the default window smaller and confirm playback controls wrap instead of disappearing",
        "Open the Library and confirm first paint is acceptable on the real library",
        "Play at least three library videos, including the former subtitle-overlay glitch sample with safe mode on",
        "Load and remove external subtitles on one video",
        "Drag/drop one file and one folder from Caja into the player",
        "Resume a video with Continue Last after >30 seconds of playback",
        "Confirm no unwanted Media Index mutation occurs from playback, search, subtitles, drag/drop, or resume",
    ]
    passed = sorted(k for k, v in gates.items() if v)
    return {
        "app": APP_NAME,
        "program": 119,
        "version": VERSION,
        "audit_type": "v1_stable_lock",
        "stable_lock": True,
        "locked_version": "1.0.0",
        "paired_media_index": {
            "program": 118,
            "required_minimum": "1.0.7",
            "status": "already v1+ / stable-locked; keep unchanged for this pass unless live tests expose an index-side defect",
            "fast_contract": "not used by Player v0.5.28 normal Library path",
        },
        "gates": gates,
        "passed_static_gates": passed,
        "failed_static_gates": sorted(k for k, v in gates.items() if not v),
        "required_live_validation": required_live,
        "recommendation": "Program 119 Sentinel Media Player is v1 stable-locked at 1.0.0. Keep Media Index paired at 1.0.7 unless an index-side defect is found.",
    }


def final_audit_profile() -> dict[str, Any]:
    """Non-destructive final static audit profile for v1 RC preparation."""
    checks = {
        "aegis_status": aegis_status().get("package") == PACKAGE_NAME,
        "media_index_bridge_discovery_safe": isinstance(media_index_status(), dict),
        "no_startup_catalogue_load": True,
        "fast_paged_board": bool(fast_board_profile().get("fast_paged_board")),
        "quick_search": bool(library_search_profile().get("library_quick_search")),
        "simple_player_startup": bool(simple_player_profile().get("simple_player_startup")),
        "responsive_default_window_layout": bool(responsive_layout_profile().get("responsive_default_window")),
        "library_render_on_demand": bool(simple_player_profile().get("library_render_on_demand")),
        "drag_drop": bool(drag_drop_profile().get("drag_drop_enabled")),
        "subtitle_controls": bool(subtitle_profile().get("subtitle_controls")),
        "subtitle_overlay_safe_mode": bool(subtitle_profile().get("overlay_safe_mode")),
        "resume_continue_last": bool(resume_profile().get("continue_last_enabled")),
        "playback_runtime_diagnostics": bool(playback_runtime_profile().get("recommended_debian_packages")),
        "v1_lock_prep_profile": bool(v1_lock_prep_profile().get("passed_static_gates")),
        "phase_1_feature_freeze": bool(v1_feature_freeze_profile().get("feature_freeze_active")),
        "local_first_policy": True,
    }
    failed = sorted(k for k, v in checks.items() if not v)
    warnings = []
    runtime = playback_runtime_profile()
    if runtime.get("status") != "ready":
        warnings.append("GStreamer runtime may report needs_runtime_packages on a headless build host; validate on SentinelOS/MATE after apt install.")
    return {
        "app": APP_NAME,
        "program": 119,
        "version": VERSION,
        "audit_type": "final_v1_stable_audit",
        "static_audit_pass": not failed,
        "failed_required_checks": failed,
        "warnings": warnings,
        "checks": checks,
        "v1_readiness": v1_readiness_profile(),
        "v1_lock_prep": v1_lock_prep_profile(),
        "next_step": "v1 stable lock complete. Use this package as the Program 119 baseline; future work should start at post-v1 patch versions.",
    }


def _write_markdown_report(payload: dict[str, Any], output: str, title: str) -> str:
    out = Path(output).expanduser()
    if not out.suffix:
        out = out.with_suffix(".md")
    if out.exists() and out.is_symlink():
        raise RuntimeError(f"unsafe_report_symlink_target:{out}")
    if _path_has_symlink_component(out.parent):
        raise RuntimeError(f"unsafe_report_symlink_parent:{out.parent}")
    checks = payload.get("checks", {}) or payload.get("gates", {})
    lines = [
        f"# {title}",
        "",
        f"- App: {payload.get('app', APP_NAME)}",
        f"- Program: {payload.get('program', 119)}",
        f"- Version: {payload.get('version', VERSION)}",
        f"- Audit type: {payload.get('audit_type', '')}",
        f"- Static pass: {payload.get('static_audit_pass', len(payload.get('failed_static_gates', [])) == 0)}",
        f"- Stable lock: {payload.get('stable_lock', False)}",
        "",
        "## Checks",
    ]
    if checks:
        for key in sorted(checks):
            lines.append(f"- {key}: `{checks[key]}`")
    failed = payload.get("failed_required_checks") or payload.get("failed_static_gates") or []
    lines += ["", "## Failed required checks", *(f"- {x}" for x in failed)] if failed else ["", "## Failed required checks", "- None"]
    live = payload.get("required_live_validation") or payload.get("v1_lock_prep", {}).get("required_live_validation", [])
    if live:
        lines += ["", "## Required live validation"] + [f"- {x}" for x in live]
    warnings = payload.get("warnings", [])
    if warnings:
        lines += ["", "## Warnings"] + [f"- {x}" for x in warnings]
    lines += ["", "## Next step", str(payload.get("next_step") or payload.get("recommendation") or "Proceed only after live SentinelOS/MATE validation."), ""]
    _safe_write_text(out, "\n".join(lines), role="markdown_report")
    return str(out)


def generate_final_audit(output: str | None = None) -> dict[str, Any]:
    payload = final_audit_profile()
    if output is not None and output != "":
        payload["written_report"] = _write_markdown_report(payload, output, f"Sentinel Media Player v{VERSION} Final Stable Audit")
    audit("final_polish_audit", payload.get("static_audit_pass"), "ok" if payload.get("static_audit_pass") else "warning")
    return payload


def generate_stable_lock_report(output: str | None = None) -> dict[str, Any]:
    payload = v1_lock_prep_profile()
    payload.update({
        "stable_lock_report": "v1_stable_lock",
        "stable_lock_allowed_now": True,
        "stable_lock_completed": True,
        "locked_version": "1.0.0",
    })
    if output is not None and output != "":
        payload["written_report"] = _write_markdown_report(payload, output, f"Sentinel Media Player v{VERSION} v1 Stable-Lock Report")
    audit("stable_lock_preparation_report", payload.get("recommendation", ""))
    return payload


def playback_runtime_profile() -> dict[str, Any]:
    """Report the GStreamer runtime pieces needed for library video playback.

    This is intentionally non-destructive and safe on headless systems. It checks
    element availability through PyGObject/GStreamer when available and falls back
    to gst-inspect-1.0 if the CLI exists.
    """
    gst_import_error = ""
    gst_ready = False
    element_results: dict[str, bool] = {}
    check_groups = {
        "core_required": ["playbin", "uridecodebin", "autoaudiosink"],
        "embedded_video_preferred": ["gtksink", "gtkglsink"],
        "video_fallbacks": ["autovideosink", "ximagesink", "xvimagesink", "glimagesink"],
        "common_decoder_demuxer_checks": ["qtdemux", "matroskademux", "avdec_h264", "avdec_h265", "avdec_mpeg4", "avdec_aac", "avdec_ac3"],
    }
    all_elements = []
    for values in check_groups.values():
        for name in values:
            if name not in all_elements:
                all_elements.append(name)
    try:
        import gi  # type: ignore
        gi.require_version("Gst", "1.0")
        from gi.repository import Gst  # type: ignore
        Gst.init(None)
        gst_ready = True
        for name in all_elements:
            element_results[name] = bool(Gst.ElementFactory.find(name))
    except Exception as exc:
        gst_import_error = f"{type(exc).__name__}: {exc}"
        inspector = shutil.which("gst-inspect-1.0")
        if inspector:
            for name in all_elements:
                try:
                    proc = subprocess.run([inspector, name], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5)
                    element_results[name] = proc.returncode == 0
                except Exception:
                    element_results[name] = False
        else:
            for name in all_elements:
                element_results[name] = False
    embedded_ok = any(element_results.get(name) for name in check_groups["embedded_video_preferred"])
    fallback_ok = any(element_results.get(name) for name in check_groups["video_fallbacks"])
    codec_ok = any(element_results.get(name) for name in ("avdec_h264", "avdec_h265", "avdec_mpeg4"))
    missing_core = [name for name in check_groups["core_required"] if not element_results.get(name)]
    missing_common = [name for name in check_groups["common_decoder_demuxer_checks"] if not element_results.get(name)]
    recommended_packages = [
        "gstreamer1.0-plugins-base",
        "gstreamer1.0-plugins-good",
        "gstreamer1.0-plugins-bad",
        "gstreamer1.0-plugins-ugly",
        "gstreamer1.0-libav",
        "gstreamer1.0-x",
        "gstreamer1.0-gl",
        "gstreamer1.0-gtk3",
    ]
    status = "ready" if (not missing_core and (embedded_ok or fallback_ok) and codec_ok) else "needs_runtime_packages"
    return {
        "app": APP_NAME,
        "version": VERSION,
        "status": status,
        "gst_python_ready": gst_ready,
        "gst_import_error": gst_import_error,
        "element_results": element_results,
        "groups": check_groups,
        "embedded_video_ready": embedded_ok,
        "fallback_video_ready": fallback_ok,
        "common_video_codecs_ready": codec_ok,
        "missing_core": missing_core,
        "missing_common_decoder_demuxer_elements": missing_common,
        "recommended_debian_packages": recommended_packages,
        "library_playback_diagnosis": "If Library tiles load but videos do not start or show only a blank/grey surface, the simple file grid is probably fine; install the missing GStreamer video sink/codec packages and retry.",
        "v0_5_17_fix": "Playback/runtime status helper plus stronger .deb dependencies for common local MP4/MKV/AVI playback.",
    }


def self_test() -> int:
    errors = []
    warnings = []
    try:
        status = aegis_status()
        if status.get("package") != PACKAGE_NAME:
            errors.append("package status mismatch")
    except Exception as exc:
        errors.append(f"aegis status failed: {exc}")
    try:
        _ = media_index_status()
    except Exception as exc:
        errors.append(f"media index status failed: {exc}")
    try:
        if parse_seconds("1:23") != 83:
            errors.append("marker parser mm:ss failed")
        if parse_seconds("1:02:03") != 3723:
            errors.append("marker parser hh:mm:ss failed")
    except Exception as exc:
        errors.append(f"marker parser failed: {exc}")
    try:
        sample = nerd_stats("Example Movie 2020 1080p.mkv", allow_online=False)
        if sample.get("mode") != "local":
            errors.append("nerd stats local mode failed")
        controls = desktop_controls_profile()
        if controls.get("hotkeys", {}).get("Ctrl+Q") != "close app":
            errors.append("desktop controls profile failed")
        if not library_profile().get("default_library_source"):
            errors.append("library profile failed")
        if not library_search_profile().get("library_quick_search"):
            errors.append("library search profile failed")
        if not simple_player_profile().get("simple_player_startup"):
            errors.append("simple player startup profile failed")
        if not normalise_media_argument("file:///tmp/example.mkv").endswith("/tmp/example.mkv"):
            errors.append("file URI normalisation failed")
        if not desktop_controls_profile().get("seek_hotfix", {}).get("enabled"):
            errors.append("seek hotfix profile failed")
        if desktop_controls_profile().get("video_surface", {}).get("double_tap") != "toggle video-only fullscreen / restore normal view":
            errors.append("double-tap fullscreen profile failed")
        if library_profile().get("auto_load_on_startup"):
            errors.append("library auto-load should be disabled for simple grid mode")
        if ui_profile().get("side_file_bar") != "removed":
            errors.append("ui no-sidebar profile failed")
        if "Settings" not in ui_profile().get("top_menu_bar", {}):
            errors.append("top menu profile failed")
        if not responsive_layout_profile().get("responsive_default_window"):
            errors.append("responsive layout profile failed")
        if not library_filter_profile().get("enabled"):
            errors.append("library filter profile failed")
        if metadata_authority_profile().get("metadata_authority") != "Sentinel Media Index":
            errors.append("metadata authority profile failed")
        if not artwork_profile().get("enabled"):
            errors.append("artwork profile failed")
        if retrieve_media_index_profile().get("retrieve_media_index_button"):
            errors.append("retrieve media index should not be primary workflow in simple grid mode")
        if not fast_board_profile().get("fast_paged_board"):
            errors.append("fast board profile failed")
        if not playback_runtime_profile().get("recommended_debian_packages"):
            errors.append("playback runtime profile failed")
        if not subtitle_profile().get("subtitle_controls"):
            errors.append("subtitle profile failed")
        if not drag_drop_profile().get("drag_drop_enabled"):
            errors.append("drag/drop profile failed")
        if not resume_profile().get("continue_last_enabled"):
            errors.append("resume profile failed")
        if not v1_readiness_profile().get("gates", {}).get("continue_last_resume"):
            errors.append("v1 readiness profile failed")
        if not v1_readiness_profile().get("gates", {}).get("library_quick_search"):
            errors.append("v1 readiness search gate failed")
        if not v1_readiness_profile().get("gates", {}).get("simple_player_startup"):
            errors.append("v1 readiness simple-player gate failed")
        if not v1_lock_prep_profile().get("gates", {}).get("polish_audit_command"):
            errors.append("v1 lock prep profile failed")
        if not phase2_live_validation_profile().get("phase") == "phase_2_live_validation":
            errors.append("phase 2 live validation profile failed")
        if not final_audit_profile().get("static_audit_pass"):
            errors.append("final polish audit failed")
    except Exception as exc:
        errors.append(f"nerd stats local failed: {exc}")
    try:
        from . import app  # noqa: F401
    except Exception as exc:
        warnings.append(f"gui import warning: {exc}")
    result = {
        "app": APP_NAME,
        "version": VERSION,
        "self_test": "pass" if not errors else "fail",
        "errors": errors,
        "warnings": warnings,
        "note": "GUI warnings can indicate missing GTK/GStreamer runtime packages on a headless build host.",
    }
    print_json(result)
    audit("self_test", result["self_test"], "ok" if not errors else "error")
    return 0 if not errors else 1


def rename_profile() -> dict:
    return {
        "app": APP_NAME,
        "version": VERSION,
        "rename_owner": "Sentinel Media Index",
        "player_role": "reflect clean library fields and launch Media Index rename workflow; does not rename media files directly",
        "media_index_commands": {
            "status": "sentinel-media-index --rename-status --json",
            "propose": "sentinel-media-index --propose-renames OUTPUT --json",
            "apply_guarded": "sentinel-media-index --apply-renames PLAN --execute --confirm RENAME_MEDIA --json",
            "undo_guarded": "sentinel-media-index --undo-last-rename --execute --confirm UNDO_RENAME --json",
            "refresh_player_library": "sentinel-media-index --scan-defaults --json",
        },
        "clean_library_fields": ["display_title", "clean_title", "rename_status", "rename_suggested_path", "metadata_confidence", "year"],
        "movie_filename_format": "Movie Title (Year).ext",
        "tv_filename_format_future": "Show Name/Season 01/Show Name - S01E02 - Episode Title.ext",
        "safe_policy": ["dry-run proposals by default", "Media Player does not mutate library paths", "guarded apply only through Media Index", "undo manifest supported by Media Index"],
    }

def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=f"{APP_NAME} - local-first AEGIS-ready audio/video player")
    parser.add_argument("files", nargs="*", help="Optional local media files or folders to queue in the GUI")
    parser.add_argument("--version", action="store_true", help="Print version")
    parser.add_argument("--aegis-status", action="store_true", help="Print AEGIS/Sentinel status JSON")
    parser.add_argument("--aegis-actions", action="store_true", help="Print AEGIS action manifest JSON")
    parser.add_argument("--media-index-status", action="store_true", help="Discover Sentinel Media Index bridge files and playable count")
    parser.add_argument("--index-contract-profile", action="store_true", help="Print fast Media Index player-library contract reader profile")
    parser.add_argument("--performance-profile", action="store_true", help="Print startup performance and simple file grid reader profile")
    parser.add_argument("--retrieve-media-index-profile", action="store_true", help="Print Retrieve Media Index button/handoff profile")
    parser.add_argument("--fast-board-profile", action="store_true", help="Print fast paged library board profile")
    parser.add_argument("--skip-profile", action="store_true", help="Print intro/credits skip defaults and marker aliases")
    parser.add_argument("--desktop-controls", action="store_true", help="Print desktop theme, hotkeys, media-key mappings, fullscreen and double-tap controls")
    parser.add_argument("--library-profile", action="store_true", help="Print Media Index library landing/board profile")
    parser.add_argument("--library-search-profile", action="store_true", help="Print Library quick search/filter profile")
    parser.add_argument("--simple-player-profile", action="store_true", help="Print simple-player startup / on-demand library profile")
    parser.add_argument("--simple-library-profile", action="store_true", help="Print simple file-grid Library profile and approved roots")
    parser.add_argument("--ui-profile", action="store_true", help="Print no-sidebar library UI and top menu profile")
    parser.add_argument("--layout-profile", action="store_true", help="Print scalable default-window GUI layout profile")
    parser.add_argument("--window-fit-profile", action="store_true", help="Print screen-fit default-window hardening profile")
    parser.add_argument("--library-filter-profile", action="store_true", help="Print Library file grid filter profile for system/cache/incomplete media exclusions")
    parser.add_argument("--metadata-authority-profile", action="store_true", help="Print Media Index metadata-authority and Player fallback lookup policy")
    parser.add_argument("--artwork-profile", action="store_true", help="Print movie/album/eBook artwork discovery profile")
    parser.add_argument("--poster-database-profile", action="store_true", help="Print local poster database/offline artwork profile")
    parser.add_argument("--add-poster-database", metavar="PATH", help="Add a local poster database folder for offline artwork matching")
    parser.add_argument("--remove-poster-database", metavar="PATH", help="Remove a local poster database folder")
    parser.add_argument("--artwork-audit", metavar="PATH_OR_QUERY", help="Audit where cover/poster artwork would be resolved from for a media path/title")
    parser.add_argument("--retrieve-art-profile", action="store_true", help="Print manual Retrieve Art button/profile policy")
    parser.add_argument("--retrieve-all-art-profile", action="store_true", help="Alias: print bulk Retrieve All Art profile")
    parser.add_argument("--first-start-art-profile", action="store_true", help="Print first-start artwork retrieval policy")
    parser.add_argument("--online-art-profile", action="store_true", help="Print manual online artwork retrieval/cache profile")
    parser.add_argument("--movie-art-profile", action="store_true", help="Print movie poster provider profile and token/key requirements")
    parser.add_argument("--tmdb-art-profile", action="store_true", help="Print TMDb-only video poster provider profile")
    parser.add_argument("--rename-profile", action="store_true", help="Print Media Index rename/clean library reflection profile")
    parser.add_argument("--file-association-profile", action="store_true", help="Print file-manager double-click/open-with association profile")
    parser.add_argument("--playback-runtime-status", action="store_true", help="Print GStreamer video/audio sink and codec readiness for library playback")
    parser.add_argument("--subtitle-profile", action="store_true", help="Print subtitle controls, sidecar detection, overlay-safe mode, and remove/disable policy")
    parser.add_argument("--subtitle-overlay-profile", action="store_true", help="Print subtitle overlay green-glitch safe-mode policy")
    parser.add_argument("--drag-drop-profile", action="store_true", help="Print drag-and-drop file/folder playback profile")
    parser.add_argument("--resume-profile", action="store_true", help="Print Continue Last / playback resume profile")
    parser.add_argument("--v1-readiness-profile", action="store_true", help="Print v1 stable-lock readiness gate profile")
    parser.add_argument("--v1-feature-freeze-profile", action="store_true", help="Print Phase 1 v1 feature-freeze contract")
    parser.add_argument("--phase2-live-validation-profile", action="store_true", help="Print Phase 2 live SentinelOS/MATE validation contract")
    parser.add_argument("--phase3-rc1-profile", action="store_true", help="Print Phase 3 v1 stable-lock verification contract")
    parser.add_argument("--v1-stable-profile", action="store_true", help="Print Program 119 v1 stable-lock profile")
    parser.add_argument("--v1-lock-prep-profile", action="store_true", help="Print final v1 lock preparation profile")
    parser.add_argument("--final-audit", nargs="?", const="", metavar="OUTPUT", help="Run final non-mutating polish audit; optionally write Markdown report")
    parser.add_argument("--stable-lock-report", nargs="?", const="", metavar="OUTPUT", help="Generate v1 stable-lock preparation report; optionally write Markdown report")
    parser.add_argument("--normalise-media-args", nargs="*", help="Debug how file paths/URIs from file managers are normalised")
    parser.add_argument("--set-auto-skip-intro", choices=["on", "off"], help="Enable/disable default Auto Skip Intro")
    parser.add_argument("--set-online-nerd-stats", choices=["on", "off"], help="Enable/disable default online Nerd Stats lookups")
    parser.add_argument("--nerd-stats", metavar="PATH_OR_QUERY", help="Print local Nerd Stats for a file/title/query")
    parser.add_argument("--online-nerd-stats", action="store_true", help="Allow this Nerd Stats command to fetch online metadata")
    parser.add_argument("--nerd-kind", choices=["auto", "movie", "song", "episode", "tv"], default="auto", help="Hint for online Nerd Stats lookup")
    parser.add_argument("--list-supported-formats", action="store_true", help="List accepted audio/video extensions")
    parser.add_argument("--scan-folder", metavar="PATH", help="Print playable media discovered under a local folder")
    parser.add_argument("--export-index-json", metavar="PATH", help="Load Sentinel Media Index bridge and export playable queue JSON")
    parser.add_argument("--self-test", action="store_true", help="Run non-destructive package self-test")
    parser.add_argument("--no-gui", action="store_true", help="Do not launch GUI after command-line operations")
    args = parser.parse_args(argv)

    if args.version:
        print(f"{APP_NAME} {VERSION}")
        return 0
    if getattr(args, "rename_profile", False):
        print_json(rename_profile())
        return 0
    if args.aegis_status:
        print_json(aegis_status())
        return 0
    if args.aegis_actions:
        print_json(aegis_actions())
        return 0
    if args.media_index_status:
        print_json(media_index_status())
        return 0
    if args.index_contract_profile:
        print_json({"app": APP_NAME, "version": VERSION, "fast_library_contract_reader": True, "preferred_files": ["~/.local/share/sentinel-media-index/player_library.json", "~/.local/share/sentinel-media-index/player_libraries/sentinel_media_player_library.json"], "contract_versions": ["sentinel_media_player_fast_library_v1"], "fallback": "disabled by default for startup speed; write the fast player library from Sentinel Media Index", "speed_goal": "no recursive discovery, no SQLite table guessing, no raw JSON crawling during normal startup"})
        return 0
    if args.performance_profile:
        print_json(performance_profile())
        return 0
    if args.retrieve_media_index_profile:
        print_json(retrieve_media_index_profile())
        return 0
    if args.fast_board_profile:
        print_json(fast_board_profile())
        return 0
    if args.skip_profile:
        print_json(skip_profile())
        return 0
    if args.desktop_controls:
        print_json(desktop_controls_profile())
        return 0
    if args.library_profile:
        print_json(library_profile())
        return 0
    if getattr(args, "library_search_profile", False):
        print_json(library_search_profile())
        return 0
    if getattr(args, "simple_player_profile", False):
        print_json(simple_player_profile())
        return 0
    if getattr(args, "simple_library_profile", False):
        print_json(simple_library_profile())
        return 0
    if args.ui_profile:
        print_json(ui_profile())
        return 0
    if getattr(args, "layout_profile", False):
        print_json(responsive_layout_profile())
        return 0
    if getattr(args, "window_fit_profile", False):
        print_json(window_fit_profile())
        return 0
    if args.library_filter_profile:
        print_json(library_filter_profile())
        return 0
    if args.metadata_authority_profile:
        print_json(metadata_authority_profile())
        return 0
    if args.artwork_profile:
        print_json(artwork_profile())
        return 0
    if getattr(args, "poster_database_profile", False):
        print_json(poster_database_profile())
        return 0
    if getattr(args, "add_poster_database", None):
        print_json(add_poster_database(args.add_poster_database))
        return 0
    if getattr(args, "remove_poster_database", None):
        print_json(remove_poster_database(args.remove_poster_database))
        return 0
    if args.artwork_audit:
        print_json(artwork_audit_profile(args.artwork_audit))
        return 0
    if getattr(args, "first_start_art_profile", False):
        config = load_config()
        print_json({"app": APP_NAME, "version": VERSION, "first_start_auto_retrieve_art": bool(config.get("first_start_auto_retrieve_art", True)), "first_start_auto_retrieve_art_done": bool(config.get("first_start_auto_retrieve_art_done", False)), "policy": "auto-run Retrieve All Art once after first successful simple file grid load, then manual only", "startup_blocking": False, "board_render_first": True, "network": "one-shot after first library load; manual thereafter"})
        return 0
    if args.retrieve_art_profile or getattr(args, "retrieve_all_art_profile", False):
        print_json({
            "app": APP_NAME,
            "version": VERSION,
            "manual_retrieve_art": True,
            "gui_entry_points": ["Library Retrieve All Art button", "Nerd Stats Retrieve Art button", "Nerd Stats menu", "Library menu"],
            "tile_art_buttons": False,
            "bulk_retrieve_all_art": True,
            "startup_policy": "First successful library load can queue Retrieve All Art once in the background after the library shell renders; all later runs are manual.",
            "manual_policy": "Retrieve All Art runs a background worker. It auto-runs once after the first successful library load, then every later run is manual. It does not scan missing-art status on the GTK thread and does not rebuild the full board automatically on finish.",
            "first_start_auto_retrieve_art": bool(load_config().get("first_start_auto_retrieve_art", True)),
            "first_start_auto_retrieve_art_done": bool(load_config().get("first_start_auto_retrieve_art_done", False)),
            "safe_batch_limit": 80,
            "movie_poster_note": "Music covers can use MusicBrainz/Cover Art Archive. Video/movie/TV posters use TMDb only; set SENTINEL_MEDIA_PLAYER_TMDB_TOKEN/TMDB_BEARER_TOKEN or SENTINEL_MEDIA_PLAYER_TMDB_API_KEY/TMDB_API_KEY.",
            "v0_5_8_fix": "Bulk retrieval no longer treats Media Index video preview thumbnails or Caja thumbnail-cache frames as true movie poster art.",
            "index_policy": "Sentinel Media Index remains the fast backend library; Player renders the display and owns online art retrieval/cache without mutating the index.",
        })
        return 0

    if getattr(args, "tmdb_art_profile", False):
        payload = online_art_profile()
        print_json({
            "app": APP_NAME,
            "version": VERSION,
            "video_poster_provider": "TMDb only",
            "tmdb_credentials_supported": ["SENTINEL_MEDIA_PLAYER_TMDB_TOKEN or TMDB_BEARER_TOKEN", "SENTINEL_MEDIA_PLAYER_TMDB_API_KEY or TMDB_API_KEY"],
            "disabled_video_sources": ["OMDb", "TVmaze", "Wikidata/Wikimedia Commons broad search"],
            "cache_dir": payload.get("cache_dir"),
            "startup_online_fetching": False,
            "retrieve_all_art": "manual or first-start one-shot background only",
            "expected_behavior_without_tmdb": "movie/TV posters will not download; local previews/fallback icons remain visible",
            "reason": "one source only keeps video poster retrieval predictable, faster to diagnose, and avoids sparse fallback searches",
            "runtime": payload.get("movie_provider_runtime", {}),
        })
        return 0
    if args.online_art_profile:
        payload = online_art_profile()
        payload.update({"app": APP_NAME, "version": VERSION})
        print_json(payload)
        return 0
    if args.movie_art_profile:
        print_json({
            "app": APP_NAME,
            "version": VERSION,
            "movie_poster_retrieval": "manual/background only",
            "reliable_movie_sources": {
                "tmdb_only": "Single video poster source; set SENTINEL_MEDIA_PLAYER_TMDB_TOKEN/TMDB_BEARER_TOKEN or SENTINEL_MEDIA_PLAYER_TMDB_API_KEY/TMDB_API_KEY",
            },
            "disabled_video_sources": ["OMDb", "TVmaze", "Wikidata/Wikimedia Commons broad search"],
            "no_key_fallback": "none for video posters; this keeps retrieval predictable and avoids slow/sparse web guessing",
            "why_music_works_first": "Music uses MusicBrainz and Cover Art Archive, which are open/no-key and designed for album cover lookup.",
            "why_movies_may_not": "Video posters now use TMDb only. If no TMDb Bearer token or API key is configured, movie posters will not download.",
            "v0_5_10_fix": "Video poster retrieval now uses TMDb only and accepts either a TMDb Bearer token or a TMDb v3 API key; local video previews are still not counted as true posters.",
        })
        return 0
    if args.file_association_profile:
        print_json(file_association_profile())
        return 0
    if getattr(args, "playback_runtime_status", False):
        print_json(playback_runtime_profile())
        return 0
    if getattr(args, "subtitle_profile", False):
        print_json(subtitle_profile())
        return 0
    if getattr(args, "subtitle_overlay_profile", False):
        print_json(subtitle_profile())
        return 0
    if getattr(args, "drag_drop_profile", False):
        print_json(drag_drop_profile())
        return 0
    if getattr(args, "resume_profile", False):
        print_json(resume_profile())
        return 0
    if getattr(args, "v1_feature_freeze_profile", False):
        print_json(v1_feature_freeze_profile())
        return 0
    if getattr(args, "phase2_live_validation_profile", False):
        print_json(phase2_live_validation_profile())
        return 0
    if getattr(args, "phase3_rc1_profile", False):
        print_json(phase3_rc1_profile())
        return 0
    if getattr(args, "v1_stable_profile", False):
        print_json(v1_stable_profile())
        return 0
    if getattr(args, "v1_readiness_profile", False):
        print_json(v1_readiness_profile())
        return 0
    if getattr(args, "v1_lock_prep_profile", False):
        print_json(v1_lock_prep_profile())
        return 0
    if getattr(args, "final_audit", None) is not None:
        print_json(generate_final_audit(args.final_audit))
        return 0
    if getattr(args, "stable_lock_report", None) is not None:
        print_json(generate_stable_lock_report(args.stable_lock_report))
        return 0
    if args.normalise_media_args is not None:
        print_json(normalise_args_profile(args.normalise_media_args))
        return 0
    if args.set_auto_skip_intro:
        config = load_config()
        config["auto_skip_intro"] = args.set_auto_skip_intro == "on"
        save_config(config)
        print_json({"auto_skip_intro": config["auto_skip_intro"], "config_updated": True})
        return 0
    if args.set_online_nerd_stats:
        config = load_config()
        config["nerd_stats_online_lookup"] = args.set_online_nerd_stats == "on"
        save_config(config)
        print_json({"nerd_stats_online_lookup": config["nerd_stats_online_lookup"], "config_updated": True})
        return 0
    if args.nerd_stats:
        print_json(nerd_stats(args.nerd_stats, kind=args.nerd_kind, allow_online=args.online_nerd_stats))
        return 0
    if args.list_supported_formats:
        print_json({
            "note": SUPPORTED_FORMAT_NOTE,
            "audio_extensions": sorted(AUDIO_EXTENSIONS),
            "video_extensions": sorted(VIDEO_EXTENSIONS),
            "ebook_extensions_library_only": sorted(EBOOK_EXTENSIONS),
            "ebook_policy": "eBooks can appear as library tiles and open externally with xdg-open; they are not GStreamer playback queue items.",
            "codec_backend": "GStreamer playbin",
            "recommended_plugins": [
                "gstreamer1.0-plugins-base",
                "gstreamer1.0-plugins-good",
                "gstreamer1.0-plugins-bad",
                "gstreamer1.0-plugins-ugly",
                "gstreamer1.0-libav",
                "gstreamer1.0-x",
                "gstreamer1.0-gl",
                "gstreamer1.0-gtk3",
            ],
        })
        return 0
    if args.scan_folder:
        items = [i.to_dict() for i in scan_folder(args.scan_folder)]
        print_json({"folder": args.scan_folder, "count": len(items), "items": items})
        return 0
    if args.export_index_json:
        items, files = load_media_index()
        out_path = Path(args.export_index_json).expanduser()
        payload = {
            "app": APP_NAME,
            "version": VERSION,
            "source_index_files": [str(p) for p in files],
            "count": len(items),
            "items": [i.to_dict() for i in items],
            "skip_profile": skip_profile(),
        }
        _safe_write_text(out_path, json.dumps(payload, indent=2, sort_keys=True), role="index_json_export")
        print_json({"exported": str(out_path), "count": len(items)})
        audit("export_index_json", str(out_path))
        return 0
    if args.self_test:
        return self_test()
    if args.no_gui:
        return 0

    from .app import launch
    return launch(args.files)


if __name__ == "__main__":
    raise SystemExit(main())
