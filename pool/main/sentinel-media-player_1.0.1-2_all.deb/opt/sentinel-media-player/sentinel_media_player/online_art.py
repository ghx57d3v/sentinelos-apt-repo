from __future__ import annotations

import hashlib
import json
import os
import re
import time
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Dict, Optional

from . import VERSION
from .aegis import CACHE_DIR, audit

USER_AGENT = f"SentinelMediaPlayer/{VERSION} (local SentinelOS desktop app; manual artwork retrieval)"
ONLINE_ART_CACHE_DIR = CACHE_DIR / "online-art"
TIMEOUT_SECONDS = 12


def _slug(text: str, fallback: str = "media") -> str:
    text = (text or fallback).strip().lower()
    text = re.sub(r"[^a-z0-9._-]+", "-", text).strip("-._")
    return text[:96] or fallback


def _query_parts(item: Any) -> Dict[str, str]:
    title = str(getattr(item, "title", "") or Path(str(getattr(item, "path", "media"))).stem)
    return {
        "title": title,
        "artist": str(getattr(item, "artist", "") or ""),
        "album": str(getattr(item, "album", "") or ""),
        "series": str(getattr(item, "series", "") or ""),
        "year": str(getattr(item, "year", "") or ""),
        "media_type": str(getattr(item, "media_type", "") or ""),
        "tmdb_id": str(getattr(item, "tmdb_id", "") or ""),
        "tvmaze_id": str(getattr(item, "tvmaze_id", "") or ""),
        "musicbrainz_id": str(getattr(item, "musicbrainz_id", "") or ""),
        "wikidata_id": str(getattr(item, "wikidata_id", "") or ""),
    }


def _tmdb_bearer_token() -> str:
    return (os.environ.get("SENTINEL_MEDIA_PLAYER_TMDB_TOKEN") or os.environ.get("TMDB_BEARER_TOKEN") or "").strip()


def _tmdb_api_key() -> str:
    return (os.environ.get("SENTINEL_MEDIA_PLAYER_TMDB_API_KEY") or os.environ.get("TMDB_API_KEY") or "").strip()


def _tmdb_available() -> bool:
    return bool(_tmdb_bearer_token() or _tmdb_api_key())


def _clean_video_title_and_year(parts: Dict[str, str]) -> tuple[str, str]:
    raw = parts.get("series") or parts.get("title") or ""
    if not raw and parts.get("path"):
        raw = Path(parts.get("path", "")).stem
    text = Path(str(raw)).stem
    year = str(parts.get("year") or "").strip()
    # Common local filename forms: [1978] Up In Smoke.avi, (1978) Title, Title 1978 720p...
    m = re.search(r"[\[(]((?:19|20)\d{2})[\])]", text)
    if m and not year:
        year = m.group(1)
    text = re.sub(r"[\[(](?:19|20)\d{2}[\])]", " ", text)
    if not year:
        m2 = re.search(r"\b((?:19|20)\d{2})\b", text)
        if m2:
            year = m2.group(1)
    # Strip release tags/noise that hurt TMDb search.
    text = re.sub(r"\b(480p|576p|720p|1080p|2160p|4k|bluray|brrip|webrip|web-dl|hdtv|dvdrip|x264|x265|h264|h265|aac|dts|extended|directors?\s*cut|remaster(?:ed)?|proper|repack)\b", " ", text, flags=re.I)
    text = re.sub(r"[._-]+", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return (text or str(raw).strip(), year)


def _request(url: str) -> urllib.request.Request:
    return urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept": "application/json,image/*,*/*"})


def _get_json(url: str) -> Optional[Any]:
    try:
        with urllib.request.urlopen(_request(url), timeout=TIMEOUT_SECONDS) as resp:
            raw = resp.read(2_000_000)
        return json.loads(raw.decode("utf-8", errors="replace"))
    except Exception as exc:
        audit("online_art_json", f"{url}: {exc}", "warning")
        return None


def _image_ext(content_type: str, url: str) -> str:
    ct = (content_type or "").lower()
    if "png" in ct:
        return ".png"
    if "webp" in ct:
        return ".webp"
    if "jpeg" in ct or "jpg" in ct:
        return ".jpg"
    suffix = Path(urllib.parse.urlparse(url).path).suffix.lower()
    if suffix in {".jpg", ".jpeg", ".png", ".webp"}:
        return ".jpg" if suffix == ".jpeg" else suffix
    return ".jpg"


def _path_has_symlink_component(path: Path) -> bool:
    p = Path(path).expanduser()
    try:
        if p.is_symlink():
            return True
    except Exception:
        return True
    cur = Path(p.anchor) if p.is_absolute() else Path.cwd()
    parts = p.parts[1:] if p.is_absolute() else p.parts
    for part in parts:
        cur = cur / part
        try:
            if cur.exists() and cur.is_symlink():
                return True
        except Exception:
            return True
    return False


def _safe_write_bytes(path: Path, data: bytes) -> None:
    out = Path(path).expanduser()
    if _path_has_symlink_component(out.parent) or (out.exists() and out.is_symlink()):
        raise RuntimeError(f"unsafe artwork cache path: {out}")
    out.parent.mkdir(parents=True, exist_ok=True)
    tmp = out.with_name(out.name + f".tmp-{os.getpid()}")
    if tmp.exists() or tmp.is_symlink():
        tmp.unlink(missing_ok=True)
    fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(data)
        os.replace(tmp, out)
    finally:
        try:
            if tmp.exists() or tmp.is_symlink():
                tmp.unlink()
        except Exception:
            pass


def _download_image(url: str, cache_key: str, provider: str) -> Optional[str]:
    try:
        if _path_has_symlink_component(ONLINE_ART_CACHE_DIR):
            raise RuntimeError(f"unsafe artwork cache dir: {ONLINE_ART_CACHE_DIR}")
        ONLINE_ART_CACHE_DIR.mkdir(parents=True, exist_ok=True)
        req = _request(url)
        with urllib.request.urlopen(req, timeout=TIMEOUT_SECONDS) as resp:
            data = resp.read(8_000_000)
            ctype = resp.headers.get("Content-Type", "")
        if not data or len(data) < 256:
            return None
        ext = _image_ext(ctype, url)
        digest = hashlib.sha256((provider + "|" + cache_key + "|" + url).encode("utf-8")).hexdigest()[:16]
        out = ONLINE_ART_CACHE_DIR / f"{_slug(cache_key)}-{provider}-{digest}{ext}"
        _safe_write_bytes(out, data)
        audit("online_art_download", f"{provider}: {out}", "ok")
        return str(out)
    except Exception as exc:
        audit("online_art_download", f"{provider}:{url}: {exc}", "warning")
        return None


def _wikidata_image_for_qid(qid: str, cache_key: str) -> Optional[str]:
    qid = (qid or "").strip()
    if not qid:
        return None
    url = "https://www.wikidata.org/w/api.php?" + urllib.parse.urlencode({
        "action": "wbgetentities",
        "ids": qid,
        "props": "claims",
        "format": "json",
    })
    data = _get_json(url)
    try:
        claims = data.get("entities", {}).get(qid, {}).get("claims", {}) if isinstance(data, dict) else {}
        p18 = claims.get("P18") or []
        if p18:
            filename = p18[0]["mainsnak"]["datavalue"]["value"]
            image_url = "https://commons.wikimedia.org/wiki/Special:Redirect/file/" + urllib.parse.quote(filename) + "?width=500"
            return _download_image(image_url, cache_key, "wikidata")
    except Exception as exc:
        audit("online_art_wikidata_qid", f"{qid}: {exc}", "warning")
    return None


def _wikidata_search_image(query: str, cache_key: str) -> Optional[str]:
    query = query.strip()
    if not query:
        return None
    search_url = "https://www.wikidata.org/w/api.php?" + urllib.parse.urlencode({
        "action": "wbsearchentities",
        "language": "en",
        "format": "json",
        "limit": "3",
        "search": query,
    })
    data = _get_json(search_url)
    if not isinstance(data, dict):
        return None
    for row in data.get("search", [])[:3]:
        qid = row.get("id")
        art = _wikidata_image_for_qid(str(qid or ""), cache_key)
        if art:
            return art
    return None


def _cover_art_archive_by_release(mbid: str, cache_key: str) -> Optional[str]:
    mbid = (mbid or "").strip()
    if not mbid:
        return None
    # The /front-500 endpoint redirects to a suitable front cover if the MBID is a release ID.
    url = f"https://coverartarchive.org/release/{urllib.parse.quote(mbid)}/front-500"
    return _download_image(url, cache_key, "coverartarchive")


def _musicbrainz_release_cover(parts: Dict[str, str]) -> Optional[str]:
    cache_key = parts.get("album") or parts.get("title") or "music"
    mbid = parts.get("musicbrainz_id", "")
    if mbid:
        art = _cover_art_archive_by_release(mbid, cache_key)
        if art:
            return art
    terms = []
    if parts.get("album"):
        terms.append(f'release:"{parts["album"]}"')
    if parts.get("artist"):
        terms.append(f'artist:"{parts["artist"]}"')
    if not terms and parts.get("title"):
        terms.append(f'release:"{parts["title"]}"')
    if not terms:
        return None
    url = "https://musicbrainz.org/ws/2/release?" + urllib.parse.urlencode({
        "query": " AND ".join(terms),
        "fmt": "json",
        "limit": "3",
    })
    data = _get_json(url)
    if not isinstance(data, dict):
        return None
    for rel in data.get("releases", [])[:3]:
        rid = rel.get("id")
        if rid:
            # Be gentle with MusicBrainz/CAA during one-hit manual retrieval.
            time.sleep(1.05)
            art = _cover_art_archive_by_release(str(rid), cache_key)
            if art:
                return art
    return None


def _tmdb_art(parts: Dict[str, str]) -> Optional[str]:
    """TMDb-only video poster provider.

    v0.5.10 policy: all video/movie/TV poster retrieval uses exactly one
    online provider, TMDb.  OMDb, TVmaze, and Wikimedia/Commons are not used
    for video poster retrieval so diagnostics are simple and behaviour is
    predictable.  TMDb works with either a Bearer token or a v3 API key.
    """
    token = _tmdb_bearer_token()
    api_key = _tmdb_api_key()
    if not token and not api_key:
        return None
    media_type = parts.get("media_type", "")
    kind = _video_kind(parts)
    query, year = _clean_video_title_and_year(parts)
    if not query:
        return None
    endpoint = "tv" if kind == "tv" or media_type in {"tv", "episode", "show"} else "movie"
    params = {"query": query, "include_adult": "false"}
    if endpoint == "movie" and year:
        params["primary_release_year"] = year
        params["year"] = year
    elif endpoint == "tv" and year:
        params["first_air_date_year"] = year
    if api_key and not token:
        params["api_key"] = api_key
    url = f"https://api.themoviedb.org/3/search/{endpoint}?" + urllib.parse.urlencode(params)
    try:
        headers = {"User-Agent": USER_AGENT, "Accept": "application/json"}
        if token:
            headers["Authorization"] = f"Bearer {token}"
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=TIMEOUT_SECONDS) as resp:
            data = json.loads(resp.read(2_000_000).decode("utf-8", errors="replace"))
        results = data.get("results") or []
        if not results:
            audit("online_art_tmdb_only", f"no TMDb match for {endpoint}:{query}:{year}", "warning")
            return None
        # Prefer candidates with a poster_path. Backdrop is deliberately not used
        # as a poster because it gives landscape placeholders in a poster tile.
        chosen = None
        for row in results[:5]:
            if row.get("poster_path"):
                chosen = row
                break
        if not chosen:
            audit("online_art_tmdb_only", f"TMDb match had no poster_path for {endpoint}:{query}:{year}", "warning")
            return None
        poster_path = chosen.get("poster_path")
        return _download_image("https://image.tmdb.org/t/p/w500" + str(poster_path), f"{query}-{year}" if year else query, "tmdb")
    except Exception as exc:
        audit("online_art_tmdb_only", str(exc), "warning")
        return None


def _omdb_art(parts: Dict[str, str]) -> Optional[str]:
    key = os.environ.get("SENTINEL_MEDIA_PLAYER_OMDB_KEY") or os.environ.get("OMDB_API_KEY")
    if not key:
        return None
    query = parts.get("title") or parts.get("series")
    if not query:
        return None
    params = {"apikey": key, "t": query, "plot": "short", "r": "json"}
    if parts.get("year"):
        params["y"] = parts["year"]
    url = "https://www.omdbapi.com/?" + urllib.parse.urlencode(params)
    data = _get_json(url)
    if not isinstance(data, dict):
        return None
    poster = str(data.get("Poster") or "")
    if poster and poster.upper() != "N/A" and poster.startswith(("http://", "https://")):
        return _download_image(poster, query, "omdb")
    return None


def _video_kind(parts: Dict[str, str]) -> str:
    media_type = (parts.get("media_type") or "").lower()
    title = (parts.get("title") or "").lower()
    series = (parts.get("series") or "").strip()
    if series or media_type in {"tv", "episode", "show"} or re.search(r"\bs\d{1,2}e\d{1,3}\b", title):
        return "tv"
    return "movie"


def _tvmaze_art(parts: Dict[str, str]) -> Optional[str]:
    query = parts.get("series") or parts.get("title")
    if not query:
        return None
    url = "https://api.tvmaze.com/singlesearch/shows?" + urllib.parse.urlencode({"q": query})
    data = _get_json(url)
    if not isinstance(data, dict):
        return None
    image = data.get("image") or {}
    image_url = image.get("original") or image.get("medium")
    if image_url:
        return _download_image(str(image_url), query, "tvmaze")
    return None


def retrieve_online_art_for_item(item: Any) -> Dict[str, Any]:
    """User-triggered online artwork lookup.

    This function is intentionally not used during startup. It downloads at most
    one image for one item into Sentinel Media Player's artwork cache and returns
    a diagnostic payload.
    """
    parts = _query_parts(item)
    providers_tried = []
    result = ""
    media_type = parts.get("media_type")
    if media_type == "audio":
        providers_tried.append("musicbrainz_cover_art_archive")
        result = _musicbrainz_release_cover(parts) or ""
        if not result:
            providers_tried.append("wikidata_commons")
            result = _wikidata_search_image(" ".join(x for x in (parts.get("artist"), parts.get("album") or parts.get("title")) if x), parts.get("album") or parts.get("title") or "music") or ""
    elif media_type == "video":
        # v0.5.10: videos use one online poster source only: TMDb.
        # This removes the confusing OMDb/TVmaze/Wikidata mix and makes it
        # obvious when posters cannot be retrieved because no TMDb credential is set.
        providers_tried.append("tmdb_only")
        if _tmdb_available():
            result = _tmdb_art(parts) or ""
            if not result:
                providers_tried.append("tmdb_no_match_or_no_poster")
        else:
            providers_tried.append("tmdb_missing_credentials")
    else:
        providers_tried.append("wikidata_commons")
        result = _wikidata_search_image(parts.get("title") or str(getattr(item, "path", "")), parts.get("title") or "media") or ""

    return {
        "title": parts.get("title"),
        "path": str(getattr(item, "path", "")),
        "media_type": media_type,
        "retrieved_artwork": result,
        "providers_tried": providers_tried,
        "cache_dir": str(ONLINE_ART_CACHE_DIR),
        "network_policy": "manual_user_triggered_only",
        "tmdb_token_available": bool(_tmdb_bearer_token()),
        "tmdb_api_key_available": bool(_tmdb_api_key()),
        "video_poster_provider": "TMDb only",
        "movie_provider_configured": _tmdb_available(),
    }


def online_art_profile() -> Dict[str, Any]:
    return {
        "manual_online_art_retrieval": True,
        "startup_online_fetching": False,
        "bulk_retrieve_all_button": True,
        "bulk_retrieve_all_fix_v8": "does not treat local video preview thumbnails / Caja thumbnails as movie poster art",
        "cache_dir": str(ONLINE_ART_CACHE_DIR),
        "default_open_sources": ["MusicBrainz + Cover Art Archive for music", "TMDb only for all video/movie/TV posters"],
        "movie_poster_sources": {
            "single_source": "TMDb only",
            "credential_options": ["SENTINEL_MEDIA_PLAYER_TMDB_TOKEN or TMDB_BEARER_TOKEN", "SENTINEL_MEDIA_PLAYER_TMDB_API_KEY or TMDB_API_KEY"],
            "disabled_video_sources": ["OMDb", "TVmaze", "Wikidata/Wikimedia Commons broad search"],
            "reason": "one source only for predictable poster retrieval and simple diagnostics",
        },
        "optional_rich_sources": ["TMDb only for movies/TV when TMDb Bearer token or API key is set"],
        "index_policy": "Sentinel Media Index supplies file catalogue and local metadata; Player retrieves and caches online artwork manually without mutating the index.",
        "speed_policy": "Fast startup is preserved because online artwork retrieval is not run during launch/catalogue render.",
        "movie_provider_runtime": {
            "tmdb_token_available": bool(_tmdb_bearer_token()),
            "tmdb_api_key_available": bool(_tmdb_api_key()),
            "tmdb_provider_available": _tmdb_available(),
            "video_provider_policy": "TMDb only",
        },
    }
