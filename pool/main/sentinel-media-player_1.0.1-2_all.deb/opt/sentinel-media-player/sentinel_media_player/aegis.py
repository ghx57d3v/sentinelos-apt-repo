from __future__ import annotations

import json
import os
import platform
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict

from . import APP_NAME, PACKAGE_NAME, PROGRAM_NUMBER, VERSION

STATE_DIR = Path(os.environ.get("XDG_STATE_HOME", Path.home() / ".local" / "state")) / PACKAGE_NAME
CONFIG_DIR = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")) / PACKAGE_NAME
CACHE_DIR = Path(os.environ.get("XDG_CACHE_HOME", Path.home() / ".cache")) / PACKAGE_NAME
AUDIT_LOG = STATE_DIR / "audit.log"
CONFIG_PATH = CONFIG_DIR / "config.json"

DEFAULT_CONFIG: Dict[str, Any] = {
    "auto_skip_intro": True,
    "auto_skip_intro_requires_marker": True,
    "manual_intro_skip_seconds": 85,
    "manual_credits_skip_action": "next_or_end",
    "nerd_stats_online_lookup": False,
    "nerd_stats_cache_enabled": True,
    "metadata_authority": "sentinel_media_index",
    "media_index_online_metadata_default": True,
    "player_online_metadata_policy": "fallback_manual_only",
    "nerd_stats_prefer_media_index_metadata": True,
    "metadata_refresh_route": "sentinel_media_index",
    "nerd_stats_user_agent": f"SentinelMediaPlayer/{VERSION} (local SentinelOS desktop app)",
    "seek_step_seconds": 10,
    "double_tap_skip_enabled": False,
    "video_double_tap_action": "fullscreen_toggle",
    "fullscreen_enabled": True,
    "subtitles_enabled": True,
    "detect_sidecar_subtitles": True,
    "subtitle_overlay_safe_mode": True,
    "subtitle_auto_apply_on_play": False,
    "subtitle_controls_v19": True,
    "subtitle_overlay_safe_mode_v20": True,
    "drag_drop_enabled": True,
    "drag_drop_v19": True,
    "catalogue_deferred_full_render": True,
    "catalogue_fast_start_v19": True,
    "desktop_theme": "Sentinel Jobs command dashboard / AEGIS Dark",
    "landing_page": "simple_player",
    "media_index_default_catalogue": False,
    "media_index_auto_load_on_startup": False,
    "media_index_discovery_mode": "disabled for player startup; Media Index remains separate",
    "catalogue_fast_contract_only": False,
    "file_association_enabled": True,
    "seek_engine": "accurate_clamped",
    "ui_layout": "simple_player_first_tabless_top_menu_workspace",
    "top_menu_bar": True,
    "visible_tabs": False,
    "real_queue_model": True,
    "audio_tile_playback_fix": True,
            "library_tile_playback_hotfix": True,
    "library_artwork_discovery": True,
    "embedded_audio_art_optional": True,
    "catalogue_filter_enabled": True,
    "catalogue_excludes_system_media": True,
    "catalogue_excludes_incomplete_downloads": True,
    "metadata_authority_bridge": True,
    "header_quick_category_buttons": False,
    "retrieve_media_index_button": False,
    "artwork_discovery_hotfix": True,
    "artwork_recovery_v3": True,
    "artwork_crash_guard_v4": True,
    "artwork_audit_v5": True,
    "now_playing_visibility_hotfix": True,
    "manual_retrieve_art": True,
    "bulk_retrieve_all_art": True,
    "online_art_retrieval_manual_only": True,
    "retrieve_all_art_nonblocking": True,
    "movie_posters_require_configured_source": True,
    "bulk_art_ignores_video_preview_thumbnails": True,
    "movie_art_provider_diagnostics_v8": True,
    "video_poster_source_tmdb_only_v10": True,
    "first_start_auto_retrieve_art": False,
    "first_start_auto_retrieve_art_done": False,
    "first_start_auto_retrieve_art_policy": "run once after first successful catalogue load, then manual only",
    "artwork_safe_mode": True,
    "artwork_heavy_generation": False,
    "artwork_recursive_scan": False,
    "artwork_max_recursive_checks": 250,
    "catalogue_background_load": True,
    "catalogue_lazy_render": True,
    "catalogue_tile_batch_size": 8,
    "catalogue_startup_display_limit": 24,
    "catalogue_page_step": 48,
    "library_quick_search_enabled": True,
    "library_quick_search_v22": True,
    "v1_polish_audit_v23": True,
    "v1_lock_prep_v23": True,
    "simple_player_startup": True,
    "catalogue_render_on_demand": True,
    "catalogue_background_metadata_only": True,
    "v1_simple_player_pivot_v24": True,
    "simple_file_library_v25": True,
    "catalogue_view_removed_v25": True,
    "catalogue_slow_raw_fallback_default": False,
    "ebook_catalogue_tiles": True,
}


def _path_has_symlink_component(path: Path) -> bool:
    p = Path(path).expanduser()
    try:
        if p.is_symlink():
            return True
    except Exception:
        return True
    cur = Path(p.anchor) if p.is_absolute() else Path.cwd()
    parts = p.parts[1:] if p.is_absolute() else p.parts
    for part in parts:
        cur = cur / part
        try:
            if cur.exists() and cur.is_symlink():
                return True
        except Exception:
            return True
    return False


def _safe_write_text(path: Path, text: str, *, append: bool = False) -> None:
    out = Path(path).expanduser()
    if _path_has_symlink_component(out.parent) or (out.exists() and out.is_symlink()):
        raise RuntimeError(f"unsafe symlinked state/config path: {out}")
    out.parent.mkdir(parents=True, exist_ok=True)
    if append:
        with out.open("a", encoding="utf-8") as fh:
            fh.write(text)
        return
    tmp = out.with_name(out.name + f".tmp-{os.getpid()}")
    if tmp.exists() or tmp.is_symlink():
        tmp.unlink(missing_ok=True)
    fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(text)
        os.replace(tmp, out)
    finally:
        try:
            if tmp.exists() or tmp.is_symlink():
                tmp.unlink()
        except Exception:
            pass


def ensure_dirs() -> None:
    for d in (STATE_DIR, CONFIG_DIR, CACHE_DIR):
        if _path_has_symlink_component(d):
            raise RuntimeError(f"unsafe symlinked app directory: {d}")
        d.mkdir(parents=True, exist_ok=True)


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def audit(action: str, detail: str = "", result: str = "ok") -> None:
    try:
        ensure_dirs()
        entry = {
            "ts": utc_now(),
            "app": PACKAGE_NAME,
            "version": VERSION,
            "action": action,
            "detail": str(detail)[:1000],
            "result": result,
        }
        _safe_write_text(AUDIT_LOG, json.dumps(entry, sort_keys=True) + "\n", append=True)
    except Exception:
        # Audit must never break playback or status reporting.
        pass


def load_config() -> Dict[str, Any]:
    ensure_dirs()
    data = dict(DEFAULT_CONFIG)
    if CONFIG_PATH.exists():
        try:
            loaded = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
            if isinstance(loaded, dict):
                data.update(loaded)
        except Exception as exc:
            audit("load_config", str(exc), "warning")
    return data


def save_config(config: Dict[str, Any]) -> None:
    ensure_dirs()
    clean = dict(DEFAULT_CONFIG)
    clean.update(config)
    _safe_write_text(CONFIG_PATH, json.dumps(clean, indent=2, sort_keys=True))
    audit("save_config", str(CONFIG_PATH))


def aegis_status(extra: Dict[str, Any] | None = None) -> Dict[str, Any]:
    config = load_config()
    status: Dict[str, Any] = {
        "app": APP_NAME,
        "package": PACKAGE_NAME,
        "program": PROGRAM_NUMBER,
        "version": VERSION,
        "readiness": "v1-stable-locked",
        "stable_lock": True,
        "stable_lock_version": "1.0.0",
        "local_first": True,
        "network": "none required for normal playback or Library grid; Player online lookup is fallback/manual only",
        "default_permission": "Disabled",
        "default_library_source": "Simple local file grid",
        "metadata_authority": "Sentinel Media Index",
        "landing_page": "simple video player; Library is a bounded file grid",
        "max_permission": "Full Local Control + Media Index Metadata Read + Optional Fallback User-Initiated Metadata Lookup",
        "ai_safe": True,
        "user_controlled": True,
        "skip_controls": {
            "auto_skip_intro_default": bool(config.get("auto_skip_intro", True)),
            "auto_skip_requires_marker": bool(config.get("auto_skip_intro_requires_marker", True)),
            "manual_skip_intro": True,
            "manual_skip_credits": True,
            "metadata_fields_supported": [
                "intro_start", "intro_end", "credits_start", "credits_end",
                "opening_start", "opening_end", "outro_start", "outro_end",
            ],
        },

        "library": {
            "default_source": "Approved user media folders",
            "landing_page": "simple player first; Library file grid is a menu/sidebar option",
            "auto_load_on_startup": False,
            "startup_render_policy": "no catalogue load at startup; scan approved folders only when Library is opened",
            "simple_player_startup": bool(config.get("simple_player_startup", True)),
            "approved_roots": ["~/Videos/Movies", "~/Videos/TV Shows", "~/Music", "~/Documents/eBooks"],
            "catalogue_view_removed": bool(config.get("catalogue_view_removed_v25", True)),
            "catalogue_render_on_demand": bool(config.get("catalogue_render_on_demand", True)),
            "manual_load_button": "refresh approved local Library folders",
            "retrieve_media_index_button": "removed from primary Player workflow",
            "discovery_mode": "no Media Index discovery during Player startup",
            "performance_mode": "simple_file_grid_only",
            "catalogue_startup_display_limit": 24,
            "catalogue_tile_batch_size": 8,
            "catalogue_page_step": 48,
            "catalogue_deferred_full_render": True,
            "library_quick_search": bool(config.get("library_quick_search_enabled", True)),
            "library_search_shortcut": "Ctrl+F",
            "v1_polish_audit": bool(config.get("v1_polish_audit_v23", True)),
            "v1_lock_prep": bool(config.get("v1_lock_prep_v23", True)),
            "drag_drop_enabled": True,
            "subtitle_overlay_safe_mode": bool(config.get("subtitle_overlay_safe_mode", True)),
            "subtitle_auto_apply_on_play": bool(config.get("subtitle_auto_apply_on_play", False)),
            "categories": ["TV Shows / Episodes", "Movies", "eBooks", "Music", "Music Videos", "Audiobooks / Podcasts", "Home Videos", "Unsorted"],
            "file_manager_double_click": True,
            "drag_drop_playback": True,
            "raw_path_first_experience": False,
            "side_file_bar": "removed",
            "queue_location": "Queue workspace via top menu (explicit play queue only)",
            "top_menu_bar": True,
    "visible_tabs": False,
            "real_queue_model": True,
            "theme_parity": "Sentinel Jobs command dashboard style",
            "catalogue_filter": {
                "enabled": True,
                "excludes": ["system/app/cache media", "incomplete/partial downloads", "Trash/cache/thumbnails", "package/build/test/sample media"],
            },
            "audio_tile_playback_fix": True,
            "library_tile_playback_hotfix": True,
            "artwork_sources": ["Media Index artwork fields when present", "Player-owned cached online artwork from manual Retrieve All Art", "local sidecar poster/cover/folder/front/album images", "freedesktop/Caja thumbnail cache", "artwork audit diagnostics", "online/heavy generation disabled during startup", "system fallback icons"],
            "artwork_crash_guard": {"enabled": True, "startup_safe": True, "heavy_generation_default": False, "recursive_scan_default": False},
            "manual_retrieve_art": {"enabled": True, "entry_points": ["Library Retrieve All Art button", "Nerd Stats Retrieve Art button", "top menu"], "tile_art_buttons": False, "bulk_retrieve_all_art": True, "nonblocking_worker": True, "network": "first successful catalogue load once, then user-triggered/manual only", "startup_fetching": "after first catalogue render only; never blocks initial board", "movie_sources": "TMDb only for video/movie/TV posters; accepts Bearer token or v3 API key"},
            "header_quick_buttons": [],
            "header_quick_buttons_removed": True,
            "ebook_catalogue_tiles": True,
        },
        "ui": {
            "layout": "simple_player_first_tabless_top_menu_workspace_jobs_theme",
            "theme_parity": "Sentinel Jobs command dashboard style",
            "side_file_bar": "removed",
            "primary_navigation": "top menu bar + tabless Library/Player/Queue/Nerd Stats/AEGIS workspaces",
            "visible_tabs": False,
            "menus": ["File", "Playback", "Library", "View", "Settings", "Nerd Stats", "AEGIS"],
            "header_quick_buttons": [],
            "header_quick_buttons_removed": True,
            "artwork_crash_guard": True,
            "manual_retrieve_art": True,
            "fast_catalogue_first_page": "v0.5.25 does not render catalogue tiles during startup; Library opens on demand and still renders only a small first page",
            "library_quick_search": "v0.5.22 filters the already-loaded fast catalogue and renders only the matched first page",
            "bulk_retrieve_all_art": True,
            "online_art_at_startup": "disabled by default in v0.5.25; manual thereafter",
        },

        "desktop_controls": {
            "theme": "Sentinel Jobs-style AEGIS Dark / Sentinel Gold dashboard fit",
            "ctrl_q_close": True,
            "keyboard_seeking": {"left": "-10 seconds", "right": "+10 seconds", "engine": "accurate seek, duration-clamped, slider fallback"},
            "volume_keys": {"up": "+5%", "down": "-5%"},
            "fullscreen": {"enabled": True, "mode": "video_only", "toggle": "F11", "exit": "Escape", "main_window_fullscreened": False},
            "fn_media_keys": ["XF86AudioPlay", "XF86AudioPause", "XF86AudioStop", "XF86AudioPrev", "XF86AudioNext", "XF86AudioRewind", "XF86AudioForward"],
            "video_double_tap": {"action": "toggle video-only fullscreen / restore normal view", "edge_skip_conflict_resolved": True, "ten_second_seek_available_via": ["buttons", "keyboard arrows", "Fn rewind/forward"], "gesture_surface": "input-only non-painting"},
            "video_surface_overlay_hotfix": True,
            "ten_second_seek_hotfix": True,
            "time_display": "played / left / total",
        },

        "metadata_authority_bridge": {
            "enabled": True,
            "primary_source": "Sentinel Media Index",
            "online_enrichment_owner": "Sentinel Media Index",
            "player_online_lookup": "fallback/manual only",
            "player_background_fetch": False,
            "cache_policy": "Player reads cached/enriched metadata from Media Index first; fallback lookups may be cached locally when explicitly requested.",
            "supported_provenance_fields": [
                "metadata_source", "metadata_provider", "online_metadata_source", "online_metadata_provider",
                "metadata_enriched_at", "metadata_status", "online_metadata_status", "metadata_cached",
                "imdb_id", "tmdb_id", "tvmaze_id", "musicbrainz_id", "wikidata_id"
            ],
            "nerd_stats_default": "Media Index metadata first",
        },
        "nerd_stats": {
            "workspace": True,
            "visible_tab": False,
            "pretty_layout": True,
            "online_default": bool(config.get("nerd_stats_online_lookup", False)),
            "online_policy": "Player-side online lookup is fallback/manual only. Default enriched metadata should come from Sentinel Media Index cache.",
            "default_metadata_source": "Sentinel Media Index",
            "sources": ["Sentinel Media Index enriched cache", "local file/index metadata", "fallback MusicBrainz", "fallback TVmaze", "fallback Wikidata", "optional fallback TMDb token"],
        },
        "storage": {
            "state_dir": str(STATE_DIR),
            "config_dir": str(CONFIG_DIR),
            "cache_dir": str(CACHE_DIR),
            "audit_log": str(AUDIT_LOG),
            "config_path": str(CONFIG_PATH),
        },
        "runtime": {
            "python": platform.python_version(),
            "system": platform.system(),
            "machine": platform.machine(),
        },
        "timestamp_utc": utc_now(),
    }
    if extra:
        status.update(extra)
    return status


def aegis_actions() -> Dict[str, Any]:
    return {
        "app": APP_NAME,
        "package": PACKAGE_NAME,
        "program": PROGRAM_NUMBER,
        "version": VERSION,
        "actions": [
            {
                "name": "launch_gui",
                "command": "sentinel-media-player",
                "permission": "User Initiated",
                "network": False,
                "description": "Launch the local GTK/GStreamer media player.",
            },
            {
                "name": "open_file",
                "command": "sentinel-media-player /path/to/media",
                "permission": "User Initiated",
                "network": False,
                "description": "Open one or more local audio/video files in the player queue.",
            },
            {
                "name": "media_index_status",
                "command": "sentinel-media-player --media-index-status",
                "permission": "Read Local Metadata",
                "network": False,
                "description": "Report discovered Sentinel Media Index databases/exports and playable item count.",
            },
            {
                "name": "skip_profile",
                "command": "sentinel-media-player --skip-profile",
                "permission": "Read App Config",
                "network": False,
                "description": "Report intro/credits skip defaults and supported marker names.",
            },
            {
                "name": "desktop_controls_profile",
                "command": "sentinel-media-player --desktop-controls",
                "permission": "Read Static Metadata",
                "network": False,
                "description": "Report supported hotkeys, Fn/media key mappings, fullscreen controls, and input-only video double-tap fullscreen toggle.",
            },
            {
                "name": "ui_profile",
                "command": "sentinel-media-player --ui-profile",
                "permission": "Read Static Metadata",
                "network": False,
                "description": "Report catalogue-first UI, Sentinel Jobs theme parity, removed side file bar, Queue tab, and top menu structure.",
            },
            {
                "name": "catalogue_filter_profile",
                "command": "sentinel-media-player --catalogue-filter-profile",
                "permission": "Read Static Metadata",
                "network": False,
                "description": "Report catalogue filtering rules for excluding system/app/cache media and incomplete downloads from the Library board.",
            },
            {
                "name": "metadata_authority_profile",
                "command": "sentinel-media-player --metadata-authority-profile",
                "permission": "Read App Config",
                "network": False,
                "description": "Report the Media Index metadata-authority policy and fallback Player lookup posture.",
            },
            {
                "name": "artwork_profile",
                "command": "sentinel-media-player --artwork-profile",
                "permission": "Read Static Metadata",
                "network": False,
                "description": "Report movie/album/eBook cover art lookup policy and supported artwork locations.",
            },
            {
                "name": "artwork_audit",
                "command": "sentinel-media-player --artwork-audit /path/to/media",
                "permission": "Read Local Metadata",
                "network": False,
                "description": "Audit where a selected movie/song cover or poster is being looked up from and whether a Media Index artwork field is present.",
            },
            {
                "name": "nerd_stats_local",
                "command": "sentinel-media-player --nerd-stats /path/to/media",
                "permission": "Read Local Metadata",
                "network": False,
                "description": "Generate local Nerd Stats from file and Media Index metadata.",
            },
            {
                "name": "nerd_stats_online",
                "command": "sentinel-media-player --nerd-stats 'title' --online-nerd-stats",
                "permission": "User Initiated Online Lookup",
                "network": True,
                "description": "Fetch user-requested free online metadata for the supplied/current title.",
            },
            {
                "name": "scan_folder",
                "command": "sentinel-media-player --scan-folder /path/to/folder",
                "permission": "Read Local Files",
                "network": False,
                "description": "Enumerate playable local media files under a selected folder.",
            },
            {
                "name": "supported_formats",
                "command": "sentinel-media-player --list-supported-formats",
                "permission": "Read Static Metadata",
                "network": False,
                "description": "List accepted file extensions and codec dependency note.",
            },
            {
                "name": "retrieve_art_profile",
                "command": "sentinel-media-player --retrieve-art-profile",
                "permission": "Read Only",
                "network": False,
                "description": "Report manual Retrieve All Art controls and policy. Actual GUI online artwork retrieval is user initiated.",
            },
            {
                "name": "online_art_profile",
                "command": "sentinel-media-player --online-art-profile",
                "permission": "Read Only",
                "network": False,
                "description": "Report Player-owned manual online artwork retrieval/cache policy and provider stack.",
            },
            {
                "name": "final_polish_audit",
                "command": "sentinel-media-player --final-audit",
                "permission": "Read Static Metadata",
                "network": False,
                "description": "Run the final static audit for the v1 stable lock.",
            },
            {
                "name": "v1_lock_prep",
                "command": "sentinel-media-player --v1-lock-prep-profile",
                "permission": "Read Static Metadata",
                "network": False,
                "description": "Report Program 119 v1 stable-lock status and validation gates.",
            },
            {
                "name": "stable_lock_report",
                "command": "sentinel-media-player --stable-lock-report OUTPUT.md",
                "permission": "Read Static Metadata",
                "network": False,
                "description": "Generate the v1 stable-lock report.",
            },
            {
                "name": "aegis_status",
                "command": "sentinel-media-player --aegis-status",
                "permission": "Read App Status",
                "network": False,
                "description": "Return JSON status for AEGIS/Sentinel Control integration.",
            },
        ],
    }
