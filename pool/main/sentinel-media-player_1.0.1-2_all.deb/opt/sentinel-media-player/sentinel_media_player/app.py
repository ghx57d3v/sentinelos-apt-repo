from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import shutil
import sys
import threading
import time
from pathlib import Path
from urllib.parse import unquote, urlparse
from typing import List, Optional

from . import APP_ID, APP_NAME, VERSION
from .aegis import CACHE_DIR, audit, load_config, save_config
from .bridge import MediaItem, catalogue_filter_profile, format_seconds, load_media_index, normalise_media_argument, scan_folder
from .formats import classify_media_path, is_media_path
from .nerd_stats import nerd_stats
from .online_art import retrieve_online_art_for_item, online_art_profile

try:
    import gi
    gi.require_version("Gtk", "3.0")
    gi.require_version("Gst", "1.0")
    from gi.repository import GLib, Gst, Gtk, Gdk, GdkPixbuf
except Exception as exc:  # pragma: no cover - runtime dependency path
    gi = None
    Gtk = None
    Gst = None
    GLib = None
    Gdk = None
    GTK_IMPORT_ERROR = exc
else:
    GTK_IMPORT_ERROR = None


SUBTITLE_EXTENSIONS = (".srt", ".ass", ".ssa", ".vtt", ".sub")
GST_PLAY_FLAG_TEXT = 1 << 2

SIMPLE_LIBRARY_ROOTS = [
    ("Movies", "~/Videos/Movies", {"video"}),
    ("TV Shows / Episodes", "~/Videos/TV Shows", {"video"}),
    ("Music", "~/Music", {"audio"}),
    ("eBooks", "~/Documents/eBooks", {"ebook"}),
]
SIMPLE_LIBRARY_ALLOWED_CATEGORIES = {name for name, _path, _types in SIMPLE_LIBRARY_ROOTS}


THEME_CSS = b"""
/* Sentinel Jobs parity theme: dark command-console shell, blue-black cards,
   Sentinel gold headings/actions, cyan status/readiness accents. */
window, .sentinel-root {
  background: #05090B;
  color: #D9E8EF;
}
label { color: #D9E8EF; }
menubar, menu, menuitem {
  background: #101821;
  color: #E8F2F5;
}
menubar {
  border-bottom: 1px solid #263845;
  padding: 2px 4px;
}
menuitem:hover {
  background: #142838;
  color: #E19B00;
}
#sentinelHero {
  background: #071116;
  border: 1px solid #142938;
  padding: 3px;
}
#sentinelHeroIcon {
  color: #E19B00;
  font-size: 18px;
}
#sentinelHeroTitle {
  color: #E19B00;
  font-weight: bold;
  letter-spacing: 2px;
}
#sentinelHeroSubtitle, #sentinelModeLabel {
  color: #C6D6DE;
}
#sentinelHeaderTitle { color: #E19B00; font-weight: bold; }
#sentinelQuickButton {
  min-width: 72px;
  min-height: 24px;
  padding: 2px 5px;
  border: 1px solid #E19B00;
  color: #E19B00;
  background: #0B1822;
  font-weight: bold;
}
#sentinelQuickButton:hover {
  background: #142C3A;
  color: #FFFFFF;
  border-color: #03C8FF;
}
button {
  background: #111D26;
  color: #EAF3F5;
  border: 1px solid #1B3340;
  border-radius: 0px;
  padding: 2px 5px;
}
button:hover {
  border-color: #E19B00;
  color: #FFFFFF;
  background: #142432;
}
button:active {
  background: #1D2E38;
}
notebook {
  background: #05090B;
  border: 1px solid #071116;
}
notebook tab {
  background: #111D26;
  color: #EAF3F5;
  border: 1px solid #1B3340;
  padding: 5px 10px;
}
notebook tab:checked {
  background: #0A151C;
  color: #E19B00;
  border-color: #E19B00;
}
treeview {
  background: #0D171F;
  color: #D9E8EF;
  border: 1px solid #1B3340;
}
treeview:selected {
  background: #122A3A;
  color: #FFFFFF;
}
textview, textview text {
  background: #071116;
  color: #D9E8EF;
}
scale trough { background: #202D36; }
scale highlight { background: #E19B00; }
#sentinelLibraryHeader {
  color: #E19B00;
  font-weight: bold;
}
#sentinelLibrarySection {
  color: #03C8FF;
  font-weight: bold;
  font-size: 13px;
  padding-top: 6px;
}
#sentinelWorkspace {
  background: #05090B;
  border: 1px solid #071116;
}
#sentinelLibraryHelp, #sentinelLibraryStatus, #sentinelStatusLabel, #sentinelMarkerLabel, #sentinelTimeLabel {
  color: #C6D6DE;
}
#sentinelSearchEntry {
  background: #0D171F;
  color: #EAF3F5;
  border: 1px solid #1B3340;
  padding: 4px;
}
#sentinelSearchEntry:focus {
  border-color: #E19B00;
}
#sentinelSearchLabel {
  color: #03C8FF;
  font-weight: bold;
}
#sentinelLibraryTile {
  background: #0D171F;
  color: #D9E8EF;
  border: 1px solid #1B3340;
  border-radius: 0px;
  padding: 5px;
}
#sentinelLibraryTile:hover {
  border-color: #E19B00;
  background: #102230;
}
#sentinelTileTitle {
  color: #FFFFFF;
  font-weight: bold;
}
#sentinelTileMeta {
  color: #AFC4CE;
}
#sentinelVideoFrame {
  background: #000000;
  border: 1px solid #E19B00;
}
#sentinelVideoSurface, #sentinelFullscreenVideoSurface {
  background: transparent;
}
#sentinelDropHint {
  color: #C6D6DE;
  font-size: 12px;
}
#sentinelPlayerHint {
  color: #03C8FF;
  font-weight: bold;
}
#sentinelNerdHero {
  background: #0D171F;
  border: 1px solid #1B3340;
  border-radius: 0px;
  padding: 12px;
}
#sentinelNerdTitle {
  color: #E19B00;
  font-weight: bold;
}
#sentinelSidebar {
  background: #071116;
  border: 1px solid #142938;
  padding: 3px;
}
#sentinelSidebarButton {
  min-width: 108px;
  min-height: 24px;
  padding: 2px 5px;
  border: 1px solid #1B3340;
  color: #EAF3F5;
  background: #111D26;
  font-weight: bold;
}
#sentinelSidebarButton:hover {
  border-color: #E19B00;
  color: #E19B00;
  background: #142432;
}
#sentinelCommandCard {
  background: #0D171F;
  border: 1px solid #1B3340;
  padding: 6px;
}
#sentinelCompactControls {
  background: #05090B;
}
#sentinelCompactControls button {
  min-height: 22px;
}
#sentinelCompactLabel {
  color: #C6D6DE;
}
#sentinelCompactCheck {
  color: #C6D6DE;
}

#sentinelNerdSubtle { color: #C6D6DE; }
#sentinelNerdField {
  color: #E19B00;
  font-weight: bold;
}
#sentinelNerdValue { color: #EAF3F5; }
"""

if GTK_IMPORT_ERROR is not None:
    class SentinelMediaPlayer:  # fallback marker for missing GUI runtime
        pass
else:
    class SentinelMediaPlayer(Gtk.Application):  # type: ignore[misc, valid-type]
        def __init__(self, initial_files: Optional[List[str]] = None) -> None:
            super().__init__(application_id=APP_ID)
            self.initial_files = initial_files or []
            self.config = load_config()
            self.window: Optional[Gtk.ApplicationWindow] = None
            self.playbin = None
            self.items: List[MediaItem] = []
            self.current_index: int = -1
            self.queue_indices: List[int] = []
            self.queue_store = None
            self.queue_tree = None
            self.audio_art_cache_dir = CACHE_DIR / "audio-art"
            self.video_art_cache_dir = CACHE_DIR / "video-thumbnails"
            self.artwork_resolution_cache: dict[str, str] = {}
            self.manual_poster_database_index: dict[str, str] = {}
            self.manual_poster_database_index_built = False
            self.local_poster_databases = self._normalise_poster_database_roots(self.config.get("local_poster_databases", []))
            self.artwork_safe_mode = bool(self.config.get("artwork_safe_mode", True))
            self.artwork_heavy_generation_enabled = bool(self.config.get("artwork_heavy_generation", False))
            self.artwork_recursive_scan_enabled = bool(self.config.get("artwork_recursive_scan", False))
            self.artwork_max_recursive_checks = int(self.config.get("artwork_max_recursive_checks", 250) or 250)
            self.online_art_bulk_limit = int(self.config.get("online_art_bulk_limit", 80) or 80)
            self.retrieve_all_art_processed = 0
            self.retrieve_all_art_total = 0
            self.retrieve_all_art_in_progress = False
            self.retrieve_media_index_in_progress = False
            self.first_start_auto_retrieve_art = bool(self.config.get("first_start_auto_retrieve_art", True))
            self.first_start_auto_retrieve_art_done = bool(self.config.get("first_start_auto_retrieve_art_done", False))
            self.first_start_auto_retrieve_art_scheduled = False
            self.retrieve_media_index_button = None
            self.load_more_button = None
            self.retrieve_all_art_button = None
            self.catalogue_lazy_render = bool(self.config.get("catalogue_lazy_render", True))
            # v0.5.19 fast-start mode: old configs may still carry v0.5.18's
            # 48-tile/all-tile behaviour. Clamp first paint hard, then page more
            # tiles on demand so Library scan feels instant on SentinelOS/MATE.
            raw_tile_batch = int(self.config.get("catalogue_tile_batch_size", 8) or 8)
            raw_start_limit = int(self.config.get("catalogue_startup_display_limit", 24) or 24)
            raw_page_step = int(self.config.get("catalogue_page_step", 48) or 48)
            self.catalogue_tile_batch_size = max(4, min(raw_tile_batch, 16))
            self.catalogue_startup_display_limit = max(12, min(raw_start_limit, 24))
            self.library_visible_limit = self.catalogue_startup_display_limit
            self.library_page_step = max(12, min(raw_page_step, 96))
            self.catalogue_deferred_full_render = bool(self.config.get("catalogue_deferred_full_render", True))
            self.catalogue_background_load = bool(self.config.get("catalogue_background_load", True))
            self.catalogue_fast_contract_only = bool(self.config.get("catalogue_fast_contract_only", True))
            self.drag_drop_enabled = bool(self.config.get("drag_drop_enabled", True))
            self._catalogue_loading = False
            self._library_render_token = 0
            self._library_render_queue = []
            self._library_render_total = 0
            self._library_render_done = 0
            self.seek_dragging = False
            self.position_scale = None
            self.position_time_label = None
            self.status_label = None
            self.marker_label = None
            self.store = None
            self.tree = None
            self.right_notebook = None
            self.library_notebook = None
            self.quick_category_buttons = True
            self.library_category_filter: Optional[str] = None
            self.library_search_enabled = bool(self.config.get("library_quick_search_enabled", True))
            self.library_search_text: str = ""
            self.library_search_entry = None
            self.library_status_label = None
            self.board_flowboxes = {}
            self.video_box = None
            self.video_event_box = None
            self.video_widget = None
            self.video_placeholder = None
            self.fullscreen_window = None
            self.fullscreen_video_event_box = None
            self.play_button = None
            self.fullscreen_button = None
            self.volume_scale = None
            self.auto_intro_check = None
            self.online_stats_check = None
            self.auto_intro_menu_item = None
            self.online_stats_menu_item = None
            self.media_index_default_menu_item = None
            self.double_tap_menu_item = None
            self.subtitle_menu_item = None
            self.sidecar_subtitle_menu_item = None
            self.subtitle_safe_mode_menu_item = None
            self.subtitle_status_label = None
            self.manual_subtitle_path: Optional[str] = None
            self.manual_subtitle_media_path: Optional[str] = None
            self.current_subtitle_path: Optional[str] = None
            self.subtitles_enabled = bool(self.config.get("subtitles_enabled", True))
            self.detect_sidecar_subtitles = bool(self.config.get("detect_sidecar_subtitles", True))
            self.subtitle_overlay_safe_mode = bool(self.config.get("subtitle_overlay_safe_mode", True))
            self.subtitle_auto_apply_on_play = bool(self.config.get("subtitle_auto_apply_on_play", False))
            self.subtitle_user_enabled_for_current = False
            self.nerd_text = None
            self.nerd_title_label = None
            self.nerd_subtitle_label = None
            self.nerd_grid = None
            self.aegis_text = None
            self.autoadvance = True
            self.intro_skipped_for_index: set[int] = set()
            self.is_fullscreen = False
            self.last_video_click_time: int = 0
            self.last_video_click_side: Optional[str] = None
            self.video_double_tap_action = str(self.config.get("video_double_tap_action", "fullscreen_toggle") or "fullscreen_toggle")
            self.skip_step_seconds = int(self.config.get("seek_step_seconds", 10) or 10)
            self.gesture_surfaces_input_only = True
            self.last_position_seconds: Optional[float] = None
            self.last_duration_seconds: Optional[float] = None
            self.seek_engine = "accurate_clamped"
            self.resume_playback_enabled = bool(self.config.get("resume_playback_enabled", True))
            self.resume_min_seconds = int(self.config.get("resume_min_seconds", 30) or 30)
            self.resume_near_end_seconds = int(self.config.get("resume_near_end_seconds", 120) or 120)
            self.resume_positions = self._normalise_resume_positions(self.config.get("resume_positions", {}))
            self._last_resume_save_at = 0.0
            self.continue_last_button = None
            self.resume_menu_item = None
            self.simple_player_startup = bool(self.config.get("simple_player_startup", True))
            self.simple_file_library = bool(self.config.get("simple_file_library_v25", True))
            self.screen_fit_default_window_layout = bool(self.config.get("screen_fit_default_window_layout", True))
            self.simple_library_loaded = False
            self.simple_library_loading = False
            self.simple_library_roots = [(name, Path(os.path.expanduser(path)), set(types)) for name, path, types in SIMPLE_LIBRARY_ROOTS]
            self.catalogue_render_on_demand = bool(self.config.get("catalogue_render_on_demand", True))
            self.catalogue_background_metadata_only = bool(self.config.get("catalogue_background_metadata_only", True))
            self._library_dirty = True
            self._library_rendered_once = False
            self._catalogue_loaded_in_background = False

        def do_activate(self) -> None:
            Gst.init(None)
            self._apply_theme()
            self._build_ui()
            self._build_pipeline()
            assert self.window is not None
            self.window.show_all()
            self._apply_window_fit_guard()
            if self.simple_player_startup and self.right_notebook is not None:
                self.right_notebook.set_current_page(1)
            self._load_initial_queue()
            GLib.timeout_add(500, self._refresh_position)
            audit("launch_gui", "Sentinel Media Player GUI launched")

        def _apply_theme(self) -> None:
            try:
                provider = Gtk.CssProvider()
                provider.load_from_data(THEME_CSS)
                screen = Gdk.Screen.get_default()
                if screen is not None:
                    Gtk.StyleContext.add_provider_for_screen(screen, provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
            except Exception as exc:
                audit("theme_apply", str(exc), "warning")

        def _enable_drag_and_drop(self, widget) -> None:
            """Accept local file/folder drops from Caja and other GTK file managers."""
            try:
                targets = [Gtk.TargetEntry.new("text/uri-list", 0, 0)]
                widget.drag_dest_set(Gtk.DestDefaults.ALL, targets, Gdk.DragAction.COPY)
                widget.connect("drag-data-received", self._on_drag_data_received)
            except Exception as exc:
                audit("drag_drop_enable", str(exc), "warning")

        def _paths_from_drag_selection(self, selection) -> list[Path]:
            paths: list[Path] = []
            try:
                uris = list(selection.get_uris() or [])
            except Exception:
                uris = []
            if not uris:
                try:
                    text = selection.get_text() or ""
                    uris = [line.strip() for line in str(text).splitlines() if line.strip()]
                except Exception:
                    uris = []
            for uri in uris:
                try:
                    parsed = urlparse(str(uri))
                    if parsed.scheme == "file":
                        raw_path = unquote(parsed.path or "")
                    elif parsed.scheme == "":
                        raw_path = str(uri)
                    else:
                        continue
                    if not raw_path:
                        continue
                    p = Path(os.path.expanduser(raw_path))
                    if p.exists():
                        paths.append(p)
                except Exception as exc:
                    audit("drag_drop_uri_parse", f"{uri}: {exc}", "warning")
            # Preserve order but drop duplicates.
            seen: set[str] = set()
            unique: list[Path] = []
            for p in paths:
                key = str(p.resolve()) if p.exists() else str(p)
                if key in seen:
                    continue
                seen.add(key)
                unique.append(p)
            return unique

        def _open_dropped_paths(self, paths: list[Path]) -> bool:
            items: List[MediaItem] = []
            rejected = 0
            for p in paths:
                try:
                    if p.is_dir():
                        items.extend(scan_folder(str(p)))
                    elif p.is_file() and is_media_path(str(p)):
                        items.append(MediaItem(path=str(p), title=p.stem, media_type=classify_media_path(str(p)), source="drag-and-drop"))
                    else:
                        rejected += 1
                except Exception as exc:
                    rejected += 1
                    audit("drag_drop_path", f"{p}: {exc}", "warning")
            if not items:
                self._set_status("Drop ignored: no supported audio/video/eBook media found.")
                return False
            added = self._append_items(items, add_to_queue=True)
            play_index = added[0] if added else self.queue_indices[-1] if self.queue_indices else -1
            if play_index >= 0:
                self._play_index(play_index)
                self._menu_set_page(1)
            self._set_status(f"Dropped {len(items)} media item/s into the player. Added {len(added)} new catalogue item/s; rejected {rejected} unsupported path/s.")
            audit("drag_drop_open", f"items={len(items)} added={len(added)} rejected={rejected}")
            return True

        def _on_drag_data_received(self, widget, context, x, y, selection, info, timestamp) -> None:
            ok = False
            try:
                paths = self._paths_from_drag_selection(selection)
                ok = self._open_dropped_paths(paths)
            except Exception as exc:
                audit("drag_drop_received", str(exc), "error")
                self._set_status(f"Drop failed safely: {exc}")
                ok = False
            try:
                Gtk.drag_finish(context, ok, False, timestamp)
            except Exception:
                pass

        def _default_window_size_for_screen(self) -> tuple[int, int]:
            """Return a conservative default that fits under MATE top/bottom panels.

            v1.0.0 keeps the v0.5.27 fit guard and the taller default height after live SentinelOS feedback: the old
            catalogue/sidebar requisition could make Marco create a window taller
            than the usable desktop and difficult to resize.  Use a taller default for normal playback comfort while still clamping under small MATE desktops.
            """
            width, height = 900, 620
            try:
                screen = Gdk.Screen.get_default()
                if screen is not None:
                    sw = int(screen.get_width())
                    sh = int(screen.get_height())
                    width = min(width, max(620, sw - 180))
                    height = min(height, max(460, sh - 180))
            except Exception as exc:
                audit("window_fit_screen_probe", str(exc), "warning")
            return int(width), int(height)

        def _apply_window_fit_guard(self) -> None:
            """Keep the default window resizable and within the visible desktop."""
            if self.window is None:
                return
            try:
                width, height = self._default_window_size_for_screen()
                self.window.set_resizable(True)
                self.window.set_size_request(360, 280)
                self.window.resize(width, height)
                audit("window_fit_guard", f"default={width}x{height} min=360x280 resizable=true taller_v1=true")
            except Exception as exc:
                audit("window_fit_guard", str(exc), "warning")

        def _build_ui(self) -> None:
            self.window = Gtk.ApplicationWindow(application=self)
            self.window.set_title(f"{APP_NAME} v{VERSION}")
            # v1.0.0: hard fit guard for SentinelOS/MATE panels with taller default height.  The old
            # Library/sidebar requisition could make Marco create a window taller
            # than the visible desktop.  Keep a compact default and a tiny forced
            # minimum; sidebar/page content scrolls instead of forcing the shell.
            default_width, default_height = self._default_window_size_for_screen()
            self.window.set_default_size(default_width, default_height)
            self.window.set_size_request(360, 280)
            self.window.set_resizable(True)
            self.window.connect("destroy", self._on_destroy)
            self.window.connect("key-press-event", self._on_key_press)
            if self.drag_drop_enabled:
                self._enable_drag_and_drop(self.window)

            root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=3)
            root.set_border_width(4)
            root.get_style_context().add_class("sentinel-root")
            self.window.add(root)

            menu_bar = self._build_top_menu()
            root.pack_start(menu_bar, False, False, 0)

            hero = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
            hero.set_name("sentinelHero")
            hero.set_border_width(2)
            root.pack_start(hero, False, False, 0)
            hero_icon = Gtk.Label(label="▤🛡")
            hero_icon.set_name("sentinelHeroIcon")
            hero.pack_start(hero_icon, False, False, 0)
            hero_text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=3)
            hero.pack_start(hero_text, True, True, 0)
            hero_title = Gtk.Label(label="S E N T I N E L   M E D I A   P L A Y E R")
            hero_title.set_name("sentinelHeroTitle")
            hero_title.set_xalign(0)
            hero_title.set_line_wrap(True)
            hero_title.set_max_width_chars(36)
            hero_text.pack_start(hero_title, False, False, 0)
            hero_subtitle = Gtk.Label(label="Simple local player • file-grid Library • local playback")
            hero_subtitle.set_name("sentinelHeroSubtitle")
            hero_subtitle.set_xalign(0)
            hero_subtitle.set_line_wrap(True)
            hero_subtitle.set_max_width_chars(48)
            hero_text.pack_start(hero_subtitle, False, False, 0)

            # v0.5.14: Sentinel Jobs parity shell. Navigation has a left
            # command sidebar while the player still reflects only the Index
            # file-grid Library and does not mutate Media Index.

            # Real playback queue model.  The file-grid Library lives in
            # self.items and the Library board.  This tree intentionally contains
            # only user-queued items / the explicit play queue.
            self.store = Gtk.ListStore(str, str, str, str, str)
            self.queue_store = self.store
            self.tree = Gtk.TreeView(model=self.queue_store)
            self.queue_tree = self.tree
            self.tree.set_headers_visible(True)
            self.tree.connect("row-activated", self._on_row_activated)
            for idx, (heading, width) in enumerate((("#", 36), ("Title", 180), ("Type", 62), ("Source", 120), ("Path", 240))):
                renderer = Gtk.CellRendererText()
                renderer.set_property("ellipsize", 3)
                column = Gtk.TreeViewColumn(heading, renderer, text=idx)
                column.set_resizable(True)
                column.set_min_width(40)
                column.set_fixed_width(width)
                self.tree.append_column(column)

            right_notebook = Gtk.Notebook()
            right_notebook.set_name("sentinelWorkspace")
            right_notebook.set_show_tabs(False)
            right_notebook.set_show_border(False)
            self.right_notebook = right_notebook
            main_shell = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
            root.pack_start(main_shell, True, True, 0)
            sidebar_scroll = Gtk.ScrolledWindow()
            sidebar_scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
            sidebar_scroll.set_shadow_type(Gtk.ShadowType.NONE)
            sidebar_scroll.set_size_request(132, 1)
            try:
                sidebar_scroll.set_min_content_width(132)
                sidebar_scroll.set_min_content_height(1)
                sidebar_scroll.set_overlay_scrolling(False)
            except Exception:
                pass
            sidebar = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=3)
            sidebar.set_name("sentinelSidebar")
            sidebar.set_size_request(128, -1)
            try:
                sidebar_scroll.add_with_viewport(sidebar)
            except Exception:
                sidebar_scroll.add(sidebar)
            main_shell.pack_start(sidebar_scroll, False, False, 0)
            for label, page in [("Library", 0), ("Now Playing", 1), ("Queue", 2), ("Nerd Stats", 3), ("AEGIS", 4)]:
                btn = Gtk.Button(label=label)
                btn.set_name("sentinelSidebarButton")
                btn.connect("clicked", lambda _b, p=page: self._menu_set_page(p))
                sidebar.pack_start(btn, False, False, 0)

            continue_nav = Gtk.Button(label="Continue Last")
            continue_nav.set_name("sentinelQuickButton")
            continue_nav.set_tooltip_text("Resume the last video/audio item from the saved playback position")
            continue_nav.connect("clicked", self._on_continue_last)
            sidebar.pack_start(continue_nav, False, False, 3)
            self.continue_last_button = continue_nav

            sidebar_sep = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            sidebar.pack_start(sidebar_sep, False, False, 2)
            for label, category in [("Movies", "Movies"), ("TV Shows", "TV Shows / Episodes"), ("Music", "Music"), ("eBooks", "eBooks")]:
                btn = Gtk.Button(label=label)
                btn.set_name("sentinelSidebarButton")
                btn.set_tooltip_text(f"Show {label} from the local Library file grid")
                btn.connect("clicked", lambda _b, c=category: self._menu_show_library_category(c))
                sidebar.pack_start(btn, False, False, 0)

            refresh_nav = Gtk.Button(label="Refresh Library")
            refresh_nav.set_name("sentinelQuickButton")
            refresh_nav.set_tooltip_text("Rescan only ~/Videos/Movies, ~/Videos/TV Shows, ~/Music, and ~/Documents/eBooks")
            refresh_nav.connect("clicked", self._on_refresh_simple_library)
            sidebar.pack_start(refresh_nav, False, False, 4)
            self.retrieve_media_index_button = refresh_nav

            load_more_nav = Gtk.Button(label="Load More")
            load_more_nav.set_name("sentinelSidebarButton")
            load_more_nav.set_tooltip_text("Render the next page of file-grid items without rescanning")
            load_more_nav.connect("clicked", self._on_load_more_library)
            sidebar.pack_start(load_more_nav, False, False, 0)
            self.load_more_button = load_more_nav

            # Poster-database workflow is no longer a primary sidebar action in
            # simple-player mode; keep it in menus/CLI so the left rail fits.
            main_shell.pack_start(right_notebook, True, True, 0)

            library_page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
            library_page.set_border_width(4)
            right_notebook.append_page(library_page, Gtk.Label(label="Library"))

            # File-grid Library only: no catalogue landing page. Navigation and
            # refresh actions live in the left command sidebar; this page scans only approved user folders.
            if self.library_search_enabled:
                search_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
                search_label = Gtk.Label(label="Find")
                search_label.set_name("sentinelSearchLabel")
                search_label.set_xalign(0)
                search_row.pack_start(search_label, False, False, 0)
                self.library_search_entry = Gtk.SearchEntry()
                self.library_search_entry.set_name("sentinelSearchEntry")
                self.library_search_entry.set_placeholder_text("Search file name, folder, type, or path…")
                self.library_search_entry.connect("search-changed", self._on_library_search_changed)
                self.library_search_entry.connect("activate", self._on_library_search_activate)
                search_row.pack_start(self.library_search_entry, True, True, 0)
                clear_search = Gtk.Button(label="Clear")
                clear_search.set_tooltip_text("Clear Library search / Escape")
                clear_search.connect("clicked", self._on_clear_library_search)
                search_row.pack_start(clear_search, False, False, 0)
                library_page.pack_start(search_row, False, False, 0)

            library_scroll = Gtk.ScrolledWindow()
            library_scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
            self.library_notebook = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
            self.library_notebook.set_border_width(2)
            if self.drag_drop_enabled:
                self._enable_drag_and_drop(self.library_notebook)
            library_scroll.add(self.library_notebook)
            library_page.pack_start(library_scroll, True, True, 0)
            self.library_status_label = Gtk.Label(label="Library file grid is available from the sidebar/menu. It scans only Videos/Movies, Videos/TV Shows, Music, and Documents/eBooks when opened.")
            self.library_status_label.set_name("sentinelLibraryStatus")
            self.library_status_label.set_xalign(0)
            library_page.pack_start(self.library_status_label, False, False, 0)

            player_page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=3)
            player_page.set_border_width(3)
            right_notebook.append_page(player_page, Gtk.Label(label="Now Playing"))
            video_frame = Gtk.Frame()
            video_frame.set_name("sentinelVideoFrame")
            video_frame.set_shadow_type(Gtk.ShadowType.NONE)
            video_frame.set_size_request(240, 135)
            video_frame.set_hexpand(True)
            video_frame.set_vexpand(True)
            player_page.pack_start(video_frame, True, True, 0)

            self.video_event_box = Gtk.EventBox()
            self.video_event_box.set_name("sentinelVideoSurface")
            self._configure_gesture_surface(self.video_event_box, "embedded")
            if self.drag_drop_enabled:
                self._enable_drag_and_drop(self.video_event_box)
            video_frame.add(self.video_event_box)

            self.video_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
            self.video_box.set_hexpand(True)
            self.video_box.set_vexpand(True)
            self.video_box.set_halign(Gtk.Align.FILL)
            self.video_box.set_valign(Gtk.Align.FILL)
            self.video_box.set_border_width(0)
            self.video_event_box.add(self.video_box)
            placeholder = Gtk.Label(label="Ready to play.\n\nDrag and drop a video or audio file here, open a file, or press Continue Last.\nLibrary is available from the sidebar/menu and loads on demand so the player stays snappy.")
            placeholder.set_name("sentinelDropHint")
            placeholder.set_justify(Gtk.Justification.CENTER)
            self.video_placeholder = placeholder
            self.video_box.pack_start(placeholder, True, True, 0)

            controls = Gtk.FlowBox()
            controls.set_name("sentinelCompactControls")
            controls.set_selection_mode(Gtk.SelectionMode.NONE)
            controls.set_max_children_per_line(6)
            controls.set_min_children_per_line(1)
            controls.set_row_spacing(2)
            controls.set_column_spacing(3)
            controls.set_homogeneous(False)
            player_page.pack_start(controls, False, False, 0)

            for label, handler, tooltip in [
                ("⏮", self._on_previous, "Previous item / media previous key"),
                (f"← {self.skip_step_seconds}s", self._on_skip_back, "Skip back 10 seconds / left arrow"),
                ("▶ / ⏸", self._on_play_pause, "Play or pause / space / media play key"),
                ("■", self._on_stop, "Stop / media stop key"),
                (f"{self.skip_step_seconds}s →", self._on_skip_forward, "Fast forward 10 seconds / right arrow"),
                ("⏭", self._on_next, "Next item / media next key"),
                ("Skip Intro", self._on_skip_intro, "Skip intro marker, or manually skip forward if no marker exists"),
                ("Skip Credits", self._on_skip_credits, "Skip credits marker or move to next item"),
                ("Fullscreen", self._on_fullscreen_toggle, "Toggle VLC-style video-only fullscreen / F11 / Escape exits"),
                ("Subtitles", self._on_load_subtitles, "Load an external subtitle file for the current video"),
                ("No Subs", self._on_remove_subtitles, "Disable/remove subtitles from the current playback without deleting subtitle files"),
            ]:
                button = Gtk.Button(label=label)
                button.set_tooltip_text(tooltip)
                button.connect("clicked", handler)
                controls.add(button)
                if "▶" in label:
                    self.play_button = button
                if label == "Fullscreen":
                    self.fullscreen_button = button

            volume_label = Gtk.Label(label="Volume")
            volume_label.set_name("sentinelCompactLabel")
            controls.add(volume_label)
            self.volume_scale = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 0, 100, 1)
            self.volume_scale.set_value(80)
            self.volume_scale.set_size_request(80, -1)
            self.volume_scale.connect("value-changed", self._on_volume_changed)
            controls.add(self.volume_scale)

            skip_row = Gtk.FlowBox()
            skip_row.set_name("sentinelCompactControls")
            skip_row.set_selection_mode(Gtk.SelectionMode.NONE)
            skip_row.set_max_children_per_line(2)
            skip_row.set_min_children_per_line(1)
            skip_row.set_row_spacing(2)
            skip_row.set_column_spacing(3)
            player_page.pack_start(skip_row, False, False, 0)
            self.auto_intro_check = Gtk.CheckButton(label="Auto Intro")
            self.auto_intro_check.set_name("sentinelCompactCheck")
            self.auto_intro_check.set_active(bool(self.config.get("auto_skip_intro", True)))
            self.auto_intro_check.connect("toggled", self._on_auto_intro_toggled)
            skip_row.add(self.auto_intro_check)

            self.subtitle_status_label = Gtk.Label(label="Subtitles: auto")
            self.subtitle_status_label.set_name("sentinelMarkerLabel")
            self.subtitle_status_label.set_xalign(0)
            self.subtitle_status_label.set_line_wrap(True)
            self.subtitle_status_label.set_max_width_chars(22)
            skip_row.add(self.subtitle_status_label)

            self.marker_label = Gtk.Label(label="Markers: none loaded")
            self.marker_label.set_name("sentinelMarkerLabel")
            self.marker_label.set_xalign(0)
            self.marker_label.set_line_wrap(True)
            self.marker_label.set_max_width_chars(34)
            skip_row.add(self.marker_label)

            position_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
            player_page.pack_start(position_row, False, False, 0)
            self.position_scale = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 0, 100, 1)
            self.position_scale.set_draw_value(False)
            self.position_scale.connect("button-press-event", self._on_seek_press)
            self.position_scale.connect("button-release-event", self._on_seek_release)
            position_row.pack_start(self.position_scale, True, True, 0)
            self.position_time_label = Gtk.Label(label="Played 00:00 · Left --:-- · Total --:--")
            self.position_time_label.set_name("sentinelTimeLabel")
            self.position_time_label.set_xalign(1)
            self.position_time_label.set_size_request(120, -1)
            self.position_time_label.set_max_width_chars(18)
            position_row.pack_start(self.position_time_label, False, False, 0)

            # v0.5.6: remove the long hotkey hint from Now Playing to keep the player surface clean.

            queue_page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
            queue_page.set_border_width(4)
            right_notebook.append_page(queue_page, Gtk.Label(label="Queue"))
            queue_header = Gtk.Label(label="Playback Queue · play-next list")
            queue_header.set_name("sentinelLibraryHeader")
            queue_header.set_xalign(0)
            queue_page.pack_start(queue_header, False, False, 0)
            queue_help = Gtk.Label(label="This is the real play queue only. It no longer mirrors every indexed media file. Use + Queue from the Library board, Open Files/Open Folder, or Queue Current to add items here.")
            queue_help.set_xalign(0)
            queue_help.set_line_wrap(True)
            queue_page.pack_start(queue_help, False, False, 0)
            queue_scroll = Gtk.ScrolledWindow()
            queue_scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
            if self.tree is not None:
                queue_scroll.add(self.tree)
            queue_page.pack_start(queue_scroll, True, True, 0)
            queue_buttons = Gtk.FlowBox()
            queue_buttons.set_selection_mode(Gtk.SelectionMode.NONE)
            queue_buttons.set_max_children_per_line(4)
            queue_buttons.set_min_children_per_line(1)
            queue_buttons.set_row_spacing(2)
            queue_buttons.set_column_spacing(3)
            queue_page.pack_start(queue_buttons, False, False, 0)
            for label, handler in [
                ("Play Queue Item", self._on_play_selected_from_queue),
                ("Queue Current", self._on_queue_current),
                ("Remove Selected", self._on_remove_selected_from_queue),
                ("Clear Queue", self._on_clear_queue),
                ("Open Files", self._on_open_files),
                ("Open Folder", self._on_open_folder),
            ]:
                button = Gtk.Button(label=label)
                button.connect("clicked", handler)
                queue_buttons.add(button)

            self.status_label = Gtk.Label(label="Ready. Drop a video/audio file, open files, or use the simple Library grid when needed.")
            self.status_label.set_name("sentinelStatusLabel")
            self.status_label.set_xalign(0)
            self.status_label.set_line_wrap(True)
            root.pack_start(self.status_label, False, False, 0)

            nerd_page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
            nerd_page.set_border_width(6)
            right_notebook.append_page(nerd_page, Gtk.Label(label="Nerd Stats"))

            nerd_controls = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            nerd_page.pack_start(nerd_controls, False, False, 0)
            nerd_btn = Gtk.Button(label="Refresh Current Nerd Stats")
            nerd_btn.connect("clicked", self._on_refresh_nerd_stats)
            nerd_controls.pack_start(nerd_btn, False, False, 0)
            online_btn = Gtk.Button(label="Fallback Online Lookup")
            online_btn.connect("clicked", self._on_online_nerd_stats)
            nerd_controls.pack_start(online_btn, False, False, 0)
            retrieve_btn = Gtk.Button(label="Retrieve Art")
            retrieve_btn.set_tooltip_text("Manually retrieve/recover cover art for the current item. Heavy artwork recovery runs only when you press this button.")
            retrieve_btn.connect("clicked", self._on_retrieve_art_current)
            nerd_controls.pack_start(retrieve_btn, False, False, 0)
            self.online_stats_check = Gtk.CheckButton(label="Allow Player fallback online lookup by default")
            self.online_stats_check.set_active(bool(self.config.get("nerd_stats_online_lookup", False)))
            self.online_stats_check.connect("toggled", self._on_online_default_toggled)
            nerd_controls.pack_start(self.online_stats_check, False, False, 0)

            nerd_help = Gtk.Label(label="Nerd Stats reads Sentinel Media Index enriched metadata first. Player-side online lookup is fallback/manual only; update the Media Index to refresh default metadata.")
            nerd_help.set_xalign(0)
            nerd_help.set_line_wrap(True)
            nerd_page.pack_start(nerd_help, False, False, 0)

            nerd_hero = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
            nerd_hero.set_name("sentinelNerdHero")
            nerd_hero.set_border_width(8)
            nerd_page.pack_start(nerd_hero, False, False, 0)
            self.nerd_title_label = Gtk.Label(label="No media selected")
            self.nerd_title_label.set_name("sentinelNerdTitle")
            self.nerd_title_label.set_xalign(0)
            self.nerd_title_label.set_use_markup(True)
            nerd_hero.pack_start(self.nerd_title_label, False, False, 0)
            self.nerd_subtitle_label = Gtk.Label(label="Select a Library file or play a file to populate Nerd Stats.")
            self.nerd_subtitle_label.set_name("sentinelNerdSubtle")
            self.nerd_subtitle_label.set_xalign(0)
            self.nerd_subtitle_label.set_line_wrap(True)
            nerd_hero.pack_start(self.nerd_subtitle_label, False, False, 0)

            self.nerd_grid = Gtk.Grid()
            self.nerd_grid.set_row_spacing(6)
            self.nerd_grid.set_column_spacing(14)
            nerd_page.pack_start(self.nerd_grid, False, False, 0)

            expander = Gtk.Expander(label="Detailed metadata / raw JSON")
            expander.set_expanded(True)
            self.nerd_text = Gtk.TextView()
            self.nerd_text.set_editable(False)
            self.nerd_text.set_monospace(False)
            self.nerd_text.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
            nerd_scroll = Gtk.ScrolledWindow()
            nerd_scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
            nerd_scroll.add(self.nerd_text)
            expander.add(nerd_scroll)
            nerd_page.pack_start(expander, True, True, 0)

            aegis_page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
            aegis_page.set_border_width(6)
            right_notebook.append_page(aegis_page, Gtk.Label(label="AEGIS"))
            self.aegis_text = Gtk.TextView()
            self.aegis_text.set_editable(False)
            self.aegis_text.set_monospace(True)
            aegis_scroll = Gtk.ScrolledWindow()
            aegis_scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
            aegis_scroll.add(self.aegis_text)
            aegis_page.pack_start(aegis_scroll, True, True, 0)
            self._set_text(self.aegis_text, json.dumps({"version": VERSION, "config": self.config, "desktop_controls": self._desktop_controls_profile(), "ui": self._ui_profile(), "resume": self._resume_profile(), "metadata_authority": "Sentinel Media Index", "player_online_lookup_policy": "fallback/manual only"}, indent=2, sort_keys=True))

        def _desktop_controls_profile(self) -> dict:
            return {
                "theme": "AEGIS Dark / Sentinel Gold desktop suite fit",
                "hotkeys": {
                    "Ctrl+Q": "close app",
                    "Space": "play/pause",
                    "Left": f"skip back {self.skip_step_seconds} seconds",
                    "Right": f"fast forward {self.skip_step_seconds} seconds",
                    "Up": "volume up",
                    "Down": "volume down",
                    "F11": "toggle video-only fullscreen",
                    "Escape": "exit video-only fullscreen",
                    "Drag and Drop": "drop local files or folders onto the player window/video surface to queue and play",
                },
                "media_keys": ["XF86AudioPlay", "XF86AudioPause", "XF86AudioStop", "XF86AudioPrev", "XF86AudioNext", "XF86AudioRewind", "XF86AudioForward"],
                "video_gestures": {
                    "double_tap": "toggle video-only fullscreen / restore normal view",
                    "ten_second_seek": "use arrow buttons, keyboard Left/Right, or Fn rewind/forward",
                    "gesture_surface": "input-only / non-painting; does not overlay or obscure video",
                    "conflict_policy": "fullscreen double-tap takes priority over old edge double-tap seek",
                },
                "time_display": "played / left / total",
                "fullscreen_mode": "video-only fullscreen window; main media-player shell remains normal",
                "video_surface_overlay_fix": True,
                "ten_second_seek_hotfix": {"enabled": True, "engine": self.seek_engine},
                "library_landing": {"default_source": "Sentinel Media Index", "auto_load_on_startup": True,
        "startup_render_policy": "background metadata load only; no catalogue tile render until Library is opened",
        "simple_player_startup": bool(load_config().get("simple_player_startup", True)),
        "catalogue_render_on_demand": bool(load_config().get("catalogue_render_on_demand", True)), "catalogue_background_load": self.catalogue_background_load, "catalogue_lazy_render": self.catalogue_lazy_render, "catalogue_tile_batch_size": self.catalogue_tile_batch_size, "catalogue_startup_display_limit": self.catalogue_startup_display_limit, "catalogue_deferred_full_render": self.catalogue_deferred_full_render, "paged_board": True, "load_more_button": True, "catalogue_fast_contract_only": self.catalogue_fast_contract_only, "library_quick_search": bool(getattr(self, "library_search_enabled", True)), "library_quick_search_shortcut": "Ctrl+F", "drag_drop_enabled": self.drag_drop_enabled, "continue_last": True, "resume_playback_enabled": self.resume_playback_enabled, "slow_raw_discovery_default": False, "manual_load_button": "reload/append", "style": "categorized thumbnail board", "theme_parity": "Sentinel Jobs command dashboard with left command sidebar", "catalogue_filter": "system/cache/incomplete media excluded", "file_double_click": True, "header_quick_buttons": [], "workspace_quick_buttons": [], "header_quick_buttons_removed": True, "side_file_bar": "removed", "queue_location": "Queue workspace via top menu (explicit play queue only)", "top_menu_bar": True, "visible_tabs": False, "real_queue_model": True, "audio_tile_playback_fix": True, "artwork_sources": ["Media Index artwork fields", "local poster database folders", "sidecar files", "Caja/MATE thumbnail cache", "manual Retrieve Art", "local artwork audit", "system fallback icons"]},
            }


        def _menu_item(self, label: str, handler, accel: str | None = None):
            item = Gtk.MenuItem(label=label if accel is None else f"{label}\t{accel}")
            item.connect("activate", handler)
            return item

        def _check_menu_item(self, label: str, active: bool, handler):
            item = Gtk.CheckMenuItem(label=label)
            item.set_active(bool(active))
            item.connect("toggled", handler)
            return item

        def _build_top_menu(self):
            menu_bar = Gtk.MenuBar()
            menu_bar.set_name("sentinelTopMenu")

            def add_menu(title: str, entries):
                top = Gtk.MenuItem(label=title)
                menu = Gtk.Menu()
                top.set_submenu(menu)
                for entry in entries:
                    if entry is None:
                        menu.append(Gtk.SeparatorMenuItem())
                    else:
                        menu.append(entry)
                menu_bar.append(top)
                return top

            add_menu("File", [
                self._menu_item("Open Files…", self._on_open_files),
                self._menu_item("Open Folder…", self._on_open_folder),
                self._menu_item("Refresh Library Grid", self._on_load_media_index),
                self._menu_item("Refresh List", self._on_retrieve_media_index),
                None,
                self._menu_item("Set Sentinel Media Player as Default", self._on_menu_set_file_defaults),
                None,
                self._menu_item("Quit", lambda *_: self.quit(), "Ctrl+Q"),
            ])

            add_menu("Playback", [
                self._menu_item("Continue Last", self._on_continue_last),
                None,
                self._menu_item("Play / Pause", self._on_play_pause, "Space"),
                self._menu_item("Stop", self._on_stop),
                None,
                self._menu_item(f"Skip Back {self.skip_step_seconds}s", self._on_skip_back, "Left"),
                self._menu_item(f"Fast Forward {self.skip_step_seconds}s", self._on_skip_forward, "Right"),
                self._menu_item("Previous Item", self._on_previous),
                self._menu_item("Next Item", self._on_next),
                None,
                self._menu_item("Skip Intro", self._on_skip_intro),
                self._menu_item("Skip Credits", self._on_skip_credits),
                None,
                self._menu_item("Toggle Video Fullscreen", self._on_fullscreen_toggle, "F11"),
                None,
                self._menu_item("Load External Subtitles…", self._on_load_subtitles),
                self._menu_item("Remove / Disable Subtitles", self._on_remove_subtitles),
            ])

            add_menu("Library", [
                self._menu_item("Show All Library", lambda *_: self._menu_show_library_category(None)),
                self._menu_item("Focus Search", self._on_focus_library_search),
                self._menu_item("Clear Search", self._on_clear_library_search),
                None,
                self._menu_item("Movies", lambda *_: self._menu_show_library_category("Movies")),
                self._menu_item("TV Shows / Episodes", lambda *_: self._menu_show_library_category("TV Shows / Episodes")),
                self._menu_item("Music", lambda *_: self._menu_show_library_category("Music")),
                self._menu_item("eBooks", lambda *_: self._menu_show_library_category("eBooks")),
                None,
                self._menu_item("Refresh Library Grid", self._on_refresh_simple_library),
                self._menu_item("Load More Library Files", self._on_load_more_library),
                self._menu_item("Clear Library Grid", self._on_clear_library),
            ])

            add_menu("View", [
                self._menu_item("Library Workspace", lambda *_: self._menu_set_page(0)),
                self._menu_item("Now Playing Workspace", lambda *_: self._menu_set_page(1)),
                self._menu_item("Playback Queue Workspace", lambda *_: self._menu_set_page(2)),
                self._menu_item("Nerd Stats Workspace", lambda *_: self._menu_set_page(3)),
                self._menu_item("AEGIS Workspace", lambda *_: self._menu_set_page(4)),
                None,
                self._menu_item("Video Fullscreen", self._on_fullscreen_toggle, "F11"),
            ])

            self.auto_intro_menu_item = self._check_menu_item(
                "Auto Skip Intro when markers exist",
                bool(self.config.get("auto_skip_intro", True)),
                self._on_auto_intro_menu_toggled,
            )
            self.online_stats_menu_item = self._check_menu_item(
                "Allow Player fallback online lookup by default",
                bool(self.config.get("nerd_stats_online_lookup", False)),
                self._on_online_stats_menu_toggled,
            )
            self.media_index_default_menu_item = self._check_menu_item(
                "Load Library file grid on startup",
                bool(self.config.get("media_index_default_catalogue", True)),
                self._on_media_index_default_toggled,
            )
            self.resume_menu_item = self._check_menu_item(
                "Remember playback position",
                self.resume_playback_enabled,
                self._on_resume_playback_toggled,
            )
            self.double_tap_menu_item = self._check_menu_item(
                "Double-tap video toggles fullscreen",
                self.video_double_tap_action == "fullscreen_toggle",
                self._on_double_tap_fullscreen_toggled,
            )
            self.subtitle_menu_item = self._check_menu_item(
                "Subtitles enabled by default",
                self.subtitles_enabled,
                self._on_subtitles_enabled_menu_toggled,
            )
            self.sidecar_subtitle_menu_item = self._check_menu_item(
                "Auto-detect sidecar subtitle files",
                self.detect_sidecar_subtitles,
                self._on_sidecar_subtitles_menu_toggled,
            )
            self.subtitle_safe_mode_menu_item = self._check_menu_item(
                "Safe subtitle overlay mode",
                self.subtitle_overlay_safe_mode,
                self._on_subtitle_safe_mode_toggled,
            )
            add_menu("Settings", [
                self.auto_intro_menu_item,
                self.online_stats_menu_item,
                self.media_index_default_menu_item,
                self.resume_menu_item,
                self.double_tap_menu_item,
                self.subtitle_menu_item,
                self.sidecar_subtitle_menu_item,
                self.subtitle_safe_mode_menu_item,
                None,
                self._menu_item("File Association Status", self._on_file_assoc_status),
                self._menu_item("Desktop Controls Status", self._on_desktop_controls_status),
                self._menu_item("Supported Formats / Codec Note", self._on_supported_formats_info),
                self._menu_item("Metadata Authority Status", self._on_metadata_authority_status),
                self._menu_item("Online Artwork Retrieval Status", self._on_online_art_profile_dialog),
                self._menu_item("Add Local Poster Database…", self._on_add_poster_database),
                self._menu_item("Local Poster Database Status", self._on_poster_database_status),
            ])

            add_menu("Nerd Stats", [
                self._menu_item("Show Nerd Stats Workspace", lambda *_: self._menu_set_page(3)),
                self._menu_item("Refresh Current Nerd Stats", self._on_refresh_nerd_stats),
                self._menu_item("Audit Current Artwork", self._on_artwork_audit_current),
                self._menu_item("Retrieve Art for Current Item", self._on_retrieve_art_current),
                self._menu_item("Retrieve All Missing Art", self._on_retrieve_all_art),
                self._menu_item("Fallback Online Lookup", self._on_online_nerd_stats),
            ])

            add_menu("AEGIS", [
                self._menu_item("Show AEGIS Workspace", lambda *_: self._menu_set_page(4)),
                self._menu_item("Refresh AEGIS Diagnostics", self._refresh_aegis_view),
                self._menu_item("Show AEGIS Status", self._on_aegis_status_dialog),
                self._menu_item("Show AEGIS Actions", self._on_aegis_actions_dialog),
            ])
            return menu_bar

        def _menu_set_page(self, page: int) -> None:
            if self.right_notebook is not None:
                self.right_notebook.set_current_page(page)
            if page == 0:
                self._ensure_library_rendered()

        def _menu_show_library_category(self, category: Optional[str]) -> None:
            self.library_category_filter = category
            self.library_visible_limit = self.catalogue_startup_display_limit
            self._menu_set_page(0)
            self._ensure_library_rendered(force=True)
            label = category or "All Library"
            self._set_status(f"Showing {label} from the simple Library file grid.")

        def _on_load_more_library(self, _button=None) -> None:
            if self.right_notebook is not None:
                self.right_notebook.set_current_page(0)
            current = int(getattr(self, "library_visible_limit", self.catalogue_startup_display_limit) or self.catalogue_startup_display_limit)
            match_count = self._current_library_match_count()
            target_total = match_count if match_count else (len(self.items) if self.items else current + self.library_page_step)
            self.library_visible_limit = min(target_total, current + int(getattr(self, "library_page_step", 48) or 48))
            self._rebuild_library()
            hidden = max(0, target_total - int(self.library_visible_limit or 0))
            search = self._library_search_query()
            suffix = f" matching '{search}'" if search else ""
            self._set_status(f"Loaded another Library grid page. Showing {self.library_visible_limit}/{target_total} item/s{suffix}; {hidden} still deferred.")

        def _library_search_query(self) -> str:
            return " ".join(str(getattr(self, "library_search_text", "") or "").lower().split())

        def _library_search_blob(self, item: MediaItem) -> str:
            fields = [
                item.title, item.path, item.media_type, item.source, item.duration,
                item.album, item.artist, item.year, item.series, item.season, item.episode,
                item.genre, item.collection, item.description, item.resolution, item.director,
                item.cast, item.creator, item.metadata_source, item.metadata_provider, item.category,
            ]
            return " ".join(str(v or "") for v in fields).lower()

        def _library_item_matches_search(self, item: MediaItem, query: Optional[str] = None) -> bool:
            q = query if query is not None else self._library_search_query()
            if not q:
                return True
            blob = self._library_search_blob(item)
            return all(token in blob for token in q.split())

        def _current_library_match_count(self) -> int:
            query = self._library_search_query()
            if not query:
                return len(self.items)
            total = 0
            for item in self.items:
                try:
                    if self._library_item_matches_search(item, query):
                        total += 1
                except Exception as exc:
                    audit("library_search_count", f"{getattr(item, 'path', '')}: {exc}", "warning")
            return total

        def _on_library_search_changed(self, entry) -> None:
            self.library_search_text = str(entry.get_text() or "")
            self.library_visible_limit = self.catalogue_startup_display_limit
            self._rebuild_library()
            query = self._library_search_query()
            if query:
                self._set_status(f"Library search active: '{query}'. Rendering matched first page only.")
            else:
                self._set_status("Library search cleared. Showing normal file grid.")

        def _on_library_search_activate(self, _entry) -> None:
            match_count = self._current_library_match_count()
            if match_count == 1:
                query = self._library_search_query()
                for idx, item in enumerate(self.items):
                    if self._library_item_matches_search(item, query):
                        self._play_from_library(idx)
                        return
            self._set_status(f"Library search found {match_count} match/es. Select a tile or press Load More if needed.")

        def _on_focus_library_search(self, *_args) -> None:
            if self.right_notebook is not None:
                self.right_notebook.set_current_page(0)
            if self.library_search_entry is not None:
                self.library_search_entry.grab_focus()
                try:
                    self.library_search_entry.select_region(0, -1)
                except Exception:
                    pass
                self._set_status("Library search focused. Type to filter file tiles without scanning again.")

        def _on_clear_library_search(self, *_args) -> None:
            self.library_search_text = ""
            if self.library_search_entry is not None:
                try:
                    if self.library_search_entry.get_text():
                        self.library_search_entry.set_text("")
                        return
                except Exception:
                    pass
            self.library_visible_limit = self.catalogue_startup_display_limit
            self._rebuild_library()
            self._set_status("Library search cleared.")

        def _ensure_library_rendered(self, force: bool = False) -> None:
            """Render the simple file-grid Library only when opened.

            v0.5.25+ removes the catalogue/poster landing model from the Player.
            The Library is now a bounded local file viewer over the approved user
            folders only: ~/Videos/Movies, ~/Videos/TV Shows, ~/Music, and
            ~/Documents/eBooks.  Scanning happens in a background worker so the
            Now Playing surface remains responsive.
            """
            if self.library_notebook is None:
                return
            if self.simple_file_library and (force or not self.simple_library_loaded) and not self.simple_library_loading:
                self._load_simple_library_async(force=force)
                return
            if force or self._library_dirty or not self._library_rendered_once:
                self._rebuild_library()
                self._library_dirty = False
                self._library_rendered_once = True
            elif self.library_status_label is not None:
                self.library_status_label.set_text(f"Library grid ready: {len(self.items)} file/s from approved folders only.")

        def _replace_catalogue_items(self, items: List[MediaItem], files: List[Path], render: bool = True) -> None:
            current_item = self.items[self.current_index] if 0 <= self.current_index < len(self.items) else None
            current_path = current_item.path if current_item is not None else ""
            queued_existing = [self.items[i] for i in self.queue_indices if 0 <= i < len(self.items)]
            queued_paths = [i.path for i in queued_existing]
            merged_items = list(items)
            known_paths = {i.path for i in merged_items}
            # Background catalogue refresh must not make a currently-open local
            # file disappear just because it is not part of Media Index yet.
            for preserve in [current_item] + queued_existing:
                if preserve is not None and preserve.path and preserve.path not in known_paths:
                    merged_items.insert(0, preserve)
                    known_paths.add(preserve.path)
            self.items = merged_items
            self.queue_indices = []
            self.current_index = -1
            path_to_index = {item.path: idx for idx, item in enumerate(self.items)}
            if current_path and current_path in path_to_index:
                self.current_index = path_to_index[current_path]
            for qpath in queued_paths:
                if qpath in path_to_index:
                    self.queue_indices.append(path_to_index[qpath])
            # v0.5.19: do not expand the first render to the whole catalogue.
            # Keep the first page small; the sidebar/menu Load More action renders
            # further pages on demand without rescanning the Media Index.
            self.library_visible_limit = min(len(self.items), self.catalogue_startup_display_limit) if self.items else self.catalogue_startup_display_limit
            self._refresh_queue_view()
            self._library_dirty = True
            if render:
                self._ensure_library_rendered(force=True)
            else:
                if self.library_status_label is not None:
                    self.library_status_label.set_text(f"Catalogue metadata ready in background: {len(self.items)} item/s. Open Library to render poster tiles.")
            hidden = max(0, len(self.items) - int(self.library_visible_limit or 0))
            extra = f" First Library page will show {self.library_visible_limit}; {hidden} deferred behind Load More." if hidden else ""
            mode = "rendered" if render else "loaded in background without rendering tiles"
            self._set_status(f"Refreshed catalogue from Media Index: {mode}; {len(self.items)} file-grid item/s from {len(files)} file/s. Queue preserved where paths still exist; playback surface preserved if current file still exists.{extra}")

        def _on_retrieve_media_index(self, _button=None) -> None:
            if self.retrieve_media_index_in_progress:
                self._set_status("Refresh List is already running.")
                return
            if shutil.which("sentinel-media-index") is None:
                self._set_status("sentinel-media-index command not found. Install Sentinel Media Index, then retry.")
                return
            self.retrieve_media_index_in_progress = True
            if self.retrieve_media_index_button is not None:
                self.retrieve_media_index_button.set_sensitive(False)
            self._set_status("Retrieving Media Index: scanning exact default files, writing fast catalogue, then refreshing the file-grid view...")

            def worker() -> None:
                cmd = ["sentinel-media-index", "--scan-default-files", "--json"]
                try:
                    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=600)
                    if result.returncode != 0:
                        GLib.idle_add(self._finish_retrieve_media_index, False, [], [], result.stderr.strip() or result.stdout.strip() or f"exit {result.returncode}")
                        return
                    items, files = load_media_index(fast_only=True)
                    GLib.idle_add(self._finish_retrieve_media_index, True, items, files, result.stdout.strip())
                except Exception as exc:
                    GLib.idle_add(self._finish_retrieve_media_index, False, [], [], str(exc))

            threading.Thread(target=worker, name="sentinel-media-index-retrieve", daemon=True).start()

        def _finish_retrieve_media_index(self, ok: bool, items, files, detail: str = "") -> bool:
            self.retrieve_media_index_in_progress = False
            self.first_start_auto_retrieve_art = bool(self.config.get("first_start_auto_retrieve_art", True))
            self.first_start_auto_retrieve_art_done = bool(self.config.get("first_start_auto_retrieve_art_done", False))
            self.first_start_auto_retrieve_art_scheduled = False
            if self.retrieve_media_index_button is not None:
                self.retrieve_media_index_button.set_sensitive(True)
            if not ok:
                audit("retrieve_media_index", detail, "error")
                self._set_status(f"Refresh List failed: {detail}")
                return False
            self._replace_catalogue_items(items, files, render=True)
            audit("retrieve_media_index", f"items={len(items)} files={len(files)}", "ok")
            return False

        def _show_info_dialog(self, title: str, body: str) -> None:
            dialog = Gtk.MessageDialog(
                transient_for=self.window,
                flags=0,
                message_type=Gtk.MessageType.INFO,
                buttons=Gtk.ButtonsType.OK,
                text=title,
            )
            dialog.format_secondary_text(body)
            dialog.run()
            dialog.destroy()

        def _on_play_selected_from_queue(self, *_args) -> None:
            idx = self._selected_queue_item_index()
            if idx is None:
                self._set_status("No queue item selected.")
                return
            self._play_index(idx)
            self._menu_set_page(1)

        def _on_rename_library_status(self, *_args) -> None:
            """Show Media Index rename workflow without mutating files from the Player."""
            if shutil.which("sentinel-media-index") is None:
                self._show_info_dialog("Clean / Rename Library", "Sentinel Media Index is not installed or not on PATH. Install/update Program 118 first.")
                return
            try:
                result = subprocess.run(["sentinel-media-index", "--rename-status", "--json"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=60)
                body = result.stdout.strip() if result.returncode == 0 else (result.stderr.strip() or result.stdout.strip())
            except Exception as exc:
                body = f"Could not read Media Index rename status: {type(exc).__name__}: {exc}"
            body = (body or "No rename status returned.") + "\n\nWorkflow:\n  1. sentinel-media-index --propose-renames ~/rename_plan.json --json\n  2. Review the plan.\n  3. sentinel-media-index --apply-renames ~/rename_plan.json --execute --confirm RENAME_MEDIA --json\n  4. sentinel-media-index --scan-defaults --json\n  5. Use Refresh List in this player.\n\nThe player never renames files directly."
            self._show_info_dialog("Clean / Rename Library", body)

        def _on_menu_set_file_defaults(self, *_args) -> None:
            self._show_info_dialog(
                "Set as default media player",
                "Run this helper as your normal user if Caja/MATE has not already associated media files:\n\n  sentinel-media-player-set-defaults\n\nThe package desktop launcher already uses Exec=sentinel-media-player %U for double-click file-manager playback.",
            )

        def _normalise_resume_positions(self, raw) -> dict:
            out = {}
            if not isinstance(raw, dict):
                return out
            for key, value in raw.items():
                if not isinstance(value, dict):
                    continue
                try:
                    path = str(value.get("path") or key)
                    if not path:
                        continue
                    out[path] = {
                        "path": path,
                        "title": str(value.get("title") or Path(path).stem),
                        "position": float(value.get("position") or 0.0),
                        "duration": float(value.get("duration") or 0.0),
                        "updated_at": float(value.get("updated_at") or 0.0),
                    }
                except Exception:
                    continue
            return out

        def _resume_profile(self) -> dict:
            last_path = str(self.config.get("last_played_path", "") or "")
            last = self.resume_positions.get(last_path, {}) if last_path else {}
            return {
                "app": APP_NAME,
                "version": VERSION,
                "continue_last_enabled": True,
                "resume_playback_enabled": bool(self.resume_playback_enabled),
                "resume_min_seconds": int(self.resume_min_seconds),
                "resume_near_end_seconds": int(self.resume_near_end_seconds),
                "saved_items": len(self.resume_positions),
                "last_played_path": last_path,
                "last_played_title": last.get("title", ""),
                "last_played_position": last.get("position", 0.0),
                "policy": "Playback position is stored locally in the user config only. It never mutates Sentinel Media Index and never phones home.",
            }

        def _on_resume_playback_toggled(self, item) -> None:
            active = bool(item.get_active())
            self.resume_playback_enabled = active
            self.config["resume_playback_enabled"] = active
            save_config(self.config)
            self._set_status(f"Remember playback position {'enabled' if active else 'disabled'}.")

        def _remember_playback_position(self, force: bool = False) -> None:
            if not bool(getattr(self, "resume_playback_enabled", True)):
                return
            if self.current_index < 0 or self.current_index >= len(self.items):
                return
            item = self.items[self.current_index]
            if item.media_type == "ebook":
                return
            media_path = self._resolve_item_play_path(item)
            if media_path is None or not media_path.is_file():
                return
            now = time.monotonic()
            if not force and now - float(getattr(self, "_last_resume_save_at", 0.0)) < 10.0:
                return
            position, duration = self._query_position_seconds()
            if position is None:
                return
            position = float(position or 0.0)
            duration_value = float(duration or item.duration_seconds() or 0.0)
            key = str(media_path)
            # Do not resume credits/end. If an item is essentially finished, clear
            # its saved point so Continue Last starts cleanly next time.
            if duration_value > 0 and position >= max(0.0, duration_value - float(self.resume_near_end_seconds)):
                if key in self.resume_positions:
                    self.resume_positions.pop(key, None)
                    self.config["resume_positions"] = self.resume_positions
                    self.config["last_played_path"] = key
                    save_config(self.config)
                return
            if position < float(self.resume_min_seconds):
                return
            payload = {
                "path": key,
                "title": item.title,
                "position": round(position, 2),
                "duration": round(duration_value, 2),
                "updated_at": time.time(),
            }
            self.resume_positions[key] = payload
            # Keep the state compact and deterministic.
            ordered = sorted(self.resume_positions.values(), key=lambda row: float(row.get("updated_at") or 0.0), reverse=True)[:100]
            self.resume_positions = {str(row.get("path")): row for row in ordered if row.get("path")}
            self.config["resume_positions"] = self.resume_positions
            self.config["last_played_path"] = key
            save_config(self.config)
            self._last_resume_save_at = now
            audit("resume_position_save", f"{item.title} @ {position:.2f}s")

        def _resume_seconds_for_path(self, media_path: Path) -> float:
            if not bool(getattr(self, "resume_playback_enabled", True)):
                return 0.0
            row = self.resume_positions.get(str(media_path)) or {}
            try:
                pos = float(row.get("position") or 0.0)
                dur = float(row.get("duration") or 0.0)
            except Exception:
                return 0.0
            if pos < float(self.resume_min_seconds):
                return 0.0
            if dur > 0 and pos >= max(0.0, dur - float(self.resume_near_end_seconds)):
                return 0.0
            return pos

        def _resume_current_after_start(self, seconds: float, title: str) -> bool:
            try:
                seconds = float(seconds)
            except Exception:
                return False
            if seconds <= 0:
                return False
            if self._seek_seconds(seconds):
                self._set_status(f"Resumed {title} at {format_seconds(seconds)}.")
                audit("resume_playback", f"{title} @ {seconds:.2f}s")
            return False

        def _on_continue_last(self, _button=None) -> None:
            last_path = str(self.config.get("last_played_path", "") or "")
            if not last_path:
                self._set_status("No saved playback position yet. Play a video/audio item for at least 30 seconds first.")
                return
            path = Path(os.path.expanduser(last_path))
            if not path.is_file() or not is_media_path(str(path)):
                self._set_status(f"Saved Continue Last file is missing or unsupported: {last_path}")
                return
            match = None
            for idx, item in enumerate(self.items):
                if str(Path(os.path.expanduser(item.path))) == str(path):
                    match = idx
                    break
            if match is None:
                item = MediaItem(path=str(path), title=path.stem, media_type=classify_media_path(str(path)), source="continue-last")
                added = self._append_items([item], add_to_queue=True)
                match = added[0] if added else len(self.items) - 1
            self._play_index(int(match))
            self._menu_set_page(1)

        def _on_auto_intro_menu_toggled(self, item) -> None:
            active = bool(item.get_active())
            self.config["auto_skip_intro"] = active
            save_config(self.config)
            if self.auto_intro_check is not None and self.auto_intro_check.get_active() != active:
                self.auto_intro_check.set_active(active)
            self._set_status(f"Auto Skip Intro {'enabled' if active else 'disabled'} from Settings menu.")

        def _on_online_stats_menu_toggled(self, item) -> None:
            active = bool(item.get_active())
            self.config["nerd_stats_online_lookup"] = active
            save_config(self.config)
            if self.online_stats_check is not None and self.online_stats_check.get_active() != active:
                self.online_stats_check.set_active(active)
            self._set_status(f"Player fallback online lookup {'enabled' if active else 'disabled'} from Settings menu; Media Index remains default metadata authority.")

        def _on_media_index_default_toggled(self, item) -> None:
            active = bool(item.get_active())
            self.config["media_index_default_catalogue"] = active
            save_config(self.config)
            self._set_status(f"Media Index auto-load on startup {'enabled' if active else 'disabled'}.")

        def _on_double_tap_fullscreen_toggled(self, item) -> None:
            active = bool(item.get_active())
            self.video_double_tap_action = "fullscreen_toggle" if active else "disabled"
            self.config["video_double_tap_action"] = self.video_double_tap_action
            save_config(self.config)
            self._set_status(f"Double-tap fullscreen {'enabled' if active else 'disabled'}.")

        def _on_subtitles_enabled_menu_toggled(self, item) -> None:
            active = bool(item.get_active())
            self.subtitles_enabled = active
            self.config["subtitles_enabled"] = active
            save_config(self.config)
            if active:
                current = self._current_item()
                if current:
                    media_path = self._resolve_item_play_path(current)
                    if media_path is not None:
                        self._prepare_subtitles_for_media(media_path)
                self._set_status("Subtitles enabled. Embedded subtitle streams and sidecar files can be shown when available.")
            else:
                self._disable_subtitles(clear_external=False)
                self._set_status("Subtitles disabled by default. Use Subtitles/Load External Subtitles to turn them back on.")

        def _on_sidecar_subtitles_menu_toggled(self, item) -> None:
            active = bool(item.get_active())
            self.detect_sidecar_subtitles = active
            self.config["detect_sidecar_subtitles"] = active
            save_config(self.config)
            self._set_status(f"Sidecar subtitle auto-detection {'enabled' if active else 'disabled'}.")

        def _on_subtitle_safe_mode_toggled(self, item) -> None:
            active = bool(item.get_active())
            self.subtitle_overlay_safe_mode = active
            self.config["subtitle_overlay_safe_mode"] = active
            save_config(self.config)
            if active:
                self.subtitle_user_enabled_for_current = False
                self._disable_subtitles(clear_external=False)
                self._set_status("Safe subtitle overlay mode enabled. Subtitle overlay stays off during automatic playback to avoid green/blocky video; load subtitles manually when needed.")
            else:
                self._set_status("Safe subtitle overlay mode disabled. Sidecar/embedded subtitles may be applied automatically again.")

        def _on_file_assoc_status(self, *_args) -> None:
            self._show_info_dialog(
                "File association status",
                "Desktop launcher: sentinel-media-player %U\nHelper: sentinel-media-player-set-defaults\nExpected result: double-clicking supported local audio/video files opens and plays them in Sentinel Media Player.",
            )

        def _on_desktop_controls_status(self, *_args) -> None:
            self._show_info_dialog("Desktop controls", json.dumps(self._desktop_controls_profile(), indent=2, sort_keys=True))

        def _on_metadata_authority_status(self, *_args) -> None:
            payload = {
                "metadata_authority": "Sentinel Media Index",
                "online_metadata_default_owner": "Sentinel Media Index",
                "player_online_lookup_policy": "fallback/manual only",
                "player_background_fetch": False,
                "nerd_stats_default": "Media Index metadata first",
                "player_fallback_online_enabled": bool(self.config.get("nerd_stats_online_lookup", False)),
                "guidance": "Refresh/enrich the Sentinel Library file grid for default online metadata, then reload the Media Player library.",
            }
            self._show_info_dialog("Metadata Authority", json.dumps(payload, indent=2, sort_keys=True))

        def _on_supported_formats_info(self, *_args) -> None:
            self._show_info_dialog(
                "Supported formats",
                "Sentinel Media Player accepts broad common audio/video extensions. Actual playback support depends on installed GStreamer plugins. Recommended Debian/SentinelOS packages: gstreamer1.0-plugins-base, good, bad, ugly, and gstreamer1.0-libav.",
            )

        def _refresh_aegis_view(self, *_args) -> None:
            if self.aegis_text is not None:
                self._set_text(self.aegis_text, json.dumps({"version": VERSION, "config": self.config, "desktop_controls": self._desktop_controls_profile(), "ui": self._ui_profile(), "resume": self._resume_profile(), "metadata_authority": "Sentinel Media Index", "player_online_lookup_policy": "fallback/manual only"}, indent=2, sort_keys=True))
            self._set_status("AEGIS diagnostics refreshed.")

        def _on_aegis_status_dialog(self, *_args) -> None:
            from .aegis import aegis_status
            self._show_info_dialog("AEGIS status", json.dumps(aegis_status(), indent=2, sort_keys=True))

        def _on_aegis_actions_dialog(self, *_args) -> None:
            from .aegis import aegis_actions
            self._show_info_dialog("AEGIS actions", json.dumps(aegis_actions(), indent=2, sort_keys=True))

        def _ui_profile(self) -> dict:
            return {
                "layout": "simple_player_first_tabless_top_menu_workspace",
                "landing_page": "simple player / Now Playing workspace",
                "side_file_bar": "removed",
                "queue_access": "Queue workspace via top menu; explicit play queue only",
                "real_queue_model": True,
                "audio_tile_playback_fix": True,
                "library_play_switches_to_now_playing": True, "library_quick_search": bool(getattr(self, "library_search_enabled", True)),
                "workspace_quick_buttons": ["Library", "Now Playing", "Queue", "Nerd Stats"],
                "artwork_sources": ["Media Index artwork fields", "local poster database folders", "sidecar cover/poster files", "Caja/MATE thumbnail cache", "manual Retrieve Art", "local artwork audit", "system fallback icons"],
                "top_menu_bar": {
                    "File": ["Open Files", "Open Folder", "Refresh Library Grid", "Refresh List", "Set as Default", "Quit"],
                    "Playback": ["Play/Pause", "Stop", "Previous/Next", "Skip", "Intro/Credits", "Video Fullscreen", "Load/Remove Subtitles"],
                    "Library": ["Show Library", "Movies", "TV Shows / Episodes", "eBooks", "Music", "Refresh Library Grid", "Rebuild Board", "Clear"],
                    "View": ["Library", "Now Playing", "Queue", "Nerd Stats", "AEGIS"],
                    "Settings": ["Auto Skip Intro", "Online Nerd Stats", "Media Index Startup Load", "Double-Tap Fullscreen", "Subtitles", "Status/Formats"],
                    "Nerd Stats": ["Refresh", "Online Lookup"],
                    "AEGIS": ["Diagnostics", "Status", "Actions"],
                },
            }


        def _configure_gesture_surface(self, event_box, surface_name: str = "video") -> None:
            """Configure gesture capture without painting over the GStreamer video widget.

            Gtk.EventBox is useful for double-tap seek detection, but a visible
            EventBox can create a real GDK window that sits above native/video
            sink widgets on some MATE/Marco/X11 setups.  That produces the
            grey/dark rectangle reported in v0.3.x.  Keep the event box
            input-only and below the child, then connect events directly to the
            gtksink widget as the primary capture path.
            """
            try:
                event_box.set_visible_window(False)
            except Exception as exc:
                audit(f"gesture_surface_visible_window_{surface_name}", str(exc), "warning")
            try:
                event_box.set_above_child(False)
            except Exception as exc:
                audit(f"gesture_surface_above_child_{surface_name}", str(exc), "warning")
            try:
                event_box.set_app_paintable(False)
            except Exception:
                pass
            try:
                event_box.set_hexpand(True)
                event_box.set_vexpand(True)
                event_box.set_halign(Gtk.Align.FILL)
                event_box.set_valign(Gtk.Align.FILL)
            except Exception:
                pass
            try:
                event_box.add_events(Gdk.EventMask.BUTTON_PRESS_MASK)
                event_box.connect("button-press-event", self._on_video_button_press)
            except Exception as exc:
                audit(f"gesture_surface_events_{surface_name}", str(exc), "warning")

        def _configure_video_widget(self, widget) -> None:
            """Make the gtksink widget fill the video frame and handle clicks itself."""
            try:
                widget.set_hexpand(True)
                widget.set_vexpand(True)
                widget.set_halign(Gtk.Align.FILL)
                widget.set_valign(Gtk.Align.FILL)
                widget.set_size_request(1, 1)
            except Exception:
                pass
            try:
                widget.add_events(Gdk.EventMask.BUTTON_PRESS_MASK)
                widget.connect("button-press-event", self._on_video_button_press)
                widget.set_can_focus(True)
            except Exception as exc:
                audit("video_widget_events", str(exc), "warning")

        def _remove_from_parent(self, widget) -> None:
            try:
                parent = widget.get_parent()
                if parent is not None:
                    parent.remove(widget)
            except Exception as exc:
                audit("video_reparent_remove", str(exc), "warning")

        def _clear_container(self, container) -> None:
            try:
                for child in list(container.get_children()):
                    container.remove(child)
            except Exception as exc:
                audit("video_container_clear", str(exc), "warning")

        def _attach_video_to_embedded(self) -> None:
            if self.video_widget is None or self.video_box is None:
                return
            self._remove_from_parent(self.video_widget)
            self._clear_container(self.video_box)
            self.video_box.pack_start(self.video_widget, True, True, 0)
            try:
                self.video_widget.show_all()
                self.video_box.show_all()
            except Exception:
                pass

        def _show_embedded_fullscreen_placeholder(self) -> None:
            if self.video_box is None:
                return
            self._clear_container(self.video_box)
            label = Gtk.Label(label="Video is playing in video-only fullscreen mode.\nPress Escape or F11 in the fullscreen video window to return here.")
            label.set_justify(Gtk.Justification.CENTER)
            self.video_placeholder = label
            self.video_box.pack_start(label, True, True, 0)
            try:
                self.video_box.show_all()
            except Exception:
                pass

        def _ensure_fullscreen_window(self):
            if self.fullscreen_window is not None:
                return self.fullscreen_window
            fs = Gtk.Window(type=Gtk.WindowType.TOPLEVEL)
            fs.set_title(f"{APP_NAME} Video Fullscreen")
            fs.set_decorated(False)
            fs.set_keep_above(True)
            fs.set_default_size(1280, 720)
            fs.connect("key-press-event", self._on_key_press)
            fs.connect("delete-event", self._on_fullscreen_delete)
            event_box = Gtk.EventBox()
            event_box.set_name("sentinelFullscreenVideoSurface")
            self._configure_gesture_surface(event_box, "fullscreen")
            fs.add(event_box)
            self.fullscreen_window = fs
            self.fullscreen_video_event_box = event_box
            return fs

        def _attach_video_to_fullscreen(self) -> bool:
            if self.video_widget is None:
                self._set_status("Video-only fullscreen requires GStreamer gtksink video output. Audio-only files keep using normal controls.")
                return False
            fs = self._ensure_fullscreen_window()
            if self.fullscreen_video_event_box is None:
                return False
            self._remove_from_parent(self.video_widget)
            self._clear_container(self.fullscreen_video_event_box)
            self.fullscreen_video_event_box.add(self.video_widget)
            self._show_embedded_fullscreen_placeholder()
            fs.show_all()
            fs.fullscreen()
            try:
                fs.present()
                self.video_widget.grab_focus()
            except Exception:
                pass
            return True

        def _on_fullscreen_delete(self, *_args) -> bool:
            self._exit_fullscreen()
            return True

        def _build_pipeline(self) -> None:
            self.playbin = Gst.ElementFactory.make("playbin", "player")
            if self.playbin is None:
                self._set_status("GStreamer playbin is unavailable. Install GStreamer runtime packages.")
                audit("pipeline", "playbin missing", "error")
                return
            self.playbin.set_property("volume", 0.80)
            audio_sink = Gst.ElementFactory.make("autoaudiosink", "audiosink")
            if audio_sink is not None:
                try:
                    self.playbin.set_property("audio-sink", audio_sink)
                except Exception as exc:
                    audit("pipeline_audio_sink", str(exc), "warning")
            sink = None
            sink_name = ""
            for candidate in ("gtksink", "gtkglsink"):
                try:
                    sink = Gst.ElementFactory.make(candidate, "videosink")
                    if sink is not None:
                        sink_name = candidate
                        break
                except Exception:
                    sink = None
            if sink is not None:
                try:
                    self.playbin.set_property("video-sink", sink)
                    widget = sink.get_property("widget")
                    if widget is not None and self.video_box is not None:
                        self.video_widget = widget
                        self.embedded_video_sink_available = True
                        self.video_sink_name = sink_name
                        self._configure_video_widget(widget)
                        self._attach_video_to_embedded()
                except Exception as exc:
                    audit("pipeline_video_sink", str(exc), "warning")
            else:
                # Keep playback possible even when the embedded GTK video plugin is
                # missing. The user will get a clear status message instead of a
                # catalogue click that appears to do nothing.
                for candidate in ("autovideosink", "xvimagesink", "ximagesink", "glimagesink"):
                    try:
                        fallback = Gst.ElementFactory.make(candidate, "videosink")
                        if fallback is not None:
                            self.playbin.set_property("video-sink", fallback)
                            self.video_sink_name = candidate
                            audit("pipeline_video_sink_fallback", candidate, "warning")
                            break
                    except Exception as exc:
                        audit("pipeline_video_sink_fallback", f"{candidate}: {exc}", "warning")
            bus = self.playbin.get_bus()
            bus.add_signal_watch()
            bus.connect("message", self._on_bus_message)

        def _load_initial_queue(self) -> None:
            initial = []
            for raw in self.initial_files:
                normalized = normalise_media_argument(raw)
                if not normalized:
                    continue
                p = Path(os.path.expanduser(normalized))
                if p.is_dir():
                    initial.extend(scan_folder(str(p)))
                elif p.is_file() and is_media_path(str(p)):
                    item = MediaItem(path=str(p), title=p.stem, media_type=classify_media_path(str(p)), source="file association/cli")
                    initial.append(item)
            if initial:
                added = self._append_items(initial, add_to_queue=True)
                if added:
                    self._play_index(added[0])
                    if self.right_notebook is not None:
                        self.right_notebook.set_current_page(1)
            self._set_status("Player ready. Catalogue startup disabled; Library grid scans only approved user folders when opened.")

        def _scan_simple_library_roots(self) -> List[MediaItem]:
            items: List[MediaItem] = []
            seen: set[str] = set()
            for category, root, allowed_types in self.simple_library_roots:
                try:
                    if not root.exists() or not root.is_dir():
                        audit("simple_library_root_missing", str(root), "warning")
                        continue
                    for path in sorted(root.rglob("*"), key=lambda p: str(p).lower()):
                        try:
                            if not path.is_file():
                                continue
                            media_type = classify_media_path(str(path))
                            if media_type not in allowed_types:
                                continue
                            key = str(path)
                            if key in seen:
                                continue
                            seen.add(key)
                            items.append(MediaItem(path=key, title=path.stem, media_type=media_type, source=f"Library grid: {category}", category=category))
                        except Exception as exc:
                            audit("simple_library_scan_file", f"{path}: {exc}", "warning")
                except Exception as exc:
                    audit("simple_library_scan_root", f"{root}: {exc}", "warning")
            audit("simple_library_scan", f"items={len(items)}", "ok")
            return items

        def _load_simple_library_async(self, force: bool = False) -> None:
            if self.simple_library_loading:
                return
            if self.simple_library_loaded and not force:
                self._ensure_library_rendered(force=True)
                return
            self.simple_library_loading = True
            if self.library_status_label is not None:
                roots = ", ".join(str(root) for _cat, root, _types in self.simple_library_roots)
                self.library_status_label.set_text(f"Scanning simple Library grid in the background: {roots}")
            self._set_status("Scanning simple Library grid in the background. Player controls remain usable.")

            def worker() -> None:
                try:
                    items = self._scan_simple_library_roots()
                    GLib.idle_add(self._finish_simple_library_load, items, None)
                except Exception as exc:
                    GLib.idle_add(self._finish_simple_library_load, [], exc)

            threading.Thread(target=worker, name="sentinel-simple-library-loader", daemon=True).start()

        def _finish_simple_library_load(self, items, error=None) -> bool:
            self.simple_library_loading = False
            if error is not None:
                audit("simple_library_finish", str(error), "error")
                self._set_status(f"Library grid scan failed safely: {error}")
                if self.library_status_label is not None:
                    self.library_status_label.set_text("Library grid scan failed safely. Check folder permissions and paths.")
                return False
            current_item = self.items[self.current_index] if 0 <= self.current_index < len(self.items) else None
            queued_existing = [self.items[i] for i in self.queue_indices if 0 <= i < len(self.items)]
            merged_items = list(items)
            known_paths = {i.path for i in merged_items}
            for preserve in [current_item] + queued_existing:
                if preserve is not None and preserve.path and preserve.path not in known_paths:
                    merged_items.insert(0, preserve)
                    known_paths.add(preserve.path)
            old_current_path = current_item.path if current_item is not None else ""
            old_queue_paths = [i.path for i in queued_existing]
            self.items = merged_items
            path_to_index = {item.path: idx for idx, item in enumerate(self.items)}
            self.current_index = path_to_index.get(old_current_path, -1) if old_current_path else -1
            self.queue_indices = [path_to_index[p] for p in old_queue_paths if p in path_to_index]
            self.library_visible_limit = min(len(self.items), self.catalogue_startup_display_limit) if self.items else self.catalogue_startup_display_limit
            self.simple_library_loaded = True
            self._library_dirty = True
            self._refresh_queue_view()
            self._ensure_library_rendered(force=True)
            self._set_status(f"Library grid ready: {len(items)} file/s from approved folders only. Library grid rendered on demand with compact scalable tiles.")
            return False

        def _on_refresh_simple_library(self, _button=None) -> None:
            if self.right_notebook is not None:
                self.right_notebook.set_current_page(0)
            self.simple_library_loaded = False
            self._load_simple_library_async(force=True)

        def _auto_load_index(self) -> bool:
            self._set_status("Library file grid auto-load is disabled. Use the Library grid or drag/drop/open files.")
            return False

        def _finish_auto_load_index(self, items, files, error=None) -> bool:
            return False

        def _append_items(self, items: List[MediaItem], add_to_queue: bool = False) -> List[int]:
            existing = {i.path: idx for idx, i in enumerate(self.items)}
            added_indices: List[int] = []
            for item in items:
                existing_idx = existing.get(item.path)
                if existing_idx is not None:
                    if add_to_queue:
                        self._add_to_queue(existing_idx)
                    continue
                self.items.append(item)
                idx = len(self.items) - 1
                existing[item.path] = idx
                added_indices.append(idx)
                if add_to_queue:
                    self._add_to_queue(idx)
            if added_indices:
                self._set_status(f"Library contains {len(self.items)} item/s. Added {len(added_indices)}. Queue contains {len(self.queue_indices)} item/s.")
            else:
                self._set_status(f"Library contains {len(self.items)} item/s. No new items added. Queue contains {len(self.queue_indices)} item/s.")
            self._rebuild_library()
            self._refresh_queue_view()
            return added_indices

        def _refresh_queue_view(self) -> None:
            if self.queue_store is None:
                return
            self.queue_store.clear()
            for pos, item_index in enumerate(self.queue_indices, start=1):
                if 0 <= item_index < len(self.items):
                    item = self.items[item_index]
                    self.queue_store.append([str(pos), item.title, item.media_type, item.source, item.path])

        def _add_to_queue(self, item_index: int) -> None:
            if item_index < 0 or item_index >= len(self.items):
                return
            if self.items[item_index].media_type == "ebook":
                self._set_status("eBooks open externally and are not added to the playback queue.")
                return
            self.queue_indices.append(item_index)
            self._refresh_queue_view()
            item = self.items[item_index]
            audit("queue_add", item.path)

        def _queue_position_for_current(self) -> Optional[int]:
            if self.current_index < 0:
                return None
            for pos, idx in enumerate(self.queue_indices):
                if idx == self.current_index:
                    return pos
            return None

        def _selected_queue_position(self) -> Optional[int]:
            if self.queue_tree is None:
                return None
            selection = self.queue_tree.get_selection()
            model, treeiter = selection.get_selected()
            if treeiter is None or model is None:
                return None
            path = model.get_path(treeiter)
            return int(path.get_indices()[0])

        def _selected_queue_item_index(self) -> Optional[int]:
            pos = self._selected_queue_position()
            if pos is None or pos < 0 or pos >= len(self.queue_indices):
                return None
            return self.queue_indices[pos]

        def _on_queue_current(self, *_args) -> None:
            if self.current_index < 0 or self.current_index >= len(self.items):
                self._set_status("No current item to queue.")
                return
            self._add_to_queue(self.current_index)
            self._set_status(f"Queued current item: {self.items[self.current_index].title}")

        def _on_add_to_queue_from_library(self, _button, index: int) -> None:
            self._add_to_queue(index)
            if 0 <= index < len(self.items):
                self._set_status(f"Added to queue: {self.items[index].title}")

        def _on_remove_selected_from_queue(self, *_args) -> None:
            pos = self._selected_queue_position()
            if pos is None:
                self._set_status("No queue item selected to remove.")
                return
            if 0 <= pos < len(self.queue_indices):
                removed_idx = self.queue_indices.pop(pos)
                title = self.items[removed_idx].title if 0 <= removed_idx < len(self.items) else "item"
                self._refresh_queue_view()
                self._set_status(f"Removed from queue: {title}")

        def _on_clear_queue(self, *_args) -> None:
            self.queue_indices.clear()
            self._refresh_queue_view()
            self._set_status("Playback queue cleared. Library catalogue preserved.")

        def _on_clear_library(self, *_args) -> None:
            if self.playbin is not None:
                self.playbin.set_state(Gst.State.NULL)
            self.items.clear()
            self.queue_indices.clear()
            self.current_index = -1
            self.intro_skipped_for_index.clear()
            self.last_position_seconds = None
            self.last_duration_seconds = None
            self._refresh_queue_view()
            self._rebuild_library()
            self._set_status("Library catalogue and playback queue cleared.")
            if self.marker_label is not None:
                self.marker_label.set_text("Markers: none loaded")
            self._update_time_label(0, None)

        def _library_category(self, item: MediaItem) -> str:
            if item.category in SIMPLE_LIBRARY_ALLOWED_CATEGORIES:
                return item.category
            text = " ".join([item.title, item.path, item.media_type, item.series, item.album, item.artist, item.genre]).lower()
            if item.media_type == "ebook" or any(k in text for k in ("ebook", "e-book", "epub", "pdf", "comic book")):
                return "eBooks"
            if item.media_type == "audio":
                return "Music"
            if item.media_type == "video" and ("/tv shows/" in item.path.lower() or item.series or item.season or item.episode or any(k in text for k in ("s01", "season", "episode", "tv show", "series"))):
                return "TV Shows / Episodes"
            if item.media_type == "video":
                return "Movies"
            return "Unsorted"

        def _artwork_audit_for_item(self, item: MediaItem, limit: int = 80) -> dict:
            """Return a deterministic artwork diagnostic for the selected item.

            This explains why artwork is or is not showing without forcing heavy
            FFmpeg generation during startup. It checks Media Index fields, local
            sidecars, and Caja/MATE thumbnail cache candidates.
            """
            candidates = self._candidate_art_paths(item)
            checked = []
            found = []
            for raw in candidates[: max(1, int(limit))]:
                p = Path(os.path.expanduser(str(raw)))
                exists = p.is_file()
                image_like = self._looks_like_image(p)
                checked.append({"path": str(p), "exists": exists, "image_like": image_like})
                if exists and image_like:
                    found.append(str(p))
            thumb = self._freedesktop_thumbnail_for_item(item)
            if thumb:
                found.append(thumb)
            resolved = self._item_art_path(item)
            return {
                "title": item.title,
                "media_path": item.path,
                "media_type": item.media_type,
                "media_index_art_fields": {
                    "poster_path": item.poster_path,
                    "thumbnail_path": item.thumbnail_path,
                    "fanart_path": item.fanart_path,
                },
                "source": item.source,
                "resolved_artwork": resolved,
                "found_candidates": found[:10],
                "checked_count": len(checked),
                "checked_first": checked[:20],
                "thumbnail_cache_hit": bool(thumb),
                "safe_mode": self.artwork_safe_mode,
                "heavy_generation_enabled": self.artwork_heavy_generation_enabled,
                "recursive_scan_enabled": self.artwork_recursive_scan_enabled,
                "guidance": "Best setup: Sentinel Media Index should store poster_path/thumbnail_path/cover_path. Player then reads that first. Without index artwork fields, Player falls back to nearby sidecars such as poster.jpg/cover.jpg/folder.jpg and Caja thumbnail cache.",
            }

        def _normalise_poster_database_roots(self, raw_roots) -> List[str]:
            roots: List[str] = []
            if isinstance(raw_roots, str):
                raw_roots = [raw_roots]
            for raw in raw_roots or []:
                try:
                    p = Path(os.path.expanduser(str(raw))).resolve()
                except Exception:
                    continue
                if p.is_dir():
                    text = str(p)
                    if text not in roots:
                        roots.append(text)
            return roots

        def _manual_poster_database_roots(self, item: Optional[MediaItem] = None) -> List[Path]:
            roots: List[Path] = []
            for raw in self._normalise_poster_database_roots(self.config.get("local_poster_databases", [])):
                root = Path(raw)
                if root not in roots:
                    roots.append(root)
                if item is not None:
                    title_bits = [item.title, item.series, item.album, item.tmdb_id, item.imdb_id, item.musicbrainz_id, item.tvmaze_id]
                    if item.title and item.year:
                        title_bits.append(f"{item.title} ({item.year})")
                    for variant in self._slug_variants(*title_bits):
                        child = root / variant
                        if child not in roots:
                            roots.append(child)
            return roots

        def _poster_database_profile(self) -> dict:
            roots = self._normalise_poster_database_roots(self.config.get("local_poster_databases", []))
            return {
                "app": APP_NAME,
                "version": VERSION,
                "local_poster_databases_enabled": True,
                "configured_roots": roots,
                "priority": "after Media Index poster fields, before sidecar thumbnails and before any online retrieval",
                "accepted_extensions": [".jpg", ".jpeg", ".png", ".webp"],
                "matching_examples": [
                    "Poster root/Movie Title (Year).jpg",
                    "Poster root/Movie Title (Year)/poster.jpg",
                    "Poster root/Movies/Movie Title-poster.jpg",
                    "Poster root/tmdb_id/poster.jpg",
                ],
            }

        def _on_add_poster_database(self, _button=None) -> None:
            dialog = Gtk.FileChooserDialog(
                title="Add Local Poster Database",
                transient_for=self.window,
                action=Gtk.FileChooserAction.SELECT_FOLDER,
            )
            dialog.add_buttons(Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL, "Add Poster Database", Gtk.ResponseType.OK)
            try:
                response = dialog.run()
                if response == Gtk.ResponseType.OK:
                    folder = dialog.get_filename()
                    roots = self._normalise_poster_database_roots(self.config.get("local_poster_databases", []))
                    if folder:
                        try:
                            clean = str(Path(os.path.expanduser(folder)).resolve())
                        except Exception:
                            clean = str(folder)
                        if Path(clean).is_dir() and clean not in roots:
                            roots.append(clean)
                            self.config["local_poster_databases"] = roots
                            save_config(self.config)
                            self.local_poster_databases = roots
                            self.artwork_resolution_cache.clear()
                            self._rebuild_library()
                            self._set_status(f"Added local poster database: {clean}. Catalogue posters now resolve from local database before online retrieval.")
                        elif clean in roots:
                            self._set_status(f"Poster database already configured: {clean}")
                        else:
                            self._set_status(f"Poster database path is not a folder: {clean}")
            finally:
                dialog.destroy()

        def _on_poster_database_status(self, _button=None) -> None:
            self._show_info_dialog("Local Poster Database", json.dumps(self._poster_database_profile(), indent=2, sort_keys=True))

        def _item_art_path(self, item: MediaItem) -> str:
            """Return best local artwork path without blocking the GTK catalogue.

            v0.4.9 crash guard:
            - Startup/library rendering uses a safe, synchronous-only path.
            - No ffmpeg/ffmpegthumbnailer/totem subprocess is spawned while tiles are
              being built unless the user explicitly enables heavy artwork generation.
            - Recursive folder scans are disabled by default and capped when enabled.
            - Caja/MATE thumbnail-cache reuse remains enabled because it is a fast
              file-existence lookup, not media decoding.

            This keeps the library fast and prevents thumbnail generation from
            crashing or freezing the app during Media Index auto-load.
            """
            cache_key = f"{item.path}|{item.poster_path}|{item.thumbnail_path}|{item.fanart_path}|{item.title}|{item.album}|safe={self.artwork_safe_mode}|heavy={self.artwork_heavy_generation_enabled}|recursive={self.artwork_recursive_scan_enabled}"
            if cache_key in self.artwork_resolution_cache:
                return self.artwork_resolution_cache[cache_key]

            resolved = ""
            try:
                for candidate in self._candidate_art_paths(item):
                    if candidate:
                        p = Path(os.path.expanduser(candidate))
                        if p.is_file() and self._looks_like_image(p):
                            resolved = str(p)
                            break

                # Recursive scans were the likely cause of long library loads on
                # large collections. Keep them opt-in and bounded.
                if not resolved and self.artwork_recursive_scan_enabled:
                    resolved = self._find_recursive_art(item)

                # Reuse desktop thumbnails that Caja/MATE already generated. This
                # is cheap and safe because it is only an md5 filename lookup.
                if not resolved:
                    resolved = self._freedesktop_thumbnail_for_item(item)

                # Heavy extraction/generation is opt-in. It must never run by
                # default during startup/library board rendering.
                if not resolved and self.artwork_heavy_generation_enabled and item.media_type == "audio":
                    resolved = self._extract_embedded_audio_art(item) or self._extract_audio_art_with_ffmpeg(item)
                if not resolved and self.artwork_heavy_generation_enabled and item.media_type == "video":
                    resolved = self._generate_video_thumbnail(item)
            except Exception as exc:
                audit("artwork_safe_resolve", f"{item.path}: {exc}", "warning")
                resolved = ""

            self.artwork_resolution_cache[cache_key] = resolved or ""
            return resolved or ""

        def _source_index_art_roots(self, item: MediaItem) -> List[Path]:
            roots: List[Path] = []
            source = str(getattr(item, "source", "") or "")
            if ":" in source:
                _kind, rest = source.split(":", 1)
                index_path_text = rest.split("::", 1)[0]
                try:
                    index_path = Path(os.path.expanduser(index_path_text))
                    if index_path.is_file():
                        roots.append(index_path.parent)
                    elif index_path.is_dir():
                        roots.append(index_path)
                except Exception:
                    pass
            for raw in (
                "~/.local/share/sentinel-media-index",
                "~/.local/share/sentinel-media-index/artwork",
                "~/.local/share/sentinel-media-index/covers",
                "~/.local/share/sentinel-media-index/posters",
                "~/.local/share/sentinel-media-index/thumbnails",
                "~/.local/share/sentinel-media-index/cache",
                "~/.local/share/sentinel/media-index/artwork",
                "~/.sentinel/media-index/artwork",
            ):
                path = Path(os.path.expanduser(raw))
                roots.append(path)
            out: List[Path] = []
            for root in roots:
                if root not in out:
                    out.append(root)
            return out

        def _slug_variants(self, *values: str) -> List[str]:
            variants: List[str] = []
            for value in values:
                text = str(value or "").strip()
                if not text:
                    continue
                basic = "".join(ch if ch.isalnum() else " " for ch in text).strip()
                collapsed = " ".join(basic.split())
                for candidate in (text, collapsed, collapsed.lower(), collapsed.replace(" ", "_"), collapsed.replace(" ", "-")):
                    if candidate and candidate not in variants:
                        variants.append(candidate)
            return variants

        def _candidate_art_paths(self, item: MediaItem) -> List[str]:
            candidates: List[str] = []
            media_path = Path(os.path.expanduser(item.path))
            parent = media_path.parent
            stem = media_path.stem
            exts = (".jpg", ".jpeg", ".png", ".webp")
            art_roots: List[Path] = [parent, parent.parent, parent / stem, parent / "artwork", parent / "covers", parent / "posters", parent / "thumbnails"]
            # User-selected local poster databases are consulted before broad
            # sidecar/cache fallbacks, so an offline poster library can replace
            # online retrieval for movies, TV, and music artwork.
            art_roots.extend(self._manual_poster_database_roots(item))
            art_roots.extend(self._source_index_art_roots(item))
            expanded_roots: List[Path] = []
            for root in art_roots:
                for sub in (Path(""), Path("artwork"), Path("covers"), Path("cover"), Path("posters"), Path("poster"), Path("thumbnails"), Path("thumbs"), Path("images"), Path("Movies"), Path("Movie"), Path("TV Shows"), Path("TV"), Path("Music")):
                    path = root / sub if str(sub) else root
                    if path not in expanded_roots:
                        expanded_roots.append(path)

            def add(raw: str | Path) -> None:
                if raw is None:
                    return
                text = str(raw).strip().strip("'\"")
                if not text:
                    return
                path = Path(os.path.expanduser(text))
                if path.is_absolute():
                    candidates.append(str(path))
                    # If an older Media Index resolved a relative artwork field
                    # against the index folder but the actual cover sits beside
                    # the media file, also try the basename near the media and
                    # common artwork roots.
                    if path.name:
                        candidates.append(str(parent / path.name))
                        tail = Path(*path.parts[-2:]) if len(path.parts) >= 2 else Path(path.name)
                        candidates.append(str(parent / tail))
                        for root in expanded_roots:
                            candidates.append(str(root / path.name))
                            candidates.append(str(root / tail))
                    return
                candidates.append(str(parent / path))
                for root in expanded_roots:
                    candidates.append(str(root / path))

            # Media Index-provided artwork has priority, but relative paths are
            # tried against the media folder and common Media Index artwork roots.
            for raw in (item.poster_path, item.thumbnail_path, item.fanart_path):
                if raw:
                    add(raw)

            names: List[str] = []
            year_title = f"{item.title} ({item.year})" if item.title and item.year else ""
            year_stem = f"{stem} ({item.year})" if stem and item.year else ""
            for suffix in ("", "-poster", "_poster", ".poster", "-cover", "_cover", ".cover", "-front", "_front", "-thumb", "_thumb", "-thumbnail", "_thumbnail"):
                for variant in self._slug_variants(stem, year_stem, item.title, year_title, item.album, item.series, item.collection, item.imdb_id, item.tmdb_id, item.musicbrainz_id, item.wikidata_id, item.tvmaze_id):
                    for ext in exts:
                        names.append(f"{variant}{suffix}{ext}")
            generic_roots = [
                "cover", "Cover", "COVER", "folder", "Folder", "FOLDER", "front", "Front",
                "album", "Album", "albumart", "album_art", "AlbumArt", "AlbumArtSmall",
                "poster", "Poster", "POSTER", "movie", "Movie", "thumbnail", "thumb", "fanart", "backdrop",
            ]
            for name in generic_roots:
                for ext in exts:
                    names.append(name + ext)
            seen = set()
            for name in names:
                if name in seen:
                    continue
                seen.add(name)
                for root in expanded_roots:
                    candidates.append(str(root / name))
            # Last deterministic fallback: some index enrichers store art under
            # identifier subdirectories, e.g. artwork/tmdb_id/poster.jpg.
            for ident in self._slug_variants(item.imdb_id, item.tmdb_id, item.musicbrainz_id, item.wikidata_id, item.tvmaze_id):
                for root in expanded_roots:
                    for generic in generic_roots:
                        for ext in exts:
                            candidates.append(str(root / ident / (generic + ext)))
            out: List[str] = []
            seen_paths = set()
            for candidate in candidates:
                key = os.path.abspath(os.path.expanduser(candidate))
                if key not in seen_paths:
                    out.append(candidate)
                    seen_paths.add(key)
            return out


        def _looks_like_image(self, path: Path) -> bool:
            return path.suffix.lower() in {".jpg", ".jpeg", ".png", ".webp"}

        def _freedesktop_thumbnail_for_item(self, item: MediaItem) -> str:
            """Use thumbnails already generated by Caja/MATE where available.

            This is the most reliable fallback for video folders that already show
            thumbnails in Caja but do not have poster_path/cover_path metadata yet.
            """
            try:
                media_path = Path(os.path.expanduser(item.path)).resolve()
                if not media_path.is_file():
                    return ""
                uri = media_path.as_uri()
                digest = hashlib.md5(uri.encode("utf-8")).hexdigest() + ".png"
                roots = [Path.home() / ".cache" / "thumbnails", Path.home() / ".thumbnails"]
                sizes = ["xx-large", "x-large", "large", "normal"]
                for root in roots:
                    for size in sizes:
                        candidate = root / size / digest
                        if candidate.is_file():
                            return str(candidate)
            except Exception as exc:
                audit("freedesktop_thumbnail", f"{item.path}: {exc}", "warning")
            return ""

        def _art_score(self, item: MediaItem, path: Path) -> int:
            name = path.name.lower()
            parent = path.parent.name.lower()
            stem = Path(os.path.expanduser(item.path)).stem.lower()
            title = (item.title or "").lower()
            album = (item.album or "").lower()
            series = (item.series or "").lower()
            collection = (item.collection or "").lower()
            score = 0
            if not self._looks_like_image(path):
                return -999
            if any(k in name for k in ("cover", "folder", "front", "album", "poster", "thumb", "thumbnail", "fanart", "backdrop")):
                score += 35
            if any(k in parent for k in ("art", "artwork", "cover", "covers", "poster", "posters", "thumb", "thumbnail", "image", "images")):
                score += 20
            if stem and stem in name:
                score += 55
            for value in (title, album, series, collection, item.imdb_id.lower(), item.tmdb_id.lower(), item.musicbrainz_id.lower(), item.wikidata_id.lower(), item.tvmaze_id.lower()):
                compact = "".join(ch for ch in value if ch.isalnum())
                if value and value in name:
                    score += 45
                elif compact and compact in "".join(ch for ch in name if ch.isalnum()):
                    score += 35
            if item.media_type == "audio" and any(k in name for k in ("album", "cover", "folder", "front")):
                score += 30
            if item.media_type == "video" and any(k in name for k in ("poster", "movie", "cover", "folder", "fanart", "backdrop")):
                score += 30
            # Avoid tiny app icons and obvious UI assets.
            if any(k in str(path).lower() for k in ("/icons/", "/hicolor/", "/themes/", "/usr/share/", "/node_modules/", "/__pycache__/")):
                score -= 100
            return score

        def _find_recursive_art(self, item: MediaItem) -> str:
            """Find nearby poster/cover art without relying on exact filename matches.

            Limit scanning so a big collection does not stall the UI. This is meant
            for common layouts like:
              Movie Folder/poster.jpg
              Album Folder/cover.jpg
              MediaIndex/artwork/<tmdb_id>/poster.jpg
              MediaIndex/covers/<album>/folder.jpg
            """
            media_path = Path(os.path.expanduser(item.path))
            if not media_path.name:
                return ""
            roots: List[Path] = []
            parent = media_path.parent
            for root in [parent, parent / "artwork", parent / "covers", parent / "posters", parent.parent, parent.parent / "artwork", parent.parent / "covers", parent.parent / "posters"]:
                roots.append(root)
            roots.extend(self._source_index_art_roots(item))
            best_path = None
            best_score = 0
            checked = 0
            for root in roots:
                try:
                    root = Path(os.path.expanduser(str(root)))
                    if not root.exists() or not root.is_dir():
                        continue
                    # Direct children first; then one-level recursive art folders.
                    walkers = [root.glob("*")]
                    if root.name.lower() in ("artwork", "covers", "posters", "thumbnails", "images") or root == parent:
                        walkers.append(root.glob("*/*"))
                    for walker in walkers:
                        for candidate in walker:
                            checked += 1
                            if checked > self.artwork_max_recursive_checks:
                                break
                            if not candidate.is_file() or not self._looks_like_image(candidate):
                                continue
                            score = self._art_score(item, candidate)
                            if score > best_score:
                                best_score = score
                                best_path = candidate
                        if checked > self.artwork_max_recursive_checks:
                            break
                except Exception:
                    continue
                if checked > self.artwork_max_recursive_checks:
                    break
            if best_path is not None and best_score >= 25:
                return str(best_path)
            return ""

        def _generate_video_thumbnail(self, item: MediaItem) -> str:
            media_path = Path(os.path.expanduser(item.path))
            if item.media_type != "video" or not media_path.is_file():
                return ""
            try:
                self.video_art_cache_dir.mkdir(parents=True, exist_ok=True)
                digest = hashlib.sha256(str(media_path).encode("utf-8")).hexdigest()[:24]
                out = self.video_art_cache_dir / f"{digest}.jpg"
                if out.is_symlink():
                    audit("thumbnail_cache_symlink_blocked", str(out), "warning")
                    return ""
                if out.is_symlink():
                    audit("audio_art_cache_symlink_blocked", str(out), "warning")
                    return ""
                if out.is_file():
                    return str(out)
                commands = []
                if shutil.which("ffmpegthumbnailer"):
                    commands.append(["ffmpegthumbnailer", "-i", str(media_path), "-o", str(out), "-s", "360", "-q", "8"])
                if shutil.which("ffmpeg"):
                    commands.append(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-ss", "00:00:30", "-i", str(media_path), "-frames:v", "1", "-vf", "scale=360:-1", str(out)])
                    commands.append(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-ss", "00:00:10", "-i", str(media_path), "-frames:v", "1", "-vf", "scale=360:-1", str(out)])
                if shutil.which("totem-video-thumbnailer"):
                    commands.append(["totem-video-thumbnailer", str(media_path), str(out)])
                for cmd in commands:
                    try:
                        result = subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=25)
                        if result.returncode == 0 and out.is_file():
                            return str(out)
                    except Exception:
                        continue
            except Exception as exc:
                audit("video_thumbnail_generation", f"{item.path}: {exc}", "warning")
            return ""

        def _extract_audio_art_with_ffmpeg(self, item: MediaItem) -> str:
            media_path = Path(os.path.expanduser(item.path))
            if item.media_type != "audio" or not media_path.is_file() or not shutil.which("ffmpeg"):
                return ""
            try:
                self.audio_art_cache_dir.mkdir(parents=True, exist_ok=True)
                digest = hashlib.sha256((str(media_path) + "|ffmpeg").encode("utf-8")).hexdigest()[:24]
                out = self.audio_art_cache_dir / f"{digest}.jpg"
                if out.is_file():
                    return str(out)
                cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(media_path), "-map", "0:v:0", "-frames:v", "1", str(out)]
                result = subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=20)
                if result.returncode == 0 and out.is_file():
                    return str(out)
            except Exception as exc:
                audit("ffmpeg_audio_art", f"{item.path}: {exc}", "warning")
            return ""

        def _extract_embedded_audio_art(self, item: MediaItem) -> str:
            if item.media_type != "audio":
                return ""
            try:
                import mutagen  # type: ignore
                from mutagen.flac import Picture  # type: ignore
            except Exception:
                return ""
            try:
                media_path = Path(os.path.expanduser(item.path))
                if not media_path.is_file():
                    return ""
                self.audio_art_cache_dir.mkdir(parents=True, exist_ok=True)
                digest = hashlib.sha256(str(media_path).encode("utf-8")).hexdigest()[:24]
                out = self.audio_art_cache_dir / f"{digest}.jpg"
                if out.is_file():
                    return str(out)
                audio = mutagen.File(str(media_path))
                data = None
                mime = "image/jpeg"
                if audio is None:
                    return ""
                # MP3/ID3 APIC frames
                tags = getattr(audio, "tags", None)
                if tags:
                    for value in tags.values():
                        if hasattr(value, "data") and value.__class__.__name__.upper().startswith("APIC"):
                            data = value.data
                            mime = getattr(value, "mime", "image/jpeg") or "image/jpeg"
                            break
                    # MP4 covr atoms
                    if data is None and "covr" in tags:
                        covr = tags.get("covr")
                        if covr:
                            data = bytes(covr[0])
                # FLAC/Vorbis pictures
                if data is None and getattr(audio, "pictures", None):
                    pic = audio.pictures[0]
                    data = getattr(pic, "data", None)
                    mime = getattr(pic, "mime", "image/jpeg") or "image/jpeg"
                if not data:
                    return ""
                ext = ".png" if "png" in str(mime).lower() else ".jpg"
                out = self.audio_art_cache_dir / f"{digest}{ext}"
                if out.is_symlink():
                    audit("embedded_audio_art_cache_symlink_blocked", str(out), "warning")
                    return ""
                tmp = out.with_name(out.name + f".tmp-{os.getpid()}")
                if tmp.exists() or tmp.is_symlink():
                    tmp.unlink(missing_ok=True)
                fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
                try:
                    with os.fdopen(fd, "wb") as fh:
                        fh.write(data)
                    os.replace(tmp, out)
                finally:
                    try:
                        if tmp.exists() or tmp.is_symlink():
                            tmp.unlink()
                    except Exception:
                        pass
                return str(out)
            except Exception as exc:
                audit("embedded_audio_art", f"{item.path}: {exc}", "warning")
                return ""

        def _item_subtitle(self, item: MediaItem) -> str:
            bits = []
            if item.year:
                bits.append(str(item.year)[:4])
            if item.series:
                bits.append(item.series)
            if item.season or item.episode:
                bits.append(f"S{str(item.season or "?").zfill(2)}E{str(item.episode or "?").zfill(2)}")
            if item.duration:
                dur = item.duration_seconds()
                bits.append(format_seconds(dur) if dur is not None else item.duration)
            if item.resolution:
                bits.append(item.resolution)
            if item.watched:
                bits.append("watched" if str(item.watched).lower() in ("1", "true", "yes", "watched") else str(item.watched))
            return " · ".join(bits) or item.media_type.title()

        def _make_tile(self, index: int, item: MediaItem):
            outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
            outer.set_name("sentinelLibraryTile")
            outer.set_tooltip_text(item.path)
            outer.set_size_request(128, 92)

            icon_name = "audio-x-generic" if item.media_type == "audio" else ("x-office-document" if item.media_type == "ebook" else "video-x-generic")
            icon = Gtk.Image.new_from_icon_name(icon_name, Gtk.IconSize.DIALOG)
            icon.set_pixel_size(40)
            open_button = Gtk.Button()
            open_button.set_relief(Gtk.ReliefStyle.NONE)
            open_button.set_tooltip_text("Open" if item.media_type == "ebook" else "Play")
            open_button.add(icon)
            open_button.connect("clicked", self._on_library_tile_clicked, index)
            outer.pack_start(open_button, False, False, 0)

            title = Gtk.Label(label=item.title)
            title.set_name("sentinelTileTitle")
            title.set_xalign(0.5)
            title.set_justify(Gtk.Justification.CENTER)
            title.set_line_wrap(True)
            title.set_max_width_chars(20)
            outer.pack_start(title, False, False, 0)

            meta = Gtk.Label(label=self._item_subtitle(item) or item.media_type.title())
            meta.set_name("sentinelTileMeta")
            meta.set_xalign(0.5)
            meta.set_justify(Gtk.Justification.CENTER)
            meta.set_line_wrap(True)
            meta.set_max_width_chars(20)
            outer.pack_start(meta, False, False, 0)

            actions = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
            play_btn = Gtk.Button(label="Open" if item.media_type == "ebook" else "Play")
            play_btn.set_tooltip_text("Open this Library file" if item.media_type == "ebook" else "Play this Library file")
            play_btn.connect("clicked", self._on_library_tile_clicked, index)
            actions.pack_start(play_btn, True, True, 0)
            if item.media_type != "ebook":
                queue_btn = Gtk.Button(label="+ Queue")
                queue_btn.set_tooltip_text("Add this file to the playback queue")
                queue_btn.connect("clicked", self._on_add_to_queue_from_library, index)
                actions.pack_start(queue_btn, True, True, 0)
            outer.pack_start(actions, False, False, 0)
            return outer

        def _rebuild_library(self) -> None:
            if self.library_notebook is None:
                return
            self._library_render_token += 1
            token = self._library_render_token
            self._library_render_queue = []
            self._library_render_total = 0
            self._library_render_done = 0
            try:
                for child in list(self.library_notebook.get_children()):
                    self.library_notebook.remove(child)
                grouped = {}
                search_query = self._library_search_query()
                matched_total = 0
                for idx, item in enumerate(self.items):
                    try:
                        if search_query and not self._library_item_matches_search(item, search_query):
                            continue
                        grouped.setdefault(self._library_category(item), []).append((idx, item))
                        matched_total += 1
                    except Exception as exc:
                        audit("library_group_item", f"{idx}: {exc}", "warning")
                order = ["Movies", "TV Shows / Episodes", "Music", "eBooks"]
                visible_categories = [self.library_category_filter] if self.library_category_filter else order
                total_visible = 0
                display_limit = max(1, int(getattr(self, "library_visible_limit", self.catalogue_startup_display_limit) or len(self.items) or 1))
                clipped = False
                for category in visible_categories:
                    if category not in order:
                        continue
                    entries = grouped.get(category, [])
                    if not entries:
                        continue
                    remaining = display_limit - total_visible
                    if remaining <= 0:
                        clipped = True
                        break
                    render_entries = entries[:remaining]
                    if len(render_entries) < len(entries):
                        clipped = True
                    total_visible += len(render_entries)
                    section = Gtk.Label(label=f"{category} ({len(entries)})")
                    section.set_name("sentinelLibrarySection")
                    section.set_xalign(0)
                    self.library_notebook.pack_start(section, False, False, 0)
                    flow = Gtk.FlowBox()
                    flow.set_selection_mode(Gtk.SelectionMode.NONE)
                    flow.set_max_children_per_line(5)
                    flow.set_row_spacing(8)
                    flow.set_column_spacing(8)
                    flow.set_homogeneous(False)
                    self.library_notebook.pack_start(flow, False, False, 0)
                    for idx, item in render_entries:
                        self._library_render_queue.append((flow, idx, item))
                if clipped:
                    note = Gtk.Label(label=f"Catalogue view showing the first {display_limit} visible item/s from the written Library file grid.")
                    note.set_name("sentinelLibraryHelp")
                    note.set_line_wrap(True)
                    note.set_xalign(0)
                    self.library_notebook.pack_start(note, False, False, 0)
                if total_visible == 0:
                    empty_text = "No indexed media yet. Use the left sidebar Refresh Library action to ask Sentinel Media Index to write the fast catalogue, then the player will reload it here."
                    if search_query:
                        empty_text = f"No Library files match '{search_query}'. Clear the search or try fewer words."
                    elif self.library_category_filter:
                        empty_text = f"No {self.library_category_filter} items are available in the selected Library folder set."
                    empty = Gtk.Label(label=empty_text)
                    empty.set_line_wrap(True)
                    empty.set_xalign(0)
                    self.library_notebook.pack_start(empty, False, False, 0)
                self._library_render_total = len(self._library_render_queue)
                if self.library_status_label is not None:
                    scope = self.library_category_filter or "all categories"
                    search_note = f" Search: '{search_query}' matched {matched_total}." if search_query else ""
                    self.library_status_label.set_text(f"Library board: {len(self.items)} file/s. Showing {scope}.{search_note} Rendering {self._library_render_total} tile/s in crash-safe batches...")
                self.library_notebook.show_all()
                if self.catalogue_lazy_render and self._library_render_queue:
                    GLib.idle_add(self._render_library_batch, token)
                elif self._library_render_queue:
                    self._render_library_batch(token)
            except Exception as exc:
                audit("library_rebuild", str(exc), "error")
                self._set_status(f"Library board rebuild failed safely: {exc}")

        def _render_library_batch(self, token: int) -> bool:
            if token != self._library_render_token:
                return False
            batch_size = max(1, min(int(self.catalogue_tile_batch_size or 8), 16))
            processed = 0
            while self._library_render_queue and processed < batch_size:
                flow, idx, item = self._library_render_queue.pop(0)
                processed += 1
                try:
                    flow.add(self._make_tile(idx, item))
                    self._library_render_done += 1
                except Exception as exc:
                    audit("library_tile_render", f"{getattr(item, 'path', idx)}: {exc}", "warning")
            try:
                self.library_notebook.show_all()
            except Exception:
                pass
            if self.library_status_label is not None and self._library_render_total:
                self.library_status_label.set_text(f"Library board: rendered {self._library_render_done}/{self._library_render_total} visible tile/s safely. Library total: {len(self.items)}.")
            if self._library_render_queue:
                return True
            if self.library_status_label is not None:
                scope = self.library_category_filter or "all categories"
                search = self._library_search_query()
                search_note = f" Search active: '{search}'." if search else ""
                self.library_status_label.set_text(f"Library board ready: {len(self.items)} file/s. Showing {scope}; artwork remains startup-safe.{search_note}")
            return False

        def _on_library_tile_clicked(self, _button, index: int) -> None:
            self._play_from_library(index)

        def _play_from_library(self, index: int) -> None:
            if index < 0 or index >= len(self.items):
                self._set_status("Library selection is no longer valid; reload the Library file grid.")
                audit("library_play_invalid_index", str(index), "warning")
                return
            # Switch first so the user sees an immediate Now Playing surface even
            # while GStreamer is preparing the URI.  Earlier versions could appear
            # to do nothing because the hidden tabless workspace stayed on Library.
            self._menu_set_page(1)
            try:
                if self.window is not None:
                    self.window.present()
            except Exception:
                pass
            self._set_status(f"Opening Now Playing: {self.items[index].title}")
            if self._play_index(index):
                self._menu_set_page(1)
                self._set_status(f"Playing from Library: {self.items[index].title}")
            else:
                self._set_status(f"Could not play library item: {self.items[index].title}. Check that the Media Index path exists and GStreamer codecs are installed.")

        def _selected_index(self) -> Optional[int]:
            # Compatibility helper: selection now refers to the real Queue tab,
            # not the full Library file grid.
            return self._selected_queue_item_index()

        def _current_item(self) -> Optional[MediaItem]:
            if 0 <= self.current_index < len(self.items):
                return self.items[self.current_index]
            selected = self._selected_index()
            if selected is not None and 0 <= selected < len(self.items):
                return self.items[selected]
            return None

        def _show_audio_now_playing(self, item: MediaItem) -> None:
            if self.video_box is None:
                return
            self._clear_container(self.video_box)
            art_path = self._item_art_path(item)
            if art_path:
                try:
                    pix = GdkPixbuf.Pixbuf.new_from_file_at_scale(art_path, 260, 260, True)
                    image = Gtk.Image.new_from_pixbuf(pix)
                except Exception:
                    image = Gtk.Image.new_from_icon_name("audio-x-generic", Gtk.IconSize.DIALOG)
                    image.set_pixel_size(128)
            else:
                image = Gtk.Image.new_from_icon_name("audio-x-generic", Gtk.IconSize.DIALOG)
                image.set_pixel_size(128)
            self.video_box.pack_start(image, True, True, 0)
            title = Gtk.Label(label=f"<b>{GLib.markup_escape_text(item.title)}</b>")
            title.set_use_markup(True)
            title.set_justify(Gtk.Justification.CENTER)
            title.set_xalign(0.5)
            self.video_box.pack_start(title, False, False, 0)
            details = " · ".join([part for part in (item.artist, item.album, item.year, item.genre) if part]) or "Audio playback"
            detail_label = Gtk.Label(label=details)
            detail_label.set_name("sentinelTileMeta")
            detail_label.set_justify(Gtk.Justification.CENTER)
            detail_label.set_xalign(0.5)
            detail_label.set_line_wrap(True)
            self.video_box.pack_start(detail_label, False, False, 0)
            self.video_box.show_all()

        def _show_video_surface_for_item(self) -> None:
            if self.video_widget is not None and self.video_box is not None:
                self._attach_video_to_embedded()
                return
            if self.video_box is None:
                return
            self._clear_container(self.video_box)
            label = Gtk.Label(label=(
                "Video playback is starting through the system GStreamer video sink.\n"
                "For embedded catalogue video, install the GTK GStreamer sink package plus libav/bad/ugly codec plugins.\n"
                "Run: sentinel-media-player-playback-status"
            ))
            label.set_justify(Gtk.Justification.CENTER)
            label.set_line_wrap(True)
            self.video_box.pack_start(label, True, True, 0)
            self.video_box.show_all()

        def _set_subtitle_status(self, text: str) -> None:
            if self.subtitle_status_label is not None:
                try:
                    self.subtitle_status_label.set_text(f"Subtitles: {text}")
                except Exception:
                    pass

        def _set_playbin_property_safe(self, name: str, value) -> bool:
            if self.playbin is None:
                return False
            try:
                self.playbin.set_property(name, value)
                return True
            except Exception as exc:
                audit("subtitle_property", f"{name}={value!r}: {exc}", "warning")
                return False

        def _set_subtitle_text_flag(self, enabled: bool) -> None:
            if self.playbin is None:
                return
            try:
                flags = int(self.playbin.get_property("flags"))
                flags = (flags | GST_PLAY_FLAG_TEXT) if enabled else (flags & ~GST_PLAY_FLAG_TEXT)
                self.playbin.set_property("flags", flags)
            except Exception as exc:
                audit("subtitle_flags", str(exc), "warning")
            if not enabled:
                self._set_playbin_property_safe("current-text", -1)

        def _clear_external_subtitle_uri(self) -> None:
            if not self._set_playbin_property_safe("suburi", None):
                self._set_playbin_property_safe("suburi", "")

        def _subtitle_auto_overlay_allowed(self) -> bool:
            """Return True only when automatic text overlay is safe/explicit.

            Some GStreamer subtitle overlay paths can corrupt the video plane on
            certain files/sinks, showing green or blocky frames while audio keeps
            playing.  v0.5.21 therefore defaults to a safe policy: automatic
            sidecar/embedded subtitle overlay is suppressed unless the user has
            explicitly enabled subtitles for the current item or disabled safe
            mode.
            """
            if not bool(getattr(self, "subtitles_enabled", True)):
                return False
            if not bool(getattr(self, "subtitle_overlay_safe_mode", True)):
                return True
            if bool(getattr(self, "subtitle_auto_apply_on_play", False)):
                return True
            return bool(getattr(self, "subtitle_user_enabled_for_current", False))

        def _suppress_subtitle_overlay_for_safe_video(self) -> None:
            self._clear_external_subtitle_uri()
            self._set_subtitle_text_flag(False)
            self.current_subtitle_path = None
            self._set_subtitle_status("safe off")

        def _candidate_subtitle_paths(self, media_path: Path) -> List[Path]:
            parent = media_path.parent
            stem = media_path.stem
            candidates: List[Path] = []
            def add(path: Path) -> None:
                try:
                    if path.is_file() and path not in candidates:
                        candidates.append(path)
                except Exception:
                    pass
            for ext in SUBTITLE_EXTENSIONS:
                add(parent / f"{stem}{ext}")
            for ext in SUBTITLE_EXTENSIONS:
                for path in sorted(parent.glob(f"{stem}.*{ext}"))[:12]:
                    add(path)
            for subdir_name in ("Subs", "subs", "Subtitles", "subtitles"):
                subdir = parent / subdir_name
                if not subdir.is_dir():
                    continue
                for ext in SUBTITLE_EXTENSIONS:
                    add(subdir / f"{stem}{ext}")
                    for path in sorted(subdir.glob(f"{stem}.*{ext}"))[:12]:
                        add(path)
            return candidates

        def _prepare_subtitles_for_media(self, media_path: Path) -> str:
            """Apply subtitle policy for the media about to play.

            External sidecar subtitles are optional and never mutate the Media Index.
            Remove/Disable Subtitles only hides subtitle streams; it does not delete
            any .srt/.ass/.ssa/.vtt/.sub files from disk.
            """
            self.current_subtitle_path = None
            if not self._subtitle_auto_overlay_allowed():
                self._suppress_subtitle_overlay_for_safe_video()
                if bool(getattr(self, "subtitle_overlay_safe_mode", True)) and bool(getattr(self, "subtitles_enabled", True)):
                    audit("subtitle_safe_mode", f"automatic overlay suppressed for {media_path.name}")
                    return "safe_off"
                return "off"
            self._set_subtitle_text_flag(True)
            manual = self.manual_subtitle_path
            if manual and self.manual_subtitle_media_path == str(media_path):
                manual_path = Path(os.path.expanduser(manual))
                if manual_path.is_file():
                    self._set_playbin_property_safe("suburi", manual_path.resolve().as_uri())
                    self.current_subtitle_path = str(manual_path)
                    self._set_subtitle_status(manual_path.name)
                    audit("subtitle_external", f"manual:{manual_path}")
                    return str(manual_path)
            # Manual subtitle was for an older item; clear it so it does not bleed
            # across unrelated catalogue entries.
            if manual and self.manual_subtitle_media_path != str(media_path):
                self.manual_subtitle_path = None
                self.manual_subtitle_media_path = None
            if bool(getattr(self, "detect_sidecar_subtitles", True)):
                candidates = self._candidate_subtitle_paths(media_path)
                if candidates:
                    sub = candidates[0]
                    self._set_playbin_property_safe("suburi", sub.resolve().as_uri())
                    self.current_subtitle_path = str(sub)
                    self._set_subtitle_status(sub.name)
                    audit("subtitle_external", f"sidecar:{sub}")
                    return str(sub)
            self._clear_external_subtitle_uri()
            self._set_subtitle_status("embedded/auto")
            return "embedded/auto"

        def _disable_subtitles(self, clear_external: bool = True) -> None:
            if clear_external:
                self.manual_subtitle_path = None
                self.manual_subtitle_media_path = None
            self.current_subtitle_path = None
            self._clear_external_subtitle_uri()
            self._set_subtitle_text_flag(False)
            self._set_subtitle_status("off")
            audit("subtitle_disable", "subtitles disabled/removed from current playback")

        def _on_remove_subtitles(self, _button=None) -> None:
            self.subtitle_user_enabled_for_current = False
            self.subtitles_enabled = False
            self.config["subtitles_enabled"] = False
            save_config(self.config)
            if self.subtitle_menu_item is not None and self.subtitle_menu_item.get_active():
                self.subtitle_menu_item.set_active(False)
            self._disable_subtitles(clear_external=True)
            self._set_status("Subtitles removed from current playback and disabled by default. Subtitle files were not deleted.")

        def _on_load_subtitles(self, _button=None) -> None:
            dialog = Gtk.FileChooserDialog(
                title="Load External Subtitle File", parent=self.window, action=Gtk.FileChooserAction.OPEN,
                buttons=(Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL, Gtk.STOCK_OPEN, Gtk.ResponseType.OK),
            )
            filt = Gtk.FileFilter()
            filt.set_name("Subtitle files")
            for ext in SUBTITLE_EXTENSIONS:
                filt.add_pattern(f"*{ext}")
                filt.add_pattern(f"*{ext.upper()}")
            dialog.add_filter(filt)
            response = dialog.run()
            if response == Gtk.ResponseType.OK:
                selected = Path(dialog.get_filename())
                if selected.is_file():
                    self.subtitles_enabled = True
                    self.config["subtitles_enabled"] = True
                    self.subtitle_user_enabled_for_current = True
                    save_config(self.config)
                    if self.subtitle_menu_item is not None and not self.subtitle_menu_item.get_active():
                        self.subtitle_menu_item.set_active(True)
                    current = self._current_item()
                    media_path = self._resolve_item_play_path(current) if current else None
                    self.manual_subtitle_path = str(selected)
                    self.manual_subtitle_media_path = str(media_path) if media_path is not None else None
                    self.subtitle_user_enabled_for_current = True
                    self._set_subtitle_text_flag(True)
                    self._set_playbin_property_safe("suburi", selected.resolve().as_uri())
                    self.current_subtitle_path = str(selected)
                    self._set_subtitle_status(selected.name)
                    self._set_status(f"Loaded external subtitles: {selected.name}")
                    audit("subtitle_external", f"manual-load:{selected}")
                else:
                    self._set_status("Selected subtitle file does not exist.")
            dialog.destroy()

        def _resolve_item_play_path(self, item: MediaItem) -> Optional[Path]:
            normalized = normalise_media_argument(item.path) or item.path
            path = Path(os.path.expanduser(normalized))
            if path.is_file():
                return path
            # Some older index exports stored a stale/relative path.  As a bounded
            # fallback, search common user media folders by basename so Library
            # tile playback can recover without polluting the catalogue.
            name = Path(str(normalized)).name
            if not name:
                return None
            roots = [Path.home() / "Videos", Path.home() / "Music", Path.home() / "Downloads"]
            for root in roots:
                try:
                    if not root.is_dir():
                        continue
                    for candidate in root.rglob(name):
                        if candidate.is_symlink():
                            continue
                        if candidate.is_file() and is_media_path(str(candidate)):
                            audit("library_play_resolved_path", f"{item.path} -> {candidate}", "ok")
                            item.path = str(candidate)
                            return candidate
                except Exception as exc:
                    audit("library_play_resolve_scan", f"{root}: {exc}", "warning")
            return None

        def _open_ebook_item(self, item: MediaItem, media_path: Path) -> bool:
            try:
                subprocess.Popen(["xdg-open", str(media_path)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                self.current_index = self.items.index(item) if item in self.items else self.current_index
                self._set_status(f"Opening eBook externally: {item.title}")
                self._refresh_current_nerd_stats(allow_online=False)
                audit("open_ebook", str(media_path))
                return True
            except Exception as exc:
                self._set_status(f"Could not open eBook externally: {exc}")
                audit("open_ebook", f"{media_path}: {exc}", "error")
                return False

        def _play_index(self, index: int) -> bool:
            if self.playbin is None:
                self._set_status("GStreamer playback pipeline is unavailable.")
                return False
            if index < 0 or index >= len(self.items):
                return False
            item = self.items[index]
            media_path = self._resolve_item_play_path(item)
            if media_path is None or not media_path.is_file():
                self._set_status(f"Missing media file: {item.path}")
                audit("play_missing_file", item.path, "error")
                return False
            if item.media_type == "ebook":
                return self._open_ebook_item(item, media_path)
            # Save the previous position before switching tracks, then stop and
            # reconfigure the visual surface. This avoids stale GStreamer surfaces
            # while preserving a local Continue Last resume point.
            self._remember_playback_position(force=True)
            try:
                self.playbin.set_state(Gst.State.NULL)
            except Exception as exc:
                audit("play_stop_before_switch", str(exc), "warning")
            item.media_type = classify_media_path(str(media_path)) or item.media_type
            self.current_index = index
            self.subtitle_user_enabled_for_current = False
            self._menu_set_page(1)
            if item.media_type == "audio":
                if self.is_fullscreen:
                    self._exit_fullscreen()
                self._show_audio_now_playing(item)
            else:
                self._show_video_surface_for_item()
            uri = media_path.absolute().as_uri()
            try:
                self.playbin.set_property("uri", uri)
                self._prepare_subtitles_for_media(media_path)
                resume_at = self._resume_seconds_for_path(media_path)
                result = self.playbin.set_state(Gst.State.PLAYING)
                if resume_at > 0:
                    GLib.timeout_add(750, self._resume_current_after_start, resume_at, item.title)
            except Exception as exc:
                self._set_status(f"Playback failed to start: {exc}")
                audit("play_start_exception", f"{item.path}: {exc}", "error")
                return False
            self.last_position_seconds = 0.0
            self.last_duration_seconds = item.duration_seconds()
            self._set_status(f"Playing {item.media_type}: {item.title}")
            self._update_marker_label(item)
            self._refresh_current_nerd_stats(allow_online=bool(self.config.get("nerd_stats_online_lookup", False)))
            audit("play", f"{item.media_type}:{item.path}:state={result.value_nick if hasattr(result, 'value_nick') else result}; sink={self.video_sink_name or 'default'}")
            try:
                if result == Gst.StateChangeReturn.FAILURE:
                    self._set_status("Playback failed to start. Check GStreamer codec/video sink packages with sentinel-media-player-playback-status.")
                    return False
            except Exception:
                if "failure" in str(result).lower():
                    self._set_status("Playback failed to start. Check GStreamer codec/video sink packages with sentinel-media-player-playback-status.")
                    return False
            return True

        def _update_marker_label(self, item: MediaItem) -> None:
            intro = "none"
            if item.has_intro_marker():
                intro = f"{format_seconds(item.marker_seconds('intro_start') or 0)}  {format_seconds(item.marker_seconds('intro_end'))}"
            credits = "none"
            if item.has_credits_marker():
                start = item.marker_seconds("credits_start")
                end = item.marker_seconds("credits_end")
                credits = f"{format_seconds(start)}  {format_seconds(end)}" if end is not None else f"starts {format_seconds(start)}"
            if self.marker_label is not None:
                self.marker_label.set_text(f"Markers · Intro: {intro} · Credits: {credits}")

        def _query_position_seconds(self) -> tuple[Optional[float], Optional[float]]:
            if self.playbin is None:
                return self.last_position_seconds, self.last_duration_seconds
            try:
                ok_pos, pos = self.playbin.query_position(Gst.Format.TIME)
                ok_dur, dur = self.playbin.query_duration(Gst.Format.TIME)
                position = pos / Gst.SECOND if ok_pos else self.last_position_seconds
                duration = dur / Gst.SECOND if ok_dur and dur > 0 else self.last_duration_seconds
                if position is not None:
                    self.last_position_seconds = float(position)
                if duration is not None:
                    self.last_duration_seconds = float(duration)
                return position, duration
            except Exception:
                return self.last_position_seconds, self.last_duration_seconds

        def _seek_seconds(self, seconds: float) -> bool:
            if self.playbin is None:
                return False
            _position, duration = self._query_position_seconds()
            target = max(0.0, float(seconds))
            if duration is not None and duration > 0:
                target = min(target, max(0.0, duration - 0.05))
            target_ns = max(0, int(target * Gst.SECOND))
            ok = False
            try:
                ok = bool(self.playbin.seek_simple(Gst.Format.TIME, Gst.SeekFlags.FLUSH | Gst.SeekFlags.ACCURATE, target_ns))
            except Exception as exc:
                audit("seek_accurate", str(exc), "warning")
            if not ok:
                try:
                    ok = bool(self.playbin.seek_simple(Gst.Format.TIME, Gst.SeekFlags.FLUSH | Gst.SeekFlags.KEY_UNIT, target_ns))
                except Exception as exc:
                    audit("seek_key_unit", str(exc), "error")
                    ok = False
            if ok:
                self.last_position_seconds = target
                if self.position_scale is not None and not self.seek_dragging:
                    try:
                        self.position_scale.set_value(target)
                    except Exception:
                        pass
                self._update_time_label(target, duration)
            return ok

        def _skip_relative(self, delta_seconds: float, reason: str = "seek_relative") -> None:
            if self.current_index < 0:
                self._set_status("No media is playing yet. Select a Library tile or double-click a queue item first.")
                return
            position, duration = self._query_position_seconds()
            if position is None and self.position_scale is not None:
                try:
                    position = float(self.position_scale.get_value())
                except Exception:
                    position = 0.0
            target = (position or 0.0) + delta_seconds
            if duration is not None:
                target = min(max(0.0, target), max(0.0, duration - 0.05))
            else:
                target = max(0.0, target)
            ok = self._seek_seconds(target)
            direction = "forward" if delta_seconds >= 0 else "back"
            if ok:
                self._set_status(f"Skipped {direction} {abs(int(delta_seconds))} seconds to {format_seconds(target)}.")
                audit(reason, f"{delta_seconds:+.0f}s -> {target:.2f}")
            else:
                self._set_status("Seek failed. The current codec/container may not be seekable yet, or playback is not ready.")
                audit(reason, f"seek failed {delta_seconds:+.0f}s -> {target:.2f}", "warning")

        def _refresh_position(self) -> bool:
            if self.playbin is None:
                return True
            position, duration = self._query_position_seconds()
            if duration and self.position_scale is not None and not self.seek_dragging:
                self.position_scale.set_range(0, duration)
                self.position_scale.set_value(position or 0)
            self._update_time_label(position, duration)
            self._auto_skip_intro_if_needed(position)
            self._remember_playback_position(force=False)
            return True

        def _update_time_label(self, position: Optional[float], duration: Optional[float]) -> None:
            if self.position_time_label is None:
                return
            if duration is None:
                self.position_time_label.set_text(f"Played {format_seconds(position or 0)} · Left --:-- · Total --:--")
                return
            played = max(0.0, position or 0.0)
            left = max(0.0, duration - played)
            self.position_time_label.set_text(f"Played {format_seconds(played)} · Left {format_seconds(left)} · Total {format_seconds(duration)}")

        def _auto_skip_intro_if_needed(self, position: Optional[float]) -> None:
            if position is None or not bool(self.config.get("auto_skip_intro", True)):
                return
            if self.current_index in self.intro_skipped_for_index:
                return
            item = self._current_item()
            if not item:
                return
            intro_start = item.marker_seconds("intro_start") or 0.0
            intro_end = item.marker_seconds("intro_end")
            if intro_end is None or intro_end <= intro_start:
                return
            if intro_start <= position < intro_end:
                self._seek_seconds(intro_end)
                self.intro_skipped_for_index.add(self.current_index)
                self._set_status(f"Auto skipped intro to {format_seconds(intro_end)} for: {item.title}")
                audit("auto_skip_intro", f"{item.title} -> {intro_end}")

        def _on_skip_back(self, _button=None) -> None:
            self._skip_relative(-float(self.skip_step_seconds), "skip_back")

        def _on_skip_forward(self, _button=None) -> None:
            self._skip_relative(float(self.skip_step_seconds), "skip_forward")

        def _on_skip_intro(self, _button) -> None:
            item = self._current_item()
            if not item:
                self._set_status("No item selected for Skip Intro.")
                return
            position, _duration = self._query_position_seconds()
            intro_end = item.marker_seconds("intro_end")
            if intro_end is not None and (position is None or position < intro_end):
                self._seek_seconds(intro_end)
                self._set_status(f"Skipped intro to {format_seconds(intro_end)}.")
                audit("manual_skip_intro_marker", item.title)
            else:
                fallback = float(self.config.get("manual_intro_skip_seconds", 85) or 85)
                self._seek_seconds((position or 0) + fallback)
                self._set_status(f"No intro marker available; skipped forward {int(fallback)} seconds manually.")
                audit("manual_skip_intro_fallback", item.title, "warning")

        def _on_skip_credits(self, _button) -> None:
            item = self._current_item()
            if not item:
                self._set_status("No item selected for Skip Credits.")
                return
            position, duration = self._query_position_seconds()
            credits_end = item.marker_seconds("credits_end")
            credits_start = item.marker_seconds("credits_start")
            if credits_end is not None and (position is None or position < credits_end):
                self._seek_seconds(credits_end)
                self._set_status(f"Skipped credits to {format_seconds(credits_end)}.")
                audit("manual_skip_credits_marker", item.title)
            elif credits_start is not None and duration is not None:
                self._seek_seconds(max(credits_start, duration - 2))
                self._set_status("Skipped to the end credits/end of item.")
                audit("manual_skip_credits_start", item.title)
            else:
                qpos = self._queue_position_for_current()
                if qpos is not None and qpos + 1 < len(self.queue_indices):
                    self._play_index(self.queue_indices[qpos + 1])
                    self._set_status("No credits marker available; moved to next queued item.")
                    audit("manual_skip_credits_next_queue", item.title, "warning")
                elif self.current_index + 1 < len(self.items):
                    self._play_index(self.current_index + 1)
                    self._set_status("No credits marker available; moved to next catalogue item.")
                    audit("manual_skip_credits_next_catalogue", item.title, "warning")
                elif duration is not None:
                    self._seek_seconds(max(0, duration - 2))
                    self._set_status("No next item; skipped to end.")
                    audit("manual_skip_credits_end", item.title, "warning")

        def _on_previous(self, _button=None) -> None:
            if not self.items:
                return
            qpos = self._queue_position_for_current()
            if qpos is not None and qpos > 0:
                self._play_index(self.queue_indices[qpos - 1])
            else:
                self._play_index(max(0, self.current_index - 1))

        def _on_next(self, _button=None) -> None:
            if not self.items:
                return
            qpos = self._queue_position_for_current()
            if qpos is not None and qpos + 1 < len(self.queue_indices):
                self._play_index(self.queue_indices[qpos + 1])
            else:
                self._play_index(min(len(self.items) - 1, self.current_index + 1))

        def _on_play_pause(self, _button=None) -> None:
            if self.playbin is None:
                return
            if self.current_index < 0:
                selected = self._selected_queue_item_index()
                if selected is None and self.queue_indices:
                    selected = self.queue_indices[0]
                self._play_index(selected if selected is not None else 0)
                return
            _ret, state, _pending = self.playbin.get_state(0)
            if state == Gst.State.PLAYING:
                self.playbin.set_state(Gst.State.PAUSED)
                self._set_status("Paused.")
            else:
                self.playbin.set_state(Gst.State.PLAYING)
                self._set_status("Playing.")

        def _on_stop(self, _button=None) -> None:
            self._remember_playback_position(force=True)
            if self.playbin is not None:
                self.playbin.set_state(Gst.State.NULL)
            self._set_status("Stopped.")

        def _on_fullscreen_toggle(self, _button=None) -> None:
            if self.is_fullscreen:
                self._exit_fullscreen()
                return
            if self._attach_video_to_fullscreen():
                self.is_fullscreen = True
                if self.fullscreen_button is not None:
                    self.fullscreen_button.set_label("Exit Fullscreen")
                self._set_status("Video-only fullscreen enabled. Press Escape or F11 in the video window to return.")
                audit("video_only_fullscreen", "on")

        def _exit_fullscreen(self) -> None:
            if not self.is_fullscreen:
                return
            try:
                if self.fullscreen_window is not None:
                    self.fullscreen_window.unfullscreen()
            except Exception:
                pass
            self._attach_video_to_embedded()
            try:
                if self.fullscreen_window is not None:
                    self.fullscreen_window.hide()
            except Exception:
                pass
            self.is_fullscreen = False
            if self.fullscreen_button is not None:
                self.fullscreen_button.set_label("Fullscreen")
            self._set_status("Exited video-only fullscreen.")
            audit("video_only_fullscreen", "off")

        def _on_volume_changed(self, scale) -> None:
            if self.playbin is not None:
                self.playbin.set_property("volume", scale.get_value() / 100.0)

        def _adjust_volume(self, delta: float) -> None:
            if self.volume_scale is None:
                return
            new_value = min(100.0, max(0.0, self.volume_scale.get_value() + delta))
            self.volume_scale.set_value(new_value)
            self._set_status(f"Volume {int(new_value)}%.")

        def _on_seek_press(self, *_args):
            self.seek_dragging = True
            return False

        def _on_seek_release(self, *_args):
            self.seek_dragging = False
            if self.playbin is not None and self.position_scale is not None:
                self._seek_seconds(float(self.position_scale.get_value()))
            return False

        def _on_video_button_press(self, widget, event) -> bool:
            try:
                allocation = widget.get_allocation()
                side = "left" if event.x < (allocation.width / 2.0) else "right"
                event_time = int(getattr(event, "time", 0) or 0)
                if self.last_video_click_time and 0 <= event_time - self.last_video_click_time <= 420:
                    # v0.4.1 resolves the gesture conflict by making double-tap on
                    # the video surface behave like VLC/Kodi: toggle video-only
                    # fullscreen, then double-tap again to return.  Ten-second seek
                    # remains on buttons, keyboard arrows, and Fn rewind/forward.
                    self.last_video_click_time = 0
                    self.last_video_click_side = None
                    if self.video_double_tap_action == "fullscreen_toggle":
                        self._on_fullscreen_toggle()
                        audit("video_double_tap_fullscreen_toggle", "on" if self.is_fullscreen else "off")
                        return True
                    return False
                self.last_video_click_time = event_time
                self.last_video_click_side = side
            except Exception as exc:
                audit("video_double_tap", str(exc), "warning")
            return False

        def _on_key_press(self, _widget, event) -> bool:
            key = Gdk.keyval_name(event.keyval) or ""
            state = event.state or 0
            ctrl = bool(state & Gdk.ModifierType.CONTROL_MASK)
            key_lower = key.lower()
            if ctrl and key_lower == "q":
                self.quit()
                return True
            if ctrl and key_lower == "f":
                self._on_focus_library_search()
                return True
            if key in ("Escape",) and not self.is_fullscreen and self._library_search_query():
                self._on_clear_library_search()
                return True
            if key in ("F11",):
                self._on_fullscreen_toggle()
                return True
            if key in ("Escape",) and self.is_fullscreen:
                self._exit_fullscreen()
                return True
            if key in ("space", "KP_Space", "XF86AudioPlay", "XF86AudioPause", "XF86AudioMedia", "AudioPlay", "AudioPause"):
                self._on_play_pause()
                return True
            if key in ("XF86AudioStop", "AudioStop"):
                self._on_stop()
                return True
            if key in ("Left", "KP_Left", "XF86AudioRewind", "AudioRewind"):
                self._on_skip_back()
                return True
            if key in ("Right", "KP_Right", "XF86AudioForward", "AudioForward"):
                self._on_skip_forward()
                return True
            if key in ("Up", "KP_Up"):
                self._adjust_volume(5)
                return True
            if key in ("Down", "KP_Down"):
                self._adjust_volume(-5)
                return True
            if key_lower == "s":
                if bool(getattr(self, "subtitles_enabled", True)):
                    self._on_remove_subtitles()
                else:
                    self.subtitles_enabled = True
                    self.config["subtitles_enabled"] = True
                    self.subtitle_user_enabled_for_current = True
                    save_config(self.config)
                    current = self._current_item()
                    if current:
                        media_path = self._resolve_item_play_path(current)
                        if media_path is not None:
                            self._prepare_subtitles_for_media(media_path)
                    self._set_status("Subtitles enabled from keyboard shortcut S.")
                return True
            if key in ("XF86AudioPrev", "XF86AudioPrevious", "AudioPrev", "AudioPrevious"):
                self._on_previous()
                return True
            if key in ("XF86AudioNext", "AudioNext"):
                self._on_next()
                return True
            return False

        def _playback_error_hint(self, message: str, debug: str = "") -> str:
            text = f"{message} {debug}".lower()
            if any(token in text for token in ("missing", "not found", "no suitable", "decoder", "demux", "streaming stopped, reason not-linked", "not-negotiated")):
                return "Install or repair GStreamer codec plugins: gstreamer1.0-libav, plugins-bad, plugins-ugly, plugins-good/base. Run sentinel-media-player-playback-status for a local check."
            if any(token in text for token in ("resource", "not-found", "no such file", "permission")):
                return "Check that the Media Index path still exists and is readable, then Refresh Library."
            return "Run sentinel-media-player-playback-status to check the local GStreamer runtime."

        def _on_bus_message(self, _bus, message) -> None:
            t = message.type
            if t == Gst.MessageType.EOS:
                if self.autoadvance:
                    qpos = self._queue_position_for_current()
                    if qpos is not None and qpos + 1 < len(self.queue_indices):
                        self._play_index(self.queue_indices[qpos + 1])
                    elif self.current_index + 1 < len(self.items):
                        self._play_index(self.current_index + 1)
                    else:
                        self._set_status("End of media.")
                else:
                    self._set_status("End of media.")
            elif t == Gst.MessageType.ERROR:
                err, debug = message.parse_error()
                hint = self._playback_error_hint(err.message, str(debug or ""))
                self._set_status(f"Playback error: {err.message}. {hint}")
                audit("playback_error", f"{err.message}; {debug}; hint={hint}", "error")

        def _on_row_activated(self, _tree, path, _column) -> None:
            pos = int(path.get_indices()[0])
            if 0 <= pos < len(self.queue_indices):
                self._play_index(self.queue_indices[pos])
                self._menu_set_page(1)

        def _on_open_files(self, _button) -> None:
            dialog = Gtk.FileChooserDialog(
                title="Open Media Files", parent=self.window, action=Gtk.FileChooserAction.OPEN,
                buttons=(Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL, Gtk.STOCK_OPEN, Gtk.ResponseType.OK),
            )
            dialog.set_select_multiple(True)
            response = dialog.run()
            if response == Gtk.ResponseType.OK:
                items: List[MediaItem] = []
                for fname in dialog.get_filenames():
                    if is_media_path(fname):
                        p = Path(fname)
                        items.append(MediaItem(path=str(p), title=p.stem, media_type=classify_media_path(str(p)), source="file chooser"))
                added = self._append_items(items, add_to_queue=True)
                if added and self.current_index < 0:
                    self._play_index(added[0])
            dialog.destroy()

        def _on_open_folder(self, _button) -> None:
            dialog = Gtk.FileChooserDialog(
                title="Open Media Folder", parent=self.window, action=Gtk.FileChooserAction.SELECT_FOLDER,
                buttons=(Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL, Gtk.STOCK_OPEN, Gtk.ResponseType.OK),
            )
            response = dialog.run()
            if response == Gtk.ResponseType.OK:
                self._append_items(scan_folder(dialog.get_filename()), add_to_queue=True)
            dialog.destroy()

        def _on_load_media_index(self, _button) -> None:
            self._on_refresh_simple_library(_button)

        def _on_clear(self, _button=None) -> None:
            # Backward-compatible menu/button hook: clear only the explicit queue.
            self._on_clear_queue()

        def _on_auto_intro_toggled(self, check) -> None:
            self.config["auto_skip_intro"] = bool(check.get_active())
            save_config(self.config)
            if self.auto_intro_menu_item is not None and self.auto_intro_menu_item.get_active() != self.config["auto_skip_intro"]:
                self.auto_intro_menu_item.set_active(self.config["auto_skip_intro"])
            self._set_status(f"Auto Skip Intro {'enabled' if self.config['auto_skip_intro'] else 'disabled'}.")

        def _on_online_default_toggled(self, check) -> None:
            self.config["nerd_stats_online_lookup"] = bool(check.get_active())
            save_config(self.config)
            if self.online_stats_menu_item is not None and self.online_stats_menu_item.get_active() != self.config["nerd_stats_online_lookup"]:
                self.online_stats_menu_item.set_active(self.config["nerd_stats_online_lookup"])
            self._set_status(f"Player fallback online lookup {'enabled' if self.config['nerd_stats_online_lookup'] else 'disabled'}; Media Index remains the default metadata authority.")

        def _clear_nerd_grid(self) -> None:
            if self.nerd_grid is None:
                return
            for child in list(self.nerd_grid.get_children()):
                self.nerd_grid.remove(child)

        def _add_nerd_row(self, row: int, key: str, value: str) -> None:
            if self.nerd_grid is None or value in (None, ""):
                return
            key_label = Gtk.Label(label=key)
            key_label.set_name("sentinelNerdField")
            key_label.set_xalign(0)
            val_label = Gtk.Label(label=str(value))
            val_label.set_name("sentinelNerdValue")
            val_label.set_xalign(0)
            val_label.set_line_wrap(True)
            val_label.set_selectable(True)
            self.nerd_grid.attach(key_label, 0, row, 1, 1)
            self.nerd_grid.attach(val_label, 1, row, 1, 1)

        def _render_nerd_stats(self, payload: dict, item: Optional[MediaItem] = None) -> None:
            item = item or self._current_item()
            local = payload.get("local", {}) if isinstance(payload, dict) else {}
            online = payload.get("online", {}) if isinstance(payload, dict) else {}
            title = item.title if item else str(local.get("title") or "Nerd Stats")
            if self.nerd_title_label is not None:
                safe_title = GLib.markup_escape_text(title)
                self.nerd_title_label.set_markup(f"<span size='large' weight='bold'>Nerd Stats · {safe_title}</span>")
            subtitle_bits = []
            if item:
                subtitle_bits.append(item.media_type.title())
                if item.year:
                    subtitle_bits.append(str(item.year)[:4])
                if item.series:
                    subtitle_bits.append(item.series)
                if item.season or item.episode:
                    subtitle_bits.append(f"S{str(item.season or '?').zfill(2)}E{str(item.episode or '?').zfill(2)}")
                if item.duration:
                    subtitle_bits.append(format_seconds(item.duration_seconds()) if item.duration_seconds() is not None else item.duration)
            if online:
                subtitle_bits.append("fallback online lookup attached")
            else:
                subtitle_bits.append("Media Index metadata")
            if self.nerd_subtitle_label is not None:
                self.nerd_subtitle_label.set_text(" · ".join([b for b in subtitle_bits if b]))
            self._clear_nerd_grid()
            rows = []
            if item:
                rows.extend([
                    ("Path", item.path),
                    ("Source", item.source),
                    ("Type", item.media_type),
                    ("Artist", item.artist),
                    ("Album", item.album),
                    ("Genre", item.genre),
                    ("Collection", item.collection),
                    ("Resolution", item.resolution),
                    ("Progress", item.progress),
                    ("Watched", item.watched),
                    ("Rating", getattr(item, "rating", "")),
                    ("Director", getattr(item, "director", "")),
                    ("Creator", getattr(item, "creator", "")),
                    ("Metadata Authority", "Sentinel Media Index"),
                    ("Metadata Source", getattr(item, "metadata_source", "") or item.source),
                    ("Metadata Provider", getattr(item, "metadata_provider", "")),
                    ("Metadata Status", getattr(item, "metadata_status", "")),
                    ("Enriched At", getattr(item, "metadata_enriched_at", "")),
                    ("Poster", item.poster_path),
                    ("Thumbnail", item.thumbnail_path),
                ])
            # Surface a few friendly local stats if nerd_stats() extracted them.
            if isinstance(local, dict):
                for key in ("kind", "exists", "size", "extension", "modified", "query"):
                    if key in local and local[key] not in (None, ""):
                        rows.append((key.replace("_", " ").title(), str(local[key])))
            for row_i, (key, value) in enumerate([(k, v) for k, v in rows if v not in (None, "")][:18]):
                self._add_nerd_row(row_i, key, str(value))
            if self.nerd_grid is not None:
                self.nerd_grid.show_all()
            pretty = []
            pretty.append("Nerd Stats Detail")
            pretty.append("=" * 17)
            if item and item.description:
                pretty.append("\nDescription\n-----------")
                pretty.append(item.description)
            if item:
                pretty.append("\nMetadata Authority\n------------------")
                pretty.append("Sentinel Media Index is the default metadata authority. Player online lookup is fallback/manual only.")
                if getattr(item, "metadata_source", "") or getattr(item, "metadata_provider", "") or getattr(item, "metadata_enriched_at", ""):
                    pretty.append(f"Source: {getattr(item, 'metadata_source', '') or item.source}")
                    pretty.append(f"Provider: {getattr(item, 'metadata_provider', '')}")
                    pretty.append(f"Enriched: {getattr(item, 'metadata_enriched_at', '')}")
            pretty.append("\nRaw metadata\n------------")
            pretty.append(json.dumps(payload, indent=2, sort_keys=True)[:120000])
            self._set_text(self.nerd_text, "\n".join(pretty))

        def _refresh_current_nerd_stats(self, allow_online: bool = False) -> None:
            item = self._current_item()
            if not item or self.nerd_text is None:
                return
            try:
                payload = nerd_stats(item.path or item.title, allow_online=allow_online)
                payload["local"] = nerd_stats(item.title or item.path, allow_online=False)["local"] if not item.path else payload["local"]
                self._render_nerd_stats(payload, item)
            except Exception as exc:
                self._set_text(self.nerd_text, f"Nerd Stats error: {exc}")
                audit("nerd_stats_gui", str(exc), "error")

        def _on_artwork_audit_current(self, _button=None) -> None:
            item = self._current_item()
            if not item:
                self._set_status("No current media selected for artwork audit.")
                self._menu_set_page(3)
                return
            payload = self._artwork_audit_for_item(item)
            self._menu_set_page(3)
            if self.nerd_title_label is not None:
                self.nerd_title_label.set_markup("<span size='large' weight='bold'>Artwork Audit</span>")
            if self.nerd_subtitle_label is not None:
                self.nerd_subtitle_label.set_text("Shows exactly where Sentinel Media Player is looking for cover art and what it found.")
            self._clear_nerd_grid()
            for row_i, (key, value) in enumerate([
                ("Title", payload.get("title")),
                ("Media Type", payload.get("media_type")),
                ("Resolved Artwork", payload.get("resolved_artwork") or "none"),
                ("Thumbnail Cache Hit", payload.get("thumbnail_cache_hit")),
                ("Source", payload.get("source")),
            ]):
                self._add_nerd_row(row_i, key, str(value))
            if self.nerd_grid is not None:
                self.nerd_grid.show_all()
            self._set_text(self.nerd_text, json.dumps(payload, indent=2, sort_keys=True))
            self._set_status("Artwork audit complete. See Nerd Stats workspace.")

        def _manual_retrieve_art_for_item(self, item: MediaItem, *, rebuild: bool = True) -> dict:
            """User-triggered artwork recovery for one media item.

            This is intentionally separate from startup artwork loading. It may run
            heavier local checks only after the user presses Retrieve Art, so the
            library stays fast and crash-safe by default.
            """
            payload = self._artwork_audit_for_item(item, limit=140)
            before = payload.get("resolved_artwork") or ""
            retrieved = before
            source = "already_resolved" if before else "none"
            try:
                # Clear cached negative/old lookups for this item.
                prefix = f"{item.path}|"
                for key in list(self.artwork_resolution_cache.keys()):
                    if key.startswith(prefix):
                        self.artwork_resolution_cache.pop(key, None)

                # 1. Try deterministic fields/sidecars and Caja cache again.
                retrieved = self._item_art_path(item)
                source = "safe_lookup" if retrieved else "none"

                # 2. User-triggered bounded recursive search.
                if not retrieved:
                    retrieved = self._find_recursive_art(item)
                    source = "bounded_recursive_scan" if retrieved else source

                # 3. User-triggered heavy local generation/extraction only for this item.
                if not retrieved and item.media_type == "audio":
                    retrieved = self._extract_embedded_audio_art(item) or self._extract_audio_art_with_ffmpeg(item)
                    source = "embedded_or_ffmpeg_audio_art" if retrieved else source
                if not retrieved and item.media_type == "video":
                    retrieved = self._generate_video_thumbnail(item)
                    source = "local_video_thumbnail_generation" if retrieved else source

                # 4. User-triggered online artwork lookup. This never runs at startup.
                if not retrieved:
                    online_payload = retrieve_online_art_for_item(item)
                    retrieved = str(online_payload.get("retrieved_artwork") or "")
                    source = "manual_online_art_lookup" if retrieved else source

                if retrieved:
                    # Store on the runtime item so the current session reflects it immediately.
                    if item.media_type == "audio":
                        item.thumbnail_path = retrieved
                    elif item.media_type == "video":
                        item.poster_path = retrieved
                    else:
                        item.thumbnail_path = retrieved
                    self.artwork_resolution_cache[f"{item.path}|manual"] = retrieved
            except Exception as exc:
                audit("manual_retrieve_art", f"{item.path}: {exc}", "error")
                source = f"error: {exc}"

            after_payload = self._artwork_audit_for_item(item, limit=140)
            after_payload.update({
                "manual_retrieve_art": True,
                "before_resolved_artwork": before,
                "retrieved_artwork": retrieved or "",
                "retrieve_source": source,
                "startup_safe_policy": "Heavy artwork recovery remains disabled at startup; this was user-triggered only.",
                "media_index_note": "Sentinel Media Index supplies the file catalogue/backend metadata. Sentinel Media Player owns manual online artwork retrieval and caches images locally without mutating the index.",
            })
            if rebuild:
                self._rebuild_library()
            return after_payload

        def _render_artwork_payload(self, payload: dict, title: str = "Retrieve Art") -> None:
            self._menu_set_page(3)
            if self.nerd_title_label is not None:
                self.nerd_title_label.set_markup(f"<span size='large' weight='bold'>{title}</span>")
            if self.nerd_subtitle_label is not None:
                self.nerd_subtitle_label.set_text("Manual artwork recovery completed. Heavy recovery only runs when the user requests it.")
            self._clear_nerd_grid()
            rows = [
                ("Title", payload.get("title")),
                ("Media Type", payload.get("media_type")),
                ("Retrieved Artwork", payload.get("retrieved_artwork") or payload.get("resolved_artwork") or "none"),
                ("Retrieve Source", payload.get("retrieve_source") or payload.get("source") or "none"),
                ("Media Index Note", payload.get("media_index_note") or "Index artwork fields remain preferred."),
            ]
            for row_i, (key, value) in enumerate(rows):
                self._add_nerd_row(row_i, key, str(value))
            if self.nerd_grid is not None:
                self.nerd_grid.show_all()
            self._set_text(self.nerd_text, json.dumps(payload, indent=2, sort_keys=True))

        def _online_art_profile_payload(self) -> dict:
            payload = online_art_profile()
            payload.update({
                "app": APP_NAME,
                "version": VERSION,
                "bulk_limit": self.online_art_bulk_limit,
                "bulk_run_mode": "background worker; cheap main-thread queueing; no full board rebuild on finish",
                "bulk_art_fix_v8": "video preview thumbnails/Caja cache are not counted as movie poster cover art",
                "first_start_auto_retrieve_art": self.first_start_auto_retrieve_art,
                "first_start_auto_retrieve_art_done": self.first_start_auto_retrieve_art_done,
                "first_start_policy_v9": "auto-run Retrieve All Art once after first successful Library scan, then manual only",
                "tile_art_buttons": False,
                "library_button": "Retrieve All Art",
                "current_item_button": "Nerd Stats Retrieve Art",
                "index_relation": "Player consumes the fast Library file grid as backend data and renders its own Library view; online artwork cache is Player-owned and does not mutate Media Index.",
            })
            return payload

        def _on_online_art_profile_dialog(self, _button=None) -> None:
            self._dialog("Online Artwork Retrieval", json.dumps(self._online_art_profile_payload(), indent=2, sort_keys=True))

        def _item_has_fast_art_reference(self, item: MediaItem) -> bool:
            # Cheap main-thread-safe check.  Do not call _item_art_path() here:
            # that may touch filesystem caches or sidecars and made the button
            # feel frozen on large libraries.  The worker performs safe resolution.
            for raw in (item.poster_path, item.thumbnail_path, item.cover_path, item.album_art_path, item.artwork_path, item.fanart_path):
                if str(raw or "").strip():
                    return True
            return False

        def _items_missing_art(self) -> List[MediaItem]:
            # Kept for diagnostics, but intentionally cheap.
            return [item for item in list(self.items) if item.media_type in ("audio", "video") and not self._item_has_true_cover_art(item)]

        def _is_real_cover_art_path(self, item: MediaItem, raw: str, *, allow_thumbnail: bool = False) -> bool:
            """Return True only for real cover/poster artwork, not generated video previews.

            v0.5.8 fix: local video preview thumbnails and Caja thumbnail-cache
            images are useful visual previews, but they are not movie posters.
            Bulk Retrieve All Art must not count those as already-local poster art,
            otherwise movie online retrieval never runs.
            """
            text = str(raw or "").strip()
            if not text:
                return False
            path = Path(os.path.expanduser(text))
            if not path.is_absolute() and item.path:
                path = Path(os.path.expanduser(item.path)).parent / path
            if not path.is_file() or not self._looks_like_image(path):
                return False
            lowered = str(path).lower()
            name = path.name.lower()
            # Never treat desktop-generated frame thumbnails as cover/poster art.
            if "/.cache/thumbnails/" in lowered or "/.thumbnails/" in lowered:
                return False
            # Player-generated local video thumbnails are previews, not posters.
            if "/video-thumbnails/" in lowered:
                return False
            if item.media_type == "video":
                posterish = ("poster", "cover", "folder", "front", "movie", "tmdb", "omdb", "imdb", "backdrop", "fanart")
                if any(k in name or k in lowered for k in posterish):
                    return True
                return bool(allow_thumbnail and any(k in lowered for k in ("/online-art/", "/artwork/", "/posters/", "/covers/")))
            if item.media_type == "audio":
                coverish = ("cover", "folder", "front", "album", "albumart", "musicbrainz", "coverartarchive")
                if any(k in name or k in lowered for k in coverish):
                    return True
                return bool(allow_thumbnail and any(k in lowered for k in ("/online-art/", "/artwork/", "/covers/")))
            return True

        def _mark_first_start_art_done(self, reason: str = "attempted") -> None:
            try:
                self.config["first_start_auto_retrieve_art_done"] = True
                self.config["first_start_auto_retrieve_art_done_reason"] = reason
                save_config(self.config)
                self.first_start_auto_retrieve_art_done = True
                audit("first_start_auto_retrieve_art_done", reason)
            except Exception as exc:
                audit("first_start_auto_retrieve_art_done", str(exc), "warning")

        def _maybe_schedule_first_start_art_retrieve(self) -> None:
            """Run Retrieve All Art once after the first successful Library scan.

            This is deliberately scheduled *after* the fast catalogue board exists
            so it does not block startup.  The one-shot flag is persisted whether
            providers are configured or not; every later run is manual.
            """
            if not self.first_start_auto_retrieve_art:
                return
            if self.first_start_auto_retrieve_art_done or self.first_start_auto_retrieve_art_scheduled:
                return
            if not self.items:
                return
            self.first_start_auto_retrieve_art_scheduled = True
            self._set_status("First startup artwork recovery will run once in the background after the catalogue renders; future runs are manual.")
            GLib.timeout_add(3500, self._run_first_start_auto_retrieve_art)

        def _run_first_start_auto_retrieve_art(self) -> bool:
            if self.retrieve_all_art_in_progress:
                # Try once more shortly if the user already started a run.
                GLib.timeout_add(5000, self._run_first_start_auto_retrieve_art)
                return False
            self._mark_first_start_art_done("queued_once_after_first_catalogue_load")
            self._begin_retrieve_all_art(auto_first_start=True)
            return False

        def _item_has_true_cover_art(self, item: MediaItem) -> bool:
            """Cheap strict cover-art check for bulk retrieval.

            Do not call _item_art_path() here because it intentionally returns
            local preview thumbnails/fallbacks for the visible board. Bulk online
            artwork needs to know whether a true poster/cover exists.
            """
            if item.media_type == "video":
                fields = (item.poster_path, item.cover_path, item.artwork_path, item.album_art_path, item.fanart_path)
                # thumbnail_path is often only a Media Index preview/frame; count it
                # only when the path clearly looks like poster/cover artwork.
                thumb_fields = (item.thumbnail_path,)
            elif item.media_type == "audio":
                fields = (item.album_art_path, item.cover_path, item.artwork_path, item.poster_path, item.thumbnail_path)
                thumb_fields = ()
            else:
                fields = (item.poster_path, item.thumbnail_path, item.cover_path, item.album_art_path, item.artwork_path, item.fanart_path)
                thumb_fields = ()
            for raw in fields:
                if self._is_real_cover_art_path(item, raw):
                    return True
            for raw in thumb_fields:
                if self._is_real_cover_art_path(item, raw, allow_thumbnail=True):
                    return True
            return False

        def _on_retrieve_all_art(self, _button=None) -> None:
            self._begin_retrieve_all_art(auto_first_start=False)

        def _begin_retrieve_all_art(self, auto_first_start: bool = False) -> None:
            if self.retrieve_all_art_in_progress:
                self._set_status("Retrieve All Art is already running in the background. Wait for the current run to finish.")
                return
            # Copy candidates immediately and hand all heavier checks to the worker.
            candidates = [item for item in list(self.items) if item.media_type in ("audio", "video")]
            if not candidates:
                self._set_status("No indexed audio/video items available for artwork retrieval. Press Refresh List first.")
                if auto_first_start:
                    self._mark_first_start_art_done("no_audio_video_items")
                return
            limit = max(1, min(int(self.online_art_bulk_limit or 80), 80))
            batch = candidates[:limit]
            skipped = max(0, len(candidates) - len(batch))
            self.retrieve_all_art_in_progress = True
            self.retrieve_all_art_processed = 0
            self.retrieve_all_art_total = len(batch)
            if self.retrieve_all_art_button is not None:
                self.retrieve_all_art_button.set_sensitive(False)
            mode = "First-start Retrieve All Art" if auto_first_start else "Retrieve All Art"
            self._set_status(f"{mode} queued {len(batch)} item/s in the background. This is one-shot on first startup, then manual only. Videos use TMDb only for poster retrieval. Set a TMDb Bearer token or API key for movie/TV posters; music can use MusicBrainz/Cover Art Archive.")

            def worker() -> None:
                found = 0
                failed = 0
                skipped_existing = 0
                movie_provider_missing = 0
                tried = 0
                for item in batch:
                    try:
                        # v0.5.8: skip only when a true cover/poster exists.
                        # Local video frame previews and Caja thumbnails are not posters.
                        if self._item_has_true_cover_art(item):
                            skipped_existing += 1
                            continue
                        tried += 1
                        payload = retrieve_online_art_for_item(item)
                        art = str(payload.get("retrieved_artwork") or "")
                        if art:
                            if item.media_type == "audio":
                                item.album_art_path = art
                                item.cover_path = art
                                item.thumbnail_path = art
                            elif item.media_type == "video":
                                item.poster_path = art
                                item.thumbnail_path = art
                            else:
                                item.thumbnail_path = art
                            prefix = f"{item.path}|"
                            for key in list(self.artwork_resolution_cache.keys()):
                                if key.startswith(prefix):
                                    self.artwork_resolution_cache.pop(key, None)
                            found += 1
                        else:
                            providers = [str(p) for p in payload.get("providers_tried", [])]
                            if item.media_type == "video" and any(p in providers for p in ("tmdb_missing_credentials", "tmdb_no_match_or_no_poster")):
                                movie_provider_missing += 1
                            failed += 1
                    except Exception as exc:
                        failed += 1
                        audit("retrieve_all_art_item", f"{getattr(item, 'path', '')}: {exc}", "warning")
                    finally:
                        self.retrieve_all_art_processed += 1
                        if self.retrieve_all_art_processed % 3 == 0:
                            GLib.idle_add(self._set_status, f"Retrieve All Art: processed {self.retrieve_all_art_processed}/{len(batch)} · online checked {tried} · downloaded {found} · missing {failed} · true local covers {skipped_existing}")
                GLib.idle_add(self._finish_retrieve_all_art, tried, found, failed, skipped, skipped_existing, movie_provider_missing)

            threading.Thread(target=worker, daemon=True).start()

        def _finish_retrieve_all_art(self, tried: int, found: int, failed: int, skipped: int = 0, skipped_existing: int = 0, movie_provider_missing: int = 0) -> bool:
            self.retrieve_all_art_in_progress = False
            if self.retrieve_all_art_button is not None:
                self.retrieve_all_art_button.set_sensitive(True)
            # Avoid a full immediate board rebuild after a bulk network run; that
            # was another perceived-freeze point.  The user can switch category or
            # press Rebuild Board/Load More when ready.
            extra = f" · {skipped} over the safe batch limit left for next run" if skipped else ""
            provider_note = f" · movie provider missing for {movie_provider_missing}" if movie_provider_missing else ""
            self._set_status(f"Retrieve All Art complete: online checked {tried}, downloaded {found}, missing {failed}, true local covers {skipped_existing}{provider_note}{extra}. Rebuild Board when convenient to refresh visible tiles.")
            if self.library_status_label is not None:
                if movie_provider_missing:
                    self.library_status_label.set_text("Retrieve All Art complete. Video poster lookup uses TMDb only; set a TMDb Bearer token or API key if posters were missing.")
                else:
                    self.library_status_label.set_text("Retrieve All Art complete. Press Rebuild Board to refresh visible cover tiles without blocking playback.")
            return False

        def _on_retrieve_art_current(self, _button=None) -> None:
            item = self._current_item()
            if not item:
                self._set_status("No current media selected for Retrieve Art. Play a Library item first, then use Retrieve Art, or use Retrieve All Art from the Library controls.")
                self._menu_set_page(3)
                return
            self._set_status(f"Retrieving artwork for: {item.title}")
            payload = self._manual_retrieve_art_for_item(item)
            self._render_artwork_payload(payload, "Retrieve Art")
            if payload.get("retrieved_artwork"):
                self._set_status(f"Artwork retrieved for: {item.title}")
            else:
                self._set_status(f"No artwork found for: {item.title}. Media Index enrichment may need to supply poster/cover paths.")

        def _on_retrieve_art_from_library(self, _button, index: int) -> None:
            if index < 0 or index >= len(self.items):
                self._set_status("Library selection is no longer valid; reload the Library file grid.")
                return
            item = self.items[index]
            self.current_index = index
            self._set_status(f"Retrieving artwork for library item: {item.title}")
            payload = self._manual_retrieve_art_for_item(item)
            self._render_artwork_payload(payload, "Retrieve Art · Library Item")
            if payload.get("retrieved_artwork"):
                self._set_status(f"Artwork retrieved for library item: {item.title}")
            else:
                self._set_status(f"No artwork found for library item: {item.title}. Run Media Index enrichment for permanent cover art.")

        def _on_refresh_nerd_stats(self, _button) -> None:
            self._refresh_current_nerd_stats(allow_online=False)

        def _on_online_nerd_stats(self, _button) -> None:
            self._set_status("Looking up online Nerd Stats for current item...")
            self._refresh_current_nerd_stats(allow_online=True)
            self._set_status("Nerd Stats lookup complete. See Nerd Stats tab.")

        def _set_text(self, textview, text: str) -> None:
            if textview is None:
                return
            buffer = textview.get_buffer()
            buffer.set_text(text)

        def _set_status(self, text: str) -> None:
            if self.status_label is not None:
                self.status_label.set_text(text)
            else:
                print(text, file=sys.stderr)

        def _on_destroy(self, *_args) -> None:
            self._remember_playback_position(force=True)
            if self.playbin is not None:
                self.playbin.set_state(Gst.State.NULL)
            try:
                if self.fullscreen_window is not None:
                    self.fullscreen_window.destroy()
            except Exception:
                pass
            audit("close_gui", "Sentinel Media Player closed")


def launch(files: Optional[List[str]] = None) -> int:
    if GTK_IMPORT_ERROR is not None:
        print(f"GTK/GStreamer import failed: {GTK_IMPORT_ERROR}", file=sys.stderr)
        return 2
    app = SentinelMediaPlayer(files)
    return app.run([])
