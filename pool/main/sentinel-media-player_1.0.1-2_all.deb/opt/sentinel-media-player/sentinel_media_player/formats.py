from __future__ import annotations

AUDIO_EXTENSIONS = {
    ".aac", ".aiff", ".aif", ".alac", ".amr", ".ape", ".au", ".caf", ".dff", ".dsf",
    ".flac", ".m4a", ".m4b", ".mid", ".midi", ".mka", ".mp2", ".mp3",
    ".mpc", ".oga", ".ogg", ".opus", ".ra", ".ram", ".snd", ".tta", ".wav",
    ".weba", ".wma", ".wv", ".xm", ".mod", ".it", ".s3m",
}

VIDEO_EXTENSIONS = {
    ".3g2", ".3gp", ".asf", ".avi", ".divx", ".dv", ".f4v", ".flv", ".m2ts",
    ".m4v", ".mkv", ".mov", ".mp4", ".mpe", ".mpeg", ".mpg", ".mts", ".mxf",
    ".ogm", ".ogv", ".qt", ".rm", ".rmvb", ".ts", ".vob", ".webm", ".wmv",
}

PLAYLIST_EXTENSIONS = {".m3u", ".m3u8", ".pls", ".xspf"}
EBOOK_EXTENSIONS = {".pdf", ".epub", ".mobi", ".azw", ".azw3", ".cbz", ".cbr", ".djvu"}
MEDIA_EXTENSIONS = AUDIO_EXTENSIONS | VIDEO_EXTENSIONS
CATALOGUE_EXTENSIONS = MEDIA_EXTENSIONS | EBOOK_EXTENSIONS

SUPPORTED_FORMAT_NOTE = (
    "Sentinel Media Player accepts common audio/video file extensions and uses the system "
    "GStreamer backend. Actual playback depends on installed GStreamer plugins/codecs."
)


def extension_for_path(path: str) -> str:
    text = path.lower().strip()
    suffix = text.rsplit(".", 1)[-1] if "." in text else ""
    return f".{suffix}" if suffix else ""


def classify_media_path(path: str) -> str:
    ext = extension_for_path(path)
    if ext in AUDIO_EXTENSIONS:
        return "audio"
    if ext in VIDEO_EXTENSIONS:
        return "video"
    if ext in PLAYLIST_EXTENSIONS:
        return "playlist"
    if ext in EBOOK_EXTENSIONS:
        return "ebook"
    return "unknown"


def is_media_path(path: str) -> bool:
    return classify_media_path(path) in {"audio", "video"}


def is_catalogue_path(path: str) -> bool:
    return classify_media_path(path) in {"audio", "video", "ebook"}
