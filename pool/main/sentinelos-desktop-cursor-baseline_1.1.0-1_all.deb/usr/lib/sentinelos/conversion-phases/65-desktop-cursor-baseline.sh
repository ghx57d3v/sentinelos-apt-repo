#!/bin/sh
# SentinelOS conversion phase 65: corrected theme/cursor baseline.
# Run after the official theme and icon families are installed.
set -eu

export DEBIAN_FRONTEND=noninteractive

apt-get update
apt-get install -y \
  sentinelos-theme-family=0.3.1-1 \
  sentinelos-icon-theme-family=1.0.16-1 \
  sentinelos-cursor-themes=1.2.0-1 \
  sentinelos-theme-cursor-integration=1.1.0-1 \
  sentinelos-desktop-cursor-baseline=1.1.0-1

sentinelos-apply-cursor-baseline
sentinelos-theme-cursor-integration --verify
