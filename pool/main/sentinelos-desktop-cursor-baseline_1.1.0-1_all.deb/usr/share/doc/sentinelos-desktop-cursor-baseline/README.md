# SentinelOS Desktop Cursor Baseline 1.1.0

The cursor variant follows the active SentinelOS icon theme. SentinelOS-Light and SentinelOS-Dark are the only GTK/Marco themes.
