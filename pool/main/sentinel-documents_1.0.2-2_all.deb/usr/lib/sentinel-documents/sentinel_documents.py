#!/usr/bin/env python3
"""
Sentinel Documents v1.0.2
Program 116 v1.0.2 security baseline patch over v1.0.0: official baseline preserving maximized window default, working visual bold/italic formatting, final audit, AEGIS contract validation, recovery hardening, font picker refinements, AEGIS/Vault readiness, document search/management, export layer, and Contacts/Inventory/Jobs Bridges.
"""
from __future__ import annotations

import argparse
import html
import subprocess
import hashlib
import json
import os
import re
import shutil
import sqlite3
import sys
import textwrap
import tempfile
import uuid
import zipfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

APP_NAME = "Sentinel Documents"
APP_ID = "sentinel-documents"
PROGRAM_ID = "116"
VERSION = "1.0.2"
SCHEMA_VERSION = 12
LOCAL_ONLY = True
NETWORK_ENABLED = False
TELEMETRY_ENABLED = False

# Redteam security baseline limits. These keep backup restore/import and rich-document
# text extraction local, bounded, and predictable.
RESTORE_CONFIRM_TOKEN = "RESTORE_SENTINEL_DOCUMENTS"
MAX_RESTORE_FILES = 10000
MAX_RESTORE_TOTAL_BYTES = 1024 * 1024 * 1024  # 1 GiB
MAX_RESTORE_FILE_BYTES = 256 * 1024 * 1024    # 256 MiB
MAX_XML_EXTRACT_BYTES = 25 * 1024 * 1024      # 25 MiB per DOCX/ODT XML member
MAX_CONTENT_SCAN_BYTES = 5 * 1024 * 1024      # 5 MiB per text read/search path

try:
    os.umask(0o077)
except Exception:
    pass

HOME = Path.home()
XDG_DATA_HOME = Path(os.environ.get("XDG_DATA_HOME", HOME / ".local" / "share"))
XDG_CONFIG_HOME = Path(os.environ.get("XDG_CONFIG_HOME", HOME / ".config"))
XDG_CACHE_HOME = Path(os.environ.get("XDG_CACHE_HOME", HOME / ".cache"))

APP_DATA = XDG_DATA_HOME / APP_ID
APP_CONFIG = XDG_CONFIG_HOME / APP_ID
APP_CACHE = XDG_CACHE_HOME / APP_ID
DOCUMENTS_ROOT = HOME / "Documents" / "Sentinel Documents"
DOCUMENTS_DIR = DOCUMENTS_ROOT / "Documents"
AEGIS_VAULT_ROOT = HOME / "AEGIS_Vault"
AEGIS_VAULT_DOCUMENTS_DIR = AEGIS_VAULT_ROOT / "Documents"
EXPORTS_DIR = DOCUMENTS_ROOT / "Exports"
ARCHIVE_DIR = DOCUMENTS_ROOT / "Archive"
BACKUP_DIR = DOCUMENTS_ROOT / "Backups"
RECOVERY_DIR = DOCUMENTS_ROOT / "Recovery"
TEMPLATES_DIR = APP_DATA / "templates"
BRIDGES_DIR = APP_DATA / "bridges"
CONTACTS_BRIDGE_DIR = BRIDGES_DIR / "contacts"
INVENTORY_BRIDGE_DIR = BRIDGES_DIR / "inventory"
JOBS_BRIDGE_DIR = BRIDGES_DIR / "jobs"
AEGIS_DIR = APP_DATA / "aegis"
GUI_THEME_FILE = APP_CONFIG / "gui_theme.json"
GUI_SCALE_FILE = APP_CONFIG / "gui_scale.json"
GUI_FORMAT_FILE = APP_CONFIG / "gui_format.json"
DB_PATH = APP_DATA / "sentinel_documents.sqlite3"
VAULT_METADATA_DIR = AEGIS_DIR / "vault_metadata"
SYSTEM_TEMPLATE_DIR = Path("/usr/share/sentinel-documents/templates")

DEFAULT_TEMPLATE_FILES: Dict[str, str] = {
    "general-letter.md": """# General Letter\n\nDate: {{date}}\n\nTo: {{contact_name}}\n{{contact_address}}\n\nDear {{contact_name}},\n\n{{letter_body}}\n\nRegards,\n{{prepared_by}}\n""",
    "repair-report.md": """# Repair Report\n\nDate: {{date}}\nJob Code: {{job_code}}\nCustomer: {{contact_name}}\n\n## Issue\n{{issue}}\n\n## Work Completed\n{{work_completed}}\n\n## Parts / Inventory\n{{inventory_items}}\n\n## Notes\n{{notes}}\n""",
    "job-quote.md": """# Job Quote\n\nDate: {{date}}\nJob Code: {{job_code}}\nCustomer: {{contact_name}}\n\n## Scope\n{{job_description}}\n\n## Materials\n{{materials}}\n\n## Labour\n{{labour}}\n\n## Estimated Total\n{{estimated_total}}\n\nPrepared By: {{prepared_by}}\n""",
    "job-completion-report.md": """# Job Completion Report\n\nDate: {{date}}\nJob Code: {{job_code}}\nCustomer: {{contact_name}}\n\n## Work Summary\n{{work_completed}}\n\n## Materials Used\n{{materials}}\n\n## Completion Notes\n{{completion_notes}}\n\n## Customer Handoff\n{{handoff_notes}}\n""",
    "inventory-item-report.md": """# Inventory Item Report\n\nDate: {{date}}\nItem Code: {{item_code}}\nItem Name: {{item_name}}\nSerial Number: {{serial_number}}\nCondition: {{condition}}\nLocation: {{location}}\nWarranty Status: {{warranty_status}}\n\n## Notes\n{{notes}}\n""",
    "contact-summary.md": """# Contact Summary\n\nDate: {{date}}\nContact Code: {{contact_code}}\nName: {{contact_name}}\nPhone: {{contact_phone}}\nEmail: {{contact_email}}\nAddress: {{contact_address}}\n\n## Notes\n{{notes}}\n""",
    "warranty-note.md": """# Warranty Note\n\nDate: {{date}}\nItem Code: {{item_code}}\nItem Name: {{item_name}}\nSerial Number: {{serial_number}}\nPurchase Date: {{purchase_date}}\nWarranty Status: {{warranty_status}}\n\n## Warranty Details\n{{warranty_details}}\n\n## Action Required\n{{action_required}}\n""",
    "manual-page.md": """# Manual / Documentation Page\n\nTopic: {{topic}}\nDate: {{date}}\nPrepared By: {{prepared_by}}\n\n## Purpose\n{{purpose}}\n\n## Steps\n1. {{step_one}}\n2. {{step_two}}\n3. {{step_three}}\n\n## Notes\n{{notes}}\n""",
    "ledger-handoff-note.md": """# Ledger Handoff Note\n\nDate: {{date}}\nRelated Job: {{job_code}}\nContact: {{contact_name}}\n\n## Summary\n{{summary}}\n\n## Amounts / Receipts\n{{ledger_items}}\n\n## Notes\n{{notes}}\n""",
    "aegis-report.md": """# AEGIS Report\n\nDate: {{date}}\nPrepared By: {{prepared_by}}\n\n## Summary\n{{summary}}\n\n## Observations\n{{observations}}\n\n## Recommended Actions\n{{recommended_actions}}\n""",
}

PLACEHOLDER_RE = re.compile(r"\{\{\s*([A-Za-z0-9_]+)\s*\}\}")

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS app_meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS documents (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    category TEXT NOT NULL DEFAULT 'General',
    doc_type TEXT NOT NULL DEFAULT 'Document',
    file_path TEXT NOT NULL,
    content_format TEXT NOT NULL DEFAULT 'markdown',
    linked_contact_code TEXT,
    linked_job_code TEXT,
    linked_inventory_code TEXT,
    status TEXT NOT NULL DEFAULT 'active',
    sha256 TEXT,
    created_at TEXT NOT NULL,
    modified_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_documents_title ON documents(title);
CREATE INDEX IF NOT EXISTS idx_documents_category ON documents(category);
CREATE INDEX IF NOT EXISTS idx_documents_contact ON documents(linked_contact_code);
CREATE INDEX IF NOT EXISTS idx_documents_job ON documents(linked_job_code);
CREATE INDEX IF NOT EXISTS idx_documents_inventory ON documents(linked_inventory_code);
CREATE INDEX IF NOT EXISTS idx_documents_status ON documents(status);
CREATE INDEX IF NOT EXISTS idx_documents_modified ON documents(modified_at);

CREATE TABLE IF NOT EXISTS contact_bridge_cache (
    contact_code TEXT PRIMARY KEY,
    contact_name TEXT,
    phone TEXT,
    email TEXT,
    address TEXT,
    company TEXT,
    notes TEXT,
    source_file TEXT,
    raw_json TEXT NOT NULL,
    imported_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_contact_bridge_name ON contact_bridge_cache(contact_name);
CREATE INDEX IF NOT EXISTS idx_contact_bridge_email ON contact_bridge_cache(email);


CREATE TABLE IF NOT EXISTS inventory_bridge_cache (
    item_code TEXT PRIMARY KEY,
    item_name TEXT,
    asset_tag TEXT,
    item_category TEXT,
    model TEXT,
    serial_number TEXT,
    condition TEXT,
    location TEXT,
    quantity TEXT,
    supplier TEXT,
    purchase_price TEXT,
    purchase_date TEXT,
    warranty_status TEXT,
    warranty_end TEXT,
    notes TEXT,
    source_file TEXT,
    raw_json TEXT NOT NULL,
    imported_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_inventory_bridge_name ON inventory_bridge_cache(item_name);
CREATE INDEX IF NOT EXISTS idx_inventory_bridge_serial ON inventory_bridge_cache(serial_number);
CREATE INDEX IF NOT EXISTS idx_inventory_bridge_location ON inventory_bridge_cache(location);


CREATE TABLE IF NOT EXISTS job_bridge_cache (
    job_code TEXT PRIMARY KEY,
    job_title TEXT,
    job_status TEXT,
    priority TEXT,
    contact_code TEXT,
    contact_name TEXT,
    contact_phone TEXT,
    contact_email TEXT,
    item_code TEXT,
    item_name TEXT,
    date_started TEXT,
    date_completed TEXT,
    due_date TEXT,
    job_location TEXT,
    estimated_total TEXT,
    labour TEXT,
    materials TEXT,
    issue TEXT,
    diagnosis TEXT,
    work_completed TEXT,
    completion_notes TEXT,
    handoff_notes TEXT,
    notes TEXT,
    source_file TEXT,
    raw_json TEXT NOT NULL,
    imported_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_job_bridge_title ON job_bridge_cache(job_title);
CREATE INDEX IF NOT EXISTS idx_job_bridge_status ON job_bridge_cache(job_status);
CREATE INDEX IF NOT EXISTS idx_job_bridge_contact ON job_bridge_cache(contact_code);
"""


def now_iso() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def safe_slug(text: str) -> str:
    allowed = []
    for ch in text.strip().lower():
        if ch.isalnum():
            allowed.append(ch)
        elif ch in (" ", "-", "_", "."):
            allowed.append("-")
    slug = "".join(allowed).strip("-")
    while "--" in slug:
        slug = slug.replace("--", "-")
    return slug or "untitled"


def document_id() -> str:
    return "SDOC-" + datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:6].upper()


def _chmod_private(path: Path, mode: int) -> None:
    try:
        path.chmod(mode)
    except Exception:
        pass


def _private_write_text(path: Path, text: str, *, mode: int = 0o600, encoding: str = "utf-8") -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding=encoding)
    _chmod_private(path, mode)


def _private_write_bytes(path: Path, data: bytes, *, mode: int = 0o600) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    _chmod_private(path, mode)


def _safe_resolve(path: Path) -> Path:
    return Path(path).expanduser().resolve(strict=False)


def _is_relative_to(path: Path, root: Path) -> bool:
    try:
        _safe_resolve(path).relative_to(_safe_resolve(root))
        return True
    except Exception:
        return False


def document_allowed_roots() -> List[Path]:
    roots = [DOCUMENTS_DIR, EXPORTS_DIR, ARCHIVE_DIR]
    if AEGIS_VAULT_DOCUMENTS_DIR.exists():
        roots.append(AEGIS_VAULT_DOCUMENTS_DIR)
    return roots


def validate_document_file_path(path: Path) -> Tuple[bool, str]:
    p = Path(path).expanduser()
    if not str(p):
        return False, "empty path"
    try:
        if p.is_symlink():
            return False, "document path is a symlink"
    except Exception:
        pass
    resolved = _safe_resolve(p)
    for root in document_allowed_roots():
        if _is_relative_to(resolved, root):
            return True, ""
    return False, "document path escapes approved Sentinel Documents roots"


def ensure_dirs() -> None:
    private_dirs = [
        APP_DATA,
        APP_CONFIG,
        APP_CACHE,
        DOCUMENTS_ROOT,
        DOCUMENTS_DIR,
        EXPORTS_DIR,
        ARCHIVE_DIR,
        BACKUP_DIR,
        RECOVERY_DIR,
        TEMPLATES_DIR,
        CONTACTS_BRIDGE_DIR / "inbox",
        CONTACTS_BRIDGE_DIR / "outbox",
        INVENTORY_BRIDGE_DIR / "inbox",
        INVENTORY_BRIDGE_DIR / "outbox",
        JOBS_BRIDGE_DIR / "inbox",
        JOBS_BRIDGE_DIR / "outbox",
        AEGIS_DIR,
        VAULT_METADATA_DIR,
    ]
    for d in private_dirs:
        d.mkdir(parents=True, exist_ok=True)
        _chmod_private(d, 0o700)
    for f in [DB_PATH, GUI_THEME_FILE, GUI_SCALE_FILE, GUI_FORMAT_FILE]:
        if f.exists():
            _chmod_private(f, 0o600)


def db_connect() -> sqlite3.Connection:
    ensure_dirs()
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA_SQL)
    conn.execute(
        "INSERT OR REPLACE INTO app_meta(key, value) VALUES(?, ?)",
        ("schema_version", str(SCHEMA_VERSION)),
    )
    conn.execute(
        "INSERT OR REPLACE INTO app_meta(key, value) VALUES(?, ?)",
        ("version", VERSION),
    )
    # Lightweight forward migration for existing local v0.1-v0.4 databases.
    try:
        cols = {row[1] for row in conn.execute("PRAGMA table_info(documents)").fetchall()}
        if "content_format" not in cols:
            conn.execute("ALTER TABLE documents ADD COLUMN content_format TEXT NOT NULL DEFAULT 'markdown'")
    except Exception:
        pass
    conn.commit()
    if DB_PATH.exists():
        _chmod_private(DB_PATH, 0o600)
    return conn


def seed_templates() -> None:
    ensure_dirs()
    copied = False
    if SYSTEM_TEMPLATE_DIR.exists():
        for src in SYSTEM_TEMPLATE_DIR.glob("*.md"):
            dest = TEMPLATES_DIR / src.name
            if not dest.exists():
                shutil.copy2(src, dest)
                copied = True
    for name, content in DEFAULT_TEMPLATE_FILES.items():
        path = TEMPLATES_DIR / name
        if not path.exists():
            path.write_text(content, encoding="utf-8")
            copied = True
    if copied:
        (TEMPLATES_DIR / ".sentinel_templates_seeded").write_text(now_iso() + "\n", encoding="utf-8")


def init_environment() -> None:
    ensure_dirs()
    with db_connect() as conn:
        conn.execute(
            "INSERT OR REPLACE INTO app_meta(key, value) VALUES(?, ?)",
            ("last_init", now_iso()),
        )
        conn.commit()
    seed_templates()
    write_aegis_contract_files()


def load_gui_theme() -> str:
    try:
        if GUI_THEME_FILE.exists():
            data = json.loads(GUI_THEME_FILE.read_text(encoding="utf-8"))
            theme = str(data.get("theme", "aegis_dark"))
            if theme in {"aegis_dark", "sentinel_light_cyan"}:
                return theme
    except Exception:
        pass
    return "aegis_dark"


def save_gui_theme(theme: str) -> None:
    if theme not in {"aegis_dark", "sentinel_light_cyan"}:
        theme = "aegis_dark"
    APP_CONFIG.mkdir(parents=True, exist_ok=True)
    GUI_THEME_FILE.write_text(json.dumps({"theme": theme, "updated_at": now_iso()}, indent=2), encoding="utf-8")


def load_gui_scale() -> Dict[str, int]:
    defaults = {"editor_scale": 100, "side_width": 190}
    try:
        if GUI_SCALE_FILE.exists():
            data = json.loads(GUI_SCALE_FILE.read_text(encoding="utf-8"))
            defaults["editor_scale"] = max(80, min(180, int(data.get("editor_scale", defaults["editor_scale"]))))
            defaults["side_width"] = max(155, min(280, int(data.get("side_width", defaults["side_width"]))))
    except Exception:
        pass
    return defaults


def save_gui_scale(editor_scale: int, side_width: int) -> None:
    editor_scale = max(80, min(180, int(editor_scale)))
    side_width = max(155, min(280, int(side_width)))
    APP_CONFIG.mkdir(parents=True, exist_ok=True)
    GUI_SCALE_FILE.write_text(
        json.dumps({"editor_scale": editor_scale, "side_width": side_width, "updated_at": now_iso()}, indent=2),
        encoding="utf-8",
    )


DEFAULT_FORMAT_PREFS: Dict[str, Any] = {
    "font_family": "Sans",
    "font_size": 12,
    "paragraph_align": "left",
    "line_spacing": 4,
    "paragraph_spacing": 8,
}

BASE_FONT_FAMILY_CHOICES = [
    "Sans",
    "Serif",
    "Monospace",
    "DejaVu Sans",
    "DejaVu Serif",
    "DejaVu Sans Mono",
    "Liberation Sans",
    "Liberation Serif",
    "Liberation Mono",
    "Noto Sans",
    "Noto Serif",
    "Noto Sans Mono",
    "Ubuntu",
    "Ubuntu Mono",
    "Cantarell",
    "FreeSans",
    "FreeSerif",
    "FreeMono",
    "Arial",
    "Arial Black",
    "Calibri",
    "Cambria",
    "Candara",
    "Consolas",
    "Constantia",
    "Corbel",
    "Courier New",
    "Georgia",
    "Impact",
    "Segoe UI",
    "Tahoma",
    "Times New Roman",
    "Trebuchet MS",
    "Verdana",
]

# Compatibility alias for older callers; GUI/CLI now prefer available_font_families().
FONT_FAMILY_CHOICES = BASE_FONT_FAMILY_CHOICES

PARAGRAPH_ALIGN_CHOICES = ["left", "center", "right"]


def normalise_font_family_names(names: Iterable[Any]) -> List[str]:
    """Return sorted, deduplicated user-facing font family names."""
    seen: Dict[str, str] = {}
    for raw in names:
        for part in str(raw or "").split(","):
            name = part.strip()
            if not name:
                continue
            # Fontconfig sometimes returns style/variant suffixes; keep family only.
            name = re.sub(r"\s+(Regular|Book|Medium|Bold|Italic|Oblique|Light|Thin|Black|Condensed|Expanded)$", "", name, flags=re.I).strip()
            if len(name) > 72:
                continue
            key = name.casefold()
            seen.setdefault(key, name)
    preferred = ["Sans", "Serif", "Monospace", "DejaVu Sans", "DejaVu Serif", "DejaVu Sans Mono", "Liberation Sans", "Liberation Serif", "Liberation Mono"]
    ordered: List[str] = []
    for name in preferred:
        key = name.casefold()
        if key in seen:
            ordered.append(seen.pop(key))
    ordered.extend(seen[key] for key in sorted(seen, key=lambda k: seen[k].casefold()))
    return ordered


def discover_fontconfig_families() -> List[str]:
    """Discover installed font families through fontconfig when available."""
    fc_list = shutil.which("fc-list")
    if not fc_list:
        return []
    try:
        result = subprocess.run([fc_list, ":", "family"], capture_output=True, text=True, timeout=5)
        if result.returncode != 0:
            return []
        return normalise_font_family_names(result.stdout.splitlines())
    except Exception:
        return []


def available_font_families(extra: Optional[Iterable[Any]] = None) -> List[str]:
    """Return the broadest safe font list available without requiring network access."""
    names: List[Any] = list(BASE_FONT_FAMILY_CHOICES)
    names.extend(discover_fontconfig_families())
    if extra:
        names.extend(list(extra))
    return normalise_font_family_names(names)


def resolve_gui_font_families(tkfont: Any = None, root: Any = None) -> List[str]:
    """Combine fontconfig and Tk runtime fonts for the GUI selector."""
    tk_names: List[str] = []
    if tkfont is not None:
        try:
            # Pass root when supported so Tk can report the active display/font map.
            tk_names = list(tkfont.families(root=root))
        except TypeError:
            try:
                tk_names = list(tkfont.families())
            except Exception:
                tk_names = []
        except Exception:
            tk_names = []
    return available_font_families(tk_names)


def load_gui_format() -> Dict[str, Any]:
    prefs = dict(DEFAULT_FORMAT_PREFS)
    try:
        if GUI_FORMAT_FILE.exists():
            data = json.loads(GUI_FORMAT_FILE.read_text(encoding="utf-8"))
            family = str(data.get("font_family", prefs["font_family"])).strip() or prefs["font_family"]
            prefs["font_family"] = family
            prefs["font_size"] = max(8, min(50, int(data.get("font_size", prefs["font_size"]))))
            align = str(data.get("paragraph_align", prefs["paragraph_align"])).lower()
            prefs["paragraph_align"] = align if align in PARAGRAPH_ALIGN_CHOICES else "left"
            prefs["line_spacing"] = max(0, min(24, int(data.get("line_spacing", prefs["line_spacing"]))))
            prefs["paragraph_spacing"] = max(0, min(36, int(data.get("paragraph_spacing", prefs["paragraph_spacing"]))))
    except Exception:
        pass
    return prefs


def save_gui_format(prefs: Dict[str, Any]) -> Dict[str, Any]:
    clean = dict(DEFAULT_FORMAT_PREFS)
    clean["font_family"] = str(prefs.get("font_family", clean["font_family"])).strip() or clean["font_family"]
    clean["font_size"] = max(8, min(50, int(prefs.get("font_size", clean["font_size"]))))
    align = str(prefs.get("paragraph_align", clean["paragraph_align"])).lower()
    clean["paragraph_align"] = align if align in PARAGRAPH_ALIGN_CHOICES else "left"
    clean["line_spacing"] = max(0, min(24, int(prefs.get("line_spacing", clean["line_spacing"]))))
    clean["paragraph_spacing"] = max(0, min(36, int(prefs.get("paragraph_spacing", clean["paragraph_spacing"]))))
    clean["updated_at"] = now_iso()
    APP_CONFIG.mkdir(parents=True, exist_ok=True)
    GUI_FORMAT_FILE.write_text(json.dumps(clean, indent=2), encoding="utf-8")
    return clean


def format_options_json() -> Dict[str, Any]:
    return {
        "app": APP_NAME,
        "app_id": APP_ID,
        "program_id": PROGRAM_ID,
        "version": VERSION,
        "formatting_foundation": "editor_display_markdown_helpers_and_context_menu_controls_v1",
        "font_families": available_font_families(),
        "font_family_count": len(available_font_families()),
        "font_family_discovery": {"base_list": True, "fontconfig_fc_list": bool(shutil.which("fc-list")), "tk_runtime_fonts_in_gui": True},
        "font_picker": {"home_button": True, "right_click_menu_launch": True, "scrollable_list": True, "search_filter": True, "theme_key_hotfix": True},
        "top_ribbon_tabs": {"placement": "directly_below_file_view_help_strip", "header_below_ribbon": True},
        "font_size_range": {"min": 8, "max": 50},
        "paragraph_alignments": PARAGRAPH_ALIGN_CHOICES,
        "line_spacing_range": {"min": 0, "max": 24},
        "paragraph_spacing_range": {"min": 0, "max": 36},
        "current_defaults": load_gui_format(),
        "supported_markdown_helpers": ["bold", "italic", "underline_marker", "strikethrough", "inline_code", "highlight_marker", "heading_1", "heading_2", "normal_paragraph", "quote", "bullets", "numbered_list", "clear_markdown_wrappers"],
        "note": "Formatting controls apply through the ribbon and right-click hot menu, using editor display preferences, discovered system/Tk font families, and Markdown-compatible structure. Advanced per-character rich text persistence remains a later foundation.",
        "local_only": True,
        "network_enabled": False,
        "telemetry_enabled": False,
        "timestamp": now_iso(),
    }


def document_style_sidecar_path(path: Path) -> Path:
    return path.with_name(path.name + ".sentinel-style.json")


def write_document_style_sidecar(file_path: Path, style: Dict[str, Any], doc_id: str = "") -> Path:
    file_path = Path(file_path).expanduser()
    sidecar = document_style_sidecar_path(file_path)
    payload = {
        "app": APP_NAME,
        "app_id": APP_ID,
        "program_id": PROGRAM_ID,
        "version": VERSION,
        "document_id": doc_id,
        "document_path": str(file_path),
        "style": save_gui_format(style),
        "local_only": True,
        "timestamp": now_iso(),
    }
    sidecar.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return sidecar


def list_templates() -> List[str]:
    seed_templates()
    return sorted([p.name for p in TEMPLATES_DIR.glob("*.md")])


def template_path(template_name: str) -> Path:
    seed_templates()
    name = Path(template_name).name
    if not name.endswith(".md"):
        name += ".md"
    return TEMPLATES_DIR / name


def read_template(template_name: str) -> str:
    path = template_path(template_name)
    if not path.exists():
        raise FileNotFoundError(f"Template not found: {template_name}")
    return path.read_text(encoding="utf-8", errors="replace")


def extract_placeholders(text: str) -> List[str]:
    return sorted(set(PLACEHOLDER_RE.findall(text)))


def default_template_context() -> Dict[str, str]:
    username = os.environ.get("USER") or os.environ.get("USERNAME") or "Sentinel User"
    today = datetime.now().strftime("%Y-%m-%d")
    return {
        "date": today,
        "prepared_by": username,
        "contact_name": "",
        "contact_code": "",
        "contact_phone": "",
        "contact_email": "",
        "contact_address": "",
        "contact_company": "",
        "company": "",
        "job_code": "",
        "job_title": "",
        "job_status": "",
        "priority": "",
        "date_started": "",
        "date_completed": "",
        "due_date": "",
        "job_location": "",
        "customer_name": "",
        "customer_contact": "",
        "job_description": "",
        "issue": "",
        "diagnosis": "",
        "result": "",
        "work_completed": "",
        "completion_notes": "",
        "handoff_notes": "",
        "materials": "",
        "labour": "",
        "estimated_total": "",
        "inventory_items": "",
        "item_code": "",
        "item_name": "",
        "asset_tag": "",
        "item_category": "",
        "model": "",
        "serial_number": "",
        "condition": "",
        "location": "",
        "quantity": "",
        "supplier": "",
        "purchase_price": "",
        "purchase_date": "",
        "warranty_end": "",
        "warranty_status": "",
        "warranty_details": "",
        "action_required": "",
        "letter_body": "[Write your letter here.]",
        "summary": "",
        "observations": "",
        "recommended_actions": "",
        "topic": "",
        "purpose": "",
        "step_one": "",
        "step_two": "",
        "step_three": "",
        "notes": "",
        "ledger_items": "",
    }


def flatten_context_object(obj: Any, prefix: str = "") -> Dict[str, str]:
    flat: Dict[str, str] = {}
    if isinstance(obj, dict):
        for key, value in obj.items():
            clean_key = str(key).strip().lower().replace(" ", "_").replace("-", "_")
            full_key = f"{prefix}_{clean_key}" if prefix else clean_key
            if isinstance(value, dict):
                flat.update(flatten_context_object(value, full_key))
            elif isinstance(value, list):
                flat[full_key] = "\n".join(str(v) for v in value)
            elif value is None:
                flat[full_key] = ""
            else:
                flat[full_key] = str(value)
    return flat


def load_context_json(path: Optional[str]) -> Dict[str, str]:
    if not path:
        return {}
    p = Path(path).expanduser()
    data = json.loads(p.read_text(encoding="utf-8"))
    return flatten_context_object(data)


def parse_template_sets(items: Optional[List[str]]) -> Dict[str, str]:
    out: Dict[str, str] = {}
    for item in items or []:
        if "=" not in item:
            raise ValueError(f"Template set must be key=value: {item}")
        key, value = item.split("=", 1)
        key = key.strip().lower().replace(" ", "_").replace("-", "_")
        out[key] = value
    return out


def render_template_text(template_name: str, context: Optional[Dict[str, str]] = None) -> Tuple[str, List[str]]:
    raw = read_template(template_name)
    merged = default_template_context()
    if context:
        merged.update({str(k).strip().lower().replace(" ", "_").replace("-", "_"): str(v) for k, v in context.items()})
    placeholders = extract_placeholders(raw)
    missing = [key for key in placeholders if key not in merged or merged.get(key, "") == ""]

    def repl(match: re.Match[str]) -> str:
        key = match.group(1).strip().lower().replace(" ", "_").replace("-", "_")
        return merged.get(key, "")

    return PLACEHOLDER_RE.sub(repl, raw), missing


def template_info(template_name: str) -> Dict[str, Any]:
    text = read_template(template_name)
    path = template_path(template_name)
    return {
        "name": path.name,
        "path": str(path),
        "placeholders": extract_placeholders(text),
        "sha256": sha256_file(path),
    }


def templates_json() -> Dict[str, Any]:
    init_environment()
    return {
        "app": APP_NAME,
        "app_id": APP_ID,
        "program_id": PROGRAM_ID,
        "version": VERSION,
        "template_engine": "placeholder_merge_v1",
        "placeholder_format": "{{placeholder_name}}",
        "templates": [template_info(name) for name in list_templates()],
        "local_only": True,
        "network_enabled": False,
        "telemetry_enabled": False,
        "timestamp": now_iso(),
    }


def create_document_from_template(
    template_name: str,
    context: Optional[Dict[str, str]] = None,
    *,
    title: Optional[str] = None,
    category: str = "Templates",
    doc_type: str = "Document",
    linked_contact_code: Optional[str] = None,
    linked_job_code: Optional[str] = None,
    linked_inventory_code: Optional[str] = None,
) -> Dict[str, Any]:
    content, missing = render_template_text(template_name, context)
    path = template_path(template_name)
    doc_title = title or path.stem.replace("-", " ").title()
    doc_id = upsert_document(
        doc_id=None,
        title=doc_title,
        content=content,
        category=category,
        doc_type=doc_type,
        linked_contact_code=linked_contact_code,
        linked_job_code=linked_job_code,
        linked_inventory_code=linked_inventory_code,
    )
    doc = get_document(doc_id) or {}
    return {
        "created": True,
        "document_id": doc_id,
        "document": doc,
        "template": path.name,
        "missing_or_empty_placeholders": missing,
        "full_text_returned": False,
    }


def list_documents(include_archived: bool = False) -> List[Dict[str, Any]]:
    with db_connect() as conn:
        if include_archived:
            rows = conn.execute("SELECT * FROM documents ORDER BY modified_at DESC").fetchall()
        else:
            rows = conn.execute("SELECT * FROM documents WHERE status='active' ORDER BY modified_at DESC").fetchall()
    return [dict(r) for r in rows]


def get_document(doc_id: str) -> Optional[Dict[str, Any]]:
    with db_connect() as conn:
        row = conn.execute("SELECT * FROM documents WHERE id=?", (doc_id,)).fetchone()
    return dict(row) if row else None


def upsert_document(
    *,
    doc_id: Optional[str],
    title: str,
    content: str,
    category: str = "General",
    doc_type: str = "Document",
    linked_contact_code: Optional[str] = None,
    linked_job_code: Optional[str] = None,
    linked_inventory_code: Optional[str] = None,
    output_path: Optional[str] = None,
    save_format: str = "markdown",
) -> str:
    init_environment()
    title = title.strip() or "Untitled Document"
    category = category.strip() or "General"
    doc_type = doc_type.strip() or "Document"
    created_at = now_iso()
    modified_at = created_at

    existing = get_document(doc_id) if doc_id else None
    if existing:
        doc_id = existing["id"]
        file_path = Path(output_path).expanduser() if output_path else Path(existing["file_path"])
        created_at = existing["created_at"]
    else:
        doc_id = document_id()
        file_path = Path(output_path).expanduser() if output_path else DOCUMENTS_DIR / f"{safe_slug(title)}_{doc_id}{SAVE_FORMATS[normalise_save_format(save_format)]['extension']}"

    file_path = ensure_extension(file_path, save_format)
    ok, reason = validate_document_file_path(file_path)
    if not ok:
        raise ValueError(f"Refusing to save indexed document outside approved roots: {reason}")
    content_format = write_content_file(file_path, title, content, save_format)
    digest = sha256_file(file_path)

    with db_connect() as conn:
        conn.execute(
            """
            INSERT INTO documents (
                id, title, category, doc_type, file_path, content_format,
                linked_contact_code, linked_job_code, linked_inventory_code,
                status, sha256, created_at, modified_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET
                title=excluded.title,
                category=excluded.category,
                doc_type=excluded.doc_type,
                file_path=excluded.file_path,
                content_format=excluded.content_format,
                linked_contact_code=excluded.linked_contact_code,
                linked_job_code=excluded.linked_job_code,
                linked_inventory_code=excluded.linked_inventory_code,
                status=excluded.status,
                sha256=excluded.sha256,
                modified_at=excluded.modified_at
            """,
            (
                doc_id,
                title,
                category,
                doc_type,
                str(file_path),
                content_format,
                linked_contact_code or None,
                linked_job_code or None,
                linked_inventory_code or None,
                "active",
                digest,
                created_at,
                modified_at,
            ),
        )
        conn.commit()
    write_aegis_contract_files()
    return doc_id


def archive_document(doc_id: str) -> bool:
    doc = get_document(doc_id)
    if not doc:
        return False
    with db_connect() as conn:
        conn.execute("UPDATE documents SET status='archived', modified_at=? WHERE id=?", (now_iso(), doc_id))
        conn.commit()
    write_aegis_contract_files()
    return True


def read_document_text(doc_id: str) -> Optional[str]:
    doc = get_document(doc_id)
    if not doc:
        return None
    path = Path(doc["file_path"]).expanduser()
    ok, reason = validate_document_file_path(path)
    if not ok:
        raise ValueError(f"Unsafe document path for {doc_id}: {reason}")
    if not path.exists():
        return None
    try:
        if path.stat().st_size > MAX_RESTORE_FILE_BYTES:
            raise ValueError("Document file exceeds safety limit")
        content, _fmt = read_external_document_file(path)
        return content
    except Exception:
        with path.open("r", encoding="utf-8", errors="replace") as f:
            return f.read(MAX_CONTENT_SCAN_BYTES)

def restore_document(doc_id: str) -> bool:
    doc = get_document(doc_id)
    if not doc:
        return False
    with db_connect() as conn:
        conn.execute("UPDATE documents SET status='active', modified_at=? WHERE id=?", (now_iso(), doc_id))
        conn.commit()
    write_aegis_contract_files()
    return True


def document_categories(include_archived: bool = True) -> List[Dict[str, Any]]:
    init_environment()
    if include_archived:
        sql = "SELECT category, status, COUNT(*) AS count FROM documents GROUP BY category, status ORDER BY category COLLATE NOCASE, status"
        params: Tuple[Any, ...] = ()
    else:
        sql = "SELECT category, status, COUNT(*) AS count FROM documents WHERE status='active' GROUP BY category, status ORDER BY category COLLATE NOCASE, status"
        params = ()
    with db_connect() as conn:
        rows = [dict(r) for r in conn.execute(sql, params).fetchall()]
    return rows


def list_recent_documents(limit: int = 12, include_archived: bool = False) -> List[Dict[str, Any]]:
    init_environment()
    limit = max(1, min(100, int(limit)))
    if include_archived:
        sql = "SELECT * FROM documents ORDER BY modified_at DESC LIMIT ?"
        params: Tuple[Any, ...] = (limit,)
    else:
        sql = "SELECT * FROM documents WHERE status='active' ORDER BY modified_at DESC LIMIT ?"
        params = (limit,)
    with db_connect() as conn:
        rows = conn.execute(sql, params).fetchall()
    return [dict(r) for r in rows]


def search_documents(
    query: str = "",
    *,
    category: str = "",
    status: str = "active",
    linked_contact_code: str = "",
    linked_job_code: str = "",
    linked_inventory_code: str = "",
    include_content: bool = False,
    limit: int = 100,
) -> List[Dict[str, Any]]:
    """Search indexed document metadata, with optional local full-text scan.

    Results deliberately return metadata and match flags, not full document text. This keeps
    AEGIS/Sentinel Command reads safe while giving the user a fast local document finder.
    """
    init_environment()
    query_norm = (query or "").strip().lower()
    category_norm = (category or "").strip().lower()
    status_norm = (status or "active").strip().lower()
    contact_norm = (linked_contact_code or "").strip().lower()
    job_norm = (linked_job_code or "").strip().lower()
    inv_norm = (linked_inventory_code or "").strip().lower()
    limit = max(1, min(500, int(limit)))

    where = []
    params: List[Any] = []
    if status_norm in {"active", "archived"}:
        where.append("status=?")
        params.append(status_norm)
    if category_norm and category_norm not in {"all", "any"}:
        where.append("LOWER(category)=?")
        params.append(category_norm)
    if contact_norm:
        where.append("LOWER(COALESCE(linked_contact_code,''))=?")
        params.append(contact_norm)
    if job_norm:
        where.append("LOWER(COALESCE(linked_job_code,''))=?")
        params.append(job_norm)
    if inv_norm:
        where.append("LOWER(COALESCE(linked_inventory_code,''))=?")
        params.append(inv_norm)
    sql = "SELECT * FROM documents"
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY modified_at DESC LIMIT ?"
    params.append(limit)
    with db_connect() as conn:
        rows = [dict(r) for r in conn.execute(sql, tuple(params)).fetchall()]

    results: List[Dict[str, Any]] = []
    for doc in rows:
        match_fields: List[str] = []
        haystacks = {
            "title": doc.get("title") or "",
            "category": doc.get("category") or "",
            "doc_type": doc.get("doc_type") or "",
            "linked_contact_code": doc.get("linked_contact_code") or "",
            "linked_job_code": doc.get("linked_job_code") or "",
            "linked_inventory_code": doc.get("linked_inventory_code") or "",
            "file_path": doc.get("file_path") or "",
            "status": doc.get("status") or "",
        }
        if query_norm:
            for field, value in haystacks.items():
                if query_norm in str(value).lower():
                    match_fields.append(field)
            if include_content:
                try:
                    content = read_document_text(doc["id"]) or ""
                    if query_norm in content.lower():
                        match_fields.append("content")
                except Exception:
                    pass
            if not match_fields:
                continue
        result = dict(doc)
        result["match_fields"] = match_fields
        result["full_text_returned"] = False
        results.append(result)
    return results


def document_library_summary() -> Dict[str, Any]:
    init_environment()
    docs = list_documents(include_archived=True)
    return {
        "total": len(docs),
        "active": len([d for d in docs if d.get("status") == "active"]),
        "archived": len([d for d in docs if d.get("status") == "archived"]),
        "categories": document_categories(include_archived=True),
        "recent": list_recent_documents(limit=8, include_archived=False),
        "full_text_returned": False,
    }


# ----------------------------- File Open / Save Formats -----------------------------

SAVE_FORMATS: Dict[str, Dict[str, str]] = {
    "markdown": {"label": "Markdown (.md)", "extension": ".md", "content_format": "markdown"},
    "text": {"label": "Plain Text (.txt)", "extension": ".txt", "content_format": "text"},
    "html": {"label": "HTML (.html)", "extension": ".html", "content_format": "html"},
    "pdf": {"label": "PDF Text Document (.pdf)", "extension": ".pdf", "content_format": "pdf_text"},
    "odt": {"label": "OpenDocument Text (.odt)", "extension": ".odt", "content_format": "odt_text"},
    "docx": {"label": "Word Document Text (.docx)", "extension": ".docx", "content_format": "docx_text"},
}


def save_locations_json() -> Dict[str, Any]:
    return {
        "documents": str(DOCUMENTS_DIR),
        "exports": str(EXPORTS_DIR),
        "aegis_vault_detected": AEGIS_VAULT_ROOT.exists(),
        "aegis_vault_documents": str(AEGIS_VAULT_DOCUMENTS_DIR),
        "default_location": "documents",
    }


def normalise_save_format(fmt: str) -> str:
    fmt = (fmt or "markdown").strip().lower().replace(".", "")
    aliases = {
        "md": "markdown", "markdown": "markdown",
        "txt": "text", "text": "text",
        "html": "html", "htm": "html",
        "pdf": "pdf",
        "odt": "odt", "opendocument": "odt", "open_document": "odt",
        "docx": "docx", "word": "docx", "msword": "docx",
    }
    return aliases.get(fmt, "markdown")


def ensure_extension(path: Path, fmt: str) -> Path:
    spec = SAVE_FORMATS[normalise_save_format(fmt)]
    ext = spec["extension"]
    if path.suffix.lower() != ext:
        path = path.with_suffix(ext)
    return path


def markdown_to_basic_html(title: str, content: str) -> str:
    return "<!doctype html>\n<html><head><meta charset='utf-8'><title>{}</title></head><body><pre>{}</pre></body></html>\n".format(
        html.escape(title or APP_NAME), html.escape(content)
    )


def _pdf_escape(text: str) -> str:
    return text.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


def write_basic_text_pdf(path: Path, title: str, content: str) -> None:
    # Minimal built-in PDF writer for local text documents. It intentionally writes
    # a simple text-layer PDF rather than preserving advanced source PDF layout.
    lines: List[str] = []
    if title:
        lines.append(title)
        lines.append("")
    for raw in content.replace("\r\n", "\n").split("\n"):
        if len(raw) <= 92:
            lines.append(raw)
        else:
            while len(raw) > 92:
                lines.append(raw[:92])
                raw = raw[92:]
            lines.append(raw)
    pages = [lines[i:i+44] for i in range(0, max(1, len(lines)), 44)] or [[]]
    objects: List[bytes] = []
    objects.append(b"<< /Type /Catalog /Pages 2 0 R >>")
    kids = " ".join(f"{3 + i*2} 0 R" for i in range(len(pages)))
    objects.append(f"<< /Type /Pages /Kids [{kids}] /Count {len(pages)} >>".encode())
    for i, page_lines in enumerate(pages):
        page_obj_no = 3 + i*2
        content_obj_no = page_obj_no + 1
        objects.append(f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> >> >> /Contents {content_obj_no} 0 R >>".encode())
        stream_lines = ["BT", "/F1 11 Tf", "50 792 Td", "14 TL"]
        for line in page_lines:
            stream_lines.append(f"({_pdf_escape(line)}) Tj")
            stream_lines.append("T*")
        stream_lines.append("ET")
        stream = "\n".join(stream_lines).encode("latin-1", errors="replace")
        objects.append(b"<< /Length " + str(len(stream)).encode() + b" >>\nstream\n" + stream + b"\nendstream")
    out = bytearray(b"%PDF-1.4\n% Sentinel Documents local text PDF\n")
    offsets = [0]
    for idx, obj in enumerate(objects, start=1):
        offsets.append(len(out))
        out.extend(f"{idx} 0 obj\n".encode())
        out.extend(obj)
        out.extend(b"\nendobj\n")
    xref_offset = len(out)
    out.extend(f"xref\n0 {len(objects)+1}\n".encode())
    out.extend(b"0000000000 65535 f \n")
    for off in offsets[1:]:
        out.extend(f"{off:010d} 00000 n \n".encode())
    out.extend(f"trailer\n<< /Size {len(objects)+1} /Root 1 0 R >>\nstartxref\n{xref_offset}\n%%EOF\n".encode())
    path.write_bytes(bytes(out))



def plain_text_lines(title: str, content: str) -> List[str]:
    lines: List[str] = []
    if title:
        lines.append(title)
        lines.append("")
    lines.extend(content.replace("\r\n", "\n").split("\n"))
    return lines


def write_basic_odt(path: Path, title: str, content: str) -> None:
    # Minimal standards-friendly ODT text export. This is a generated text document,
    # not a full rich-layout preservation layer.
    path.parent.mkdir(parents=True, exist_ok=True)
    body = "\n".join(
        f"<text:p>{html.escape(line)}</text:p>" for line in plain_text_lines(title, content)
    )
    content_xml = f'''<?xml version="1.0" encoding="UTF-8"?>
<office:document-content
 xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0"
 xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0"
 xmlns:style="urn:oasis:names:tc:opendocument:xmlns:style:1.0"
 office:version="1.2">
 <office:automatic-styles/>
 <office:body><office:text>{body}</office:text></office:body>
</office:document-content>
'''
    manifest_xml = '''<?xml version="1.0" encoding="UTF-8"?>
<manifest:manifest xmlns:manifest="urn:oasis:names:tc:opendocument:xmlns:manifest:1.0" manifest:version="1.2">
 <manifest:file-entry manifest:full-path="/" manifest:media-type="application/vnd.oasis.opendocument.text"/>
 <manifest:file-entry manifest:full-path="content.xml" manifest:media-type="text/xml"/>
</manifest:manifest>
'''
    meta_xml = f'''<?xml version="1.0" encoding="UTF-8"?>
<office:document-meta xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:dc="http://purl.org/dc/elements/1.1/" office:version="1.2">
 <office:meta><dc:title>{html.escape(title or APP_NAME)}</dc:title><dc:creator>{APP_NAME}</dc:creator><dc:date>{now_iso()}</dc:date></office:meta>
</office:document-meta>
'''
    with zipfile.ZipFile(path, "w") as zf:
        info = zipfile.ZipInfo("mimetype")
        info.compress_type = zipfile.ZIP_STORED
        zf.writestr(info, "application/vnd.oasis.opendocument.text")
        zf.writestr("META-INF/manifest.xml", manifest_xml, compress_type=zipfile.ZIP_DEFLATED)
        zf.writestr("content.xml", content_xml, compress_type=zipfile.ZIP_DEFLATED)
        zf.writestr("meta.xml", meta_xml, compress_type=zipfile.ZIP_DEFLATED)


def write_basic_docx(path: Path, title: str, content: str) -> None:
    # Minimal DOCX text export that opens in LibreOffice/Word-compatible editors.
    path.parent.mkdir(parents=True, exist_ok=True)
    paras = []
    for line in plain_text_lines(title, content):
        if line == "":
            paras.append("<w:p/>")
        else:
            paras.append(f"<w:p><w:r><w:t xml:space=\"preserve\">{html.escape(line)}</w:t></w:r></w:p>")
    document_xml = f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
 <w:body>{''.join(paras)}<w:sectPr><w:pgSz w:w="12240" w:h="15840"/><w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440"/></w:sectPr></w:body>
</w:document>
'''
    content_types = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
 <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
 <Default Extension="xml" ContentType="application/xml"/>
 <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
 <Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
</Types>
'''
    rels = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
 <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
 <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
</Relationships>
'''
    core = f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
 <dc:title>{html.escape(title or APP_NAME)}</dc:title><dc:creator>{APP_NAME}</dc:creator><dcterms:created xsi:type="dcterms:W3CDTF">{now_iso()}</dcterms:created>
</cp:coreProperties>
'''
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("[Content_Types].xml", content_types)
        zf.writestr("_rels/.rels", rels)
        zf.writestr("word/document.xml", document_xml)
        zf.writestr("docProps/core.xml", core)

def write_content_file(path: Path, title: str, content: str, fmt: str) -> str:
    fmt = normalise_save_format(fmt)
    path = ensure_extension(path, fmt)
    path.parent.mkdir(parents=True, exist_ok=True)
    if fmt == "html":
        path.write_text(markdown_to_basic_html(title, content), encoding="utf-8")
        return "html"
    if fmt == "pdf":
        write_basic_text_pdf(path, title, content)
        return "pdf_text"
    if fmt == "odt":
        write_basic_odt(path, title, content)
        return "odt_text"
    if fmt == "docx":
        write_basic_docx(path, title, content)
        return "docx_text"
    if fmt == "text":
        path.write_text(content, encoding="utf-8")
        return "text"
    path.write_text(content, encoding="utf-8")
    return "markdown"


def extract_pdf_text(path: Path) -> str:
    # Prefer pdftotext when present, then pypdf if installed, otherwise a safe placeholder.
    try:
        proc = subprocess.run(["pdftotext", "-layout", str(path), "-"], text=True, capture_output=True, timeout=15)
        if proc.returncode == 0 and proc.stdout.strip():
            return proc.stdout
    except Exception:
        pass
    try:
        from pypdf import PdfReader  # type: ignore
        reader = PdfReader(str(path))
        text_parts = []
        for i, page in enumerate(reader.pages, start=1):
            try:
                text_parts.append(f"\n--- Page {i} ---\n" + (page.extract_text() or ""))
            except Exception:
                text_parts.append(f"\n--- Page {i}: text extraction failed ---\n")
        if "".join(text_parts).strip():
            return "".join(text_parts)
    except Exception:
        pass
    return f"# Imported PDF\n\nSource: {path}\n\nNo readable text layer was extracted. You can still write replacement text here and save as a new PDF.\n"


def read_external_document_file(path: Path) -> Tuple[str, str]:
    suffix = path.suffix.lower()
    if suffix == ".pdf":
        return extract_pdf_text(path), "pdf_text"
    if suffix in {".md", ".markdown"}:
        return path.read_text(encoding="utf-8", errors="replace"), "markdown"
    if suffix in {".txt", ".text", ".log"}:
        return path.read_text(encoding="utf-8", errors="replace"), "text"
    if suffix in {".html", ".htm"}:
        return path.read_text(encoding="utf-8", errors="replace"), "html"
    if suffix == ".docx":
        return extract_docx_text(path), "docx_text"
    if suffix == ".odt":
        return extract_odt_text(path), "odt_text"
    return path.read_text(encoding="utf-8", errors="replace"), "text"


def _read_zip_member_limited(zf: zipfile.ZipFile, member_name: str, max_bytes: int = MAX_XML_EXTRACT_BYTES) -> bytes:
    info = zf.getinfo(member_name)
    if info.file_size > max_bytes:
        raise ValueError(f"Archive member too large: {member_name}")
    with zf.open(info, "r") as src:
        data = src.read(max_bytes + 1)
    if len(data) > max_bytes:
        raise ValueError(f"Archive member exceeds limit: {member_name}")
    return data


def extract_docx_text(path: Path) -> str:
    try:
        if path.stat().st_size > MAX_RESTORE_FILE_BYTES:
            raise ValueError("DOCX file exceeds safety limit")
        with zipfile.ZipFile(path) as zf:
            xml = _read_zip_member_limited(zf, "word/document.xml").decode("utf-8", errors="replace")
        xml = re.sub(r"</w:p>", "\n", xml)
        xml = re.sub(r"<[^>]+>", "", xml)
        return html.unescape(xml).strip() or f"# Imported DOCX\n\nSource: {path}\n\nNo readable text was extracted."
    except Exception:
        return f"# Imported DOCX\n\nSource: {path}\n\nNo readable text was extracted."


def extract_odt_text(path: Path) -> str:
    try:
        if path.stat().st_size > MAX_RESTORE_FILE_BYTES:
            raise ValueError("ODT file exceeds safety limit")
        with zipfile.ZipFile(path) as zf:
            xml = _read_zip_member_limited(zf, "content.xml").decode("utf-8", errors="replace")
        xml = re.sub(r"</text:p>", "\n", xml)
        xml = re.sub(r"<[^>]+>", "", xml)
        return html.unescape(xml).strip() or f"# Imported ODT\n\nSource: {path}\n\nNo readable text was extracted."
    except Exception:
        return f"# Imported ODT\n\nSource: {path}\n\nNo readable text was extracted."

def export_formats_json() -> Dict[str, Any]:
    init_environment()
    return {
        "formats": [
            {"key": key, "label": spec["label"], "extension": spec["extension"], "content_format": spec["content_format"]}
            for key, spec in SAVE_FORMATS.items()
        ],
        "notes": {
            "pdf": "Built-in text-layer PDF export. Complex PDF layout/forms/images are not preserved.",
            "odt": "Generated OpenDocument text file containing plain document text.",
            "docx": "Generated Word-compatible DOCX containing plain document text.",
        },
        "libreoffice": libreoffice_status_json(write_contract=False),
    }


def safe_read_document(doc_id: str, limit: int = 20000) -> Dict[str, Any]:
    init_environment()
    doc = get_document(doc_id)
    if not doc:
        return {"found": False, "id": doc_id, "content_returned": False}
    content = read_document_text(doc_id) or ""
    limit = max(1000, min(200000, int(limit)))
    truncated = len(content) > limit
    return {
        "found": True,
        "document": doc,
        "content": content[:limit],
        "content_returned": True,
        "truncated": truncated,
        "limit": limit,
        "local_only": True,
        "network_enabled": False,
        "telemetry_enabled": False,
        "timestamp": now_iso(),
    }


def vault_metadata_json() -> Dict[str, Any]:
    init_environment()
    docs = list_documents(include_archived=True)
    enriched: List[Dict[str, Any]] = []
    for d in docs:
        path = Path(str(d.get("file_path") or ""))
        item = dict(d)
        item["file_exists"] = path.exists()
        item["style_sidecar"] = str(document_style_sidecar_path(path)) if path.name else ""
        item["style_sidecar_exists"] = document_style_sidecar_path(path).exists() if path.name else False
        item["full_text_returned"] = False
        enriched.append(item)
    return {
        "app": APP_NAME,
        "app_id": APP_ID,
        "program_id": PROGRAM_ID,
        "version": VERSION,
        "metadata_contract": "sentinel_documents_vault_metadata_v1",
        "vault_root_detected": AEGIS_VAULT_ROOT.exists(),
        "vault_root": str(AEGIS_VAULT_ROOT),
        "vault_documents": str(AEGIS_VAULT_DOCUMENTS_DIR),
        "documents_root": str(DOCUMENTS_ROOT),
        "document_count_total": len(docs),
        "library_summary": document_library_summary(),
        "documents": enriched,
        "bridges": bridge_status(),
        "templates": templates_json(),
        "format_options": format_options_json(),
        "safe_read_available": True,
        "full_text_returned": False,
        "local_only": True,
        "network_enabled": False,
        "telemetry_enabled": False,
        "timestamp": now_iso(),
    }


def export_vault_metadata(output_path: Optional[str] = None) -> Dict[str, Any]:
    init_environment()
    metadata = vault_metadata_json()
    if output_path:
        dest = Path(output_path).expanduser()
    else:
        dest = VAULT_METADATA_DIR / "sentinel_documents_vault_metadata.json"
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    copied_to_vault = ""
    if AEGIS_VAULT_ROOT.exists():
        try:
            vault_dest = AEGIS_VAULT_DOCUMENTS_DIR / "sentinel_documents_vault_metadata.json"
            vault_dest.parent.mkdir(parents=True, exist_ok=True)
            vault_dest.write_text(json.dumps(metadata, indent=2), encoding="utf-8")
            copied_to_vault = str(vault_dest)
        except Exception:
            copied_to_vault = ""
    return {
        "exported": True,
        "path": str(dest),
        "copied_to_vault": copied_to_vault,
        "sha256": sha256_file(dest),
        "document_count_total": metadata["document_count_total"],
        "full_text_returned": False,
        "local_only": True,
        "timestamp": now_iso(),
    }


def aegis_capabilities_json() -> Dict[str, Any]:
    h = health_json()
    return {
        "program": APP_NAME,
        "program_id": PROGRAM_ID,
        "app_id": APP_ID,
        "version": VERSION,
        "capability_contract": "sentinel_documents_aegis_capabilities_v1",
        "ready": True,
        "local_only": True,
        "network_enabled": False,
        "telemetry_enabled": False,
        "document_creation": True,
        "templates": True,
        "contacts_bridge": True,
        "inventory_bridge": True,
        "jobs_bridge": True,
        "export_layer": True,
        "libreoffice_handoff": bool(libreoffice_binary()),
        "document_search": True,
        "document_management": True,
        "vault_metadata_export": True,
        "safe_read_document": True,
        "formatting_controls": True,
        "font_options": True,
        "expanded_font_family_discovery": True,
        "paragraph_formatting": True,
        "release_candidate_audit": True,
        "v1_readiness_report": True,
        "silent_control_of_other_apps": False,
        "supported_actions": [a.get("name") for a in aegis_actions_json()["actions"]],
        "paths": h["paths"],
        "bridges": h["bridges"],
        "timestamp": now_iso(),
    }


def export_document(doc_id: str, fmt: str = "markdown", output_path: Optional[str] = None) -> Dict[str, Any]:
    init_environment()
    doc = get_document(doc_id)
    if not doc:
        raise ValueError(f"Document not found: {doc_id}")
    content = read_document_text(doc_id)
    if content is None:
        raise ValueError(f"Document file missing or unreadable: {doc_id}")
    fmt = normalise_save_format(fmt)
    title = str(doc.get("title") or doc_id)
    if output_path:
        dest = Path(output_path).expanduser()
    else:
        dest = EXPORTS_DIR / f"{safe_slug(title)}_{doc_id}{SAVE_FORMATS[fmt]['extension']}"
    dest = ensure_extension(dest, fmt)
    content_format = write_content_file(dest, title, content, fmt)
    result = {
        "exported": True,
        "document_id": doc_id,
        "title": title,
        "format": fmt,
        "content_format": content_format,
        "path": str(dest),
        "sha256": sha256_file(dest),
        "timestamp": now_iso(),
        "local_only": True,
    }
    return result


def libreoffice_binary() -> Optional[str]:
    for name in ("libreoffice", "soffice"):
        found = shutil.which(name)
        if found:
            return found
    return None


def libreoffice_status_json(write_contract: bool = True) -> Dict[str, Any]:
    init_environment()
    binary = libreoffice_binary()
    result = {
        "installed": bool(binary),
        "binary": binary or "",
        "supported_handoff_formats": ["odt", "docx", "pdf", "html", "markdown", "text"],
        "handoff_mode": "external_editor_explicit_user_action",
        "silent_control": False,
        "local_only": True,
        "timestamp": now_iso(),
    }
    if write_contract:
        write_aegis_contract_files()
    return result


def open_in_libreoffice(doc_id: str, preferred_format: str = "odt") -> Dict[str, Any]:
    init_environment()
    binary = libreoffice_binary()
    if not binary:
        return {"opened": False, "reason": "LibreOffice/soffice not found", "installed": False}
    doc = get_document(doc_id)
    if not doc:
        raise ValueError(f"Document not found: {doc_id}")
    path = Path(doc["file_path"])
    fmt = normalise_save_format(preferred_format)
    if path.suffix.lower() not in {".odt", ".docx", ".pdf", ".html", ".htm", ".txt", ".md"}:
        exported = export_document(doc_id, fmt=fmt)
        path = Path(exported["path"])
    elif path.suffix.lower() in {".md"}:
        # Create an ODT handoff copy so LibreOffice opens a document editor, not a text/code view.
        exported = export_document(doc_id, fmt=fmt)
        path = Path(exported["path"])
    subprocess.Popen([binary, str(path)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return {"opened": True, "document_id": doc_id, "path": str(path), "binary": binary, "timestamp": now_iso()}


# ----------------------------- Contacts Bridge -----------------------------

CONTACT_ALIASES: Dict[str, List[str]] = {
    "contact_code": ["contact_code", "code", "id", "contact_id", "sentinel_contact_code", "quickfill_contact_code"],
    "contact_name": ["contact_name", "name", "full_name", "display_name", "person_name", "customer_name"],
    "contact_phone": ["contact_phone", "phone", "phone_number", "mobile", "mobile_phone", "cell", "customer_phone"],
    "contact_email": ["contact_email", "email", "email_address", "mail", "customer_email"],
    "contact_address": ["contact_address", "address", "postal_address", "street_address", "customer_address"],
    "contact_company": ["contact_company", "company", "business", "organisation", "organization", "employer"],
    "notes": ["notes", "note", "description", "contact_notes"],
}


def _first_alias(flat: Dict[str, str], aliases: List[str]) -> str:
    for key in aliases:
        if key in flat and str(flat[key]).strip():
            return str(flat[key]).strip()
    # support nested flattened keys like contact_name/name_details_full_name
    for alias in aliases:
        for key, value in flat.items():
            if key.endswith("_" + alias) and str(value).strip():
                return str(value).strip()
    return ""


def _join_address(flat: Dict[str, str]) -> str:
    direct = _first_alias(flat, CONTACT_ALIASES["contact_address"])
    if direct:
        return direct
    parts = []
    for key in ["street", "street_1", "street_address", "suburb", "city", "state", "postcode", "postal_code", "country"]:
        val = flat.get(key, "")
        if val:
            parts.append(str(val).strip())
    return ", ".join([p for p in parts if p])


def _normalise_contact_object(obj: Any, source_file: str = "") -> Dict[str, Any]:
    flat = flatten_context_object(obj)
    first_name = flat.get("first_name", "").strip()
    last_name = flat.get("last_name", "").strip()
    name = _first_alias(flat, CONTACT_ALIASES["contact_name"])
    if not name and (first_name or last_name):
        name = (first_name + " " + last_name).strip()
    phone = _first_alias(flat, CONTACT_ALIASES["contact_phone"])
    email = _first_alias(flat, CONTACT_ALIASES["contact_email"])
    address = _join_address(flat)
    company = _first_alias(flat, CONTACT_ALIASES["contact_company"])
    notes = _first_alias(flat, CONTACT_ALIASES["notes"])
    code = _first_alias(flat, CONTACT_ALIASES["contact_code"])
    if not code:
        seed = "|".join([name, email, phone, company]) or json.dumps(obj, sort_keys=True, default=str)
        code = "SCON-" + hashlib.sha256(seed.encode("utf-8")).hexdigest()[:8].upper()
    return {
        "contact_code": code,
        "contact_name": name or code,
        "contact_phone": phone,
        "contact_email": email,
        "contact_address": address,
        "contact_company": company,
        "company": company,
        "notes": notes,
        "source_file": source_file,
        "raw": obj,
        "flat": flat,
    }


def _extract_contact_objects(data: Any) -> List[Any]:
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        for key in ["contacts", "contact_records", "records", "items", "results"]:
            if isinstance(data.get(key), list):
                return data[key]
        for key in ["contact", "record", "quickfill", "data"]:
            if isinstance(data.get(key), dict):
                return [data[key]]
        return [data]
    return []


def import_contact_bridge_file(path: str) -> Dict[str, Any]:
    init_environment()
    src = Path(path).expanduser()
    if not src.exists():
        raise FileNotFoundError(f"Contact bridge file not found: {src}")
    data = json.loads(src.read_text(encoding="utf-8"))
    objects = _extract_contact_objects(data)
    if not objects:
        raise ValueError("No contact objects found in contact bridge JSON")
    imported = []
    ts = now_iso()
    CONTACTS_BRIDGE_DIR.joinpath("inbox").mkdir(parents=True, exist_ok=True)
    CONTACTS_BRIDGE_DIR.joinpath("outbox").mkdir(parents=True, exist_ok=True)
    copied_name = f"imported_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{safe_slug(src.stem)}{src.suffix or '.json'}"
    copied_to = CONTACTS_BRIDGE_DIR / "inbox" / copied_name
    try:
        shutil.copy2(src, copied_to)
    except Exception:
        copied_to.write_text(src.read_text(encoding="utf-8"), encoding="utf-8")
    with db_connect() as conn:
        for obj in objects:
            contact = _normalise_contact_object(obj, str(copied_to))
            conn.execute(
                """
                INSERT INTO contact_bridge_cache (
                    contact_code, contact_name, phone, email, address, company, notes,
                    source_file, raw_json, imported_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(contact_code) DO UPDATE SET
                    contact_name=excluded.contact_name,
                    phone=excluded.phone,
                    email=excluded.email,
                    address=excluded.address,
                    company=excluded.company,
                    notes=excluded.notes,
                    source_file=excluded.source_file,
                    raw_json=excluded.raw_json,
                    updated_at=excluded.updated_at
                """,
                (
                    contact["contact_code"],
                    contact["contact_name"],
                    contact["contact_phone"],
                    contact["contact_email"],
                    contact["contact_address"],
                    contact["contact_company"],
                    contact["notes"],
                    contact["source_file"],
                    json.dumps(contact["raw"], ensure_ascii=False, sort_keys=True),
                    ts,
                    ts,
                ),
            )
            imported.append({k: contact[k] for k in ["contact_code", "contact_name", "contact_phone", "contact_email", "contact_company"]})
        conn.commit()
    summary = {
        "imported": True,
        "count": len(imported),
        "contacts": imported,
        "source_file": str(src),
        "stored_copy": str(copied_to),
        "timestamp": ts,
    }
    out = CONTACTS_BRIDGE_DIR / "outbox" / f"contact_import_summary_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    out.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    write_aegis_contract_files()
    return summary


def list_contact_bridge_records() -> List[Dict[str, Any]]:
    init_environment()
    with db_connect() as conn:
        rows = conn.execute(
            "SELECT contact_code, contact_name, phone, email, address, company, notes, source_file, imported_at, updated_at FROM contact_bridge_cache ORDER BY contact_name COLLATE NOCASE"
        ).fetchall()
    return [dict(r) for r in rows]


def contact_record_count() -> int:
    try:
        with db_connect() as conn:
            row = conn.execute("SELECT COUNT(*) AS n FROM contact_bridge_cache").fetchone()
        return int(row["n"] if row else 0)
    except Exception:
        return 0


def get_contact_bridge_record(contact_code: str) -> Optional[Dict[str, Any]]:
    init_environment()
    with db_connect() as conn:
        row = conn.execute("SELECT * FROM contact_bridge_cache WHERE contact_code=?", (contact_code,)).fetchone()
    return dict(row) if row else None


def contact_context(contact_code: str) -> Dict[str, str]:
    row = get_contact_bridge_record(contact_code)
    if not row:
        raise KeyError(f"Contact not found in Sentinel Documents contact bridge cache: {contact_code}")
    try:
        raw = json.loads(row.get("raw_json") or "{}")
    except Exception:
        raw = {}
    ctx = default_template_context()
    ctx.update(flatten_context_object(raw))
    ctx.update(
        {
            "contact_code": row.get("contact_code") or "",
            "contact_name": row.get("contact_name") or "",
            "contact_phone": row.get("phone") or "",
            "contact_email": row.get("email") or "",
            "contact_address": row.get("address") or "",
            "contact_company": row.get("company") or "",
            "company": row.get("company") or "",
            "notes": row.get("notes") or ctx.get("notes", ""),
        }
    )
    return {str(k): "" if v is None else str(v) for k, v in ctx.items()}


def create_contact_document(contact_code: str, template_name: str, title: Optional[str] = None) -> Dict[str, Any]:
    ctx = contact_context(contact_code)
    doc_title = title or f"{ctx.get('contact_name') or contact_code} - {Path(template_name).stem.replace('-', ' ').title()}"
    result = create_document_from_template(
        template_name,
        ctx,
        title=doc_title,
        category="Contacts",
        doc_type="Contact Document",
        linked_contact_code=contact_code,
    )
    export_contact_document_bridge(result["document_id"])
    return result


def export_contact_document_bridge(document_id: Optional[str] = None) -> Dict[str, Any]:
    init_environment()
    docs = []
    if document_id:
        doc = get_document(document_id)
        if not doc:
            raise KeyError(f"Document not found: {document_id}")
        if doc.get("linked_contact_code"):
            docs = [doc]
    else:
        with db_connect() as conn:
            rows = conn.execute("SELECT * FROM documents WHERE linked_contact_code IS NOT NULL AND linked_contact_code!='' ORDER BY modified_at DESC").fetchall()
        docs = [dict(r) for r in rows]
    records = []
    for doc in docs:
        contact = get_contact_bridge_record(doc.get("linked_contact_code") or "") or {}
        records.append(
            {
                "document_id": doc.get("id"),
                "title": doc.get("title"),
                "category": doc.get("category"),
                "doc_type": doc.get("doc_type"),
                "file_path": doc.get("file_path"),
                "sha256": doc.get("sha256"),
                "linked_contact_code": doc.get("linked_contact_code"),
                "contact_name": contact.get("contact_name"),
                "contact_email": contact.get("email"),
                "contact_phone": contact.get("phone"),
                "status": doc.get("status"),
                "modified_at": doc.get("modified_at"),
            }
        )
    payload = {
        "app": APP_NAME,
        "app_id": APP_ID,
        "program_id": PROGRAM_ID,
        "version": VERSION,
        "bridge": "contacts",
        "mode": "local_file_handoff",
        "silent_control": False,
        "document_count": len(records),
        "documents": records,
        "timestamp": now_iso(),
    }
    out = CONTACTS_BRIDGE_DIR / "outbox" / f"document_contact_bridge_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    payload["export_path"] = str(out)
    write_aegis_contract_files()
    return payload


# ----------------------------- Inventory Bridge -----------------------------

INVENTORY_ALIASES: Dict[str, List[str]] = {
    "item_code": ["item_code", "code", "id", "item_id", "inventory_code", "sentinel_inventory_code", "sku", "asset_id"],
    "item_name": ["item_name", "name", "title", "display_name", "asset_name", "product_name"],
    "asset_tag": ["asset_tag", "tag", "asset_number", "asset_no", "property_tag"],
    "item_category": ["item_category", "category", "type", "asset_category", "class"],
    "model": ["model", "model_number", "model_no", "part_number", "part_no"],
    "serial_number": ["serial_number", "serial", "serial_no", "serial_num", "sn"],
    "condition": ["condition", "state", "item_condition", "asset_condition"],
    "location": ["location", "stored_location", "storage_location", "room", "site"],
    "quantity": ["quantity", "qty", "count", "stock", "stock_count", "on_hand"],
    "supplier": ["supplier", "vendor", "seller", "store", "purchased_from"],
    "purchase_price": ["purchase_price", "price", "cost", "value", "amount", "purchase_cost"],
    "purchase_date": ["purchase_date", "bought_date", "date_purchased", "acquired_date"],
    "warranty_status": ["warranty_status", "warranty", "warranty_state"],
    "warranty_end": ["warranty_end", "warranty_expiry", "warranty_expires", "warranty_until"],
    "warranty_details": ["warranty_details", "warranty_notes", "warranty_description"],
    "notes": ["notes", "note", "description", "item_notes", "asset_notes"],
}


def _normalise_inventory_object(obj: Any, source_file: str = "") -> Dict[str, Any]:
    flat = flatten_context_object(obj)
    item_name = _first_alias(flat, INVENTORY_ALIASES["item_name"])
    serial = _first_alias(flat, INVENTORY_ALIASES["serial_number"])
    asset_tag = _first_alias(flat, INVENTORY_ALIASES["asset_tag"])
    code = _first_alias(flat, INVENTORY_ALIASES["item_code"])
    if not code:
        seed = "|".join([item_name, serial, asset_tag, _first_alias(flat, INVENTORY_ALIASES["model"])]) or json.dumps(obj, sort_keys=True, default=str)
        code = "SINV-" + hashlib.sha256(seed.encode("utf-8")).hexdigest()[:8].upper()
    inv = {
        "item_code": code,
        "item_name": item_name or code,
        "asset_tag": asset_tag,
        "item_category": _first_alias(flat, INVENTORY_ALIASES["item_category"]),
        "model": _first_alias(flat, INVENTORY_ALIASES["model"]),
        "serial_number": serial,
        "condition": _first_alias(flat, INVENTORY_ALIASES["condition"]),
        "location": _first_alias(flat, INVENTORY_ALIASES["location"]),
        "quantity": _first_alias(flat, INVENTORY_ALIASES["quantity"]),
        "supplier": _first_alias(flat, INVENTORY_ALIASES["supplier"]),
        "purchase_price": _first_alias(flat, INVENTORY_ALIASES["purchase_price"]),
        "purchase_date": _first_alias(flat, INVENTORY_ALIASES["purchase_date"]),
        "warranty_status": _first_alias(flat, INVENTORY_ALIASES["warranty_status"]),
        "warranty_end": _first_alias(flat, INVENTORY_ALIASES["warranty_end"]),
        "warranty_details": _first_alias(flat, INVENTORY_ALIASES["warranty_details"]),
        "notes": _first_alias(flat, INVENTORY_ALIASES["notes"]),
        "source_file": source_file,
        "raw": obj,
        "flat": flat,
    }
    return inv


def _extract_inventory_objects(data: Any) -> List[Any]:
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        for key in ["inventory", "inventory_items", "items", "assets", "records", "results", "stock"]:
            if isinstance(data.get(key), list):
                return data[key]
        for key in ["item", "asset", "record", "quickfill", "data"]:
            if isinstance(data.get(key), dict):
                return [data[key]]
        return [data]
    return []


def import_inventory_bridge_file(path: str) -> Dict[str, Any]:
    init_environment()
    src = Path(path).expanduser()
    if not src.exists():
        raise FileNotFoundError(f"Inventory bridge file not found: {src}")
    data = json.loads(src.read_text(encoding="utf-8"))
    objects = _extract_inventory_objects(data)
    if not objects:
        raise ValueError("No inventory item objects found in inventory bridge JSON")
    imported = []
    ts = now_iso()
    INVENTORY_BRIDGE_DIR.joinpath("inbox").mkdir(parents=True, exist_ok=True)
    INVENTORY_BRIDGE_DIR.joinpath("outbox").mkdir(parents=True, exist_ok=True)
    copied_name = f"imported_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{safe_slug(src.stem)}{src.suffix or '.json'}"
    copied_to = INVENTORY_BRIDGE_DIR / "inbox" / copied_name
    try:
        shutil.copy2(src, copied_to)
    except Exception:
        copied_to.write_text(src.read_text(encoding="utf-8"), encoding="utf-8")
    with db_connect() as conn:
        for obj in objects:
            inv = _normalise_inventory_object(obj, str(copied_to))
            conn.execute(
                """
                INSERT INTO inventory_bridge_cache (
                    item_code, item_name, asset_tag, item_category, model, serial_number,
                    condition, location, quantity, supplier, purchase_price, purchase_date,
                    warranty_status, warranty_end, notes, source_file, raw_json, imported_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(item_code) DO UPDATE SET
                    item_name=excluded.item_name,
                    asset_tag=excluded.asset_tag,
                    item_category=excluded.item_category,
                    model=excluded.model,
                    serial_number=excluded.serial_number,
                    condition=excluded.condition,
                    location=excluded.location,
                    quantity=excluded.quantity,
                    supplier=excluded.supplier,
                    purchase_price=excluded.purchase_price,
                    purchase_date=excluded.purchase_date,
                    warranty_status=excluded.warranty_status,
                    warranty_end=excluded.warranty_end,
                    notes=excluded.notes,
                    source_file=excluded.source_file,
                    raw_json=excluded.raw_json,
                    updated_at=excluded.updated_at
                """,
                (
                    inv["item_code"], inv["item_name"], inv["asset_tag"], inv["item_category"],
                    inv["model"], inv["serial_number"], inv["condition"], inv["location"],
                    inv["quantity"], inv["supplier"], inv["purchase_price"], inv["purchase_date"],
                    inv["warranty_status"], inv["warranty_end"], inv["notes"], inv["source_file"],
                    json.dumps(inv["raw"], ensure_ascii=False, sort_keys=True), ts, ts,
                ),
            )
            imported.append({k: inv[k] for k in ["item_code", "item_name", "serial_number", "location", "condition"]})
        conn.commit()
    summary = {
        "imported": True,
        "count": len(imported),
        "items": imported,
        "source_file": str(src),
        "stored_copy": str(copied_to),
        "timestamp": ts,
    }
    out = INVENTORY_BRIDGE_DIR / "outbox" / f"inventory_import_summary_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    out.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    write_aegis_contract_files()
    return summary


def list_inventory_bridge_records() -> List[Dict[str, Any]]:
    init_environment()
    with db_connect() as conn:
        rows = conn.execute(
            "SELECT item_code, item_name, asset_tag, item_category, model, serial_number, condition, location, quantity, supplier, purchase_price, purchase_date, warranty_status, warranty_end, notes, source_file, imported_at, updated_at FROM inventory_bridge_cache ORDER BY item_name COLLATE NOCASE"
        ).fetchall()
    return [dict(r) for r in rows]


def inventory_record_count() -> int:
    try:
        with db_connect() as conn:
            row = conn.execute("SELECT COUNT(*) AS n FROM inventory_bridge_cache").fetchone()
        return int(row["n"] if row else 0)
    except Exception:
        return 0


def get_inventory_bridge_record(item_code: str) -> Optional[Dict[str, Any]]:
    init_environment()
    with db_connect() as conn:
        row = conn.execute("SELECT * FROM inventory_bridge_cache WHERE item_code=?", (item_code,)).fetchone()
    return dict(row) if row else None


def inventory_context(item_code: str) -> Dict[str, str]:
    row = get_inventory_bridge_record(item_code)
    if not row:
        raise KeyError(f"Inventory item not found in Sentinel Documents inventory bridge cache: {item_code}")
    try:
        raw = json.loads(row.get("raw_json") or "{}")
    except Exception:
        raw = {}
    ctx = default_template_context()
    ctx.update(flatten_context_object(raw))
    ctx.update(
        {
            "item_code": row.get("item_code") or "",
            "item_name": row.get("item_name") or "",
            "asset_tag": row.get("asset_tag") or "",
            "item_category": row.get("item_category") or "",
            "model": row.get("model") or "",
            "serial_number": row.get("serial_number") or "",
            "condition": row.get("condition") or "",
            "location": row.get("location") or "",
            "quantity": row.get("quantity") or "",
            "supplier": row.get("supplier") or "",
            "purchase_price": row.get("purchase_price") or "",
            "purchase_date": row.get("purchase_date") or "",
            "warranty_status": row.get("warranty_status") or "",
            "warranty_end": row.get("warranty_end") or "",
            "notes": row.get("notes") or ctx.get("notes", ""),
        }
    )
    return {str(k): "" if v is None else str(v) for k, v in ctx.items()}


def create_inventory_document(item_code: str, template_name: str, title: Optional[str] = None) -> Dict[str, Any]:
    ctx = inventory_context(item_code)
    doc_title = title or f"{ctx.get('item_name') or item_code} - {Path(template_name).stem.replace('-', ' ').title()}"
    result = create_document_from_template(
        template_name,
        ctx,
        title=doc_title,
        category="Inventory",
        doc_type="Inventory Document",
        linked_inventory_code=item_code,
    )
    export_inventory_document_bridge(result["document_id"])
    return result


def export_inventory_document_bridge(document_id: Optional[str] = None) -> Dict[str, Any]:
    init_environment()
    docs = []
    if document_id:
        doc = get_document(document_id)
        if not doc:
            raise KeyError(f"Document not found: {document_id}")
        if doc.get("linked_inventory_code"):
            docs = [doc]
    else:
        with db_connect() as conn:
            rows = conn.execute("SELECT * FROM documents WHERE linked_inventory_code IS NOT NULL AND linked_inventory_code!='' ORDER BY modified_at DESC").fetchall()
        docs = [dict(r) for r in rows]
    records = []
    for doc in docs:
        item = get_inventory_bridge_record(doc.get("linked_inventory_code") or "") or {}
        records.append(
            {
                "document_id": doc.get("id"),
                "title": doc.get("title"),
                "category": doc.get("category"),
                "doc_type": doc.get("doc_type"),
                "file_path": doc.get("file_path"),
                "sha256": doc.get("sha256"),
                "linked_inventory_code": doc.get("linked_inventory_code"),
                "item_name": item.get("item_name"),
                "serial_number": item.get("serial_number"),
                "asset_tag": item.get("asset_tag"),
                "location": item.get("location"),
                "condition": item.get("condition"),
                "status": doc.get("status"),
                "modified_at": doc.get("modified_at"),
            }
        )
    payload = {
        "app": APP_NAME,
        "app_id": APP_ID,
        "program_id": PROGRAM_ID,
        "version": VERSION,
        "bridge": "inventory",
        "mode": "local_file_handoff",
        "silent_control": False,
        "document_count": len(records),
        "documents": records,
        "timestamp": now_iso(),
    }
    out = INVENTORY_BRIDGE_DIR / "outbox" / f"document_inventory_bridge_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    payload["export_path"] = str(out)
    write_aegis_contract_files()
    return payload


# ----------------------------- Jobs Bridge -----------------------------

JOB_ALIASES: Dict[str, List[str]] = {
    "job_code": ["job_code", "code", "id", "job_id", "sentinel_job_code", "work_order", "work_order_id"],
    "job_title": ["job_title", "title", "name", "summary", "subject", "job_name"],
    "job_status": ["job_status", "status", "state"],
    "priority": ["priority", "urgency"],
    "contact_code": ["contact_code", "customer_code", "client_code", "linked_contact_code"],
    "contact_name": ["contact_name", "customer_name", "client_name", "name"],
    "contact_phone": ["contact_phone", "customer_phone", "client_phone", "phone"],
    "contact_email": ["contact_email", "customer_email", "client_email", "email"],
    "item_code": ["item_code", "inventory_code", "asset_code", "linked_inventory_code"],
    "item_name": ["item_name", "asset_name", "device", "equipment", "product"],
    "date_started": ["date_started", "started", "start_date", "opened_at"],
    "date_completed": ["date_completed", "completed", "completion_date", "closed_at"],
    "due_date": ["due_date", "deadline", "target_date"],
    "job_location": ["job_location", "location", "site", "address", "work_location"],
    "estimated_total": ["estimated_total", "estimate", "quote_total", "total", "amount"],
    "labour": ["labour", "labor", "labour_notes", "labor_notes"],
    "materials": ["materials", "parts", "inventory_items", "items_used"],
    "job_description": ["job_description", "description", "scope", "work_scope"],
    "issue": ["issue", "problem", "fault", "symptom"],
    "diagnosis": ["diagnosis", "assessment", "finding"],
    "work_completed": ["work_completed", "work_done", "completed_work", "resolution"],
    "completion_notes": ["completion_notes", "completion", "finish_notes"],
    "handoff_notes": ["handoff_notes", "customer_handoff", "handover"],
    "notes": ["notes", "note", "internal_notes", "comments"],
}


def _normalise_job_object(obj: Any, source_file: str = "") -> Dict[str, Any]:
    flat = flatten_context_object(obj)
    title = _first_alias(flat, JOB_ALIASES["job_title"])
    contact_name = _first_alias(flat, JOB_ALIASES["contact_name"])
    code = _first_alias(flat, JOB_ALIASES["job_code"])
    if not code:
        seed = "|".join([title, contact_name, _first_alias(flat, JOB_ALIASES["date_started"]), _first_alias(flat, JOB_ALIASES["item_name"])]) or json.dumps(obj, sort_keys=True, default=str)
        code = "SJOB-" + hashlib.sha256(seed.encode("utf-8")).hexdigest()[:8].upper()
    job = {
        "job_code": code,
        "job_title": title or code,
        "job_status": _first_alias(flat, JOB_ALIASES["job_status"]),
        "priority": _first_alias(flat, JOB_ALIASES["priority"]),
        "contact_code": _first_alias(flat, JOB_ALIASES["contact_code"]),
        "contact_name": contact_name,
        "contact_phone": _first_alias(flat, JOB_ALIASES["contact_phone"]),
        "contact_email": _first_alias(flat, JOB_ALIASES["contact_email"]),
        "item_code": _first_alias(flat, JOB_ALIASES["item_code"]),
        "item_name": _first_alias(flat, JOB_ALIASES["item_name"]),
        "date_started": _first_alias(flat, JOB_ALIASES["date_started"]),
        "date_completed": _first_alias(flat, JOB_ALIASES["date_completed"]),
        "due_date": _first_alias(flat, JOB_ALIASES["due_date"]),
        "job_location": _first_alias(flat, JOB_ALIASES["job_location"]),
        "estimated_total": _first_alias(flat, JOB_ALIASES["estimated_total"]),
        "labour": _first_alias(flat, JOB_ALIASES["labour"]),
        "materials": _first_alias(flat, JOB_ALIASES["materials"]),
        "job_description": _first_alias(flat, JOB_ALIASES["job_description"]),
        "issue": _first_alias(flat, JOB_ALIASES["issue"]),
        "diagnosis": _first_alias(flat, JOB_ALIASES["diagnosis"]),
        "work_completed": _first_alias(flat, JOB_ALIASES["work_completed"]),
        "completion_notes": _first_alias(flat, JOB_ALIASES["completion_notes"]),
        "handoff_notes": _first_alias(flat, JOB_ALIASES["handoff_notes"]),
        "notes": _first_alias(flat, JOB_ALIASES["notes"]),
        "source_file": source_file,
        "raw": obj,
        "flat": flat,
    }
    return job


def _extract_job_objects(data: Any) -> List[Any]:
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        for key in ["jobs", "job_records", "work_orders", "records", "results", "tasks"]:
            if isinstance(data.get(key), list):
                return data[key]
        for key in ["job", "work_order", "record", "quickfill", "data"]:
            if isinstance(data.get(key), dict):
                return [data[key]]
        return [data]
    return []


def import_job_bridge_file(path: str) -> Dict[str, Any]:
    init_environment()
    src = Path(path).expanduser()
    if not src.exists():
        raise FileNotFoundError(f"Jobs bridge file not found: {src}")
    data = json.loads(src.read_text(encoding="utf-8"))
    objects = _extract_job_objects(data)
    if not objects:
        raise ValueError("No job objects found in jobs bridge JSON")
    imported = []
    ts = now_iso()
    JOBS_BRIDGE_DIR.joinpath("inbox").mkdir(parents=True, exist_ok=True)
    JOBS_BRIDGE_DIR.joinpath("outbox").mkdir(parents=True, exist_ok=True)
    copied_name = f"imported_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{safe_slug(src.stem)}{src.suffix or '.json'}"
    copied_to = JOBS_BRIDGE_DIR / "inbox" / copied_name
    try:
        shutil.copy2(src, copied_to)
    except Exception:
        copied_to.write_text(src.read_text(encoding="utf-8"), encoding="utf-8")
    with db_connect() as conn:
        for obj in objects:
            job = _normalise_job_object(obj, str(copied_to))
            conn.execute(
                """
                INSERT INTO job_bridge_cache (
                    job_code, job_title, job_status, priority, contact_code, contact_name, contact_phone, contact_email,
                    item_code, item_name, date_started, date_completed, due_date, job_location, estimated_total,
                    labour, materials, issue, diagnosis, work_completed, completion_notes, handoff_notes, notes,
                    source_file, raw_json, imported_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(job_code) DO UPDATE SET
                    job_title=excluded.job_title,
                    job_status=excluded.job_status,
                    priority=excluded.priority,
                    contact_code=excluded.contact_code,
                    contact_name=excluded.contact_name,
                    contact_phone=excluded.contact_phone,
                    contact_email=excluded.contact_email,
                    item_code=excluded.item_code,
                    item_name=excluded.item_name,
                    date_started=excluded.date_started,
                    date_completed=excluded.date_completed,
                    due_date=excluded.due_date,
                    job_location=excluded.job_location,
                    estimated_total=excluded.estimated_total,
                    labour=excluded.labour,
                    materials=excluded.materials,
                    issue=excluded.issue,
                    diagnosis=excluded.diagnosis,
                    work_completed=excluded.work_completed,
                    completion_notes=excluded.completion_notes,
                    handoff_notes=excluded.handoff_notes,
                    notes=excluded.notes,
                    source_file=excluded.source_file,
                    raw_json=excluded.raw_json,
                    updated_at=excluded.updated_at
                """,
                (
                    job["job_code"], job["job_title"], job["job_status"], job["priority"], job["contact_code"],
                    job["contact_name"], job["contact_phone"], job["contact_email"], job["item_code"], job["item_name"],
                    job["date_started"], job["date_completed"], job["due_date"], job["job_location"], job["estimated_total"],
                    job["labour"], job["materials"], job["issue"], job["diagnosis"], job["work_completed"],
                    job["completion_notes"], job["handoff_notes"], job["notes"], job["source_file"],
                    json.dumps(job["raw"], ensure_ascii=False, sort_keys=True), ts, ts,
                ),
            )
            imported.append({k: job[k] for k in ["job_code", "job_title", "job_status", "contact_name", "estimated_total"]})
        conn.commit()
    summary = {
        "imported": True,
        "count": len(imported),
        "jobs": imported,
        "source_file": str(src),
        "stored_copy": str(copied_to),
        "timestamp": ts,
    }
    out = JOBS_BRIDGE_DIR / "outbox" / f"job_import_summary_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    out.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    write_aegis_contract_files()
    return summary


def list_job_bridge_records() -> List[Dict[str, Any]]:
    init_environment()
    with db_connect() as conn:
        rows = conn.execute(
            "SELECT job_code, job_title, job_status, priority, contact_code, contact_name, contact_phone, contact_email, item_code, item_name, date_started, date_completed, due_date, job_location, estimated_total, labour, materials, issue, work_completed, completion_notes, handoff_notes, notes, source_file, imported_at, updated_at FROM job_bridge_cache ORDER BY updated_at DESC, job_title COLLATE NOCASE"
        ).fetchall()
    return [dict(r) for r in rows]


def job_record_count() -> int:
    try:
        with db_connect() as conn:
            row = conn.execute("SELECT COUNT(*) AS n FROM job_bridge_cache").fetchone()
        return int(row["n"] if row else 0)
    except Exception:
        return 0


def get_job_bridge_record(job_code: str) -> Optional[Dict[str, Any]]:
    init_environment()
    with db_connect() as conn:
        row = conn.execute("SELECT * FROM job_bridge_cache WHERE job_code=?", (job_code,)).fetchone()
    return dict(row) if row else None


def job_context(job_code: str) -> Dict[str, str]:
    row = get_job_bridge_record(job_code)
    if not row:
        raise KeyError(f"Job not found in Sentinel Documents jobs bridge cache: {job_code}")
    try:
        raw = json.loads(row.get("raw_json") or "{}")
    except Exception:
        raw = {}
    ctx = default_template_context()
    ctx.update(flatten_context_object(raw))
    ctx.update({
        "job_code": row.get("job_code") or "",
        "job_title": row.get("job_title") or "",
        "job_status": row.get("job_status") or "",
        "priority": row.get("priority") or "",
        "contact_code": row.get("contact_code") or "",
        "contact_name": row.get("contact_name") or "",
        "customer_name": row.get("contact_name") or "",
        "contact_phone": row.get("contact_phone") or "",
        "customer_contact": row.get("contact_phone") or row.get("contact_email") or "",
        "contact_email": row.get("contact_email") or "",
        "item_code": row.get("item_code") or "",
        "item_name": row.get("item_name") or "",
        "date_started": row.get("date_started") or "",
        "date_completed": row.get("date_completed") or "",
        "due_date": row.get("due_date") or "",
        "job_location": row.get("job_location") or "",
        "estimated_total": row.get("estimated_total") or "",
        "labour": row.get("labour") or "",
        "materials": row.get("materials") or "",
        "job_description": (row.get("job_description") or row.get("notes") or ""),
        "issue": row.get("issue") or "",
        "diagnosis": row.get("diagnosis") or "",
        "work_completed": row.get("work_completed") or "",
        "completion_notes": row.get("completion_notes") or "",
        "handoff_notes": row.get("handoff_notes") or "",
        "notes": row.get("notes") or ctx.get("notes", ""),
    })
    return {str(k): "" if v is None else str(v) for k, v in ctx.items()}


def create_job_document(job_code: str, template_name: str, title: Optional[str] = None) -> Dict[str, Any]:
    ctx = job_context(job_code)
    doc_title = title or f"{ctx.get('job_title') or job_code} - {Path(template_name).stem.replace('-', ' ').title()}"
    category = "Quotes" if "quote" in template_name else "Jobs"
    result = create_document_from_template(
        template_name,
        ctx,
        title=doc_title,
        category=category,
        doc_type="Job Document",
        linked_contact_code=ctx.get("contact_code") or None,
        linked_job_code=job_code,
        linked_inventory_code=ctx.get("item_code") or None,
    )
    export_job_document_bridge(result["document_id"])
    return result


def export_job_document_bridge(document_id: Optional[str] = None) -> Dict[str, Any]:
    init_environment()
    docs = []
    if document_id:
        doc = get_document(document_id)
        if not doc:
            raise KeyError(f"Document not found: {document_id}")
        if doc.get("linked_job_code"):
            docs = [doc]
    else:
        with db_connect() as conn:
            rows = conn.execute("SELECT * FROM documents WHERE linked_job_code IS NOT NULL AND linked_job_code!='' ORDER BY modified_at DESC").fetchall()
        docs = [dict(r) for r in rows]
    records = []
    for doc in docs:
        job = get_job_bridge_record(doc.get("linked_job_code") or "") or {}
        records.append({
            "document_id": doc.get("id"),
            "title": doc.get("title"),
            "category": doc.get("category"),
            "doc_type": doc.get("doc_type"),
            "file_path": doc.get("file_path"),
            "content_format": doc.get("content_format"),
            "sha256": doc.get("sha256"),
            "linked_job_code": doc.get("linked_job_code"),
            "job_title": job.get("job_title"),
            "job_status": job.get("job_status"),
            "contact_name": job.get("contact_name"),
            "estimated_total": job.get("estimated_total"),
            "status": doc.get("status"),
            "modified_at": doc.get("modified_at"),
        })
    payload = {
        "app": APP_NAME,
        "app_id": APP_ID,
        "program_id": PROGRAM_ID,
        "version": VERSION,
        "bridge": "jobs",
        "mode": "local_file_handoff",
        "silent_control": False,
        "document_count": len(records),
        "documents": records,
        "timestamp": now_iso(),
    }
    out = JOBS_BRIDGE_DIR / "outbox" / f"document_job_bridge_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    payload["export_path"] = str(out)
    write_aegis_contract_files()
    return payload


def paths_json() -> Dict[str, str]:
    return {
        "app_data": str(APP_DATA),
        "app_config": str(APP_CONFIG),
        "app_cache": str(APP_CACHE),
        "database": str(DB_PATH),
        "documents_root": str(DOCUMENTS_ROOT),
        "documents": str(DOCUMENTS_DIR),
        "aegis_vault_root": str(AEGIS_VAULT_ROOT),
        "aegis_vault_documents": str(AEGIS_VAULT_DOCUMENTS_DIR),
        "aegis_vault_detected": str(AEGIS_VAULT_ROOT.exists()),
        "exports": str(EXPORTS_DIR),
        "archive": str(ARCHIVE_DIR),
        "backups": str(BACKUP_DIR),
        "recovery": str(RECOVERY_DIR),
        "templates": str(TEMPLATES_DIR),
        "bridges": str(BRIDGES_DIR),
        "contacts_bridge": str(CONTACTS_BRIDGE_DIR),
        "inventory_bridge": str(INVENTORY_BRIDGE_DIR),
        "jobs_bridge": str(JOBS_BRIDGE_DIR),
        "aegis": str(AEGIS_DIR),
    }


def bridge_status() -> Dict[str, Any]:
    bridges = {}
    for name, path in {
        "contacts": CONTACTS_BRIDGE_DIR,
        "inventory": INVENTORY_BRIDGE_DIR,
        "jobs": JOBS_BRIDGE_DIR,
    }.items():
        bridges[name] = {
            "ready": path.exists() and (path / "inbox").exists() and (path / "outbox").exists(),
            "path": str(path),
            "mode": "local_file_handoff",
            "inbox": str(path / "inbox"),
            "outbox": str(path / "outbox"),
            "silent_control": False,
        }
    return bridges


def health_json() -> Dict[str, Any]:
    init_environment()
    docs = list_documents(include_archived=True)
    return {
        "app": APP_NAME,
        "app_id": APP_ID,
        "program_id": PROGRAM_ID,
        "version": VERSION,
        "schema_version": SCHEMA_VERSION,
        "phase": "v1.0.1 stable-lock consistency / guarded restore / v1 handoff patch",
        "status": "ready",
        "local_only": LOCAL_ONLY,
        "network_enabled": NETWORK_ENABLED,
        "telemetry_enabled": TELEMETRY_ENABLED,
        "database_exists": DB_PATH.exists(),
        "document_count_total": len(docs),
        "document_count_active": len([d for d in docs if d.get("status") == "active"]),
        "templates_count": len(list_templates()),
        "hotkeys_ready": True,
        "themed_inputs_ready": True,
        "gui_theme_options": ["aegis_dark", "sentinel_light_cyan"],
        "responsive_gui_ready": True,
        "manual_gui_scaling_ready": True,
        "non_white_editor_surface": True,
        "contacts_bridge_import_ready": True,
        "contact_records_cached": contact_record_count(),
        "contact_document_generation_ready": True,
        "inventory_bridge_import_ready": True,
        "inventory_records_cached": inventory_record_count(),
        "inventory_document_generation_ready": True,
        "jobs_bridge_import_ready": True,
        "job_records_cached": job_record_count(),
        "job_document_generation_ready": True,
        "save_options_popup_ready": True,
        "save_formats_ready": ["markdown", "text", "html", "pdf", "odt", "docx"],
        "export_layer_ready": True,
        "document_search_ready": True,
        "document_filter_ready": True,
        "document_categories_ready": True,
        "recent_documents_ready": True,
        "archive_restore_ready": True,
        "font_options_ready": True,
        "expanded_font_family_discovery_ready": True,
        "scrollable_font_picker_ready": True,
        "home_font_button_ready": True,
        "maximized_default_window_ready": True,
        "visual_bold_italic_ready": True,
        "backup_restore_ready": True,
        "backup_dir_ready": BACKUP_DIR.exists(),
        "verify_db_ready": True,
        "repair_db_ready": True,
        "library_export_import_ready": True,
        "launcher_repair_ready": True,
        "recovery_report_ready": True,
        "release_candidate_audit_ready": True,
        "stable_lock_report_ready": True,
        "stable_locked": True,
        "stable_lock_consistency_patch_ready": True,
        "guarded_restore_ready": True,
        "audit_report_ready": True,
        "audit_export_ready": True,
        "v1_handoff_bundle_ready": True,
        "stable_lock_wrapper_ready": True,
        "v1_handoff_wrapper_ready": True,
        "v1_candidate_wording_removed": True,
        "final_audit_json_ready": True,
        "v1_readiness_report_ready": True,
        "gui_audit_tab_ready": True,
        "paragraph_formatting_ready": True,
        "right_click_format_menu_ready": True,
        "highlighted_text_context_formatting_ready": True,
        "document_formatting_foundation_ready": True,
        "format_options": format_options_json(),
        "vault_metadata_export_ready": True,
        "aegis_capabilities_json_ready": True,
        "safe_read_document_ready": True,
        "library_summary": document_library_summary(),
        "export_formats_ready": list(SAVE_FORMATS.keys()),
        "odt_text_export_ready": True,
        "docx_text_export_ready": True,
        "libreoffice_handoff_ready": True,
        "libreoffice_installed": bool(libreoffice_binary()),
        "pdf_open_edit_foundation_ready": True,
        "side_library_removed": True,
        "search_manager_popup_ready": True,
        "default_window_widened": True,
        "word_selection_hotkeys_ready": True,
        "paths": paths_json(),
        "bridges": bridge_status(),
        "aegis_ready": True,
        "sentinel_command_ready": True,
        "timestamp": now_iso(),
    }


def aegis_status_json() -> Dict[str, Any]:
    h = health_json()
    return {
        "program": APP_NAME,
        "program_id": PROGRAM_ID,
        "app_id": APP_ID,
        "version": VERSION,
        "ready": True,
        "state": "v1_stable_locked",
        "local_only": True,
        "network_enabled": False,
        "telemetry_enabled": False,
        "can_create_documents": True,
        "can_create_from_templates": True,
        "can_merge_templates": True,
        "can_use_gui_hotkeys": True,
        "can_switch_gui_theme": True,
        "can_scale_gui_to_window": True,
        "can_manual_scale_editor": True,
        "can_manual_scale_side_menu": True,
        "can_use_ctrl_shift_arrow_selection": True,
        "can_import_contact_bridge_json": True,
        "can_create_contact_documents": True,
        "can_export_contact_document_bridge": True,
        "can_import_inventory_bridge_json": True,
        "can_create_inventory_documents": True,
        "can_export_inventory_document_bridge": True,
        "can_import_job_bridge_json": True,
        "can_create_job_documents": True,
        "can_export_job_document_bridge": True,
        "can_prompt_save_name_location_format": True,
        "can_save_markdown_text_html_pdf_odt_docx": True,
        "can_export_document_formats": True,
        "can_search_documents": True,
        "can_filter_documents": True,
        "can_list_document_categories": True,
        "can_list_recent_documents": True,
        "can_restore_archived_documents": True,
        "can_use_font_options": True,
        "can_use_expanded_font_family_discovery": True,
        "can_open_scrollable_font_picker": True,
        "can_use_home_font_button": True,
        "can_start_maximized_by_default": True,
        "can_use_visual_bold_italic": True,
        "can_apply_paragraph_formatting": True,
        "can_use_right_click_format_menu": True,
        "can_use_font_picker_without_theme_key_failure": True,
        "can_format_highlighted_text_from_context_menu": True,
        "can_export_vault_metadata": True,
        "can_report_aegis_capabilities": True,
        "can_safe_read_document_text": True,
        "can_create_backups": True,
        "can_restore_backups": True,
        "can_restore_backups_guarded": True,
        "can_export_audit_reports": True,
        "can_export_v1_handoff_bundle": True,
        "can_verify_database": True,
        "can_repair_database": True,
        "can_export_import_library": True,
        "can_repair_launcher": True,
        "can_report_recovery_status": True,
        "can_run_release_candidate_audit": True,
        "can_write_release_candidate_report": True,
        "can_write_stable_lock_report": True,
        "stable_locked": True,
        "can_use_font_options": True,
        "can_use_expanded_font_family_discovery": True,
        "can_apply_paragraph_formatting": True,
        "can_use_right_click_format_menu": True,
        "can_use_font_picker_without_theme_key_failure": True,
        "can_format_highlighted_text_from_context_menu": True,
        "can_export_vault_metadata": True,
        "can_report_aegis_capabilities": True,
        "can_safe_read_document_text": True,
        "can_export_odt_text": True,
        "can_export_docx_text": True,
        "can_handoff_to_libreoffice": bool(libreoffice_binary()),
        "can_open_pdf_text_layer_for_editing": True,
        "can_index_documents": True,
        "can_safe_read_metadata": True,
        "can_bridge_contacts": True,
        "can_bridge_inventory": True,
        "can_bridge_jobs": True,
        "can_control_other_apps_silently": False,
        "can_run_release_candidate_audit": True,
        "can_write_release_candidate_report": True,
        "can_write_stable_lock_report": True,
        "stable_locked": True,
        "paths": h["paths"],
        "bridges": h["bridges"],
        "timestamp": h["timestamp"],
    }


def aegis_actions_json() -> Dict[str, Any]:
    return {
        "program": APP_NAME,
        "program_id": PROGRAM_ID,
        "app_id": APP_ID,
        "version": VERSION,
        "actions": [
            {
                "name": "status",
                "cli": "sentinel-documents --status",
                "mode": "read_only",
                "description": "Return human-readable app readiness status.",
            },
            {
                "name": "health_json",
                "cli": "sentinel-documents --health-json",
                "mode": "read_only",
                "description": "Return machine-readable health and path information.",
            },
            {
                "name": "aegis_status_json",
                "cli": "sentinel-documents --aegis-status-json",
                "mode": "read_only",
                "description": "Return AEGIS-compatible readiness and bridge state.",
            },
            {
                "name": "aegis_actions_json",
                "cli": "sentinel-documents --aegis-actions-json",
                "mode": "read_only",
                "description": "Return the supported AEGIS action contract.",
            },
            {
                "name": "list_documents",
                "cli": "sentinel-documents --list-documents-json",
                "mode": "read_only_metadata",
                "description": "List indexed document metadata without exposing full document text.",
            },
            {
                "name": "safe_read_metadata",
                "cli": "sentinel-documents --safe-read-metadata DOCUMENT_ID",
                "mode": "read_only_metadata",
                "description": "Read metadata for a specific document id.",
            },
            {
                "name": "list_templates",
                "cli": "sentinel-documents --list-templates",
                "mode": "read_only",
                "description": "List available Sentinel document templates.",
            },
            {
                "name": "export_templates_json",
                "cli": "sentinel-documents --export-templates-json",
                "mode": "read_only",
                "description": "Return template metadata, placeholders, and hashes as JSON.",
            },
            {
                "name": "template_info",
                "cli": "sentinel-documents --template-info TEMPLATE_NAME",
                "mode": "read_only",
                "description": "Return placeholder and hash information for one template.",
            },
            {
                "name": "create_from_template",
                "cli": "sentinel-documents --create-from-template TEMPLATE_NAME --template-set key=value",
                "mode": "write_local_document",
                "description": "Create a local Sentinel document from a template using explicit local context only.",
            },
            {
                "name": "import_contact_bridge",
                "cli": "sentinel-documents --import-contact-bridge FILE.json",
                "mode": "local_bridge_import",
                "description": "Import Sentinel Contacts quick-fill/contact JSON into the local contact bridge cache.",
            },
            {
                "name": "list_contact_bridges_json",
                "cli": "sentinel-documents --list-contact-bridges-json",
                "mode": "read_only_metadata",
                "description": "List contacts cached from the Sentinel Contacts bridge without controlling Contacts.",
            },
            {
                "name": "create_contact_document",
                "cli": "sentinel-documents --create-contact-document CONTACT_CODE TEMPLATE_NAME",
                "mode": "write_local_document",
                "description": "Create a local document from a template using a cached contact bridge record.",
            },
            {
                "name": "export_contact_document_bridge",
                "cli": "sentinel-documents --export-contact-document-bridge [DOCUMENT_ID]",
                "mode": "local_bridge_export",
                "description": "Export linked document/contact metadata for Sentinel Contacts local handoff.",
            },
            {
                "name": "import_inventory_bridge",
                "cli": "sentinel-documents --import-inventory-bridge FILE.json",
                "mode": "local_bridge_import",
                "description": "Import Sentinel Inventory item/asset JSON into the local inventory bridge cache.",
            },
            {
                "name": "list_inventory_bridges_json",
                "cli": "sentinel-documents --list-inventory-bridges-json",
                "mode": "read_only_metadata",
                "description": "List inventory items cached from the Sentinel Inventory bridge without controlling Inventory.",
            },
            {
                "name": "create_inventory_document",
                "cli": "sentinel-documents --create-inventory-document ITEM_CODE TEMPLATE_NAME",
                "mode": "write_local_document",
                "description": "Create a local inventory document from a template using a cached inventory bridge record.",
            },
            {
                "name": "export_inventory_document_bridge",
                "cli": "sentinel-documents --export-inventory-document-bridge [DOCUMENT_ID]",
                "mode": "local_bridge_export",
                "description": "Export linked document/inventory metadata for Sentinel Inventory local handoff.",
            },
            {
                "name": "import_job_bridge",
                "cli": "sentinel-documents --import-job-bridge FILE.json",
                "mode": "local_bridge_import",
                "description": "Import Sentinel Jobs job/work-order JSON into the local jobs bridge cache.",
            },
            {
                "name": "list_job_bridges_json",
                "cli": "sentinel-documents --list-job-bridges-json",
                "mode": "read_only_metadata",
                "description": "List jobs cached from the Sentinel Jobs bridge without controlling Jobs.",
            },
            {
                "name": "create_job_document",
                "cli": "sentinel-documents --create-job-document JOB_CODE TEMPLATE_NAME",
                "mode": "write_local_document",
                "description": "Create a local job document from a template using a cached jobs bridge record.",
            },
            {
                "name": "export_job_document_bridge",
                "cli": "sentinel-documents --export-job-document-bridge [DOCUMENT_ID]",
                "mode": "local_bridge_export",
                "description": "Export linked document/job metadata for Sentinel Jobs local handoff.",
            },
            {
                "name": "search_documents",
                "cli": "sentinel-documents --search-documents QUERY [--search-category CATEGORY] [--search-status active|archived|all]",
                "mode": "read_only_metadata",
                "description": "Search indexed document metadata with optional local content scan; returns metadata only.",
            },
            {
                "name": "list_categories",
                "cli": "sentinel-documents --list-categories-json",
                "mode": "read_only_metadata",
                "description": "List document categories and active/archived counts.",
            },
            {
                "name": "list_recent_documents",
                "cli": "sentinel-documents --list-recent-documents-json 12",
                "mode": "read_only_metadata",
                "description": "List recently modified active documents without exposing full text.",
            },
            {
                "name": "restore_document",
                "cli": "sentinel-documents --restore DOCUMENT_ID",
                "mode": "write_local_metadata",
                "description": "Restore an archived document to active status.",
            },
            {
                "name": "aegis_capabilities_json",
                "cli": "sentinel-documents --aegis-capabilities-json",
                "mode": "read_only",
                "description": "Return the expanded AEGIS/Sentinel Command capability contract.",
            },
            {
                "name": "vault_metadata_json",
                "cli": "sentinel-documents --vault-metadata-json",
                "mode": "read_only_metadata",
                "description": "Return Vault-ready document metadata without exposing full document text.",
            },
            {
                "name": "export_vault_metadata",
                "cli": "sentinel-documents --export-vault-metadata [PATH]",
                "mode": "write_local_metadata",
                "description": "Export Sentinel Documents metadata for AEGIS Vault indexing and handoff.",
            },
            {
                "name": "safe_read_document",
                "cli": "sentinel-documents --safe-read DOCUMENT_ID [--safe-read-limit N]",
                "mode": "read_local_document",
                "description": "Safely read a local document text layer by id with a configurable limit.",
            },
            {
                "name": "format_options_json",
                "cli": "sentinel-documents --format-options-json",
                "mode": "read_only",
                "description": "Return available GUI font and paragraph formatting options.",
            },
            {
                "name": "backup",
                "cli": "sentinel-documents --backup [OUTPUT.zip]",
                "mode": "write_local_backup",
                "description": "Create a local ZIP backup of Sentinel Documents data, config, documents, bridges, and metadata.",
            },
            {
                "name": "restore_backup",
                "cli": "sentinel-documents --restore-backup BACKUP.zip",
                "mode": "write_local_restore",
                "description": "Restore a Sentinel Documents backup after creating a local safety snapshot.",
            },
            {
                "name": "verify_db",
                "cli": "sentinel-documents --verify-db",
                "mode": "read_only_diagnostics",
                "description": "Run SQLite integrity, missing-file, and SHA256 verification checks.",
            },
            {
                "name": "repair_db",
                "cli": "sentinel-documents --repair-db",
                "mode": "write_local_repair",
                "description": "Repair/reconcile the local document index, hashes, and unindexed document files.",
            },
            {
                "name": "export_library",
                "cli": "sentinel-documents --export-library [OUTPUT.zip]",
                "mode": "write_local_export",
                "description": "Export the local document library and metadata to a portable ZIP.",
            },
            {
                "name": "import_library",
                "cli": "sentinel-documents --import-library LIBRARY.zip",
                "mode": "write_local_import",
                "description": "Import a Sentinel Documents library ZIP using the safe restore/repair pathway.",
            },
            {
                "name": "repair_launcher",
                "cli": "sentinel-documents --repair-launcher",
                "mode": "write_local_launcher",
                "description": "Repair the user-local MATE/Desktop launcher entry.",
            },
            {
                "name": "recovery_report_json",
                "cli": "sentinel-documents --recovery-report-json",
                "mode": "read_only_diagnostics",
                "description": "Return backup/recovery status, recent backups, and latest verification output.",
            },
            {
                "name": "rc_audit_json",
                "cli": "sentinel-documents --rc-audit-json",
                "mode": "read_only_diagnostics",
                "description": "Run the v1 stable-lock readiness audit and return JSON.",
            },
            {
                "name": "release_candidate_report",
                "cli": "sentinel-documents --v1 audit-report [OUTPUT.md]",
                "mode": "write_local_report",
                "description": "Write a local Markdown v1 audit report.",
            },
            {
                "name": "stable_lock_report",
                "cli": "sentinel-documents --stable-lock-report [OUTPUT.md]",
                "mode": "write_local_report",
                "description": "Write a local Markdown v1.0.1 stable-lock report.",
            },
            {
                "name": "print_paths",
                "cli": "sentinel-documents --print-paths",
                "mode": "read_only",
                "description": "Print local storage and bridge paths.",
            },
        ],
        "bridge_contracts": {
            "contacts": {
                "path": str(CONTACTS_BRIDGE_DIR),
                "inbox_accepts": ["contact_quickfill_json", "contact_document_request_json", "sentinel_contacts_export_json"],
                "outbox_exports": ["document_contact_link_json", "created_document_metadata_json", "contact_import_summary_json"],
                "silent_control": False,
            },
            "inventory": {
                "path": str(INVENTORY_BRIDGE_DIR),
                "inbox_accepts": ["inventory_item_bridge_json", "inventory_document_request_json"],
                "outbox_exports": ["document_inventory_link_json", "created_document_metadata_json", "inventory_import_summary_json"],
                "silent_control": False,
            },
            "jobs": {
                "path": str(JOBS_BRIDGE_DIR),
                "inbox_accepts": ["job_bridge_json", "job_document_request_json"],
                "outbox_exports": ["document_job_link_json", "created_document_metadata_json", "job_import_summary_json"],
                "silent_control": False,
            },
        },
        "local_only": True,
        "network_enabled": False,
        "telemetry_enabled": False,
        "timestamp": now_iso(),
    }


def write_aegis_contract_files() -> None:
    ensure_dirs()
    (AEGIS_DIR / "status.json").write_text(json.dumps(aegis_status_json_no_write(), indent=2), encoding="utf-8")
    (AEGIS_DIR / "actions.json").write_text(json.dumps(aegis_actions_json_no_write(), indent=2), encoding="utf-8")


def aegis_status_json_no_write() -> Dict[str, Any]:
    return {
        "program": APP_NAME,
        "program_id": PROGRAM_ID,
        "app_id": APP_ID,
        "version": VERSION,
        "ready": True,
        "state": "v1_stable_locked",
        "local_only": True,
        "network_enabled": False,
        "telemetry_enabled": False,
        "can_create_documents": True,
        "can_create_from_templates": True,
        "can_merge_templates": True,
        "can_use_gui_hotkeys": True,
        "can_switch_gui_theme": True,
        "can_scale_gui_to_window": True,
        "can_manual_scale_editor": True,
        "can_manual_scale_side_menu": True,
        "can_use_ctrl_shift_arrow_selection": True,
        "can_import_contact_bridge_json": True,
        "can_create_contact_documents": True,
        "can_export_contact_document_bridge": True,
        "can_import_inventory_bridge_json": True,
        "can_create_inventory_documents": True,
        "can_export_inventory_document_bridge": True,
        "can_import_job_bridge_json": True,
        "can_create_job_documents": True,
        "can_export_job_document_bridge": True,
        "can_prompt_save_name_location_format": True,
        "can_save_markdown_text_html_pdf_odt_docx": True,
        "can_export_document_formats": True,
        "can_search_documents": True,
        "can_filter_documents": True,
        "can_list_document_categories": True,
        "can_list_recent_documents": True,
        "can_restore_archived_documents": True,
        "can_use_font_options": True,
        "can_use_expanded_font_family_discovery": True,
        "can_apply_paragraph_formatting": True,
        "can_use_right_click_format_menu": True,
        "can_use_font_picker_without_theme_key_failure": True,
        "can_format_highlighted_text_from_context_menu": True,
        "can_export_vault_metadata": True,
        "can_report_aegis_capabilities": True,
        "can_safe_read_document_text": True,
        "can_use_font_options": True,
        "can_use_expanded_font_family_discovery": True,
        "can_apply_paragraph_formatting": True,
        "can_use_right_click_format_menu": True,
        "can_use_font_picker_without_theme_key_failure": True,
        "can_format_highlighted_text_from_context_menu": True,
        "can_export_vault_metadata": True,
        "can_report_aegis_capabilities": True,
        "can_safe_read_document_text": True,
        "can_export_odt_text": True,
        "can_export_docx_text": True,
        "can_handoff_to_libreoffice": bool(libreoffice_binary()),
        "can_open_pdf_text_layer_for_editing": True,
        "can_index_documents": True,
        "can_safe_read_metadata": True,
        "can_bridge_contacts": True,
        "can_bridge_inventory": True,
        "can_bridge_jobs": True,
        "can_control_other_apps_silently": False,
        "paths": paths_json(),
        "bridges": bridge_status(),
        "timestamp": now_iso(),
    }


def aegis_actions_json_no_write() -> Dict[str, Any]:
    # Deliberately no recursive write.
    return {
        "program": APP_NAME,
        "program_id": PROGRAM_ID,
        "app_id": APP_ID,
        "version": VERSION,
        "actions": [
            "status",
            "health_json",
            "aegis_status_json",
            "aegis_actions_json",
            "list_documents",
            "safe_read_metadata",
            "list_templates",
            "export_templates_json",
            "template_info",
            "create_from_template",
            "import_contact_bridge",
            "list_contact_bridges_json",
            "create_contact_document",
            "export_contact_document_bridge",
            "import_inventory_bridge",
            "list_inventory_bridges_json",
            "create_inventory_document",
            "export_inventory_document_bridge",
            "import_job_bridge",
            "list_job_bridges_json",
            "create_job_document",
            "export_job_document_bridge",
            "export_document",
            "export_formats_json",
            "libreoffice_status_json",
            "open_in_libreoffice",
            "search_documents",
            "list_categories",
            "list_recent_documents",
            "restore_document",
            "aegis_capabilities_json",
            "vault_metadata_json",
            "export_vault_metadata",
            "safe_read_document",
            "format_options_json",
            "backup",
            "restore_backup",
            "verify_db",
            "repair_db",
            "export_library",
            "import_library",
            "repair_launcher",
            "recovery_report_json",
            "rc_audit_json",
            "release_candidate_report",
            "stable_lock_report",
            "audit_report_json",
            "export_audit_json",
            "export_audit_csv",
            "export_v1_bundle",
            "guarded_restore_backup",
            "print_paths",
        ],
        "bridge_contracts": {
            "contacts": str(CONTACTS_BRIDGE_DIR),
            "inventory": str(INVENTORY_BRIDGE_DIR),
            "jobs": str(JOBS_BRIDGE_DIR),
        },
        "local_only": True,
        "network_enabled": False,
        "telemetry_enabled": False,
        "timestamp": now_iso(),
    }


# ------------------------ V1 Audit ------------------------

def rc_audit_json() -> Dict[str, Any]:
    """Return a local-only v1 audit summary for v1 readiness."""
    init_environment()
    h = health_json()
    verification = verify_database()
    actions = aegis_actions_json_no_write()
    format_options = format_options_json()
    recovery = recovery_report_json()
    required_flags = {
        "local_only": h.get("local_only") is True,
        "network_disabled": h.get("network_enabled") is False,
        "telemetry_disabled": h.get("telemetry_enabled") is False,
        "database_exists": h.get("database_exists") is True,
        "templates_present": int(h.get("templates_count") or 0) >= 10,
        "contacts_bridge_ready": h.get("contacts_bridge_import_ready") is True,
        "inventory_bridge_ready": h.get("inventory_bridge_import_ready") is True,
        "jobs_bridge_ready": h.get("jobs_bridge_import_ready") is True,
        "export_layer_ready": h.get("export_layer_ready") is True,
        "search_ready": h.get("document_search_ready") is True,
        "formatting_ready": h.get("document_formatting_foundation_ready") is True,
        "right_click_formatting_ready": h.get("right_click_format_menu_ready") is True,
        "font_discovery_ready": h.get("expanded_font_family_discovery_ready") is True,
        "scrollable_font_picker_ready": h.get("scrollable_font_picker_ready") is True,
        "aegis_capabilities_ready": h.get("aegis_capabilities_json_ready") is True,
        "vault_metadata_ready": h.get("vault_metadata_export_ready") is True,
        "safe_read_ready": h.get("safe_read_document_ready") is True,
        "backup_restore_ready": h.get("backup_restore_ready") is True,
        "verify_db_ready": h.get("verify_db_ready") is True,
        "repair_db_ready": h.get("repair_db_ready") is True,
        "recovery_report_ready": h.get("recovery_report_ready") is True,
        "launcher_repair_ready": h.get("launcher_repair_ready") is True,
        "aegis_actions_present": len(actions.get("actions", [])) >= 30,
        "font_options_usable": int(format_options.get("font_family_count") or len(format_options.get("font_families", [])) or 0) > 0,
        "font_size_max_50": int(format_options.get("font_size_max") or format_options.get("font_size_range", {}).get("max") or 0) >= 50,
    }
    verification_ok = bool(verification.get("ok") or verification.get("sqlite_integrity_ok"))
    missing_raw = verification.get("missing_file_count", verification.get("missing_files", 0))
    mismatch_raw = verification.get("sha256_mismatch_count", verification.get("sha256_mismatches", verification.get("hash_mismatches", 0)))
    missing_files = len(missing_raw) if isinstance(missing_raw, (list, tuple, set)) else int(missing_raw or 0)
    hash_mismatches = len(mismatch_raw) if isinstance(mismatch_raw, (list, tuple, set)) else int(mismatch_raw or 0)
    failed = [name for name, ok in required_flags.items() if not ok]
    warnings = []
    if not verification_ok:
        warnings.append("SQLite/file verification reported an issue; run --verify-db and --repair-db before v1 lock.")
    if missing_files:
        warnings.append(f"{missing_files} indexed document file(s) are missing.")
    if hash_mismatches:
        warnings.append(f"{hash_mismatches} indexed document hash mismatch(es) found.")
    if not h.get("libreoffice_installed"):
        warnings.append("LibreOffice is not installed on this host; handoff remains optional and will work when installed.")
    status = "pass" if not failed and verification_ok and missing_files == 0 and hash_mismatches == 0 else ("warning" if not failed else "fail")
    return {
        "app": APP_NAME,
        "app_id": APP_ID,
        "program_id": PROGRAM_ID,
        "version": VERSION,
        "audit_kind": "release_candidate_v1_readiness",
        "status": status,
        "ready_for_v1_lock": status in ("pass", "warning") and not failed,
        "failed_required_flags": failed,
        "warnings": warnings,
        "required_flags": required_flags,
        "verification_summary": {
            "sqlite_integrity_ok": verification.get("sqlite_integrity_ok", verification.get("ok")),
            "missing_file_count": missing_files,
            "sha256_mismatch_count": hash_mismatches,
            "checked_documents": verification.get("checked_documents", verification.get("document_count")),
        },
        "capability_summary": {
            "actions_count": len(actions.get("actions", [])),
            "templates_count": h.get("templates_count"),
            "export_formats": h.get("export_formats_ready"),
            "font_family_count": format_options.get("font_family_count", len(format_options.get("font_families", []))),
            "bridges": h.get("bridges"),
            "recovery": recovery,
        },
        "local_only": True,
        "network_enabled": False,
        "telemetry_enabled": False,
        "timestamp": now_iso(),
    }


def release_candidate_report(output_path: Optional[str] = None) -> Dict[str, Any]:
    """Write a Markdown v1 audit report and return metadata."""
    init_environment()
    audit = rc_audit_json()
    h = health_json()
    dest = Path(output_path).expanduser() if output_path else RECOVERY_DIR / f"sentinel_documents_v{VERSION.replace('.', '_')}_rc_audit_report.md"
    dest.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        f"# Sentinel Documents v{VERSION} V1 Audit",
        "",
        f"Program: {PROGRAM_ID}",
        f"Status: {audit['status']}",
        f"Ready for v1 lock: {audit['ready_for_v1_lock']}",
        f"Generated: {audit['timestamp']}",
        "",
        "## Local doctrine",
        "",
        f"- Local-only: {h.get('local_only')}",
        f"- Network enabled: {h.get('network_enabled')}",
        f"- Telemetry enabled: {h.get('telemetry_enabled')}",
        "",
        "## Completed capability areas",
        "",
        "- Office-familiar Sentinel GUI foundation",
        "- Sentinel Jobs-style AEGIS Dark theme and Sentinel Light Cyan theme",
        "- Template engine",
        "- Contacts, Inventory, and Jobs bridges",
        "- Save popup with name, location, and format",
        "- Export to MD, TXT, HTML, PDF text-layer, ODT text foundation, DOCX text foundation",
        "- PDF text-layer open/edit foundation",
        "- LibreOffice explicit handoff",
        "- Document search, filters, categories, recent documents, archive/restore",
        "- AEGIS capabilities/actions/status and Vault metadata export",
        "- Font/paragraph formatting controls, expanded font discovery, scrollable font picker, working visual bold/italic controls, right-click formatting hot menu",
        "- Backup, restore, verify, repair, launcher repair, recovery report",
        "",
        "## Required flag audit",
        "",
    ]
    for name, ok in audit["required_flags"].items():
        lines.append(f"- [{'PASS' if ok else 'FAIL'}] {name}")
    lines += ["", "## Warnings", ""]
    if audit["warnings"]:
        lines += [f"- {w}" for w in audit["warnings"]]
    else:
        lines.append("- None")
    lines += ["", "## v1 lock recommendation", ""]
    if audit["ready_for_v1_lock"]:
        lines.append("Sentinel Documents is v1 stable locked and ready for deployment after final user approval.")
    else:
        lines.append("Sentinel Documents should not be deployed as v1 until failed required flags are corrected.")
    lines += ["", "## Raw audit JSON", "", "```json", json.dumps(audit, indent=2), "```", ""]
    dest.write_text("\n".join(lines), encoding="utf-8")
    return {"written": True, "path": str(dest), "sha256": sha256_file(dest), "audit_status": audit["status"], "ready_for_v1_lock": audit["ready_for_v1_lock"], "timestamp": now_iso()}


def stable_lock_report(output_path: Optional[str] = None) -> Dict[str, Any]:
    """Write a Markdown v1.0.1 stable-lock report and return metadata."""
    init_environment()
    audit = rc_audit_json()
    h = health_json()
    dest = Path(output_path).expanduser() if output_path else RECOVERY_DIR / "sentinel_documents_v1_0_1_stable_lock_report.md"
    dest.parent.mkdir(parents=True, exist_ok=True)
    accepted_limitations = [
        "PDF editing is a text-layer foundation only; complex PDF layout/forms/images/annotations are post-v1 work.",
        "ODT/DOCX export is a generated text-document foundation; advanced layouts/tracked changes are post-v1 work.",
        "Formatting persistence uses visual editor tags plus Markdown/helper/sidecar foundations; full per-character rich-text persistence is post-v1 work.",
    ]
    lines = [
        "# Sentinel Documents v1.0.1 Stable Lock Report",
        "",
        f"Program: {PROGRAM_ID}",
        f"Application: {APP_NAME}",
        f"Version: {VERSION}",
        "Stable locked: true",
        f"Generated: {now_iso()}",
        "",
        "## Doctrine",
        "",
        f"- Local-only: {h.get('local_only')}",
        f"- Network enabled: {h.get('network_enabled')}",
        f"- Telemetry enabled: {h.get('telemetry_enabled')}",
        "- No cloud dependency",
        "- No silent control of Contacts, Inventory, Jobs, LibreOffice, or AEGIS",
        "",
        "## Locked v1 baseline capabilities",
        "",
        "- Office-familiar Sentinel-branded GUI with top ribbon/tabs and maximized default window",
        "- AEGIS Dark and Sentinel Light Cyan themes with non-white editor surface",
        "- Template engine and seeded document templates",
        "- Contacts, Inventory, and Jobs local bridge import/cache/document generation/export",
        "- Save popup with file name, location, and format selection",
        "- Export to Markdown, text, HTML, PDF text-layer, ODT text foundation, and DOCX text foundation",
        "- PDF text-layer open/edit foundation",
        "- Explicit LibreOffice handoff when LibreOffice/soffice is installed",
        "- Search, filters, categories, recent documents, archive and restore",
        "- Font and paragraph formatting controls, expanded local font discovery, scrollable font picker, Home Font button, and right-click formatting menu",
        "- Visual bold/italic/underline/strikethrough/highlight editor tags for selected text",
        "- AEGIS status/actions/capabilities JSON and Vault metadata export",
        "- Safe-read metadata and safe-read document text layer by explicit document id",
        "- Backup, restore, verify, repair, launcher repair, recovery report, library import/export",
        "",
        "## Stable-lock audit",
        "",
        f"- Stable-lock audit status: {audit.get('status')}",
        f"- Ready for v1 lock: {audit.get('ready_for_v1_lock')}",
        f"- Failed required flags: {len(audit.get('failed_required_flags', []))}",
        "",
        "## Accepted v1 baseline limitations",
        "",
    ]
    lines.extend([f"- {item}" for item in accepted_limitations])
    lines += [
        "",
        "## Stable-lock verdict",
        "",
    ]
    if audit.get("ready_for_v1_lock") and not audit.get("failed_required_flags"):
        lines.append("Sentinel Documents v1.0.1 is stable locked as the official Program 116 baseline with guarded restore and v1 handoff exports.")
    else:
        lines.append("Stable lock was requested, but audit warnings/flags should be reviewed before deployment.")
    lines += ["", "## Raw audit JSON", "", "```json", json.dumps(audit, indent=2), "```", ""]
    dest.write_text("\n".join(lines), encoding="utf-8")
    return {
        "written": True,
        "path": str(dest),
        "sha256": sha256_file(dest),
        "version": VERSION,
        "stable_locked": True,
        "audit_status": audit.get("status"),
        "ready_for_v1_lock": audit.get("ready_for_v1_lock"),
        "accepted_limitations": accepted_limitations,
        "timestamp": now_iso(),
    }


def audit_report_json() -> Dict[str, Any]:
    """Return the stable-lock audit JSON under the current v1 suite naming."""
    audit = rc_audit_json()
    audit["audit_kind"] = "v1_stable_lock_audit"
    audit["stable_locked"] = True
    audit["stable_lock_consistency_patch"] = True
    audit["guarded_restore_ready"] = True
    audit["audit_export_ready"] = True
    audit["v1_handoff_bundle_ready"] = True
    audit["candidate_wording_removed"] = True
    return audit


def export_audit_json(output_path: Optional[str] = None) -> Dict[str, Any]:
    init_environment()
    audit = audit_report_json()
    dest = Path(output_path).expanduser() if output_path else RECOVERY_DIR / f"sentinel_documents_v{VERSION.replace('.', '_')}_audit_report.json"
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(json.dumps(audit, indent=2), encoding="utf-8")
    return {"written": True, "path": str(dest), "sha256": sha256_file(dest), "audit_status": audit.get("status"), "timestamp": now_iso()}


def export_audit_csv(output_path: Optional[str] = None) -> Dict[str, Any]:
    init_environment()
    audit = audit_report_json()
    dest = Path(output_path).expanduser() if output_path else RECOVERY_DIR / f"sentinel_documents_v{VERSION.replace('.', '_')}_audit_report.csv"
    dest.parent.mkdir(parents=True, exist_ok=True)
    rows = ["flag,status"]
    for name, ok in sorted((audit.get("required_flags") or {}).items()):
        rows.append(f"{name},{'PASS' if ok else 'FAIL'}")
    rows.append(f"audit_status,{audit.get('status')}")
    rows.append(f"ready_for_v1_lock,{audit.get('ready_for_v1_lock')}")
    dest.write_text("\n".join(rows) + "\n", encoding="utf-8")
    return {"written": True, "path": str(dest), "sha256": sha256_file(dest), "flag_count": len(audit.get("required_flags") or {}), "timestamp": now_iso()}


def export_v1_bundle(output_path: Optional[str] = None) -> Dict[str, Any]:
    """Export the v1 handoff bundle with audit, stable-lock, backup, and manifest artifacts."""
    init_environment()
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    target = Path(output_path).expanduser() if output_path else EXPORTS_DIR / f"sentinel_documents_v1_handoff_{stamp}.zip"
    if target.suffix.lower() != ".zip":
        target = target.with_suffix(".zip")
    target.parent.mkdir(parents=True, exist_ok=True)
    stable = stable_lock_report()
    audit_json = export_audit_json()
    audit_csv = export_audit_csv()
    backup = create_backup(str(BACKUP_DIR / f"sentinel_documents_v1_handoff_backup_{stamp}.zip"), kind="v1_handoff_backup")
    manifest = {
        "program": APP_NAME,
        "program_id": PROGRAM_ID,
        "app_id": APP_ID,
        "version": VERSION,
        "bundle_kind": "v1_handoff_bundle",
        "stable_locked": True,
        "local_only": True,
        "network_enabled": False,
        "telemetry_enabled": False,
        "created_at": now_iso(),
        "stable_lock_report": stable,
        "audit_json": audit_json,
        "audit_csv": audit_csv,
        "verified_backup": backup,
        "health": health_json(),
    }
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("sentinel_documents_v1_handoff_manifest.json", json.dumps(manifest, indent=2))
        for key, meta in [("stable_lock_report.md", stable), ("audit_report.json", audit_json), ("audit_report.csv", audit_csv), ("verified_backup.zip", backup)]:
            path = Path(meta.get("path") or meta.get("backup_file") or "")
            if path.exists():
                zf.write(path, key)
    return {"written": True, "path": str(target), "sha256": sha256_file(target), "manifest": manifest, "timestamp": now_iso()}


def print_json(obj: Any) -> None:
    print(json.dumps(obj, indent=2, sort_keys=False))


def print_status() -> None:
    h = health_json()
    print(f"{APP_NAME} v{VERSION} — Program {PROGRAM_ID}")
    print("State: v1.0.1 stable locked baseline")
    print("Local-only: yes")
    print("Network/telemetry: disabled")
    print(f"Documents: {h['document_count_active']} active / {h['document_count_total']} total")
    print(f"Templates: {h['templates_count']}")
    print(f"Database: {DB_PATH}")
    print(f"Document root: {DOCUMENTS_ROOT}")
    print("AEGIS-ready: yes")
    print("Bridge readiness:")
    for name, info in h["bridges"].items():
        print(f"  - {name}: {'ready' if info['ready'] else 'not ready'} ({info['path']})")


def safe_read_metadata(doc_id: str) -> Dict[str, Any]:
    doc = get_document(doc_id)
    if not doc:
        return {"found": False, "id": doc_id}
    return {"found": True, "document": doc, "full_text_returned": False}



# ------------------------ Backup / Recovery Hardening ------------------------

def _iter_existing_files(root: Path) -> Iterable[Path]:
    if not root.exists():
        return []
    return (p for p in root.rglob("*") if p.is_file() and not p.is_symlink())


def _zip_tree(zf: zipfile.ZipFile, root: Path, arc_prefix: str) -> int:
    count = 0
    if not root.exists():
        return count
    root_resolved = _safe_resolve(root)
    for path in root.rglob("*"):
        if path.is_symlink() or not path.is_file():
            continue
        resolved = _safe_resolve(path)
        if not _is_relative_to(resolved, root_resolved):
            continue
        try:
            if BACKUP_DIR in path.parents and path.suffix.lower() == ".zip":
                continue
        except Exception:
            pass
        zf.write(path, f"{arc_prefix}/{path.relative_to(root)}")
        count += 1
    return count


def _zipinfo_is_symlink(info: zipfile.ZipInfo) -> bool:
    mode = (info.external_attr >> 16) & 0o170000
    return mode == 0o120000


def safe_extract_zip(zf: zipfile.ZipFile, dest: Path, *, allowed_prefixes: Optional[Iterable[str]] = None) -> int:
    dest = _safe_resolve(dest)
    dest.mkdir(parents=True, exist_ok=True)
    prefixes = None
    if allowed_prefixes is not None:
        cleaned = []
        for p in allowed_prefixes:
            p = p.strip("/")
            if not p:
                continue
            cleaned.append(p if p.endswith("/") else p + "/")
            cleaned.append(p)
        prefixes = tuple(cleaned)
    total_size = 0
    extracted = 0
    for info in zf.infolist():
        name = info.filename.replace("\\", "/")
        if not name or name.startswith("/") or name.startswith("../") or "/../" in name or name == "..":
            raise ValueError(f"Unsafe ZIP member path: {info.filename}")
        if Path(name).is_absolute():
            raise ValueError(f"Absolute ZIP member path refused: {info.filename}")
        if _zipinfo_is_symlink(info):
            raise ValueError(f"ZIP symlink member refused: {info.filename}")
        if prefixes and not info.is_dir():
            if not any(name == p.rstrip("/") or name.startswith(p if p.endswith("/") else p + "/") for p in prefixes):
                raise ValueError(f"Unexpected ZIP member prefix: {info.filename}")
        if info.file_size > MAX_RESTORE_FILE_BYTES:
            raise ValueError(f"ZIP member too large: {info.filename}")
        total_size += info.file_size
        if total_size > MAX_RESTORE_TOTAL_BYTES:
            raise ValueError("ZIP expanded size exceeds safety limit")
        if extracted > MAX_RESTORE_FILES:
            raise ValueError("ZIP file count exceeds safety limit")
        target = _safe_resolve(dest / name)
        if not _is_relative_to(target, dest):
            raise ValueError(f"ZIP member escapes destination: {info.filename}")
        if info.is_dir():
            target.mkdir(parents=True, exist_ok=True)
            _chmod_private(target, 0o700)
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        with zf.open(info, "r") as src, target.open("wb") as out:
            copied = 0
            while True:
                chunk = src.read(1024 * 1024)
                if not chunk:
                    break
                copied += len(chunk)
                if copied > MAX_RESTORE_FILE_BYTES:
                    raise ValueError(f"ZIP member expanded beyond per-file limit: {info.filename}")
                out.write(chunk)
        _chmod_private(target, 0o600)
        extracted += 1
    return extracted

def backup_manifest(kind: str = "full_backup") -> Dict[str, Any]:
    docs = list_documents(include_archived=True)
    return {
        "program": APP_NAME,
        "program_id": PROGRAM_ID,
        "app_id": APP_ID,
        "version": VERSION,
        "kind": kind,
        "created_at": now_iso(),
        "local_only": LOCAL_ONLY,
        "network_enabled": NETWORK_ENABLED,
        "telemetry_enabled": TELEMETRY_ENABLED,
        "document_count_total": len(docs),
        "document_count_active": len([d for d in docs if d.get("status") == "active"]),
        "document_count_archived": len([d for d in docs if d.get("status") == "archived"]),
        "paths": paths_json(),
        "restore_policy": "copy-overwrite-known-sentinel-paths-only",
        "silent_control": False,
    }


def create_backup(output_path: Optional[str] = None, kind: str = "full_backup") -> Dict[str, Any]:
    init_environment()
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    target = Path(output_path).expanduser() if output_path else BACKUP_DIR / f"sentinel_documents_backup_{stamp}.zip"
    if target.suffix.lower() != ".zip":
        target = target.with_suffix(".zip")
    target.parent.mkdir(parents=True, exist_ok=True)
    manifest = backup_manifest(kind=kind)
    files_added = 0
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("manifest.json", json.dumps(manifest, indent=2))
        files_added += _zip_tree(zf, APP_DATA, "app_data")
        files_added += _zip_tree(zf, APP_CONFIG, "app_config")
        files_added += _zip_tree(zf, DOCUMENTS_ROOT, "documents_root")
    digest = sha256_file(target)
    result = {
        "ok": True,
        "backup_file": str(target),
        "sha256": digest,
        "files_added": files_added,
        "manifest": manifest,
        "timestamp": now_iso(),
    }
    (BACKUP_DIR / f"{target.stem}.manifest.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    write_aegis_contract_files()
    return result


def _copy_tree_contents(src: Path, dst: Path) -> int:
    count = 0
    if not src.exists():
        return count
    src_resolved = _safe_resolve(src)
    dst_resolved = _safe_resolve(dst)
    dst_resolved.mkdir(parents=True, exist_ok=True)
    for path in src.rglob("*"):
        if path.is_symlink() or not path.is_file():
            continue
        resolved = _safe_resolve(path)
        if not _is_relative_to(resolved, src_resolved):
            continue
        rel = path.relative_to(src)
        out = _safe_resolve(dst_resolved / rel)
        if not _is_relative_to(out, dst_resolved):
            raise ValueError(f"Refusing copy outside destination: {rel}")
        out.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, out)
        _chmod_private(out, 0o600)
        count += 1
    return count


def _merge_tree_contents(src: Path, dst: Path) -> int:
    count = 0
    if not src.exists():
        return count
    src_resolved = _safe_resolve(src)
    dst_resolved = _safe_resolve(dst)
    dst_resolved.mkdir(parents=True, exist_ok=True)
    for path in src.rglob("*"):
        if path.is_symlink() or not path.is_file():
            continue
        resolved = _safe_resolve(path)
        if not _is_relative_to(resolved, src_resolved):
            continue
        rel = path.relative_to(src)
        out = _safe_resolve(dst_resolved / rel)
        if not _is_relative_to(out, dst_resolved):
            raise ValueError(f"Refusing import outside destination: {rel}")
        if out.exists():
            out = out.with_name(f"{out.stem}_imported_{uuid.uuid4().hex[:8]}{out.suffix}")
        out.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, out)
        _chmod_private(out, 0o600)
        count += 1
    return count


def validate_backup_manifest(manifest: Dict[str, Any], *, allowed_kinds: Iterable[str]) -> None:
    if not manifest:
        raise ValueError("Backup manifest is missing")
    if manifest.get("app_id") != APP_ID:
        raise ValueError("Backup manifest app_id mismatch")
    if str(manifest.get("program_id")) != PROGRAM_ID:
        raise ValueError("Backup manifest program_id mismatch")
    if manifest.get("kind") not in set(allowed_kinds):
        raise ValueError(f"Backup manifest kind not allowed: {manifest.get('kind')}")


def validate_document_database_paths() -> Dict[str, Any]:
    unsafe: List[Dict[str, Any]] = []
    with db_connect() as conn:
        rows = [dict(r) for r in conn.execute("SELECT id,file_path,status FROM documents").fetchall()]
        for row in rows:
            path = Path(str(row.get("file_path") or "")).expanduser()
            ok, reason = validate_document_file_path(path)
            if not ok:
                unsafe.append({"id": row.get("id"), "path": str(path), "reason": reason})
                conn.execute("UPDATE documents SET status='unsafe_path', modified_at=? WHERE id=?", (now_iso(), row.get("id")))
        conn.commit()
    return {"unsafe_paths": unsafe, "unsafe_count": len(unsafe)}


def restore_backup(backup_file: str, make_safety_snapshot: bool = True, confirm: Optional[str] = None) -> Dict[str, Any]:
    if confirm != RESTORE_CONFIRM_TOKEN:
        raise ValueError(f"Guarded restore requires --confirm {RESTORE_CONFIRM_TOKEN}")
    init_environment()
    backup_path = Path(backup_file).expanduser()
    if not backup_path.exists():
        raise FileNotFoundError(str(backup_path))
    safety = None
    with tempfile.TemporaryDirectory(prefix="sentinel-documents-restore-") as tmp:
        tmp_root = Path(tmp)
        with zipfile.ZipFile(backup_path, "r") as zf:
            extracted_files = safe_extract_zip(zf, tmp_root, allowed_prefixes=("manifest.json", "app_data", "app_config", "documents_root"))
        manifest_path = tmp_root / "manifest.json"
        manifest = json.loads(manifest_path.read_text(encoding="utf-8")) if manifest_path.exists() else {}
        validate_backup_manifest(manifest, allowed_kinds=("full_backup", "pre_restore_safety"))
        if make_safety_snapshot:
            safety = create_backup(str(RECOVERY_DIR / f"pre_restore_safety_{datetime.now().strftime('%Y%m%d-%H%M%S')}.zip"), kind="pre_restore_safety")
        copied = 0
        copied += _copy_tree_contents(tmp_root / "app_data", APP_DATA)
        copied += _copy_tree_contents(tmp_root / "app_config", APP_CONFIG)
        copied += _copy_tree_contents(tmp_root / "documents_root", DOCUMENTS_ROOT)
    init_environment()
    path_validation = validate_document_database_paths()
    repair = repair_database()
    result = {
        "ok": True,
        "guarded_restore": True,
        "safe_extract_zip": True,
        "manifest_validated": True,
        "confirmation_token_required": RESTORE_CONFIRM_TOKEN,
        "restored_from": str(backup_path),
        "extracted_files": extracted_files,
        "copied_files": copied,
        "safety_snapshot": safety.get("backup_file") if safety else None,
        "source_manifest": manifest,
        "path_validation": path_validation,
        "post_restore_repair": repair,
        "timestamp": now_iso(),
    }
    _private_write_text(RECOVERY_DIR / f"restore_report_{datetime.now().strftime('%Y%m%d-%H%M%S')}.json", json.dumps(result, indent=2))
    write_aegis_contract_files()
    return result

def verify_database() -> Dict[str, Any]:
    init_environment()
    issues: List[Dict[str, Any]] = []
    integrity = "unknown"
    document_rows = []
    try:
        with db_connect() as conn:
            integrity = str(conn.execute("PRAGMA integrity_check").fetchone()[0])
            document_rows = [dict(r) for r in conn.execute("SELECT * FROM documents ORDER BY modified_at DESC").fetchall()]
    except Exception as exc:
        issues.append({"type": "database_error", "message": str(exc)})
    missing_files = 0
    hash_mismatches = 0
    unsafe_paths = 0
    for row in document_rows:
        path = Path(str(row.get("file_path") or "")).expanduser()
        ok_path, reason = validate_document_file_path(path)
        if not ok_path:
            unsafe_paths += 1
            issues.append({"type": "unsafe_document_path", "id": row.get("id"), "path": str(path), "message": reason})
            continue
        if not path.exists():
            missing_files += 1
            issues.append({"type": "missing_document_file", "id": row.get("id"), "path": str(path)})
            continue
        recorded = row.get("sha256")
        if recorded:
            try:
                actual = sha256_file(path)
                if actual != recorded:
                    hash_mismatches += 1
                    issues.append({"type": "sha256_mismatch", "id": row.get("id"), "path": str(path), "recorded": recorded, "actual": actual})
            except Exception as exc:
                issues.append({"type": "hash_error", "id": row.get("id"), "path": str(path), "message": str(exc)})
    return {
        "ok": integrity == "ok" and not issues,
        "database": str(DB_PATH),
        "database_exists": DB_PATH.exists(),
        "integrity_check": integrity,
        "document_count": len(document_rows),
        "missing_files": missing_files,
        "hash_mismatches": hash_mismatches,
        "unsafe_paths": unsafe_paths,
        "template_count": len(list_templates()),
        "bridge_status": bridge_status(),
        "issues": issues,
        "timestamp": now_iso(),
    }

def repair_database() -> Dict[str, Any]:
    init_environment()
    updated_hashes = 0
    marked_missing = 0
    imported_files = 0
    unsafe_paths = 0
    with db_connect() as conn:
        rows = [dict(r) for r in conn.execute("SELECT * FROM documents").fetchall()]
        indexed_paths = {str(Path(r.get("file_path") or "").expanduser()) for r in rows}
        for row in rows:
            path = Path(str(row.get("file_path") or "")).expanduser()
            ok_path, _reason = validate_document_file_path(path)
            if not ok_path:
                if row.get("status") != "unsafe_path":
                    conn.execute("UPDATE documents SET status='unsafe_path', modified_at=? WHERE id=?", (now_iso(), row.get("id")))
                unsafe_paths += 1
                continue
            if path.exists():
                digest = sha256_file(path)
                if digest != row.get("sha256"):
                    conn.execute("UPDATE documents SET sha256=?, modified_at=? WHERE id=?", (digest, now_iso(), row.get("id")))
                    updated_hashes += 1
            else:
                if row.get("status") != "missing_file":
                    conn.execute("UPDATE documents SET status='missing_file', modified_at=? WHERE id=?", (now_iso(), row.get("id")))
                    marked_missing += 1
        for root in [DOCUMENTS_DIR, EXPORTS_DIR]:
            if not root.exists():
                continue
            for path in root.rglob("*"):
                if path.is_symlink() or not path.is_file() or path.name.endswith(".sentinel-style.json"):
                    continue
                ok_path, _reason = validate_document_file_path(path)
                if not ok_path:
                    continue
                if str(path) in indexed_paths:
                    continue
                if path.suffix.lower() not in {".md", ".txt", ".html", ".pdf", ".odt", ".docx"}:
                    continue
                title = path.stem.replace("-", " ").replace("_", " ").strip().title() or "Recovered Document"
                doc_id = document_id()
                conn.execute(
                    """
                    INSERT INTO documents(id,title,category,doc_type,file_path,content_format,status,sha256,created_at,modified_at)
                    VALUES(?,?,?,?,?,?,?,?,?,?)
                    """,
                    (doc_id, title, "Recovered", "Recovered Document", str(path), path.suffix.lower().lstrip(".") or "text", "active", sha256_file(path), now_iso(), now_iso()),
                )
                imported_files += 1
        conn.commit()
    verify = verify_database()
    result = {
        "ok": True,
        "updated_hashes": updated_hashes,
        "marked_missing_files": marked_missing,
        "unsafe_paths_marked": unsafe_paths,
        "imported_unindexed_files": imported_files,
        "post_repair_verify_ok": verify.get("ok"),
        "post_repair_verify": verify,
        "timestamp": now_iso(),
    }
    _private_write_text(RECOVERY_DIR / f"repair_report_{datetime.now().strftime('%Y%m%d-%H%M%S')}.json", json.dumps(result, indent=2))
    write_aegis_contract_files()
    return result

def export_library(output_path: Optional[str] = None) -> Dict[str, Any]:
    init_environment()
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    target = Path(output_path).expanduser() if output_path else EXPORTS_DIR / f"sentinel_documents_library_export_{stamp}.zip"
    if target.suffix.lower() != ".zip":
        target = target.with_suffix(".zip")
    target.parent.mkdir(parents=True, exist_ok=True)
    docs = list_documents(include_archived=True)
    manifest = {
        "program": APP_NAME,
        "program_id": PROGRAM_ID,
        "app_id": APP_ID,
        "kind": "library_export",
        "version": VERSION,
        "created_at": now_iso(),
        "documents": docs,
        "import_policy": "merge-only-no-db-config-overwrite",
    }
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("library_manifest.json", json.dumps(manifest, indent=2))
        count = _zip_tree(zf, DOCUMENTS_ROOT, "documents_root")
    _chmod_private(target, 0o600)
    return {"ok": True, "export_file": str(target), "sha256": sha256_file(target), "files_added": count, "document_count": len(docs), "timestamp": now_iso()}


def import_library(import_file: str, confirm: Optional[str] = None) -> Dict[str, Any]:
    # Library import is intentionally merge-only. It never restores app_data, app_config,
    # or a supplied database. Full overwrite remains --restore-backup with the typed token.
    if confirm != "IMPORT_SENTINEL_DOCUMENTS_LIBRARY":
        raise ValueError("Library import requires --confirm IMPORT_SENTINEL_DOCUMENTS_LIBRARY")
    init_environment()
    import_path = Path(import_file).expanduser()
    if not import_path.exists():
        raise FileNotFoundError(str(import_path))
    with tempfile.TemporaryDirectory(prefix="sentinel-documents-import-") as tmp:
        tmp_root = Path(tmp)
        with zipfile.ZipFile(import_path, "r") as zf:
            extracted_files = safe_extract_zip(zf, tmp_root, allowed_prefixes=("library_manifest.json", "documents_root"))
        manifest_path = tmp_root / "library_manifest.json"
        manifest = json.loads(manifest_path.read_text(encoding="utf-8")) if manifest_path.exists() else {}
        if manifest.get("app_id") != APP_ID or str(manifest.get("program_id")) != PROGRAM_ID or manifest.get("kind") != "library_export":
            raise ValueError("Invalid Sentinel Documents library manifest")
        copied = 0
        copied += _merge_tree_contents(tmp_root / "documents_root" / "Documents", DOCUMENTS_DIR)
        copied += _merge_tree_contents(tmp_root / "documents_root" / "Archive", ARCHIVE_DIR)
        copied += _merge_tree_contents(tmp_root / "documents_root" / "Exports", EXPORTS_DIR)
    repair = repair_database()
    result = {
        "ok": True,
        "operation": "import_library",
        "merge_only": True,
        "safe_extract_zip": True,
        "manifest_validated": True,
        "imported_from": str(import_path),
        "extracted_files": extracted_files,
        "copied_files": copied,
        "source_manifest": manifest,
        "post_import_repair": repair,
        "timestamp": now_iso(),
    }
    _private_write_text(RECOVERY_DIR / f"import_report_{datetime.now().strftime('%Y%m%d-%H%M%S')}.json", json.dumps(result, indent=2))
    write_aegis_contract_files()
    return result

def repair_launcher() -> Dict[str, Any]:
    init_environment()
    local_apps = HOME / ".local" / "share" / "applications"
    local_apps.mkdir(parents=True, exist_ok=True)
    desktop = local_apps / "sentinel-documents.desktop"
    desktop.write_text("""[Desktop Entry]\nType=Application\nName=Sentinel Documents\nComment=Sentinel document maker and local document bridge\nExec=/usr/bin/sentinel-documents\nIcon=sentinel-documents\nTerminal=false\nCategories=Office;Utility;\nStartupNotify=true\n""", encoding="utf-8")
    try:
        desktop.chmod(0o755)
    except Exception:
        pass
    return {"ok": True, "desktop_file": str(desktop), "timestamp": now_iso()}


def recovery_report_json() -> Dict[str, Any]:
    return {
        "program": APP_NAME,
        "version": VERSION,
        "backup_dir": str(BACKUP_DIR),
        "recovery_dir": str(RECOVERY_DIR),
        "latest_verify": verify_database(),
        "recent_backups": [str(p) for p in sorted(BACKUP_DIR.glob("*.zip"), key=lambda x: x.stat().st_mtime, reverse=True)[:10]],
        "recent_recovery_reports": [str(p) for p in sorted(RECOVERY_DIR.glob("*.json"), key=lambda x: x.stat().st_mtime, reverse=True)[:10]],
        "timestamp": now_iso(),
    }

# ----------------------------- GUI -----------------------------

def launch_gui() -> int:
    init_environment()
    try:
        import tkinter as tk
        from tkinter import filedialog, messagebox, simpledialog
        from tkinter import ttk
        import tkinter.font as tkfont
    except Exception as exc:  # pragma: no cover - depends on host packages
        print("Sentinel Documents GUI requires Python Tk support (package: python3-tk).", file=sys.stderr)
        print(f"Import error: {exc}", file=sys.stderr)
        return 2

    class SentinelDocumentsGUI:
        def __init__(self, root: tk.Tk) -> None:
            self.root = root
            self.root.title(f"{APP_NAME} v{VERSION}")
            self.root.geometry("1360x860")
            self.root.minsize(1060, 660)
            self.root.resizable(True, True)
            self.current_doc_id: Optional[str] = None
            self.dirty = False
            self.var_title = tk.StringVar(value="Untitled Document")
            self.var_category = tk.StringVar(value="General")
            self.var_doc_type = tk.StringVar(value="Document")
            self.var_contact = tk.StringVar(value="")
            self.var_job = tk.StringVar(value="")
            self.var_inventory = tk.StringVar(value="")
            self.var_status = tk.StringVar(value="Ready — v1 stable locked: AEGIS/Vault metadata, working bold/italic formatting, search, bridges, export layer, backup/recovery, and LibreOffice handoff active")
            format_prefs = load_gui_format()
            self.font_family_choices = resolve_gui_font_families(tkfont, self.root)
            saved_font_family = str(format_prefs.get("font_family", "Sans"))
            if saved_font_family and saved_font_family.casefold() not in {name.casefold() for name in self.font_family_choices}:
                self.font_family_choices.insert(0, saved_font_family)
            self.var_font_family = tk.StringVar(value=saved_font_family)
            self.var_font_size = tk.IntVar(value=int(format_prefs.get("font_size", 12)))
            self.var_paragraph_align = tk.StringVar(value=str(format_prefs.get("paragraph_align", "left")))
            self.var_line_spacing = tk.IntVar(value=int(format_prefs.get("line_spacing", 4)))
            self.var_paragraph_spacing = tk.IntVar(value=int(format_prefs.get("paragraph_spacing", 8)))
            self.var_search = tk.StringVar(value="")
            self.var_theme = tk.StringVar(value=load_gui_theme())
            scale_prefs = load_gui_scale()
            self.var_editor_scale = tk.IntVar(value=scale_prefs.get("editor_scale", 100))
            self.var_side_width = tk.IntVar(value=scale_prefs.get("side_width", 190))
            self.documents: List[Dict[str, Any]] = []
            self.left_panel = None
            self.right_panel = None
            self.editor_canvas = None
            self.icon_box = None
            self.search_entry = None
            self.menu_widgets: List[Any] = []
            self.tkfont_module = tkfont

            self.colors = self.theme_palette(self.var_theme.get())
            self.setup_style(ttk, tkfont)
            self.build_ui(tk, ttk, filedialog, messagebox, simpledialog)
            self.load_document_list()
            self.new_document(initial=True)
            self.root.after(120, self.maximize_default_window)

        def theme_palette(self, theme: str) -> Dict[str, str]:
            if theme == "sentinel_light_cyan":
                return {
                    "theme_name": "sentinel_light_cyan",
                    "bg": "#d9edf5",
                    "panel": "#c4e4ef",
                    "panel2": "#a7d8e8",
                    "panel3": "#7fcce4",
                    "hero": "#eefbff",
                    "menu": "#8acfe5",
                    "text": "#061018",
                    "muted": "#294d59",
                    "gold": "#9A6400",
                    "cyan": "#006f88",
                    "red": "#a33c35",
                    "page": "#dff6fb",
                    "page_text": "#061018",
                    "border": "#4b9eb4",
                    "button": "#b7e9f7",
                    "input": "#f6fdff",
                    "input_text": "#061018",
                    "select_bg": "#00a7ca",
                    "select_fg": "#ffffff",
                    "editor_shell": "#b7e9f7",
                    "active_fg": "#003f4e",
                }
            return {
                "theme_name": "aegis_dark",
                "bg": "#03080c",
                "panel": "#071019",
                "panel2": "#0d1821",
                "panel3": "#132631",
                "hero": "#02070a",
                "menu": "#202428",
                "text": "#d6e1ea",
                "muted": "#a9b8c6",
                "gold": "#FFB000",
                "cyan": "#00D7FF",
                "red": "#ff746b",
                "page": "#0b1118",
                "page_text": "#d6e1ea",
                "border": "#253744",
                "button": "#142632",
                "input": "#0b1720",
                "input_text": "#e6f0f6",
                "select_bg": "#005f73",
                "select_fg": "#ffffff",
                "editor_shell": "#02070a",
                "active_fg": "#FFB000",
            }

        def setup_style(self, ttk: Any, tkfont: Any) -> None:
            style = ttk.Style()
            try:
                style.theme_use("clam")
            except Exception:
                pass
            style.configure("TFrame", background=self.colors["bg"])
            style.configure("Panel.TFrame", background=self.colors["panel"])
            style.configure("Header.TFrame", background=self.colors["panel2"])
            style.configure("TLabel", background=self.colors["bg"], foreground=self.colors["text"])
            style.configure("Panel.TLabel", background=self.colors["panel"], foreground=self.colors["text"])
            style.configure("Muted.TLabel", background=self.colors["panel"], foreground=self.colors["muted"])
            style.configure("Gold.TLabel", background=self.colors["panel2"], foreground=self.colors["gold"], font=("Sans", 12, "bold"))
            style.configure("TButton", background=self.colors["button"], foreground=self.colors["text"], bordercolor=self.colors["border"], padding=6)
            style.map("TButton", foreground=[("active", self.colors["active_fg"])], background=[("active", self.colors["panel3"])])
            style.configure("Nav.TButton", background=self.colors["button"], foreground=self.colors["text"], bordercolor=self.colors["border"], padding=(6, 6))
            style.map("Nav.TButton", foreground=[("active", self.colors["active_fg"])], background=[("active", self.colors["panel3"])])
            style.configure("Hero.TFrame", background=self.colors["panel2"], borderwidth=1, relief="solid")
            style.configure("HeroInner.TFrame", background=self.colors["hero"])
            style.configure("HeroTitle.TLabel", background=self.colors["hero"], foreground=self.colors["gold"], font=("Sans", 16, "bold"))
            style.configure("HeroSub.TLabel", background=self.colors["hero"], foreground=self.colors["muted"])
            style.configure("Menu.TFrame", background=self.colors["menu"])
            style.configure("Ribbon.TNotebook", background=self.colors["panel2"], borderwidth=0)
            style.configure("Ribbon.TNotebook.Tab", padding=(12, 6), background=self.colors["panel"], foreground=self.colors["text"])
            style.map("Ribbon.TNotebook.Tab", background=[("selected", self.colors["panel2"])], foreground=[("selected", self.colors["active_fg"])])
            style.configure("TEntry", fieldbackground=self.colors["input"], foreground=self.colors["input_text"], insertcolor=self.colors["input_text"], bordercolor=self.colors["border"], lightcolor=self.colors["border"], darkcolor=self.colors["border"], padding=4)
            style.map("TEntry", fieldbackground=[("focus", self.colors["input"])], foreground=[("focus", self.colors["input_text"])])
            style.configure("TCombobox", fieldbackground=self.colors["input"], background=self.colors["button"], foreground=self.colors["input_text"], arrowcolor=self.colors["cyan"], bordercolor=self.colors["border"], lightcolor=self.colors["border"], darkcolor=self.colors["border"], padding=4)
            style.map("TCombobox", fieldbackground=[("readonly", self.colors["input"]), ("focus", self.colors["input"])], foreground=[("readonly", self.colors["input_text"]), ("focus", self.colors["input_text"])], selectbackground=[("readonly", self.colors["select_bg"])], selectforeground=[("readonly", self.colors["select_fg"])])
            style.configure("TSpinbox", fieldbackground=self.colors["input"], foreground=self.colors["input_text"], arrowcolor=self.colors["cyan"], bordercolor=self.colors["border"], padding=4)
            style.configure("Treeview", background=self.colors["panel"], foreground=self.colors["text"], fieldbackground=self.colors["panel"], rowheight=24, bordercolor=self.colors["border"])
            style.map("Treeview", background=[("selected", self.colors["select_bg"])], foreground=[("selected", self.colors["select_fg"])])
            style.configure("Treeview.Heading", background=self.colors["panel2"], foreground=self.colors["gold"])
            try:
                self.root.option_add("*Menu.background", self.colors["panel2"])
                self.root.option_add("*Menu.foreground", self.colors["text"])
                self.root.option_add("*Menu.activeBackground", self.colors["panel3"])
                self.root.option_add("*Menu.activeForeground", self.colors["active_fg"])
                self.root.option_add("*TCombobox*Listbox.background", self.colors["input"])
                self.root.option_add("*TCombobox*Listbox.foreground", self.colors["input_text"])
                self.root.option_add("*TCombobox*Listbox.selectBackground", self.colors["select_bg"])
                self.root.option_add("*TCombobox*Listbox.selectForeground", self.colors["select_fg"])
            except Exception:
                pass
            self.base_font = tkfont.Font(family=str(self.var_font_family.get() or "Sans"), size=int(self.var_font_size.get() or 12))

        def build_ui(self, tk: Any, ttk: Any, filedialog: Any, messagebox: Any, simpledialog: Any) -> None:
            self.tk = tk
            self.ttk = ttk
            self.filedialog = filedialog
            self.messagebox = messagebox
            self.simpledialog = simpledialog

            self.root.configure(bg=self.colors["bg"])
            self.menu_strip = ttk.Frame(self.root, style="Menu.TFrame")
            self.menu_strip.pack(side="top", fill="x")
            self.make_dropdown_menu(self.menu_strip, "File", [
                ("New	Ctrl+N", self.new_document),
                ("Open	Ctrl+O", self.open_document_dialog),
                ("Save	Ctrl+S", self.save_document),
                ("Save As	Ctrl+Shift+S", self.save_as_document),
                ("Archive", self.archive_current_document),
                ("Restore Archived...", self.show_document_search),
                ("Search Documents	Ctrl+F", self.show_document_search),
                ("Quit	Ctrl+Q", self.on_close),
            ])
            self.make_dropdown_menu(self.menu_strip, "View", [
                ("AEGIS Dark", lambda: self.set_theme("aegis_dark")),
                ("Sentinel Light Cyan", lambda: self.set_theme("sentinel_light_cyan")),
                ("Dashboard", self.show_dashboard),
                ("Search Documents	Ctrl+F", self.show_document_search),
            ])
            self.make_dropdown_menu(self.menu_strip, "Help", [
                ("About", self.show_about),
                ("Print Paths", self.show_paths),
                ("Show Health", self.show_health),
            ])

            # Keep the office-style ribbon/tab row at the top of the window, directly under the File/View/Help strip.
            # The Sentinel header remains below it so the working tabs stay in the top menu area.
            self.ribbon = ttk.Notebook(self.root, style="Ribbon.TNotebook")
            self.ribbon.pack(side="top", fill="x", padx=10, pady=(4, 0))
            self.make_home_tab()
            self.make_format_tab()
            self.make_insert_tab()
            self.make_layout_tab()
            self.make_templates_tab()
            self.make_search_tab()
            self.make_sentinel_tab()
            self.make_aegis_tab()
            self.make_recovery_tab()
            self.make_audit_tab()
            self.make_export_tab()
            self.make_help_tab()

            hero_outer = ttk.Frame(self.root, style="Hero.TFrame")
            hero_outer.pack(side="top", fill="x", padx=10, pady=(8, 8))
            self.icon_box = self.tk.Canvas(hero_outer, width=96, height=82, bg=self.colors["panel2"], highlightthickness=0)
            self.icon_box.pack(side="left", padx=14, pady=8)
            self.draw_header_icon()
            hero_text = ttk.Frame(hero_outer, style="HeroInner.TFrame")
            hero_text.pack(side="left", fill="both", expand=True, padx=(0, 12), pady=10)
            ttk.Label(hero_text, text="S E N T I N E L   D O C U M E N T S", style="HeroTitle.TLabel").pack(anchor="w", padx=12, pady=(10, 2))
            ttk.Label(hero_text, text="Document Maker, Template Engine & Jobs Bridge — Program 116", style="HeroSub.TLabel").pack(anchor="w", padx=12, pady=2)
            ttk.Label(hero_text, text="Office-familiar • Templates • Contacts • Inventory • Jobs • AEGIS • Local Handoff", style="HeroSub.TLabel").pack(anchor="w", padx=12, pady=2)
            ttk.Label(hero_text, text=f"Sentinel Documents v{VERSION} • V1 stable locked • Maximized default window • Bold/Italic fixed • Expanded font library • AEGIS/Vault ready • Local-only", foreground=self.colors["cyan"], background=self.colors["hero"]).pack(anchor="w", padx=12, pady=(2, 10))

            main = ttk.Frame(self.root)
            main.pack(fill="both", expand=True)

            left = ttk.Frame(main, style="Panel.TFrame", width=210)
            self.left_panel = left
            left.pack(side="left", fill="y")
            left.pack_propagate(False)
            nav_title = ttk.Label(left, text="Command", style="Panel.TLabel", font=("Sans", 11, "bold"))
            nav_title.pack(anchor="w", padx=10, pady=(10, 4))
            for label, cmd in [
                ("Dashboard", self.show_dashboard),
                ("New", self.new_document),
                ("Open File", self.open_document_dialog),
                ("Search", self.show_document_search),
                ("Templates", lambda: self.ribbon.select(4)),
                ("Contacts", lambda: self.ribbon.select(6)),
                ("Inventory", lambda: self.open_path(INVENTORY_BRIDGE_DIR)),
                ("Jobs", lambda: self.open_path(JOBS_BRIDGE_DIR)),
                ("Import / Export", lambda: self.ribbon.select(8)),
                ("Manual", self.show_about),
            ]:
                ttk.Button(left, text=label, style="Nav.TButton", command=cmd).pack(fill="x", padx=10, pady=3)
            ttk.Separator(left).pack(fill="x", padx=10, pady=10)
            ttk.Label(left, text="Open/save from File or Home. Search opens as a separate manager, not a side-library panel.", style="Muted.TLabel", wraplength=160, justify="left").pack(anchor="w", padx=10, pady=(4, 8))
            self.doc_tree = None
            self.search_entry = None

            center = ttk.Frame(main)
            center.pack(side="left", fill="both", expand=True)
            meta = ttk.Frame(center, style="Panel.TFrame")
            meta.pack(side="top", fill="x", padx=12, pady=(10, 4))
            ttk.Label(meta, text="Title", style="Panel.TLabel").grid(row=0, column=0, padx=6, pady=4, sticky="w")
            ttk.Entry(meta, textvariable=self.var_title, width=38).grid(row=0, column=1, padx=4, pady=4, sticky="ew")
            ttk.Label(meta, text="Category", style="Panel.TLabel").grid(row=0, column=2, padx=6, pady=4, sticky="w")
            ttk.Combobox(meta, textvariable=self.var_category, values=["General", "Letters", "Jobs", "Quotes", "Reports", "Inventory", "Warranty", "Contacts", "Manuals", "Ledger", "AEGIS", "Vault"], width=16).grid(row=0, column=3, padx=4, pady=4)
            ttk.Label(meta, text="Type", style="Panel.TLabel").grid(row=0, column=4, padx=6, pady=4, sticky="w")
            ttk.Combobox(meta, textvariable=self.var_doc_type, values=["Document", "Letter", "Report", "Quote", "Job Sheet", "Inventory Sheet", "AEGIS Report"], width=15).grid(row=0, column=5, padx=4, pady=4)
            meta.columnconfigure(1, weight=1)

            editor_shell = ttk.Frame(center)
            editor_shell.pack(fill="both", expand=True, padx=12, pady=10)
            self.editor_canvas = tk.Frame(editor_shell, bg=self.colors["editor_shell"])
            canvas = self.editor_canvas
            canvas.pack(fill="both", expand=True)
            self.text = tk.Text(
                canvas,
                wrap="word",
                undo=True,
                font=self.base_font,
                bg=self.colors["page"],
                fg=self.colors["page_text"],
                insertbackground=self.colors["page_text"],
                selectbackground=self.colors["select_bg"],
                selectforeground=self.colors["select_fg"],
                exportselection=False,
                relief="flat",
                padx=48,
                pady=38,
            )
            self.text.pack(fill="both", expand=True, padx=28, pady=18)
            self.text.bind("<<Modified>>", self.on_text_modified)
            self.text.bind("<Button-3>", self.show_text_context_menu)
            self.text.bind("<Button-2>", self.show_text_context_menu)
            self.text.bind("<Shift-F10>", self.show_text_context_menu)
            self.text.bind("<Menu>", self.show_text_context_menu)
            self.apply_document_formatting(save=False, announce=False)

            right = ttk.Frame(main, style="Panel.TFrame", width=265)
            self.right_panel = right
            right.pack(side="right", fill="y")
            right.pack_propagate(False)
            ttk.Label(right, text="Sentinel Links", style="Panel.TLabel", font=("Sans", 11, "bold")).pack(anchor="w", padx=10, pady=(10, 4))
            for label, var in [("Contact Code", self.var_contact), ("Job Code", self.var_job), ("Inventory Code", self.var_inventory)]:
                ttk.Label(right, text=label, style="Panel.TLabel").pack(anchor="w", padx=10, pady=(8, 2))
                ttk.Entry(right, textvariable=var).pack(fill="x", padx=10, pady=2)
            ttk.Separator(right).pack(fill="x", padx=10, pady=12)
            self.info_label = ttk.Label(right, text=self.right_info_text(), style="Panel.TLabel", justify="left", wraplength=235)
            self.info_label.pack(anchor="w", padx=10, pady=4)
            ttk.Separator(right).pack(fill="x", padx=10, pady=12)
            ttk.Label(right, text="Bridge Surfaces", style="Panel.TLabel", font=("Sans", 10, "bold")).pack(anchor="w", padx=10, pady=(4, 2))
            bridge_text = f"Contacts: ready ({contact_record_count()} cached)\nInventory: ready\nJobs: ready\nMode: local file handoff\nSilent control: disabled"
            ttk.Label(right, text=bridge_text, style="Panel.TLabel", justify="left").pack(anchor="w", padx=10, pady=4)

            status = ttk.Frame(self.root, style="Header.TFrame")
            status.pack(side="bottom", fill="x")
            ttk.Label(status, textvariable=self.var_status, style="Muted.TLabel").pack(side="left", padx=10, pady=4)

            self.apply_scale_settings(save=False, announce=False)
            self.root.protocol("WM_DELETE_WINDOW", self.on_close)
            self.bind_hotkeys()
            self.root.bind("<Configure>", self.on_resize)

        def ribbon_frame(self, name: str) -> Any:
            f = self.ttk.Frame(self.ribbon, style="Panel.TFrame")
            self.ribbon.add(f, text=name)
            return f

        def make_home_tab(self) -> None:
            f = self.ribbon_frame("Home")
            for text, cmd in [
                ("New", self.new_document),
                ("Open", self.open_document_dialog),
                ("Search", self.show_document_search),
                ("Save", self.save_document),
                ("Save As", self.save_as_document),
                ("Delete/Archive", self.archive_current_document),
                ("Restore", self.show_document_search),
                ("Bold", lambda: self.toggle_inline_style("bold")),
                ("Italic", lambda: self.toggle_inline_style("italic")),
                ("Underline", lambda: self.toggle_text_decoration("fmt_underline", "Underline", "__", "__")),
                ("Bullets", self.insert_bullets),
                ("Date", self.insert_date),
            ]:
                self.ttk.Button(f, text=text, command=cmd).pack(side="left", padx=4, pady=8)
            self.ttk.Label(f, text="Font Size", style="Panel.TLabel").pack(side="left", padx=(16, 4))
            spin = self.ttk.Spinbox(f, from_=8, to=50, textvariable=self.var_font_size, width=4, command=self.apply_document_formatting)
            spin.pack(side="left", padx=4)
            self.ttk.Button(f, text="Font...", command=lambda: self.show_font_picker(source="home")).pack(side="left", padx=4, pady=8)
            self.ttk.Button(f, text="Format Tab", command=lambda: self.ribbon.select(1)).pack(side="left", padx=4, pady=8)

        def make_format_tab(self) -> None:
            f = self.ribbon_frame("Format")
            self.ttk.Label(f, text="Font", style="Panel.TLabel").pack(side="left", padx=(8, 4), pady=10)
            self.font_combo = self.ttk.Combobox(f, textvariable=self.var_font_family, values=self.font_family_choices, width=24)
            self.font_combo.pack(side="left", padx=4, pady=8)
            self.font_combo.bind("<<ComboboxSelected>>", lambda e: self.apply_document_formatting())
            self.ttk.Button(f, text="Refresh Fonts", command=self.refresh_font_choices).pack(side="left", padx=4, pady=8)
            self.ttk.Label(f, text="Size", style="Panel.TLabel").pack(side="left", padx=(8, 4), pady=10)
            self.ttk.Spinbox(f, from_=8, to=50, textvariable=self.var_font_size, width=4, command=self.apply_document_formatting).pack(side="left", padx=4, pady=8)
            self.ttk.Button(f, text="Apply Font", command=self.apply_document_formatting).pack(side="left", padx=4, pady=8)
            self.ttk.Separator(f, orient="vertical").pack(side="left", fill="y", padx=8, pady=6)
            for label, align in [("Left", "left"), ("Center", "center"), ("Right", "right")]:
                self.ttk.Button(f, text=label, command=lambda a=align: self.apply_paragraph_alignment(a)).pack(side="left", padx=3, pady=8)
            self.ttk.Label(f, text="Line", style="Panel.TLabel").pack(side="left", padx=(8, 4), pady=10)
            self.ttk.Spinbox(f, from_=0, to=24, textvariable=self.var_line_spacing, width=4, command=self.apply_document_formatting).pack(side="left", padx=4, pady=8)
            self.ttk.Label(f, text="Para", style="Panel.TLabel").pack(side="left", padx=(8, 4), pady=10)
            self.ttk.Spinbox(f, from_=0, to=36, textvariable=self.var_paragraph_spacing, width=4, command=self.apply_document_formatting).pack(side="left", padx=4, pady=8)
            self.ttk.Separator(f, orient="vertical").pack(side="left", fill="y", padx=8, pady=6)
            for label, cmd in [
                ("H1", lambda: self.apply_line_style("h1")),
                ("H2", lambda: self.apply_line_style("h2")),
                ("Normal", lambda: self.apply_line_style("normal")),
                ("Quote", lambda: self.apply_line_style("quote")),
                ("Numbered", self.insert_numbered_list),
            ]:
                self.ttk.Button(f, text=label, command=cmd).pack(side="left", padx=3, pady=8)
            self.ttk.Button(f, text="Save Format", command=lambda: self.apply_document_formatting(save=True)).pack(side="left", padx=8, pady=8)
            self.ttk.Button(f, text="Right-Click Menu Help", command=self.show_context_menu_help).pack(side="left", padx=4, pady=8)

        def make_insert_tab(self) -> None:
            f = self.ribbon_frame("Insert")
            for text, cmd in [
                ("Heading", lambda: self.insert_text("# Heading\n")),
                ("Subheading", lambda: self.insert_text("## Subheading\n")),
                ("Table Stub", self.insert_table_stub),
                ("Signature Block", self.insert_signature),
                ("Page Break Marker", lambda: self.insert_text("\n--- page break ---\n")),
            ]:
                self.ttk.Button(f, text=text, command=cmd).pack(side="left", padx=4, pady=8)

        def make_layout_tab(self) -> None:
            f = self.ribbon_frame("Layout")
            self.ttk.Label(f, text="Theme", style="Panel.TLabel").pack(side="left", padx=(10, 4), pady=10)
            self.theme_combo = self.ttk.Combobox(f, textvariable=self.var_theme, values=["aegis_dark", "sentinel_light_cyan"], width=20, state="readonly")
            self.theme_combo.pack(side="left", padx=4, pady=8)
            self.ttk.Button(f, text="Apply Theme", command=lambda: self.set_theme(self.var_theme.get())).pack(side="left", padx=4, pady=8)
            self.ttk.Label(f, text="Editor Scale %", style="Panel.TLabel").pack(side="left", padx=(12, 4), pady=10)
            self.editor_scale_spin = self.ttk.Spinbox(f, from_=80, to=180, increment=5, textvariable=self.var_editor_scale, width=5, command=self.apply_scale_settings)
            self.editor_scale_spin.pack(side="left", padx=4, pady=8)
            self.ttk.Label(f, text="Side Menu px", style="Panel.TLabel").pack(side="left", padx=(12, 4), pady=10)
            self.side_width_spin = self.ttk.Spinbox(f, from_=155, to=280, increment=5, textvariable=self.var_side_width, width=5, command=self.apply_scale_settings)
            self.side_width_spin.pack(side="left", padx=4, pady=8)
            self.ttk.Button(f, text="Apply Scale", command=self.apply_scale_settings).pack(side="left", padx=4, pady=8)
            self.ttk.Label(f, text="The editor page follows the active Sentinel theme; font/paragraph controls live on the Format tab.", style="Panel.TLabel").pack(side="left", padx=10, pady=10)

        def make_templates_tab(self) -> None:
            f = self.ribbon_frame("Templates")
            self.template_var = self.tk.StringVar(value=list_templates()[0] if list_templates() else "")
            self.ttk.Combobox(f, textvariable=self.template_var, values=list_templates(), width=28).pack(side="left", padx=8, pady=8)
            self.ttk.Button(f, text="Load Raw Template", command=self.load_template).pack(side="left", padx=4, pady=8)
            self.ttk.Button(f, text="Create From Template", command=self.gui_create_from_template).pack(side="left", padx=4, pady=8)
            self.ttk.Button(f, text="Template Info", command=self.gui_template_info).pack(side="left", padx=4, pady=8)
            self.ttk.Button(f, text="Open Templates Folder", command=lambda: self.open_path(TEMPLATES_DIR)).pack(side="left", padx=4, pady=8)

        def make_search_tab(self) -> None:
            f = self.ribbon_frame("Search")
            self.ttk.Button(f, text="Search Documents", command=self.show_document_search).pack(side="left", padx=4, pady=8)
            self.ttk.Button(f, text="Recent Documents", command=lambda: self.show_document_search(preset="recent")).pack(side="left", padx=4, pady=8)
            self.ttk.Button(f, text="Archived Documents", command=lambda: self.show_document_search(preset="archived")).pack(side="left", padx=4, pady=8)
            self.ttk.Button(f, text="Category Summary", command=self.show_category_summary).pack(side="left", padx=4, pady=8)
            self.ttk.Label(f, text="Search and manage the local document index without putting the library back into the side menu.", style="Panel.TLabel").pack(side="left", padx=12, pady=10)

        def make_sentinel_tab(self) -> None:
            f = self.ribbon_frame("Sentinel")
            self.ttk.Button(f, text="Import Contact JSON", command=self.gui_import_contact_bridge).pack(side="left", padx=4, pady=8)
            self.ttk.Button(f, text="Create Contact Summary", command=self.gui_create_contact_summary).pack(side="left", padx=4, pady=8)
            self.ttk.Button(f, text="Export Contact Bridge", command=self.gui_export_contact_bridge).pack(side="left", padx=4, pady=8)
            self.ttk.Button(f, text="Import Inventory JSON", command=self.gui_import_inventory_bridge).pack(side="left", padx=4, pady=8)
            self.ttk.Button(f, text="Create Inventory Report", command=self.gui_create_inventory_report).pack(side="left", padx=4, pady=8)
            self.ttk.Button(f, text="Export Inventory Bridge", command=self.gui_export_inventory_bridge).pack(side="left", padx=4, pady=8)
            self.ttk.Button(f, text="Import Job JSON", command=self.gui_import_job_bridge).pack(side="left", padx=4, pady=8)
            self.ttk.Button(f, text="Create Job Quote", command=self.gui_create_job_quote).pack(side="left", padx=4, pady=8)
            self.ttk.Button(f, text="Export Job Bridge", command=self.gui_export_job_bridge).pack(side="left", padx=4, pady=8)
            for label, path in [
                ("Contacts Folder", CONTACTS_BRIDGE_DIR),
                ("Inventory Bridge", INVENTORY_BRIDGE_DIR),
                ("Jobs Bridge", JOBS_BRIDGE_DIR),
                ("Documents Folder", DOCUMENTS_ROOT),
            ]:
                self.ttk.Button(f, text=label, command=lambda p=path: self.open_path(p)).pack(side="left", padx=4, pady=8)

        def make_aegis_tab(self) -> None:
            f = self.ribbon_frame("AEGIS")
            self.ttk.Button(f, text="Write Status JSON", command=self.gui_write_aegis_files).pack(side="left", padx=4, pady=8)
            self.ttk.Button(f, text="Show Health", command=self.show_health).pack(side="left", padx=4, pady=8)
            self.ttk.Button(f, text="Capabilities", command=self.show_aegis_capabilities).pack(side="left", padx=4, pady=8)
            self.ttk.Button(f, text="Export Vault Metadata", command=self.gui_export_vault_metadata).pack(side="left", padx=4, pady=8)
            self.ttk.Button(f, text="Safe Read Current", command=self.gui_safe_read_current).pack(side="left", padx=4, pady=8)
            self.ttk.Button(f, text="Open AEGIS Folder", command=lambda: self.open_path(AEGIS_DIR)).pack(side="left", padx=4, pady=8)
            self.ttk.Label(f, text="AEGIS can read status/actions/capabilities and Vault-ready metadata without silent control.", style="Panel.TLabel").pack(side="left", padx=12)


        def make_recovery_tab(self) -> None:
            f = self.ribbon_frame("Recovery")
            self.ttk.Button(f, text="Backup Now", command=self.gui_backup_now).pack(side="left", padx=4, pady=8)
            self.ttk.Button(f, text="Verify DB", command=self.gui_verify_db).pack(side="left", padx=4, pady=8)
            self.ttk.Button(f, text="Repair DB", command=self.gui_repair_db).pack(side="left", padx=4, pady=8)
            self.ttk.Button(f, text="Export Library", command=self.gui_export_library).pack(side="left", padx=4, pady=8)
            self.ttk.Button(f, text="Recovery Report", command=self.gui_recovery_report).pack(side="left", padx=4, pady=8)
            self.ttk.Button(f, text="Open Backups", command=lambda: self.open_path(BACKUP_DIR)).pack(side="left", padx=4, pady=8)
            self.ttk.Button(f, text="Repair Launcher", command=self.gui_repair_launcher).pack(side="left", padx=4, pady=8)
            self.ttk.Label(f, text="Local backup/restore/recovery tools. Restore/import are CLI-first for safer review.", style="Panel.TLabel").pack(side="left", padx=12)

        def make_audit_tab(self) -> None:
            f = self.ribbon_frame("Audit")
            self.ttk.Button(f, text="V1 Audit JSON", command=self.gui_rc_audit).pack(side="left", padx=4, pady=8)
            self.ttk.Button(f, text="Write V1 Audit Report", command=self.gui_release_candidate_report).pack(side="left", padx=4, pady=8)
            self.ttk.Button(f, text="Show Actions", command=lambda: self.show_text_popup("AEGIS Actions JSON", json.dumps(aegis_actions_json(), indent=2))).pack(side="left", padx=4, pady=8)
            self.ttk.Button(f, text="Show Capabilities", command=self.show_aegis_capabilities).pack(side="left", padx=4, pady=8)
            self.ttk.Label(f, text="V1 stable-lock readiness checks. This is local-only and does not contact the network.", style="Panel.TLabel").pack(side="left", padx=12)

        def make_export_tab(self) -> None:
            f = self.ribbon_frame("Export")
            self.ttk.Button(f, text="Export Current...", command=self.gui_export_current).pack(side="left", padx=4, pady=8)
            self.ttk.Button(f, text="Save As / Choose Format", command=self.save_as_document).pack(side="left", padx=4, pady=8)
            self.ttk.Button(f, text="Open PDF/Text File", command=self.open_document_dialog).pack(side="left", padx=4, pady=8)
            self.ttk.Button(f, text="Open in LibreOffice", command=self.gui_open_in_libreoffice).pack(side="left", padx=4, pady=8)
            self.ttk.Button(f, text="LibreOffice Status", command=self.gui_libreoffice_status).pack(side="left", padx=4, pady=8)
            self.ttk.Button(f, text="Open Exports Folder", command=lambda: self.open_path(EXPORTS_DIR)).pack(side="left", padx=4, pady=8)
            self.ttk.Label(f, text="Exports: MD, TXT, HTML, PDF text-layer, ODT text, DOCX text. LibreOffice handoff is optional and explicit.", style="Panel.TLabel").pack(side="left", padx=12)

        def make_help_tab(self) -> None:
            f = self.ribbon_frame("Help")
            self.ttk.Button(f, text="About", command=self.show_about).pack(side="left", padx=4, pady=8)
            self.ttk.Button(f, text="Print Paths", command=self.show_paths).pack(side="left", padx=4, pady=8)

        def right_info_text(self) -> str:
            return (
                f"Current ID: {self.current_doc_id or 'new / unsaved'}\n"
                f"AEGIS: ready\n"
                f"Vault metadata: ready/exportable\n"
                f"Storage: local only\n"
                f"Format: Markdown/TXT/HTML/PDF/ODT/DOCX export + LibreOffice handoff\n"
                f"Search: metadata/content filters + archive restore\n"
                f"Formatting: font + paragraph controls + right-click hot menu\n"
                f"Recovery: backup/verify/repair/export ready\n"
                f"Audit: RC/v1 readiness checks ready"
            )

        def update_info(self) -> None:
            self.info_label.configure(text=self.right_info_text())

        def ask_save_if_dirty(self) -> bool:
            if not self.dirty:
                return True
            ans = self.messagebox.askyesnocancel("Unsaved changes", "Save the current document before continuing?")
            if ans is None:
                return False
            if ans:
                return self.save_document()
            return True

        def new_document(self, initial: bool = False) -> None:
            if not initial and not self.ask_save_if_dirty():
                return
            self.current_doc_id = None
            self.var_title.set("Untitled Document")
            self.var_category.set("General")
            self.var_doc_type.set("Document")
            self.var_contact.set("")
            self.var_job.set("")
            self.var_inventory.set("")
            self.text.delete("1.0", "end")
            self.text.insert("1.0", "# Untitled Document\n\n")
            self.dirty = False
            self.text.edit_modified(False)
            self.var_status.set("New local document")
            self.update_info()

        def save_document(self) -> bool:
            title = self.var_title.get().strip() or "Untitled Document"
            content = self.text.get("1.0", "end-1c")
            options = self.prompt_save_options(title)
            if not options:
                return False
            title = options["title"]
            self.var_title.set(title)
            doc_id = upsert_document(
                doc_id=self.current_doc_id,
                title=title,
                content=content,
                category=self.var_category.get(),
                doc_type=self.var_doc_type.get(),
                linked_contact_code=self.var_contact.get().strip() or None,
                linked_job_code=self.var_job.get().strip() or None,
                linked_inventory_code=self.var_inventory.get().strip() or None,
                output_path=options["path"],
                save_format=options["format"],
            )
            self.current_doc_id = doc_id
            self.save_current_document_style(doc_id)
            self.dirty = False
            self.text.edit_modified(False)
            self.var_status.set(f"Saved {title} as {options['format']} ({doc_id})")
            self.load_document_list(select_id=doc_id)
            self.update_info()
            return True

        def save_as_document(self) -> bool:
            old_id = self.current_doc_id
            self.current_doc_id = None
            ok = self.save_document()
            if not ok:
                self.current_doc_id = old_id
            return ok

        def prompt_save_options(self, default_title: str) -> Optional[Dict[str, str]]:
            dialog = self.tk.Toplevel(self.root)
            dialog.title("Save Sentinel Document")
            dialog.configure(bg=self.colors["panel"])
            dialog.transient(self.root)
            dialog.grab_set()
            result: Dict[str, str] = {}
            title_var = self.tk.StringVar(value=default_title or "Untitled Document")
            fmt_var = self.tk.StringVar(value="markdown")
            location_names = ["Documents"]
            if AEGIS_VAULT_ROOT.exists():
                location_names.append("AEGIS Vault")
            location_names.append("Custom")
            loc_var = self.tk.StringVar(value="Documents")
            folder_var = self.tk.StringVar(value=str(DOCUMENTS_DIR))

            def sync_location(*args: Any) -> None:
                if loc_var.get() == "Documents":
                    folder_var.set(str(DOCUMENTS_DIR))
                elif loc_var.get() == "AEGIS Vault":
                    folder_var.set(str(AEGIS_VAULT_DOCUMENTS_DIR))
            def browse() -> None:
                chosen = self.filedialog.askdirectory(title="Choose save folder", initialdir=folder_var.get() or str(DOCUMENTS_DIR))
                if chosen:
                    loc_var.set("Custom")
                    folder_var.set(chosen)
            loc_var.trace_add("write", sync_location)

            def row(label: str, widget: Any, r: int) -> None:
                self.ttk.Label(dialog, text=label, style="Panel.TLabel").grid(row=r, column=0, padx=12, pady=8, sticky="w")
                widget.grid(row=r, column=1, padx=12, pady=8, sticky="ew")
            row("File name", self.ttk.Entry(dialog, textvariable=title_var, width=42), 0)
            row("Save location", self.ttk.Combobox(dialog, textvariable=loc_var, values=location_names, state="readonly", width=24), 1)
            folder_entry = self.ttk.Entry(dialog, textvariable=folder_var, width=42)
            row("Folder", folder_entry, 2)
            self.ttk.Button(dialog, text="Browse", command=browse).grid(row=2, column=2, padx=12, pady=8)
            row("Format", self.ttk.Combobox(dialog, textvariable=fmt_var, values=list(SAVE_FORMATS.keys()), state="readonly", width=24), 3)
            info = "Choose the name, folder, and format. AEGIS Vault appears when ~/AEGIS_Vault is installed."
            self.ttk.Label(dialog, text=info, style="Panel.TLabel", wraplength=420).grid(row=4, column=0, columnspan=3, padx=12, pady=(2, 8), sticky="w")
            buttons = self.ttk.Frame(dialog, style="Panel.TFrame")
            buttons.grid(row=5, column=0, columnspan=3, sticky="e", padx=12, pady=12)
            def ok() -> None:
                title = title_var.get().strip() or "Untitled Document"
                fmt = normalise_save_format(fmt_var.get())
                folder = Path(folder_var.get()).expanduser()
                path = ensure_extension(folder / safe_slug(title), fmt)
                result.update({"title": title, "format": fmt, "path": str(path)})
                dialog.destroy()
            def cancel() -> None:
                dialog.destroy()
            self.ttk.Button(buttons, text="Cancel", command=cancel).pack(side="right", padx=4)
            self.ttk.Button(buttons, text="Save", command=ok).pack(side="right", padx=4)
            dialog.columnconfigure(1, weight=1)
            self.root.wait_window(dialog)
            return result or None

        def open_document_dialog(self) -> None:
            if not self.ask_save_if_dirty():
                return
            path_str = self.filedialog.askopenfilename(
                title="Open Sentinel document / PDF",
                initialdir=str(DOCUMENTS_DIR),
                filetypes=[("Supported documents", "*.md *.txt *.html *.htm *.pdf *.odt *.docx"), ("PDF files", "*.pdf"), ("Office text files", "*.odt *.docx"), ("Text files", "*.md *.txt"), ("All files", "*.*")],
            )
            if not path_str:
                return
            path = Path(path_str)
            try:
                content, fmt = read_external_document_file(path)
                self.current_doc_id = None
                self.var_title.set(path.stem)
                self.var_doc_type.set("PDF Text Edit" if fmt == "pdf_text" else "Document")
                self.var_category.set("Imported")
                self.text.delete("1.0", "end")
                self.text.insert("1.0", content)
                self.dirty = True
                self.text.edit_modified(False)
                if fmt == "pdf_text":
                    self.var_status.set("Opened PDF text layer for editing. Save writes a new text-layer PDF or chosen format.")
                else:
                    self.var_status.set(f"Opened {path.name}")
                self.update_info()
            except Exception as exc:
                self.messagebox.showerror("Open document", str(exc))

        def load_document_list(self, select_id: Optional[str] = None) -> None:
            self.documents = list_documents(include_archived=False)
            tree = getattr(self, "doc_tree", None)
            if tree is None:
                return
            search = self.var_search.get().strip().lower()
            for item in tree.get_children():
                tree.delete(item)
            for doc in self.documents:
                if search and search not in doc["title"].lower() and search not in doc["category"].lower():
                    continue
                iid = doc["id"]
                tree.insert("", "end", iid=iid, text=doc["title"], values=(doc["category"],))
            if select_id and tree.exists(select_id):
                tree.selection_set(select_id)
                tree.see(select_id)

        def on_tree_select(self, event: Any) -> None:
            if getattr(self, "doc_tree", None) is None:
                return
            selection = self.doc_tree.selection()
            if not selection:
                return
            doc_id = selection[0]
            if doc_id == self.current_doc_id:
                return
            if not self.ask_save_if_dirty():
                return
            doc = get_document(doc_id)
            if not doc:
                return
            content = read_document_text(doc_id) or ""
            self.current_doc_id = doc_id
            self.var_title.set(doc.get("title", "Untitled"))
            self.var_category.set(doc.get("category", "General"))
            self.var_doc_type.set(doc.get("doc_type", "Document"))
            self.var_contact.set(doc.get("linked_contact_code") or "")
            self.var_job.set(doc.get("linked_job_code") or "")
            self.var_inventory.set(doc.get("linked_inventory_code") or "")
            self.text.delete("1.0", "end")
            self.text.insert("1.0", content)
            self.dirty = False
            self.text.edit_modified(False)
            self.var_status.set(f"Loaded {doc.get('title')} ({doc_id})")
            self.update_info()

        def archive_current_document(self) -> None:
            if not self.current_doc_id:
                self.messagebox.showinfo("Archive", "This document has not been saved yet.")
                return
            if not self.messagebox.askyesno("Archive document", "Archive this document from the active library?"):
                return
            if archive_document(self.current_doc_id):
                self.var_status.set("Document archived")
                self.current_doc_id = None
                self.load_document_list()
                self.new_document(initial=True)

        def on_text_modified(self, event: Any) -> None:
            if self.text.edit_modified():
                self.dirty = True
                self.var_status.set("Unsaved changes")
                self.text.edit_modified(False)

        def wrap_selection(self, prefix: str, suffix: str) -> None:
            """Legacy Markdown-wrapper helper retained for non-rich marker actions."""
            try:
                start = self.text.index("sel.first")
                end = self.text.index("sel.last")
                selected = self.text.get(start, end)
                self.text.delete(start, end)
                self.text.insert(start, f"{prefix}{selected}{suffix}")
                self.text.tag_add("sel", start, f"{start}+{len(prefix + selected + suffix)}c")
                self.dirty = True
            except Exception:
                self.insert_text(prefix + suffix)

        def maximize_default_window(self) -> None:
            """Open maximized by default on MATE/Marco/X11, with geometry fallback."""
            try:
                self.root.state("zoomed")
                return
            except Exception:
                pass
            try:
                self.root.attributes("-zoomed", True)
                return
            except Exception:
                pass
            try:
                width = max(1360, int(self.root.winfo_screenwidth()))
                height = max(860, int(self.root.winfo_screenheight()) - 32)
                self.root.geometry(f"{width}x{height}+0+0")
            except Exception:
                self.root.geometry("1360x860")

        def setup_inline_format_tags(self) -> None:
            """Configure in-editor rich display tags for Office-familiar bold/italic use."""
            if not getattr(self, "text", None):
                return
            family = str(self.var_font_family.get() or "Sans")
            size = max(8, min(50, int(self.var_font_size.get() or 12)))
            try:
                self.text.tag_configure("fmt_bold", font=(family, size, "bold"))
                self.text.tag_configure("fmt_italic", font=(family, size, "italic"))
                self.text.tag_configure("fmt_bold_italic", font=(family, size, "bold italic"))
                self.text.tag_configure("fmt_underline", underline=True)
                self.text.tag_configure("fmt_strike", overstrike=True)
                self.text.tag_configure("fmt_highlight", background=self.colors["select_bg"], foreground=self.colors["select_fg"])
            except Exception:
                # Fall back to base-font-safe tags if a selected system font rejects a style tuple.
                self.text.tag_configure("fmt_bold", font=("Sans", size, "bold"))
                self.text.tag_configure("fmt_italic", font=("Sans", size, "italic"))
                self.text.tag_configure("fmt_bold_italic", font=("Sans", size, "bold italic"))

        def selected_inline_flags(self, start: str) -> Tuple[bool, bool]:
            tags = set(self.text.tag_names(start))
            bold = "fmt_bold" in tags or "fmt_bold_italic" in tags
            italic = "fmt_italic" in tags or "fmt_bold_italic" in tags
            return bold, italic

        def toggle_inline_style(self, style: str) -> None:
            """Toggle visual rich bold/italic on highlighted text, preserving selection across buttons."""
            try:
                start = self.text.index("sel.first")
                end = self.text.index("sel.last")
            except Exception:
                # No selection: insert useful Markdown marker fallback and place cursor inside.
                if style == "bold":
                    self.text.insert("insert", "****")
                    self.text.mark_set("insert", "insert-2c")
                    self.var_status.set("Bold marker inserted; type between the asterisks")
                elif style == "italic":
                    self.text.insert("insert", "**")
                    self.text.mark_set("insert", "insert-1c")
                    self.var_status.set("Italic marker inserted; type between the asterisks")
                self.dirty = True
                self.text.focus_set()
                return
            bold, italic = self.selected_inline_flags(start)
            if style == "bold":
                bold = not bold
            elif style == "italic":
                italic = not italic
            for tag in ("fmt_bold", "fmt_italic", "fmt_bold_italic"):
                self.text.tag_remove(tag, start, end)
            if bold and italic:
                self.text.tag_add("fmt_bold_italic", start, end)
                label = "bold + italic"
            elif bold:
                self.text.tag_add("fmt_bold", start, end)
                label = "bold"
            elif italic:
                self.text.tag_add("fmt_italic", start, end)
                label = "italic"
            else:
                label = "plain"
            self.text.tag_add("sel", start, end)
            self.dirty = True
            self.text.focus_set()
            self.var_status.set(f"Selection formatting applied: {label}")

        def toggle_text_decoration(self, tag: str, label: str, fallback_prefix: str = "", fallback_suffix: str = "") -> None:
            try:
                start = self.text.index("sel.first")
                end = self.text.index("sel.last")
                midpoint_tags = set(self.text.tag_names(start))
                if tag in midpoint_tags:
                    self.text.tag_remove(tag, start, end)
                    state = "removed"
                else:
                    self.text.tag_add(tag, start, end)
                    state = "applied"
                self.text.tag_add("sel", start, end)
                self.dirty = True
                self.text.focus_set()
                self.var_status.set(f"{label} {state}")
            except Exception:
                if fallback_prefix or fallback_suffix:
                    self.wrap_selection(fallback_prefix, fallback_suffix)

        def show_context_menu_help(self) -> None:
            self.messagebox.showinfo(
                "Right-click formatting menu",
                "Right-click inside the editor to open the Sentinel hot menu.\n\n"
                "With highlighted text you can apply Bold, Italic, Underline, Strikethrough, Inline Code, Highlight markers, Quote, headings, lists, and paragraph alignment.\n\n"
                "The Font menu opens a scrollable searchable font picker, so large local font libraries remain usable. Size, Line Spacing, and Paragraph Spacing update the current Sentinel editor/document style and are saved to the .sentinel-style.json sidecar when the document is saved."
            )

        def text_has_selection(self) -> bool:
            try:
                return bool(self.text.tag_ranges("sel"))
            except Exception:
                return False

        def text_context_menu_colors(self) -> Dict[str, str]:
            return {
                "bg": self.colors["panel2"],
                "fg": self.colors["text"],
                "activebackground": self.colors["panel3"],
                "activeforeground": self.colors["active_fg"],
                "selectcolor": self.colors["cyan"],
            }

        def make_text_menu(self, parent: Any = None) -> Any:
            colours = self.text_context_menu_colors()
            return self.tk.Menu(
                parent or self.root,
                tearoff=0,
                bg=colours["bg"],
                fg=colours["fg"],
                activebackground=colours["activebackground"],
                activeforeground=colours["activeforeground"],
                selectcolor=colours["selectcolor"],
                borderwidth=1,
                relief="solid",
            )

        def add_context_submenu(self, menu: Any, label: str) -> Any:
            submenu = self.make_text_menu(menu)
            menu.add_cascade(label=label, menu=submenu)
            return submenu

        def show_text_context_menu(self, event: Any = None) -> str:
            try:
                if event is not None and hasattr(event, "x") and not self.text_has_selection():
                    self.text.mark_set("insert", f"@{event.x},{event.y}")
                    self.text.focus_set()
            except Exception:
                pass
            menu = self.build_text_context_menu()
            try:
                if event is not None and hasattr(event, "x_root") and hasattr(event, "y_root"):
                    x_root, y_root = int(event.x_root), int(event.y_root)
                else:
                    bbox = self.text.bbox("insert")
                    if bbox:
                        x, y, _w, h = bbox
                        x_root = self.text.winfo_rootx() + x
                        y_root = self.text.winfo_rooty() + y + h
                    else:
                        x_root = self.root.winfo_pointerx()
                        y_root = self.root.winfo_pointery()
                menu.tk_popup(x_root, y_root)
            finally:
                try:
                    menu.grab_release()
                except Exception:
                    pass
            return "break"

        def build_text_context_menu(self) -> Any:
            menu = self.make_text_menu()
            has_sel = self.text_has_selection()
            menu.add_command(label="Cut", command=lambda: self.text.event_generate("<<Cut>>"), state=("normal" if has_sel else "disabled"))
            menu.add_command(label="Copy", command=lambda: self.text.event_generate("<<Copy>>"), state=("normal" if has_sel else "disabled"))
            menu.add_command(label="Paste", command=lambda: self.text.event_generate("<<Paste>>"))
            menu.add_separator()
            menu.add_command(label="Select All    Ctrl+A", command=lambda: self.select_all(None))
            menu.add_command(label="Open Format Ribbon", command=lambda: self.ribbon.select(1))
            menu.add_separator()

            fmt = self.add_context_submenu(menu, "Format Selection")
            fmt.add_command(label="Bold    Ctrl+B", command=lambda: self.toggle_inline_style("bold"))
            fmt.add_command(label="Italic    Ctrl+I", command=lambda: self.toggle_inline_style("italic"))
            fmt.add_command(label="Underline    Ctrl+U", command=lambda: self.toggle_text_decoration("fmt_underline", "Underline", "__", "__"))
            fmt.add_command(label="Strikethrough", command=lambda: self.toggle_text_decoration("fmt_strike", "Strikethrough", "~~", "~~"))
            fmt.add_command(label="Inline Code", command=lambda: self.wrap_selection("`", "`"))
            fmt.add_command(label="Highlight", command=lambda: self.toggle_text_decoration("fmt_highlight", "Highlight", "==", "=="))
            fmt.add_command(label="Clear Markdown Wrappers", command=self.clear_selection_markdown_wrappers)

            paragraph = self.add_context_submenu(menu, "Paragraph")
            paragraph.add_command(label="Align Left", command=lambda: self.apply_paragraph_alignment("left"))
            paragraph.add_command(label="Align Center", command=lambda: self.apply_paragraph_alignment("center"))
            paragraph.add_command(label="Align Right", command=lambda: self.apply_paragraph_alignment("right"))
            paragraph.add_separator()
            paragraph.add_command(label="Heading 1", command=lambda: self.apply_line_style("h1"))
            paragraph.add_command(label="Heading 2", command=lambda: self.apply_line_style("h2"))
            paragraph.add_command(label="Normal", command=lambda: self.apply_line_style("normal"))
            paragraph.add_command(label="Quote", command=lambda: self.apply_line_style("quote"))
            paragraph.add_command(label="Bulleted List", command=self.insert_bullets)
            paragraph.add_command(label="Numbered List", command=self.insert_numbered_list)

            font_menu = self.add_context_submenu(menu, "Font")
            current_font = str(self.var_font_family.get() or "Sans")
            font_menu.add_command(label=f"Current: {current_font}", state="disabled")
            font_menu.add_command(label="Choose Font...    Scrollable", command=lambda: self.show_font_picker(source="context"))
            font_menu.add_command(label="Refresh Fonts", command=self.refresh_font_choices)
            font_menu.add_separator()
            for family in self.quick_font_choices():
                font_menu.add_command(label=family, command=lambda fam=family: self.context_set_font_family(fam))

            size_menu = self.add_context_submenu(menu, "Font Size")
            for size in [8, 10, 11, 12, 14, 16, 18, 20, 24, 28, 32, 36, 42, 48, 50]:
                size_menu.add_command(label=f"{size} pt", command=lambda value=size: self.context_set_font_size(value))

            spacing_menu = self.add_context_submenu(menu, "Spacing")
            spacing_menu.add_command(label="Compact", command=lambda: self.context_set_spacing(1, 3, "compact"))
            spacing_menu.add_command(label="Normal", command=lambda: self.context_set_spacing(4, 8, "normal"))
            spacing_menu.add_command(label="Relaxed", command=lambda: self.context_set_spacing(8, 14, "relaxed"))
            spacing_menu.add_command(label="Wide", command=lambda: self.context_set_spacing(12, 22, "wide"))

            menu.add_separator()
            menu.add_command(label="Save Current Formatting", command=lambda: self.apply_document_formatting(save=True))
            return menu

        def quick_font_choices(self, limit: int = 28) -> List[str]:
            """Return a compact set of useful fonts for native menus.

            Native Tk menus do not provide reliable scrollbar support across desktops,
            so the right-click menu launches a proper scrollable picker for the full
            discovered library and keeps this submenu intentionally compact.
            """
            current = str(self.var_font_family.get() or "Sans")
            preferred = [
                current,
                "Sans", "Serif", "Monospace", "Arial", "Calibri", "Carlito",
                "Times New Roman", "Liberation Serif", "Liberation Sans",
                "Liberation Mono", "DejaVu Sans", "DejaVu Serif", "DejaVu Sans Mono",
                "Noto Sans", "Noto Serif", "Ubuntu", "Cantarell",
            ]
            out: List[str] = []
            seen = set()
            available = {name.casefold(): name for name in self.font_family_choices}
            for name in preferred:
                if not name:
                    continue
                resolved = available.get(str(name).casefold(), str(name))
                key = resolved.casefold()
                if key not in seen:
                    out.append(resolved)
                    seen.add(key)
            for name in self.font_family_choices:
                key = str(name).casefold()
                if key not in seen:
                    out.append(str(name))
                    seen.add(key)
                if len(out) >= limit:
                    break
            return out[:limit]

        def show_font_picker(self, source: str = "format") -> None:
            """Open a themed, scrollable font picker for large local font libraries."""
            try:
                if not self.font_family_choices:
                    self.refresh_font_choices()
                popup = self.tk.Toplevel(self.root)
                popup.title("Sentinel Documents — Font Picker")
                popup.configure(bg=self.colors["panel"])
                popup.geometry("520x560")
                popup.minsize(420, 360)
                popup.transient(self.root)

                outer = self.ttk.Frame(popup, style="Panel.TFrame")
                outer.pack(fill="both", expand=True, padx=12, pady=12)
                self.ttk.Label(
                    outer,
                    text="Choose Font",
                    style="Gold.TLabel",
                ).pack(anchor="w", pady=(0, 6))
                self.ttk.Label(
                    outer,
                    text=f"{len(self.font_family_choices)} local font families available. Type to filter, scroll to browse, double-click or Apply to use.",
                    style="Muted.TLabel",
                    wraplength=470,
                ).pack(anchor="w", pady=(0, 8))

                search_var = self.tk.StringVar()
                search_entry = self.ttk.Entry(outer, textvariable=search_var)
                search_entry.pack(fill="x", pady=(0, 8))

                list_frame = self.ttk.Frame(outer, style="Panel.TFrame")
                list_frame.pack(fill="both", expand=True)
                yscroll = self.ttk.Scrollbar(list_frame, orient="vertical")
                xscroll = self.ttk.Scrollbar(list_frame, orient="horizontal")
                listbox = self.tk.Listbox(
                    list_frame,
                    activestyle="dotbox",
                    bg=self.colors.get("page", self.colors.get("panel", "#0b1118")),
                    fg=self.colors.get("page_text", self.colors.get("text", "#d6e1ea")),
                    selectbackground=self.colors.get("select_bg", self.colors.get("cyan", "#005f73")),
                    selectforeground=self.colors.get("select_fg", "#ffffff"),
                    highlightthickness=1,
                    highlightbackground=self.colors.get("border", self.colors.get("panel3", "#253744")),
                    relief="flat",
                    exportselection=False,
                    yscrollcommand=yscroll.set,
                    xscrollcommand=xscroll.set,
                )
                yscroll.configure(command=listbox.yview)
                xscroll.configure(command=listbox.xview)
                listbox.grid(row=0, column=0, sticky="nsew")
                yscroll.grid(row=0, column=1, sticky="ns")
                xscroll.grid(row=1, column=0, sticky="ew")
                list_frame.grid_rowconfigure(0, weight=1)
                list_frame.grid_columnconfigure(0, weight=1)

                preview = self.tk.Label(
                    outer,
                    text="The quick brown fox jumps over the lazy dog — 0123456789",
                    bg=self.colors["panel2"],
                    fg=self.colors["text"],
                    anchor="w",
                    padx=8,
                    pady=8,
                )
                preview.pack(fill="x", pady=(8, 0))

                state = {"filtered": list(self.font_family_choices)}

                def populate(names: List[str]) -> None:
                    listbox.delete(0, "end")
                    for name in names:
                        listbox.insert("end", name)
                    current = str(self.var_font_family.get() or "")
                    for i, name in enumerate(names):
                        if name.casefold() == current.casefold():
                            listbox.selection_set(i)
                            listbox.see(i)
                            break

                def selected_font() -> Optional[str]:
                    selection = listbox.curselection()
                    if not selection:
                        return None
                    return str(listbox.get(selection[0]))

                def update_preview(_event: Any = None) -> None:
                    name = selected_font() or str(self.var_font_family.get() or "Sans")
                    try:
                        preview.configure(font=(name, max(8, min(50, int(self.var_font_size.get() or 12)))))
                    except Exception:
                        pass

                def filter_fonts(*_args: Any) -> None:
                    query = search_var.get().strip().casefold()
                    if query:
                        state["filtered"] = [name for name in self.font_family_choices if query in name.casefold()]
                    else:
                        state["filtered"] = list(self.font_family_choices)
                    populate(state["filtered"])
                    update_preview()

                def apply_selected(close: bool = True) -> None:
                    family = selected_font()
                    if not family and state["filtered"]:
                        family = state["filtered"][0]
                    if family:
                        self.context_set_font_family(family)
                        if getattr(self, "font_combo", None) is not None:
                            self.font_combo.set(family)
                        if close:
                            popup.destroy()

                def refresh_and_repopulate() -> None:
                    self.refresh_font_choices()
                    filter_fonts()

                search_var.trace_add("write", filter_fonts)
                listbox.bind("<<ListboxSelect>>", update_preview)
                listbox.bind("<Double-Button-1>", lambda _e: apply_selected(close=True))
                popup.bind("<Return>", lambda _e: apply_selected(close=True))
                popup.bind("<Escape>", lambda _e: popup.destroy())

                buttons = self.ttk.Frame(outer, style="Panel.TFrame")
                buttons.pack(fill="x", pady=(10, 0))
                self.ttk.Button(buttons, text="Apply", command=lambda: apply_selected(close=True)).pack(side="right", padx=4)
                self.ttk.Button(buttons, text="Preview", command=update_preview).pack(side="right", padx=4)
                self.ttk.Button(buttons, text="Refresh Fonts", command=refresh_and_repopulate).pack(side="left", padx=4)
                self.ttk.Button(buttons, text="Cancel", command=popup.destroy).pack(side="right", padx=4)

                populate(state["filtered"])
                update_preview()
                search_entry.focus_set()
                self.var_status.set(f"Scrollable font picker opened from {source}: {len(self.font_family_choices)} fonts")
            except Exception as exc:
                self.messagebox.showerror("Font picker", f"Could not open font picker:\n{exc}")

        def refresh_font_choices(self) -> None:
            try:
                self.font_family_choices = resolve_gui_font_families(__import__("tkinter.font").font, self.root)
                current = str(self.var_font_family.get() or "Sans")
                if current.casefold() not in {name.casefold() for name in self.font_family_choices}:
                    self.font_family_choices.insert(0, current)
                if getattr(self, "font_combo", None) is not None:
                    self.font_combo.configure(values=self.font_family_choices)
                self.var_status.set(f"Font list refreshed: {len(self.font_family_choices)} families available")
            except Exception as exc:
                self.var_status.set(f"Font refresh failed: {exc}")

        def context_set_font_family(self, family: str) -> None:
            self.var_font_family.set(family)
            self.apply_document_formatting(save=True)
            self.var_status.set(f"Font family applied from context menu: {family}")

        def context_set_font_size(self, size: int) -> None:
            self.var_font_size.set(max(8, min(50, int(size))))
            self.apply_document_formatting(save=True)
            self.var_status.set(f"Font size applied from context menu: {self.var_font_size.get()} pt")

        def context_set_spacing(self, line_spacing: int, paragraph_spacing: int, label: str) -> None:
            self.var_line_spacing.set(max(0, min(24, int(line_spacing))))
            self.var_paragraph_spacing.set(max(0, min(36, int(paragraph_spacing))))
            self.apply_document_formatting(save=True)
            self.var_status.set(f"Spacing applied from context menu: {label}")

        def clear_selection_markdown_wrappers(self) -> None:
            try:
                if self.text_has_selection():
                    start = self.text.index("sel.first")
                    end = self.text.index("sel.last")
                else:
                    start, end = self.current_line_range()
                selected = self.text.get(start, end)
                cleaned = selected
                # Remove common Markdown/HTML-helper wrappers used by the Sentinel formatting controls.
                cleaned = re.sub(r"^([ \t]*)(#{1,6}\s+|>\s+|\d+\.\s+|-\s+)", r"\1", cleaned, flags=re.MULTILINE)
                for token in ["**", "__", "~~", "==", "`"]:
                    cleaned = cleaned.replace(token, "")
                self.text.delete(start, end)
                self.text.insert(start, cleaned)
                self.dirty = True
                self.var_status.set("Markdown helper formatting cleared")
            except Exception:
                self.var_status.set("No selectable formatting found to clear")

        def insert_text(self, text: str) -> None:
            self.text.insert("insert", text)
            self.dirty = True

        def insert_bullets(self) -> None:
            self.insert_text("\n- Item 1\n- Item 2\n- Item 3\n")

        def insert_date(self) -> None:
            self.insert_text(datetime.now().strftime("%Y-%m-%d"))

        def insert_table_stub(self) -> None:
            self.insert_text("\n| Item | Details | Notes |\n|---|---|---|\n|  |  |  |\n")

        def insert_signature(self) -> None:
            self.insert_text("\n\nRegards,\n\n____________________________\n")

        def apply_font_size(self) -> None:
            self.apply_document_formatting(save=True, announce=False)

        def current_format_prefs(self) -> Dict[str, Any]:
            return {
                "font_family": self.var_font_family.get().strip() or "Sans",
                "font_size": int(self.var_font_size.get() or 12),
                "paragraph_align": self.var_paragraph_align.get().strip() or "left",
                "line_spacing": int(self.var_line_spacing.get() or 4),
                "paragraph_spacing": int(self.var_paragraph_spacing.get() or 8),
            }

        def apply_document_formatting(self, event: Any = None, save: bool = True, announce: bool = True) -> None:
            prefs = save_gui_format(self.current_format_prefs()) if save else self.current_format_prefs()
            self.var_font_family.set(str(prefs.get("font_family", "Sans")))
            self.var_font_size.set(int(prefs.get("font_size", 12)))
            self.var_paragraph_align.set(str(prefs.get("paragraph_align", "left")))
            self.var_line_spacing.set(int(prefs.get("line_spacing", 4)))
            self.var_paragraph_spacing.set(int(prefs.get("paragraph_spacing", 8)))
            self.apply_scale_settings(save=False, announce=False)
            if self.text is not None:
                self.text.configure(
                    spacing2=int(self.var_line_spacing.get()),
                    spacing3=int(self.var_paragraph_spacing.get()),
                )
                for align in PARAGRAPH_ALIGN_CHOICES:
                    self.text.tag_configure(f"align_{align}", justify=align)
            self.setup_inline_format_tags()
            if announce:
                self.var_status.set(f"Format applied: {self.var_font_family.get()} {self.var_font_size.get()}pt / paragraph {self.var_paragraph_align.get()}")

        def current_line_range(self) -> Tuple[str, str]:
            try:
                if self.text.tag_ranges("sel"):
                    return self.text.index("sel.first linestart"), self.text.index("sel.last lineend +1c")
            except Exception:
                pass
            return self.text.index("insert linestart"), self.text.index("insert lineend +1c")

        def apply_paragraph_alignment(self, align: str) -> None:
            if align not in PARAGRAPH_ALIGN_CHOICES:
                align = "left"
            self.var_paragraph_align.set(align)
            self.apply_document_formatting(save=True, announce=False)
            start, end = self.current_line_range()
            for tag in [f"align_{a}" for a in PARAGRAPH_ALIGN_CHOICES]:
                self.text.tag_remove(tag, start, end)
            self.text.tag_add(f"align_{align}", start, end)
            self.var_status.set(f"Paragraph alignment applied: {align}")

        def _selected_or_current_lines(self) -> Tuple[str, str, str]:
            start, end = self.current_line_range()
            text = self.text.get(start, end).rstrip("\n")
            return start, end, text

        def apply_line_style(self, style: str) -> None:
            start, end, text = self._selected_or_current_lines()
            lines = text.split("\n") if text else [""]
            cleaned = [re.sub(r"^\s*(#{1,6}\s+|>\s+|\d+\.\s+|-\s+)", "", line) for line in lines]
            if style == "h1":
                new = "\n".join("# " + line for line in cleaned)
            elif style == "h2":
                new = "\n".join("## " + line for line in cleaned)
            elif style == "quote":
                new = "\n".join("> " + line for line in cleaned)
            else:
                new = "\n".join(cleaned)
            self.text.delete(start, end)
            self.text.insert(start, new + "\n")
            self.dirty = True
            self.var_status.set(f"Line style applied: {style}")

        def insert_numbered_list(self) -> None:
            self.insert_text("\n1. First item\n2. Second item\n3. Third item\n")

        def save_current_document_style(self, doc_id: str) -> None:
            doc = get_document(doc_id)
            if not doc:
                return
            try:
                sidecar = write_document_style_sidecar(Path(doc["file_path"]), self.current_format_prefs(), doc_id=doc_id)
                self.var_status.set(f"Saved document style sidecar: {sidecar.name}")
            except Exception:
                pass

        def load_template(self) -> None:
            name = self.template_var.get().strip()
            path = TEMPLATES_DIR / name
            if not path.exists():
                self.messagebox.showerror("Template", "Template not found.")
                return
            if not self.ask_save_if_dirty():
                return
            self.current_doc_id = None
            self.text.delete("1.0", "end")
            self.text.insert("1.0", path.read_text(encoding="utf-8", errors="replace"))
            self.var_title.set(path.stem.replace("-", " ").title())
            self.var_category.set("Templates")
            self.dirty = True
            self.var_status.set(f"Loaded template: {name}")
            self.update_info()

        def draw_header_icon(self) -> None:
            if self.icon_box is None:
                return
            c = self.icon_box
            c.configure(bg=self.colors["panel2"])
            c.delete("all")
            c.create_rectangle(24, 16, 68, 64, outline=self.colors["gold"], width=4)
            c.create_line(34, 29, 59, 29, fill=self.colors["gold"], width=3)
            c.create_line(34, 41, 59, 41, fill=self.colors["gold"], width=3)
            c.create_line(34, 53, 54, 53, fill=self.colors["gold"], width=3)
            c.create_polygon(67, 35, 87, 45, 82, 69, 67, 79, 52, 69, 48, 45, outline=self.colors["cyan"], fill="", width=3)
            c.create_line(59, 57, 66, 65, 78, 49, fill=self.colors["cyan"], width=3)

        def make_dropdown_menu(self, parent: Any, label: str, items: List[Tuple[str, Any]]) -> Any:
            mb = self.tk.Menubutton(
                parent,
                text=label,
                bg=self.colors["menu"],
                fg=self.colors["text"],
                activebackground=self.colors["panel3"],
                activeforeground=self.colors["active_fg"],
                relief="flat",
                padx=10,
                pady=4,
            )
            menu = self.tk.Menu(
                mb,
                tearoff=0,
                bg=self.colors["panel2"],
                fg=self.colors["text"],
                activebackground=self.colors["panel3"],
                activeforeground=self.colors["active_fg"],
                borderwidth=0,
            )
            for text, cmd in items:
                menu.add_command(label=text, command=cmd)
            mb.configure(menu=menu)
            mb.pack(side="left")
            self.menu_widgets.append(mb)
            return mb

        def bind_hotkeys(self) -> None:
            bindings = {
                "<Control-a>": self.select_all,
                "<Control-A>": self.select_all,
                "<Control-s>": self.hotkey_save,
                "<Control-S>": self.hotkey_save,
                "<Control-Shift-S>": self.hotkey_save_as,
                "<Control-n>": self.hotkey_new,
                "<Control-N>": self.hotkey_new,
                "<Control-o>": self.hotkey_open,
                "<Control-O>": self.hotkey_open,
                "<Control-q>": self.hotkey_quit,
                "<Control-Q>": self.hotkey_quit,
                "<Control-f>": self.hotkey_focus_search,
                "<Control-F>": self.hotkey_focus_search,
                "<Control-b>": self.hotkey_bold,
                "<Control-B>": self.hotkey_bold,
                "<Control-i>": self.hotkey_italic,
                "<Control-I>": self.hotkey_italic,
                "<Control-u>": self.hotkey_underline,
                "<Control-U>": self.hotkey_underline,
                "<Control-plus>": self.hotkey_font_larger,
                "<Control-equal>": self.hotkey_font_larger,
                "<Control-minus>": self.hotkey_font_smaller,
                "<Control-Shift-Left>": lambda event: self.extend_selection_by_direction("left", event),
                "<Shift-Control-Left>": lambda event: self.extend_selection_by_direction("left", event),
                "<Control-Shift-Right>": lambda event: self.extend_selection_by_direction("right", event),
                "<Shift-Control-Right>": lambda event: self.extend_selection_by_direction("right", event),
                "<Control-Shift-Up>": lambda event: self.extend_selection_by_direction("up", event),
                "<Shift-Control-Up>": lambda event: self.extend_selection_by_direction("up", event),
                "<Control-Shift-Down>": lambda event: self.extend_selection_by_direction("down", event),
                "<Shift-Control-Down>": lambda event: self.extend_selection_by_direction("down", event),
            }
            for key, func in bindings.items():
                self.root.bind_all(key, func)

        def select_all(self, event: Any = None) -> str:
            widget = self.root.focus_get()
            try:
                if widget is self.text or widget.winfo_class() == "Text":
                    widget.tag_add("sel", "1.0", "end-1c")
                    widget.mark_set("insert", "1.0")
                    widget.see("insert")
                elif hasattr(widget, "selection_range"):
                    widget.selection_range(0, "end")
                    if hasattr(widget, "icursor"):
                        widget.icursor("end")
                elif self.text:
                    self.text.tag_add("sel", "1.0", "end-1c")
            except Exception:
                pass
            return "break"

        def hotkey_save(self, event: Any = None) -> str:
            self.save_document()
            return "break"

        def hotkey_save_as(self, event: Any = None) -> str:
            self.save_as_document()
            return "break"

        def hotkey_new(self, event: Any = None) -> str:
            self.new_document()
            return "break"

        def hotkey_open(self, event: Any = None) -> str:
            self.open_document_dialog()
            return "break"

        def hotkey_quit(self, event: Any = None) -> str:
            self.on_close()
            return "break"

        def focus_search(self) -> None:
            self.show_document_search()

        def hotkey_focus_search(self, event: Any = None) -> str:
            self.focus_search()
            return "break"

        def hotkey_bold(self, event: Any = None) -> str:
            self.toggle_inline_style("bold")
            return "break"

        def hotkey_italic(self, event: Any = None) -> str:
            self.toggle_inline_style("italic")
            return "break"

        def hotkey_underline(self, event: Any = None) -> str:
            self.toggle_text_decoration("fmt_underline", "Underline", "__", "__")
            return "break"

        def hotkey_font_larger(self, event: Any = None) -> str:
            self.var_font_size.set(min(50, int(self.var_font_size.get()) + 1))
            self.apply_font_size()
            return "break"

        def hotkey_font_smaller(self, event: Any = None) -> str:
            self.var_font_size.set(max(8, int(self.var_font_size.get()) - 1))
            self.apply_font_size()
            return "break"

        def extend_selection_by_direction(self, direction: str, event: Any = None) -> str:
            """Office-familiar Ctrl+Shift+Arrow selection inside the document editor.

            Left/right extend by word boundary. Up/down extend by line boundary, matching common
            document-editor expectations where vertical arrows extend selection vertically.
            """
            widget = self.root.focus_get()
            if widget is not self.text:
                return ""
            try:
                if not self.text.tag_ranges("sel") or "sentinel_sel_anchor" not in self.text.mark_names():
                    self.text.mark_set("sentinel_sel_anchor", "insert")
                anchor = self.text.index("sentinel_sel_anchor")
                insert = self.text.index("insert")
                if direction == "left":
                    current_word_start = self.text.index("insert wordstart")
                    if self.text.compare(insert, "==", current_word_start):
                        target = self.text.index("insert -1c wordstart")
                    else:
                        target = current_word_start
                elif direction == "right":
                    current_word_end = self.text.index("insert wordend")
                    if self.text.compare(insert, "==", current_word_end):
                        target = self.text.index("insert +1c wordend")
                    else:
                        target = current_word_end
                elif direction == "up":
                    target = self.text.index("insert -1line linestart")
                elif direction == "down":
                    target = self.text.index("insert +1line lineend")
                else:
                    return "break"
                self.text.tag_remove("sel", "1.0", "end")
                if self.text.compare(target, "<", anchor):
                    self.text.tag_add("sel", target, anchor)
                else:
                    self.text.tag_add("sel", anchor, target)
                self.text.mark_set("insert", target)
                self.text.see("insert")
            except Exception:
                pass
            return "break"

        def apply_scale_settings(self, event: Any = None, save: bool = True, announce: bool = True) -> None:
            try:
                editor_scale = max(80, min(180, int(self.var_editor_scale.get())))
            except Exception:
                editor_scale = 100
                self.var_editor_scale.set(editor_scale)
            try:
                side_width = max(155, min(280, int(self.var_side_width.get())))
            except Exception:
                side_width = 190
                self.var_side_width.set(side_width)
            if self.text is not None:
                effective_font = max(8, min(50, round(int(self.var_font_size.get()) * editor_scale / 100)))
                self.base_font.configure(family=str(self.var_font_family.get() or "Sans"), size=effective_font)
                outer_pad_x = max(10, round(28 * editor_scale / 100))
                outer_pad_y = max(8, round(18 * editor_scale / 100))
                inner_pad_x = max(18, round(48 * editor_scale / 100))
                inner_pad_y = max(16, round(38 * editor_scale / 100))
                self.text.pack_configure(padx=outer_pad_x, pady=outer_pad_y)
                self.text.configure(padx=inner_pad_x, pady=inner_pad_y, spacing2=int(self.var_line_spacing.get()), spacing3=int(self.var_paragraph_spacing.get()))
            if self.left_panel is not None:
                self.left_panel.configure(width=side_width)
            if save:
                save_gui_scale(editor_scale, side_width)
            if announce:
                self.var_status.set(f"Scale applied: editor {editor_scale}% / side menu {side_width}px")

        def set_theme(self, theme: str) -> None:
            if theme not in {"aegis_dark", "sentinel_light_cyan"}:
                theme = "aegis_dark"
            self.var_theme.set(theme)
            self.colors = self.theme_palette(theme)
            save_gui_theme(theme)
            # Re-apply ttk style and direct Tk widget colours.
            try:
                self.setup_style(self.ttk, __import__("tkinter.font").font)
            except Exception:
                pass
            self.root.configure(bg=self.colors["bg"])
            if self.editor_canvas is not None:
                self.editor_canvas.configure(bg=self.colors["editor_shell"])
            if self.text is not None:
                self.text.configure(
                    bg=self.colors["page"],
                    fg=self.colors["page_text"],
                    insertbackground=self.colors["page_text"],
                    selectbackground=self.colors["select_bg"],
                    selectforeground=self.colors["select_fg"],
                )
            for mb in getattr(self, "menu_widgets", []):
                try:
                    mb.configure(bg=self.colors["menu"], fg=self.colors["text"], activebackground=self.colors["panel3"], activeforeground=self.colors["active_fg"])
                    menu = mb.cget("menu")
                    if menu:
                        self.root.nametowidget(menu).configure(bg=self.colors["panel2"], fg=self.colors["text"], activebackground=self.colors["panel3"], activeforeground=self.colors["active_fg"])
                except Exception:
                    pass
            self.draw_header_icon()
            self.apply_document_formatting(save=False, announce=False)
            self.var_status.set(f"Theme applied: {theme}")

        def on_resize(self, event: Any) -> None:
            if event.widget is not self.root:
                return
            width = max(1060, int(event.width))
            side_w = max(155, min(280, int(self.var_side_width.get())))
            right_w = 220 if width < 1120 else 248 if width < 1360 else 270
            try:
                if self.left_panel is not None:
                    self.left_panel.configure(width=side_w)
                if self.right_panel is not None:
                    self.right_panel.configure(width=right_w)
                if hasattr(self, "info_label"):
                    self.info_label.configure(wraplength=max(190, right_w - 30))
            except Exception:
                pass

        def load_indexed_document(self, doc_id: str) -> bool:
            if not self.ask_save_if_dirty():
                return False
            doc = get_document(doc_id)
            if not doc:
                self.messagebox.showerror("Open indexed document", f"Document not found: {doc_id}")
                return False
            if doc.get("status") == "archived":
                if not self.messagebox.askyesno("Archived document", "This document is archived. Restore and open it?"):
                    return False
                restore_document(doc_id)
                doc = get_document(doc_id) or doc
            content = read_document_text(doc_id) or ""
            self.current_doc_id = doc_id
            self.var_title.set(doc.get("title", "Untitled"))
            self.var_category.set(doc.get("category", "General"))
            self.var_doc_type.set(doc.get("doc_type", "Document"))
            self.var_contact.set(doc.get("linked_contact_code") or "")
            self.var_job.set(doc.get("linked_job_code") or "")
            self.var_inventory.set(doc.get("linked_inventory_code") or "")
            self.text.delete("1.0", "end")
            self.text.insert("1.0", content)
            self.dirty = False
            self.text.edit_modified(False)
            self.var_status.set(f"Loaded {doc.get('title')} ({doc_id})")
            self.update_info()
            return True

        def show_category_summary(self) -> None:
            rows = document_categories(include_archived=True)
            if not rows:
                body = "No indexed documents yet."
            else:
                body = "Document Categories\n\n" + "\n".join(f"{r.get('category') or 'General'} — {r.get('status')}: {r.get('count')}" for r in rows)
            self.show_text_popup("Document Category Summary", body)

        def show_document_search(self, preset: str = "") -> None:
            win = self.tk.Toplevel(self.root)
            win.title("Sentinel Document Search")
            win.geometry("900x560")
            win.minsize(760, 440)
            win.configure(bg=self.colors["panel"])
            win.transient(self.root)
            q_var = self.tk.StringVar(value="")
            cats = ["All"] + sorted({(r.get("category") or "General") for r in document_categories(include_archived=True)})
            cat_var = self.tk.StringVar(value="All")
            status_var = self.tk.StringVar(value="Archived" if preset == "archived" else "Active")
            content_var = self.tk.BooleanVar(value=False)

            top = self.ttk.Frame(win, style="Panel.TFrame")
            top.pack(side="top", fill="x", padx=10, pady=10)
            self.ttk.Label(top, text="Search", style="Panel.TLabel").grid(row=0, column=0, padx=4, pady=4, sticky="w")
            q_entry = self.ttk.Entry(top, textvariable=q_var, width=32)
            q_entry.grid(row=0, column=1, padx=4, pady=4, sticky="ew")
            self.ttk.Label(top, text="Category", style="Panel.TLabel").grid(row=0, column=2, padx=4, pady=4, sticky="w")
            self.ttk.Combobox(top, textvariable=cat_var, values=cats, state="readonly", width=18).grid(row=0, column=3, padx=4, pady=4)
            self.ttk.Label(top, text="Status", style="Panel.TLabel").grid(row=0, column=4, padx=4, pady=4, sticky="w")
            self.ttk.Combobox(top, textvariable=status_var, values=["Active", "Archived", "All"], state="readonly", width=12).grid(row=0, column=5, padx=4, pady=4)
            self.ttk.Checkbutton(top, text="Content scan", variable=content_var).grid(row=1, column=1, padx=4, pady=2, sticky="w")
            top.columnconfigure(1, weight=1)

            table_frame = self.ttk.Frame(win, style="Panel.TFrame")
            table_frame.pack(fill="both", expand=True, padx=10, pady=(0, 8))
            columns = ("category", "status", "type", "modified", "matches")
            tree = self.ttk.Treeview(table_frame, columns=columns, show="tree headings", selectmode="browse")
            tree.heading("#0", text="Title")
            for col, title in [("category", "Category"), ("status", "Status"), ("type", "Type"), ("modified", "Modified"), ("matches", "Matches")]:
                tree.heading(col, text=title)
            tree.column("#0", width=260, stretch=True)
            tree.column("category", width=110, stretch=False)
            tree.column("status", width=90, stretch=False)
            tree.column("type", width=120, stretch=False)
            tree.column("modified", width=170, stretch=False)
            tree.column("matches", width=150, stretch=True)
            vsb = self.ttk.Scrollbar(table_frame, orient="vertical", command=tree.yview)
            tree.configure(yscrollcommand=vsb.set)
            tree.pack(side="left", fill="both", expand=True)
            vsb.pack(side="right", fill="y")

            result_label = self.ttk.Label(win, text="", style="Panel.TLabel")
            result_label.pack(side="left", padx=14, pady=(0, 10))

            def run_search() -> None:
                for item in tree.get_children():
                    tree.delete(item)
                status = status_var.get().lower()
                category = "" if cat_var.get() == "All" else cat_var.get()
                if preset == "recent" and not q_var.get().strip() and cat_var.get() == "All" and status == "active":
                    rows = list_recent_documents(limit=50, include_archived=False)
                    for r in rows:
                        r["match_fields"] = ["recent"]
                else:
                    rows = search_documents(q_var.get(), category=category, status=status, include_content=bool(content_var.get()), limit=200)
                for doc in rows:
                    tree.insert("", "end", iid=doc["id"], text=doc.get("title") or doc["id"], values=(doc.get("category") or "", doc.get("status") or "", doc.get("doc_type") or "", doc.get("modified_at") or "", ",".join(doc.get("match_fields") or [])))
                result_label.configure(text=f"{len(rows)} result(s) — metadata only; content is not displayed in search results.")

            def selected_id() -> Optional[str]:
                sel = tree.selection()
                return sel[0] if sel else None

            def open_selected() -> None:
                doc_id = selected_id()
                if not doc_id:
                    self.messagebox.showinfo("Search", "Select a document first.")
                    return
                if self.load_indexed_document(doc_id):
                    win.destroy()

            def archive_selected() -> None:
                doc_id = selected_id()
                if not doc_id:
                    self.messagebox.showinfo("Archive", "Select a document first.")
                    return
                if self.messagebox.askyesno("Archive", "Archive selected document?"):
                    archive_document(doc_id)
                    run_search()
                    self.var_status.set(f"Archived {doc_id}")

            def restore_selected() -> None:
                doc_id = selected_id()
                if not doc_id:
                    self.messagebox.showinfo("Restore", "Select a document first.")
                    return
                restore_document(doc_id)
                run_search()
                self.var_status.set(f"Restored {doc_id}")

            tree.bind("<Double-1>", lambda event: open_selected())
            buttons = self.ttk.Frame(win, style="Panel.TFrame")
            buttons.pack(side="bottom", fill="x", padx=10, pady=10)
            self.ttk.Button(buttons, text="Search", command=run_search).pack(side="left", padx=4)
            self.ttk.Button(buttons, text="Open Selected", command=open_selected).pack(side="left", padx=4)
            self.ttk.Button(buttons, text="Archive", command=archive_selected).pack(side="left", padx=4)
            self.ttk.Button(buttons, text="Restore", command=restore_selected).pack(side="left", padx=4)
            self.ttk.Button(buttons, text="Categories", command=self.show_category_summary).pack(side="left", padx=4)
            self.ttk.Button(buttons, text="Close", command=win.destroy).pack(side="right", padx=4)
            q_entry.bind("<Return>", lambda event: run_search())
            q_entry.focus_set()
            run_search()

        def menu_action(self, label: str) -> None:
            if label == "File":
                self.var_status.set("File: New, Save, Save As, Archive available on Home ribbon")
            elif label == "View":
                self.var_status.set("View: Sentinel Jobs-aligned dark command layout active")
            else:
                self.show_about()

        def show_dashboard(self) -> None:
            h = health_json()
            self.show_text_popup(
                "Sentinel Documents Dashboard",
                "Sentinel Documents Command Dashboard\n\n"
                f"Version: {VERSION}\n"
                f"Documents: {h['document_count_active']} active / {h['document_count_total']} total\n"
                f"Templates: {h['templates_count']}\n"
                "Contacts bridge: active/import-ready\nInventory bridge: ready\nJobs bridge: ready\n"
                "Network: disabled\nTelemetry: disabled\n"
            )


        def gui_import_contact_bridge(self) -> None:
            path = self.filedialog.askopenfilename(
                title="Import Sentinel Contacts bridge JSON",
                initialdir=str(CONTACTS_BRIDGE_DIR / "inbox"),
                filetypes=[("JSON files", "*.json"), ("All files", "*.*")],
            )
            if not path:
                return
            try:
                result = import_contact_bridge_file(path)
                first = result.get("contacts", [{}])[0] if result.get("contacts") else {}
                if first.get("contact_code"):
                    self.var_contact.set(first.get("contact_code"))
                self.var_status.set(f"Imported {result.get('count', 0)} contact bridge record(s)")
                self.messagebox.showinfo("Contacts Bridge", f"Imported {result.get('count', 0)} contact(s).")
                self.update_info()
            except Exception as exc:
                self.messagebox.showerror("Contacts Bridge", str(exc))

        def gui_create_contact_summary(self) -> None:
            code = self.var_contact.get().strip()
            if not code:
                records = list_contact_bridge_records()
                if records:
                    code = records[0].get("contact_code", "")
                else:
                    code = self.simpledialog.askstring("Contact Code", "Enter cached contact code:") or ""
            if not code:
                return
            try:
                result = create_contact_document(code, "contact-summary", title=None)
                doc_id = result.get("document_id")
                if doc_id:
                    self.load_document_by_id(doc_id)
                    self.var_contact.set(code)
                    self.var_status.set(f"Created contact document for {code}")
            except Exception as exc:
                self.messagebox.showerror("Contacts Bridge", str(exc))

        def gui_export_contact_bridge(self) -> None:
            try:
                result = export_contact_document_bridge(self.current_doc_id if self.current_doc_id else None)
                self.var_status.set(f"Exported contact bridge metadata: {result.get('document_count', 0)} document(s)")
                self.show_text_popup("Contact Bridge Export", json.dumps(result, indent=2))
            except Exception as exc:
                self.messagebox.showerror("Contacts Bridge", str(exc))



        def gui_import_inventory_bridge(self) -> None:
            path = self.filedialog.askopenfilename(
                title="Import Sentinel Inventory bridge JSON",
                initialdir=str(INVENTORY_BRIDGE_DIR / "inbox"),
                filetypes=[("JSON files", "*.json"), ("All files", "*.*")],
            )
            if not path:
                return
            try:
                result = import_inventory_bridge_file(path)
                first = result.get("items", [{}])[0] if result.get("items") else {}
                if first.get("item_code"):
                    self.var_inventory.set(first.get("item_code"))
                self.var_status.set(f"Imported {result.get('count', 0)} inventory bridge item(s)")
                self.messagebox.showinfo("Inventory Bridge", f"Imported {result.get('count', 0)} inventory item(s).")
                self.update_info()
            except Exception as exc:
                self.messagebox.showerror("Inventory Bridge", str(exc))

        def gui_create_inventory_report(self) -> None:
            code = self.var_inventory.get().strip()
            if not code:
                records = list_inventory_bridge_records()
                if records:
                    code = records[0].get("item_code", "")
                else:
                    code = self.simpledialog.askstring("Inventory Item Code", "Enter cached inventory item code:") or ""
            if not code:
                return
            try:
                result = create_inventory_document(code, "inventory-item-report", title=None)
                doc_id = result.get("document_id")
                if doc_id:
                    self.load_document_by_id(doc_id)
                    self.var_inventory.set(code)
                    self.var_status.set(f"Created inventory document for {code}")
            except Exception as exc:
                self.messagebox.showerror("Inventory Bridge", str(exc))

        def gui_export_inventory_bridge(self) -> None:
            try:
                result = export_inventory_document_bridge(self.current_doc_id if self.current_doc_id else None)
                self.var_status.set(f"Exported inventory bridge metadata: {result.get('document_count', 0)} document(s)")
                self.show_text_popup("Inventory Bridge Export", json.dumps(result, indent=2))
            except Exception as exc:
                self.messagebox.showerror("Inventory Bridge", str(exc))



        def gui_import_job_bridge(self) -> None:
            path = self.filedialog.askopenfilename(
                title="Import Sentinel Jobs bridge JSON",
                initialdir=str(JOBS_BRIDGE_DIR / "inbox"),
                filetypes=[("JSON files", "*.json"), ("All files", "*.*")],
            )
            if not path:
                return
            try:
                result = import_job_bridge_file(path)
                first = result.get("jobs", [{}])[0] if result.get("jobs") else {}
                if first.get("job_code"):
                    self.var_job.set(first.get("job_code"))
                self.var_status.set(f"Imported {result.get('count', 0)} job bridge record(s)")
                self.messagebox.showinfo("Jobs Bridge", f"Imported {result.get('count', 0)} job record(s).")
                self.update_info()
            except Exception as exc:
                self.messagebox.showerror("Jobs Bridge", str(exc))

        def gui_create_job_quote(self) -> None:
            code = self.var_job.get().strip()
            if not code:
                records = list_job_bridge_records()
                if records:
                    code = records[0].get("job_code", "")
                else:
                    code = self.simpledialog.askstring("Job Code", "Enter cached job code:") or ""
            if not code:
                return
            try:
                result = create_job_document(code, "job-quote", title=None)
                doc_id = result.get("document_id")
                if doc_id:
                    self.load_document_by_id(doc_id)
                    self.var_job.set(code)
                    self.var_status.set(f"Created job quote for {code}")
            except Exception as exc:
                self.messagebox.showerror("Jobs Bridge", str(exc))

        def gui_export_job_bridge(self) -> None:
            try:
                result = export_job_document_bridge(self.current_doc_id if self.current_doc_id else None)
                self.var_status.set(f"Exported jobs bridge metadata: {result.get('document_count', 0)} document(s)")
                self.show_text_popup("Jobs Bridge Export", json.dumps(result, indent=2))
            except Exception as exc:
                self.messagebox.showerror("Jobs Bridge", str(exc))

        def gui_template_info(self) -> None:
            name = self.template_var.get().strip()
            try:
                self.show_text_popup("Template Info", json.dumps(template_info(name), indent=2))
            except Exception as exc:
                self.messagebox.showerror("Template", str(exc))

        def gui_create_from_template(self) -> None:
            name = self.template_var.get().strip()
            try:
                contact_code = self.var_contact.get().strip()
                context = contact_context(contact_code) if contact_code and get_contact_bridge_record(contact_code) else {}
                context.update({
                    "contact_code": contact_code,
                    "job_code": self.var_job.get().strip(),
                    "item_code": self.var_inventory.get().strip(),
                    "prepared_by": os.environ.get("USER") or os.environ.get("USERNAME") or "Sentinel User",
                })
                rendered, missing = render_template_text(name, context)
                if not self.ask_save_if_dirty():
                    return
                self.current_doc_id = None
                self.text.delete("1.0", "end")
                self.text.insert("1.0", rendered)
                self.var_title.set(template_path(name).stem.replace("-", " ").title())
                if "job" in name:
                    self.var_category.set("Jobs")
                    self.var_doc_type.set("Job Sheet")
                elif "inventory" in name or "warranty" in name:
                    self.var_category.set("Inventory")
                    self.var_doc_type.set("Inventory Sheet")
                elif "contact" in name or "letter" in name:
                    self.var_category.set("Contacts")
                    self.var_doc_type.set("Letter")
                else:
                    self.var_category.set("Templates")
                    self.var_doc_type.set("Document")
                self.dirty = True
                self.var_status.set(f"Created from template: {name}; empty placeholders: {len(missing)}")
                self.update_info()
            except Exception as exc:
                self.messagebox.showerror("Template", str(exc))

        def export_markdown(self) -> None:
            EXPORTS_DIR.mkdir(parents=True, exist_ok=True)
            name = safe_slug(self.var_title.get()) + ".md"
            dest = self.filedialog.asksaveasfilename(
                initialdir=str(EXPORTS_DIR),
                initialfile=name,
                defaultextension=".md",
                filetypes=[("Markdown", "*.md"), ("Text", "*.txt"), ("All files", "*.*")],
            )
            if not dest:
                return
            Path(dest).write_text(self.text.get("1.0", "end-1c"), encoding="utf-8")
            self.var_status.set(f"Exported Markdown: {dest}")

        def gui_export_current(self) -> None:
            EXPORTS_DIR.mkdir(parents=True, exist_ok=True)
            title = self.var_title.get().strip() or "Untitled Document"
            fmt = self.simple_choice_dialog("Export Format", "Choose export format", list(SAVE_FORMATS.keys()), "pdf")
            if not fmt:
                return
            fmt = normalise_save_format(fmt)
            dest = self.filedialog.asksaveasfilename(
                initialdir=str(EXPORTS_DIR),
                initialfile=safe_slug(title) + SAVE_FORMATS[fmt]["extension"],
                defaultextension=SAVE_FORMATS[fmt]["extension"],
                filetypes=[(SAVE_FORMATS[fmt]["label"], "*" + SAVE_FORMATS[fmt]["extension"]), ("All files", "*.*")],
            )
            if not dest:
                return
            try:
                write_content_file(Path(dest), title, self.text.get("1.0", "end-1c"), fmt)
                self.var_status.set(f"Exported {fmt}: {dest}")
            except Exception as exc:
                self.messagebox.showerror("Export", str(exc))

        def simple_choice_dialog(self, title: str, label: str, choices: List[str], default: str) -> Optional[str]:
            dialog = self.tk.Toplevel(self.root)
            dialog.title(title)
            dialog.configure(bg=self.colors["panel"])
            dialog.transient(self.root)
            dialog.grab_set()
            value = self.tk.StringVar(value=default if default in choices else (choices[0] if choices else ""))
            result: Dict[str, str] = {}
            self.ttk.Label(dialog, text=label, style="Panel.TLabel").grid(row=0, column=0, padx=12, pady=10, sticky="w")
            self.ttk.Combobox(dialog, textvariable=value, values=choices, state="readonly", width=24).grid(row=0, column=1, padx=12, pady=10, sticky="ew")
            buttons = self.ttk.Frame(dialog, style="Panel.TFrame")
            buttons.grid(row=1, column=0, columnspan=2, sticky="e", padx=12, pady=12)
            def ok() -> None:
                result["value"] = value.get()
                dialog.destroy()
            def cancel() -> None:
                dialog.destroy()
            self.ttk.Button(buttons, text="Cancel", command=cancel).pack(side="right", padx=4)
            self.ttk.Button(buttons, text="OK", command=ok).pack(side="right", padx=4)
            dialog.columnconfigure(1, weight=1)
            self.root.wait_window(dialog)
            return result.get("value")

        def gui_open_in_libreoffice(self) -> None:
            try:
                if not self.current_doc_id:
                    if not self.save_document():
                        return
                result = open_in_libreoffice(self.current_doc_id or "")
                if result.get("opened"):
                    self.var_status.set(f"Opened in LibreOffice: {result.get('path')}")
                else:
                    self.messagebox.showinfo("LibreOffice", result.get("reason", "LibreOffice not available"))
            except Exception as exc:
                self.messagebox.showerror("LibreOffice", str(exc))

        def gui_libreoffice_status(self) -> None:
            self.show_text_popup("LibreOffice Status", json.dumps(libreoffice_status_json(write_contract=False), indent=2))


        def gui_backup_now(self) -> None:
            try:
                result = create_backup()
                self.show_text_popup("Backup Created", json.dumps(result, indent=2))
            except Exception as exc:
                self.messagebox.showerror("Backup Failed", str(exc))

        def gui_verify_db(self) -> None:
            self.show_text_popup("Database Verification", json.dumps(verify_database(), indent=2))

        def gui_repair_db(self) -> None:
            if not self.messagebox.askyesno("Repair Database", "Run local database repair/reconciliation now?"):
                return
            try:
                self.show_text_popup("Repair Result", json.dumps(repair_database(), indent=2))
                self.load_document_list()
            except Exception as exc:
                self.messagebox.showerror("Repair Failed", str(exc))

        def gui_export_library(self) -> None:
            try:
                result = export_library()
                self.show_text_popup("Library Export", json.dumps(result, indent=2))
            except Exception as exc:
                self.messagebox.showerror("Export Failed", str(exc))

        def gui_repair_launcher(self) -> None:
            try:
                self.show_text_popup("Launcher Repair", json.dumps(repair_launcher(), indent=2))
            except Exception as exc:
                self.messagebox.showerror("Launcher Repair Failed", str(exc))

        def gui_recovery_report(self) -> None:
            self.show_text_popup("Recovery Report", json.dumps(recovery_report_json(), indent=2))

        def gui_rc_audit(self) -> None:
            self.show_text_popup("V1 Audit", json.dumps(rc_audit_json(), indent=2))

        def gui_release_candidate_report(self) -> None:
            try:
                result = release_candidate_report()
                self.show_text_popup("V1 Audit Report", json.dumps(result, indent=2))
            except Exception as exc:
                self.messagebox.showerror("V1 Audit Report Failed", str(exc))

        def show_aegis_capabilities(self) -> None:
            self.show_text_popup("AEGIS Capabilities JSON", json.dumps(aegis_capabilities_json(), indent=2))

        def gui_export_vault_metadata(self) -> None:
            try:
                result = export_vault_metadata()
                self.var_status.set(f"Vault metadata exported: {result.get('path')}")
                self.show_text_popup("Vault Metadata Export", json.dumps(result, indent=2))
            except Exception as exc:
                self.messagebox.showerror("Vault Metadata", str(exc))

        def gui_safe_read_current(self) -> None:
            if not self.current_doc_id:
                self.messagebox.showinfo("Safe Read", "Save or open a document first.")
                return
            self.show_text_popup("Safe Read Current Document", json.dumps(safe_read_document(self.current_doc_id, limit=20000), indent=2))

        def gui_write_aegis_files(self) -> None:
            write_aegis_contract_files()
            self.var_status.set("AEGIS status/actions JSON written")
            self.messagebox.showinfo("AEGIS", f"AEGIS contract files written to:\n{AEGIS_DIR}")

        def show_health(self) -> None:
            self.show_text_popup("Health JSON", json.dumps(health_json(), indent=2))

        def show_paths(self) -> None:
            self.show_text_popup("Sentinel Documents Paths", json.dumps(paths_json(), indent=2))

        def show_about(self) -> None:
            self.messagebox.showinfo(
                "About Sentinel Documents",
                f"{APP_NAME} v{VERSION}\nProgram {PROGRAM_ID}\n\nOffice-familiar local document foundation.\nAEGIS-ready. Contacts, Inventory, and Jobs bridges are active. V1 stable locked audit is available.\n\nNetwork: disabled\nTelemetry: disabled",
            )

        def show_text_popup(self, title: str, text: str) -> None:
            win = self.tk.Toplevel(self.root)
            win.title(title)
            win.geometry("760x520")
            t = self.tk.Text(win, wrap="word", bg=self.colors["page"], fg=self.colors["page_text"], insertbackground=self.colors["page_text"], selectbackground=self.colors["select_bg"], selectforeground=self.colors["select_fg"])
            t.pack(fill="both", expand=True)
            t.insert("1.0", text)
            t.configure(state="disabled")

        def open_path(self, path: Path) -> None:
            path.mkdir(parents=True, exist_ok=True)
            # Prefer xdg-open on Linux; no hard failure if absent.
            try:
                import subprocess
                subprocess.Popen(["xdg-open", str(path)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            except Exception:
                self.messagebox.showinfo("Path", str(path))

        def on_close(self) -> None:
            if self.ask_save_if_dirty():
                self.root.destroy()

    root = tk.Tk()
    app = SentinelDocumentsGUI(root)
    root.mainloop()
    return 0


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        prog="sentinel-documents",
        description=f"Sentinel Documents v{VERSION} — Program 116 local document maker/library v1 stable locked with maximized default window, working visual bold/italic controls, repaired font picker, AEGIS/Vault readiness, and bridges.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=textwrap.dedent(
            """
            Examples:
              sentinel-documents
              sentinel-documents --status
              sentinel-documents --health-json
              sentinel-documents --aegis-actions-json
              sentinel-documents --export-templates-json
              sentinel-documents --create-from-template job-quote --template-set contact_name=Customer
              sentinel-documents --import-contact-bridge contacts.json
              sentinel-documents --create-contact-document SCON-0001 contact-summary
              sentinel-documents --import-inventory-bridge inventory.json
              sentinel-documents --create-inventory-document SINV-0001 inventory-item-report
              sentinel-documents --import-job-bridge jobs.json
              sentinel-documents --create-job-document SJOB-0001 job-quote
              sentinel-documents --export DOCUMENT_ID --export-format pdf
              sentinel-documents --open-in-libreoffice DOCUMENT_ID
              sentinel-documents --search-documents quote --search-category Jobs --search-status active
              sentinel-documents --list-categories-json
              sentinel-documents --restore DOCUMENT_ID
              sentinel-documents --aegis-capabilities-json
              sentinel-documents --vault-metadata-json
              sentinel-documents --export-vault-metadata
              sentinel-documents --safe-read DOCUMENT_ID
              sentinel-documents --format-options-json
            """
        ),
    )
    parser.add_argument("--init", action="store_true", help="Create local folders, database, templates, and AEGIS contract files.")
    parser.add_argument("--status", action="store_true", help="Print human-readable status.")
    parser.add_argument("--health-json", action="store_true", help="Print machine-readable health JSON.")
    parser.add_argument("--aegis-status-json", action="store_true", help="Print AEGIS status JSON.")
    parser.add_argument("--aegis-actions-json", action="store_true", help="Print AEGIS actions JSON contract.")
    parser.add_argument("--aegis-capabilities-json", action="store_true", help="Print expanded AEGIS/Sentinel Command capabilities JSON.")
    parser.add_argument("--vault-metadata-json", action="store_true", help="Print Vault-ready document metadata JSON without full document text.")
    parser.add_argument("--export-vault-metadata", nargs="?", const="", metavar="PATH", help="Export Vault-ready document metadata JSON to AEGIS metadata folder or optional PATH.")
    parser.add_argument("--safe-read", metavar="DOCUMENT_ID", help="Safely read a local document text layer by id.")
    parser.add_argument("--safe-read-limit", type=int, default=20000, help="Maximum characters returned by --safe-read.")
    parser.add_argument("--format-options-json", action="store_true", help="Print GUI font and paragraph formatting option metadata.")
    parser.add_argument("--print-paths", action="store_true", help="Print local storage paths as JSON.")
    parser.add_argument("--list-templates", action="store_true", help="List seeded templates.")
    parser.add_argument("--export-templates-json", action="store_true", help="Print template metadata, placeholders, and hashes as JSON.")
    parser.add_argument("--template-info", metavar="TEMPLATE_NAME", help="Print metadata for one template.")
    parser.add_argument("--create-from-template", metavar="TEMPLATE_NAME", help="Create a local document from a template.")
    parser.add_argument("--template-context-json", metavar="FILE", help="Optional JSON context file for --create-from-template.")
    parser.add_argument("--template-set", action="append", default=[], metavar="KEY=VALUE", help="Set a template placeholder value. Can be repeated.")
    parser.add_argument("--template-title", metavar="TITLE", help="Title for a document created from a template.")
    parser.add_argument("--template-category", metavar="CATEGORY", default="Templates", help="Category for a document created from a template.")
    parser.add_argument("--template-doc-type", metavar="TYPE", default="Document", help="Document type for a document created from a template.")
    parser.add_argument("--template-contact-code", metavar="CODE", help="Link created document to a contact code.")
    parser.add_argument("--template-job-code", metavar="CODE", help="Link created document to a job code.")
    parser.add_argument("--template-inventory-code", metavar="CODE", help="Link created document to an inventory item code.")
    parser.add_argument("--import-contact-bridge", metavar="FILE", help="Import Sentinel Contacts quick-fill/contact bridge JSON into the local contact cache.")
    parser.add_argument("--list-contact-bridges-json", action="store_true", help="List cached contact bridge records as JSON.")
    parser.add_argument("--contact-context-json", metavar="CONTACT_CODE", help="Print the merged template context for a cached contact code.")
    parser.add_argument("--create-contact-document", nargs=2, metavar=("CONTACT_CODE", "TEMPLATE_NAME"), help="Create a local document from a cached contact bridge record and template.")
    parser.add_argument("--contact-doc-title", metavar="TITLE", help="Optional title for --create-contact-document.")
    parser.add_argument("--export-contact-document-bridge", nargs="?", const="__ALL__", metavar="DOCUMENT_ID", help="Export contact-linked document metadata to the Contacts bridge outbox. Omit DOCUMENT_ID for all.")
    parser.add_argument("--import-inventory-bridge", metavar="FILE", help="Import Sentinel Inventory item/asset bridge JSON into the local inventory cache.")
    parser.add_argument("--list-inventory-bridges-json", action="store_true", help="List cached inventory bridge records as JSON.")
    parser.add_argument("--inventory-context-json", metavar="ITEM_CODE", help="Print the merged template context for a cached inventory item code.")
    parser.add_argument("--create-inventory-document", nargs=2, metavar=("ITEM_CODE", "TEMPLATE_NAME"), help="Create a local document from a cached inventory bridge record and template.")
    parser.add_argument("--inventory-doc-title", metavar="TITLE", help="Optional title for --create-inventory-document.")
    parser.add_argument("--export-inventory-document-bridge", nargs="?", const="__ALL__", metavar="DOCUMENT_ID", help="Export inventory-linked document metadata to the Inventory bridge outbox. Omit DOCUMENT_ID for all.")
    parser.add_argument("--import-job-bridge", metavar="FILE", help="Import Sentinel Jobs job/work-order bridge JSON into the local jobs cache.")
    parser.add_argument("--list-job-bridges-json", action="store_true", help="List cached job bridge records as JSON.")
    parser.add_argument("--job-context-json", metavar="JOB_CODE", help="Print the merged template context for a cached job code.")
    parser.add_argument("--create-job-document", nargs=2, metavar=("JOB_CODE", "TEMPLATE_NAME"), help="Create a local document from a cached job bridge record and template.")
    parser.add_argument("--job-doc-title", metavar="TITLE", help="Optional title for --create-job-document.")
    parser.add_argument("--export-job-document-bridge", nargs="?", const="__ALL__", metavar="DOCUMENT_ID", help="Export job-linked document metadata to the Jobs bridge outbox. Omit DOCUMENT_ID for all.")
    parser.add_argument("--list-documents-json", action="store_true", help="List indexed document metadata.")
    parser.add_argument("--search-documents", metavar="QUERY", help="Search indexed document metadata; use an empty string to list by filters.")
    parser.add_argument("--search-category", metavar="CATEGORY", default="", help="Optional category filter for --search-documents.")
    parser.add_argument("--search-status", choices=["active", "archived", "all"], default="active", help="Status filter for --search-documents.")
    parser.add_argument("--search-content", action="store_true", help="Allow local content scan during --search-documents; results still return metadata only.")
    parser.add_argument("--list-categories-json", action="store_true", help="List document categories and active/archived counts.")
    parser.add_argument("--list-recent-documents-json", nargs="?", const="12", metavar="LIMIT", help="List recently modified active documents as metadata JSON.")
    parser.add_argument("--safe-read-metadata", metavar="DOCUMENT_ID", help="Read one document's metadata without full document text.")
    parser.add_argument("--export", metavar="DOCUMENT_ID", help="Export an indexed document by id.")
    parser.add_argument("--export-format", default="markdown", metavar="FORMAT", help="Export format: markdown, text, html, pdf, odt, or docx.")
    parser.add_argument("--export-output", metavar="PATH", help="Optional explicit export destination path.")
    parser.add_argument("--export-formats-json", action="store_true", help="List supported save/export formats as JSON.")
    parser.add_argument("--libreoffice-status-json", action="store_true", help="Report LibreOffice/soffice handoff availability.")
    parser.add_argument("--open-in-libreoffice", metavar="DOCUMENT_ID", help="Open an indexed document in LibreOffice when installed.")
    parser.add_argument("--archive", metavar="DOCUMENT_ID", help="Archive a document by id.")
    parser.add_argument("--restore", metavar="DOCUMENT_ID", help="Restore an archived document by id.")
    parser.add_argument("--backup", nargs="?", const="", metavar="OUTPUT.zip", help="Create a local backup ZIP. Optional output path.")
    parser.add_argument("--restore-backup", metavar="BACKUP.zip", help="Restore a Sentinel Documents backup ZIP after creating a safety snapshot.")
    parser.add_argument("--confirm", metavar="TOKEN", help="Required typed confirmation token for guarded restore operations. Use RESTORE_SENTINEL_DOCUMENTS.")
    parser.add_argument("--verify-db", action="store_true", help="Verify database integrity, file existence, and SHA256 hashes.")
    parser.add_argument("--repair-db", action="store_true", help="Repair/reconcile database hashes, missing-file status, and unindexed files.")
    parser.add_argument("--export-library", nargs="?", const="", metavar="OUTPUT.zip", help="Export document library to a portable ZIP. Optional output path.")
    parser.add_argument("--import-library", metavar="LIBRARY.zip", help="Merge-import a Sentinel Documents library ZIP. Requires --confirm IMPORT_SENTINEL_DOCUMENTS_LIBRARY and never overwrites app data/config/database.")
    parser.add_argument("--repair-launcher", action="store_true", help="Repair the user-local desktop launcher.")
    parser.add_argument("--allow-root-runtime", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--recovery-report-json", action="store_true", help="Print backup/recovery report JSON.")
    parser.add_argument("--rc-audit-json", action="store_true", help="Print v1 stable-lock readiness audit JSON.")
    parser.add_argument("--release-candidate-report", dest="release_candidate_report", nargs="?", const="", metavar="OUTPUT.md", help="Legacy alias: write a Markdown v1 audit report. Optional output path.")
    parser.add_argument("--v1-audit-report", dest="release_candidate_report", nargs="?", const="", metavar="OUTPUT.md", help="Write a Markdown v1 audit report. Optional output path.")
    parser.add_argument("--stable-lock-report", nargs="?", const="", metavar="OUTPUT.md", help="Write a Markdown v1.0.1 stable-lock report. Optional output path.")
    parser.add_argument("--audit-report-json", action="store_true", help="Print v1 stable-lock audit JSON.")
    parser.add_argument("--export-audit-json", nargs="?", const="", metavar="OUTPUT.json", help="Export v1 audit JSON to the recovery folder or optional path.")
    parser.add_argument("--export-audit-csv", nargs="?", const="", metavar="OUTPUT.csv", help="Export v1 audit flag summary CSV to the recovery folder or optional path.")
    parser.add_argument("--export-v1-bundle", nargs="?", const="", metavar="OUTPUT.zip", help="Export a v1 handoff bundle with stable-lock, audit, backup, and manifest files.")
    parser.add_argument("--version", action="store_true", help="Print version.")
    args = parser.parse_args(argv)

    if args.version:
        print(VERSION)
        return 0
    if hasattr(os, "geteuid") and os.geteuid() == 0 and not args.allow_root_runtime:
        print("Do not run Sentinel Documents as root. Install as root, run as a normal user. Use --allow-root-runtime only for controlled diagnostics/tests.", file=sys.stderr)
        return 1
    if args.init:
        init_environment()
        print(f"Initialized {APP_NAME} v{VERSION}")
        return 0
    if args.status:
        print_status()
        return 0
    if args.health_json:
        print_json(health_json())
        return 0
    if args.aegis_status_json:
        print_json(aegis_status_json())
        return 0
    if args.aegis_actions_json:
        init_environment()
        print_json(aegis_actions_json())
        return 0
    if args.aegis_capabilities_json:
        print_json(aegis_capabilities_json())
        return 0
    if args.vault_metadata_json:
        print_json(vault_metadata_json())
        return 0
    if args.export_vault_metadata is not None:
        output = args.export_vault_metadata or None
        print_json(export_vault_metadata(output_path=output))
        return 0
    if args.safe_read:
        print_json(safe_read_document(args.safe_read, limit=args.safe_read_limit))
        return 0
    if args.format_options_json:
        print_json(format_options_json())
        return 0
    if args.print_paths:
        init_environment()
        print_json(paths_json())
        return 0
    if args.list_templates:
        init_environment()
        for name in list_templates():
            print(name)
        return 0
    if args.export_templates_json:
        print_json(templates_json())
        return 0
    if args.template_info:
        init_environment()
        print_json(template_info(args.template_info))
        return 0
    if args.create_from_template:
        init_environment()
        try:
            context = load_context_json(args.template_context_json)
            context.update(parse_template_sets(args.template_set))
            result = create_document_from_template(
                args.create_from_template,
                context,
                title=args.template_title,
                category=args.template_category,
                doc_type=args.template_doc_type,
                linked_contact_code=args.template_contact_code,
                linked_job_code=args.template_job_code,
                linked_inventory_code=args.template_inventory_code,
            )
            print_json(result)
            return 0
        except Exception as exc:
            print(f"Template creation failed: {exc}", file=sys.stderr)
            return 1
    if args.import_contact_bridge:
        try:
            print_json(import_contact_bridge_file(args.import_contact_bridge))
            return 0
        except Exception as exc:
            print(f"Contact bridge import failed: {exc}", file=sys.stderr)
            return 1
    if args.list_contact_bridges_json:
        init_environment()
        print_json({"contacts": list_contact_bridge_records(), "count": contact_record_count(), "full_text_returned": False})
        return 0
    if args.contact_context_json:
        try:
            print_json(contact_context(args.contact_context_json))
            return 0
        except Exception as exc:
            print(f"Contact context failed: {exc}", file=sys.stderr)
            return 1
    if args.create_contact_document:
        try:
            code, template_name = args.create_contact_document
            print_json(create_contact_document(code, template_name, title=args.contact_doc_title))
            return 0
        except Exception as exc:
            print(f"Contact document creation failed: {exc}", file=sys.stderr)
            return 1
    if args.export_contact_document_bridge:
        try:
            doc_id = None if args.export_contact_document_bridge == "__ALL__" else args.export_contact_document_bridge
            print_json(export_contact_document_bridge(doc_id))
            return 0
        except Exception as exc:
            print(f"Contact document bridge export failed: {exc}", file=sys.stderr)
            return 1
    if args.import_inventory_bridge:
        try:
            print_json(import_inventory_bridge_file(args.import_inventory_bridge))
            return 0
        except Exception as exc:
            print(f"Inventory bridge import failed: {exc}", file=sys.stderr)
            return 1
    if args.list_inventory_bridges_json:
        init_environment()
        print_json({"items": list_inventory_bridge_records(), "count": inventory_record_count(), "full_text_returned": False})
        return 0
    if args.inventory_context_json:
        try:
            print_json(inventory_context(args.inventory_context_json))
            return 0
        except Exception as exc:
            print(f"Inventory context failed: {exc}", file=sys.stderr)
            return 1
    if args.create_inventory_document:
        try:
            code, template_name = args.create_inventory_document
            print_json(create_inventory_document(code, template_name, title=args.inventory_doc_title))
            return 0
        except Exception as exc:
            print(f"Inventory document creation failed: {exc}", file=sys.stderr)
            return 1
    if args.export_inventory_document_bridge:
        try:
            doc_id = None if args.export_inventory_document_bridge == "__ALL__" else args.export_inventory_document_bridge
            print_json(export_inventory_document_bridge(doc_id))
            return 0
        except Exception as exc:
            print(f"Inventory document bridge export failed: {exc}", file=sys.stderr)
            return 1
    if args.import_job_bridge:
        try:
            print_json(import_job_bridge_file(args.import_job_bridge))
            return 0
        except Exception as exc:
            print(f"Jobs bridge import failed: {exc}", file=sys.stderr)
            return 1
    if args.list_job_bridges_json:
        init_environment()
        print_json({"jobs": list_job_bridge_records(), "count": job_record_count(), "full_text_returned": False})
        return 0
    if args.job_context_json:
        try:
            print_json(job_context(args.job_context_json))
            return 0
        except Exception as exc:
            print(f"Job context failed: {exc}", file=sys.stderr)
            return 1
    if args.create_job_document:
        try:
            code, template_name = args.create_job_document
            print_json(create_job_document(code, template_name, title=args.job_doc_title))
            return 0
        except Exception as exc:
            print(f"Job document creation failed: {exc}", file=sys.stderr)
            return 1
    if args.export_job_document_bridge:
        try:
            doc_id = None if args.export_job_document_bridge == "__ALL__" else args.export_job_document_bridge
            print_json(export_job_document_bridge(doc_id))
            return 0
        except Exception as exc:
            print(f"Job document bridge export failed: {exc}", file=sys.stderr)
            return 1
    if args.list_categories_json:
        init_environment()
        print_json({"categories": document_categories(include_archived=True), "full_text_returned": False})
        return 0
    if args.list_recent_documents_json is not None:
        init_environment()
        try:
            limit = int(args.list_recent_documents_json)
        except Exception:
            limit = 12
        print_json({"documents": list_recent_documents(limit=limit), "full_text_returned": False})
        return 0
    if args.search_documents is not None:
        init_environment()
        print_json({"documents": search_documents(args.search_documents, category=args.search_category, status=args.search_status, include_content=args.search_content), "full_text_returned": False})
        return 0
    if args.list_documents_json:
        init_environment()
        print_json({"documents": list_documents(include_archived=True), "library_summary": document_library_summary(), "full_text_returned": False})
        return 0
    if args.safe_read_metadata:
        init_environment()
        print_json(safe_read_metadata(args.safe_read_metadata))
        return 0
    if args.export_formats_json:
        print_json(export_formats_json())
        return 0
    if args.libreoffice_status_json:
        print_json(libreoffice_status_json())
        return 0
    if args.export:
        try:
            print_json(export_document(args.export, fmt=args.export_format, output_path=args.export_output))
            return 0
        except Exception as exc:
            print(f"Document export failed: {exc}", file=sys.stderr)
            return 1
    if args.open_in_libreoffice:
        try:
            print_json(open_in_libreoffice(args.open_in_libreoffice))
            return 0
        except Exception as exc:
            print(f"LibreOffice handoff failed: {exc}", file=sys.stderr)
            return 1
    if args.backup is not None:
        try:
            output = args.backup or None
            print_json(create_backup(output))
            return 0
        except Exception as exc:
            print(f"Backup failed: {exc}", file=sys.stderr)
            return 1
    if args.restore_backup:
        try:
            print_json(restore_backup(args.restore_backup, confirm=args.confirm))
            return 0
        except Exception as exc:
            print(f"Backup restore failed: {exc}", file=sys.stderr)
            return 1
    if args.verify_db:
        print_json(verify_database())
        return 0
    if args.repair_db:
        try:
            print_json(repair_database())
            return 0
        except Exception as exc:
            print(f"Database repair failed: {exc}", file=sys.stderr)
            return 1
    if args.export_library is not None:
        try:
            output = args.export_library or None
            print_json(export_library(output))
            return 0
        except Exception as exc:
            print(f"Library export failed: {exc}", file=sys.stderr)
            return 1
    if args.import_library:
        try:
            print_json(import_library(args.import_library, confirm=args.confirm))
            return 0
        except Exception as exc:
            print(f"Library import failed: {exc}", file=sys.stderr)
            return 1
    if args.repair_launcher:
        print_json(repair_launcher())
        return 0
    if args.recovery_report_json:
        print_json(recovery_report_json())
        return 0
    if args.rc_audit_json:
        print_json(rc_audit_json())
        return 0
    if args.release_candidate_report is not None:
        output = args.release_candidate_report or None
        print_json(release_candidate_report(output_path=output))
        return 0
    if args.stable_lock_report is not None:
        output = args.stable_lock_report or None
        print_json(stable_lock_report(output_path=output))
        return 0
    if args.audit_report_json:
        print_json(audit_report_json())
        return 0
    if args.export_audit_json is not None:
        output = args.export_audit_json or None
        print_json(export_audit_json(output_path=output))
        return 0
    if args.export_audit_csv is not None:
        output = args.export_audit_csv or None
        print_json(export_audit_csv(output_path=output))
        return 0
    if args.export_v1_bundle is not None:
        output = args.export_v1_bundle or None
        print_json(export_v1_bundle(output_path=output))
        return 0
    if args.archive:
        init_environment()
        if archive_document(args.archive):
            print(f"Archived {args.archive}")
            return 0
        print(f"Document not found: {args.archive}", file=sys.stderr)
        return 1
    if args.restore:
        init_environment()
        if restore_document(args.restore):
            print(f"Restored {args.restore}")
            return 0
        print(f"Document not found: {args.restore}", file=sys.stderr)
        return 1

    return launch_gui()


if __name__ == "__main__":
    raise SystemExit(main())
