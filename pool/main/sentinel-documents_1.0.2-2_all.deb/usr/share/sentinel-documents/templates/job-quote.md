# Job Quote

Date: {{date}}
Job Code: {{job_code}}
Job Title: {{job_title}}
Customer: {{contact_name}}
Phone: {{contact_phone}}
Email: {{contact_email}}

## Scope
{{job_description}}

## Materials
{{materials}}

## Labour
{{labour}}

## Estimated Total
{{estimated_total}}

## Terms / Notes
{{notes}}

Prepared By: {{prepared_by}}
