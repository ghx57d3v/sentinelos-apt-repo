# Inventory Asset Sheet

Date: {{date}}
Asset Tag: {{asset_tag}}
Item Code: {{item_code}}
Item Name: {{item_name}}
Category: {{item_category}}
Location: {{location}}
Condition: {{condition}}
Quantity: {{quantity}}

## Ownership / Value
Supplier: {{supplier}}
Purchase Date: {{purchase_date}}
Purchase Price: {{purchase_price}}

## Service / Repair Notes
{{notes}}
