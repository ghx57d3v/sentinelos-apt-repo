# General Letter

Date: {{date}}

To: {{contact_name}}
{{contact_address}}

Dear {{contact_name}},

{{letter_body}}

Regards,
{{prepared_by}}
