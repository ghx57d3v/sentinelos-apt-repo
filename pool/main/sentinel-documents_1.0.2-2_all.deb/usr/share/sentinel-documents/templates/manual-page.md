# Manual / Documentation Page

Topic: {{topic}}
Date: {{date}}
Prepared By: {{prepared_by}}

## Purpose
{{purpose}}

## Steps
1. {{step_one}}
2. {{step_two}}
3. {{step_three}}

## Notes
{{notes}}
