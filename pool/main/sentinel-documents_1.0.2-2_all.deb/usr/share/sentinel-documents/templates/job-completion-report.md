# Job Completion Report

Date: {{date}}
Job Code: {{job_code}}
Job Title: {{job_title}}
Customer: {{contact_name}}
Date Started: {{date_started}}
Date Completed: {{date_completed}}

## Work Summary
{{work_completed}}

## Materials Used
{{materials}}

## Completion Notes
{{completion_notes}}

## Customer Handoff
{{handoff_notes}}
