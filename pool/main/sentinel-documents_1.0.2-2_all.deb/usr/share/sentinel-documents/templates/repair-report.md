# Repair Report

Date: {{date}}
Job Code: {{job_code}}
Customer: {{contact_name}}

## Issue
{{issue}}

## Work Completed
{{work_completed}}

## Parts / Inventory
{{inventory_items}}

## Notes
{{notes}}
