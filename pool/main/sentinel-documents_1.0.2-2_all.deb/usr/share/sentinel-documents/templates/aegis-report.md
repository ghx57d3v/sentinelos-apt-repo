# AEGIS Report

Date: {{date}}
Prepared By: {{prepared_by}}

## Summary
{{summary}}

## Observations
{{observations}}

## Recommended Actions
{{recommended_actions}}
