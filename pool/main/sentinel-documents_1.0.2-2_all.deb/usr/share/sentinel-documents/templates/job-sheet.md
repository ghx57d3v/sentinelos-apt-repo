# Job Sheet

Date: {{date}}
Job Code: {{job_code}}
Job Title: {{job_title}}
Customer: {{contact_name}}
Status: {{job_status}}
Priority: {{priority}}
Date Started: {{date_started}}
Due Date: {{due_date}}
Location: {{job_location}}

## Job Description
{{job_description}}

## Materials / Inventory
{{materials}}

## Labour
{{labour}}

## Internal Notes
{{notes}}
