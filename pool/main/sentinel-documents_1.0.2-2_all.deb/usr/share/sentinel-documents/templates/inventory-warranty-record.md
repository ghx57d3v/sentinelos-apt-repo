# Inventory Warranty Record

Date: {{date}}
Item Code: {{item_code}}
Item Name: {{item_name}}
Serial Number: {{serial_number}}
Purchase Date: {{purchase_date}}
Supplier: {{supplier}}
Warranty Status: {{warranty_status}}
Warranty End: {{warranty_end}}

## Warranty Details
{{warranty_details}}

## Action Required
{{action_required}}

## Notes
{{notes}}
