# Job Repair Report

Date: {{date}}
Job Code: {{job_code}}
Job Title: {{job_title}}
Customer: {{contact_name}}
Asset / Item: {{item_name}}
Serial: {{serial_number}}

## Issue
{{issue}}

## Diagnosis
{{diagnosis}}

## Work Completed
{{work_completed}}

## Parts / Inventory
{{materials}}

## Result
{{result}}

## Notes
{{notes}}
