# Inventory Item Report

Date: {{date}}
Item Code: {{item_code}}
Item Name: {{item_name}}
Asset Tag: {{asset_tag}}
Category: {{item_category}}
Serial Number: {{serial_number}}
Model: {{model}}
Condition: {{condition}}
Location: {{location}}
Quantity: {{quantity}}
Purchase Date: {{purchase_date}}
Purchase Price: {{purchase_price}}
Supplier: {{supplier}}
Warranty Status: {{warranty_status}}
Warranty End: {{warranty_end}}

## Notes
{{notes}}
