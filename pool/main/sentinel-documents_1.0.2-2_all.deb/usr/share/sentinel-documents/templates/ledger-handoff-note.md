# Ledger Handoff Note

Date: {{date}}
Related Job: {{job_code}}
Contact: {{contact_name}}

## Summary
{{summary}}

## Amounts / Receipts
{{ledger_items}}

## Notes
{{notes}}
