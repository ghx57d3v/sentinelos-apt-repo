# Sentinel Documents v1.0.2

Program 116 Sentinel Documents v1.0.2 is the Stable Lock Consistency / Guarded Restore / V1 Handoff Patch over v1.0.0.

## Locked posture

- Local-only: true
- Network enabled: false
- Telemetry enabled: false
- Stable locked: true

## Added in v1.0.2

- Removed remaining user-facing pre-lock wording.
- Added guarded restore requiring `--confirm RESTORE_SENTINEL_DOCUMENTS`.
- Added v1 audit JSON command and audit export commands.
- Added v1 handoff bundle export.
- Added wrapper commands:
  - `sentinel-documents-stable-lock-report`
  - `sentinel-documents-v1-handoff`

## Core commands

```bash
sentinel-documents --health-json
sentinel-documents --aegis-status-json
sentinel-documents --stable-lock-report
sentinel-documents --audit-report-json
sentinel-documents --export-audit-json
sentinel-documents --export-audit-csv
sentinel-documents --export-v1-bundle
sentinel-documents --backup
sentinel-documents --restore-backup BACKUP.zip --confirm RESTORE_SENTINEL_DOCUMENTS
```

## v1 standard wrappers

```bash
sentinel-documents-stable-lock-report
sentinel-documents-v1-handoff
```
