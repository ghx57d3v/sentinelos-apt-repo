# Conditional AEGIS appearance policy

This package is intentionally absent from a normal SentinelOS conversion.
It depends on the complete public `aegis-sentinel-suite`, installs the
`AEGIS-Navy-Gold` GTK/Marco theme and uses the approved `SentinelOS-Dark`
gold icon package. Removing AEGIS removes this overlay without affecting the
SentinelOS Light or SentinelOS Dark themes.
