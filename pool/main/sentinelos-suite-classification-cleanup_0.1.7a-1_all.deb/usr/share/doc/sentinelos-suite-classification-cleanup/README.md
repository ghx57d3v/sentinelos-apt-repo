# SentinelOS v0.1.7a Suite Classification Cleanup

## Purpose

After v0.1.7, the Suite Completion gate was active and the local repository was valid, but the integration summary showed:

```text
unexpected_installed_blocked: 1
```

This patch corrects package-state classification so only packages with dpkg status `install ok installed` count as installed. Residual records such as `un`, removed packages, or dpkg database remnants are no longer treated as installed.

## Changes

- Updates SentinelOS identity to `v0.1.7a Suite Classification Cleanup`.
- Updates `sentinelos-suite-integration` to v0.1.7a.
- Adds explicit `--blocked` and `--unexpected` reporting modes.
- Keeps `--installed`, `--missing`, `--plan`, and `--summary` modes.
- Updates `sentinelctl` to include fixed reporting and classification output.
- Keeps report logging behavior from v0.1.6f/v0.1.6g.
- Keeps sysctl absolute path fallback from v0.1.6e.

## Safety scope

This patch does not install Ledger, Inventory, or any future apps. It does not remove applications. It does not enable AEGIS runtime, install AI models, alter MATE settings, change hardening posture, or overwrite Debian `/etc/os-release`.

## Validation

Run:

```bash
sentinelctl verify
sudo sentinelctl report
sentinelos-suite-integration --summary
sentinelos-suite-integration --blocked
sentinelos-suite-integration --unexpected
sentinelos-suite-completion --remaining
```

Expected:

```text
PATCH_LEVEL="v0.1.7a suite-classification-cleanup"
repo_metadata_valid: yes
unexpected_installed_blocked: 0
```
