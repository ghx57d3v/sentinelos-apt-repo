# SentinelOS Theme/Cursor Integration 1.1.0

SentinelOS uses two GTK/Marco themes:

- `SentinelOS-Light`
- `SentinelOS-Dark`

Cursor colour follows the active icon theme:

| Icon theme | Cursor |
|---|---|
| SentinelOS-Light | SentinelOS-Cursor-Light-Cyan |
| SentinelOS-Dark | SentinelOS-Cursor-Light-Cyan |
| SentinelOS-Green | SentinelOS-Cursor-Light-Green |
| SentinelOS-Purple | SentinelOS-Cursor-Light-Purple |
| SentinelOS-Red | SentinelOS-Cursor-Dark-Red |
| SentinelOS-Pink | SentinelOS-Cursor-Dark-Pink |

White and Black remain neutral manual choices. AEGIS Navy/Gold is excluded.
