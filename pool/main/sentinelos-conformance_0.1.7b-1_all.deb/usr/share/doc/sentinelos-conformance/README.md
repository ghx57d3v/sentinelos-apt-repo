SentinelOS v0.1.7b conformance and report tooling.
