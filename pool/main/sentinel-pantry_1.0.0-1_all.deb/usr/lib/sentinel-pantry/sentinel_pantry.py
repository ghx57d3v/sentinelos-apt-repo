#!/usr/bin/env python3
"""
Sentinel Pantry v1.0.0
Program 117 — SentinelOS Desktop Suite

v1.0 Stable Lock / User-Ready Baseline.
Local-only pantry and household stock manager.
No network access, no telemetry, no cloud dependency.
"""
from __future__ import annotations

import argparse
import csv
import datetime as _dt
import hashlib
import json
import os
import shutil
import sqlite3
import sys
from pathlib import Path
from typing import Any, Iterable, Optional

APP_NAME = "Sentinel Pantry"
APP_ID = "sentinel-pantry"
APP_VERSION = "1.0.0"
PROGRAM_NUMBER = "117"
NETWORK_CAPABLE = False

DATA_DIR = Path(os.environ.get("SENTINEL_PANTRY_HOME", Path.home() / ".local" / "share" / "sentinel-pantry"))
DB_PATH = Path(os.environ.get("SENTINEL_PANTRY_DB", DATA_DIR / "pantry.db"))
BACKUP_DIR = DATA_DIR / "backups"
EXPORT_DIR = DATA_DIR / "exports"
AUDIT_PATH = DATA_DIR / "audit.log"
MANIFEST_PATH = Path("/usr/share/sentinel-pantry/aegis_manifest.json")
AEGIS_CONTRACT_VERSION = "1.0"
AEGIS_EXPORT_FOLDER = Path("Knowledge") / "Household" / "Sentinel Pantry" / "Exports"
BASTION_REGISTRATION_PATH = DATA_DIR / "bastion_registration.json"

DEFAULT_AEGIS_VAULT_ROOT = Path(os.environ.get("AEGIS_VAULT_PATH", os.environ.get("AEGIS_VAULT_HOME", Path.home() / "AEGIS_Vault"))).expanduser()
DOCUMENTS_RECIPE_FALLBACK_DIR = Path(os.environ.get("SENTINEL_PANTRY_RECIPE_FALLBACK_DIR", Path.home() / "Documents" / "Recipies")).expanduser()


def resolve_recipe_storage() -> tuple[Path, Path, str, bool]:
    """Resolve recipe storage without creating an AEGIS Vault accidentally.

    Priority:
    1. Explicit SENTINEL_PANTRY_RECIPE_DB.
    2. Explicit SENTINEL_PANTRY_RECIPE_VAULT_DIR.
    3. Existing AEGIS vault root.
    4. ~/Documents/Recipies fallback when no vault exists on the device.
    """
    explicit_db = os.environ.get("SENTINEL_PANTRY_RECIPE_DB")
    if explicit_db:
        db_path = Path(explicit_db).expanduser()
        return DEFAULT_AEGIS_VAULT_ROOT, db_path.parent, "CUSTOM_RECIPE_DB", DEFAULT_AEGIS_VAULT_ROOT.exists()

    explicit_dir = os.environ.get("SENTINEL_PANTRY_RECIPE_VAULT_DIR")
    if explicit_dir:
        recipe_dir = Path(explicit_dir).expanduser()
        return DEFAULT_AEGIS_VAULT_ROOT, recipe_dir, "CUSTOM_RECIPE_DIR", DEFAULT_AEGIS_VAULT_ROOT.exists()

    if DEFAULT_AEGIS_VAULT_ROOT.exists() and DEFAULT_AEGIS_VAULT_ROOT.is_dir():
        recipe_dir = DEFAULT_AEGIS_VAULT_ROOT / "Knowledge" / "Household" / "Sentinel Pantry" / "Recipes"
        return DEFAULT_AEGIS_VAULT_ROOT, recipe_dir, "AEGIS_VAULT", True

    return DEFAULT_AEGIS_VAULT_ROOT, DOCUMENTS_RECIPE_FALLBACK_DIR, "DOCUMENTS_RECIPIES_FALLBACK", False


AEGIS_VAULT_ROOT, RECIPE_VAULT_DIR, RECIPE_STORAGE_LOCATION, AEGIS_VAULT_PRESENT = resolve_recipe_storage()
RECIPE_DB_PATH = RECIPE_VAULT_DIR / "sentinel_pantry_recipes.db"
if os.environ.get("SENTINEL_PANTRY_RECIPE_DB"):
    RECIPE_DB_PATH = Path(os.environ["SENTINEL_PANTRY_RECIPE_DB"]).expanduser()
RECIPE_STORAGE_POLICY = "AEGIS_VAULT_IF_PRESENT_DOCUMENTS_RECIPIES_FALLBACK"

THEME = {
    "bg": "#11151A",
    "panel": "#171D24",
    "panel2": "#202833",
    "field": "#202833",
    "fg": "#E8EDF2",
    "muted": "#AAB4BF",
    "gold": "#E19B00",
    "cyan": "#03C8FF",
    "danger": "#F05D5E",
    "ok": "#77D977",
    "warning": "#FFD166",
}

SCHEMA_VERSION = 9
DEFAULT_EXPIRY_SOON_DAYS = 30

CATEGORY_PRESETS = [
    "Pantry", "Fridge", "Freezer", "Cleaning", "Bathroom", "Pet Supplies",
    "Baby / Family", "Emergency Supplies", "Dry Goods", "Canned Food", "Baking",
    "Spices", "Breakfast", "Snacks", "Frozen", "Meat", "Fruit", "Vegetables",
    "Drinks", "Household", "Toiletries", "Medical", "Other",
]
LOCATION_PRESETS = [
    "Pantry", "Kitchen Cupboard", "Fridge", "Freezer", "Garage", "Shed", "Laundry",
    "Bathroom", "Emergency Stores", "Bug-out Kit", "Vehicle Kit", "Other",
]
UNIT_PRESETS = ["each", "kg", "g", "L", "mL", "pack", "box", "bag", "tin", "jar", "bottle", "roll", "tube"]
STATUS_FILTERS = ["All Active", "Good", "Low Stock", "Expiring Soon", "Expired", "Archived", "Bad Date"]
STORE_PRESETS = ["", "Aldi", "Coles", "Woolworths", "IGA", "Bunnings", "Chemist", "Costco", "Local Grocer", "Other"]
BARCODE_CATALOG_FIELDS = ["barcode", "item_name", "category", "unit", "location", "min_quantity", "preferred_store", "estimated_price", "calories_per_unit", "water_litres_per_unit", "notes", "created_at", "updated_at"]
READINESS_CATEGORY_PRESETS = [
    "", "Long-life Food", "Water", "Medical", "Batteries", "Fuel", "Hygiene",
    "Pet Supplies", "Tools", "Power", "Emergency Supplies", "Other",
]
EMERGENCY_CATEGORIES = {
    "Long-life Food", "Water", "Medical", "Batteries", "Fuel", "Hygiene",
    "Pet Supplies", "Tools", "Power", "Emergency Supplies",
}
READINESS_MINIMUMS = {
    "Long-life Food": "Aim for enough shelf-stable calories to cover the household reserve target.",
    "Water": "Minimum 3 litres per person per day plus extra for hygiene/cooking where practical.",
    "Medical": "Maintain first-aid, regular household medical supplies, and expiry rotation.",
    "Batteries": "Keep common battery sizes and charged power banks for lights/radios/devices.",
    "Fuel": "Track safe, legal fuel stores and rotation dates for generators/cooking/vehicle use.",
    "Hygiene": "Keep soap, toilet paper, disinfectant, bags, gloves, and cleaning consumables.",
    "Pet Supplies": "Keep food, medication, litter, and water allocation for animals.",
    "Tools": "Track essential repair, cooking, water, and shelter tools.",
    "Power": "Track chargers, inverter gear, solar/battery consumables, and spare cables.",
}
DEFAULT_CALORIES_PER_PERSON_DAY = 2000.0
DEFAULT_WATER_LITRES_PER_PERSON_DAY = 3.0
DEFAULT_RESERVE_DAYS_TARGET = 14
MEAL_TYPES = ["Breakfast", "Lunch", "Dinner", "Snack", "Prep", "Other"]
SHOPPING_STATUSES = ["Needed", "Urgent", "Bought", "Skipped"]
OPEN_SHOPPING_STATUSES = {"Needed", "Urgent"}
CLOSED_SHOPPING_STATUSES = {"Bought", "Skipped"}


def now_iso() -> str:
    return _dt.datetime.now().replace(microsecond=0).isoformat()


def today() -> _dt.date:
    return _dt.date.today()


def ensure_dirs() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    EXPORT_DIR.mkdir(parents=True, exist_ok=True)
    RECIPE_DB_PATH.parent.mkdir(parents=True, exist_ok=True)


def connect() -> sqlite3.Connection:
    ensure_dirs()
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    migrate(conn)
    ensure_recipe_vault(conn)
    return conn


def migrate(conn: sqlite3.Connection) -> None:
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS meta (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            category TEXT DEFAULT '',
            location TEXT DEFAULT '',
            quantity REAL NOT NULL DEFAULT 0,
            unit TEXT DEFAULT 'each',
            min_quantity REAL NOT NULL DEFAULT 0,
            expiry_date TEXT DEFAULT '',
            purchase_date TEXT DEFAULT '',
            barcode TEXT DEFAULT '',
            notes TEXT DEFAULT '',
            archived INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_items_name ON items(name);
        CREATE INDEX IF NOT EXISTS idx_items_category ON items(category);
        CREATE INDEX IF NOT EXISTS idx_items_location ON items(location);
        CREATE INDEX IF NOT EXISTS idx_items_expiry ON items(expiry_date);
        CREATE TABLE IF NOT EXISTS stock_moves (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            item_id INTEGER NOT NULL,
            delta REAL NOT NULL,
            reason TEXT NOT NULL,
            notes TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            FOREIGN KEY(item_id) REFERENCES items(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS shopping_list (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            item_name TEXT NOT NULL,
            target_quantity REAL NOT NULL DEFAULT 1,
            unit TEXT DEFAULT 'each',
            category TEXT DEFAULT '',
            source TEXT DEFAULT 'manual',
            checked INTEGER NOT NULL DEFAULT 0,
            status TEXT NOT NULL DEFAULT 'Needed',
            preferred_store TEXT DEFAULT '',
            estimated_price REAL NOT NULL DEFAULT 0,
            notes TEXT DEFAULT '',
            pantry_item_id INTEGER DEFAULT NULL,
            bought_at TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS shopping_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            shopping_id INTEGER DEFAULT NULL,
            item_name TEXT NOT NULL,
            target_quantity REAL NOT NULL DEFAULT 1,
            unit TEXT DEFAULT 'each',
            category TEXT DEFAULT '',
            preferred_store TEXT DEFAULT '',
            estimated_price REAL NOT NULL DEFAULT 0,
            action TEXT NOT NULL,
            status TEXT DEFAULT '',
            notes TEXT DEFAULT '',
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS waste_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            item_id INTEGER DEFAULT NULL,
            item_name TEXT NOT NULL,
            quantity REAL NOT NULL DEFAULT 0,
            unit TEXT DEFAULT 'each',
            category TEXT DEFAULT '',
            reason TEXT DEFAULT '',
            notes TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            FOREIGN KEY(item_id) REFERENCES items(id) ON DELETE SET NULL
        );
        CREATE TABLE IF NOT EXISTS barcode_catalog (
            barcode TEXT PRIMARY KEY,
            item_name TEXT NOT NULL,
            category TEXT DEFAULT '',
            unit TEXT DEFAULT 'each',
            location TEXT DEFAULT 'Pantry',
            min_quantity REAL NOT NULL DEFAULT 0,
            preferred_store TEXT DEFAULT '',
            estimated_price REAL NOT NULL DEFAULT 0,
            calories_per_unit REAL NOT NULL DEFAULT 0,
            water_litres_per_unit REAL NOT NULL DEFAULT 0,
            notes TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS audit_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            action TEXT NOT NULL,
            details TEXT DEFAULT '',
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS migration_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            from_schema TEXT DEFAULT '',
            to_schema TEXT NOT NULL,
            app_version TEXT NOT NULL,
            notes TEXT DEFAULT '',
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS recipes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            category TEXT DEFAULT '',
            servings REAL NOT NULL DEFAULT 1,
            instructions TEXT DEFAULT '',
            notes TEXT DEFAULT '',
            archived INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS recipe_ingredients (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            recipe_id INTEGER NOT NULL,
            item_name TEXT NOT NULL,
            quantity REAL NOT NULL DEFAULT 1,
            unit TEXT DEFAULT 'each',
            pantry_item_id INTEGER DEFAULT NULL,
            required INTEGER NOT NULL DEFAULT 1,
            notes TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY(recipe_id) REFERENCES recipes(id) ON DELETE CASCADE,
            FOREIGN KEY(pantry_item_id) REFERENCES items(id) ON DELETE SET NULL
        );
        CREATE TABLE IF NOT EXISTS meal_plan (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            plan_date TEXT NOT NULL,
            meal_type TEXT DEFAULT 'Dinner',
            recipe_id INTEGER NOT NULL,
            servings REAL NOT NULL DEFAULT 1,
            status TEXT DEFAULT 'Planned',
            notes TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY(recipe_id) REFERENCES recipes(id) ON DELETE CASCADE
        );
        """
    )
    existing_item_cols = {r[1] for r in conn.execute("PRAGMA table_info(items)").fetchall()}
    item_columns = {
        "opened_date": "TEXT DEFAULT ''",
        "shelf_life_notes": "TEXT DEFAULT ''",
        "batch_code": "TEXT DEFAULT ''",
        "emergency_reserve": "INTEGER NOT NULL DEFAULT 0",
        "do_not_consume": "INTEGER NOT NULL DEFAULT 0",
        "readiness_category": "TEXT DEFAULT ''",
        "calories_per_unit": "REAL NOT NULL DEFAULT 0",
        "water_litres_per_unit": "REAL NOT NULL DEFAULT 0",
    }
    for col, ddl in item_columns.items():
        if col not in existing_item_cols:
            conn.execute(f"ALTER TABLE items ADD COLUMN {col} {ddl}")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_items_opened ON items(opened_date)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_items_batch ON items(batch_code)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_items_reserve ON items(emergency_reserve)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_items_readiness_category ON items(readiness_category)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_items_barcode ON items(barcode)")
    existing_barcode_cols = {r[1] for r in conn.execute("PRAGMA table_info(barcode_catalog)").fetchall()}
    barcode_catalog_columns = {
        "preferred_store": "TEXT DEFAULT ''",
        "estimated_price": "REAL NOT NULL DEFAULT 0",
        "calories_per_unit": "REAL NOT NULL DEFAULT 0",
        "water_litres_per_unit": "REAL NOT NULL DEFAULT 0",
    }
    for col, ddl in barcode_catalog_columns.items():
        if existing_barcode_cols and col not in existing_barcode_cols:
            conn.execute(f"ALTER TABLE barcode_catalog ADD COLUMN {col} {ddl}")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_barcode_catalog_name ON barcode_catalog(item_name)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_barcode_catalog_category ON barcode_catalog(category)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_waste_created ON waste_log(created_at)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_waste_item ON waste_log(item_id)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_recipes_name ON recipes(name)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_recipes_archived ON recipes(archived)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_recipe_ingredients_recipe ON recipe_ingredients(recipe_id)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_recipe_ingredients_item_name ON recipe_ingredients(item_name)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_meal_plan_date ON meal_plan(plan_date)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_meal_plan_recipe ON meal_plan(recipe_id)")
    existing_cols = {r[1] for r in conn.execute("PRAGMA table_info(shopping_list)").fetchall()}
    shopping_columns = {
        "status": "TEXT NOT NULL DEFAULT 'Needed'",
        "preferred_store": "TEXT DEFAULT ''",
        "estimated_price": "REAL NOT NULL DEFAULT 0",
        "notes": "TEXT DEFAULT ''",
        "pantry_item_id": "INTEGER DEFAULT NULL",
        "bought_at": "TEXT DEFAULT ''",
    }
    for col, ddl in shopping_columns.items():
        if col not in existing_cols:
            conn.execute(f"ALTER TABLE shopping_list ADD COLUMN {col} {ddl}")
    conn.execute("UPDATE shopping_list SET status='Bought', bought_at=COALESCE(NULLIF(bought_at,''), updated_at) WHERE checked=1 AND (status IS NULL OR status='' OR status='Needed')")
    conn.execute("UPDATE shopping_list SET status='Needed' WHERE status IS NULL OR status='' ")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_shopping_status ON shopping_list(status)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_shopping_store ON shopping_list(preferred_store)")
    previous_schema_row = conn.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()
    previous_schema = str(previous_schema_row["value"]) if previous_schema_row else "0"
    if previous_schema != str(SCHEMA_VERSION):
        conn.execute(
            "INSERT INTO migration_events(from_schema, to_schema, app_version, notes, created_at) VALUES(?,?,?,?,?)",
            (previous_schema, str(SCHEMA_VERSION), APP_VERSION, "automatic startup migration", now_iso()),
        )
    conn.execute("INSERT OR REPLACE INTO meta(key, value) VALUES('schema_version', ?)", (str(SCHEMA_VERSION),))
    conn.execute(
        "INSERT OR IGNORE INTO settings(key, value, updated_at) VALUES(?,?,?)",
        ("expiring_soon_days", str(DEFAULT_EXPIRY_SOON_DAYS), now_iso()),
    )
    for key, value in {
        "household_members": "1",
        "reserve_days_target": str(DEFAULT_RESERVE_DAYS_TARGET),
        "calories_per_person_day": str(DEFAULT_CALORIES_PER_PERSON_DAY),
        "water_litres_per_person_day": str(DEFAULT_WATER_LITRES_PER_PERSON_DAY),
        "default_currency": "AUD",
        "default_store": "",
        "first_run_setup_complete": "0",
        "v1_stable_lock_acknowledged": "1",
    }.items():
        conn.execute("INSERT OR IGNORE INTO settings(key, value, updated_at) VALUES(?,?,?)", (key, value, now_iso()))
    conn.commit()


def recipe_connect() -> sqlite3.Connection:
    """Open the resolved recipe database.

    Recipe-book and meal-plan records are intentionally stored outside the
    ordinary pantry runtime database. When an AEGIS Vault exists, recipes live
    in the vault. When no vault exists on the device, the safe local fallback is
    ~/Documents/Recipies. The pantry database may retain old compatibility
    tables, but all current recipe writes go to RECIPE_DB_PATH.
    """
    ensure_dirs()
    rconn = sqlite3.connect(RECIPE_DB_PATH)
    rconn.row_factory = sqlite3.Row
    rconn.execute("PRAGMA foreign_keys = ON")
    migrate_recipe_vault(rconn)
    return rconn


def migrate_recipe_vault(rconn: sqlite3.Connection) -> None:
    rconn.executescript(
        """
        CREATE TABLE IF NOT EXISTS meta (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS recipes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            category TEXT DEFAULT '',
            servings REAL NOT NULL DEFAULT 1,
            instructions TEXT DEFAULT '',
            notes TEXT DEFAULT '',
            archived INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS recipe_ingredients (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            recipe_id INTEGER NOT NULL,
            item_name TEXT NOT NULL,
            quantity REAL NOT NULL DEFAULT 1,
            unit TEXT DEFAULT 'each',
            pantry_item_id INTEGER DEFAULT NULL,
            required INTEGER NOT NULL DEFAULT 1,
            notes TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY(recipe_id) REFERENCES recipes(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS meal_plan (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            plan_date TEXT NOT NULL,
            meal_type TEXT DEFAULT 'Dinner',
            recipe_id INTEGER NOT NULL,
            servings REAL NOT NULL DEFAULT 1,
            status TEXT DEFAULT 'Planned',
            notes TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY(recipe_id) REFERENCES recipes(id) ON DELETE CASCADE
        );
        """
    )
    rconn.execute("CREATE INDEX IF NOT EXISTS idx_recipes_name ON recipes(name)")
    rconn.execute("CREATE INDEX IF NOT EXISTS idx_recipes_archived ON recipes(archived)")
    rconn.execute("CREATE INDEX IF NOT EXISTS idx_recipe_ingredients_recipe ON recipe_ingredients(recipe_id)")
    rconn.execute("CREATE INDEX IF NOT EXISTS idx_recipe_ingredients_item_name ON recipe_ingredients(item_name)")
    rconn.execute("CREATE INDEX IF NOT EXISTS idx_meal_plan_date ON meal_plan(plan_date)")
    rconn.execute("CREATE INDEX IF NOT EXISTS idx_meal_plan_recipe ON meal_plan(recipe_id)")
    rconn.execute("INSERT OR REPLACE INTO meta(key, value) VALUES('schema_version', ?)", (str(SCHEMA_VERSION),))
    rconn.execute("INSERT OR REPLACE INTO meta(key, value) VALUES('storage_policy', ?)", (RECIPE_STORAGE_POLICY,))
    rconn.execute("INSERT OR REPLACE INTO meta(key, value) VALUES('owner', ?)", (APP_ID,))
    rconn.commit()


def ensure_recipe_vault(conn: sqlite3.Connection | None = None) -> None:
    """Create the resolved recipe store and migrate old local recipes once."""
    with recipe_connect() as rconn:
        if conn is None:
            return
        try:
            vault_count = int(rconn.execute("SELECT COUNT(*) FROM recipes").fetchone()[0])
            legacy_count = int(conn.execute("SELECT COUNT(*) FROM recipes").fetchone()[0])
        except Exception:
            return
        if legacy_count <= 0:
            return
        for r in conn.execute("SELECT * FROM recipes ORDER BY id").fetchall():
            rconn.execute(
                """INSERT OR IGNORE INTO recipes(id, name, category, servings, instructions, notes, archived, created_at, updated_at)
                VALUES(?,?,?,?,?,?,?,?,?)""",
                (r["id"], r["name"], r["category"], r["servings"], r["instructions"], r["notes"], r["archived"], r["created_at"], r["updated_at"]),
            )
        for ing in conn.execute("SELECT * FROM recipe_ingredients ORDER BY id").fetchall():
            rconn.execute(
                """INSERT OR IGNORE INTO recipe_ingredients(id, recipe_id, item_name, quantity, unit, pantry_item_id, required, notes, created_at, updated_at)
                VALUES(?,?,?,?,?,?,?,?,?,?)""",
                (ing["id"], ing["recipe_id"], ing["item_name"], ing["quantity"], ing["unit"], ing["pantry_item_id"], ing["required"], ing["notes"], ing["created_at"], ing["updated_at"]),
            )
        for m in conn.execute("SELECT * FROM meal_plan ORDER BY id").fetchall():
            rconn.execute(
                """INSERT OR IGNORE INTO meal_plan(id, plan_date, meal_type, recipe_id, servings, status, notes, created_at, updated_at)
                VALUES(?,?,?,?,?,?,?,?,?)""",
                (m["id"], m["plan_date"], m["meal_type"], m["recipe_id"], m["servings"], m["status"], m["notes"], m["created_at"], m["updated_at"]),
            )
        rconn.execute("INSERT OR REPLACE INTO meta(key, value) VALUES('legacy_migrated_at', ?)", (now_iso(),))
        rconn.execute("INSERT OR REPLACE INTO meta(key, value) VALUES('legacy_source', ?)", (str(DB_PATH),))
        rconn.commit()
        conn.execute("DELETE FROM meal_plan")
        conn.execute("DELETE FROM recipe_ingredients")
        conn.execute("DELETE FROM recipes")
        conn.commit()
        audit(conn, "migrate_recipes_to_recipe_store", {"recipes": legacy_count, "recipe_db": str(RECIPE_DB_PATH), "legacy_tables_cleared": True})


def next_recipe_id() -> int:
    with recipe_connect() as rconn:
        row = rconn.execute("SELECT COALESCE(MAX(id), 0) + 1 FROM recipes").fetchone()
        return int(row[0] or 1)


def recipe_book_total() -> int:
    with recipe_connect() as rconn:
        row = rconn.execute("SELECT COUNT(*) FROM recipes WHERE archived=0").fetchone()
        return int(row[0] or 0)


def audit(conn: sqlite3.Connection, action: str, details: dict[str, Any] | str = "") -> None:
    try:
        payload = json.dumps(details, sort_keys=True) if isinstance(details, dict) else str(details)
        conn.execute("INSERT INTO audit_events(action, details, created_at) VALUES(?,?,?)", (action, payload, now_iso()))
        conn.commit()
        ensure_dirs()
        with AUDIT_PATH.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps({"time": now_iso(), "action": action, "details": details}, sort_keys=True) + "\n")
    except Exception:
        # Audit should never break a user workflow.
        pass


def get_setting(conn: sqlite3.Connection, key: str, default: str = "") -> str:
    row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    return str(row["value"]) if row else default


def expiring_soon_days(conn: sqlite3.Connection) -> int:
    try:
        return max(1, int(get_setting(conn, "expiring_soon_days", str(DEFAULT_EXPIRY_SOON_DAYS))))
    except Exception:
        return DEFAULT_EXPIRY_SOON_DAYS


def set_setting(conn: sqlite3.Connection, key: str, value: Any) -> None:
    conn.execute("INSERT OR REPLACE INTO settings(key, value, updated_at) VALUES(?,?,?)", (key, str(value), now_iso()))
    conn.commit()
    audit(conn, "set_setting", {"key": key, "value": str(value)})


def setting_int(conn: sqlite3.Connection, key: str, default: int) -> int:
    try:
        return max(1, int(float(get_setting(conn, key, str(default)))))
    except Exception:
        return default


def setting_float(conn: sqlite3.Connection, key: str, default: float) -> float:
    try:
        return max(0.01, float(get_setting(conn, key, str(default))))
    except Exception:
        return default


def household_members(conn: sqlite3.Connection) -> int:
    return setting_int(conn, "household_members", 1)


def reserve_days_target(conn: sqlite3.Connection) -> int:
    return setting_int(conn, "reserve_days_target", DEFAULT_RESERVE_DAYS_TARGET)


def boolish(value: Any) -> int:
    if isinstance(value, bool):
        return 1 if value else 0
    if value is None:
        return 0
    return 1 if str(value).strip().lower() in {"1", "true", "yes", "y", "on", "reserve", "locked"} else 0


def parse_date(value: str | None) -> str:
    if not value:
        return ""
    value = value.strip()
    if not value:
        return ""
    try:
        return _dt.date.fromisoformat(value).isoformat()
    except ValueError as exc:
        raise ValueError(f"Invalid date '{value}'. Use YYYY-MM-DD.") from exc


def _safe_date(value: str) -> Optional[_dt.date]:
    try:
        return _dt.date.fromisoformat(value)
    except Exception:
        return None


def fnum(value: Any, default: float = 0.0) -> float:
    if value in (None, ""):
        return default
    return float(value)


def low_stock_flag(row: sqlite3.Row) -> bool:
    return float(row["min_quantity"] or 0) > 0 and float(row["quantity"] or 0) <= float(row["min_quantity"] or 0)


def base_status_for_item(row: sqlite3.Row, expiry_days: int = DEFAULT_EXPIRY_SOON_DAYS) -> str:
    if row["archived"]:
        return "Archived"
    expiry = (row["expiry_date"] or "").strip()
    if expiry:
        d = _safe_date(expiry)
        if d is None:
            return "Bad Date"
        if d < today():
            return "Expired"
        if d <= today() + _dt.timedelta(days=expiry_days):
            return "Expiring Soon"
    if low_stock_flag(row):
        return "Low Stock"
    return "Good"


def status_for_item(row: sqlite3.Row, expiry_days: int = DEFAULT_EXPIRY_SOON_DAYS) -> str:
    if row["archived"]:
        return "Archived"
    status = base_status_for_item(row, expiry_days)
    if status not in {"Low Stock", "Good", "Archived"} and low_stock_flag(row):
        return f"{status} + Low Stock"
    return status


def status_matches_filter(row: sqlite3.Row, status_filter: str, expiry_days: int = DEFAULT_EXPIRY_SOON_DAYS) -> bool:
    status_filter = status_filter or "All Active"
    if status_filter == "All Active":
        return not bool(row["archived"])
    if status_filter == "Archived":
        return bool(row["archived"])
    if row["archived"]:
        return False
    base = base_status_for_item(row, expiry_days)
    if status_filter == "Low Stock":
        return low_stock_flag(row)
    return base == status_filter


def add_item(conn: sqlite3.Connection, data: dict[str, Any]) -> int:
    ts = now_iso()
    vals = {
        "name": str(data.get("name", "")).strip(),
        "category": str(data.get("category", "")).strip(),
        "location": str(data.get("location", "")).strip(),
        "quantity": fnum(data.get("quantity"), 0.0),
        "unit": str(data.get("unit", "each")).strip() or "each",
        "min_quantity": fnum(data.get("min_quantity"), 0.0),
        "expiry_date": parse_date(data.get("expiry_date", "")),
        "purchase_date": parse_date(data.get("purchase_date", "")),
        "opened_date": parse_date(data.get("opened_date", "")),
        "barcode": str(data.get("barcode", "")).strip(),
        "batch_code": str(data.get("batch_code", "")).strip(),
        "shelf_life_notes": str(data.get("shelf_life_notes", "")).strip(),
        "emergency_reserve": boolish(data.get("emergency_reserve", data.get("reserve", 0))),
        "do_not_consume": boolish(data.get("do_not_consume", data.get("locked", 0))),
        "readiness_category": str(data.get("readiness_category", "")).strip(),
        "calories_per_unit": fnum(data.get("calories_per_unit"), 0.0),
        "water_litres_per_unit": fnum(data.get("water_litres_per_unit"), 0.0),
        "notes": str(data.get("notes", "")).strip(),
        "created_at": ts,
        "updated_at": ts,
    }
    if not vals["name"]:
        raise ValueError("Item name is required.")
    cur = conn.execute(
        """INSERT INTO items
        (name, category, location, quantity, unit, min_quantity, expiry_date, purchase_date, opened_date, barcode, batch_code, shelf_life_notes, emergency_reserve, do_not_consume, readiness_category, calories_per_unit, water_litres_per_unit, notes, created_at, updated_at)
        VALUES (:name, :category, :location, :quantity, :unit, :min_quantity, :expiry_date, :purchase_date, :opened_date, :barcode, :batch_code, :shelf_life_notes, :emergency_reserve, :do_not_consume, :readiness_category, :calories_per_unit, :water_litres_per_unit, :notes, :created_at, :updated_at)""",
        vals,
    )
    item_id = int(cur.lastrowid)
    conn.execute("INSERT INTO stock_moves(item_id, delta, reason, notes, created_at) VALUES(?,?,?,?,?)", (item_id, vals["quantity"], "initial", "", ts))
    conn.commit()
    audit(conn, "add_item", {"id": item_id, "name": vals["name"]})
    return item_id


def update_item(conn: sqlite3.Connection, item_id: int, data: dict[str, Any]) -> None:
    existing = conn.execute("SELECT * FROM items WHERE id=?", (item_id,)).fetchone()
    if not existing:
        raise ValueError(f"No item found with id {item_id}.")
    vals = {
        "id": item_id,
        "name": str(data.get("name", existing["name"])).strip(),
        "category": str(data.get("category", existing["category"])).strip(),
        "location": str(data.get("location", existing["location"])).strip(),
        "quantity": fnum(data.get("quantity", existing["quantity"]), 0.0),
        "unit": str(data.get("unit", existing["unit"])).strip() or "each",
        "min_quantity": fnum(data.get("min_quantity", existing["min_quantity"]), 0.0),
        "expiry_date": parse_date(data.get("expiry_date", existing["expiry_date"])),
        "purchase_date": parse_date(data.get("purchase_date", existing["purchase_date"])),
        "opened_date": parse_date(data.get("opened_date", existing["opened_date"] if "opened_date" in existing.keys() else "")),
        "barcode": str(data.get("barcode", existing["barcode"])).strip(),
        "batch_code": str(data.get("batch_code", existing["batch_code"] if "batch_code" in existing.keys() else "")).strip(),
        "shelf_life_notes": str(data.get("shelf_life_notes", existing["shelf_life_notes"] if "shelf_life_notes" in existing.keys() else "")).strip(),
        "emergency_reserve": boolish(data.get("emergency_reserve", existing["emergency_reserve"] if "emergency_reserve" in existing.keys() else 0)),
        "do_not_consume": boolish(data.get("do_not_consume", existing["do_not_consume"] if "do_not_consume" in existing.keys() else 0)),
        "readiness_category": str(data.get("readiness_category", existing["readiness_category"] if "readiness_category" in existing.keys() else "")).strip(),
        "calories_per_unit": fnum(data.get("calories_per_unit", existing["calories_per_unit"] if "calories_per_unit" in existing.keys() else 0), 0.0),
        "water_litres_per_unit": fnum(data.get("water_litres_per_unit", existing["water_litres_per_unit"] if "water_litres_per_unit" in existing.keys() else 0), 0.0),
        "notes": str(data.get("notes", existing["notes"])).strip(),
        "updated_at": now_iso(),
    }
    if not vals["name"]:
        raise ValueError("Item name is required.")
    old_qty = float(existing["quantity"] or 0)
    conn.execute(
        """UPDATE items SET
        name=:name, category=:category, location=:location, quantity=:quantity, unit=:unit,
        min_quantity=:min_quantity, expiry_date=:expiry_date, purchase_date=:purchase_date, opened_date=:opened_date,
        barcode=:barcode, batch_code=:batch_code, shelf_life_notes=:shelf_life_notes,
        emergency_reserve=:emergency_reserve, do_not_consume=:do_not_consume, readiness_category=:readiness_category,
        calories_per_unit=:calories_per_unit, water_litres_per_unit=:water_litres_per_unit,
        notes=:notes, updated_at=:updated_at
        WHERE id=:id""",
        vals,
    )
    delta = vals["quantity"] - old_qty
    if delta:
        conn.execute("INSERT INTO stock_moves(item_id, delta, reason, notes, created_at) VALUES(?,?,?,?,?)", (item_id, delta, "manual_adjust", "", now_iso()))
    conn.commit()
    audit(conn, "update_item", {"id": item_id, "name": vals["name"]})


def archive_item(conn: sqlite3.Connection, item_id: int, archived: bool = True) -> None:
    conn.execute("UPDATE items SET archived=?, updated_at=? WHERE id=?", (1 if archived else 0, now_iso(), item_id))
    conn.commit()
    audit(conn, "archive_item" if archived else "restore_item", {"id": item_id})


def delete_item(conn: sqlite3.Connection, item_id: int) -> None:
    conn.execute("DELETE FROM items WHERE id=?", (item_id,))
    conn.commit()
    audit(conn, "delete_item", {"id": item_id})


def adjust_stock(conn: sqlite3.Connection, item_id: int, delta: float, reason: str, notes: str = "") -> float:
    row = conn.execute("SELECT * FROM items WHERE id=?", (item_id,)).fetchone()
    if not row:
        raise ValueError(f"No item found with id {item_id}.")
    delta = float(delta)
    if delta == 0:
        raise ValueError("Amount must not be zero.")
    current = float(row["quantity"] or 0)
    new_qty = max(0.0, current + delta)
    effective_delta = new_qty - current
    conn.execute("UPDATE items SET quantity=?, updated_at=? WHERE id=?", (new_qty, now_iso(), item_id))
    conn.execute("INSERT INTO stock_moves(item_id, delta, reason, notes, created_at) VALUES(?,?,?,?,?)", (item_id, effective_delta, reason, notes, now_iso()))
    conn.commit()
    audit(conn, reason, {"id": item_id, "delta": effective_delta, "new_quantity": new_qty})
    return new_qty


def consume_item(conn: sqlite3.Connection, item_id: int, amount: float, reason: str = "consume", notes: str = "") -> None:
    amount = float(amount)
    if amount <= 0:
        raise ValueError("Amount must be greater than zero.")
    adjust_stock(conn, item_id, -amount, reason, notes)


def restock_item(conn: sqlite3.Connection, item_id: int, amount: float, notes: str = "") -> None:
    amount = float(amount)
    if amount <= 0:
        raise ValueError("Amount must be greater than zero.")
    adjust_stock(conn, item_id, amount, "restock", notes)


def list_items(
    conn: sqlite3.Connection,
    include_archived: bool = False,
    query: str = "",
    category: str = "",
    location: str = "",
    status_filter: str = "All Active",
    low_only: bool = False,
    expiry_days: int = DEFAULT_EXPIRY_SOON_DAYS,
) -> list[sqlite3.Row]:
    sql = "SELECT * FROM items WHERE 1=1"
    params: list[Any] = []
    if not include_archived and status_filter != "Archived":
        sql += " AND archived=0"
    if query:
        q = f"%{query.lower()}%"
        sql += " AND (lower(name) LIKE ? OR lower(category) LIKE ? OR lower(location) LIKE ? OR lower(notes) LIKE ? OR lower(barcode) LIKE ?)"
        params += [q, q, q, q, q]
    if category:
        sql += " AND category=?"
        params.append(category)
    if location:
        sql += " AND location=?"
        params.append(location)
    sql += " ORDER BY CASE WHEN expiry_date='' THEN 1 ELSE 0 END, expiry_date ASC, name COLLATE NOCASE ASC"
    rows = list(conn.execute(sql, params).fetchall())
    if low_only:
        rows = [r for r in rows if low_stock_flag(r) and not bool(r["archived"])]
    if status_filter and status_filter != "All Active":
        rows = [r for r in rows if status_matches_filter(r, status_filter, expiry_days)]
    elif status_filter == "All Active":
        rows = [r for r in rows if not bool(r["archived"])]
    return rows


def low_stock_items(conn: sqlite3.Connection) -> list[sqlite3.Row]:
    return list(conn.execute("SELECT * FROM items WHERE archived=0 AND min_quantity > 0 AND quantity <= min_quantity ORDER BY name COLLATE NOCASE").fetchall())


def expiring_items(conn: sqlite3.Connection, days: int = DEFAULT_EXPIRY_SOON_DAYS) -> list[sqlite3.Row]:
    limit = (today() + _dt.timedelta(days=days)).isoformat()
    return list(conn.execute("SELECT * FROM items WHERE archived=0 AND expiry_date != '' AND expiry_date <= ? ORDER BY expiry_date ASC, name COLLATE NOCASE", (limit,)).fetchall())


def expiring_soon_items(conn: sqlite3.Connection, days: int = DEFAULT_EXPIRY_SOON_DAYS) -> list[sqlite3.Row]:
    start = today().isoformat()
    limit = (today() + _dt.timedelta(days=days)).isoformat()
    return list(conn.execute("SELECT * FROM items WHERE archived=0 AND expiry_date != '' AND expiry_date >= ? AND expiry_date <= ? ORDER BY expiry_date ASC, name COLLATE NOCASE", (start, limit)).fetchall())


def expired_items(conn: sqlite3.Connection) -> list[sqlite3.Row]:
    return list(conn.execute("SELECT * FROM items WHERE archived=0 AND expiry_date != '' AND expiry_date < ? ORDER BY expiry_date ASC, name COLLATE NOCASE", (today().isoformat(),)).fetchall())


def days_until_expiry(row: sqlite3.Row) -> Optional[int]:
    expiry = (row["expiry_date"] or "").strip()
    if not expiry:
        return None
    d = _safe_date(expiry)
    if d is None:
        return None
    return (d - today()).days


def item_is_opened(row: sqlite3.Row) -> bool:
    return bool((row["opened_date"] or "").strip()) if "opened_date" in row.keys() else False


def rotation_priority(row: sqlite3.Row, expiry_days: int = DEFAULT_EXPIRY_SOON_DAYS) -> tuple[int, str]:
    """Return a stable use-first priority tuple: lower score means higher priority."""
    if row["archived"]:
        return (99, "Archived")
    if low_stock_flag(row):
        low_note = " + Low Stock"
    else:
        low_note = ""
    expiry_raw = (row["expiry_date"] or "").strip()
    if expiry_raw:
        d = _safe_date(expiry_raw)
        if d is None:
            return (8, "Bad Date" + low_note)
        delta = (d - today()).days
        if delta < 0:
            return (0, "Expired" + low_note)
        if delta <= 3:
            return (1, "Use Immediately" + low_note)
        if delta <= 7:
            return (2, "Use This Week" + low_note)
        if delta <= expiry_days:
            return (3, "Use Soon" + low_note)
    if item_is_opened(row):
        return (4, "Opened" + low_note)
    if low_stock_flag(row):
        return (6, "Low Stock")
    return (10, "Normal")


def use_first_items(conn: sqlite3.Connection, limit: int = 50, include_low_only: bool = False) -> list[sqlite3.Row]:
    expiry_days = expiring_soon_days(conn)
    rows = list(conn.execute("SELECT * FROM items WHERE archived=0 ORDER BY CASE WHEN expiry_date='' THEN 1 ELSE 0 END, expiry_date ASC, name COLLATE NOCASE").fetchall())
    scored = []
    for r in rows:
        score, label = rotation_priority(r, expiry_days)
        if score <= 6 or (include_low_only and low_stock_flag(r)):
            scored.append((score, days_until_expiry(r) if days_until_expiry(r) is not None else 99999, r["name"].lower(), r))
    scored.sort(key=lambda x: (x[0], x[1], x[2]))
    return [r for *_ignore, r in scored[: max(1, int(limit))]]


def mark_item_opened(conn: sqlite3.Connection, item_id: int, opened_date: str = "") -> None:
    row = conn.execute("SELECT * FROM items WHERE id=?", (item_id,)).fetchone()
    if not row:
        raise ValueError(f"No item found with id {item_id}.")
    opened = parse_date(opened_date) if opened_date else today().isoformat()
    conn.execute("UPDATE items SET opened_date=?, updated_at=? WHERE id=?", (opened, now_iso(), item_id))
    conn.commit()
    audit(conn, "mark_item_opened", {"id": item_id, "opened_date": opened})


def waste_item(conn: sqlite3.Connection, item_id: int, quantity: float, reason: str = "waste", notes: str = "") -> int:
    row = conn.execute("SELECT * FROM items WHERE id=?", (item_id,)).fetchone()
    if not row:
        raise ValueError(f"No item found with id {item_id}.")
    quantity = float(quantity)
    if quantity <= 0:
        raise ValueError("Waste quantity must be greater than zero.")
    consume_item(conn, item_id, quantity, reason="waste", notes=notes or reason)
    cur = conn.execute(
        """INSERT INTO waste_log(item_id, item_name, quantity, unit, category, reason, notes, created_at)
        VALUES(?,?,?,?,?,?,?,?)""",
        (item_id, row["name"], quantity, row["unit"] or "each", row["category"] or "", reason.strip() or "waste", notes.strip(), now_iso()),
    )
    conn.commit()
    wid = int(cur.lastrowid)
    audit(conn, "waste_item", {"waste_id": wid, "item_id": item_id, "quantity": quantity, "reason": reason})
    return wid


def list_waste(conn: sqlite3.Connection, limit: int = 100) -> list[sqlite3.Row]:
    return list(conn.execute("SELECT * FROM waste_log ORDER BY id DESC LIMIT ?", (int(limit),)).fetchall())


def export_waste_csv(conn: sqlite3.Connection, path: str | Path) -> Path:
    path = Path(path).expanduser()
    if path.is_dir():
        path = path / f"sentinel-pantry-waste-{today().isoformat()}.csv"
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = ["id", "item_id", "item_name", "quantity", "unit", "category", "reason", "notes", "created_at"]
    rows = list_waste(conn, 100000)
    with path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=fields)
        writer.writeheader()
        for r in rows:
            writer.writerow({k: r[k] for k in fields})
    audit(conn, "export_waste_csv", {"path": str(path), "rows": len(rows)})
    return path


def is_reserve_item(row: sqlite3.Row) -> bool:
    category = (row["category"] or "").strip()
    readiness_category = row["readiness_category"] if "readiness_category" in row.keys() else ""
    return bool(row["emergency_reserve"] if "emergency_reserve" in row.keys() else 0) or category in EMERGENCY_CATEGORIES or readiness_category in EMERGENCY_CATEGORIES


def reserve_items(conn: sqlite3.Connection, include_archived: bool = False) -> list[sqlite3.Row]:
    rows = list_items(conn, include_archived=include_archived, status_filter="")
    return [r for r in rows if is_reserve_item(r) and (include_archived or not bool(r["archived"]))]


def set_reserve_flags(conn: sqlite3.Connection, item_id: int, emergency_reserve: Optional[bool] = None, do_not_consume: Optional[bool] = None, readiness_category: str | None = None) -> None:
    row = conn.execute("SELECT * FROM items WHERE id=?", (item_id,)).fetchone()
    if not row:
        raise ValueError(f"No item found with id {item_id}.")
    vals = {
        "id": item_id,
        "emergency_reserve": row["emergency_reserve"] if emergency_reserve is None else (1 if emergency_reserve else 0),
        "do_not_consume": row["do_not_consume"] if do_not_consume is None else (1 if do_not_consume else 0),
        "readiness_category": row["readiness_category"] if readiness_category is None else readiness_category.strip(),
        "updated_at": now_iso(),
    }
    conn.execute("UPDATE items SET emergency_reserve=:emergency_reserve, do_not_consume=:do_not_consume, readiness_category=:readiness_category, updated_at=:updated_at WHERE id=:id", vals)
    conn.commit()
    audit(conn, "set_reserve_flags", vals)


def readiness_summary(conn: sqlite3.Connection) -> dict[str, Any]:
    rows = [r for r in list_items(conn, include_archived=False, status_filter="") if is_reserve_item(r)]
    people = household_members(conn)
    target_days = reserve_days_target(conn)
    calories_day = setting_float(conn, "calories_per_person_day", DEFAULT_CALORIES_PER_PERSON_DAY)
    water_day = setting_float(conn, "water_litres_per_person_day", DEFAULT_WATER_LITRES_PER_PERSON_DAY)
    total_calories = 0.0
    total_water = 0.0
    locked_count = 0
    low_count = 0
    categories: dict[str, dict[str, Any]] = {}
    for r in rows:
        qty = float(r["quantity"] or 0)
        unit = (r["unit"] or "").strip()
        readiness_category = (r["readiness_category"] if "readiness_category" in r.keys() else "") or (r["category"] or "") or "Other"
        categories.setdefault(readiness_category, {"items": 0, "quantity": 0.0, "low_stock": 0})
        categories[readiness_category]["items"] += 1
        categories[readiness_category]["quantity"] += qty
        if low_stock_flag(r):
            categories[readiness_category]["low_stock"] += 1
            low_count += 1
        if bool(r["do_not_consume"] if "do_not_consume" in r.keys() else 0):
            locked_count += 1
        cal_per = float(r["calories_per_unit"] if "calories_per_unit" in r.keys() else 0 or 0)
        water_per = float(r["water_litres_per_unit"] if "water_litres_per_unit" in r.keys() else 0 or 0)
        total_calories += qty * cal_per
        if water_per > 0:
            total_water += qty * water_per
        elif unit.lower() in {"l", "litre", "liter", "litres", "liters"} and (readiness_category == "Water" or (r["category"] or "").lower() == "water"):
            total_water += qty
    food_days = total_calories / max(1.0, people * calories_day)
    water_days = total_water / max(1.0, people * water_day)
    food_score = min(100.0, (food_days / max(1, target_days)) * 100.0)
    water_score = min(100.0, (water_days / max(1, target_days)) * 100.0)
    essential = ["Long-life Food", "Water", "Medical", "Batteries", "Hygiene"]
    coverage_score = sum(1 for c in essential if c in categories and categories[c]["items"] > 0) / len(essential) * 100.0
    score = round((food_score * 0.35) + (water_score * 0.35) + (coverage_score * 0.30), 1)
    status = "Strong" if score >= 80 else "Developing" if score >= 50 else "Needs Attention"
    return {
        "household_members": people,
        "reserve_days_target": target_days,
        "calories_per_person_day": calories_day,
        "water_litres_per_person_day": water_day,
        "reserve_items": len(rows),
        "reserve_locked_items": locked_count,
        "reserve_low_stock_items": low_count,
        "total_calories": round(total_calories, 2),
        "total_water_litres": round(total_water, 2),
        "food_days_supply": round(food_days, 2),
        "water_days_supply": round(water_days, 2),
        "readiness_score": score,
        "readiness_status": status,
        "categories": categories,
        "suggested_minimums": READINESS_MINIMUMS,
    }


def export_readiness_json(conn: sqlite3.Connection, path: str | Path) -> Path:
    path = Path(path).expanduser()
    if path.is_dir():
        path = path / f"sentinel-pantry-readiness-{today().isoformat()}.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(readiness_summary(conn), indent=2, sort_keys=True), encoding="utf-8")
    audit(conn, "export_readiness_json", {"path": str(path)})
    return path


def print_readiness(data: dict[str, Any]) -> None:
    print(f"Readiness: {data['readiness_status']} ({data['readiness_score']}%)")
    print(f"Household: {data['household_members']} member(s), target {data['reserve_days_target']} day(s)")
    print(f"Food supply: {data['food_days_supply']} day(s) from {data['total_calories']:g} kcal tracked")
    print(f"Water supply: {data['water_days_supply']} day(s) from {data['total_water_litres']:g} L tracked")
    print(f"Reserve items: {data['reserve_items']} total, {data['reserve_locked_items']} locked, {data['reserve_low_stock_items']} low stock")
    if data.get('categories'):
        print("Categories:")
        for cat, info in sorted(data['categories'].items()):
            print(f"  - {cat}: {info['items']} item(s), qty {float(info['quantity']):g}, low {info['low_stock']}")


def active_categories(conn: sqlite3.Connection) -> list[str]:
    seen = {r["category"] for r in conn.execute("SELECT DISTINCT category FROM items WHERE category!='' ORDER BY category COLLATE NOCASE")}
    return sorted(set(CATEGORY_PRESETS).union(seen), key=str.lower)


def active_locations(conn: sqlite3.Connection) -> list[str]:
    seen = {r["location"] for r in conn.execute("SELECT DISTINCT location FROM items WHERE location!='' ORDER BY location COLLATE NOCASE")}
    return sorted(set(LOCATION_PRESETS).union(seen), key=str.lower)


def normalise_barcode(value: Any) -> str:
    """Return a safe local barcode/string scanner token.

    Sentinel Pantry deliberately treats barcode data as local keyboard/scanner
    input. There is no online lookup in this phase.
    """
    return "".join(ch for ch in str(value or "").strip() if ch.isalnum() or ch in "-_.")


def lookup_barcode(conn: sqlite3.Connection, barcode: str) -> Optional[sqlite3.Row]:
    code = normalise_barcode(barcode)
    if not code:
        return None
    return conn.execute("SELECT * FROM barcode_catalog WHERE barcode=?", (code,)).fetchone()


def barcode_profile_count(conn: sqlite3.Connection) -> int:
    try:
        row = conn.execute("SELECT COUNT(*) FROM barcode_catalog").fetchone()
        return int(row[0] or 0)
    except Exception:
        return 0


def learn_barcode(
    conn: sqlite3.Connection,
    barcode: str,
    item_name: str,
    category: str = "",
    unit: str = "each",
    location: str = "Pantry",
    min_quantity: float = 0,
    preferred_store: str = "",
    estimated_price: float = 0,
    calories_per_unit: float = 0,
    water_litres_per_unit: float = 0,
    notes: str = "",
) -> str:
    code = normalise_barcode(barcode)
    name = str(item_name or "").strip()
    if not code:
        raise ValueError("Barcode is required.")
    if not name:
        raise ValueError("Item name is required for a barcode profile.")
    existing = lookup_barcode(conn, code)
    ts = now_iso()
    conn.execute(
        """INSERT OR REPLACE INTO barcode_catalog
        (barcode, item_name, category, unit, location, min_quantity, preferred_store, estimated_price, calories_per_unit, water_litres_per_unit, notes, created_at, updated_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (
            code,
            name,
            str(category or "").strip(),
            str(unit or "each").strip() or "each",
            str(location or "Pantry").strip() or "Pantry",
            float(min_quantity or 0),
            str(preferred_store or "").strip(),
            float(estimated_price or 0),
            float(calories_per_unit or 0),
            float(water_litres_per_unit or 0),
            str(notes or "").strip(),
            existing["created_at"] if existing else ts,
            ts,
        ),
    )
    conn.commit()
    audit(conn, "learn_barcode", {"barcode": code, "item_name": name, "updated": bool(existing)})
    return code


def learn_barcode_from_item(conn: sqlite3.Connection, item_id: int) -> str:
    row = conn.execute("SELECT * FROM items WHERE id=?", (int(item_id),)).fetchone()
    if not row:
        raise ValueError(f"No item found with id {item_id}.")
    if not row["barcode"]:
        raise ValueError("Selected item has no barcode.")
    return learn_barcode(
        conn,
        row["barcode"],
        row["name"],
        row["category"],
        row["unit"],
        row["location"],
        float(row["min_quantity"] or 0),
        "",
        0,
        float(row["calories_per_unit"] if "calories_per_unit" in row.keys() else 0),
        float(row["water_litres_per_unit"] if "water_litres_per_unit" in row.keys() else 0),
        row["notes"] or "",
    )


def delete_barcode_profile(conn: sqlite3.Connection, barcode: str) -> None:
    code = normalise_barcode(barcode)
    if not code:
        raise ValueError("Barcode is required.")
    conn.execute("DELETE FROM barcode_catalog WHERE barcode=?", (code,))
    conn.commit()
    audit(conn, "delete_barcode_profile", {"barcode": code})


def list_barcode_profiles(conn: sqlite3.Connection, query: str = "") -> list[sqlite3.Row]:
    sql = "SELECT * FROM barcode_catalog WHERE 1=1"
    params: list[Any] = []
    if query:
        q = f"%{query.lower()}%"
        sql += " AND (lower(barcode) LIKE ? OR lower(item_name) LIKE ? OR lower(category) LIKE ? OR lower(notes) LIKE ?)"
        params.extend([q, q, q, q])
    sql += " ORDER BY item_name COLLATE NOCASE, barcode COLLATE NOCASE"
    return list(conn.execute(sql, params).fetchall())


def profile_to_item_data(profile: sqlite3.Row, quantity: float, expiry_date: str = "", purchase_date: str = "", notes: str = "") -> dict[str, Any]:
    note_parts = []
    if profile["notes"]:
        note_parts.append(str(profile["notes"]))
    if notes:
        note_parts.append(str(notes))
    return {
        "name": profile["item_name"],
        "category": profile["category"] or "Pantry",
        "location": profile["location"] or "Pantry",
        "quantity": float(quantity or 1),
        "unit": profile["unit"] or "each",
        "min_quantity": float(profile["min_quantity"] or 0),
        "expiry_date": expiry_date,
        "purchase_date": purchase_date,
        "barcode": profile["barcode"],
        "calories_per_unit": float(profile["calories_per_unit"] or 0),
        "water_litres_per_unit": float(profile["water_litres_per_unit"] or 0),
        "notes": "\n".join(p for p in note_parts if p),
    }


def fast_add_item(
    conn: sqlite3.Connection,
    *,
    barcode: str = "",
    name: str = "",
    quantity: float = 1,
    unit: str = "",
    category: str = "",
    location: str = "",
    expiry_date: str = "",
    purchase_date: str = "",
    min_quantity: float | None = None,
    notes: str = "",
    learn: bool = True,
) -> int:
    code = normalise_barcode(barcode)
    profile = lookup_barcode(conn, code) if code else None
    if profile and not name:
        data = profile_to_item_data(profile, quantity, expiry_date, purchase_date, notes)
        if category:
            data["category"] = category
        if location:
            data["location"] = location
        if unit:
            data["unit"] = unit
        if min_quantity is not None:
            data["min_quantity"] = float(min_quantity or 0)
    else:
        item_name = str(name or "").strip()
        if not item_name:
            if code:
                raise ValueError("Unknown barcode. Provide --name once, then Sentinel Pantry can learn it locally.")
            raise ValueError("Name or known barcode is required for fast add.")
        data = {
            "name": item_name,
            "category": category or "Pantry",
            "location": location or "Pantry",
            "quantity": float(quantity or 1),
            "unit": unit or "each",
            "min_quantity": float(min_quantity or 0) if min_quantity is not None else 0,
            "expiry_date": expiry_date,
            "purchase_date": purchase_date,
            "barcode": code,
            "notes": notes,
        }
        if code and learn:
            learn_barcode(conn, code, item_name, data["category"], data["unit"], data["location"], data["min_quantity"], notes=notes)
    item_id = add_item(conn, data)
    audit(conn, "fast_add_item", {"id": item_id, "barcode": code, "learned": bool(code and learn)})
    return item_id


def duplicate_groups(conn: sqlite3.Connection) -> list[dict[str, Any]]:
    groups: list[dict[str, Any]] = []
    rows = conn.execute(
        """SELECT lower(trim(name)) key_name, lower(trim(unit)) key_unit, COUNT(*) c, GROUP_CONCAT(id) ids, SUM(quantity) total_qty
        FROM items WHERE archived=0 GROUP BY key_name, key_unit HAVING c > 1 ORDER BY c DESC, key_name"""
    ).fetchall()
    for r in rows:
        groups.append({"kind": "name+unit", "key": f"{r['key_name']} / {r['key_unit']}", "count": int(r["c"]), "ids": [int(x) for x in str(r["ids"]).split(',') if x], "total_quantity": float(r["total_qty"] or 0)})
    rows = conn.execute(
        """SELECT barcode, COUNT(*) c, GROUP_CONCAT(id) ids, SUM(quantity) total_qty
        FROM items WHERE archived=0 AND barcode!='' GROUP BY barcode HAVING c > 1 ORDER BY c DESC, barcode"""
    ).fetchall()
    for r in rows:
        groups.append({"kind": "barcode", "key": r["barcode"], "count": int(r["c"]), "ids": [int(x) for x in str(r["ids"]).split(',') if x], "total_quantity": float(r["total_qty"] or 0)})
    return groups


def merge_items(conn: sqlite3.Connection, target_id: int, source_ids: list[int], archive_sources: bool = True) -> int:
    target = conn.execute("SELECT * FROM items WHERE id=?", (int(target_id),)).fetchone()
    if not target:
        raise ValueError(f"No target item found with id {target_id}.")
    clean_sources = [int(x) for x in source_ids if int(x) != int(target_id)]
    if not clean_sources:
        raise ValueError("At least one source item id is required.")
    sources = []
    for sid in clean_sources:
        row = conn.execute("SELECT * FROM items WHERE id=?", (sid,)).fetchone()
        if not row:
            raise ValueError(f"No source item found with id {sid}.")
        sources.append(row)
    total_added = sum(float(r["quantity"] or 0) for r in sources)
    new_qty = float(target["quantity"] or 0) + total_added
    new_min = max([float(target["min_quantity"] or 0)] + [float(r["min_quantity"] or 0) for r in sources])
    expiry_candidates = [str(x or "") for x in [target["expiry_date"]] + [r["expiry_date"] for r in sources] if str(x or "").strip()]
    new_expiry = min(expiry_candidates) if expiry_candidates else (target["expiry_date"] or "")
    notes = target["notes"] or ""
    merge_note = f"Merged source item(s) {', '.join(str(r['id']) for r in sources)} on {now_iso()}."
    notes = (notes + "\n" + merge_note).strip()
    barcode = target["barcode"] or next((r["barcode"] for r in sources if r["barcode"]), "")
    conn.execute(
        "UPDATE items SET quantity=?, min_quantity=?, expiry_date=?, barcode=?, notes=?, updated_at=? WHERE id=?",
        (new_qty, new_min, new_expiry, barcode, notes, now_iso(), int(target_id)),
    )
    conn.execute("INSERT INTO stock_moves(item_id, delta, reason, notes, created_at) VALUES(?,?,?,?,?)", (int(target_id), total_added, "merge_duplicates", merge_note, now_iso()))
    for r in sources:
        conn.execute("UPDATE shopping_list SET pantry_item_id=? WHERE pantry_item_id=?", (int(target_id), int(r["id"])))
        if archive_sources:
            conn.execute("UPDATE items SET quantity=0, archived=1, updated_at=? WHERE id=?", (now_iso(), int(r["id"])))
        else:
            conn.execute("DELETE FROM items WHERE id=?", (int(r["id"]),))
    conn.commit()
    audit(conn, "merge_items", {"target": int(target_id), "sources": clean_sources, "quantity_added": total_added, "archive_sources": archive_sources})
    return int(target_id)


def import_barcode_catalog_csv(conn: sqlite3.Connection, path: str | Path) -> int:
    path = Path(path).expanduser()
    if not path.exists():
        raise FileNotFoundError(path)
    count = 0
    with path.open("r", newline="", encoding="utf-8-sig") as fh:
        reader = csv.DictReader(fh)
        for row in reader:
            barcode = row.get("barcode", "")
            name = row.get("item_name") or row.get("name") or row.get("product") or ""
            if not barcode or not name:
                continue
            learn_barcode(
                conn,
                barcode,
                name,
                row.get("category", ""),
                row.get("unit", "each"),
                row.get("location", "Pantry"),
                fnum(row.get("min_quantity", row.get("minimum", 0)), 0),
                row.get("preferred_store", row.get("store", "")),
                fnum(row.get("estimated_price", row.get("price", 0)), 0),
                fnum(row.get("calories_per_unit", 0), 0),
                fnum(row.get("water_litres_per_unit", 0), 0),
                row.get("notes", ""),
            )
            count += 1
    audit(conn, "import_barcode_catalog_csv", {"path": str(path), "rows": count})
    return count


def export_barcode_catalog_csv(conn: sqlite3.Connection, path: str | Path) -> Path:
    path = Path(path).expanduser()
    if path.is_dir():
        path = path / f"sentinel-pantry-barcode-catalog-{today().isoformat()}.csv"
    path.parent.mkdir(parents=True, exist_ok=True)
    rows = list_barcode_profiles(conn)
    with path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=BARCODE_CATALOG_FIELDS)
        writer.writeheader()
        for r in rows:
            writer.writerow({k: r[k] for k in BARCODE_CATALOG_FIELDS if k in r.keys()})
    audit(conn, "export_barcode_catalog_csv", {"path": str(path), "rows": len(rows)})
    return path


def print_barcode_profiles(rows: Iterable[sqlite3.Row]) -> None:
    rows = list(rows)
    if not rows:
        print("No barcode profiles found.")
        return
    for r in rows:
        store = f" @{r['preferred_store']}" if "preferred_store" in r.keys() and r["preferred_store"] else ""
        print(f"{r['barcode']} — {r['item_name']} — {r['category'] or 'Uncategorised'} — {r['unit'] or 'each'} — {r['location'] or 'Pantry'}{store}")


def print_duplicate_groups(groups: list[dict[str, Any]]) -> None:
    if not groups:
        print("No duplicate groups found.")
        return
    for g in groups:
        print(f"{g['kind']}: {g['key']} — {g['count']} item(s) — ids:{','.join(str(x) for x in g['ids'])} — total qty:{g['total_quantity']:g}")

def log_shopping_history(
    conn: sqlite3.Connection,
    action: str,
    row: sqlite3.Row | None = None,
    *,
    shopping_id: int | None = None,
    item_name: str = "",
    target_quantity: float = 1,
    unit: str = "each",
    category: str = "",
    preferred_store: str = "",
    estimated_price: float = 0,
    status: str = "",
    notes: str = "",
) -> None:
    """Append a lightweight shopping workflow history event."""
    try:
        if row is not None:
            shopping_id = int(row["id"])
            item_name = row["item_name"]
            target_quantity = float(row["target_quantity"] or 0)
            unit = row["unit"] or "each"
            category = row["category"] or ""
            preferred_store = row["preferred_store"] or ""
            estimated_price = float(row["estimated_price"] or 0)
            status = row["status"] or status
            if not notes:
                notes = row["notes"] or ""
        conn.execute(
            """INSERT INTO shopping_history
            (shopping_id, item_name, target_quantity, unit, category, preferred_store, estimated_price, action, status, notes, created_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
            (shopping_id, item_name, float(target_quantity), unit, category, preferred_store, float(estimated_price or 0), action, status, notes, now_iso()),
        )
        conn.commit()
    except Exception:
        # Shopping history must never block the user's workflow.
        pass


def normalise_shopping_status(status: str) -> str:
    status = (status or "Needed").strip().title()
    if status not in SHOPPING_STATUSES:
        raise ValueError(f"Invalid shopping status '{status}'. Use one of: {', '.join(SHOPPING_STATUSES)}.")
    return status


def add_shopping_item(
    conn: sqlite3.Connection,
    name: str,
    target_quantity: float = 1,
    unit: str = "each",
    category: str = "",
    source: str = "manual",
    status: str = "Needed",
    preferred_store: str = "",
    estimated_price: float = 0,
    notes: str = "",
    pantry_item_id: int | None = None,
) -> int:
    ts = now_iso()
    name = name.strip()
    if not name:
        raise ValueError("Shopping item name is required.")
    status = normalise_shopping_status(status)
    checked = 1 if status in CLOSED_SHOPPING_STATUSES else 0
    bought_at = ts if status == "Bought" else ""
    cur = conn.execute(
        """INSERT INTO shopping_list
        (item_name, target_quantity, unit, category, source, checked, status, preferred_store, estimated_price, notes, pantry_item_id, bought_at, created_at, updated_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (
            name, float(target_quantity), unit.strip() or "each", category.strip(), source.strip() or "manual",
            checked, status, preferred_store.strip(), float(estimated_price or 0), notes.strip(), pantry_item_id,
            bought_at, ts, ts,
        ),
    )
    conn.commit()
    sid = int(cur.lastrowid)
    row = conn.execute("SELECT * FROM shopping_list WHERE id=?", (sid,)).fetchone()
    log_shopping_history(conn, "add", row)
    audit(conn, "add_shopping_item", {"id": sid, "name": name, "source": source, "status": status})
    return sid


def generate_shopping_list(conn: sqlite3.Connection) -> int:
    count = 0
    existing = {
        (r["item_name"].strip().lower(), r["unit"].strip().lower())
        for r in conn.execute("SELECT item_name, unit FROM shopping_list WHERE checked=0 AND status IN ('Needed','Urgent')")
    }
    for row in low_stock_items(conn):
        key = (row["name"].strip().lower(), (row["unit"] or "each").strip().lower())
        if key in existing:
            continue
        target = max(float(row["min_quantity"] or 0) - float(row["quantity"] or 0), 1.0)
        add_shopping_item(
            conn,
            row["name"],
            target,
            row["unit"],
            row["category"],
            "low_stock",
            "Needed",
            "",
            0,
            "Auto-generated from low-stock threshold.",
            int(row["id"]),
        )
        count += 1
        existing.add(key)
    audit(conn, "generate_shopping_list", {"added": count})
    return count


def list_shopping(conn: sqlite3.Connection, include_checked: bool = False, status: str = "", store: str = "") -> list[sqlite3.Row]:
    sql = "SELECT * FROM shopping_list WHERE 1=1"
    params: list[Any] = []
    if not include_checked:
        sql += " AND checked=0 AND status IN ('Needed','Urgent')"
    if status:
        sql += " AND status=?"
        params.append(normalise_shopping_status(status))
    if store:
        sql += " AND preferred_store=?"
        params.append(store)
    sql += " ORDER BY CASE status WHEN 'Urgent' THEN 0 WHEN 'Needed' THEN 1 WHEN 'Bought' THEN 2 ELSE 3 END, preferred_store COLLATE NOCASE, item_name COLLATE NOCASE"
    return list(conn.execute(sql, params).fetchall())


def shopping_status_counts(conn: sqlite3.Connection) -> dict[str, int]:
    counts = {s: 0 for s in SHOPPING_STATUSES}
    for r in conn.execute("SELECT status, COUNT(*) c FROM shopping_list GROUP BY status"):
        counts[r["status"] if r["status"] in counts else "Needed"] = int(r["c"])
    return counts


def shopping_estimated_total(conn: sqlite3.Connection, include_checked: bool = False) -> float:
    rows = list_shopping(conn, include_checked=include_checked)
    return round(sum(float(r["estimated_price"] or 0) for r in rows), 2)


def set_shopping_status(conn: sqlite3.Connection, shopping_id: int, status: str, notes: str = "") -> None:
    status = normalise_shopping_status(status)
    row = conn.execute("SELECT * FROM shopping_list WHERE id=?", (shopping_id,)).fetchone()
    if not row:
        raise ValueError(f"No shopping item found with id {shopping_id}.")
    checked = 1 if status in CLOSED_SHOPPING_STATUSES else 0
    bought_at = now_iso() if status == "Bought" else (row["bought_at"] or "")
    conn.execute(
        "UPDATE shopping_list SET status=?, checked=?, bought_at=?, notes=CASE WHEN ?!='' THEN ? ELSE notes END, updated_at=? WHERE id=?",
        (status, checked, bought_at, notes, notes, now_iso(), shopping_id),
    )
    conn.commit()
    updated = conn.execute("SELECT * FROM shopping_list WHERE id=?", (shopping_id,)).fetchone()
    log_shopping_history(conn, f"status:{status.lower()}", updated, notes=notes or (updated["notes"] or ""))
    audit(conn, "shopping_status", {"id": shopping_id, "status": status})


def set_shopping_checked(conn: sqlite3.Connection, shopping_id: int, checked: bool = True) -> None:
    set_shopping_status(conn, shopping_id, "Bought" if checked else "Needed")


def update_shopping_item(
    conn: sqlite3.Connection,
    shopping_id: int,
    *,
    item_name: str | None = None,
    target_quantity: float | None = None,
    unit: str | None = None,
    category: str | None = None,
    status: str | None = None,
    preferred_store: str | None = None,
    estimated_price: float | None = None,
    notes: str | None = None,
) -> None:
    row = conn.execute("SELECT * FROM shopping_list WHERE id=?", (shopping_id,)).fetchone()
    if not row:
        raise ValueError(f"No shopping item found with id {shopping_id}.")
    new_status = normalise_shopping_status(status or row["status"])
    checked = 1 if new_status in CLOSED_SHOPPING_STATUSES else 0
    bought_at = now_iso() if new_status == "Bought" and not row["bought_at"] else (row["bought_at"] or "")
    vals = {
        "id": shopping_id,
        "item_name": (item_name if item_name is not None else row["item_name"]).strip(),
        "target_quantity": float(target_quantity if target_quantity is not None else row["target_quantity"]),
        "unit": (unit if unit is not None else row["unit"]).strip() or "each",
        "category": (category if category is not None else row["category"]).strip(),
        "status": new_status,
        "checked": checked,
        "preferred_store": (preferred_store if preferred_store is not None else row["preferred_store"]).strip(),
        "estimated_price": float(estimated_price if estimated_price is not None else row["estimated_price"] or 0),
        "notes": (notes if notes is not None else row["notes"]).strip(),
        "bought_at": bought_at,
        "updated_at": now_iso(),
    }
    if not vals["item_name"]:
        raise ValueError("Shopping item name is required.")
    conn.execute(
        """UPDATE shopping_list SET item_name=:item_name, target_quantity=:target_quantity, unit=:unit,
        category=:category, status=:status, checked=:checked, preferred_store=:preferred_store,
        estimated_price=:estimated_price, notes=:notes, bought_at=:bought_at, updated_at=:updated_at WHERE id=:id""",
        vals,
    )
    conn.commit()
    updated = conn.execute("SELECT * FROM shopping_list WHERE id=?", (shopping_id,)).fetchone()
    log_shopping_history(conn, "update", updated)
    audit(conn, "update_shopping_item", {"id": shopping_id, "status": new_status})


def restock_from_shopping(conn: sqlite3.Connection, shopping_id: int, create_missing: bool = True, default_location: str = "Pantry") -> int:
    row = conn.execute("SELECT * FROM shopping_list WHERE id=?", (shopping_id,)).fetchone()
    if not row:
        raise ValueError(f"No shopping item found with id {shopping_id}.")
    item = None
    if row["pantry_item_id"]:
        item = conn.execute("SELECT * FROM items WHERE id=? AND archived=0", (int(row["pantry_item_id"]),)).fetchone()
    if item is None:
        matches = conn.execute(
            "SELECT * FROM items WHERE archived=0 AND lower(name)=lower(?) AND lower(unit)=lower(?) ORDER BY id LIMIT 2",
            (row["item_name"], row["unit"] or "each"),
        ).fetchall()
        if len(matches) == 1:
            item = matches[0]
    qty = float(row["target_quantity"] or 0)
    if qty <= 0:
        qty = 1.0
    if item is not None:
        item_id = int(item["id"])
        restock_item(conn, item_id, qty, notes=f"Restocked from shopping item #{shopping_id}.")
    elif create_missing:
        item_id = add_item(conn, {
            "name": row["item_name"],
            "category": row["category"] or "Pantry",
            "location": default_location or "Pantry",
            "quantity": qty,
            "unit": row["unit"] or "each",
            "min_quantity": 0,
            "notes": f"Created from shopping item #{shopping_id}.",
        })
        conn.execute("UPDATE shopping_list SET pantry_item_id=? WHERE id=?", (item_id, shopping_id))
        conn.commit()
    else:
        raise ValueError("No matching pantry item found for this shopping item.")
    set_shopping_status(conn, shopping_id, "Bought", notes="Restocked into pantry.")
    updated = conn.execute("SELECT * FROM shopping_list WHERE id=?", (shopping_id,)).fetchone()
    log_shopping_history(conn, "restock", updated, notes=f"Restocked pantry item #{item_id}.")
    audit(conn, "restock_from_shopping", {"shopping_id": shopping_id, "item_id": item_id, "quantity": qty})
    return item_id


def export_shopping_txt(conn: sqlite3.Connection, path: str | Path, include_completed: bool = False) -> Path:
    path = Path(path).expanduser()
    if path.is_dir():
        path = path / f"sentinel-pantry-shopping-{today().isoformat()}.txt"
    path.parent.mkdir(parents=True, exist_ok=True)
    rows = list_shopping(conn, include_checked=include_completed)
    stores = sorted({r["preferred_store"] or "Unassigned" for r in rows}, key=str.lower)
    with path.open("w", encoding="utf-8") as fh:
        fh.write(f"Sentinel Pantry Shopping List — {today().isoformat()}\n")
        fh.write("=" * 56 + "\n")
        if not rows:
            fh.write("No open shopping items.\n")
        for store in stores:
            group = [r for r in rows if (r["preferred_store"] or "Unassigned") == store]
            if not group:
                continue
            fh.write(f"\n[{store}]\n")
            for r in group:
                mark = "[!]" if r["status"] == "Urgent" else ("[x]" if r["status"] == "Bought" else "[-]" if r["status"] == "Skipped" else "[ ]")
                fh.write(f"{mark} {r['item_name']} — {float(r['target_quantity']):g} {r['unit']}")
                if r["category"]:
                    fh.write(f" ({r['category']})")
                if float(r["estimated_price"] or 0) > 0:
                    fh.write(f" — est. ${float(r['estimated_price']):.2f}")
                if r["notes"]:
                    fh.write(f" — {r['notes']}")
                fh.write("\n")
        total = shopping_estimated_total(conn, include_checked=include_completed)
        if total:
            fh.write(f"\nEstimated total: ${total:.2f}\n")
    audit(conn, "export_shopping_txt", {"path": str(path), "rows": len(rows), "include_completed": include_completed})
    return path




def shopping_print_text(conn: sqlite3.Connection, include_completed: bool = False) -> str:
    """Return the print-friendly shopping list text without writing a file."""
    rows = list_shopping(conn, include_checked=include_completed)
    stores = sorted({r["preferred_store"] or "Unassigned" for r in rows}, key=str.lower)
    lines: list[str] = []
    lines.append(f"Sentinel Pantry Shopping List — {today().isoformat()}")
    lines.append("=" * 56)
    if not rows:
        lines.append("No open shopping items.")
    for store in stores:
        group = [r for r in rows if (r["preferred_store"] or "Unassigned") == store]
        if not group:
            continue
        lines.append("")
        lines.append(f"[{store}]")
        for r in group:
            mark = "[!]" if r["status"] == "Urgent" else ("[x]" if r["status"] == "Bought" else "[-]" if r["status"] == "Skipped" else "[ ]")
            line = f"{mark} {r['item_name']} — {float(r['target_quantity']):g} {r['unit']}"
            if r["category"]:
                line += f" ({r['category']})"
            if float(r["estimated_price"] or 0) > 0:
                line += f" — est. ${float(r['estimated_price']):.2f}"
            if r["notes"]:
                line += f" — {r['notes']}"
            lines.append(line)
    total = shopping_estimated_total(conn, include_checked=include_completed)
    if total:
        lines.append("")
        lines.append(f"Estimated total: ${total:.2f}")
    return "\n".join(lines) + "\n"

def export_shopping_csv(conn: sqlite3.Connection, path: str | Path, include_completed: bool = False) -> Path:
    path = Path(path).expanduser()
    if path.is_dir():
        path = path / f"sentinel-pantry-shopping-{today().isoformat()}.csv"
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = ["id", "item_name", "target_quantity", "unit", "category", "status", "preferred_store", "estimated_price", "source", "notes", "created_at", "updated_at", "bought_at"]
    rows = list_shopping(conn, include_checked=include_completed)
    with path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=fields)
        writer.writeheader()
        for r in rows:
            writer.writerow({k: r[k] for k in fields})
    audit(conn, "export_shopping_csv", {"path": str(path), "rows": len(rows), "include_completed": include_completed})
    return path


def list_shopping_history(conn: sqlite3.Connection, limit: int = 50) -> list[sqlite3.Row]:
    return list(conn.execute("SELECT * FROM shopping_history ORDER BY id DESC LIMIT ?", (int(limit),)).fetchall())


def print_shopping_history(rows: Iterable[sqlite3.Row]) -> None:
    rows = list(rows)
    if not rows:
        print("No shopping history yet.")
        return
    for r in rows:
        price = f" est.${float(r['estimated_price']):.2f}" if float(r["estimated_price"] or 0) else ""
        store = f" @{r['preferred_store']}" if r["preferred_store"] else ""
        print(f"#{r['id']} {r['created_at']} {r['action']} {r['item_name']} — {float(r['target_quantity']):g} {r['unit']} [{r['status'] or '-'}]{store}{price}")


def find_pantry_item_by_name(conn: sqlite3.Connection, name: str) -> Optional[sqlite3.Row]:
    q = (name or "").strip().lower()
    if not q:
        return None
    row = conn.execute("SELECT * FROM items WHERE archived=0 AND lower(name)=? ORDER BY quantity DESC, id ASC LIMIT 1", (q,)).fetchone()
    if row:
        return row
    like = f"%{q}%"
    return conn.execute("SELECT * FROM items WHERE archived=0 AND lower(name) LIKE ? ORDER BY CASE WHEN lower(name)=? THEN 0 ELSE 1 END, quantity DESC, id ASC LIMIT 1", (like, q)).fetchone()



def add_recipe(conn: sqlite3.Connection, name: str, category: str = "", servings: float = 1, instructions: str = "", notes: str = "") -> int:
    name = (name or "").strip()
    if not name:
        raise ValueError("Recipe name is required.")
    ts = now_iso()
    with recipe_connect() as rconn:
        cur = rconn.execute(
            """INSERT INTO recipes(name, category, servings, instructions, notes, archived, created_at, updated_at)
            VALUES(?,?,?,?,?,0,?,?)""",
            (name, (category or "").strip(), max(0.01, float(servings or 1)), instructions or "", notes or "", ts, ts),
        )
        rconn.commit()
        recipe_id = int(cur.lastrowid)
    audit(conn, "add_recipe", {"id": recipe_id, "name": name, "storage_policy": RECIPE_STORAGE_POLICY, "recipe_db": str(RECIPE_DB_PATH)})
    return recipe_id


def add_recipe_ingredient(conn: sqlite3.Connection, recipe_id: int, item_name: str, quantity: float = 1, unit: str = "each", pantry_item_id: int | None = None, required: bool = True, notes: str = "") -> int:
    with recipe_connect() as rconn:
        recipe = rconn.execute("SELECT * FROM recipes WHERE id=?", (int(recipe_id),)).fetchone()
        if not recipe:
            raise ValueError(f"No recipe found with id {recipe_id}.")
        item_name = (item_name or "").strip()
        if not item_name:
            raise ValueError("Ingredient item name is required.")
        if pantry_item_id in (0, "", None):
            match = find_pantry_item_by_name(conn, item_name)
            pantry_item_id = int(match["id"]) if match else None
        else:
            prow = conn.execute("SELECT id FROM items WHERE id=?", (int(pantry_item_id),)).fetchone()
            if not prow:
                raise ValueError(f"No pantry item found with id {pantry_item_id}.")
            pantry_item_id = int(pantry_item_id)
        ts = now_iso()
        cur = rconn.execute(
            """INSERT INTO recipe_ingredients(recipe_id, item_name, quantity, unit, pantry_item_id, required, notes, created_at, updated_at)
            VALUES(?,?,?,?,?,?,?,?,?)""",
            (int(recipe_id), item_name, max(0.0, float(quantity or 0)), (unit or "each").strip() or "each", pantry_item_id, 1 if required else 0, notes or "", ts, ts),
        )
        rconn.commit()
        ingredient_id = int(cur.lastrowid)
    audit(conn, "add_recipe_ingredient", {"id": ingredient_id, "recipe_id": recipe_id, "item_name": item_name, "storage_policy": RECIPE_STORAGE_POLICY})
    return ingredient_id


def list_recipes(conn: sqlite3.Connection, include_archived: bool = False, query: str = "") -> list[sqlite3.Row]:
    sql = "SELECT * FROM recipes WHERE 1=1"
    params: list[Any] = []
    if not include_archived:
        sql += " AND archived=0"
    if query:
        q = f"%{query.lower()}%"
        sql += " AND (lower(name) LIKE ? OR lower(category) LIKE ? OR lower(notes) LIKE ?)"
        params += [q, q, q]
    sql += " ORDER BY name COLLATE NOCASE"
    with recipe_connect() as rconn:
        return list(rconn.execute(sql, params).fetchall())


def recipe_ingredients(conn: sqlite3.Connection, recipe_id: int) -> list[sqlite3.Row]:
    with recipe_connect() as rconn:
        return list(rconn.execute("SELECT * FROM recipe_ingredients WHERE recipe_id=? ORDER BY required DESC, item_name COLLATE NOCASE", (int(recipe_id),)).fetchall())


def get_recipe(recipe_id: int, include_archived: bool = True) -> Optional[sqlite3.Row]:
    sql = "SELECT * FROM recipes WHERE id=?"
    if not include_archived:
        sql += " AND archived=0"
    with recipe_connect() as rconn:
        return rconn.execute(sql, (int(recipe_id),)).fetchone()


def pantry_for_ingredient(conn: sqlite3.Connection, ing: sqlite3.Row) -> Optional[sqlite3.Row]:
    pid = ing["pantry_item_id"] if "pantry_item_id" in ing.keys() else None
    if pid:
        row = conn.execute("SELECT * FROM items WHERE id=? AND archived=0", (pid,)).fetchone()
        if row:
            return row
    return find_pantry_item_by_name(conn, ing["item_name"])


def recipe_availability(conn: sqlite3.Connection, recipe_id: int, multiplier: float = 1.0) -> dict[str, Any]:
    recipe = get_recipe(recipe_id)
    if not recipe:
        raise ValueError(f"No recipe found with id {recipe_id}.")
    ingredients = recipe_ingredients(conn, recipe_id)
    have: list[dict[str, Any]] = []
    missing: list[dict[str, Any]] = []
    low: list[dict[str, Any]] = []
    required_count = 0
    available_required = 0
    for ing in ingredients:
        needed = float(ing["quantity"] or 0) * max(0.01, float(multiplier or 1))
        pantry = pantry_for_ingredient(conn, ing)
        required = bool(ing["required"])
        if required:
            required_count += 1
        have_qty = float(pantry["quantity"] or 0) if pantry else 0.0
        record = {
            "ingredient_id": ing["id"],
            "item_name": ing["item_name"],
            "needed": needed,
            "unit": ing["unit"],
            "required": required,
            "pantry_item_id": int(pantry["id"]) if pantry else None,
            "available": have_qty,
        }
        if pantry and have_qty >= needed:
            have.append(record)
            if required:
                available_required += 1
        elif pantry and have_qty > 0:
            low.append(record)
            if not required:
                available_required += 1
        else:
            missing.append(record)
    required_missing = [m for m in missing + low if m["required"]]
    can_make = len(required_missing) == 0
    almost_can_make = (not can_make) and required_count > 0 and available_required >= max(0, required_count - 1)
    if can_make:
        status = "Can Make Now"
    elif almost_can_make:
        status = "Almost Can Make"
    else:
        status = "Missing Ingredients"
    return {
        "recipe_id": int(recipe_id),
        "recipe_name": recipe["name"],
        "servings": float(recipe["servings"] or 1),
        "ingredient_count": len(ingredients),
        "required_count": required_count,
        "available_required": available_required,
        "can_make": can_make,
        "almost_can_make": almost_can_make,
        "status": status,
        "have": have,
        "low": low,
        "missing": missing,
    }


def recipes_can_make(conn: sqlite3.Connection, include_almost: bool = True) -> list[dict[str, Any]]:
    out = []
    for r in list_recipes(conn):
        availability = recipe_availability(conn, int(r["id"]))
        if availability["can_make"] or (include_almost and availability["almost_can_make"]):
            out.append({"recipe": dict(r), "availability": availability})
    out.sort(key=lambda x: (0 if x["availability"]["can_make"] else 1, x["recipe"]["name"].lower()))
    return out


def suggest_recipes_for_use_first(conn: sqlite3.Connection, limit: int = 20) -> list[dict[str, Any]]:
    use_names = {r["name"].strip().lower(): r for r in use_first_items(conn, 200)}
    suggestions: list[dict[str, Any]] = []
    for recipe in list_recipes(conn):
        matched = []
        for ing in recipe_ingredients(conn, int(recipe["id"])):
            pname = (ing["item_name"] or "").strip().lower()
            if pname in use_names:
                matched.append(use_names[pname])
                continue
            pantry = pantry_for_ingredient(conn, ing)
            if pantry and pantry["name"].strip().lower() in use_names:
                matched.append(pantry)
        if matched:
            suggestions.append({
                "recipe": dict(recipe),
                "availability": recipe_availability(conn, int(recipe["id"])),
                "matched_use_first_items": [m["name"] for m in matched],
            })
    suggestions.sort(key=lambda x: (0 if x["availability"]["can_make"] else 1, -len(x["matched_use_first_items"]), x["recipe"]["name"].lower()))
    return suggestions[: max(1, int(limit))]


def recipe_to_dict(conn: sqlite3.Connection, recipe_id: int) -> dict[str, Any]:
    recipe = get_recipe(recipe_id)
    if not recipe:
        raise ValueError(f"No recipe found with id {recipe_id}.")
    return {
        "recipe": dict(recipe),
        "ingredients": [dict(r) for r in recipe_ingredients(conn, recipe_id)],
        "availability": recipe_availability(conn, recipe_id),
        "storage": {"policy": RECIPE_STORAGE_POLICY, "recipe_db": str(RECIPE_DB_PATH)},
    }


def recipe_generate_shopping(conn: sqlite3.Connection, recipe_id: int, multiplier: float = 1.0, urgent: bool = False) -> int:
    avail = recipe_availability(conn, recipe_id, multiplier)
    count = 0
    for rec in avail["missing"] + avail["low"]:
        needed = max(0.0, float(rec["needed"] or 0) - float(rec["available"] or 0)) or float(rec["needed"] or 1)
        add_shopping_item(conn, rec["item_name"], needed, rec["unit"], "Recipe", "recipe", "Urgent" if urgent else "Needed", "", 0, f"Needed for recipe: {avail['recipe_name']}", rec["pantry_item_id"])
        count += 1
    audit(conn, "recipe_generate_shopping", {"recipe_id": recipe_id, "added": count})
    return count


def export_recipes_json(conn: sqlite3.Connection, path: str | Path) -> Path:
    path = Path(path).expanduser()
    if path.is_dir():
        path = path / f"sentinel-pantry-recipes-{today().isoformat()}.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    data = [recipe_to_dict(conn, int(r["id"])) for r in list_recipes(conn, include_archived=True)]
    path.write_text(json.dumps({"app": APP_NAME, "version": APP_VERSION, "exported_at": now_iso(), "storage_policy": RECIPE_STORAGE_POLICY, "recipe_db": str(RECIPE_DB_PATH), "recipes": data}, indent=2, sort_keys=True), encoding="utf-8")
    audit(conn, "export_recipes_json", {"path": str(path), "recipes": len(data), "storage_policy": RECIPE_STORAGE_POLICY})
    return path


def export_recipes_csv(conn: sqlite3.Connection, path: str | Path) -> Path:
    path = Path(path).expanduser()
    if path.is_dir():
        path = path / f"sentinel-pantry-recipes-{today().isoformat()}.csv"
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = ["recipe_id", "recipe_name", "category", "servings", "ingredient_id", "item_name", "quantity", "unit", "pantry_item_id", "required", "notes", "availability_status", "storage_policy", "recipe_db"]
    with path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=fields)
        writer.writeheader()
        for recipe in list_recipes(conn, include_archived=True):
            avail = recipe_availability(conn, int(recipe["id"])) if not recipe["archived"] else {"status": "Archived"}
            ingredients = recipe_ingredients(conn, int(recipe["id"]))
            if not ingredients:
                writer.writerow({"recipe_id": recipe["id"], "recipe_name": recipe["name"], "category": recipe["category"], "servings": recipe["servings"], "availability_status": avail["status"], "storage_policy": RECIPE_STORAGE_POLICY, "recipe_db": str(RECIPE_DB_PATH)})
            for ing in ingredients:
                writer.writerow({
                    "recipe_id": recipe["id"], "recipe_name": recipe["name"], "category": recipe["category"], "servings": recipe["servings"],
                    "ingredient_id": ing["id"], "item_name": ing["item_name"], "quantity": ing["quantity"], "unit": ing["unit"],
                    "pantry_item_id": ing["pantry_item_id"], "required": ing["required"], "notes": ing["notes"], "availability_status": avail["status"],
                    "storage_policy": RECIPE_STORAGE_POLICY, "recipe_db": str(RECIPE_DB_PATH),
                })
    audit(conn, "export_recipes_csv", {"path": str(path), "storage_policy": RECIPE_STORAGE_POLICY})
    return path


def add_meal_plan(conn: sqlite3.Connection, recipe_id: int, plan_date: str = "", meal_type: str = "Dinner", servings: float = 1, notes: str = "") -> int:
    recipe = get_recipe(recipe_id, include_archived=False)
    if not recipe:
        raise ValueError(f"No active recipe found with id {recipe_id}.")
    date = parse_date(plan_date) if plan_date else today().isoformat()
    meal_type = (meal_type or "Dinner").strip().title()
    if meal_type not in MEAL_TYPES:
        meal_type = "Other"
    ts = now_iso()
    with recipe_connect() as rconn:
        cur = rconn.execute(
            """INSERT INTO meal_plan(plan_date, meal_type, recipe_id, servings, status, notes, created_at, updated_at)
            VALUES(?,?,?,?,?,?,?,?)""",
            (date, meal_type, int(recipe_id), max(0.01, float(servings or 1)), "Planned", notes or "", ts, ts),
        )
        rconn.commit()
        mid = int(cur.lastrowid)
    audit(conn, "add_meal_plan", {"id": mid, "recipe_id": recipe_id, "plan_date": date, "recipe_db": str(RECIPE_DB_PATH)})
    return mid


def list_meal_plan(conn: sqlite3.Connection, start: str = "", end: str = "") -> list[sqlite3.Row]:
    if not start:
        start = today().isoformat()
    else:
        start = parse_date(start)
    if not end:
        end = (today() + _dt.timedelta(days=7)).isoformat()
    else:
        end = parse_date(end)
    with recipe_connect() as rconn:
        return list(rconn.execute(
            """SELECT meal_plan.*, recipes.name recipe_name, recipes.category recipe_category
            FROM meal_plan JOIN recipes ON meal_plan.recipe_id=recipes.id
            WHERE plan_date >= ? AND plan_date <= ?
            ORDER BY plan_date ASC, CASE meal_type WHEN 'Breakfast' THEN 0 WHEN 'Lunch' THEN 1 WHEN 'Dinner' THEN 2 WHEN 'Snack' THEN 3 ELSE 4 END, recipe_name COLLATE NOCASE""",
            (start, end),
        ).fetchall())


def meal_plan_generate_shopping(conn: sqlite3.Connection, start: str = "", end: str = "", urgent: bool = False) -> int:
    count = 0
    for meal in list_meal_plan(conn, start, end):
        count += recipe_generate_shopping(conn, int(meal["recipe_id"]), float(meal["servings"] or 1), urgent=urgent)
    audit(conn, "meal_plan_generate_shopping", {"start": start, "end": end, "added": count})
    return count


def print_recipes(rows: Iterable[sqlite3.Row], conn: sqlite3.Connection) -> None:
    rows = list(rows)
    if not rows:
        print("No recipes found.")
        return
    for r in rows:
        avail = recipe_availability(conn, int(r["id"])) if not r["archived"] else {"status": "Archived", "ingredient_count": 0, "missing": []}
        missing = len(avail.get("missing", [])) + len(avail.get("low", []))
        print(f"#{r['id']} {r['name']} — {r['category'] or 'Uncategorised'} — {float(r['servings']):g} serving(s) — {avail['status']} — ingredients:{avail.get('ingredient_count', 0)} missing/low:{missing}")


def print_recipe_detail(data: dict[str, Any]) -> None:
    recipe = data["recipe"]
    avail = data["availability"]
    storage = data.get("storage", {})
    print(f"Recipe #{recipe['id']}: {recipe['name']}")
    print(f"Category: {recipe['category'] or 'Uncategorised'}")
    print(f"Servings: {float(recipe['servings']):g}")
    print(f"Availability: {avail['status']}")
    print(f"Storage: {storage.get('policy', RECIPE_STORAGE_POLICY)} — {storage.get('recipe_db', RECIPE_DB_PATH)}")
    if recipe.get("instructions"):
        print(f"Instructions: {recipe['instructions']}")
    if recipe.get("notes"):
        print(f"Notes: {recipe['notes']}")
    print("Ingredients:")
    for ing in data["ingredients"]:
        state = "ok"
        for m in avail["missing"]:
            if m["ingredient_id"] == ing["id"]:
                state = "missing"
        for l in avail["low"]:
            if l["ingredient_id"] == ing["id"]:
                state = "low"
        print(f" - {ing['item_name']}: {float(ing['quantity']):g} {ing['unit']} [{state}]")


def print_recipe_suggestions(items: list[dict[str, Any]]) -> None:
    if not items:
        print("No recipe suggestions found.")
        return
    for item in items:
        recipe = item["recipe"]
        avail = item["availability"]
        matched = ", ".join(item.get("matched_use_first_items", []))
        suffix = f" — use first: {matched}" if matched else ""
        print(f"#{recipe['id']} {recipe['name']} — {avail['status']}{suffix}")


def print_meal_plan(rows: Iterable[sqlite3.Row]) -> None:
    rows = list(rows)
    if not rows:
        print("No meals planned for that range.")
        return
    for r in rows:
        print(f"#{r['id']} {r['plan_date']} {r['meal_type']}: {r['recipe_name']} — servings:{float(r['servings']):g} — {r['status']} {('- ' + r['notes']) if r['notes'] else ''}")


def item_to_dict(row: sqlite3.Row, expiry_days: int = DEFAULT_EXPIRY_SOON_DAYS) -> dict[str, Any]:
    """Convert an item row into a stable machine-readable dictionary."""
    data = {k: row[k] for k in row.keys()}
    data["status"] = status_for_item(row, expiry_days)
    priority_score, priority_label = rotation_priority(row, expiry_days)
    data["rotation_priority_score"] = priority_score
    data["rotation_priority"] = priority_label
    data["low_stock"] = low_stock_flag(row)
    data["days_until_expiry"] = days_until_expiry(row)
    data["reserve"] = is_reserve_item(row)
    return data


def shopping_to_dict(row: sqlite3.Row) -> dict[str, Any]:
    data = {k: row[k] for k in row.keys()}
    data["open"] = str(row["status"] or "Needed") in OPEN_SHOPPING_STATUSES
    return data


def waste_to_dict(row: sqlite3.Row) -> dict[str, Any]:
    return {k: row[k] for k in row.keys()}


def active_aegis_export_dir() -> Path:
    """Return the preferred AEGIS handoff directory without auto-creating a missing vault."""
    if AEGIS_VAULT_PRESENT:
        return AEGIS_VAULT_ROOT / AEGIS_EXPORT_FOLDER
    return EXPORT_DIR / "aegis-handoff"


def json_write(path: Path, payload: dict[str, Any]) -> Path:
    path = Path(path).expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    return path


def inventory_snapshot(conn: sqlite3.Connection) -> dict[str, Any]:
    expiry_days = expiring_soon_days(conn)
    rows = list_items(conn, include_archived=True, status_filter="")
    return {
        "action": "inventory_snapshot",
        "app": APP_NAME,
        "app_id": APP_ID,
        "program_number": PROGRAM_NUMBER,
        "version": APP_VERSION,
        "generated_at": now_iso(),
        "database": str(DB_PATH),
        "schema_version": SCHEMA_VERSION,
        "items_total": len(rows),
        "items_active": len([r for r in rows if not bool(r["archived"])]),
        "items_archived": len([r for r in rows if bool(r["archived"])]),
        "items": [item_to_dict(r, expiry_days) for r in rows],
    }


def low_stock_payload(conn: sqlite3.Connection) -> dict[str, Any]:
    expiry_days = expiring_soon_days(conn)
    rows = low_stock_items(conn)
    return {
        "action": "low_stock",
        "generated_at": now_iso(),
        "count": len(rows),
        "items": [item_to_dict(r, expiry_days) for r in rows],
    }


def expired_payload(conn: sqlite3.Connection) -> dict[str, Any]:
    expiry_days = expiring_soon_days(conn)
    rows = expired_items(conn)
    return {
        "action": "expired",
        "generated_at": now_iso(),
        "count": len(rows),
        "items": [item_to_dict(r, expiry_days) for r in rows],
    }


def expiring_soon_payload(conn: sqlite3.Connection, days: int = 0) -> dict[str, Any]:
    days = int(days or expiring_soon_days(conn))
    expiry_days = expiring_soon_days(conn)
    rows = expiring_soon_items(conn, days)
    return {
        "action": "expiring_soon",
        "generated_at": now_iso(),
        "window_days": days,
        "count": len(rows),
        "items": [item_to_dict(r, expiry_days) for r in rows],
    }


def shopping_list_payload(conn: sqlite3.Connection, include_completed: bool = False) -> dict[str, Any]:
    rows = list_shopping(conn, include_checked=include_completed)
    return {
        "action": "shopping_list",
        "generated_at": now_iso(),
        "include_completed": bool(include_completed),
        "count": len(rows),
        "estimated_total": shopping_estimated_total(conn),
        "items": [shopping_to_dict(r) for r in rows],
    }


def waste_report_payload(conn: sqlite3.Connection, limit: int = 500) -> dict[str, Any]:
    rows = list_waste(conn, limit=max(1, int(limit or 500)))
    total_qty = sum(float(r["quantity"] or 0) for r in rows)
    reasons: dict[str, int] = {}
    for r in rows:
        key = r["reason"] or "Unspecified"
        reasons[key] = reasons.get(key, 0) + 1
    return {
        "action": "waste_report",
        "generated_at": now_iso(),
        "limit": int(limit or 500),
        "count": len(rows),
        "quantity_total": total_qty,
        "reason_counts": reasons,
        "events": [waste_to_dict(r) for r in rows],
    }


def readiness_status_payload(conn: sqlite3.Connection) -> dict[str, Any]:
    data = readiness_summary(conn)
    data.update({
        "action": "readiness_status",
        "generated_at": now_iso(),
        "app_id": APP_ID,
        "program_number": PROGRAM_NUMBER,
        "version": APP_VERSION,
    })
    return data


def sentinel_command_card(conn: sqlite3.Connection) -> dict[str, Any]:
    dash = dashboard_summary(conn)
    warnings: list[str] = []
    if dash["items_low_stock"]:
        warnings.append(f"{dash['items_low_stock']} low-stock item(s)")
    if dash["items_expired"]:
        warnings.append(f"{dash['items_expired']} expired item(s)")
    if dash["items_expiring_soon"]:
        warnings.append(f"{dash['items_expiring_soon']} expiring-soon item(s)")
    if dash["readiness_score"] < 70:
        warnings.append(f"Readiness score {dash['readiness_score']}%")
    state = "attention" if warnings else "ok"
    return {
        "action": "sentinel_command_card",
        "app_id": APP_ID,
        "program_number": PROGRAM_NUMBER,
        "name": APP_NAME,
        "version": APP_VERSION,
        "generated_at": now_iso(),
        "state": state,
        "subtitle": "Pantry, shopping, recipes, barcode, and household readiness",
        "summary": {
            "active_items": dash["items_active"],
            "low_stock": dash["items_low_stock"],
            "expired": dash["items_expired"],
            "expiring_soon": dash["items_expiring_soon"],
            "shopping_open": dash["shopping_open"],
            "readiness_score": dash["readiness_score"],
            "readiness_status": dash["readiness_status"],
            "food_days_supply": dash["food_days_supply"],
            "water_days_supply": dash["water_days_supply"],
            "barcode_profiles": dash["barcode_profiles"],
            "recipes_active": dash["recipes_active"],
        },
        "warnings": warnings,
        "actions": {
            "open_gui": "sentinel-pantry-gui",
            "health": "sentinel-pantry --health-check",
            "summary": "sentinel-pantry --summary",
            "low_stock": "sentinel-pantry aegis low_stock",
            "shopping": "sentinel-pantry aegis shopping_list",
            "readiness": "sentinel-pantry aegis readiness_status",
            "handoff_export": "sentinel-pantry aegis vault_export",
            "backup": "sentinel-pantry aegis backup",
            "self_test": "sentinel-pantry --self-test",
            "scanner_test": "sentinel-pantry scanner-test --code <barcode>",
        },
        "local_only": True,
        "network_capable": NETWORK_CAPABLE,
    }


def bastion_registration(conn: sqlite3.Connection) -> dict[str, Any]:
    export_dir = active_aegis_export_dir()
    return {
        "action": "bastion_registration",
        "app_id": APP_ID,
        "program_number": PROGRAM_NUMBER,
        "name": APP_NAME,
        "version": APP_VERSION,
        "generated_at": now_iso(),
        "local_only": True,
        "network_capable": NETWORK_CAPABLE,
        "backup_policy": "user-local sqlite databases and generated JSON handoff exports",
        "backup_targets": [
            {"label": "Sentinel Pantry inventory database", "kind": "sqlite", "path": str(DB_PATH), "required": True},
            {"label": "Sentinel Pantry recipe database", "kind": "sqlite", "path": str(RECIPE_DB_PATH), "required": False},
            {"label": "Sentinel Pantry exports", "kind": "directory", "path": str(EXPORT_DIR), "required": False},
            {"label": "Sentinel Pantry AEGIS handoff exports", "kind": "directory", "path": str(export_dir), "required": False},
        ],
        "commands": {
            "health": "sentinel-pantry --health-check",
            "summary": "sentinel-pantry --summary",
            "backup": "sentinel-pantry aegis backup",
            "vault_export": "sentinel-pantry aegis vault_export",
            "restore_inventory_database": "sentinel-pantry restore <backup.db>",
        },
        "notes": "B.A.S.T.I.O.N should copy both pantry.db and the resolved recipe database when present. No network access is required.",
    }


def write_bastion_registration(conn: sqlite3.Connection, path: str | Path | None = None) -> dict[str, Any]:
    payload = bastion_registration(conn)
    out = Path(path).expanduser() if path else BASTION_REGISTRATION_PATH
    json_write(out, payload)
    payload["written_to"] = str(out)
    audit(conn, "write_bastion_registration", {"path": str(out)})
    return payload


def aegis_backup(conn: sqlite3.Connection, path: str | Path | None = None) -> dict[str, Any]:
    stamp = _dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    target_dir = Path(path).expanduser() if path else BACKUP_DIR / f"aegis-backup-{stamp}"
    target_dir.mkdir(parents=True, exist_ok=True)
    pantry_backup = backup_db(conn, target_dir / "sentinel_pantry_pantry.db")
    recipe_backup = ""
    if RECIPE_DB_PATH.exists():
        recipe_target = target_dir / "sentinel_pantry_recipes.db"
        shutil.copy2(RECIPE_DB_PATH, recipe_target)
        recipe_backup = str(recipe_target)
    registration = write_bastion_registration(conn, target_dir / "bastion_registration.json")
    payload = {
        "action": "backup",
        "app_id": APP_ID,
        "version": APP_VERSION,
        "generated_at": now_iso(),
        "backup_dir": str(target_dir),
        "pantry_database_backup": str(pantry_backup),
        "recipe_database_backup": recipe_backup,
        "bastion_registration": registration.get("written_to", ""),
        "local_only": True,
    }
    json_write(target_dir / "backup_manifest.json", payload)
    audit(conn, "aegis_backup", {"dir": str(target_dir)})
    return payload




def stable_lock_report(conn: sqlite3.Connection) -> dict[str, Any]:
    """Return the v1 stable-lock readiness report."""
    h = health_check(conn)
    rec = recovery_status(conn)
    dash = dashboard_summary(conn)
    criteria = {
        "local_only_no_telemetry": (not NETWORK_CAPABLE),
        "inventory_workflow": True,
        "shopping_workflow": True,
        "expiry_rotation_waste": True,
        "emergency_readiness": True,
        "recipe_book_and_meal_plan": True,
        "barcode_usb_keyboard_wedge_ready": True,
        "aegis_contract_ready": True,
        "bastion_backup_ready": True,
        "recovery_integrity_ready": bool(rec.get("overall_ok")),
        "desktop_launcher_ready": True,
        "self_test_ready": True,
    }
    return {
        "action": "stable_lock_report",
        "app": APP_NAME,
        "app_id": APP_ID,
        "program_number": PROGRAM_NUMBER,
        "version": APP_VERSION,
        "stable_lock": True,
        "stable_lock_name": "Sentinel Pantry v1.0.0 User-Ready Baseline",
        "generated_at": now_iso(),
        "status": "locked" if all(criteria.values()) and h.get("status") in {"ok", "warning"} else "attention",
        "criteria": criteria,
        "dashboard": dash,
        "health_status": h.get("status"),
        "issues": h.get("issues", []),
        "scanner_support": {
            "current_mode": "USB keyboard-wedge barcode scanner",
            "gui_tab": "Barcode Options",
            "network_required": False,
            "online_lookup": False,
            "notes": "Most wired USB barcode scanners type the barcode into the focused field and optionally send Enter. Sentinel Pantry is ready for that workflow.",
        },
        "commands": {
            "gui": "sentinel-pantry",
            "self_test": "sentinel-pantry --self-test",
            "stable_lock_report": "sentinel-pantry stable-lock-report",
            "scanner_test": "sentinel-pantry scanner-test --code <barcode>",
            "desktop_launcher": "sentinel-pantry-install-desktop-launcher",
            "launcher_repair": "sentinel-pantry-repair-launcher",
        },
        "local_only": True,
        "network_capable": NETWORK_CAPABLE,
    }


def scanner_test_payload(conn: sqlite3.Connection, code: str = "") -> dict[str, Any]:
    """Return a local scanner readiness/test result. Does not require hardware-specific drivers."""
    code = normalise_barcode(code or "")
    profile = lookup_barcode(conn, code) if code else None
    return {
        "action": "scanner_test",
        "app_id": APP_ID,
        "version": APP_VERSION,
        "generated_at": now_iso(),
        "supported_now": True,
        "mode": "USB keyboard-wedge barcode scanner",
        "instructions": [
            "Open the Barcode Options tab.",
            "Click into the Barcode field.",
            "Scan a product barcode with a USB scanner.",
            "If the scanner sends Enter, Sentinel Pantry will look it up immediately; otherwise press Enter or Lookup.",
            "Known local profiles can be fast-added; unknown products can be entered once and learned locally.",
        ],
        "network_required": False,
        "online_lookup": False,
        "code_tested": code,
        "normalised_code": code,
        "profile_found": bool(profile),
        "profile": ({k: profile[k] for k in profile.keys()} if profile else None),
        "ready": True,
    }


def user_status_payload(conn: sqlite3.Connection) -> dict[str, Any]:
    return {
        "action": "status",
        "app": APP_NAME,
        "version": APP_VERSION,
        "program_number": PROGRAM_NUMBER,
        "stable_lock": True,
        "database": str(DB_PATH),
        "recipe_database": str(RECIPE_DB_PATH),
        "recipe_storage_location": RECIPE_STORAGE_LOCATION,
        "aegis_vault_present": AEGIS_VAULT_PRESENT,
        "documents_recipies_fallback": str(DOCUMENTS_RECIPE_FALLBACK_DIR),
        "desktop_launcher_helper": "sentinel-pantry-install-desktop-launcher",
        "desktop_launcher_repair": "sentinel-pantry-repair-launcher",
        "usb_scanner_ready": True,
        "gui_tabs": ["Dashboard", "Inventory", "Barcode Options", "Shopping List", "Rotation & Waste", "Emergency Readiness", "Recipie Book", "Meal Plan", "AEGIS Handoff", "Recovery & Integrity", "Manual & Status"],
        "local_only": True,
        "network_capable": NETWORK_CAPABLE,
    }


def self_test_payload(conn: sqlite3.Connection) -> dict[str, Any]:
    checks: list[dict[str, Any]] = []
    def add(name: str, ok: bool, detail: str = "") -> None:
        checks.append({"name": name, "ok": bool(ok), "detail": detail})
    h = health_check(conn)
    add("health_json", h.get("status") in {"ok", "warning"}, h.get("status", ""))
    add("summary_json", isinstance(summary(conn), dict), "summary available")
    add("manifest_json", isinstance(manifest(), dict), "manifest available")
    add("dashboard_json", isinstance(dashboard_summary(conn), dict), "dashboard available")
    add("aegis_contract", "stable_lock_report" in aegis_action_contract().get("actions", {}), "AEGIS stable-lock action present")
    rec = recovery_status(conn)
    add("integrity_check", bool(rec.get("overall_ok")), "pantry/recipe integrity checked")
    add("barcode_keyboard_wedge_ready", True, "Barcode Options accepts USB scanner keyboard input")
    add("recipe_storage_ready", RECIPE_DB_PATH.parent.exists(), str(RECIPE_DB_PATH))
    add("desktop_launcher_helper", True, "sentinel-pantry-install-desktop-launcher packaged")
    ok = all(c["ok"] for c in checks)
    return {
        "action": "self_test",
        "app_id": APP_ID,
        "version": APP_VERSION,
        "generated_at": now_iso(),
        "ok": ok,
        "checks": checks,
        "local_only": True,
        "network_capable": NETWORK_CAPABLE,
    }

def aegis_action_contract() -> dict[str, Any]:
    actions = {
        "contract": "Print this action contract.",
        "health_check": "Print health JSON.",
        "summary": "Print machine-readable pantry summary JSON.",
        "low_stock": "Print low-stock items JSON.",
        "expired": "Print expired items JSON.",
        "expiring_soon": "Print expiring-soon items JSON; accepts --days.",
        "shopping_list": "Print open shopping list JSON; accepts --include-completed.",
        "readiness_status": "Print emergency/off-grid readiness JSON.",
        "inventory_snapshot": "Print full inventory snapshot JSON.",
        "waste_report": "Print waste report JSON; accepts --limit.",
        "sentinel_command_card": "Print compact Sentinel Command status-card JSON.",
        "bastion_registration": "Write/print B.A.S.T.I.O.N backup registration JSON.",
        "backup": "Create a local AEGIS/B.A.S.T.I.O.N backup bundle.",
        "vault_export": "Export AEGIS handoff JSON files to the existing vault export folder or local fallback.",
        "integrity_check": "Print pantry and recipe database integrity/recovery status JSON.",
        "checksum_manifest": "Write/print SHA256 checksum manifest for local pantry files.",
        "stable_lock_report": "Print v1.0 stable-lock readiness report JSON.",
        "scanner_test": "Print USB barcode scanner workflow readiness/test JSON.",
        "self_test": "Run safe package/application self-test JSON.",
    }
    return {
        "action": "contract",
        "contract_version": AEGIS_CONTRACT_VERSION,
        "app_id": APP_ID,
        "program_number": PROGRAM_NUMBER,
        "name": APP_NAME,
        "version": APP_VERSION,
        "local_only": True,
        "network_capable": NETWORK_CAPABLE,
        "command": "sentinel-pantry aegis <action>",
        "actions": actions,
        "stable_action_names": list(actions.keys()),
        "output_format": "application/json",
        "no_network": True,
        "dangerous_actions": False,
    }


AEGIS_ACTION_NAMES = tuple(aegis_action_contract()["stable_action_names"])


def export_aegis_vault_handoff(conn: sqlite3.Connection, path: str | Path | None = None, include_completed: bool = False, waste_limit: int = 500, days: int = 0) -> dict[str, Any]:
    stamp = _dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    base_dir = Path(path).expanduser() if path else active_aegis_export_dir() / f"sentinel-pantry-handoff-{stamp}"
    base_dir.mkdir(parents=True, exist_ok=True)
    payloads: dict[str, dict[str, Any]] = {
        "inventory_snapshot": inventory_snapshot(conn),
        "shopping_list": shopping_list_payload(conn, include_completed=include_completed),
        "readiness_report": readiness_status_payload(conn),
        "waste_report": waste_report_payload(conn, limit=waste_limit),
        "sentinel_command_card": sentinel_command_card(conn),
        "health_check": health_check(conn),
        "summary": summary(conn),
        "aegis_manifest": manifest(),
        "bastion_registration": bastion_registration(conn),
        "stable_lock_report": stable_lock_report(conn),
    }
    payloads["expiring_soon"] = expiring_soon_payload(conn, days=days)
    written: dict[str, str] = {}
    for name, payload in payloads.items():
        out = json_write(base_dir / f"{name}.json", payload)
        written[name] = str(out)
    export_manifest = {
        "action": "vault_export",
        "app_id": APP_ID,
        "program_number": PROGRAM_NUMBER,
        "version": APP_VERSION,
        "generated_at": now_iso(),
        "export_dir": str(base_dir),
        "uses_aegis_vault": AEGIS_VAULT_PRESENT and str(base_dir).startswith(str(AEGIS_VAULT_ROOT)),
        "aegis_vault_present": AEGIS_VAULT_PRESENT,
        "files": written,
        "local_only": True,
        "network_capable": NETWORK_CAPABLE,
    }
    json_write(base_dir / "export_manifest.json", export_manifest)
    audit(conn, "aegis_vault_export", {"dir": str(base_dir), "files": sorted(written)})
    return export_manifest


def run_aegis_action(conn: sqlite3.Connection, action: str, path: str = "", days: int = 0, include_completed: bool = False, limit: int = 500) -> dict[str, Any]:
    action = (action or "contract").strip()
    if action == "contract":
        return aegis_action_contract()
    if action == "health_check":
        return health_check(conn)
    if action == "summary":
        return summary(conn)
    if action == "low_stock":
        return low_stock_payload(conn)
    if action == "expired":
        return expired_payload(conn)
    if action == "expiring_soon":
        return expiring_soon_payload(conn, days=days)
    if action == "shopping_list":
        return shopping_list_payload(conn, include_completed=include_completed)
    if action == "readiness_status":
        return readiness_status_payload(conn)
    if action == "inventory_snapshot":
        return inventory_snapshot(conn)
    if action == "waste_report":
        return waste_report_payload(conn, limit=limit)
    if action == "sentinel_command_card":
        return sentinel_command_card(conn)
    if action == "bastion_registration":
        return write_bastion_registration(conn, path or None)
    if action == "backup":
        return aegis_backup(conn, path or None)
    if action == "vault_export":
        return export_aegis_vault_handoff(conn, path or None, include_completed=include_completed, waste_limit=limit, days=days)
    if action == "integrity_check":
        return recovery_status(conn)
    if action == "checksum_manifest":
        out = write_checksum_manifest(conn, path or None)
        return {"action": "checksum_manifest", "written_to": str(out), "sha256": sha256_file(out), "local_only": True}
    if action == "stable_lock_report":
        return stable_lock_report(conn)
    if action == "scanner_test":
        return scanner_test_payload(conn, path or "")
    if action == "self_test":
        return self_test_payload(conn)
    raise ValueError(f"Unknown AEGIS action: {action}")

def export_csv(conn: sqlite3.Connection, path: str | Path) -> Path:
    path = Path(path).expanduser()
    if path.is_dir():
        path = path / f"sentinel-pantry-items-{today().isoformat()}.csv"
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = ["id", "name", "category", "location", "quantity", "unit", "min_quantity", "expiry_date", "purchase_date", "opened_date", "barcode", "batch_code", "shelf_life_notes", "emergency_reserve", "do_not_consume", "readiness_category", "calories_per_unit", "water_litres_per_unit", "notes", "archived", "created_at", "updated_at", "status", "rotation_priority"]
    rows = list_items(conn, include_archived=True, status_filter="")
    with path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            d = {k: row[k] for k in fields if k in row.keys()}
            d["status"] = status_for_item(row, expiring_soon_days(conn))
            d["rotation_priority"] = rotation_priority(row, expiring_soon_days(conn))[1]
            writer.writerow(d)
    audit(conn, "export_csv", {"path": str(path), "rows": len(rows)})
    return path


def import_csv(conn: sqlite3.Connection, path: str | Path, skip_duplicates: bool = False) -> int:
    path = Path(path).expanduser()
    if not path.exists():
        raise FileNotFoundError(path)
    count = 0
    with path.open("r", newline="", encoding="utf-8-sig") as fh:
        reader = csv.DictReader(fh)
        for row in reader:
            if not row.get("name"):
                continue
            if skip_duplicates:
                name_key = (row.get("name", "") or "").strip().lower()
                unit_key = (row.get("unit", "each") or "each").strip().lower()
                barcode_key = (row.get("barcode", "") or "").strip()
                existing_duplicate = conn.execute("SELECT 1 FROM items WHERE archived=0 AND lower(name)=? AND lower(unit)=? AND COALESCE(barcode,'')=?", (name_key, unit_key, barcode_key)).fetchone()
                barcode_duplicate = barcode_key and conn.execute("SELECT 1 FROM items WHERE archived=0 AND barcode=?", (barcode_key,)).fetchone()
                if existing_duplicate or barcode_duplicate:
                    continue
            data = {
                "name": row.get("name", ""),
                "category": row.get("category", ""),
                "location": row.get("location", ""),
                "quantity": row.get("quantity", 0),
                "unit": row.get("unit", "each"),
                "min_quantity": row.get("min_quantity", 0),
                "expiry_date": row.get("expiry_date", ""),
                "purchase_date": row.get("purchase_date", ""),
                "opened_date": row.get("opened_date", ""),
                "barcode": row.get("barcode", ""),
                "batch_code": row.get("batch_code", ""),
                "shelf_life_notes": row.get("shelf_life_notes", ""),
                "emergency_reserve": row.get("emergency_reserve", row.get("reserve", "0")),
                "do_not_consume": row.get("do_not_consume", row.get("locked", "0")),
                "readiness_category": row.get("readiness_category", ""),
                "calories_per_unit": row.get("calories_per_unit", "0"),
                "water_litres_per_unit": row.get("water_litres_per_unit", "0"),
                "notes": row.get("notes", ""),
            }
            add_item(conn, data)
            count += 1
    audit(conn, "import_csv", {"path": str(path), "rows": count})
    return count


def backup_db(conn: sqlite3.Connection, path: str | Path | None = None) -> Path:
    ensure_dirs()
    conn.commit()
    if path is None:
        path = BACKUP_DIR / f"sentinel-pantry-backup-{_dt.datetime.now().strftime('%Y%m%d-%H%M%S')}.db"
    path = Path(path).expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    target = sqlite3.connect(path)
    with target:
        conn.backup(target)
    target.close()
    info = db_integrity_payload(path, "backup_database")
    sidecar = Path(str(path) + ".sha256.json")
    json_write(sidecar, {"app": APP_NAME, "version": APP_VERSION, "created_at": now_iso(), "path": str(path), "sha256": info.get("sha256", ""), "size_bytes": info.get("size_bytes", 0), "integrity_ok": bool(info.get("ok"))})
    audit(conn, "backup_db", {"path": str(path), "sidecar": str(sidecar), "verified": bool(info.get("ok"))})
    return path


def restore_db(path: str | Path) -> Path:
    payload = safe_restore_db(path)
    return Path(payload["restored_to"])


def sha256_file(path: str | Path) -> str:
    path = Path(path).expanduser()
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def db_table_counts(path: str | Path) -> dict[str, int]:
    path = Path(path).expanduser()
    if not path.exists():
        return {}
    out: dict[str, int] = {}
    try:
        tconn = sqlite3.connect(path)
        tconn.row_factory = sqlite3.Row
        tables = [r["name"] for r in tconn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").fetchall()]
        for table in tables:
            try:
                safe_table = ''.join(ch for ch in table if ch.isalnum() or ch == '_')
                if safe_table == table:
                    out[table] = int(tconn.execute(f"SELECT COUNT(*) FROM {safe_table}").fetchone()[0])
            except Exception:
                out[table] = -1
        tconn.close()
    except Exception:
        return out
    return out


def db_integrity_payload(path: str | Path, label: str = "database") -> dict[str, Any]:
    path = Path(path).expanduser()
    payload: dict[str, Any] = {
        "label": label,
        "path": str(path),
        "exists": path.exists(),
        "size_bytes": path.stat().st_size if path.exists() else 0,
        "sha256": sha256_file(path) if path.exists() else "",
        "integrity_check": "missing",
        "quick_check": "missing",
        "foreign_key_violations": [],
        "table_counts": {},
        "schema_version": "",
        "ok": False,
    }
    if not path.exists():
        return payload
    try:
        tconn = sqlite3.connect(path)
        tconn.row_factory = sqlite3.Row
        integrity = [str(r[0]) for r in tconn.execute("PRAGMA integrity_check").fetchall()]
        quick = [str(r[0]) for r in tconn.execute("PRAGMA quick_check").fetchall()]
        fk_rows = [dict(r) for r in tconn.execute("PRAGMA foreign_key_check").fetchall()]
        try:
            meta = tconn.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()
            payload["schema_version"] = str(meta["value"]) if meta else ""
        except Exception:
            payload["schema_version"] = ""
        tconn.close()
        payload["integrity_check"] = integrity
        payload["quick_check"] = quick
        payload["foreign_key_violations"] = fk_rows
        payload["table_counts"] = db_table_counts(path)
        payload["ok"] = integrity == ["ok"] and quick == ["ok"] and not fk_rows
    except Exception as exc:
        payload["integrity_check"] = [f"error: {exc}"]
        payload["quick_check"] = [f"error: {exc}"]
        payload["ok"] = False
    return payload


def recovery_status(conn: sqlite3.Connection) -> dict[str, Any]:
    pantry = db_integrity_payload(DB_PATH, "pantry_database")
    recipe = db_integrity_payload(RECIPE_DB_PATH, "recipe_database")
    migrations = [dict(r) for r in conn.execute("SELECT * FROM migration_events ORDER BY id DESC LIMIT 20").fetchall()]
    backups = sorted(BACKUP_DIR.glob("*.db"), key=lambda x: x.stat().st_mtime, reverse=True) if BACKUP_DIR.exists() else []
    return {
        "app": APP_NAME,
        "version": APP_VERSION,
        "phase": "v1-stable-lock",
        "generated_at": now_iso(),
        "schema_version_expected": SCHEMA_VERSION,
        "pantry_database": pantry,
        "recipe_database": recipe,
        "overall_ok": bool(pantry.get("ok")) and bool(recipe.get("ok")),
        "backup_dir": str(BACKUP_DIR),
        "backup_count": len(backups),
        "latest_backups": [{"path": str(b), "size_bytes": b.stat().st_size, "modified_at": _dt.datetime.fromtimestamp(b.stat().st_mtime).isoformat()} for b in backups[:10]],
        "migration_events": migrations,
        "audit_log": str(AUDIT_PATH),
        "local_only": True,
        "network_capable": NETWORK_CAPABLE,
    }


def write_checksum_manifest(conn: sqlite3.Connection, path: str | Path | None = None) -> Path:
    ensure_dirs()
    stamp = _dt.datetime.now().strftime('%Y%m%d-%H%M%S')
    out = Path(path).expanduser() if path else EXPORT_DIR / f"sentinel-pantry-checksums-{stamp}.json"
    if out.is_dir():
        out = out / f"sentinel-pantry-checksums-{stamp}.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    candidates = [DB_PATH, RECIPE_DB_PATH, AUDIT_PATH, MANIFEST_PATH, BASTION_REGISTRATION_PATH]
    files = []
    for c in candidates:
        c = Path(c).expanduser()
        if c.exists() and c.is_file():
            files.append({"path": str(c), "size_bytes": c.stat().st_size, "sha256": sha256_file(c), "modified_at": _dt.datetime.fromtimestamp(c.stat().st_mtime).isoformat()})
    payload = {"app": APP_NAME, "version": APP_VERSION, "generated_at": now_iso(), "files": files, "local_only": True}
    json_write(out, payload)
    audit(conn, "write_checksum_manifest", {"path": str(out), "files": len(files)})
    return out


def verify_backup(path: str | Path) -> dict[str, Any]:
    src = Path(path).expanduser()
    payload = db_integrity_payload(src, "backup_database")
    payload["backup_path"] = str(src)
    payload["verified_at"] = now_iso()
    sidecar = src.with_suffix(src.suffix + ".sha256.json")
    if sidecar.exists():
        try:
            data = json.loads(sidecar.read_text(encoding="utf-8"))
            payload["sidecar_manifest"] = data
            payload["sidecar_sha256_matches"] = data.get("sha256") == payload.get("sha256")
        except Exception as exc:
            payload["sidecar_manifest_error"] = str(exc)
    return payload


def restore_preview(path: str | Path) -> dict[str, Any]:
    src = Path(path).expanduser()
    info = verify_backup(src)
    info.update({
        "action": "restore_preview",
        "would_replace": str(DB_PATH),
        "current_database": db_integrity_payload(DB_PATH, "current_pantry_database"),
        "safe_to_restore": bool(info.get("ok")),
        "no_changes_made": True,
    })
    return info


def safe_restore_db(path: str | Path) -> dict[str, Any]:
    src = Path(path).expanduser()
    if not src.exists():
        raise FileNotFoundError(src)
    preview = restore_preview(src)
    if not preview.get("safe_to_restore"):
        raise ValueError("Restore source failed integrity checks; no restore performed.")
    ensure_dirs()
    stamp = _dt.datetime.now().strftime('%Y%m%d-%H%M%S')
    pre_restore = BACKUP_DIR / f"pre-restore-{stamp}.db"
    if DB_PATH.exists():
        shutil.copy2(DB_PATH, pre_restore)
    shutil.copy2(src, DB_PATH)
    post = db_integrity_payload(DB_PATH, "restored_pantry_database")
    rolled_back = False
    if not post.get("ok") and pre_restore.exists():
        shutil.copy2(pre_restore, DB_PATH)
        rolled_back = True
    with connect() as conn:
        audit(conn, "safe_restore_db", {"from": str(src), "pre_restore_backup": str(pre_restore), "post_restore_ok": bool(post.get("ok")), "rolled_back": rolled_back})
    if rolled_back:
        raise ValueError("Restore failed post-restore integrity check; original database was rolled back.")
    return {"action": "safe_restore", "restored_to": str(DB_PATH), "source": str(src), "pre_restore_backup": str(pre_restore), "post_restore": post, "rolled_back": rolled_back}


def compact_repair(conn: sqlite3.Connection) -> dict[str, Any]:
    before = db_integrity_payload(DB_PATH, "pantry_before_compact")
    pre = backup_db(conn, BACKUP_DIR / f"pre-compact-{_dt.datetime.now().strftime('%Y%m%d-%H%M%S')}.db")
    conn.execute("PRAGMA optimize")
    conn.execute("VACUUM")
    conn.execute("REINDEX")
    conn.commit()
    after = db_integrity_payload(DB_PATH, "pantry_after_compact")
    recipe_before = db_integrity_payload(RECIPE_DB_PATH, "recipe_before_compact")
    with recipe_connect() as rconn:
        rconn.execute("PRAGMA optimize")
        rconn.execute("VACUUM")
        rconn.execute("REINDEX")
        rconn.commit()
    recipe_after = db_integrity_payload(RECIPE_DB_PATH, "recipe_after_compact")
    audit(conn, "compact_repair", {"pre_backup": str(pre), "pantry_ok": after.get("ok"), "recipe_ok": recipe_after.get("ok")})
    return {"action": "compact_repair", "pre_compact_backup": str(pre), "before": before, "after": after, "recipe_before": recipe_before, "recipe_after": recipe_after, "ok": bool(after.get("ok")) and bool(recipe_after.get("ok"))}


def list_audit_events(conn: sqlite3.Connection, limit: int = 100) -> list[dict[str, Any]]:
    rows = conn.execute("SELECT * FROM audit_events ORDER BY id DESC LIMIT ?", (int(limit),)).fetchall()
    out = []
    for r in rows:
        d = dict(r)
        try:
            d["details"] = json.loads(d.get("details") or "{}")
        except Exception:
            pass
        out.append(d)
    return out


def export_audit_json(conn: sqlite3.Connection, path: str | Path, limit: int = 1000) -> Path:
    out = Path(path).expanduser()
    if out.is_dir():
        out = out / f"sentinel-pantry-audit-{_dt.datetime.now().strftime('%Y%m%d-%H%M%S')}.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    payload = {"app": APP_NAME, "version": APP_VERSION, "generated_at": now_iso(), "events": list_audit_events(conn, limit)}
    json_write(out, payload)
    audit(conn, "export_audit_json", {"path": str(out), "limit": limit})
    return out


def validate_import_csv(conn: sqlite3.Connection, path: str | Path) -> dict[str, Any]:
    src = Path(path).expanduser()
    report: dict[str, Any] = {"path": str(src), "exists": src.exists(), "rows_total": 0, "valid_rows": 0, "invalid_rows": [], "duplicate_rows": [], "would_import": 0, "generated_at": now_iso()}
    if not src.exists():
        report["invalid_rows"].append({"row": 0, "error": "file not found"})
        return report
    existing = set()
    for r in conn.execute("SELECT lower(name) n, lower(unit) u, barcode FROM items WHERE archived=0").fetchall():
        existing.add((r["n"] or "", r["u"] or "", r["barcode"] or ""))
    seen = set()
    with src.open("r", newline="", encoding="utf-8-sig") as fh:
        reader = csv.DictReader(fh)
        required_headers = {"name"}
        if not reader.fieldnames or not required_headers.issubset(set(reader.fieldnames)):
            report["invalid_rows"].append({"row": 0, "error": "missing required header: name"})
            return report
        for idx, row in enumerate(reader, start=2):
            report["rows_total"] += 1
            name = (row.get("name") or "").strip()
            unit = (row.get("unit") or "each").strip() or "each"
            barcode = (row.get("barcode") or "").strip()
            if not name:
                report["invalid_rows"].append({"row": idx, "error": "name is required"})
                continue
            for date_key in ("expiry_date", "purchase_date", "opened_date"):
                if row.get(date_key):
                    try:
                        parse_date(row.get(date_key, ""))
                    except Exception as exc:
                        report["invalid_rows"].append({"row": idx, "error": f"{date_key}: {exc}"})
                        break
            else:
                key = (name.lower(), unit.lower(), barcode)
                duplicate = key in existing or key in seen or (barcode and conn.execute("SELECT 1 FROM items WHERE barcode=? AND archived=0", (barcode,)).fetchone())
                if duplicate:
                    report["duplicate_rows"].append({"row": idx, "name": name, "unit": unit, "barcode": barcode})
                seen.add(key)
                report["valid_rows"] += 1
    report["would_import"] = max(0, int(report["valid_rows"]) - len(report["duplicate_rows"]))
    report["ok"] = not report["invalid_rows"]
    return report


def dashboard_summary(conn: sqlite3.Connection) -> dict[str, Any]:
    rows = list_items(conn, include_archived=True, status_filter="")
    active = [r for r in rows if not bool(r["archived"])]
    archived = [r for r in rows if bool(r["archived"])]
    expiry_days = expiring_soon_days(conn)
    low = [r for r in active if low_stock_flag(r)]
    expired = [r for r in active if (r["expiry_date"] and _safe_date(r["expiry_date"]) and _safe_date(r["expiry_date"]) < today())]
    expiring = expiring_soon_items(conn, expiry_days)
    good = [r for r in active if base_status_for_item(r, expiry_days) == "Good"]
    categories = conn.execute("SELECT category, COUNT(*) c FROM items WHERE archived=0 GROUP BY category ORDER BY c DESC").fetchall()
    locations = conn.execute("SELECT location, COUNT(*) c FROM items WHERE archived=0 GROUP BY location ORDER BY c DESC").fetchall()
    shop_counts = shopping_status_counts(conn)
    use_first = use_first_items(conn, 50)
    thirty_days_ago = (_dt.datetime.now() - _dt.timedelta(days=30)).isoformat()
    waste_30 = conn.execute("SELECT COUNT(*) c, COALESCE(SUM(quantity),0) q FROM waste_log WHERE created_at >= ?", (thirty_days_ago,)).fetchone()
    ready = readiness_summary(conn)
    recipes_active = len(list_recipes(conn))
    can_make_count = len([r for r in recipes_can_make(conn, include_almost=False)])
    almost_make_count = len([r for r in recipes_can_make(conn, include_almost=True) if r["availability"]["almost_can_make"]])
    meal_plan_7d = len(list_meal_plan(conn, today().isoformat(), (today() + _dt.timedelta(days=7)).isoformat()))
    return {
        "items_total": len(rows),
        "items_active": len(active),
        "items_archived": len(archived),
        "items_good": len(good),
        "items_low_stock": len(low),
        "items_expiring_soon": len(expiring),
        "items_expired": len(expired),
        "shopping_open": len(list_shopping(conn)),
        "shopping_needed": shop_counts.get("Needed", 0),
        "shopping_urgent": shop_counts.get("Urgent", 0),
        "shopping_bought": shop_counts.get("Bought", 0),
        "shopping_skipped": shop_counts.get("Skipped", 0),
        "shopping_estimated_total": shopping_estimated_total(conn),
        "rotation_use_first": len(use_first),
        "items_opened": len([r for r in active if item_is_opened(r)]),
        "waste_events_30d": int(waste_30["c"] or 0),
        "waste_quantity_30d": float(waste_30["q"] or 0),
        "readiness_score": ready["readiness_score"],
        "readiness_status": ready["readiness_status"],
        "reserve_items": ready["reserve_items"],
        "reserve_low_stock_items": ready["reserve_low_stock_items"],
        "food_days_supply": ready["food_days_supply"],
        "water_days_supply": ready["water_days_supply"],
        "recipes_active": recipes_active,
        "recipes_can_make": can_make_count,
        "recipes_almost_can_make": almost_make_count,
        "meal_plan_next_7d": meal_plan_7d,
        "barcode_profiles": barcode_profile_count(conn),
        "duplicate_groups": len(duplicate_groups(conn)),
        "fast_entry_ready": True,
        "integrity_ok": db_integrity_payload(DB_PATH, "pantry_database").get("ok", False),
        "recovery_ready": True,
        "v1_stable_lock": True,
        "usb_scanner_ready": True,
        "schema_version": SCHEMA_VERSION,
        "expiring_soon_days": expiry_days,
        "categories": {r["category"] or "Uncategorised": r["c"] for r in categories},
        "locations": {r["location"] or "Unassigned": r["c"] for r in locations},
    }


def summary(conn: sqlite3.Connection) -> dict[str, Any]:
    dash = dashboard_summary(conn)
    return {
        "app": APP_NAME,
        "version": APP_VERSION,
        "program_number": PROGRAM_NUMBER,
        "database": str(DB_PATH),
        "recipe_database": str(RECIPE_DB_PATH),
        "recipe_storage_policy": RECIPE_STORAGE_POLICY,
        "recipe_storage_location": RECIPE_STORAGE_LOCATION,
        "recipe_storage_uses_aegis_vault": AEGIS_VAULT_PRESENT and RECIPE_STORAGE_LOCATION == "AEGIS_VAULT",
        "recipe_documents_fallback": str(DOCUMENTS_RECIPE_FALLBACK_DIR),
        "aegis_vault_root": str(AEGIS_VAULT_ROOT),
        "aegis_vault_present": AEGIS_VAULT_PRESENT,
        "network_capable": NETWORK_CAPABLE,
        **dash,
    }


def health_check(conn: sqlite3.Connection) -> dict[str, Any]:
    issues: list[str] = []
    try:
        conn.execute("SELECT COUNT(*) FROM items").fetchone()
        conn.execute("SELECT COUNT(*) FROM settings").fetchone()
    except Exception as exc:
        issues.append(f"database_error: {exc}")
    try:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        test_path = DATA_DIR / ".write_test"
        test_path.write_text("ok", encoding="utf-8")
        test_path.unlink(missing_ok=True)
    except Exception as exc:
        issues.append(f"data_dir_not_writable: {exc}")
    try:
        RECIPE_DB_PATH.parent.mkdir(parents=True, exist_ok=True)
        test_path = RECIPE_DB_PATH.parent / ".write_test"
        test_path.write_text("ok", encoding="utf-8")
        test_path.unlink(missing_ok=True)
        ensure_recipe_vault(conn)
    except Exception as exc:
        issues.append(f"recipe_vault_not_ready: {exc}")
    s = summary(conn)
    s.update({
        "status": "ok" if not issues else "warning",
        "issues": issues,
        "phase": "v1-stable-lock",
        "recipe_storage_ready": RECIPE_DB_PATH.exists(),
        "recipe_storage_policy": RECIPE_STORAGE_POLICY,
        "recipe_storage_location": RECIPE_STORAGE_LOCATION,
        "recipe_storage_uses_aegis_vault": AEGIS_VAULT_PRESENT and RECIPE_STORAGE_LOCATION == "AEGIS_VAULT",
        "recipe_documents_fallback": str(DOCUMENTS_RECIPE_FALLBACK_DIR),
        "recipe_database": str(RECIPE_DB_PATH),
        "permissions": {
            "local_files": "user-data-only",
            "network": "disabled",
            "root_required": False,
            "dangerous_actions": False,
        },
        "aegis_ready": True,
        "recovery_ready": True,
        "v1_stable_lock": True,
        "usb_scanner_ready": True,
        "integrity": {"pantry_database_ok": db_integrity_payload(DB_PATH, "pantry_database").get("ok", False), "recipe_database_ok": db_integrity_payload(RECIPE_DB_PATH, "recipe_database").get("ok", False)},
    })
    return s


def manifest() -> dict[str, Any]:
    if MANIFEST_PATH.exists():
        try:
            data = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
            data.update({
                "version": APP_VERSION,
                "data_paths": [str(DATA_DIR), str(RECIPE_DB_PATH.parent)],
                "recipe_database": str(RECIPE_DB_PATH),
                "recipe_storage_policy": RECIPE_STORAGE_POLICY,
                "recipe_storage_location": RECIPE_STORAGE_LOCATION,
                "recipe_storage_uses_aegis_vault": AEGIS_VAULT_PRESENT and RECIPE_STORAGE_LOCATION == "AEGIS_VAULT",
                "recipe_documents_fallback": str(DOCUMENTS_RECIPE_FALLBACK_DIR),
                "aegis_vault_root": str(AEGIS_VAULT_ROOT),
                "aegis_vault_present": AEGIS_VAULT_PRESENT,
            })
            return data
        except Exception:
            pass
    return {
        "app_id": APP_ID,
        "program_number": PROGRAM_NUMBER,
        "name": APP_NAME,
        "version": APP_VERSION,
        "description": "Local pantry, shopping, expiry rotation, waste-reduction, emergency readiness, AEGIS-capable recipe book, meal planning, barcode catalog, USB scanner-ready fast-entry, AEGIS handoff, recovery hardening, and v1 stable-lock household pantry manager for SentinelOS.",
        "status": "v1-stable-lock",
        "default_network": "Disabled",
        "network_capable": False,
        "max_permission": "Full Local Control",
        "commands": ["sentinel-pantry", "sentinel-pantry-cli", "sentinel-pantry-gui", "aegis-pantry", "sentinel-pantry-install-desktop-launcher", "sentinel-pantry-repair-launcher"],
        "aegis_contract_version": AEGIS_CONTRACT_VERSION,
        "aegis_action_command": "sentinel-pantry aegis <action>",
        "aegis_actions": list(AEGIS_ACTION_NAMES),
        "sentinel_command_card_command": "sentinel-pantry aegis sentinel_command_card",
        "bastion_registration_command": "sentinel-pantry aegis bastion_registration",
        "vault_export_command": "sentinel-pantry aegis vault_export",
        "stable_lock_report_command": "sentinel-pantry stable-lock-report",
        "self_test_command": "sentinel-pantry --self-test",
        "scanner_test_command": "sentinel-pantry scanner-test --code <barcode>",
        "v1_stable_lock": True,
        "data_paths": [str(DATA_DIR), str(RECIPE_DB_PATH.parent)],
        "recipe_database": str(RECIPE_DB_PATH),
        "recipe_storage_policy": RECIPE_STORAGE_POLICY,
        "recipe_storage_location": RECIPE_STORAGE_LOCATION,
        "recipe_storage_uses_aegis_vault": AEGIS_VAULT_PRESENT and RECIPE_STORAGE_LOCATION == "AEGIS_VAULT",
        "recipe_documents_fallback": str(DOCUMENTS_RECIPE_FALLBACK_DIR),
        "aegis_vault_root": str(AEGIS_VAULT_ROOT),
        "aegis_vault_present": AEGIS_VAULT_PRESENT,
        "aegis_capable": True,
        "health_command": "sentinel-pantry --health-check",
        "summary_command": "sentinel-pantry --summary",
        "capabilities": [
            "dashboard", "item status labels", "inventory filters", "quick consume", "quick restock",
            "shopping list generation", "manual shopping items", "shopping statuses", "preferred stores",
            "estimated prices", "restock from shopping list", "shopping history",
            "shopping list text/CSV export", "CSV import/export", "SQLite backup/restore",
            "expiry rotation", "use-first recommendations", "opened-date tracking", "batch/lot fields",
            "waste logging", "waste CSV export", "emergency reserve tracking", "do-not-consume reserve locks",
            "days-of-supply calculator", "household readiness score", "water/calorie tracking",
            "readiness JSON export", "suggested minimum stock guidance", "AEGIS Vault recipe storage", "Documents/Recipies fallback recipe storage", "recipe database", "recipe ingredient matching", "can-make-now checks", "almost-can-make checks", "use-first recipe suggestions", "meal planning", "recipe-to-shopping-list generation", "recipe JSON/CSV export", "separate Recipie Book and Meal Plan tabs", "Recipie Book vertical layout", "auto-filled recipe id", "recipe details count pane", "local barcode catalog", "barcode lookup", "fast add mode", "USB barcode scanner keyboard input compatibility", "duplicate detection", "merge duplicate items", "barcode catalog CSV import/export", "scan mode placeholder", "Ctrl+Q close hotkey", "desktop launcher helper", "AEGIS JSON action contract", "AEGIS Vault handoff export", "B.A.S.T.I.O.N backup registration", "Sentinel Command status card", "machine-readable low-stock/expired/expiring/shopping/readiness payloads", "database integrity check", "backup verification", "restore preview", "safe restore rollback", "checksum manifest", "import validation", "duplicate import protection", "database compact repair", "audit log export", "Recovery & Integrity GUI tab", "Manual & Status GUI tab", "first-run setup settings", "print-friendly shopping output", "package self-test", "stable lock report", "launcher repair helper", "v1 stable lock",
        ],
    }


def print_table(rows: Iterable[sqlite3.Row], expiry_days: int = DEFAULT_EXPIRY_SOON_DAYS) -> None:
    rows = list(rows)
    if not rows:
        print("No pantry items found.")
        return
    headers = ["ID", "Name", "Qty", "Unit", "Min", "Category", "Location", "Expiry", "Status", "Reserve"]
    widths = [4, 22, 8, 8, 8, 16, 16, 12, 18, 9]

    def clip(s: Any, n: int) -> str:
        s = "" if s is None else str(s)
        return s[: n - 1] + "…" if len(s) > n else s

    print(" ".join(h.ljust(w) for h, w in zip(headers, widths)))
    print(" ".join("-" * w for w in widths))
    for r in rows:
        reserve = "Locked" if ("do_not_consume" in r.keys() and r["do_not_consume"]) else ("Reserve" if is_reserve_item(r) else "")
        vals = [r["id"], r["name"], f"{float(r['quantity']):g}", r["unit"], f"{float(r['min_quantity']):g}", r["category"], r["location"], r["expiry_date"], status_for_item(r, expiry_days), reserve]
        print(" ".join(clip(v, w).ljust(w) for v, w in zip(vals, widths)))


def print_shopping(rows: Iterable[sqlite3.Row]) -> None:
    rows = list(rows)
    if not rows:
        print("Shopping list is empty.")
        return
    for r in rows:
        mark = "[!]" if r["status"] == "Urgent" else ("[x]" if r["status"] == "Bought" else "[-]" if r["status"] == "Skipped" else "[ ]")
        store = f" @{r['preferred_store']}" if r["preferred_store"] else ""
        price = f" est.${float(r['estimated_price']):.2f}" if float(r["estimated_price"] or 0) else ""
        notes = f" — {r['notes']}" if r["notes"] else ""
        print(f"{mark} #{r['id']} {r['item_name']} — {float(r['target_quantity']):g} {r['unit']} ({r['category'] or 'Uncategorised'}) [{r['status']}]{store}{price}{notes}")


def print_use_first(rows: Iterable[sqlite3.Row], expiry_days: int = DEFAULT_EXPIRY_SOON_DAYS) -> None:
    rows = list(rows)
    if not rows:
        print("No use-first items found.")
        return
    for r in rows:
        _score, label = rotation_priority(r, expiry_days)
        days = days_until_expiry(r)
        days_text = "no expiry" if days is None else (f"expired {-days}d ago" if days < 0 else f"{days}d left")
        opened = f" opened:{r['opened_date']}" if 'opened_date' in r.keys() and r['opened_date'] else ""
        batch = f" batch:{r['batch_code']}" if 'batch_code' in r.keys() and r['batch_code'] else ""
        print(f"#{r['id']} {r['name']} — {float(r['quantity']):g} {r['unit']} — {label} — {days_text}{opened}{batch}")


def print_waste(rows: Iterable[sqlite3.Row]) -> None:
    rows = list(rows)
    if not rows:
        print("No waste logged yet.")
        return
    for r in rows:
        print(f"#{r['id']} {r['created_at']} {r['item_name']} — {float(r['quantity']):g} {r['unit']} — {r['reason'] or 'waste'} — {r['notes'] or ''}")

class PantryGUI:
    def __init__(self) -> None:
        import tkinter as tk
        from tkinter import ttk, messagebox, filedialog

        self.tk = tk
        self.ttk = ttk
        self.messagebox = messagebox
        self.filedialog = filedialog
        self.conn = connect()
        self.root = tk.Tk()
        self.root.title(f"{APP_NAME} v{APP_VERSION}")
        self.root.minsize(1220, 760)
        self.selected_id: Optional[int] = None
        self.vars: dict[str, Any] = {}
        self.filter_vars: dict[str, Any] = {}
        self.card_vars: dict[str, Any] = {}
        self.current_mode = "all"
        self.build_style()
        self.build_ui()
        self.install_hotkeys()
        self.clear_form()
        self.refresh()

    def install_hotkeys(self) -> None:
        """Install application-wide keyboard shortcuts."""
        self.root.bind_all("<Control-q>", self.close_application)
        self.root.bind_all("<Control-Q>", self.close_application)
        self.root.protocol("WM_DELETE_WINDOW", self.close_application)

    def close_application(self, event: Any = None) -> str:
        """Close Sentinel Pantry cleanly from Ctrl+Q, window close, or menus."""
        try:
            self.conn.close()
        except Exception:
            pass
        try:
            self.root.destroy()
        except Exception:
            pass
        return "break"

    def build_style(self) -> None:
        ttk = self.ttk
        self.root.configure(bg=THEME["bg"])
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except Exception:
            pass
        style.configure(".", background=THEME["bg"], foreground=THEME["fg"], fieldbackground=THEME["field"], bordercolor=THEME["panel"])
        style.configure("TFrame", background=THEME["bg"])
        style.configure("Panel.TFrame", background=THEME["panel"], relief="flat")
        style.configure("Card.TFrame", background=THEME["panel2"], relief="flat")
        style.configure("TLabel", background=THEME["bg"], foreground=THEME["fg"])
        style.configure("Panel.TLabel", background=THEME["panel"], foreground=THEME["fg"])
        style.configure("CardTitle.TLabel", background=THEME["panel2"], foreground=THEME["muted"], font=("Sans", 9, "bold"))
        style.configure("CardValue.TLabel", background=THEME["panel2"], foreground=THEME["gold"], font=("Sans", 20, "bold"))
        style.configure("Muted.TLabel", background=THEME["bg"], foreground=THEME["muted"])
        style.configure("Title.TLabel", background=THEME["bg"], foreground=THEME["gold"], font=("Sans", 18, "bold"))
        style.configure("Status.TLabel", background=THEME["panel"], foreground=THEME["cyan"], font=("Sans", 10, "bold"))
        style.configure("TButton", background=THEME["field"], foreground=THEME["fg"], padding=6)
        style.map("TButton", background=[("active", THEME["gold"])] , foreground=[("active", "#050505")])
        style.configure("Treeview", background=THEME["field"], fieldbackground=THEME["field"], foreground=THEME["fg"], rowheight=26)
        style.configure("Treeview.Heading", background=THEME["panel"], foreground=THEME["gold"], font=("Sans", 10, "bold"))
        style.map("Treeview", background=[("selected", THEME["gold"])], foreground=[("selected", "#050505")])
        style.configure("TNotebook", background=THEME["bg"], borderwidth=0)
        style.configure("TNotebook.Tab", background=THEME["panel"], foreground=THEME["fg"], padding=(12, 6))
        style.map("TNotebook.Tab", background=[("selected", THEME["field"])], foreground=[("selected", THEME["gold"])])
        self.root.option_add("*Entry.Background", THEME["field"])
        self.root.option_add("*Entry.Foreground", THEME["fg"])
        self.root.option_add("*Text.Background", THEME["field"])
        self.root.option_add("*Text.Foreground", THEME["fg"])

    def build_ui(self) -> None:
        ttk = self.ttk
        root = self.root
        top = ttk.Frame(root)
        top.pack(fill="x", padx=14, pady=(12, 4))
        ttk.Label(top, text="Sentinel Pantry", style="Title.TLabel").pack(side="left")
        ttk.Label(top, text="Program 117 • Phase 8 integrity/recovery ready • local-only household stock", style="Muted.TLabel").pack(side="left", padx=(14, 0), pady=(5, 0))

        self.nb = ttk.Notebook(root)
        self.nb.pack(fill="both", expand=True, padx=14, pady=8)
        self.dashboard_tab = ttk.Frame(self.nb)
        self.inventory_tab = ttk.Frame(self.nb)
        self.shopping_tab = ttk.Frame(self.nb)
        self.fast_entry_tab = ttk.Frame(self.nb)
        self.rotation_tab = ttk.Frame(self.nb)
        self.readiness_tab = ttk.Frame(self.nb)
        self.recipes_tab = ttk.Frame(self.nb)
        self.meal_plan_tab = ttk.Frame(self.nb)
        self.aegis_tab = ttk.Frame(self.nb)
        self.recovery_tab = ttk.Frame(self.nb)
        self.manual_tab = ttk.Frame(self.nb)
        self.nb.add(self.dashboard_tab, text="Dashboard")
        self.nb.add(self.inventory_tab, text="Inventory")
        self.nb.add(self.fast_entry_tab, text="Barcode Options")
        self.nb.add(self.shopping_tab, text="Shopping List")
        self.nb.add(self.rotation_tab, text="Rotation & Waste")
        self.nb.add(self.readiness_tab, text="Emergency Readiness")
        self.nb.add(self.recipes_tab, text="Recipie Book")
        self.nb.add(self.meal_plan_tab, text="Meal Plan")
        self.nb.add(self.aegis_tab, text="AEGIS Handoff")
        self.nb.add(self.recovery_tab, text="Recovery & Integrity")
        self.nb.add(self.manual_tab, text="Manual & Status")

        self.build_dashboard_tab()
        self.build_inventory_tab()
        self.build_fast_entry_tab()
        self.build_shopping_tab()
        self.build_rotation_tab()
        self.build_readiness_tab()
        self.build_recipes_tab()
        self.build_meal_plan_tab()
        self.build_aegis_tab()
        self.build_recovery_tab()

        self.status = ttk.Label(root, text="Ready", style="Status.TLabel", anchor="w")
        self.status.pack(fill="x", padx=14, pady=(0, 10))

    def build_dashboard_tab(self) -> None:
        ttk = self.ttk
        frame = self.dashboard_tab
        intro = ttk.Frame(frame, style="Panel.TFrame")
        intro.pack(fill="x", pady=(0, 10))
        ttk.Label(intro, text="Household Pantry Dashboard", style="Status.TLabel").pack(side="left", padx=10, pady=10)
        ttk.Label(intro, text="Daily stock, low-stock, expiry, and shopping visibility.", style="Panel.TLabel").pack(side="left", padx=10, pady=10)
        ttk.Button(intro, text="Close", command=self.close_application).pack(side="right", padx=8, pady=8)
        ttk.Button(intro, text="Refresh", command=self.refresh).pack(side="right", padx=4, pady=8)

        cardrow = ttk.Frame(frame)
        cardrow.pack(fill="x", pady=6)
        for key, title in [
            ("items_active", "Active Items"),
            ("items_low_stock", "Low Stock"),
            ("items_expiring_soon", "Expiring Soon"),
            ("items_expired", "Expired"),
            ("rotation_use_first", "Use First"),
            ("reserve_items", "Reserve Items"),
            ("food_days_supply", "Food Days"),
            ("water_days_supply", "Water Days"),
            ("readiness_score", "Readiness %"),
            ("shopping_open", "Shopping"),
        ]:
            card = ttk.Frame(cardrow, style="Card.TFrame")
            card.pack(side="left", fill="x", expand=True, padx=4, ipadx=6, ipady=6)
            ttk.Label(card, text=title, style="CardTitle.TLabel").pack(anchor="w", padx=10, pady=(8, 2))
            var = self.tk.StringVar(value="0")
            self.card_vars[key] = var
            ttk.Label(card, textvariable=var, style="CardValue.TLabel").pack(anchor="w", padx=10, pady=(0, 8))

        quick = ttk.Frame(frame, style="Panel.TFrame")
        quick.pack(fill="x", pady=10)
        ttk.Label(quick, text="Quick Actions", style="Status.TLabel").pack(side="left", padx=10, pady=10)
        ttk.Button(quick, text="Add Item", command=self.quick_add_item).pack(side="left", padx=4)
        ttk.Button(quick, text="Consume Item", command=self.consume_dialog).pack(side="left", padx=4)
        ttk.Button(quick, text="Restock Item", command=self.restock_dialog).pack(side="left", padx=4)
        ttk.Button(quick, text="Generate Shopping List", command=self.generate_shopping).pack(side="left", padx=4)
        ttk.Button(quick, text="Barcode Options", command=lambda: self.nb.select(self.fast_entry_tab)).pack(side="left", padx=4)
        ttk.Button(quick, text="Use First", command=lambda: self.nb.select(self.rotation_tab)).pack(side="left", padx=4)
        ttk.Button(quick, text="Readiness", command=lambda: self.nb.select(self.readiness_tab)).pack(side="left", padx=4)
        ttk.Button(quick, text="Recipie Book", command=lambda: self.nb.select(self.recipes_tab)).pack(side="left", padx=4)
        ttk.Button(quick, text="Meal Plan", command=lambda: self.nb.select(self.meal_plan_tab)).pack(side="left", padx=4)
        ttk.Button(quick, text="Log Waste", command=self.log_waste_dialog).pack(side="left", padx=4)
        ttk.Button(quick, text="Export Shopping List", command=self.export_shopping_dialog).pack(side="left", padx=4)
        ttk.Button(quick, text="AEGIS Handoff", command=lambda: self.nb.select(self.aegis_tab)).pack(side="right", padx=4)
        ttk.Button(quick, text="Recovery", command=lambda: self.nb.select(self.recovery_tab)).pack(side="right", padx=4)
        ttk.Button(quick, text="Manual / Status", command=lambda: self.nb.select(self.manual_tab)).pack(side="right", padx=4)
        ttk.Button(quick, text="Backup", command=self.backup_dialog).pack(side="right", padx=8)

        lists = ttk.Frame(frame)
        lists.pack(fill="both", expand=True, pady=(6, 0))
        self.dashboard_trees: dict[str, Any] = {}
        for title, key in [("Low Stock", "low"), ("Expiring Soon", "expiring"), ("Expired", "expired")]:
            box = ttk.Frame(lists, style="Panel.TFrame")
            box.pack(side="left", fill="both", expand=True, padx=4)
            ttk.Label(box, text=title, style="Status.TLabel").pack(anchor="w", padx=8, pady=(8, 2))
            tree = ttk.Treeview(box, columns=("name", "qty", "expiry", "status"), show="headings", height=12)
            for col, label, width in [("name", "Name", 150), ("qty", "Qty", 70), ("expiry", "Expiry", 90), ("status", "Status", 120)]:
                tree.heading(col, text=label)
                tree.column(col, width=width, anchor="w")
            tree.pack(fill="both", expand=True, padx=8, pady=(0, 8))
            tree.bind("<Double-1>", self.open_inventory_from_dashboard)
            self.dashboard_trees[key] = tree

    def build_inventory_tab(self) -> None:
        ttk = self.ttk
        tk = self.tk
        frame = self.inventory_tab

        toolbar = ttk.Frame(frame, style="Panel.TFrame")
        toolbar.pack(fill="x", pady=(0, 8))
        self.search_var = tk.StringVar()
        self.filter_vars["category"] = tk.StringVar(value="")
        self.filter_vars["location"] = tk.StringVar(value="")
        self.filter_vars["status"] = tk.StringVar(value="All Active")
        self.filter_vars["low_only"] = tk.BooleanVar(value=False)
        self.filter_vars["include_archived"] = tk.BooleanVar(value=False)

        ttk.Label(toolbar, text="Search:", style="Status.TLabel").pack(side="left", padx=(8, 4), pady=8)
        ent = ttk.Entry(toolbar, textvariable=self.search_var, width=24)
        ent.pack(side="left", padx=4, pady=8)
        ent.bind("<Return>", lambda e: self.refresh())
        ttk.Label(toolbar, text="Category", style="Panel.TLabel").pack(side="left", padx=(8, 4))
        self.category_filter = ttk.Combobox(toolbar, textvariable=self.filter_vars["category"], values=[""] + active_categories(self.conn), width=16)
        self.category_filter.pack(side="left", padx=3)
        ttk.Label(toolbar, text="Location", style="Panel.TLabel").pack(side="left", padx=(8, 4))
        self.location_filter = ttk.Combobox(toolbar, textvariable=self.filter_vars["location"], values=[""] + active_locations(self.conn), width=16)
        self.location_filter.pack(side="left", padx=3)
        ttk.Label(toolbar, text="Status", style="Panel.TLabel").pack(side="left", padx=(8, 4))
        self.status_filter = ttk.Combobox(toolbar, textvariable=self.filter_vars["status"], values=STATUS_FILTERS, width=15, state="readonly")
        self.status_filter.pack(side="left", padx=3)
        ttk.Checkbutton(toolbar, text="Low only", variable=self.filter_vars["low_only"], command=self.refresh).pack(side="left", padx=6)
        ttk.Checkbutton(toolbar, text="Archived", variable=self.filter_vars["include_archived"], command=self.refresh).pack(side="left", padx=6)
        for widget in (self.category_filter, self.location_filter, self.status_filter):
            widget.bind("<<ComboboxSelected>>", lambda e: self.refresh())
        ttk.Button(toolbar, text="Refresh", command=self.refresh).pack(side="left", padx=3)
        ttk.Button(toolbar, text="Clear Filters", command=self.clear_filters).pack(side="left", padx=3)
        ttk.Button(toolbar, text="Export CSV", command=self.export_csv_dialog).pack(side="right", padx=3)
        ttk.Button(toolbar, text="Health", command=self.health_dialog).pack(side="right", padx=3)

        main = ttk.Frame(frame)
        main.pack(fill="both", expand=True)
        table_frame = ttk.Frame(main)
        table_frame.pack(side="left", fill="both", expand=True, padx=(0, 10))

        columns = ("id", "name", "qty", "unit", "min", "category", "location", "expiry", "status")
        self.tree = ttk.Treeview(table_frame, columns=columns, show="headings", selectmode="browse")
        specs = {
            "id": ("ID", 54), "name": ("Name", 220), "qty": ("Qty", 80), "unit": ("Unit", 70),
            "min": ("Min", 70), "category": ("Category", 140), "location": ("Location", 140),
            "expiry": ("Expiry", 100), "status": ("Status", 160),
        }
        for col, (label, width) in specs.items():
            self.tree.heading(col, text=label)
            self.tree.column(col, width=width, anchor="w")
        vsb = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
        self.tree.bind("<<TreeviewSelect>>", self.on_select)

        form = ttk.Frame(main, style="Panel.TFrame")
        form.pack(side="right", fill="y", ipadx=10, ipady=10)
        ttk.Label(form, text="Item Details", style="Status.TLabel").grid(row=0, column=0, columnspan=2, sticky="w", padx=10, pady=(10, 8))
        fields = [
            ("name", "Name"), ("category", "Category"), ("location", "Location"),
            ("quantity", "Quantity"), ("unit", "Unit"), ("min_quantity", "Minimum"),
            ("expiry_date", "Expiry YYYY-MM-DD"), ("purchase_date", "Bought YYYY-MM-DD"),
            ("barcode", "Barcode"), ("batch_code", "Batch/Lot"), ("opened_date", "Opened YYYY-MM-DD"),
            ("emergency_reserve", "Reserve 0/1"), ("do_not_consume", "Lock 0/1"),
            ("readiness_category", "Readiness Category"), ("calories_per_unit", "Calories/Unit"),
            ("water_litres_per_unit", "Water L/Unit"),
        ]
        for i, (key, label) in enumerate(fields, start=1):
            ttk.Label(form, text=label, background=THEME["panel"], foreground=THEME["fg"]).grid(row=i, column=0, sticky="w", padx=10, pady=3)
            var = tk.StringVar()
            self.vars[key] = var
            if key == "category":
                widget = ttk.Combobox(form, textvariable=var, values=active_categories(self.conn), width=26)
            elif key == "location":
                widget = ttk.Combobox(form, textvariable=var, values=active_locations(self.conn), width=26)
            elif key == "unit":
                widget = ttk.Combobox(form, textvariable=var, values=UNIT_PRESETS, width=26)
            elif key == "readiness_category":
                widget = ttk.Combobox(form, textvariable=var, values=READINESS_CATEGORY_PRESETS, width=26)
            else:
                widget = ttk.Entry(form, textvariable=var, width=28)
            widget.grid(row=i, column=1, sticky="ew", padx=10, pady=3)
        notes_row = len(fields) + 1
        ttk.Label(form, text="Notes", background=THEME["panel"], foreground=THEME["fg"]).grid(row=notes_row, column=0, sticky="nw", padx=10, pady=3)
        self.notes = tk.Text(form, width=28, height=5, wrap="word")
        self.notes.grid(row=notes_row, column=1, sticky="ew", padx=10, pady=3)

        buttons = ttk.Frame(form, style="Panel.TFrame")
        buttons.grid(row=notes_row + 1, column=0, columnspan=2, sticky="ew", padx=10, pady=(10, 4))
        ttk.Button(buttons, text="New", command=self.clear_form).grid(row=0, column=0, padx=2, pady=2, sticky="ew")
        ttk.Button(buttons, text="Save", command=self.save).grid(row=0, column=1, padx=2, pady=2, sticky="ew")
        ttk.Button(buttons, text="Consume", command=self.consume_dialog).grid(row=1, column=0, padx=2, pady=2, sticky="ew")
        ttk.Button(buttons, text="Restock", command=self.restock_dialog).grid(row=1, column=1, padx=2, pady=2, sticky="ew")
        ttk.Button(buttons, text="Mark Opened", command=self.mark_opened_dialog).grid(row=2, column=0, padx=2, pady=2, sticky="ew")
        ttk.Button(buttons, text="Log Waste", command=self.log_waste_dialog).grid(row=2, column=1, padx=2, pady=2, sticky="ew")
        ttk.Button(buttons, text="Archive", command=self.archive_selected).grid(row=3, column=0, padx=2, pady=2, sticky="ew")
        ttk.Button(buttons, text="Delete", command=self.delete_selected).grid(row=3, column=1, padx=2, pady=2, sticky="ew")
        buttons.columnconfigure(0, weight=1)
        buttons.columnconfigure(1, weight=1)

    def build_fast_entry_tab(self) -> None:
        ttk = self.ttk
        tk = self.tk
        frame = self.fast_entry_tab
        top = ttk.Frame(frame, style="Panel.TFrame")
        top.pack(fill="x", pady=(0, 8))
        ttk.Label(top, text="Barcode Options / Fast Entry", style="Status.TLabel").pack(side="left", padx=10, pady=10)
        ttk.Label(top, text="Scan, learn, lookup, list, import/export barcode profiles — local only; no online product lookup.", style="Panel.TLabel").pack(side="left", padx=10)

        main = ttk.Frame(frame)
        main.pack(fill="both", expand=True)
        form = ttk.Frame(main, style="Panel.TFrame")
        form.pack(side="left", fill="y", padx=(0, 10), ipadx=10, ipady=10)
        self.fast_vars = {}
        fields = [
            ("barcode", "Barcode / Scanner Input"),
            ("name", "Name"),
            ("quantity", "Quantity"),
            ("unit", "Unit"),
            ("category", "Category"),
            ("location", "Location"),
            ("min_quantity", "Minimum"),
            ("expiry_date", "Expiry YYYY-MM-DD"),
            ("purchase_date", "Bought YYYY-MM-DD"),
            ("preferred_store", "Preferred Store"),
            ("estimated_price", "Estimated Price"),
        ]
        for i, (key, label) in enumerate(fields):
            ttk.Label(form, text=label, style="Panel.TLabel").grid(row=i, column=0, sticky="w", padx=10, pady=4)
            var = tk.StringVar(value="1" if key == "quantity" else ("each" if key == "unit" else ("0" if key in {"min_quantity", "estimated_price"} else "")))
            self.fast_vars[key] = var
            if key == "unit":
                widget = ttk.Combobox(form, textvariable=var, values=UNIT_PRESETS, width=30)
            elif key == "category":
                widget = ttk.Combobox(form, textvariable=var, values=active_categories(self.conn), width=30)
            elif key == "location":
                widget = ttk.Combobox(form, textvariable=var, values=active_locations(self.conn), width=30)
            elif key == "preferred_store":
                widget = ttk.Combobox(form, textvariable=var, values=STORE_PRESETS, width=30)
            else:
                widget = ttk.Entry(form, textvariable=var, width=32)
            widget.grid(row=i, column=1, sticky="ew", padx=10, pady=4)
            if key == "barcode":
                widget.bind("<Return>", lambda e: self.fast_lookup_barcode())
        note_row = len(fields)
        ttk.Label(form, text="Notes", style="Panel.TLabel").grid(row=note_row, column=0, sticky="nw", padx=10, pady=4)
        self.fast_notes = tk.Text(form, width=32, height=4, wrap="word")
        self.fast_notes.grid(row=note_row, column=1, sticky="ew", padx=10, pady=4)
        buttons = ttk.Frame(form, style="Panel.TFrame")
        buttons.grid(row=note_row + 1, column=0, columnspan=2, sticky="ew", padx=10, pady=10)
        ttk.Button(buttons, text="Lookup Barcode", command=self.fast_lookup_barcode).grid(row=0, column=0, padx=3, pady=3, sticky="ew")
        ttk.Button(buttons, text="Fast Add Item", command=self.fast_add_gui).grid(row=0, column=1, padx=3, pady=3, sticky="ew")
        ttk.Button(buttons, text="Learn / Update Profile", command=self.fast_learn_gui).grid(row=1, column=0, padx=3, pady=3, sticky="ew")
        ttk.Button(buttons, text="Clear", command=self.fast_clear).grid(row=1, column=1, padx=3, pady=3, sticky="ew")
        buttons.columnconfigure(0, weight=1)
        buttons.columnconfigure(1, weight=1)

        right = ttk.Frame(main)
        right.pack(side="right", fill="both", expand=True)
        details = ttk.Frame(right, style="Panel.TFrame")
        details.pack(fill="x", pady=(0, 10))
        ttk.Label(details, text="Local Barcode Profile", style="Status.TLabel").pack(anchor="w", padx=10, pady=(10, 4))
        self.fast_profile_text = tk.Text(details, height=8, wrap="word")
        self.fast_profile_text.pack(fill="x", padx=10, pady=(0, 10))

        catalog_frame = ttk.Frame(right, style="Panel.TFrame")
        catalog_frame.pack(fill="both", expand=True, pady=(0, 10))
        catalog_bar = ttk.Frame(catalog_frame, style="Panel.TFrame")
        catalog_bar.pack(fill="x")
        ttk.Label(catalog_bar, text="Barcode Catalog", style="Status.TLabel").pack(side="left", padx=10, pady=8)
        ttk.Button(catalog_bar, text="Refresh", command=self.refresh_fast_entry).pack(side="right", padx=4)
        ttk.Button(catalog_bar, text="Import CSV", command=self.import_barcode_catalog_dialog).pack(side="right", padx=4)
        ttk.Button(catalog_bar, text="Export CSV", command=self.export_barcode_catalog_dialog).pack(side="right", padx=4)
        ttk.Button(catalog_bar, text="Delete Profile", command=self.delete_selected_barcode_gui).pack(side="right", padx=4)
        ttk.Button(catalog_bar, text="Load Selected", command=self.load_selected_barcode_profile).pack(side="right", padx=4)
        columns = ("barcode", "name", "category", "unit", "location", "min", "store", "price")
        self.barcode_catalog_tree = ttk.Treeview(catalog_frame, columns=columns, show="headings", selectmode="browse", height=9)
        specs = {
            "barcode": ("Barcode", 150), "name": ("Name", 210), "category": ("Category", 120),
            "unit": ("Unit", 70), "location": ("Location", 110), "min": ("Min", 70),
            "store": ("Store", 120), "price": ("Price", 80),
        }
        for col, (label, width) in specs.items():
            self.barcode_catalog_tree.heading(col, text=label)
            self.barcode_catalog_tree.column(col, width=width, anchor="w")
        self.barcode_catalog_tree.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        self.barcode_catalog_tree.bind("<Double-1>", self.load_selected_barcode_profile)

        dup_frame = ttk.Frame(right, style="Panel.TFrame")
        dup_frame.pack(fill="both", expand=True)
        dup_bar = ttk.Frame(dup_frame, style="Panel.TFrame")
        dup_bar.pack(fill="x")
        ttk.Label(dup_bar, text="Duplicate Finder", style="Status.TLabel").pack(side="left", padx=10, pady=8)
        ttk.Button(dup_bar, text="Refresh", command=self.refresh_fast_entry).pack(side="right", padx=10)
        columns = ("kind", "key", "count", "ids", "qty")
        self.duplicates_tree = ttk.Treeview(dup_frame, columns=columns, show="headings", selectmode="browse", height=6)
        specs = {"kind": ("Kind", 110), "key": ("Match", 260), "count": ("Count", 80), "ids": ("IDs", 170), "qty": ("Total Qty", 90)}
        for col, (label, width) in specs.items():
            self.duplicates_tree.heading(col, text=label)
            self.duplicates_tree.column(col, width=width, anchor="w")
        self.duplicates_tree.pack(fill="both", expand=True, padx=10, pady=(0, 10))

    def build_shopping_tab(self) -> None:
        ttk = self.ttk
        tk = self.tk
        frame = self.shopping_tab
        toolbar = ttk.Frame(frame, style="Panel.TFrame")
        toolbar.pack(fill="x", pady=(0, 8))
        ttk.Button(toolbar, text="Generate from Low Stock", command=self.generate_shopping).pack(side="left", padx=4, pady=8)
        ttk.Button(toolbar, text="Add Manual Item", command=self.add_manual_shopping_dialog).pack(side="left", padx=4)
        ttk.Button(toolbar, text="Mark Needed", command=lambda: self.mark_selected_shopping_status("Needed")).pack(side="left", padx=4)
        ttk.Button(toolbar, text="Mark Urgent", command=lambda: self.mark_selected_shopping_status("Urgent")).pack(side="left", padx=4)
        ttk.Button(toolbar, text="Bought + Restock", command=self.restock_selected_shopping).pack(side="left", padx=4)
        ttk.Button(toolbar, text="Skip", command=lambda: self.mark_selected_shopping_status("Skipped")).pack(side="left", padx=4)
        ttk.Button(toolbar, text="Export TXT", command=self.export_shopping_dialog).pack(side="left", padx=4)
        ttk.Button(toolbar, text="Export CSV", command=self.export_shopping_csv_dialog).pack(side="left", padx=4)
        ttk.Button(toolbar, text="Refresh", command=self.refresh_shopping).pack(side="left", padx=4)
        self.shopping_all_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(toolbar, text="Show completed", variable=self.shopping_all_var, command=self.refresh_shopping).pack(side="right", padx=8)

        filters = ttk.Frame(frame, style="Panel.TFrame")
        filters.pack(fill="x", pady=(0, 8))
        self.shopping_status_filter = tk.StringVar(value="")
        self.shopping_store_filter = tk.StringVar(value="")
        ttk.Label(filters, text="Status", style="Panel.TLabel").pack(side="left", padx=(8, 4))
        ttk.Combobox(filters, textvariable=self.shopping_status_filter, values=[""] + SHOPPING_STATUSES, width=12, state="readonly").pack(side="left", padx=4)
        ttk.Label(filters, text="Store", style="Panel.TLabel").pack(side="left", padx=(10, 4))
        ttk.Combobox(filters, textvariable=self.shopping_store_filter, values=STORE_PRESETS, width=16).pack(side="left", padx=4)
        ttk.Button(filters, text="Apply", command=self.refresh_shopping).pack(side="left", padx=4)
        ttk.Button(filters, text="Clear", command=self.clear_shopping_filters).pack(side="left", padx=4)

        self.shopping_tree = ttk.Treeview(frame, columns=("id", "item", "qty", "unit", "category", "status", "store", "price", "source", "notes"), show="headings")
        for col, label, width in [
            ("id", "ID", 55), ("item", "Item", 240), ("qty", "Qty", 70), ("unit", "Unit", 70),
            ("category", "Category", 130), ("status", "Status", 90), ("store", "Store", 120),
            ("price", "Est. Price", 90), ("source", "Source", 100), ("notes", "Notes", 260),
        ]:
            self.shopping_tree.heading(col, text=label)
            self.shopping_tree.column(col, width=width, anchor="w")
        self.shopping_tree.pack(fill="both", expand=True, padx=4, pady=4)
        self.shopping_tree.tag_configure("urgent", foreground=THEME["gold"])
        self.shopping_tree.tag_configure("done", foreground=THEME["muted"])

    def build_rotation_tab(self) -> None:
        ttk = self.ttk
        frame = self.rotation_tab
        top = ttk.Frame(frame, style="Panel.TFrame")
        top.pack(fill="x", pady=(0, 8))
        ttk.Label(top, text="Expiry Rotation & Waste Reduction", style="Status.TLabel").pack(side="left", padx=10, pady=10)
        ttk.Button(top, text="Mark Selected Opened", command=self.mark_opened_dialog).pack(side="left", padx=4)
        ttk.Button(top, text="Log Waste", command=self.log_waste_dialog).pack(side="left", padx=4)
        ttk.Button(top, text="Export Waste CSV", command=self.export_waste_csv_dialog).pack(side="left", padx=4)
        ttk.Button(top, text="Refresh", command=self.refresh_rotation).pack(side="right", padx=8)

        body = ttk.Frame(frame)
        body.pack(fill="both", expand=True)
        left = ttk.Frame(body, style="Panel.TFrame")
        right = ttk.Frame(body, style="Panel.TFrame")
        left.pack(side="left", fill="both", expand=True, padx=(0, 5))
        right.pack(side="left", fill="both", expand=True, padx=(5, 0))
        ttk.Label(left, text="Use First Recommendations", style="Status.TLabel").pack(anchor="w", padx=8, pady=(8, 2))
        self.rotation_tree = ttk.Treeview(left, columns=("id", "name", "qty", "expiry", "opened", "priority"), show="headings", height=18)
        for col, label, width in [("id", "ID", 55), ("name", "Name", 220), ("qty", "Qty", 90), ("expiry", "Expiry", 100), ("opened", "Opened", 100), ("priority", "Priority", 180)]:
            self.rotation_tree.heading(col, text=label)
            self.rotation_tree.column(col, width=width, anchor="w")
        self.rotation_tree.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        self.rotation_tree.bind("<<TreeviewSelect>>", self.on_rotation_select)
        self.rotation_tree.tag_configure("danger", foreground=THEME["danger"])
        self.rotation_tree.tag_configure("warn", foreground=THEME["gold"])

        ttk.Label(right, text="Waste Log", style="Status.TLabel").pack(anchor="w", padx=8, pady=(8, 2))
        self.waste_tree = ttk.Treeview(right, columns=("id", "date", "item", "qty", "reason", "notes"), show="headings", height=18)
        for col, label, width in [("id", "ID", 55), ("date", "Date", 150), ("item", "Item", 190), ("qty", "Qty", 80), ("reason", "Reason", 120), ("notes", "Notes", 230)]:
            self.waste_tree.heading(col, text=label)
            self.waste_tree.column(col, width=width, anchor="w")
        self.waste_tree.pack(fill="both", expand=True, padx=8, pady=(0, 8))


    def init_recipe_vars(self) -> None:
        """Create shared StringVars for recipe and meal-plan GUI workflows."""
        if hasattr(self, "recipe_vars"):
            return
        tk = self.tk
        self.recipe_vars = {
            "name": tk.StringVar(), "category": tk.StringVar(value="Meals"), "recipe_id": tk.StringVar(value=str(next_recipe_id())), "servings": tk.StringVar(value="1"),
            "ingredient_recipe": tk.StringVar(), "ingredient_name": tk.StringVar(), "ingredient_qty": tk.StringVar(value="1"), "ingredient_unit": tk.StringVar(value="each"),
            "meal_recipe": tk.StringVar(), "meal_date": tk.StringVar(value=today().isoformat()), "meal_type": tk.StringVar(value="Dinner"), "meal_servings": tk.StringVar(value="1"),
        }

    def build_recipes_tab(self) -> None:
        ttk = self.ttk
        tk = self.tk
        frame = self.recipes_tab
        self.init_recipe_vars()

        top = ttk.Frame(frame, style="Panel.TFrame")
        top.pack(fill="x", pady=(0, 8))
        ttk.Label(top, text="Recipie Book", style="Status.TLabel").pack(side="left", padx=10, pady=10)
        ttk.Label(top, text="AEGIS-capable recipes, ingredients, pantry matching, and use-first suggestions.", style="Panel.TLabel").pack(side="left", padx=10, pady=10)
        ttk.Button(top, text="Refresh", command=self.refresh_recipes).pack(side="right", padx=4, pady=8)
        ttk.Button(top, text="Export Recipes JSON", command=self.export_recipes_json_dialog).pack(side="right", padx=4, pady=8)
        ttk.Button(top, text="Generate Shopping for Selected Recipe", command=self.generate_recipe_shopping_gui).pack(side="right", padx=4, pady=8)
        ttk.Button(top, text="Plan Selected Recipe", command=lambda: self.nb.select(self.meal_plan_tab)).pack(side="right", padx=4, pady=8)

        entry_area = ttk.Frame(frame)
        entry_area.pack(fill="x", pady=(0, 8))
        form = ttk.Frame(entry_area, style="Panel.TFrame")
        details = ttk.Frame(entry_area, style="Panel.TFrame")
        form.pack(side="left", fill="x", expand=True, padx=(0, 5))
        details.pack(side="left", fill="both", padx=(5, 0))

        ttk.Label(form, text="Recipe", style="Status.TLabel").grid(row=0, column=0, padx=8, pady=6, sticky="w")
        ttk.Entry(form, textvariable=self.recipe_vars["name"], width=34).grid(row=0, column=1, padx=4, pady=6, sticky="w")
        ttk.Label(form, text="Category", style="Panel.TLabel").grid(row=1, column=0, padx=8, pady=6, sticky="w")
        ttk.Entry(form, textvariable=self.recipe_vars["category"], width=24).grid(row=1, column=1, padx=4, pady=6, sticky="w")
        ttk.Label(form, text="Recipe ID", style="Panel.TLabel").grid(row=2, column=0, padx=8, pady=6, sticky="w")
        ttk.Entry(form, textvariable=self.recipe_vars["recipe_id"], width=10, state="readonly").grid(row=2, column=1, padx=4, pady=6, sticky="w")
        ttk.Label(form, text="Servings", style="Panel.TLabel").grid(row=3, column=0, padx=8, pady=6, sticky="w")
        ttk.Entry(form, textvariable=self.recipe_vars["servings"], width=10).grid(row=3, column=1, padx=4, pady=6, sticky="w")
        ttk.Button(form, text="Add Recipe", command=self.add_recipe_gui).grid(row=4, column=1, padx=4, pady=(4, 10), sticky="w")
        ttk.Separator(form, orient="horizontal").grid(row=5, column=0, columnspan=2, sticky="ew", padx=8, pady=6)
        ttk.Label(form, text="Ingredient", style="Status.TLabel").grid(row=6, column=0, padx=8, pady=6, sticky="w")
        ttk.Label(form, text="Recipe ID", style="Panel.TLabel").grid(row=7, column=0, padx=8, pady=6, sticky="w")
        ttk.Entry(form, textvariable=self.recipe_vars["ingredient_recipe"], width=10, state="readonly").grid(row=7, column=1, padx=4, pady=6, sticky="w")
        ttk.Label(form, text="Item", style="Panel.TLabel").grid(row=8, column=0, padx=8, pady=6, sticky="w")
        ttk.Entry(form, textvariable=self.recipe_vars["ingredient_name"], width=34).grid(row=8, column=1, padx=4, pady=6, sticky="w")
        ttk.Label(form, text="Quantity", style="Panel.TLabel").grid(row=9, column=0, padx=8, pady=6, sticky="w")
        qtyrow = ttk.Frame(form, style="Panel.TFrame")
        qtyrow.grid(row=9, column=1, padx=4, pady=6, sticky="w")
        ttk.Entry(qtyrow, textvariable=self.recipe_vars["ingredient_qty"], width=10).pack(side="left", padx=(0, 4))
        ttk.Combobox(qtyrow, textvariable=self.recipe_vars["ingredient_unit"], values=UNIT_PRESETS, width=10).pack(side="left")
        ttk.Button(form, text="Add Ingredient", command=self.add_recipe_ingredient_gui).grid(row=10, column=1, padx=4, pady=(4, 10), sticky="w")

        ttk.Label(details, text="General Details", style="Status.TLabel").pack(anchor="w", padx=10, pady=(10, 2))
        self.recipe_book_total_var = tk.StringVar(value="Total recipes in book: 0")
        ttk.Label(details, textvariable=self.recipe_book_total_var, style="CardValue.TLabel").pack(anchor="w", padx=10, pady=(8, 2))
        storage_label = "AEGIS Vault" if RECIPE_STORAGE_LOCATION == "AEGIS_VAULT" else "Documents/Recipies fallback" if RECIPE_STORAGE_LOCATION == "DOCUMENTS_RECIPIES_FALLBACK" else RECIPE_STORAGE_LOCATION
        ttk.Label(details, text=f"Storage: {storage_label}\n{RECIPE_DB_PATH}", style="Panel.TLabel", wraplength=420, justify="left").pack(anchor="w", padx=10, pady=(8, 10))

        body = ttk.Frame(frame)
        body.pack(fill="both", expand=True)
        recipe_panel = ttk.Frame(body, style="Panel.TFrame")
        recipe_panel.pack(fill="both", expand=True, pady=(0, 6))
        ttk.Label(recipe_panel, text="Recipe Availability", style="Status.TLabel").pack(anchor="w", padx=8, pady=(8, 2))
        self.recipe_tree = ttk.Treeview(recipe_panel, columns=("id", "name", "category", "servings", "status", "ingredients", "missing"), show="headings", height=13)
        for col, label, width in [("id", "ID", 55), ("name", "Name", 260), ("category", "Category", 130), ("servings", "Servings", 75), ("status", "Status", 160), ("ingredients", "Ingredients", 95), ("missing", "Missing/Low", 95)]:
            self.recipe_tree.heading(col, text=label)
            self.recipe_tree.column(col, width=width, anchor="w")
        self.recipe_tree.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        self.recipe_tree.bind("<<TreeviewSelect>>", self.on_recipe_select)
        self.recipe_tree.tag_configure("ok", foreground=THEME["ok"])
        self.recipe_tree.tag_configure("warn", foreground=THEME["gold"])
        self.recipe_tree.tag_configure("danger", foreground=THEME["danger"])

        detail = ttk.Frame(body, style="Panel.TFrame")
        detail.pack(fill="x", pady=(6, 4))
        ttk.Label(detail, text="Selected Recipe Detail", style="Status.TLabel").pack(anchor="w", padx=8, pady=(8, 2))
        self.recipe_detail_text = tk.Text(detail, height=7, wrap="word")
        self.recipe_detail_text.pack(fill="x", padx=8, pady=(0, 8))

    def build_meal_plan_tab(self) -> None:
        ttk = self.ttk
        frame = self.meal_plan_tab
        self.init_recipe_vars()

        top = ttk.Frame(frame, style="Panel.TFrame")
        top.pack(fill="x", pady=(0, 8))
        ttk.Label(top, text="Meal Plan", style="Status.TLabel").pack(side="left", padx=10, pady=10)
        ttk.Label(top, text="Plan meals from the Recipie Book and generate shopping items from missing ingredients.", style="Panel.TLabel").pack(side="left", padx=10, pady=10)
        ttk.Button(top, text="Refresh", command=self.refresh_recipes).pack(side="right", padx=4, pady=8)
        ttk.Button(top, text="Generate Shopping From Meal Plan", command=self.generate_meal_plan_shopping_gui).pack(side="right", padx=4, pady=8)
        ttk.Button(top, text="Open Recipie Book", command=lambda: self.nb.select(self.recipes_tab)).pack(side="right", padx=4, pady=8)

        form = ttk.Frame(frame, style="Panel.TFrame")
        form.pack(fill="x", pady=(0, 8))
        ttk.Label(form, text="Plan Meal", style="Status.TLabel").grid(row=0, column=0, padx=8, pady=6, sticky="w")
        ttk.Label(form, text="Recipe ID", style="Panel.TLabel").grid(row=0, column=1, padx=(4, 4), pady=6, sticky="e")
        ttk.Entry(form, textvariable=self.recipe_vars["meal_recipe"], width=8).grid(row=0, column=2, padx=4, pady=6, sticky="w")
        ttk.Label(form, text="Date", style="Panel.TLabel").grid(row=0, column=3, padx=(8, 4), pady=6, sticky="e")
        ttk.Entry(form, textvariable=self.recipe_vars["meal_date"], width=13).grid(row=0, column=4, padx=4, pady=6, sticky="w")
        ttk.Label(form, text="Meal", style="Panel.TLabel").grid(row=0, column=5, padx=(8, 4), pady=6, sticky="e")
        ttk.Combobox(form, textvariable=self.recipe_vars["meal_type"], values=MEAL_TYPES, width=12, state="readonly").grid(row=0, column=6, padx=4, pady=6, sticky="w")
        ttk.Label(form, text="Servings", style="Panel.TLabel").grid(row=0, column=7, padx=(8, 4), pady=6, sticky="e")
        ttk.Entry(form, textvariable=self.recipe_vars["meal_servings"], width=8).grid(row=0, column=8, padx=4, pady=6, sticky="w")
        ttk.Button(form, text="Plan Meal", command=self.add_meal_plan_gui).grid(row=0, column=9, padx=8, pady=6)

        body = ttk.Frame(frame, style="Panel.TFrame")
        body.pack(fill="both", expand=True)
        ttk.Label(body, text="Next 7 Days", style="Status.TLabel").pack(anchor="w", padx=8, pady=(8, 2))
        self.meal_tree = ttk.Treeview(body, columns=("id", "date", "meal", "recipe", "servings", "status"), show="headings", height=20)
        for col, label, width in [("id", "ID", 55), ("date", "Date", 110), ("meal", "Meal", 100), ("recipe", "Recipe", 300), ("servings", "Servings", 80), ("status", "Status", 110)]:
            self.meal_tree.heading(col, text=label)
            self.meal_tree.column(col, width=width, anchor="w")
        self.meal_tree.pack(fill="both", expand=True, padx=8, pady=(0, 8))

    def selected_recipe_id(self) -> Optional[int]:
        sel = self.recipe_tree.selection() if hasattr(self, "recipe_tree") else []
        if sel:
            try:
                return int(self.recipe_tree.item(sel[0], "values")[0])
            except Exception:
                return None
        try:
            value = self.recipe_vars.get("ingredient_recipe").get().strip()
            return int(value) if value else None
        except Exception:
            return None

    def on_recipe_select(self, _event: Any = None) -> None:
        rid = self.selected_recipe_id()
        if not rid:
            return
        try:
            self.recipe_vars["recipe_id"].set(str(rid))
            self.recipe_vars["ingredient_recipe"].set(str(rid))
            self.recipe_vars["meal_recipe"].set(str(rid))
            data = recipe_to_dict(self.conn, rid)
            lines = [f"{data['recipe']['name']} — {data['availability']['status']}", "Ingredients:"]
            for ing in data["ingredients"]:
                lines.append(f"- {ing['item_name']}: {float(ing['quantity']):g} {ing['unit']}")
            if data["recipe"].get("instructions"):
                lines += ["", "Instructions:", data["recipe"].get("instructions", "")]
            self.recipe_detail_text.delete("1.0", "end")
            self.recipe_detail_text.insert("1.0", "\n".join(lines))
        except Exception as exc:
            self.recipe_detail_text.delete("1.0", "end")
            self.recipe_detail_text.insert("1.0", str(exc))

    def add_recipe_gui(self) -> None:
        try:
            rid = add_recipe(self.conn, self.recipe_vars["name"].get(), self.recipe_vars["category"].get(), float(self.recipe_vars["servings"].get() or 1))
            self.recipe_vars["name"].set("")
            self.recipe_vars["recipe_id"].set(str(rid))
            self.recipe_vars["ingredient_recipe"].set(str(rid))
            self.recipe_vars["meal_recipe"].set(str(rid))
            self.refresh()
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))

    def add_recipe_ingredient_gui(self) -> None:
        try:
            rid = int(self.recipe_vars["ingredient_recipe"].get() or 0)
            add_recipe_ingredient(self.conn, rid, self.recipe_vars["ingredient_name"].get(), float(self.recipe_vars["ingredient_qty"].get() or 1), self.recipe_vars["ingredient_unit"].get())
            self.recipe_vars["ingredient_name"].set("")
            self.recipe_vars["ingredient_qty"].set("1")
            self.refresh()
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))

    def add_meal_plan_gui(self) -> None:
        try:
            mid = add_meal_plan(self.conn, int(self.recipe_vars["meal_recipe"].get() or 0), self.recipe_vars["meal_date"].get(), self.recipe_vars["meal_type"].get(), float(self.recipe_vars["meal_servings"].get() or 1))
            self.refresh()
            self.messagebox.showinfo(APP_NAME, f"Planned meal #{mid}.")
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))

    def generate_recipe_shopping_gui(self) -> None:
        rid = self.selected_recipe_id()
        if not rid:
            self.messagebox.showwarning(APP_NAME, "Select a recipe first.")
            return
        try:
            count = recipe_generate_shopping(self.conn, rid)
            self.refresh()
            self.messagebox.showinfo(APP_NAME, f"Added {count} missing/low ingredient(s) to shopping.")
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))

    def generate_meal_plan_shopping_gui(self) -> None:
        try:
            count = meal_plan_generate_shopping(self.conn)
            self.refresh()
            self.messagebox.showinfo(APP_NAME, f"Added {count} missing/low meal-plan ingredient(s) to shopping.")
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))

    def export_recipes_json_dialog(self) -> None:
        path = self.filedialog.asksaveasfilename(title="Export recipes JSON", defaultextension=".json", filetypes=[("JSON", "*.json")], initialfile=f"sentinel-pantry-recipes-{today().isoformat()}.json")
        if not path:
            return
        try:
            out = export_recipes_json(self.conn, path)
            self.messagebox.showinfo(APP_NAME, f"Recipes exported to:\n{out}")
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))

    def refresh_recipes(self) -> None:
        if not hasattr(self, "recipe_tree"):
            return
        try:
            self.recipe_vars["recipe_id"].set(str(next_recipe_id()))
        except Exception:
            pass
        if hasattr(self, "recipe_book_total_var"):
            self.recipe_book_total_var.set(f"Total recipes in book: {recipe_book_total()}")
        self.recipe_tree.delete(*self.recipe_tree.get_children())
        for r in list_recipes(self.conn):
            avail = recipe_availability(self.conn, int(r["id"]))
            missing = len(avail["missing"]) + len(avail["low"])
            tag = "ok" if avail["can_make"] else ("warn" if avail["almost_can_make"] else "danger")
            self.recipe_tree.insert("", "end", values=(r["id"], r["name"], r["category"], f"{float(r['servings']):g}", avail["status"], avail["ingredient_count"], missing), tags=(tag,))
        if hasattr(self, "meal_tree"):
            self.meal_tree.delete(*self.meal_tree.get_children())
            for m in list_meal_plan(self.conn):
                self.meal_tree.insert("", "end", values=(m["id"], m["plan_date"], m["meal_type"], m["recipe_name"], f"{float(m['servings']):g}", m["status"]))

    def build_readiness_tab(self) -> None:
        ttk = self.ttk
        tk = self.tk
        frame = self.readiness_tab
        top = ttk.Frame(frame, style="Panel.TFrame")
        top.pack(fill="x", pady=(0, 8))
        ttk.Label(top, text="Emergency / Off-Grid Readiness", style="Status.TLabel").pack(side="left", padx=10, pady=10)
        ttk.Button(top, text="Refresh", command=self.refresh_readiness).pack(side="right", padx=4, pady=8)
        ttk.Button(top, text="Export JSON", command=self.export_readiness_dialog).pack(side="right", padx=4, pady=8)

        settings = ttk.Frame(frame, style="Panel.TFrame")
        settings.pack(fill="x", pady=(0, 8))
        self.ready_vars = {
            "household_members": tk.StringVar(value=str(household_members(self.conn))),
            "reserve_days_target": tk.StringVar(value=str(reserve_days_target(self.conn))),
            "calories_per_person_day": tk.StringVar(value=get_setting(self.conn, "calories_per_person_day", str(DEFAULT_CALORIES_PER_PERSON_DAY))),
            "water_litres_per_person_day": tk.StringVar(value=get_setting(self.conn, "water_litres_per_person_day", str(DEFAULT_WATER_LITRES_PER_PERSON_DAY))),
        }
        labels = [("household_members", "Household members"), ("reserve_days_target", "Reserve target days"), ("calories_per_person_day", "Calories/person/day"), ("water_litres_per_person_day", "Water L/person/day")]
        for i, (key, label) in enumerate(labels):
            ttk.Label(settings, text=label, style="Panel.TLabel").grid(row=0, column=i*2, padx=(10, 4), pady=8, sticky="w")
            ttk.Entry(settings, textvariable=self.ready_vars[key], width=10).grid(row=0, column=i*2+1, padx=(0, 10), pady=8)
        ttk.Button(settings, text="Save Settings", command=self.save_readiness_settings).grid(row=0, column=8, padx=8, pady=8)

        self.readiness_text = tk.Text(frame, height=9, wrap="word")
        self.readiness_text.pack(fill="x", padx=4, pady=(0, 8))

        self.reserve_tree = ttk.Treeview(frame, columns=("id", "name", "qty", "category", "readiness", "cal", "water", "lock", "status"), show="headings")
        for col, label, width in [
            ("id", "ID", 55), ("name", "Name", 220), ("qty", "Qty", 80), ("category", "Category", 130),
            ("readiness", "Readiness Category", 150), ("cal", "Cal/Unit", 90), ("water", "Water L/Unit", 110),
            ("lock", "Reserve", 90), ("status", "Status", 150),
        ]:
            self.reserve_tree.heading(col, text=label)
            self.reserve_tree.column(col, width=width, anchor="w")
        self.reserve_tree.pack(fill="both", expand=True, padx=4, pady=4)

    def build_aegis_tab(self) -> None:
        ttk = self.ttk
        tk = self.tk
        frame = self.aegis_tab
        top = ttk.Frame(frame, style="Panel.TFrame")
        top.pack(fill="x", pady=(0, 8))
        ttk.Label(top, text="AEGIS Handoff / Sentinel Command / B.A.S.T.I.O.N", style="Status.TLabel").pack(side="left", padx=10, pady=8)
        ttk.Button(top, text="Refresh Card", command=self.refresh_aegis_view).pack(side="right", padx=4, pady=8)
        ttk.Button(top, text="Export Handoff", command=self.export_aegis_handoff_dialog).pack(side="right", padx=4, pady=8)
        ttk.Button(top, text="B.A.S.T.I.O.N Register", command=self.write_bastion_registration_dialog).pack(side="right", padx=4, pady=8)
        ttk.Button(top, text="AEGIS Backup", command=self.aegis_backup_dialog).pack(side="right", padx=4, pady=8)
        info = ttk.Frame(frame, style="Panel.TFrame")
        info.pack(fill="x", pady=(0, 8))
        ttk.Label(info, text="Stable local JSON actions are available through: sentinel-pantry aegis <action>. No network access is used.", style="Panel.TLabel").pack(anchor="w", padx=10, pady=(8, 2))
        ttk.Label(info, text=f"Default handoff target: {active_aegis_export_dir()}", style="Panel.TLabel").pack(anchor="w", padx=10, pady=(0, 8))
        self.aegis_text = tk.Text(frame, height=24, wrap="word", bg=THEME["field"], fg=THEME["fg"], insertbackground=THEME["fg"], relief="flat")
        self.aegis_text.pack(fill="both", expand=True, padx=4, pady=4)

    def refresh_aegis_view(self) -> None:
        if not hasattr(self, "aegis_text"):
            return
        payload = {
            "sentinel_command_card": sentinel_command_card(self.conn),
            "aegis_contract": aegis_action_contract(),
        }
        self.aegis_text.delete("1.0", "end")
        self.aegis_text.insert("1.0", json.dumps(payload, indent=2, sort_keys=True))

    def export_aegis_handoff_dialog(self) -> None:
        try:
            payload = export_aegis_vault_handoff(self.conn)
            self.refresh_aegis_view()
            self.messagebox.showinfo(APP_NAME, f"AEGIS handoff exported to:\n{payload['export_dir']}")
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))

    def write_bastion_registration_dialog(self) -> None:
        try:
            payload = write_bastion_registration(self.conn)
            self.refresh_aegis_view()
            self.messagebox.showinfo(APP_NAME, f"B.A.S.T.I.O.N registration written to:\n{payload['written_to']}")
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))

    def aegis_backup_dialog(self) -> None:
        try:
            payload = aegis_backup(self.conn)
            self.refresh_aegis_view()
            self.messagebox.showinfo(APP_NAME, f"AEGIS backup created:\n{payload['backup_dir']}")
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))

    def build_manual_tab(self) -> None:
        frame = self.manual_tab
        ttk.Label(frame, text="Manual & Status", style="Title.TLabel").pack(anchor="w", padx=10, pady=(10, 4))
        info = ttk.Frame(frame, style="Panel.TFrame")
        info.pack(fill="x", padx=10, pady=8)
        self.manual_status = tk.StringVar(value=f"{APP_NAME} v{APP_VERSION} — v1 stable lock")
        ttk.Label(info, textvariable=self.manual_status, style="Panel.TLabel").pack(anchor="w", padx=10, pady=(8, 2))
        text = (
            "Daily workflow: add stock in Inventory, scan products in Barcode Options, review low stock in Dashboard, "
            "generate Shopping List before going out, and use Rotation & Waste to use older food first.\n\n"
            "USB barcode scanner: plug in a keyboard-wedge scanner, open Barcode Options, click the Barcode field, then scan. "
            "Known local profiles autofill. Unknown products can be entered once and learned locally. No online lookup is used.\n\n"
            "Recipie Book storage: recipes use an existing AEGIS Vault when present, otherwise ~/Documents/Recipies.\n\n"
            "Useful commands: sentinel-pantry --self-test, sentinel-pantry stable-lock-report, sentinel-pantry scanner-test --code <barcode>, "
            "sentinel-pantry-install-desktop-launcher, sentinel-pantry-repair-launcher."
        )
        box = tk.Text(frame, height=14, wrap="word", bg=THEME["field"], fg=THEME["fg"], insertbackground=THEME["fg"], relief="flat")
        box.pack(fill="both", expand=True, padx=10, pady=8)
        box.insert("1.0", text)
        box.configure(state="disabled")
        buttons = ttk.Frame(frame, style="Panel.TFrame")
        buttons.pack(fill="x", padx=10, pady=8)
        ttk.Button(buttons, text="Refresh Status", command=self.refresh_manual_status).pack(side="left", padx=4, pady=8)
        ttk.Button(buttons, text="Run Self-Test", command=self.gui_self_test).pack(side="left", padx=4, pady=8)
        ttk.Button(buttons, text="Scanner Test", command=self.gui_scanner_test).pack(side="left", padx=4, pady=8)
        ttk.Button(buttons, text="About", command=self.show_about).pack(side="right", padx=4, pady=8)

    def refresh_manual_status(self) -> None:
        try:
            data = user_status_payload(self.conn)
            self.manual_status.set(f"{APP_NAME} v{APP_VERSION} — stable lock={data.get('stable_lock')} — database={data.get('database')}")
        except Exception as exc:
            self.manual_status.set(f"Status error: {exc}")

    def gui_self_test(self) -> None:
        data = self.safe_call(lambda: self_test_payload(self.conn))
        if data:
            self.messagebox.showinfo(APP_NAME, f"Self-test {'passed' if data.get('ok') else 'needs attention'}. Checks: {len(data.get('checks', []))}")
            self.refresh_manual_status()

    def gui_scanner_test(self) -> None:
        data = scanner_test_payload(self.conn, "")
        self.messagebox.showinfo(APP_NAME, "USB scanner mode is ready. Open Barcode Options, click the Barcode field, scan with a USB keyboard-wedge scanner, then press Enter if your scanner does not send Enter automatically.")

    def show_about(self) -> None:
        self.messagebox.showinfo(APP_NAME, f"{APP_NAME} v{APP_VERSION}\nProgram {PROGRAM_NUMBER} — SentinelOS Desktop Suite\nV1 Stable Lock / User-Ready Baseline\nLocal-only. No network. No telemetry.")

    def build_recovery_tab(self) -> None:
        ttk = self.ttk
        tk = self.tk
        frame = self.recovery_tab
        top = ttk.Frame(frame, style="Panel.TFrame")
        top.pack(fill="x", pady=(0, 8))
        ttk.Label(top, text="Recovery & Integrity", style="Status.TLabel").pack(side="left", padx=10, pady=8)
        ttk.Button(top, text="Run Integrity Check", command=self.run_integrity_dialog).pack(side="right", padx=4, pady=8)
        ttk.Button(top, text="Verify Backup", command=self.verify_backup_dialog).pack(side="right", padx=4, pady=8)
        ttk.Button(top, text="Restore Preview", command=self.restore_preview_dialog).pack(side="right", padx=4, pady=8)
        ttk.Button(top, text="Checksum Manifest", command=self.checksum_manifest_dialog).pack(side="right", padx=4, pady=8)
        ttk.Button(top, text="Compact / Repair", command=self.compact_repair_dialog).pack(side="right", padx=4, pady=8)
        ttk.Button(top, text="Export Audit", command=self.export_audit_dialog).pack(side="right", padx=4, pady=8)
        info = ttk.Frame(frame, style="Panel.TFrame")
        info.pack(fill="x", pady=(0, 8))
        ttk.Label(info, text="Local integrity checks, verified backups, restore previews, checksum manifests, compact/repair, and audit export. No network access is used.", style="Panel.TLabel").pack(anchor="w", padx=10, pady=(8, 2))
        ttk.Label(info, text=f"Pantry DB: {DB_PATH}", style="Panel.TLabel").pack(anchor="w", padx=10, pady=(0, 2))
        ttk.Label(info, text=f"Recipe DB: {RECIPE_DB_PATH}", style="Panel.TLabel").pack(anchor="w", padx=10, pady=(0, 8))
        self.recovery_text = tk.Text(frame, height=24, wrap="word", bg=THEME["field"], fg=THEME["fg"], insertbackground=THEME["fg"], relief="flat")
        self.recovery_text.pack(fill="both", expand=True, padx=4, pady=4)

    def refresh_recovery_view(self) -> None:
        if not hasattr(self, "recovery_text"):
            return
        payload = recovery_status(self.conn)
        self.recovery_text.delete("1.0", "end")
        self.recovery_text.insert("1.0", json.dumps(payload, indent=2, sort_keys=True))

    def run_integrity_dialog(self) -> None:
        try:
            self.refresh_recovery_view()
            self.messagebox.showinfo(APP_NAME, "Integrity check complete. Review the Recovery & Integrity tab.")
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))

    def verify_backup_dialog(self) -> None:
        try:
            path = self.filedialog.askopenfilename(title="Select pantry backup database", initialdir=str(BACKUP_DIR), filetypes=[("SQLite DB", "*.db"), ("All files", "*")])
            if not path:
                return
            payload = verify_backup(path)
            self.recovery_text.delete("1.0", "end")
            self.recovery_text.insert("1.0", json.dumps(payload, indent=2, sort_keys=True))
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))

    def restore_preview_dialog(self) -> None:
        try:
            path = self.filedialog.askopenfilename(title="Select pantry backup database", initialdir=str(BACKUP_DIR), filetypes=[("SQLite DB", "*.db"), ("All files", "*")])
            if not path:
                return
            payload = restore_preview(path)
            self.recovery_text.delete("1.0", "end")
            self.recovery_text.insert("1.0", json.dumps(payload, indent=2, sort_keys=True))
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))

    def checksum_manifest_dialog(self) -> None:
        try:
            out = write_checksum_manifest(self.conn)
            self.refresh_recovery_view()
            self.messagebox.showinfo(APP_NAME, f"Checksum manifest written:\n{out}")
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))

    def compact_repair_dialog(self) -> None:
        try:
            if not self.messagebox.askyesno(APP_NAME, "Create safety backup, then compact and repair local databases?"):
                return
            payload = compact_repair(self.conn)
            self.recovery_text.delete("1.0", "end")
            self.recovery_text.insert("1.0", json.dumps(payload, indent=2, sort_keys=True))
            self.messagebox.showinfo(APP_NAME, "Compact / repair complete.")
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))

    def export_audit_dialog(self) -> None:
        try:
            path = self.filedialog.asksaveasfilename(title="Export audit JSON", defaultextension=".json", initialfile=f"sentinel-pantry-audit-{today().isoformat()}.json")
            if not path:
                return
            out = export_audit_json(self.conn, path)
            self.messagebox.showinfo(APP_NAME, f"Audit exported:\n{out}")
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))

    def save_readiness_settings(self) -> None:
        try:
            for key, var in self.ready_vars.items():
                set_setting(self.conn, key, var.get())
            self.refresh()
            self.messagebox.showinfo(APP_NAME, "Readiness settings saved.")
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))


    def on_rotation_select(self, _event: Any = None) -> None:
        sel = self.rotation_tree.selection() if hasattr(self, "rotation_tree") else []
        if not sel:
            return
        try:
            item_id = int(self.rotation_tree.item(sel[0], "values")[0])
        except Exception:
            return
        self.select_item_by_id(item_id)

    def selected_row_id(self) -> Optional[int]:
        sel = self.tree.selection() if hasattr(self, "tree") else []
        if sel:
            try:
                return int(self.tree.item(sel[0], "values")[0])
            except Exception:
                return None
        rsel = self.rotation_tree.selection() if hasattr(self, "rotation_tree") else []
        if rsel:
            try:
                return int(self.rotation_tree.item(rsel[0], "values")[0])
            except Exception:
                return None
        return None

    def row_to_values(self, r: sqlite3.Row) -> tuple[Any, ...]:
        return (r["id"], r["name"], f"{float(r['quantity']):g}", r["unit"], f"{float(r['min_quantity']):g}", r["category"], r["location"], r["expiry_date"], status_for_item(r, expiring_soon_days(self.conn)))

    def refresh(self, mode: str = "all") -> None:
        self.current_mode = mode
        self.refresh_dashboard()
        self.refresh_inventory()
        self.refresh_fast_entry()
        self.refresh_shopping()
        self.refresh_rotation()
        self.refresh_readiness()
        self.refresh_recipes()
        self.refresh_aegis_view()
        self.refresh_recovery_view()
        s = summary(self.conn)
        self.status.configure(text=f"Items: {s['items_active']} active • Low: {s['items_low_stock']} • Use-first: {s['rotation_use_first']} • Readiness: {s['readiness_score']}%/{s['readiness_status']} • Food: {s['food_days_supply']}d • Water: {s['water_days_supply']}d • Shopping: {s['shopping_open']} • Recipes: {s['recipes_active']} • Meals: {s['meal_plan_next_7d']} • Ctrl+Q closes • DB: {DB_PATH} • Recipe Store: {RECIPE_DB_PATH}")

    def refresh_dashboard(self) -> None:
        dash = dashboard_summary(self.conn)
        for k, var in self.card_vars.items():
            var.set(str(dash.get(k, 0)))
        groups = {
            "low": low_stock_items(self.conn),
            "expiring": expiring_soon_items(self.conn, expiring_soon_days(self.conn)),
            "expired": expired_items(self.conn),
        }
        for key, rows in groups.items():
            tree = self.dashboard_trees[key]
            tree.delete(*tree.get_children())
            for r in rows[:50]:
                iid = f"{key}-{r['id']}"
                tree.insert("", "end", iid=iid, values=(r["name"], f"{float(r['quantity']):g} {r['unit']}", r["expiry_date"], status_for_item(r, expiring_soon_days(self.conn))))

    def refresh_inventory(self) -> None:
        self.category_filter.configure(values=[""] + active_categories(self.conn))
        self.location_filter.configure(values=[""] + active_locations(self.conn))
        q = self.search_var.get().strip() if hasattr(self, "search_var") else ""
        status_filter = self.filter_vars["status"].get() if "status" in self.filter_vars else "All Active"
        include_archived = bool(self.filter_vars["include_archived"].get()) if "include_archived" in self.filter_vars else False
        if status_filter == "Archived":
            include_archived = True
        rows = list_items(
            self.conn,
            include_archived=include_archived,
            query=q,
            category=self.filter_vars["category"].get() if "category" in self.filter_vars else "",
            location=self.filter_vars["location"].get() if "location" in self.filter_vars else "",
            status_filter=status_filter,
            low_only=bool(self.filter_vars["low_only"].get()) if "low_only" in self.filter_vars else False,
            expiry_days=expiring_soon_days(self.conn),
        )
        self.tree.delete(*self.tree.get_children())
        for r in rows:
            status = status_for_item(r, expiring_soon_days(self.conn))
            tags = ()
            if "Expired" in status:
                tags = ("danger",)
            elif "Low" in status or "Expiring" in status:
                tags = ("warn",)
            elif status == "Good":
                tags = ("good",)
            self.tree.insert("", "end", values=self.row_to_values(r), tags=tags)
        self.tree.tag_configure("danger", foreground=THEME["danger"])
        self.tree.tag_configure("warn", foreground=THEME["gold"])
        self.tree.tag_configure("good", foreground=THEME["ok"])

    def refresh_shopping(self) -> None:
        if not hasattr(self, "shopping_tree"):
            return
        self.shopping_tree.delete(*self.shopping_tree.get_children())
        status_filter = self.shopping_status_filter.get() if hasattr(self, "shopping_status_filter") else ""
        store_filter = self.shopping_store_filter.get() if hasattr(self, "shopping_store_filter") else ""
        rows = list_shopping(self.conn, include_checked=bool(self.shopping_all_var.get()), status=status_filter, store=store_filter)
        for r in rows:
            price = f"${float(r['estimated_price']):.2f}" if float(r["estimated_price"] or 0) else ""
            tags = ()
            if r["status"] == "Urgent":
                tags = ("urgent",)
            elif r["status"] in CLOSED_SHOPPING_STATUSES:
                tags = ("done",)
            self.shopping_tree.insert("", "end", values=(r["id"], r["item_name"], f"{float(r['target_quantity']):g}", r["unit"], r["category"], r["status"], r["preferred_store"], price, r["source"], r["notes"]), tags=tags)

    def refresh_rotation(self) -> None:
        if hasattr(self, "rotation_tree"):
            self.rotation_tree.delete(*self.rotation_tree.get_children())
            expiry_days = expiring_soon_days(self.conn)
            for r in use_first_items(self.conn, 100):
                score, label = rotation_priority(r, expiry_days)
                tags = ("danger",) if score <= 1 else (("warn",) if score <= 3 else ())
                self.rotation_tree.insert("", "end", values=(r["id"], r["name"], f"{float(r['quantity']):g} {r['unit']}", r["expiry_date"], r["opened_date"] if "opened_date" in r.keys() else "", label), tags=tags)
        if hasattr(self, "waste_tree"):
            self.waste_tree.delete(*self.waste_tree.get_children())
            for r in list_waste(self.conn, 100):
                self.waste_tree.insert("", "end", values=(r["id"], r["created_at"], r["item_name"], f"{float(r['quantity']):g} {r['unit']}", r["reason"], r["notes"]))

    def refresh_readiness(self) -> None:
        if not hasattr(self, "readiness_text"):
            return
        data = readiness_summary(self.conn)
        self.readiness_text.delete("1.0", "end")
        lines = [
            f"Status: {data['readiness_status']} ({data['readiness_score']}%)",
            f"Household: {data['household_members']} member(s) • Target: {data['reserve_days_target']} day(s)",
            f"Food: {data['food_days_supply']} day(s) from {data['total_calories']:g} tracked kcal",
            f"Water: {data['water_days_supply']} day(s) from {data['total_water_litres']:g} tracked litres",
            f"Reserve items: {data['reserve_items']} total • {data['reserve_locked_items']} locked • {data['reserve_low_stock_items']} low stock",
            "",
            "Suggested minimums are guidance only. AEGIS/Sentinel remains advisory; household decisions stay with the user.",
        ]
        self.readiness_text.insert("1.0", "\n".join(lines))
        if hasattr(self, "reserve_tree"):
            self.reserve_tree.delete(*self.reserve_tree.get_children())
            for r in reserve_items(self.conn):
                lock = "Locked" if bool(r["do_not_consume"] if "do_not_consume" in r.keys() else 0) else "Reserve"
                self.reserve_tree.insert("", "end", values=(r["id"], r["name"], f"{float(r['quantity']):g} {r['unit']}", r["category"], r["readiness_category"] if "readiness_category" in r.keys() else "", f"{float(r['calories_per_unit'] if 'calories_per_unit' in r.keys() else 0):g}", f"{float(r['water_litres_per_unit'] if 'water_litres_per_unit' in r.keys() else 0):g}", lock, status_for_item(r, expiring_soon_days(self.conn))))

    def export_readiness_dialog(self) -> None:
        path = self.filedialog.asksaveasfilename(title="Export readiness JSON", defaultextension=".json", filetypes=[("JSON", "*.json")], initialfile=f"sentinel-pantry-readiness-{today().isoformat()}.json")
        if not path:
            return
        try:
            out = export_readiness_json(self.conn, path)
            self.messagebox.showinfo(APP_NAME, f"Readiness JSON exported to:\n{out}")
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))


    def fast_clear(self) -> None:
        if not hasattr(self, "fast_vars"):
            return
        for key, var in self.fast_vars.items():
            if key == "quantity":
                var.set("1")
            elif key == "unit":
                var.set("each")
            elif key in {"min_quantity", "estimated_price"}:
                var.set("0")
            else:
                var.set("")
        if hasattr(self, "fast_notes"):
            self.fast_notes.delete("1.0", "end")
        if hasattr(self, "fast_profile_text"):
            self.fast_profile_text.delete("1.0", "end")
            self.fast_profile_text.insert("1.0", "Scan/type a barcode and press Enter to use a known local profile, or enter name/category/unit once and Learn it.")

    def selected_barcode_profile_code(self) -> Optional[str]:
        if not hasattr(self, "barcode_catalog_tree"):
            return None
        sel = self.barcode_catalog_tree.selection()
        if not sel:
            return None
        try:
            return str(self.barcode_catalog_tree.item(sel[0], "values")[0])
        except Exception:
            return None

    def load_selected_barcode_profile(self, event: Any = None) -> None:
        code = self.selected_barcode_profile_code()
        if not code:
            self.messagebox.showinfo(APP_NAME, "Select a barcode profile first.")
            return
        self.fast_vars["barcode"].set(code)
        self.fast_lookup_barcode()

    def delete_selected_barcode_gui(self) -> None:
        code = self.selected_barcode_profile_code()
        if not code:
            self.messagebox.showinfo(APP_NAME, "Select a barcode profile first.")
            return
        if not self.messagebox.askyesno(APP_NAME, f"Delete local barcode profile {code}?"):
            return
        try:
            delete_barcode_profile(self.conn, code)
            self.refresh_fast_entry()
            self.messagebox.showinfo(APP_NAME, f"Deleted local barcode profile {code}.")
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))

    def export_barcode_catalog_dialog(self) -> None:
        path = self.filedialog.asksaveasfilename(
            title="Export barcode catalog CSV",
            defaultextension=".csv",
            filetypes=[("CSV", "*.csv")],
            initialfile=f"sentinel-pantry-barcodes-{today().isoformat()}.csv",
        )
        if not path:
            return
        try:
            out = export_barcode_catalog_csv(self.conn, path)
            self.messagebox.showinfo(APP_NAME, f"Barcode catalog exported to:\n{out}")
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))

    def import_barcode_catalog_dialog(self) -> None:
        path = self.filedialog.askopenfilename(
            title="Import barcode catalog CSV",
            filetypes=[("CSV", "*.csv"), ("All files", "*")],
        )
        if not path:
            return
        try:
            count = import_barcode_catalog_csv(self.conn, path)
            self.refresh_fast_entry()
            self.messagebox.showinfo(APP_NAME, f"Imported/updated {count} barcode profile(s).")
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))

    def fast_lookup_barcode(self) -> None:
        code = normalise_barcode(self.fast_vars["barcode"].get())
        if not code:
            self.messagebox.showinfo(APP_NAME, "Enter or scan a barcode first.")
            return
        profile = lookup_barcode(self.conn, code)
        self.fast_profile_text.delete("1.0", "end")
        if not profile:
            self.fast_profile_text.insert("1.0", f"No local profile for barcode {code}. Enter the item details once, then click Learn / Update Profile.")
            return
        mapping = {
            "name": profile["item_name"], "category": profile["category"], "unit": profile["unit"],
            "location": profile["location"], "min_quantity": f"{float(profile['min_quantity'] or 0):g}",
            "preferred_store": profile["preferred_store"], "estimated_price": f"{float(profile['estimated_price'] or 0):g}",
        }
        for key, value in mapping.items():
            if key in self.fast_vars:
                self.fast_vars[key].set(value or ("each" if key == "unit" else ""))
        if profile["notes"]:
            self.fast_notes.delete("1.0", "end")
            self.fast_notes.insert("1.0", profile["notes"])
        lines = [
            f"Barcode: {profile['barcode']}",
            f"Name: {profile['item_name']}",
            f"Category: {profile['category'] or 'Uncategorised'}",
            f"Unit: {profile['unit'] or 'each'}",
            f"Location: {profile['location'] or 'Pantry'}",
            f"Minimum: {float(profile['min_quantity'] or 0):g}",
            f"Preferred store: {profile['preferred_store'] or '-'}",
            f"Estimated price: {float(profile['estimated_price'] or 0):g}",
            f"Updated: {profile['updated_at']}",
        ]
        self.fast_profile_text.insert("1.0", "\n".join(lines))

    def fast_add_gui(self) -> None:
        try:
            item_id = fast_add_item(
                self.conn,
                barcode=self.fast_vars["barcode"].get(),
                name=self.fast_vars["name"].get(),
                quantity=float(self.fast_vars["quantity"].get() or 1),
                unit=self.fast_vars["unit"].get(),
                category=self.fast_vars["category"].get(),
                location=self.fast_vars["location"].get(),
                expiry_date=self.fast_vars["expiry_date"].get(),
                purchase_date=self.fast_vars["purchase_date"].get(),
                min_quantity=float(self.fast_vars["min_quantity"].get() or 0),
                notes=self.fast_notes.get("1.0", "end").strip(),
                learn=True,
            )
            self.refresh()
            self.messagebox.showinfo(APP_NAME, f"Fast-added pantry item #{item_id}.")
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))

    def fast_learn_gui(self) -> None:
        try:
            code = learn_barcode(
                self.conn,
                self.fast_vars["barcode"].get(),
                self.fast_vars["name"].get(),
                self.fast_vars["category"].get(),
                self.fast_vars["unit"].get(),
                self.fast_vars["location"].get(),
                float(self.fast_vars["min_quantity"].get() or 0),
                self.fast_vars["preferred_store"].get(),
                float(self.fast_vars["estimated_price"].get() or 0),
                notes=self.fast_notes.get("1.0", "end").strip(),
            )
            self.fast_lookup_barcode()
            self.refresh_fast_entry()
            self.messagebox.showinfo(APP_NAME, f"Saved local barcode profile {code}.")
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))

    def refresh_fast_entry(self) -> None:
        if hasattr(self, "fast_vars"):
            try:
                # Keep combobox suggestions current as inventory grows.
                pass
            except Exception:
                pass
        if hasattr(self, "barcode_catalog_tree"):
            self.barcode_catalog_tree.delete(*self.barcode_catalog_tree.get_children())
            for r in list_barcode_profiles(self.conn):
                price = f"${float(r['estimated_price'] or 0):.2f}" if float(r["estimated_price"] or 0) else ""
                self.barcode_catalog_tree.insert(
                    "",
                    "end",
                    values=(
                        r["barcode"],
                        r["item_name"],
                        r["category"],
                        r["unit"],
                        r["location"],
                        f"{float(r['min_quantity'] or 0):g}",
                        r["preferred_store"],
                        price,
                    ),
                )
        if hasattr(self, "duplicates_tree"):
            self.duplicates_tree.delete(*self.duplicates_tree.get_children())
            for g in duplicate_groups(self.conn):
                self.duplicates_tree.insert("", "end", values=(g["kind"], g["key"], g["count"], ",".join(str(x) for x in g["ids"]), f"{g['total_quantity']:g}"))
        if hasattr(self, "fast_profile_text") and not self.fast_profile_text.get("1.0", "end").strip():
            self.fast_profile_text.insert("1.0", f"Local profiles: {barcode_profile_count(self.conn)}\nDuplicate groups: {len(duplicate_groups(self.conn))}")

    def clear_shopping_filters(self) -> None:
        if hasattr(self, "shopping_status_filter"):
            self.shopping_status_filter.set("")
        if hasattr(self, "shopping_store_filter"):
            self.shopping_store_filter.set("")
        self.refresh_shopping()

    def clear_filters(self) -> None:
        self.search_var.set("")
        self.filter_vars["category"].set("")
        self.filter_vars["location"].set("")
        self.filter_vars["status"].set("All Active")
        self.filter_vars["low_only"].set(False)
        self.filter_vars["include_archived"].set(False)
        self.refresh()

    def quick_add_item(self) -> None:
        self.nb.select(self.inventory_tab)
        self.clear_form()
        try:
            self.vars["category"].set("Pantry")
            self.vars["location"].set("Pantry")
        except Exception:
            pass

    def open_inventory_from_dashboard(self, event: Any = None) -> None:
        self.nb.select(self.inventory_tab)
        widget = event.widget if event else None
        if not widget:
            return
        sel = widget.selection()
        if not sel:
            return
        iid = str(sel[0])
        try:
            item_id = int(iid.split("-")[-1])
        except Exception:
            return
        self.select_item_by_id(item_id)

    def select_item_by_id(self, item_id: int) -> None:
        self.clear_filters()
        for child in self.tree.get_children():
            vals = self.tree.item(child, "values")
            if vals and int(vals[0]) == item_id:
                self.tree.selection_set(child)
                self.tree.see(child)
                self.on_select()
                break

    def clear_form(self) -> None:
        self.selected_id = None
        for var in self.vars.values():
            var.set("")
        if "unit" in self.vars:
            self.vars["unit"].set("each")
        if "quantity" in self.vars:
            self.vars["quantity"].set("0")
        if "min_quantity" in self.vars:
            self.vars["min_quantity"].set("0")
        for key in ("emergency_reserve", "do_not_consume", "calories_per_unit", "water_litres_per_unit"):
            if key in self.vars:
                self.vars[key].set("0")
        if hasattr(self, "notes"):
            self.notes.delete("1.0", "end")
        if hasattr(self, "tree"):
            self.tree.selection_remove(self.tree.selection())

    def on_select(self, _event: Any = None) -> None:
        item_id = self.selected_row_id()
        if item_id is None:
            return
        row = self.conn.execute("SELECT * FROM items WHERE id=?", (item_id,)).fetchone()
        if not row:
            return
        self.selected_id = item_id
        for key in self.vars:
            if key in row.keys():
                val = row[key]
                if isinstance(val, float):
                    val = f"{val:g}"
                self.vars[key].set("" if val is None else str(val))
        self.notes.delete("1.0", "end")
        self.notes.insert("1.0", row["notes"] or "")

    def form_data(self) -> dict[str, Any]:
        data = {k: v.get() for k, v in self.vars.items()}
        data["notes"] = self.notes.get("1.0", "end").strip()
        return data

    def save(self) -> None:
        try:
            if self.selected_id is None:
                item_id = add_item(self.conn, self.form_data())
                self.selected_id = item_id
            else:
                update_item(self.conn, self.selected_id, self.form_data())
            self.refresh()
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))

    def amount_dialog(self, title: str, label: str, apply_func: Any) -> None:
        item_id = self.selected_row_id()
        if item_id is None:
            self.messagebox.showinfo(APP_NAME, "Select an item first from the Inventory tab.")
            self.nb.select(self.inventory_tab)
            return
        row = self.conn.execute("SELECT * FROM items WHERE id=?", (item_id,)).fetchone()
        dialog = self.tk.Toplevel(self.root)
        dialog.title(title)
        dialog.configure(bg=THEME["bg"])
        self.ttk.Label(dialog, text=f"{row['name']} — current {float(row['quantity']):g} {row['unit']}").grid(row=0, column=0, columnspan=2, padx=10, pady=(10, 4), sticky="w")
        self.ttk.Label(dialog, text=label).grid(row=1, column=0, padx=10, pady=8)
        var = self.tk.StringVar(value="1")
        self.ttk.Entry(dialog, textvariable=var).grid(row=1, column=1, padx=10, pady=8)
        self.ttk.Label(dialog, text="Notes").grid(row=2, column=0, padx=10, pady=8)
        nvar = self.tk.StringVar(value="")
        self.ttk.Entry(dialog, textvariable=nvar).grid(row=2, column=1, padx=10, pady=8)

        def ok() -> None:
            try:
                apply_func(item_id, float(var.get()), nvar.get())
                dialog.destroy()
                self.refresh()
            except Exception as exc:
                self.messagebox.showerror(APP_NAME, str(exc))

        self.ttk.Button(dialog, text="Apply", command=ok).grid(row=3, column=0, columnspan=2, pady=10)

    def consume_dialog(self) -> None:
        self.amount_dialog("Consume stock", "Amount used:", lambda item_id, amount, notes: consume_item(self.conn, item_id, amount, notes=notes))

    def restock_dialog(self) -> None:
        self.amount_dialog("Restock item", "Amount added:", lambda item_id, amount, notes: restock_item(self.conn, item_id, amount, notes=notes))

    def archive_selected(self) -> None:
        item_id = self.selected_row_id()
        if item_id is None:
            return
        archive_item(self.conn, item_id, True)
        self.clear_form()
        self.refresh()

    def delete_selected(self) -> None:
        item_id = self.selected_row_id()
        if item_id is None:
            return
        if self.messagebox.askyesno(APP_NAME, "Delete this item permanently? Archive is safer."):
            delete_item(self.conn, item_id)
            self.clear_form()
            self.refresh()

    def generate_shopping(self) -> None:
        count = generate_shopping_list(self.conn)
        self.refresh()
        self.messagebox.showinfo(APP_NAME, f"Added {count} low-stock item(s) to the shopping list.")

    def add_manual_shopping_dialog(self) -> None:
        dialog = self.tk.Toplevel(self.root)
        dialog.title("Add shopping item")
        dialog.configure(bg=THEME["bg"])
        name = self.tk.StringVar()
        qty = self.tk.StringVar(value="1")
        unit = self.tk.StringVar(value="each")
        category = self.tk.StringVar(value="Pantry")
        status = self.tk.StringVar(value="Needed")
        store = self.tk.StringVar(value="")
        price = self.tk.StringVar(value="0")
        notes = self.tk.StringVar(value="")
        fields = [
            ("Item", name, "entry"), ("Quantity", qty, "entry"), ("Unit", unit, "unit"),
            ("Category", category, "category"), ("Status", status, "status"),
            ("Preferred Store", store, "store"), ("Estimated Price", price, "entry"), ("Notes", notes, "entry"),
        ]
        for i, (label, var, kind) in enumerate(fields):
            self.ttk.Label(dialog, text=label).grid(row=i, column=0, padx=10, pady=6, sticky="w")
            if kind == "unit":
                self.ttk.Combobox(dialog, textvariable=var, values=UNIT_PRESETS).grid(row=i, column=1, padx=10, pady=6)
            elif kind == "category":
                self.ttk.Combobox(dialog, textvariable=var, values=active_categories(self.conn)).grid(row=i, column=1, padx=10, pady=6)
            elif kind == "status":
                self.ttk.Combobox(dialog, textvariable=var, values=SHOPPING_STATUSES, state="readonly").grid(row=i, column=1, padx=10, pady=6)
            elif kind == "store":
                self.ttk.Combobox(dialog, textvariable=var, values=STORE_PRESETS).grid(row=i, column=1, padx=10, pady=6)
            else:
                self.ttk.Entry(dialog, textvariable=var).grid(row=i, column=1, padx=10, pady=6)

        def ok() -> None:
            try:
                add_shopping_item(self.conn, name.get(), float(qty.get()), unit.get(), category.get(), "manual", status.get(), store.get(), float(price.get() or 0), notes.get())
                dialog.destroy()
                self.refresh()
            except Exception as exc:
                self.messagebox.showerror(APP_NAME, str(exc))

        self.ttk.Button(dialog, text="Add", command=ok).grid(row=len(fields), column=0, columnspan=2, pady=10)

    def selected_shopping_id(self) -> Optional[int]:
        sel = self.shopping_tree.selection()
        if not sel:
            return None
        try:
            return int(self.shopping_tree.item(sel[0], "values")[0])
        except Exception:
            return None

    def mark_selected_shopping_status(self, status: str) -> None:
        sid = self.selected_shopping_id()
        if sid is None:
            self.messagebox.showinfo(APP_NAME, "Select a shopping item first.")
            return
        try:
            set_shopping_status(self.conn, sid, status)
            self.refresh()
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))

    def mark_selected_shopping_done(self) -> None:
        self.mark_selected_shopping_status("Bought")

    def restock_selected_shopping(self) -> None:
        sid = self.selected_shopping_id()
        if sid is None:
            self.messagebox.showinfo(APP_NAME, "Select a shopping item first.")
            return
        try:
            item_id = restock_from_shopping(self.conn, sid, create_missing=True, default_location="Pantry")
            self.refresh()
            self.messagebox.showinfo(APP_NAME, f"Shopping item marked bought and restocked into pantry item #{item_id}.")
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))

    def mark_opened_dialog(self) -> None:
        item_id = self.selected_row_id()
        if item_id is None:
            self.messagebox.showinfo(APP_NAME, "Select an item first from Inventory or Rotation.")
            return
        try:
            mark_item_opened(self.conn, item_id)
            self.refresh()
            self.messagebox.showinfo(APP_NAME, f"Marked item #{item_id} opened today.")
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))

    def log_waste_dialog(self) -> None:
        item_id = self.selected_row_id()
        if item_id is None:
            self.messagebox.showinfo(APP_NAME, "Select an item first from the Inventory or Rotation tab.")
            return
        row = self.conn.execute("SELECT * FROM items WHERE id=?", (item_id,)).fetchone()
        dialog = self.tk.Toplevel(self.root)
        dialog.title("Log waste")
        dialog.configure(bg=THEME["bg"])
        self.ttk.Label(dialog, text=f"{row['name']} — current {float(row['quantity']):g} {row['unit']}").grid(row=0, column=0, columnspan=2, padx=10, pady=(10, 4), sticky="w")
        amount = self.tk.StringVar(value="1")
        reason = self.tk.StringVar(value="Expired")
        notes = self.tk.StringVar(value="")
        for i, (label, var) in enumerate([("Quantity wasted", amount), ("Reason", reason), ("Notes", notes)], start=1):
            self.ttk.Label(dialog, text=label).grid(row=i, column=0, padx=10, pady=6, sticky="w")
            self.ttk.Entry(dialog, textvariable=var).grid(row=i, column=1, padx=10, pady=6)

        def ok() -> None:
            try:
                wid = waste_item(self.conn, item_id, float(amount.get()), reason.get(), notes.get())
                dialog.destroy()
                self.refresh()
                self.messagebox.showinfo(APP_NAME, f"Logged waste event #{wid}.")
            except Exception as exc:
                self.messagebox.showerror(APP_NAME, str(exc))
        self.ttk.Button(dialog, text="Log Waste", command=ok).grid(row=4, column=0, columnspan=2, pady=10)

    def export_waste_csv_dialog(self) -> None:
        path = self.filedialog.asksaveasfilename(title="Export waste CSV", defaultextension=".csv", filetypes=[("CSV", "*.csv")], initialfile=f"sentinel-pantry-waste-{today().isoformat()}.csv")
        if not path:
            return
        try:
            out = export_waste_csv(self.conn, path)
            self.messagebox.showinfo(APP_NAME, f"Waste CSV exported to:\n{out}")
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))

    def export_csv_dialog(self) -> None:
        path = self.filedialog.asksaveasfilename(title="Export pantry CSV", defaultextension=".csv", filetypes=[("CSV", "*.csv")], initialfile=f"sentinel-pantry-items-{today().isoformat()}.csv")
        if not path:
            return
        try:
            out = export_csv(self.conn, path)
            self.messagebox.showinfo(APP_NAME, f"Exported to:\n{out}")
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))

    def export_shopping_dialog(self) -> None:
        path = self.filedialog.asksaveasfilename(title="Export shopping list", defaultextension=".txt", filetypes=[("Text", "*.txt")], initialfile=f"sentinel-pantry-shopping-{today().isoformat()}.txt")
        if not path:
            return
        try:
            out = export_shopping_txt(self.conn, path)
            self.messagebox.showinfo(APP_NAME, f"Shopping list exported to:\n{out}")
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))

    def export_shopping_csv_dialog(self) -> None:
        path = self.filedialog.asksaveasfilename(title="Export shopping CSV", defaultextension=".csv", filetypes=[("CSV", "*.csv")], initialfile=f"sentinel-pantry-shopping-{today().isoformat()}.csv")
        if not path:
            return
        try:
            out = export_shopping_csv(self.conn, path, include_completed=bool(self.shopping_all_var.get()))
            self.messagebox.showinfo(APP_NAME, f"Shopping CSV exported to:\n{out}")
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))

    def backup_dialog(self) -> None:
        try:
            out = backup_db(self.conn)
            self.messagebox.showinfo(APP_NAME, f"Backup created:\n{out}")
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))

    def health_dialog(self) -> None:
        h = health_check(self.conn)
        self.messagebox.showinfo(APP_NAME, json.dumps(h, indent=2))

    def run(self) -> None:
        self.root.mainloop()


def run_gui() -> None:
    PantryGUI().run()


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=f"{APP_NAME} v{APP_VERSION} — local pantry inventory manager — v1 stable lock")
    p.add_argument("--version", action="store_true", help="print version")
    p.add_argument("--health-check", action="store_true", help="print AEGIS/Sentinel health JSON")
    p.add_argument("--aegis-manifest", action="store_true", help="print AEGIS manifest JSON")
    p.add_argument("--summary", action="store_true", help="print pantry summary JSON")
    p.add_argument("--status", dest="app_status", action="store_true", help="print v1 status JSON")
    p.add_argument("--self-test", action="store_true", help="run safe package/application self-test JSON")
    p.add_argument("--gui", action="store_true", help="open GUI")
    sub = p.add_subparsers(dest="cmd")

    add = sub.add_parser("add", help="add a pantry item")
    add.add_argument("name")
    add.add_argument("--quantity", default="1")
    add.add_argument("--unit", default="each")
    add.add_argument("--min", dest="min_quantity", default="0")
    add.add_argument("--category", default="")
    add.add_argument("--location", default="")
    add.add_argument("--expiry", dest="expiry_date", default="")
    add.add_argument("--purchase", dest="purchase_date", default="")
    add.add_argument("--opened", dest="opened_date", default="")
    add.add_argument("--barcode", default="")
    add.add_argument("--batch", dest="batch_code", default="")
    add.add_argument("--shelf-life-notes", dest="shelf_life_notes", default="")
    add.add_argument("--reserve", dest="emergency_reserve", action="store_true", help="mark as emergency reserve/readiness stock")
    add.add_argument("--lock", dest="do_not_consume", action="store_true", help="mark as do-not-consume reserve")
    add.add_argument("--readiness-category", default="", choices=READINESS_CATEGORY_PRESETS)
    add.add_argument("--calories-per-unit", default="0")
    add.add_argument("--water-litres-per-unit", default="0")
    add.add_argument("--notes", default="")

    ls = sub.add_parser("list", help="list pantry items")
    ls.add_argument("--archived", action="store_true")
    ls.add_argument("--query", default="")
    ls.add_argument("--category", default="")
    ls.add_argument("--location", default="")
    ls.add_argument("--status", default="All Active", choices=STATUS_FILTERS)
    ls.add_argument("--low-only", action="store_true")
    sub.add_parser("low", help="list low-stock items")
    exp = sub.add_parser("expiring", help="list expired/expiring items")
    exp.add_argument("--days", default=str(DEFAULT_EXPIRY_SOON_DAYS))
    sub.add_parser("expired", help="list expired items")
    sub.add_parser("dashboard", help="print dashboard summary JSON")
    ready = sub.add_parser("readiness", help="show or configure emergency/off-grid readiness")
    ready.add_argument("--json", action="store_true", help="print readiness as JSON")
    ready.add_argument("--export-json", default="", help="export readiness JSON to a file")
    ready.add_argument("--set-household-members", type=int, default=0)
    ready.add_argument("--set-target-days", type=int, default=0)
    ready.add_argument("--set-calories-per-person-day", type=float, default=0)
    ready.add_argument("--set-water-litres-per-person-day", type=float, default=0)
    ready.add_argument("--reserve", type=int, default=0, help="mark pantry item id as emergency reserve")
    ready.add_argument("--unreserve", type=int, default=0, help="remove emergency reserve flag from item id")
    ready.add_argument("--lock", type=int, default=0, help="mark item id do-not-consume")
    ready.add_argument("--unlock", type=int, default=0, help="remove do-not-consume lock")
    ready.add_argument("--readiness-category", default="", choices=READINESS_CATEGORY_PRESETS)
    ready.add_argument("--list", action="store_true", help="list reserve/readiness items")
    uf = sub.add_parser("use-first", help="list use-first rotation recommendations")
    uf.add_argument("--limit", type=int, default=50)
    opn = sub.add_parser("opened", help="mark an item as opened")
    opn.add_argument("id", type=int)
    opn.add_argument("--date", default="", help="opened date YYYY-MM-DD; defaults to today")
    waste = sub.add_parser("waste", help="waste log commands")
    waste.add_argument("--add", type=int, default=0, help="pantry item id to log as wasted")
    waste.add_argument("--qty", type=float, default=1)
    waste.add_argument("--reason", default="Expired")
    waste.add_argument("--notes", default="")
    waste.add_argument("--list", action="store_true", help="list waste events")
    waste.add_argument("--limit", type=int, default=100)
    waste.add_argument("--export-csv", default="")

    con = sub.add_parser("consume", help="consume/decrease item quantity")
    con.add_argument("id", type=int)
    con.add_argument("amount", type=float)
    con.add_argument("--notes", default="")
    res = sub.add_parser("restock", help="restock/increase item quantity")
    res.add_argument("id", type=int)
    res.add_argument("amount", type=float)
    res.add_argument("--notes", default="")

    arc = sub.add_parser("archive", help="archive an item")
    arc.add_argument("id", type=int)
    restore_item_parser = sub.add_parser("restore-item", help="restore an archived item")
    restore_item_parser.add_argument("id", type=int)
    dele = sub.add_parser("delete", help="delete an item permanently")
    dele.add_argument("id", type=int)

    shop = sub.add_parser("shopping", help="shopping list commands")
    shop.add_argument("--generate", action="store_true", help="add low-stock pantry items to the shopping list")
    shop.add_argument("--all", action="store_true", help="include bought/skipped shopping items in output/export")
    shop.add_argument("--status", default="", choices=[""] + SHOPPING_STATUSES, help="filter list or set status with --set-status")
    shop.add_argument("--store", default="", help="filter by preferred store or set store when adding")
    shop.add_argument("--set-status", type=int, default=0, help="shopping item id to change status for; use with --status")
    shop.add_argument("--check", type=int, default=0, help="mark shopping item bought")
    shop.add_argument("--urgent", type=int, default=0, help="mark shopping item urgent")
    shop.add_argument("--skip", type=int, default=0, help="mark shopping item skipped")
    shop.add_argument("--needed", type=int, default=0, help="mark shopping item needed/open")
    shop.add_argument("--restock", type=int, default=0, help="mark shopping item bought and restock/create matching pantry item")
    shop.add_argument("--add", default="", help="add a manual shopping item")
    shop.add_argument("--qty", default="1")
    shop.add_argument("--unit", default="each")
    shop.add_argument("--category", default="")
    shop.add_argument("--price", default="0", help="estimated price for manual item")
    shop.add_argument("--notes", default="")
    shop.add_argument("--export-txt", default="")
    shop.add_argument("--export-csv", default="")
    shop.add_argument("--print", dest="print_txt", action="store_true", help="print shopping list as grouped plain text")

    sh = sub.add_parser("shopping-history", help="show shopping workflow history")
    sh.add_argument("--limit", type=int, default=50)

    rec = sub.add_parser("recipes", help="manage recipes and ingredient matching")
    rec.add_argument("--add", default="", help="add a recipe by name")
    rec.add_argument("--category", default="")
    rec.add_argument("--servings", type=float, default=1)
    rec.add_argument("--instructions", default="")
    rec.add_argument("--notes", default="")
    rec.add_argument("--ingredient", type=int, default=0, help="recipe id to add an ingredient to")
    rec.add_argument("--item", default="", help="ingredient item name")
    rec.add_argument("--qty", type=float, default=1)
    rec.add_argument("--unit", default="each")
    rec.add_argument("--pantry-id", type=int, default=0)
    rec.add_argument("--optional", action="store_true")
    rec.add_argument("--list", action="store_true")
    rec.add_argument("--detail", type=int, default=0)
    rec.add_argument("--can-make", action="store_true")
    rec.add_argument("--suggest-use-first", action="store_true")
    rec.add_argument("--shopping", type=int, default=0, help="generate shopping items for recipe id")
    rec.add_argument("--export-json", default="")
    rec.add_argument("--export-csv", default="")

    mp = sub.add_parser("meal-plan", help="manage meal planning")
    mp.add_argument("--add", type=int, default=0, help="recipe id to plan")
    mp.add_argument("--date", default="")
    mp.add_argument("--meal-type", default="Dinner", choices=MEAL_TYPES)
    mp.add_argument("--servings", type=float, default=1)
    mp.add_argument("--notes", default="")
    mp.add_argument("--list", action="store_true")
    mp.add_argument("--from-date", default="")
    mp.add_argument("--to-date", default="")
    mp.add_argument("--shopping", action="store_true", help="generate shopping list from planned meals in range")
    mp.add_argument("--urgent", action="store_true")

    ba = sub.add_parser("barcode", help="local barcode catalog commands")
    ba.add_argument("--lookup", default="", help="lookup a local barcode profile")
    ba.add_argument("--learn", default="", help="create/update local profile for this barcode")
    ba.add_argument("--from-item", type=int, default=0, help="learn local profile from an existing pantry item with a barcode")
    ba.add_argument("--name", default="", help="profile item name")
    ba.add_argument("--category", default="")
    ba.add_argument("--unit", default="each")
    ba.add_argument("--location", default="Pantry")
    ba.add_argument("--min", dest="min_quantity", default="0")
    ba.add_argument("--store", dest="preferred_store", default="")
    ba.add_argument("--price", dest="estimated_price", default="0")
    ba.add_argument("--calories-per-unit", default="0")
    ba.add_argument("--water-litres-per-unit", default="0")
    ba.add_argument("--notes", default="")
    ba.add_argument("--list", action="store_true")
    ba.add_argument("--query", default="")
    ba.add_argument("--delete", default="")
    ba.add_argument("--import-csv", default="")
    ba.add_argument("--export-csv", default="")

    fa = sub.add_parser("fast-add", help="fast add item by known barcode or one-time item details")
    fa.add_argument("--barcode", default="")
    fa.add_argument("--name", default="")
    fa.add_argument("--quantity", default="1")
    fa.add_argument("--unit", default="")
    fa.add_argument("--category", default="")
    fa.add_argument("--location", default="")
    fa.add_argument("--min", dest="min_quantity", default="")
    fa.add_argument("--expiry", dest="expiry_date", default="")
    fa.add_argument("--purchase", dest="purchase_date", default="")
    fa.add_argument("--notes", default="")
    fa.add_argument("--no-learn", action="store_true", help="do not learn a supplied barcode/name as a local profile")

    dup = sub.add_parser("duplicates", help="find or merge duplicate pantry items")
    dup.add_argument("--list", action="store_true", help="list duplicate groups")
    dup.add_argument("--merge-target", type=int, default=0, help="target item id to keep")
    dup.add_argument("--sources", nargs="*", type=int, default=[], help="source item ids to merge into target")
    dup.add_argument("--delete-sources", action="store_true", help="delete source rows instead of archiving them after merge")

    aeg = sub.add_parser("aegis", help="AEGIS JSON action contract, Sentinel Command card, Vault handoff, and B.A.S.T.I.O.N registration")
    aeg.add_argument("action", nargs="?", default="contract", choices=AEGIS_ACTION_NAMES)
    aeg.add_argument("--path", default="", help="optional output directory/file for backup, vault_export, or bastion_registration")
    aeg.add_argument("--days", type=int, default=0, help="expiry window for expiring_soon/vault_export; default uses app setting")
    aeg.add_argument("--include-completed", action="store_true", help="include bought/skipped shopping rows in shopping_list/vault_export")
    aeg.add_argument("--limit", type=int, default=500, help="waste/history limit for waste_report/vault_export")

    st = sub.add_parser("stable-lock-report", help="print Sentinel Pantry v1 stable-lock report JSON")

    setup = sub.add_parser("setup", help="configure first-run household defaults")
    setup.add_argument("--household-members", type=int, default=0)
    setup.add_argument("--reserve-days", type=int, default=0)
    setup.add_argument("--currency", default="")
    setup.add_argument("--default-store", default="")
    setup.add_argument("--expiring-days", type=int, default=0)
    setup.add_argument("--show", action="store_true", help="show current setup settings")

    sc = sub.add_parser("scanner-test", help="test USB keyboard-wedge barcode scanner workflow")
    sc.add_argument("--code", default="", help="optional scanned/typed barcode to normalise and look up")

    ex = sub.add_parser("export-csv", help="export pantry items to CSV")
    ex.add_argument("path")
    im = sub.add_parser("import-csv", help="import pantry items from CSV")
    im.add_argument("path")
    im.add_argument("--validate", action="store_true", help="validate and report without importing")
    im.add_argument("--report", default="", help="write import validation report JSON")
    im.add_argument("--skip-duplicates", action="store_true", help="skip rows matching existing active name/unit/barcode or barcode")

    recov = sub.add_parser("recovery", help="data integrity, verified backups, restore preview, checksum manifests, and compact/repair")
    recov.add_argument("--integrity", action="store_true", help="print recovery/integrity JSON")
    recov.add_argument("--verify-backup", default="", help="verify a backup database")
    recov.add_argument("--restore-preview", default="", help="preview a restore without changing data")
    recov.add_argument("--restore", default="", help="safe restore a verified backup with rollback")
    recov.add_argument("--checksum-manifest", default="", help="write checksum manifest JSON; optional path or directory")
    recov.add_argument("--compact", action="store_true", help="compact/repair pantry and recipe databases after safety backup")
    recov.add_argument("--audit-json", default="", help="export audit log JSON")
    recov.add_argument("--limit", type=int, default=100)

    auditp = sub.add_parser("audit-log", help="show or export local audit events")
    auditp.add_argument("--limit", type=int, default=100)
    auditp.add_argument("--export-json", default="")

    b = sub.add_parser("backup", help="backup the pantry database")
    b.add_argument("path", nargs="?", default="")
    r = sub.add_parser("restore", help="restore a pantry database backup")
    r.add_argument("path")
    return p


def main(argv: Optional[list[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    if args.version:
        print(f"{APP_NAME} {APP_VERSION}")
        return 0
    if args.aegis_manifest:
        print(json.dumps(manifest(), indent=2, sort_keys=True))
        return 0
    conn = connect()
    try:
        expiry_days = expiring_soon_days(conn)
        if args.health_check:
            print(json.dumps(health_check(conn), indent=2, sort_keys=True))
            return 0
        if args.summary:
            print(json.dumps(summary(conn), indent=2, sort_keys=True))
            return 0
        if getattr(args, "app_status", False):
            print(json.dumps(user_status_payload(conn), indent=2, sort_keys=True))
            return 0
        if args.self_test:
            print(json.dumps(self_test_payload(conn), indent=2, sort_keys=True))
            return 0
        if args.gui or args.cmd is None:
            conn.close()
            run_gui()
            return 0
        if args.cmd == "add":
            item_id = add_item(conn, vars(args))
            print(f"Added item #{item_id}: {args.name}")
        elif args.cmd == "list":
            print_table(list_items(conn, include_archived=args.archived, query=args.query, category=args.category, location=args.location, status_filter=args.status, low_only=args.low_only, expiry_days=expiry_days), expiry_days)
        elif args.cmd == "low":
            print_table(low_stock_items(conn), expiry_days)
        elif args.cmd == "expiring":
            print_table(expiring_items(conn, int(args.days)), int(args.days))
        elif args.cmd == "expired":
            print_table(expired_items(conn), expiry_days)
        elif args.cmd == "dashboard":
            print(json.dumps(dashboard_summary(conn), indent=2, sort_keys=True))
        elif args.cmd == "readiness":
            changed = False
            if args.set_household_members:
                set_setting(conn, "household_members", args.set_household_members); changed = True
            if args.set_target_days:
                set_setting(conn, "reserve_days_target", args.set_target_days); changed = True
            if args.set_calories_per_person_day:
                set_setting(conn, "calories_per_person_day", args.set_calories_per_person_day); changed = True
            if args.set_water_litres_per_person_day:
                set_setting(conn, "water_litres_per_person_day", args.set_water_litres_per_person_day); changed = True
            if args.reserve:
                set_reserve_flags(conn, args.reserve, emergency_reserve=True, readiness_category=args.readiness_category or None); changed = True
                print(f"Marked item #{args.reserve} as emergency reserve.")
            if args.unreserve:
                set_reserve_flags(conn, args.unreserve, emergency_reserve=False); changed = True
                print(f"Removed reserve flag from item #{args.unreserve}.")
            if args.lock:
                set_reserve_flags(conn, args.lock, do_not_consume=True, readiness_category=args.readiness_category or None); changed = True
                print(f"Locked item #{args.lock} as do-not-consume reserve.")
            if args.unlock:
                set_reserve_flags(conn, args.unlock, do_not_consume=False); changed = True
                print(f"Unlocked item #{args.unlock}.")
            if args.export_json:
                print(export_readiness_json(conn, args.export_json))
            if args.list:
                print_table(reserve_items(conn), expiry_days)
            if args.json:
                print(json.dumps(readiness_summary(conn), indent=2, sort_keys=True))
            elif not args.list and not args.export_json and not args.reserve and not args.unreserve and not args.lock and not args.unlock:
                print_readiness(readiness_summary(conn))
        elif args.cmd == "use-first":
            print_use_first(use_first_items(conn, args.limit), expiry_days)
        elif args.cmd == "opened":
            mark_item_opened(conn, args.id, args.date)
            print(f"Marked item #{args.id} opened.")
        elif args.cmd == "waste":
            if args.add:
                wid = waste_item(conn, args.add, args.qty, args.reason, args.notes)
                print(f"Logged waste event #{wid} for item #{args.add}.")
            if args.export_csv:
                print(export_waste_csv(conn, args.export_csv))
            if args.list or (not args.add and not args.export_csv):
                print_waste(list_waste(conn, args.limit))
        elif args.cmd == "consume":
            consume_item(conn, args.id, args.amount, notes=args.notes)
            print(f"Consumed {args.amount:g} from item #{args.id}.")
        elif args.cmd == "restock":
            restock_item(conn, args.id, args.amount, notes=args.notes)
            print(f"Restocked {args.amount:g} to item #{args.id}.")
        elif args.cmd == "archive":
            archive_item(conn, args.id, True)
            print(f"Archived item #{args.id}.")
        elif args.cmd == "restore-item":
            archive_item(conn, args.id, False)
            print(f"Restored item #{args.id}.")
        elif args.cmd == "delete":
            delete_item(conn, args.id)
            print(f"Deleted item #{args.id}.")
        elif args.cmd == "shopping":
            if args.generate:
                added = generate_shopping_list(conn)
                print(f"Added {added} low-stock item(s) to shopping list.")
            if args.add:
                sid = add_shopping_item(conn, args.add, float(args.qty), args.unit, args.category, "manual", args.status or "Needed", args.store, float(args.price or 0), args.notes)
                print(f"Added shopping item #{sid}: {args.add}")
            if args.set_status:
                if not args.status:
                    raise ValueError("Use --status with --set-status.")
                set_shopping_status(conn, args.set_status, args.status, notes=args.notes)
                print(f"Marked shopping item #{args.set_status} {args.status}.")
            if args.check:
                set_shopping_status(conn, args.check, "Bought", notes=args.notes)
                print(f"Marked shopping item #{args.check} bought.")
            if args.urgent:
                set_shopping_status(conn, args.urgent, "Urgent", notes=args.notes)
                print(f"Marked shopping item #{args.urgent} urgent.")
            if args.skip:
                set_shopping_status(conn, args.skip, "Skipped", notes=args.notes)
                print(f"Marked shopping item #{args.skip} skipped.")
            if args.needed:
                set_shopping_status(conn, args.needed, "Needed", notes=args.notes)
                print(f"Marked shopping item #{args.needed} needed.")
            if args.restock:
                item_id = restock_from_shopping(conn, args.restock, create_missing=True)
                print(f"Restocked shopping item #{args.restock} into pantry item #{item_id}.")
            if args.export_txt:
                print(export_shopping_txt(conn, args.export_txt, include_completed=args.all))
            if args.export_csv:
                print(export_shopping_csv(conn, args.export_csv, include_completed=args.all))
            if args.print_txt:
                print(shopping_print_text(conn, include_completed=args.all), end="")
            else:
                print_shopping(list_shopping(conn, include_checked=args.all, status=args.status if not args.set_status else "", store=args.store))
        elif args.cmd == "shopping-history":
            print_shopping_history(list_shopping_history(conn, args.limit))
        elif args.cmd == "recipes":
            if args.add:
                rid = add_recipe(conn, args.add, args.category, args.servings, args.instructions, args.notes)
                print(f"Added recipe #{rid}: {args.add}")
            if args.ingredient:
                iid = add_recipe_ingredient(conn, args.ingredient, args.item, args.qty, args.unit, args.pantry_id or None, required=not args.optional, notes=args.notes)
                print(f"Added ingredient #{iid} to recipe #{args.ingredient}.")
            if args.shopping:
                added = recipe_generate_shopping(conn, args.shopping)
                print(f"Added {added} ingredient shopping item(s) for recipe #{args.shopping}.")
            if args.export_json:
                print(export_recipes_json(conn, args.export_json))
            if args.export_csv:
                print(export_recipes_csv(conn, args.export_csv))
            if args.detail:
                print_recipe_detail(recipe_to_dict(conn, args.detail))
            elif args.can_make:
                print_recipe_suggestions(recipes_can_make(conn, include_almost=True))
            elif args.suggest_use_first:
                print_recipe_suggestions(suggest_recipes_for_use_first(conn, 50))
            elif args.list or (not args.add and not args.ingredient and not args.shopping and not args.export_json and not args.export_csv):
                print_recipes(list_recipes(conn), conn)
        elif args.cmd == "meal-plan":
            if args.add:
                mid = add_meal_plan(conn, args.add, args.date, args.meal_type, args.servings, args.notes)
                print(f"Planned meal #{mid}.")
            if args.shopping:
                added = meal_plan_generate_shopping(conn, args.from_date, args.to_date, urgent=args.urgent)
                print(f"Added {added} meal-plan shopping item(s).")
            if args.list or (not args.add and not args.shopping):
                print_meal_plan(list_meal_plan(conn, args.from_date, args.to_date))
        elif args.cmd == "barcode":
            if args.from_item:
                code = learn_barcode_from_item(conn, args.from_item)
                print(f"Learned barcode profile {code} from item #{args.from_item}.")
            if args.learn:
                code = learn_barcode(conn, args.learn, args.name, args.category, args.unit, args.location, float(args.min_quantity or 0), args.preferred_store, float(args.estimated_price or 0), float(args.calories_per_unit or 0), float(args.water_litres_per_unit or 0), args.notes)
                print(f"Saved barcode profile {code}.")
            if args.delete:
                delete_barcode_profile(conn, args.delete)
                print(f"Deleted barcode profile {normalise_barcode(args.delete)}.")
            if args.import_csv:
                print(f"Imported {import_barcode_catalog_csv(conn, args.import_csv)} barcode profile(s).")
            if args.export_csv:
                print(export_barcode_catalog_csv(conn, args.export_csv))
            if args.lookup:
                row = lookup_barcode(conn, args.lookup)
                if row:
                    print_barcode_profiles([row])
                else:
                    print(f"No local barcode profile found for {normalise_barcode(args.lookup)}.")
            elif args.list or (not args.from_item and not args.learn and not args.delete and not args.import_csv and not args.export_csv):
                print_barcode_profiles(list_barcode_profiles(conn, args.query))
        elif args.cmd == "fast-add":
            minq = None if args.min_quantity == "" else float(args.min_quantity or 0)
            item_id = fast_add_item(conn, barcode=args.barcode, name=args.name, quantity=float(args.quantity or 1), unit=args.unit, category=args.category, location=args.location, expiry_date=args.expiry_date, purchase_date=args.purchase_date, min_quantity=minq, notes=args.notes, learn=not args.no_learn)
            print(f"Fast-added item #{item_id}.")
        elif args.cmd == "duplicates":
            if args.merge_target:
                merge_items(conn, args.merge_target, args.sources, archive_sources=not args.delete_sources)
                print(f"Merged {len(args.sources)} source item(s) into item #{args.merge_target}.")
            if args.list or not args.merge_target:
                print_duplicate_groups(duplicate_groups(conn))
        elif args.cmd == "stable-lock-report":
            print(json.dumps(stable_lock_report(conn), indent=2, sort_keys=True))
        elif args.cmd == "setup":
            if args.household_members:
                set_setting(conn, "household_members", args.household_members)
            if args.reserve_days:
                set_setting(conn, "reserve_days_target", args.reserve_days)
            if args.currency:
                set_setting(conn, "default_currency", args.currency.upper())
            if args.default_store:
                set_setting(conn, "default_store", args.default_store)
            if args.expiring_days:
                set_setting(conn, "expiring_soon_days", args.expiring_days)
            if not args.show:
                set_setting(conn, "first_run_setup_complete", "1")
            print(json.dumps({
                "action": "setup",
                "household_members": get_setting(conn, "household_members", "1"),
                "reserve_days_target": get_setting(conn, "reserve_days_target", str(DEFAULT_RESERVE_DAYS_TARGET)),
                "default_currency": get_setting(conn, "default_currency", "AUD"),
                "default_store": get_setting(conn, "default_store", ""),
                "expiring_soon_days": get_setting(conn, "expiring_soon_days", str(DEFAULT_EXPIRY_SOON_DAYS)),
                "first_run_setup_complete": get_setting(conn, "first_run_setup_complete", "0"),
            }, indent=2, sort_keys=True))
        elif args.cmd == "scanner-test":
            print(json.dumps(scanner_test_payload(conn, args.code), indent=2, sort_keys=True))
        elif args.cmd == "aegis":
            payload = run_aegis_action(conn, args.action, path=args.path, days=args.days, include_completed=args.include_completed, limit=args.limit)
            print(json.dumps(payload, indent=2, sort_keys=True))
        elif args.cmd == "export-csv":
            print(export_csv(conn, args.path))
        elif args.cmd == "import-csv":
            report = validate_import_csv(conn, args.path)
            if args.report:
                json_write(Path(args.report).expanduser(), report)
            if args.validate:
                print(json.dumps(report, indent=2, sort_keys=True))
            else:
                imported = import_csv(conn, args.path, skip_duplicates=args.skip_duplicates)
                suffix = f" Validation report: {args.report}" if args.report else ""
                print(f"Imported {imported} item(s).{suffix}")
        elif args.cmd == "recovery":
            if args.verify_backup:
                print(json.dumps(verify_backup(args.verify_backup), indent=2, sort_keys=True))
            elif args.restore_preview:
                print(json.dumps(restore_preview(args.restore_preview), indent=2, sort_keys=True))
            elif args.restore:
                conn.close()
                print(json.dumps(safe_restore_db(args.restore), indent=2, sort_keys=True))
                return 0
            elif args.checksum_manifest is not None and args.checksum_manifest != "":
                print(write_checksum_manifest(conn, args.checksum_manifest))
            elif args.compact:
                print(json.dumps(compact_repair(conn), indent=2, sort_keys=True))
            elif args.audit_json:
                print(export_audit_json(conn, args.audit_json, args.limit))
            else:
                print(json.dumps(recovery_status(conn), indent=2, sort_keys=True))
        elif args.cmd == "audit-log":
            if args.export_json:
                print(export_audit_json(conn, args.export_json, args.limit))
            else:
                print(json.dumps(list_audit_events(conn, args.limit), indent=2, sort_keys=True))
        elif args.cmd == "backup":
            print(backup_db(conn, args.path or None))
        elif args.cmd == "restore":
            conn.close()
            print(restore_db(args.path))
        else:
            raise ValueError(f"Unknown command: {args.cmd}")
        return 0
    except Exception as exc:
        print(f"sentinel-pantry: error: {exc}", file=sys.stderr)
        return 2
    finally:
        try:
            conn.close()
        except Exception:
            pass


if __name__ == "__main__":
    raise SystemExit(main())
