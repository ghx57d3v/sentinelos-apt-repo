# Sentinel Pantry v0.8.0

Program 117 — SentinelOS Desktop Suite

Phase 7 AEGIS Integration and Vault Handoff Patch over v0.7.1.

## Added in v0.8.0

- Stable `sentinel-pantry aegis <action>` JSON action contract.
- Machine-readable payloads for health, summary, low-stock, expired, expiring-soon, shopping list, readiness status, inventory snapshot, waste report, and Sentinel Command status card.
- AEGIS handoff export bundle containing inventory, shopping, readiness, waste, health, summary, manifest, Sentinel Command card, and B.A.S.T.I.O.N registration JSON.
- Existing-vault export target: `~/AEGIS_Vault/Knowledge/Household/Sentinel Pantry/Exports/...`.
- No-vault fallback export target: `~/.local/share/sentinel-pantry/exports/aegis-handoff/...`.
- B.A.S.T.I.O.N backup registration JSON.
- AEGIS backup bundle for pantry and recipe SQLite databases.
- GUI **AEGIS Handoff** tab with Refresh Card, Export Handoff, B.A.S.T.I.O.N Register, and AEGIS Backup controls.
- Updated health, summary, and manifest metadata for AEGIS readiness.

## AEGIS actions

```bash
sentinel-pantry aegis contract
sentinel-pantry aegis health_check
sentinel-pantry aegis summary
sentinel-pantry aegis low_stock
sentinel-pantry aegis expired
sentinel-pantry aegis expiring_soon --days 14
sentinel-pantry aegis shopping_list
sentinel-pantry aegis readiness_status
sentinel-pantry aegis inventory_snapshot
sentinel-pantry aegis waste_report --limit 500
sentinel-pantry aegis sentinel_command_card
sentinel-pantry aegis bastion_registration
sentinel-pantry aegis backup
sentinel-pantry aegis vault_export
```

## Preserved

- Barcode Options GUI tab and local barcode catalog.
- No online barcode lookup.
- USB scanner keyboard-input compatible fast entry.
- Recipie Book layout and separate Meal Plan tab.
- AEGIS-capable recipe storage with existing `~/AEGIS_Vault` or `~/Documents/Recipies` fallback.
- Shopping, expiry rotation, waste logging, emergency/off-grid readiness, duplicate merge, CSV/JSON export, backup/restore.
- Ctrl+Q close hotkey, desktop/menu launcher, desktop launcher helper, and Sentinel Pantry icon.

Local-only posture preserved: no network, no telemetry, no cloud dependency.
